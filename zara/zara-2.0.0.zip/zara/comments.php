<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
?>

<div id="comments" class="septiani-comments-area">

    <?php $this->comments()->to($comments); ?>

    <?php if ($comments->have()): ?>

    <!-- سربرگ نظرات -->
    <div class="septiani-comments-header">
        <h3 class="septiani-comments-title">
            <i class="fa-solid fa-comments"></i>
            نظرات
            <span class="septiani-comments-count">
                (<?php
                ob_start();
                $comments->num('%d');
                echo toPersianNumbers((string)ob_get_clean());
                ?>)
            </span>
        </h3>
    </div>

    <!-- لیست نظرات — تخت: همهٔ دیدگاه‌ها (شامل پاسخ‌ها) زیر هم در یک فهرست -->
    <div class="septiani-comments-list">
        <ol class="septiani-comments-ol">
        <?php $comments->listComments([
            'before'        => '',
            'after'         => '',
            'commentStatus' => _t('در انتظار تأیید'),
        ]); ?>
        </ol>
    </div>

    <?php
    ob_start();
    $comments->pageNav('&laquo;', '&raquo;');
    echo zara_nav_fa((string)ob_get_clean());
    ?>

    <?php else: ?>

    <!-- پیام وقتی نظری وجود ندارد -->
    <div class="septiani-no-comments">
        <i class="fa-regular fa-comment-dots"></i>
        <h3>هنوز نظری ثبت نشده است</h3>
        <p>شما اولین نفری هستید که نظر می‌دهید.</p>
    </div>

    <?php endif; ?>

    <!-- فرم ارسال نظر -->
    <?php if ($this->allow('comment')): ?>
    <div id="<?php $this->respondId(); ?>" class="septiani-comment-respond">
        <h3 id="response" class="septiani-respond-title">
            <i class="fa-solid fa-pen-to-square"></i>
            <?php if ($comments->have()): ?>
            ارسال نظر جدید
            <?php else: ?>
            اولین نظر را ثبت کنید
            <?php endif; ?>
        </h3>

        <form method="post" action="<?php $this->commentUrl(); ?>" id="comment-form" class="septiani-comment-form">

            <!-- دکمه لغو پاسخ (استاندارد Typecho) -->
            <div class="septiani-cancel-reply">
                <?php $comments->cancelReply('لغو پاسخ'); ?>
            </div>

            <input type="hidden" name="parent" id="comment-parent" value="0">

            <?php if ($this->user->hasLogin()): ?>
            <div class="septiani-logged-in">
                <span>وارد شده به عنوان <strong><?php $this->user->screenName(); ?></strong></span>
                <a href="<?php $this->options->logoutUrl(); ?>" class="septiani-logout-link">خروج</a>
            </div>
            <?php else: ?>
            <div class="septiani-form-row">
                <div class="septiani-form-group">
                    <label for="author">نام *</label>
                    <input type="text" id="author" name="author" placeholder="نام شما" value="<?php $this->remember('author'); ?>" required>
                </div>
                <div class="septiani-form-group">
                    <label for="email">ایمیل *</label>
                    <input type="email" id="email" name="mail" placeholder="ایمیل شما" value="<?php $this->remember('mail'); ?>" required dir="ltr">
                </div>
            </div>
            <div class="septiani-form-group">
                <label for="url">وب‌سایت (اختیاری)</label>
                <input type="url" id="url" name="url" placeholder="https://example.com" value="<?php $this->remember('url'); ?>" dir="ltr">
            </div>
            <?php endif; ?>

            <div class="septiani-form-group">
                <label for="textarea">نظر شما *</label>
                <textarea id="textarea" name="text" placeholder="نظر خود را بنویسید..." rows="5" required><?php $this->remember('text'); ?></textarea>
            </div>

            <div class="septiani-form-actions">
                <button type="submit" class="septiani-btn">
                    ارسال نظر
                    <i class="fa-solid fa-paper-plane"></i>
                </button>
            </div>
        </form>
    </div>
    <?php else: ?>
    <div class="septiani-comments-closed">
        <i class="fa-solid fa-lock"></i>
        <p>نظرات برای این مطلب بسته شده است.</p>
    </div>
    <?php endif; ?>
</div>
