
(function () {
    if (window.__zaraIconPickerLoaded) { return; }
    window.__zaraIconPickerLoaded = true;

    var ZARA_GROUPS = {"عمومی و نماد":[["folder","پوشه"],["folder-open","پوشه باز"],["folder-plus","پوشه جدید"],["file","فایل"],["file-lines","فایل متن"],["file-pdf","فایل PDF"],["file-image","فایل تصویر"],["file-code","فایل کد"],["file-zipper","فایل فشرده"],["bookmark","نشانک"],["paperclip","گیره"],["clipboard","کلیپ‌بورد"],["copy","کپی"],["scissors","قیچی"],["thumbtack","سنجاق"],["link","لینک"],["paper-plane","پیام"],["print","چاپ"],["envelope","ایمیل"],["phone","تلفن"],["mobile-screen","موبایل"],["fax","فکس"],["address-book","دفترچه"],["id-card","کارت شناسایی"],["globe","وب"],["wifi","وای‌فای"],["rss","آر‌اس‌اس"],["qrcode","کیوآر"],["barcode","بارکد"]],"لوگو و نشان":[["feather-alt","پر (پیش‌فرض)"],["feather-pointed","پر نوک‌تیز"],["pen","قلم"],["pen-nib","نوک قلم"],["pen-to-square","ویرایش"],["pencil","مداد"],["highlighter","ماژیک"],["brush","قلم‌مو"],["palette","پالت رنگ"],["stamp","مهر"],["award","نشان"],["trophy","جام"],["medal","مدال"],["crown","تاج"],["gem","جواهر"],["star","ستاره"],["star-half-stroke","نیم‌ستاره"],["certificate","گواهی"],["bullhorn","بوق"],["drum","طبل"],["microphone","میکروفون"],["flag","پرچم"]],"مقیسه و سلامت":[["heart","قلب"],["heart-pulse","سلامت"],["hand-holding-heart","دست و قلب"],["hand-holding-medical","کمک‌های درمانی"],["stethoscope","گوشی پزشکی"],["user-doctor","پزشک"],["user-nurse","پرستار"],["syringe","سرنگ"],["pills","قرص"],["capsules","کپسول"],["prescription","نسخه"],["pump-medical","پمپ"],["truck-medical","آمبولانس"],["briefcase-medical","کیس پزشکی"],["dna","دی‌ان‌ای"],["microscope","میکروسکوپ"],["flask","ارلن"],["vial","ویال"],["weight-scale","ترازو"],["tooth","دندان"],["eye","چشم"],["eye-dropper","قطره‌چکان"],["ear-listen","شنیدن"],["hands-bubbles","شست‌وشو"],["virus","ویروس"],["virus-covid","کرونا"]],"مادر و کودک":[["baby","نوزاد"],["baby-carriage","کالسکه"],["child","کودک"],["children","بچه‌ها"],["people-roof","خانواده زیر یک‌سقف"],["gamepad","دسته بازی"],["puzzle-piece","پازل"],["futbol","فوتبال"],["basketball","بسکتبال"],["volleyball","والیبال"],["table-tennis-paddle-ball","پینگ‌پنگ"],["users","افراد"],["user-group","گروه"],["people-group","جمعیت"],["hand-holding-dollar","نیاز"],["hands-holding-child","مراقبت"],["school","مدرسه"],["graduation-cap","فارغ‌التحصیلی"],["book","کتاب"],["book-open","کتاب باز"],["book-open-reader","مطالعه"],["chalkboard-user","معلم"],["suitcase","چمدان"],["suitcase-rolling","چمدان دستی"]],"فناوری و وب":[["code","کد"],["code-branch","شاخه کد"],["terminal","ترمینال"],["keyboard","کیبورد"],["laptop","لپ‌تاپ"],["laptop-code","برنامه‌نویسی"],["desktop","رایانه"],["server","سرور"],["database","پایگاه داده"],["cloud","ابر"],["cloud-arrow-up","آپلود"],["cloud-arrow-down","دانلود"],["bug","باگ"],["robot","ربات"],["microchip","ریزپردازنده"],["memory","حافظه"],["camera","دوربین"],["camera-retro","دوربین رترو"],["video","ویدئو"],["film","فیلم"],["headphones","هدفون"],["volume-high","بلندگو"],["music","موسیقی"],["guitar","گیتار"],["podcast","پادکست"],["broadcast-tower","رادیو"],["satellite-dish","دیش"]],"سفر و دنیا":[["plane","هواپیما"],["plane-departure","پرواز"],["plane-arrival","فرود"],["car","خودرو"],["car-side","خودرو نیم‌رخ"],["taxi","تاکسی"],["bus","اتوبوس"],["train","قطار"],["ship","کشتی"],["motorcycle","موتور"],["bicycle","دوچرخه"],["road","جاده"],["map","نقشه"],["map-location-dot","نقشه مکان"],["route","مسیر"],["location-dot","مکان"],["compass","قطب‌نما"],["mountain","کوه"],["sun","خورشید"],["sun-plant-wilt","آفتاب"],["moon","ماه"],["cloud-sun","ابری آفتابی"],["snowflake","برف"],["umbrella-beach","ساحل"],["tree","درخت"],["leaf","برگ"],["seedling","نهال"],["water","آب"],["fire","آتش"],["earth-americas","زمین"],["earth-asia","زمین آسیا"]],"خانه و آشپزی":[["house","خانه"],["house-chimney","خانه دودکش"],["building","ساختمان"],["city","شهر"],["warehouse","انبار"],["shop","فروشگاه"],["cart-shopping","سبد خرید"],["bag-shopping","کیف خرید"],["basket-shopping","سبد"],["tags","برچسب‌ها"],["tag","برچسب"],["percent","درصد"],["money-bill","اسکناس"],["credit-card","کارت"],["wallet","کیف پول"],["piggy-bank","قورت‌پول"],["scale-balanced","ترازو عدالت"],["handshake","معامله"],["lightbulb","ایده"],["mug-hot","نوشیدنی گرم"],["mug-saucer","فنجان"],["coffee","قهوه"],["jar","شیشه مربا"],["utensils","قاشق و چنگال"],["hat-cowboy","کابوی"],["pizza-slice","پیتزا"],["burger","برگر"],["ice-cream","بستنی"],["cake-candles","کیک تولد"],["bread-slice","نان"],["bowl-food","کاسه غذا"],["bottle-water","بطری آب"],["wine-glass","شراب"]],"کسب‌وکار و کار":[["briefcase","کیف کار"],["building-columns","بانک"],["chart-line","نمودار خط"],["chart-pie","نمودار دایره"],["chart-column","نمودار ستون"],["chart-simple","نمودار ساده"],["magnifying-glass-chart","تحلیل"],["arrow-trend-up","رشد"],["coins","سکه‌ها"],["sack-dollar","کیس پول"],["receipt","رسید"],["bell-concierge","زنگ کانسیرج"],["calculator","ماشین حساب"],["users-gear","مدیریت"],["user-tie","مدیر"],["user-graduate","دانش‌آموخته"],["gear","تنظیمات"],["screwdriver-wrench","ابزار"],["wrench","آچار"],["hammer","چکش"],["toolbox","جعبه‌ابزار"],["plug","پریز"],["bolt","برق"],["battery-full","باتری"],["industry","کارخانه"],["truck","کامیون"],["truck-fast","ارسال سریع"],["dolly","جابه‌جایی"],["calendar-days","تقویم"],["calendar-check","تقویم تیک"],["clock","ساعت"],["hourglass","شیشه ساعت"],["list-check","چک‌لیست"],["clipboard-check","بررسی"],["bell","اعلان"]],"ورزش و سرگرمی":[["person-running","دویدن"],["person-biking","دوچرخه‌سواری"],["person-swimming","شنا"],["person-skiing","اسکی"],["dumbbell","دمبل"],["baseball","بیسبال"],["golf-ball-tee","گلف"],["chess","شطرنج"],["dice","تاس"],["crosshairs","هدف"],["bowling-ball","بولینگ"],["person-falling","سقوط"],["heart-crack","شکستگی قلبی"],["wine-bottle","بطری"],["martini-glass","کوکتل"],["beer-mug-empty","آبجو"],["smoking","سیگار"],["couch","مبل"],["tv","تلویزیون"],["mobile-screen-button","موبایل کلید"],["paintbrush","قلم نقاشی"],["masks-theater","تئاتر"],["shirt","پیراهن"],["user-astronaut","فضانورد"]],"خوراک":[["plate-wheat","ظرف غذا"],["apple-whole","سیب"],["cookie-bite","کلوچه"],["carrot","هویج"],["fish","ماهی"],["egg","تخم‌مرغ"],["drumstick-bite","ران"],["cheese","پنیر"],["bowl-rice","کاسه برنج"]],"پیام و شبکه":[["comment","نظر"],["comments","نظرات"],["message","پیام"],["envelope-open-text","نامه باز"],["inbox","صندوق ورودی"],["at","ایمیل علامت"],["share-nodes","اشتراک"],["retweet","بازنشر"],["hashtag","هشتگ"],["user","کاربر"],["user-plus","کاربر جدید"],["user-check","تأیید کاربر"],["circle-user","پروفایل"],["id-badge","نشان شناسایی"],["heart-circle-plus","لایک جدید"],["face-smile","لبخند"],["face-grin-stars","ستاره چهره"],["face-laugh-squint","خنده"],["face-angry","عصبانی"],["face-kiss-wink-heart","بوسه"]],"دسته و آرشیو":[["layer-group","لایه‌ها"],["diagram-project","دیاگرام"],["sitemap","نقشه سایت"],["network-wired","شبکه"],["table-cells","جدول"],["table-list","لیست جدول"],["timeline","تایم‌لاین"],["arrows-turn-to-dots","مسیر"],["arrow-right-long","جهت"],["arrow-left-long","جهت چپ"],["angles-right","چهارگوشه"],["shuffle","برزن"],["rotate","چرخش"],["recycle","بازیافت"],["history","تاریخچه"],["box-archive","بایگانی"],["boxes-stacked","جعبه‌ها"],["cube","مکعب"],["cubes","مکعب‌ها"],["circle-info","اطلاعات"],["circle-question","سؤال"],["circle-exclamation","هشدار"],["circle-check","موفق"],["circle-xmark","خطا"],["lock","قفل"],["lock-open","باز"],["key","کلید"],["shield-halved","سپر"],["user-shield","امنیت کاربر"],["triangle-exclamation","احتیاط"],["spinner","چرخش بار"],["wand-magic-sparkles","جادو"]]};

    function ready(fn) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', fn);
        } else {
            fn();
        }
    }

    function injectCss(href) {
        if (!document.querySelector('link[data-zara-fa]')) {
            var link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = href;
            link.setAttribute('data-zara-fa', '1');
            document.head.appendChild(link);
        }
    }

    function injectStyle() {
        if (document.getElementById('zara-picker-style')) { return; }
        var css = [
            '.zara-picker-root{display:block;margin:6px 0 0}',
            '.zara-picker-box{background:#fffdf9;border:1px solid #d9cdb3;border-radius:10px;padding:12px;font-family:inherit}',
            '.zara-picker-head{display:flex;flex-direction:column;gap:2px;margin-bottom:10px}',
            '.zara-picker-head strong{font-size:13px;color:#3e3a36}',
            '.zara-picker-hint{font-size:12px;color:#8a8177}',
            '.zara-picker-rows{list-style:none;margin:0;padding:0;max-height:300px;overflow:auto}',
            '.zara-picker-row{display:flex;align-items:center;gap:10px;padding:7px 10px;border-bottom:1px dashed #e8dfc9;border-radius:6px}',
            '.zara-picker-row:last-child{border-bottom:0}',
            '.zara-picker-row:hover{background:#f7f1e4}',
            '.zara-picker-icon{width:34px;height:34px;display:inline-flex;align-items:center;justify-content:center;background:#f1e9d8;border:1px solid #d9cdb3;border-radius:8px;color:#b58b6b;font-size:15px;flex:none}',
            '.zara-picker-name{font-size:13px;color:#3e3a36;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
            '.zara-picker-slug{font-size:11px;color:#a89e91;direction:ltr;flex:none}',
            '.zara-picker-choose{flex:none;cursor:pointer;font-size:12px;font-family:inherit;color:#8a5a2b;background:#f5ead8;border:1px solid #d9cdb3;border-radius:20px;padding:4px 12px;transition:all .15s}',
            '.zara-picker-choose:hover{background:#b58b6b;color:#fff;border-color:#b58b6b}',
            '.zara-picker-reset{flex:none;cursor:pointer;font-size:11px;font-family:inherit;color:#b05c5c;background:none;border:1px solid #e5c9c9;border-radius:20px;padding:4px 10px;margin-right:6px}',
            '.zara-picker-reset:hover{background:#b05c5c;color:#fff}',
            '.zara-picker-empty{font-size:12px;color:#8a8177;padding:8px;background:#f7f1e4;border-radius:8px}',
            /* مودال */
            '.zara-ip-modal{position:fixed;inset:0;z-index:99999;direction:rtl;display:flex;align-items:center;justify-content:center;background:rgba(40,32,24,.55);backdrop-filter:blur(3px);opacity:0;visibility:hidden;transition:opacity .2s,visibility .2s;font-family:inherit}',
            '.zara-ip-modal.show{opacity:1;visibility:visible}',
            '.zara-ip-dialog{background:#fffdf9;border:1px solid #d9cdb3;border-radius:14px;width:min(680px,94vw);max-height:86vh;display:flex;flex-direction:column;box-shadow:0 24px 70px rgba(62,58,54,.35);transform:translateY(14px);transition:transform .2s}',
            '.zara-ip-modal.show .zara-ip-dialog{transform:translateY(0)}',
            '.zara-ip-head{display:flex;align-items:center;gap:10px;padding:14px 16px;border-bottom:1px solid #e8dfc9}',
            '.zara-ip-title{font-size:14px;font-weight:700;color:#3e3a36;display:flex;align-items:center;gap:8px}',
            '.zara-ip-title .zara-ip-cur{width:32px;height:32px;display:inline-flex;align-items:center;justify-content:center;background:#f1e9d8;border-radius:8px;color:#b58b6b;font-size:15px}',
            '.zara-ip-close{margin-right:auto;cursor:pointer;width:32px;height:32px;border:none;background:#f1e9d8;border-radius:50%;color:#6b6257;font-size:16px;line-height:1}',
            '.zara-ip-close:hover{background:#b05c5c;color:#fff}',
            '.zara-ip-search{padding:12px 16px 8px}',
            '.zara-ip-search input{width:100%;box-sizing:border-box;padding:9px 14px;border:1px solid #d9cdb3;border-radius:24px;font-family:inherit;font-size:13px;background:#fff;color:#3e3a36;outline:none}',
            '.zara-ip-search input:focus{border-color:#b58b6b;box-shadow:0 0 0 3px rgba(181,139,107,.18)}',
            '.zara-ip-tabs{display:flex;flex-wrap:wrap;gap:6px;padding:4px 16px 10px;border-bottom:1px solid #e8dfc9}',
            '.zara-ip-tab{cursor:pointer;font-size:12px;font-family:inherit;border:1px solid #d9cdb3;background:#f7f1e4;color:#6b6257;border-radius:16px;padding:4px 12px}',
            '.zara-ip-tab.on{background:#b58b6b;color:#fff;border-color:#b58b6b}',
            '.zara-ip-body{overflow:auto;padding:12px 16px;flex:1}',
            '.zara-ip-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(64px,1fr));gap:8px}',
            '.zara-ip-item{cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:5px;padding:9px 4px;border:1px solid transparent;border-radius:10px;background:#fbf7ef;color:#7a6a55;transition:all .12s}',
            '.zara-ip-item i{font-size:19px}',
            '.zara-ip-item span{font-size:10px;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:ltr}',
            '.zara-ip-item:hover{border-color:#b58b6b;color:#8a5a2b;transform:translateY(-2px)}',
            '.zara-ip-item.on{border-color:#b58b6b;background:#f5ead8;color:#8a5a2b}',
            '.zara-ip-foot{padding:10px 16px;border-top:1px solid #e8dfc9;display:flex;justify-content:space-between;align-items:center}',
            '.zara-ip-foot .zara-ip-note{font-size:11px;color:#a89e91}',
            '.zara-ip-resetall{cursor:pointer;border:1px solid #e5c9c9;color:#b05c5c;background:none;border-radius:18px;padding:5px 12px;font-size:12px;font-family:inherit}',
            '.zara-ip-resetall:hover{background:#b05c5c;color:#fff}',
            '.zara-ip-search-empty{padding:22px;text-align:center;color:#a89e91;font-size:13px}'
        ].join('');
        var st = document.createElement('style');
        st.id = 'zara-picker-style';
        st.textContent = css;
        document.head.appendChild(st);
    }

    /* ---------- ساخت ردیف‌ها برای هر انتخابگر ---------- */

    function findInput(target, single) {
        if (single) {
            return document.querySelector('input[type="text"][name="' + target + '"]')
                || document.querySelector('[name="' + target + '"]');
        }
        return document.querySelector('textarea[name="' + target + '"]') || document.querySelector('[name="' + target + '"]');
    }

    function buildPicker(root) {
        var target = root.getAttribute('data-target');
        var def = root.getAttribute('data-default') || 'fa-folder';
        var single = root.getAttribute('data-single') === '1';
        var items = [];
        try { items = JSON.parse(root.getAttribute('data-items') || '[]'); } catch (e) { items = []; }

        var input = findInput(target, single);
        if (!input && !single) { return; }

        function readMap() {
            if (single) {
                var v = (input && input.value ? input.value : '').trim();
                return v || def;
            }
            var m = {};
            try { m = JSON.parse(input.value || '{}'); } catch (e) { m = {}; }
            return m;
        }

        function writeMap(m) {
            if (single) {
                if (input) { input.value = m; }
            } else if (input) {
                input.value = JSON.stringify(m);
            }
        }

        var box = document.createElement('div');
        box.className = 'zara-picker-box';

        var head = document.createElement('div');
        head.className = 'zara-picker-head';
        var strong = document.createElement('strong');
        strong.textContent = root.getAttribute('data-title') || 'انتخاب آیکون';
        var hint = document.createElement('span');
        hint.className = 'zara-picker-hint';
        hint.textContent = 'روی «انتخاب آیکون» بزنید و از پنجرهٔ جست‌وجو یک آیکون بردارید. تغییرات با دکمهٔ ذخیرهٔ تنظیمات ثبت می‌شوند.';
        head.appendChild(strong);
        head.appendChild(hint);
        box.appendChild(head);

        if (single) {
            var row = buildSingleRow(def, readMap, writeMap, root.getAttribute('data-title') || 'انتخاب آیکون');
            box.appendChild(row);
        } else if (items.length === 0) {
            var empty = document.createElement('div');
            empty.className = 'zara-picker-empty';
            empty.textContent = 'هنوز دسته‌بندی یا برگه‌ای برای نمایش وجود ندارد؛ پس از ساختن، این بخش خودکار فهرست می‌شود.';
            box.appendChild(empty);
        } else {
            var list = document.createElement('ul');
            list.className = 'zara-picker-rows';

            items.forEach(function (item) {
                var slug = String(item.slug || '');
                var li = document.createElement('li');
                li.className = 'zara-picker-row';
                li.setAttribute('data-slug', slug);

                var ic = document.createElement('span');
                ic.className = 'zara-picker-icon';
                var i = document.createElement('i');
                i.className = 'fa-solid';
                ic.appendChild(i);

                var nm = document.createElement('span');
                nm.className = 'zara-picker-name';
                nm.textContent = item.name || slug;

                var sl = document.createElement('span');
                sl.className = 'zara-picker-slug';
                sl.textContent = slug;

                var reset = document.createElement('button');
                reset.type = 'button';
                reset.className = 'zara-picker-reset';
                reset.textContent = 'پیش‌فرض';

                var choose = document.createElement('button');
                choose.type = 'button';
                choose.className = 'zara-picker-choose';
                choose.textContent = 'انتخاب آیکون';

                li.appendChild(ic);
                li.appendChild(nm);
                li.appendChild(sl);
                li.appendChild(reset);
                li.appendChild(choose);
                list.appendChild(li);

                function paint() {
                    var m = readMap();
                    var cur = (m && m[slug]) ? String(m[slug]) : def;
                    cur = cur.replace(/^(fa-solid|fas|fa)\s+/, '');
                    cur = /^fa-/.test(cur) ? cur : 'fa-' + cur;
                    i.className = 'fa-solid ' + cur;
                }

                choose.addEventListener('click', function () {
                    var m = readMap();
                    var cur = (m && m[slug]) ? String(m[slug]) : '';
                    openModal({
                        current: cur,
                        title: item.name || slug,
                        onPick: function (name) {
                            var mm = readMap();
                            mm[slug] = name;
                            writeMap(mm);
                            paint();
                        },
                        onClear: function () {
                            var mm = readMap();
                            delete mm[slug];
                            writeMap(mm);
                            paint();
                        }
                    });
                });

                reset.addEventListener('click', function () {
                    var mm = readMap();
                    delete mm[slug];
                    writeMap(mm);
                    paint();
                });

                paint();
            });

            box.appendChild(list);
        }

        root.textContent = '';
        root.appendChild(box);
    }

    function buildSingleRow(def, readMap, writeMap, title) {
        var row = document.createElement('div');
        row.className = 'zara-picker-row';
        var ic = document.createElement('span');
        ic.className = 'zara-picker-icon';
        var i = document.createElement('i');
        i.className = 'fa-solid';
        ic.appendChild(i);

        function paint() {
            var v = String(readMap() || def).trim();
            v = v.replace(/^(fa-solid|fas|fa)\s+/, '');
            v = /^fa-/.test(v) ? v : 'fa-' + v;
            i.className = 'fa-solid ' + v;
        }

        var choose = document.createElement('button');
        choose.type = 'button';
        choose.className = 'zara-picker-choose';
        choose.textContent = 'انتخاب آیکون';

        var reset = document.createElement('button');
        reset.type = 'button';
        reset.className = 'zara-picker-reset';
        reset.textContent = 'پیش‌فرض';

        choose.addEventListener('click', function () {
            openModal({
                current: String(readMap() || ''),
                title: title,
                onPick: function (name) { writeMap(name); paint(); },
                onClear: function () { writeMap(def); paint(); }
            });
        });
        reset.addEventListener('click', function () { writeMap(def); paint(); });

        row.appendChild(ic);
        row.appendChild(choose);
        row.appendChild(reset);
        paint();
        return row;
    }

    /* ---------- مودال ---------- */

    var modal = null, modalState = null;

    function buildModal() {
        modal = document.createElement('div');
        modal.className = 'zara-ip-modal';

        var dialog = document.createElement('div');
        dialog.className = 'zara-ip-dialog';

        var head = document.createElement('div');
        head.className = 'zara-ip-head';
        var title = document.createElement('div');
        title.className = 'zara-ip-title';
        var curIcon = document.createElement('span');
        curIcon.className = 'zara-ip-cur';
        var curI = document.createElement('i');
        curI.className = 'fa-solid fa-star';
        curIcon.appendChild(curI);
        var titleText = document.createElement('span');
        titleText.textContent = 'انتخاب آیکون';
        title.appendChild(curIcon);
        title.appendChild(titleText);
        var close = document.createElement('button');
        close.type = 'button';
        close.className = 'zara-ip-close';
        close.innerHTML = '&times;';
        head.appendChild(title);
        head.appendChild(close);

        var search = document.createElement('div');
        search.className = 'zara-ip-search';
        var searchInput = document.createElement('input');
        searchInput.type = 'text';
        searchInput.placeholder = 'جست‌وجو… (مثلاً: قلب، عکس، code، baby)';
        search.appendChild(searchInput);

        var tabs = document.createElement('div');
        tabs.className = 'zara-ip-tabs';

        var body = document.createElement('div');
        body.className = 'zara-ip-body';

        var foot = document.createElement('div');
        foot.className = 'zara-ip-foot';
        var note = document.createElement('span');
        note.className = 'zara-ip-note';
        note.textContent = '۳۰۰+ آیکون آفلاین از فونت آیکون خود پوسته';
        var resetAll = document.createElement('button');
        resetAll.type = 'button';
        resetAll.className = 'zara-ip-resetall';
        resetAll.textContent = 'حذف انتخاب';
        foot.appendChild(note);
        foot.appendChild(resetAll);

        dialog.appendChild(head);
        dialog.appendChild(search);
        dialog.appendChild(tabs);
        dialog.appendChild(body);
        dialog.appendChild(foot);
        modal.appendChild(dialog);
        document.body.appendChild(modal);

        close.addEventListener('click', closeModal);
        resetAll.addEventListener('click', function () {
            if (modalState && modalState.onClear) { modalState.onClear(); }
            closeModal();
        });
        modal.addEventListener('click', function (e) {
            if (e.target === modal) { closeModal(); }
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && modal.classList.contains('show')) { closeModal(); }
        });

        var activeTab = '__all__';

        function renderTabs() {
            tabs.textContent = '';
            var groups = [['__all__', 'همه']].concat(Object.keys(ZARA_GROUPS).map(function (g) { return [g, g]; }));
            groups.forEach(function (pair) {
                var b = document.createElement('button');
                b.type = 'button';
                b.className = 'zara-ip-tab' + (activeTab === pair[0] ? ' on' : '');
                b.textContent = pair[1];
                b.addEventListener('click', function () {
                    activeTab = pair[0];
                    searchInput.value = '';
                    renderTabs();
                    renderGrid();
                });
                tabs.appendChild(b);
            });
        }

        function bareName(v) {
            v = String(v || '').trim();
            v = v.replace(/^(fa-solid|fa-regular|fa-brands|fas|far|fab|fa)\s+/, '');
            v = v.replace(/^fa-/, '');
            return v;
        }

        function renderGrid() {
            var raw = searchInput.value.trim();
            var q = raw.toLowerCase();
            body.textContent = '';
            var grid = document.createElement('div');
            grid.className = 'zara-ip-grid';
            var found = 0;

            var groups = (activeTab === '__all__') ? Object.keys(ZARA_GROUPS) : [activeTab];
            groups.forEach(function (g) {
                ZARA_GROUPS[g].forEach(function (pair) {
                    var name = pair[0], label = pair[1] || '';
                    if (q && name.indexOf(q) === -1 && label.indexOf(raw) === -1) { return; }
                    found++;
                    var item = document.createElement('div');
                    item.className = 'zara-ip-item';
                    item.setAttribute('title', label + ' — ' + name);
                    var i = document.createElement('i');
                    i.className = 'fa-solid fa-' + name;
                    var sp = document.createElement('span');
                    sp.textContent = name;
                    item.appendChild(i);
                    item.appendChild(sp);

                    if (modalState && bareName(modalState.current) === name) {
                        item.classList.add('on');
                    }

                    item.addEventListener('click', function () {
                        if (modalState && modalState.onPick) { modalState.onPick('fa-' + name); }
                        closeModal();
                    });
                    grid.appendChild(item);
                });
            });

            if (found === 0) {
                var empty = document.createElement('div');
                empty.className = 'zara-ip-search-empty';
                empty.textContent = 'آیکونی مطابق جست‌وجو پیدا نشد.';
                body.appendChild(empty);
            } else {
                body.appendChild(grid);
            }
        }

        searchInput.addEventListener('input', renderGrid);
        searchInput.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') { e.preventDefault(); }
        });

        modal._render = function () {
            renderTabs();
            renderGrid();
            setTimeout(function () { searchInput.focus(); }, 120);
        };
        modal._setTitle = function (text, icon) {
            titleText.textContent = text;
            curI.className = 'fa-solid ' + (icon || 'fa-star');
        };
    }

    function openModal(state) {
        if (!modal) { buildModal(); }
        modalState = state;
        modal._setTitle(state.title, state.current || 'fa-star');
        modal.classList.add('show');
        modal._render();
    }

    function closeModal() {
        if (modal) { modal.classList.remove('show'); modalState = null; }
    }

    /* ---------- راه‌اندازی ---------- */

    ready(function () {
        var roots = document.querySelectorAll('.zara-picker-root');
        if (roots.length === 0) { return; }

        var themeUrl = roots[0].getAttribute('data-themeurl');
        if (themeUrl) { injectCss(themeUrl + '/css/all.css'); }
        injectStyle();

        roots.forEach(buildPicker);
    });
})();
