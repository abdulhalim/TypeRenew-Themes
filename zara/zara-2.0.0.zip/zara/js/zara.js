(function () {
    'use strict';

    var docEl = document.documentElement;

    /* ================================================================
     *  ۱) دارک‌مود
     * ================================================================ */

    var THEME_COLORS = { light: '#faf7f2', dark: '#1c1815' };

    function applyTheme(mode, persist) {
        if (mode === 'dark') {
            docEl.classList.add('dark');
        } else {
            docEl.classList.remove('dark');
        }
        docEl.setAttribute('data-zara-theme', mode);

        var meta = document.getElementById('zara-meta-theme');
        if (meta) { meta.setAttribute('content', THEME_COLORS[mode] || THEME_COLORS.light); }

        if (persist) {
            try { localStorage.setItem('zara-theme', mode); } catch (e) {}
        }
    }

    window.zaraToggleTheme = function () {
        var mode = docEl.classList.contains('dark') ? 'light' : 'dark';
        applyTheme(mode, true);
    };

    // دکمه‌های تغییر تم (نوار بالا + منوی موبایل)
    function bindThemeToggles() {
        var btn = document.getElementById('zara-theme-toggle');
        if (btn) { btn.addEventListener('click', window.zaraToggleTheme); }
    }

    // همگام‌سازی حالت اولیه (اگر اسکریپت سربرگ نتوانست اجرا شود)
    if (!docEl.getAttribute('data-zara-theme')) {
        var saved = null;
        try { saved = localStorage.getItem('zara-theme'); } catch (e) {}
        applyTheme(saved === 'dark' || saved === 'light'
            ? saved
            : (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'), false);
    } else {
        applyTheme(docEl.getAttribute('data-zara-theme'), false);
    }

    // اعلان تغییر تم برای اسکریپت‌های جانبی (الگوهای CSS خودشان با متغیرهای تیره هماهنگ می‌شوند)
    function notifyThemeChange() {
        window.dispatchEvent(new CustomEvent('zara-theme-change', {
            detail: { dark: docEl.classList.contains('dark') }
        }));
    }
    var origToggle = window.zaraToggleTheme;
    window.zaraToggleTheme = function () { origToggle(); notifyThemeChange(); };

    /* ================================================================
     *  ۲) منو و جستجو (بازتعریف سراسری برای onclick)
     * ================================================================ */

    window.toggleMobileMenu = function () {
        var menu = document.getElementById('mobileMenu');
        if (!menu) { return; }
        menu.classList.toggle('show');
        document.body.style.overflow = menu.classList.contains('show') ? 'hidden' : '';
    };

    window.toggleSearchPanel = function () {
        var panel = document.getElementById('searchPanel');
        if (!panel) { return; }
        panel.classList.toggle('show');
        if (panel.classList.contains('show')) {
            document.body.style.overflow = 'hidden';
            var input = panel.querySelector('input');
            if (input) { setTimeout(function () { input.focus(); }, 300); }
        } else {
            document.body.style.overflow = '';
        }
    };

    /* ================================================================
     *  ۳) لایک نوشته (AJAX + رابط خوش‌بینانه)
     * ================================================================ */

    function faNum(n) {
        var map = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return String(n).replace(/\d/g, function (d) { return map[+d]; });
    }

    function paintLike(btn, likes, liked) {
        var count = btn.querySelector('.zara-like-count');
        var label = btn.querySelector('.zara-like-label');
        if (count) { count.textContent = faNum(Math.max(0, likes)); }
        if (label) { label.textContent = liked ? 'پسندیدی' : 'این نوشته را بپسند'; }
        if (liked) { btn.classList.add('is-liked'); } else { btn.classList.remove('is-liked'); }
        btn.setAttribute('data-likes', String(Math.max(0, likes)));
        btn.setAttribute('data-liked', liked ? '1' : '0');
        btn.setAttribute('aria-pressed', liked ? 'true' : 'false');
    }

    function initLikeButton() {
        var likeBtn = document.getElementById('zara-like-btn');
        if (!likeBtn || !likeBtn.getAttribute('data-cid')) { return; }
        var likeBusy = false;

        likeBtn.addEventListener('click', function () {
            if (likeBusy) { return; }
            likeBusy = true;

            var cid = String(likeBtn.getAttribute('data-cid') || '');
            var before = {
                likes: parseInt(likeBtn.getAttribute('data-likes'), 10) || 0,
                liked: likeBtn.getAttribute('data-liked') === '1'
            };
            var delta = before.liked ? -1 : 1;

            // رابط خوش‌بینانه
            paintLike(likeBtn, before.likes + delta, !before.liked);
            if (delta > 0) {
                likeBtn.classList.add('pop');
                window.setTimeout(function () { likeBtn.classList.remove('pop'); }, 650);
            }

            var body = new URLSearchParams();
            body.append('zaraLike', cid);

            fetch(window.location.href, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: body.toString(),
                credentials: 'same-origin'
            })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    likeBusy = false;
                    if (!data || !data.ok) {
                        paintLike(likeBtn, before.likes, before.liked);
                        return;
                    }
                    paintLike(likeBtn, data.likes, data.liked);
                })
                .catch(function () {
                    likeBusy = false;
                    paintLike(likeBtn, before.likes, before.liked);
                });
        });
    }

    /* ================================================================
     *  ۴) پاسخ به دیدگاه (استاندارد Typecho)
     *
     *  تایپ‌چو ۱.۲+ خودش TypechoComment را در <head> تزریق می‌کند
     *  (با شناسهٔ respond درست)؛ آن‌گاه پوسته نباید آن را بازنویسی
     *  کند. اگر نسخهٔ قدیمی‌تر آن را نداشت، این نمونهٔ جایگزین با
     *  جست‌وجوی خودکار جعبهٔ پاسخ (کلاس پوسته) کار می‌کند.
     * ================================================================ */

    window.TypechoComment = window.TypechoComment || {
        dom: function (id) {
            return document.getElementById(id);
        },

        create: function (tag, attr) {
            var el = document.createElement(tag);
            for (var key in attr) {
                if (Object.prototype.hasOwnProperty.call(attr, key)) {
                    el.setAttribute(key, attr[key]);
                }
            }
            return el;
        },

        // جعبهٔ پاسخ — با شناسهٔ respond-{cid} هر نسخه، یا کلاس پوسته
        findRespond: function () {
            var box = document.querySelector('.septiani-comment-respond');
            if (box) { return box; }
            var byId = document.querySelector('div[id^="respond-"], form#respond, #respond');
            return byId || null;
        },

        getChild: function (root, node) {
            var parent = node ? node.parentNode : null;
            if (parent === null) { return null; }
            if (parent === root) { return node; }
            return this.getChild(root, parent);
        },

        reply: function (htmlId, coid, btn) {
            var comment = this.dom(htmlId);
            var response = this.findRespond();
            var input = this.dom('comment-parent');
            if (!comment || !response) { return false; }

            if (input) { input.setAttribute('value', coid); }

            if (null === this.dom('comment-form-place-holder')) {
                var holder = this.create('div', { 'id': 'comment-form-place-holder' });
                response.parentNode.insertBefore(holder, response);
            }

            // درج بعد از بدنهٔ دیدگاه (مثل اسکریپت داخلی تایپ‌چو)
            var child = null;
            try { child = btn ? this.getChild(comment, btn) : null; } catch (e) { child = null; }
            if (child && child.nextSibling) {
                comment.insertBefore(response, child.nextSibling);
            } else {
                comment.appendChild(response);
            }

            var cancel = this.dom('cancel-comment-reply-link');
            if (cancel) { cancel.style.display = ''; }
            var textarea = this.dom('textarea');
            if (textarea) { textarea.focus(); }
            return false;
        },

        cancelReply: function () {
            var response = this.findRespond();
            var holder = this.dom('comment-form-place-holder');
            var input = this.dom('comment-parent');

            if (!response || !holder) { return true; }

            var cancel = this.dom('cancel-comment-reply-link');
            if (cancel) { cancel.style.display = 'none'; }
            if (input) { input.setAttribute('value', '0'); }
            holder.parentNode.insertBefore(response, holder);
            holder.parentNode.removeChild(holder);
            return false;
        }
    };

    /* ================================================================
     *  ۵) بازگشت به بالا
     * ================================================================ */

    function initBackTop() {
        var btn = document.getElementById('septiani-back-to-top');
        if (!btn) { return; }
        var shown = false;
        var update = function () {
            var should = window.scrollY > 300;
            if (should !== shown) {
                shown = should;
                if (should) { btn.classList.add('show'); } else { btn.classList.remove('show'); }
            }
        };
        window.addEventListener('scroll', update, { passive: true });
        update();
        window.scrollToTop = function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        };
    }

    /* ================================================================
     *  ۶) لایت‌باکس تصاویر محتوا
     * ================================================================ */

    function initLightbox() {
        var lightbox = document.getElementById('septiani-lightbox');
        if (!lightbox) { return; }

        var lightboxImg = document.getElementById('septiani-lightbox-img');
        var caption = lightbox.querySelector('.septiani-lightbox-caption');

        window.openLightbox = function (src, alt) {
            if (lightboxImg) { lightboxImg.src = src; }
            if (caption) { caption.textContent = alt || ''; }
            lightbox.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        };

        window.closeLightbox = function () {
            lightbox.style.display = 'none';
            document.body.style.overflow = '';
        };

        lightbox.addEventListener('click', function (e) {
            if (e.target === lightbox || e.target.classList.contains('septiani-lightbox-close')) {
                closeLightbox();
            }
        });

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') { closeLightbox(); }
        });

        var images = document.querySelectorAll('.septiani-post-content img, .septiani-page-content img');
        images.forEach(function (img) {
            // تصاویر گرید جداگانه مدیریت می‌شوند (لینک تصویر کامل در لایت‌باکس)
            if (img.closest('.zara-img-grid')) { return; }
            img.addEventListener('click', function (e) {
                e.stopPropagation();
                openLightbox(this.src, this.alt);
            });
        });

        // گالری گرید: کلیک روی بندانگشتی → نمایش تصویر کامل در لایت‌باکس
        var gridImages = document.querySelectorAll('.zara-img-grid img');
        gridImages.forEach(function (img) {
            img.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                var link = img.closest('a');
                var href = link ? (link.getAttribute('href') || '') : '';
                var full = /\.(jpe?g|png|gif|webp|avif|bmp|svg)([?#]|$)/i.test(href) ? href : img.src;
                openLightbox(full, img.alt);
            });
        });
    }

    /* ================================================================
     *  ۷) راه‌اندازی
     * ================================================================ */

    function init() {
        bindThemeToggles();
        initLikeButton();
        initBackTop();
        initLightbox();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
