<footer class="septiani-footer p-3 p-md-5 mt-5 text-center">
    <div class="container">
        <?php
        $socials = [
            'instagram' => ['icon' => 'fab fa-instagram', 'label' => 'Instagram'],
            'twitter'   => ['icon' => 'fab fa-twitter', 'label' => 'Twitter'],
            'facebook'  => ['icon' => 'fab fa-facebook', 'label' => 'Facebook'],
            'youtube'   => ['icon' => 'fab fa-youtube', 'label' => 'YouTube'],
            'telegram'  => ['icon' => 'fab fa-telegram', 'label' => 'Telegram'],
            'whatsapp'  => ['icon' => 'fab fa-whatsapp', 'label' => 'WhatsApp']
        ];
        $hasSocial = false;
        foreach ($socials as $key => $data) {
            $url = $this->options->{$key};
            if (!empty($url)) {
                if (!$hasSocial) {
                    echo '<div class="septiani-social-links mb-3">';
                    $hasSocial = true;
                }
                echo '<a href="' . htmlspecialchars($url) . '" target="_blank" rel="noopener" class="mx-2" aria-label="' . $data['label'] . '"><i class="' . $data['icon'] . '"></i></a>';
            }
        }
        if ($hasSocial) {
            echo '</div>';
        }
        ?>
        <p class="m-0 mt-2">© <?php echo zara_jalali_year(); ?> <?php $this->options->title(); ?> - قدرت گرفته از <a class="color-accent" href="https://www.typecho.ir">تایپ‌چو فارسی</a></p>
    </div>
</footer>

<!-- Back to Top Button -->
<div id="septiani-back-to-top" onclick="scrollToTop()" aria-label="بازگشت به بالا">
    <svg viewBox="0 0 24 24">
        <polyline points="18 15 12 9 6 15"></polyline>
    </svg>
</div>

<!-- اسکریپت اصلی پوسته: دارک‌مود، لایک، نظرات، لایت‌باکس -->
<script src="<?php $this->options->themeUrl('js/zara.js'); ?>"></script>

<?php $this->footer(); ?>
</body>
</html>
