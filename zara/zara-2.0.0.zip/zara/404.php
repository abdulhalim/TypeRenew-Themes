<?php $this->need('header.php'); ?>

<main class="container my-5">
    <div class="row">
        <div class="col-lg-8 mx-auto text-center">
            <div class="zara-404-box">
                <div class="zara-404-code" aria-hidden="true">۴۰۴</div>
                <h1 class="septiani-entry-title">صفحه پیدا نشد</h1>
                <p class="text-muted zara-404-text">
                    به نظر می‌رسد این صفحه جابه‌جا شده یا هرگز وجود نداشته است.
                    نگران نباشید، راه‌های برگشت همین‌جا هستند:
                </p>
                <div class="zara-404-actions">
                    <a href="<?php $this->options->siteUrl(); ?>" class="septiani-cta">
                        <i class="fa-solid fa-house"></i>
                        <span>بازگشت به صفحه اصلی</span>
                    </a>
                    <button type="button" class="septiani-search-btn zara-404-search" onclick="toggleSearchPanel()" aria-label="جستجو">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</main>

<?php $this->need('footer.php'); ?>
