<?php
/**
 * درباره من
 *
 * @package custom
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');

$options = Typecho_Widget::widget('Widget_Options');

/* اطلاعات فقط از پنل تنظیمات */
$name  = $options->author_name  ?? '';
$bio   = $options->author_bio   ?? '';
$email = $options->author_email ?? '';
$phone = $options->author_phone ?? '';
$url   = $options->author_url   ?? '';

/* شغل: «عنوان | توضیح» — بخش دوم به‌عنوان توضیح (tooltip) نمایش داده می‌شود */
$job      = $options->author_job ?? '';
$jobTitle = $job;
$jobNote  = '';
if ($job !== '' && strpos($job, '|') !== false) {
    $parts    = array_map('trim', explode('|', $job, 2));
    $jobTitle = $parts[0] !== '' ? $parts[0] : $job;
    $jobNote  = isset($parts[1]) ? $parts[1] : '';
}

/* tel: باید با ارقام لاتین باشد */
$phoneLatin = zara_latin_digits($phone);

/* شبکه‌های اجتماعی */
$socials = [
    'instagram' => 'fa-instagram',
    'twitter'   => 'fa-twitter',
    'facebook'  => 'fa-facebook',
    'youtube'   => 'fa-youtube',
    'telegram'  => 'fa-telegram',
    'whatsapp'  => 'fa-whatsapp'
];

/* نمای کارت اطلاعات (مشترک دسکتاپ/موبایل) */
function zara_resume_card($name, $jobTitle, $jobNote, $phone, $phoneLatin, $bio, $email, $url, $socials, $options)
{
    ?>
    <?php if ($name): ?>
        <h1><?php echo htmlspecialchars($name); ?></h1>
    <?php endif; ?>

    <?php if ($jobTitle): ?>
        <?php if ($jobNote): ?>
            <div class="resume-job" title="<?php echo htmlspecialchars($jobNote); ?>">
                <?php echo htmlspecialchars($jobTitle); ?>
                <i class="fa-solid fa-circle-info resume-job-note-icon" aria-hidden="true"></i>
            </div>
            <div class="resume-job-note"><?php echo htmlspecialchars($jobNote); ?></div>
        <?php else: ?>
            <div class="resume-job"><?php echo htmlspecialchars($jobTitle); ?></div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if ($phone): ?>
        <a href="tel:<?php echo htmlspecialchars($phoneLatin); ?>" class="resume-btn">
            <i class="fa-solid fa-phone"></i> تماس بگیرید
        </a>
    <?php endif; ?>

    <?php if ($bio): ?>
        <div class="resume-bio"><?php echo nl2br(htmlspecialchars($bio)); ?></div>
    <?php endif; ?>

    <div class="resume-contact-info">
        <?php if ($email): ?>
            <a class="contact-line" href="mailto:<?php echo htmlspecialchars($email); ?>">
                <i class="fa-solid fa-envelope"></i> <span dir="ltr"><?php echo htmlspecialchars($email); ?></span>
            </a>
        <?php endif; ?>
        <?php if ($phone): ?>
            <div class="contact-line"><i class="fa-solid fa-phone"></i> <?php echo htmlspecialchars($phone); ?></div>
        <?php endif; ?>
        <?php if ($url): ?>
            <a class="contact-line" href="<?php echo htmlspecialchars($url); ?>" target="_blank" rel="noopener">
                <i class="fa-solid fa-globe"></i> <span dir="ltr"><?php echo htmlspecialchars((string)parse_url($url, PHP_URL_HOST) ?: $url); ?></span>
            </a>
        <?php endif; ?>
    </div>

    <?php
    $hasSocial = false;
    foreach ($socials as $key => $icon) {
        if (!empty($options->{$key})) {
            $hasSocial = true;
            break;
        }
    }
    if ($hasSocial): ?>
        <div class="resume-divider"></div>
        <div class="resume-socials">
            <?php foreach ($socials as $key => $icon): ?>
                <?php if (!empty($options->{$key})): ?>
                    <a href="<?php echo htmlspecialchars($options->{$key}); ?>" target="_blank" rel="noopener"><i class="fa-brands <?php echo $icon; ?>"></i></a>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?php
}
?>
<section class="resume-section">

    <div class="container">
    <div class="resume-wrap">

    <!-- طرح دسکتاپ (تصویر + کارت در کنار هم) -->
    <div class="resume-container-desktop">
        <div class="resume-image-desktop">
            <img src="<?php echo htmlspecialchars((string)getAuthorImage()); ?>" alt="<?php echo htmlspecialchars($name ?: 'نویسنده'); ?>">
        </div>
        <div class="resume-card-desktop">
            <?php zara_resume_card($name, $jobTitle, $jobNote, $phone, $phoneLatin, $bio, $email, $url, $socials, $options); ?>
        </div>
    </div>

    <!-- طرح موبایل/تبلت (دو کارت مجزا) -->
    <div class="resume-container-mobile">
        <!-- کارت تصویر -->
        <div class="resume-card-mobile-image">
            <img src="<?php echo htmlspecialchars((string)getAuthorImage()); ?>" alt="<?php echo htmlspecialchars($name ?: 'نویسنده'); ?>">
        </div>
        <!-- کارت اطلاعات -->
        <div class="resume-card-mobile-info">
            <?php zara_resume_card($name, $jobTitle, $jobNote, $phone, $phoneLatin, $bio, $email, $url, $socials, $options); ?>
        </div>
    </div>

    </div>
    </div>

    <?php
    /* محتوای برگهٔ «درباره من» (هرچه در ویرایشگر نوشته شده باشد) */
    ob_start();
    $this->content();
    $pageContent = trim((string)ob_get_clean());
    if ($pageContent !== ''):
    ?>
    <div class="container zara-about-content-wrap">
        <div class="septiani-page-content zara-about-content">
            <?php echo $pageContent; ?>
        </div>
    </div>
    <?php endif; ?>

</section>

<div class="septiani-lightbox" id="septiani-lightbox">
    <span class="septiani-lightbox-close">&times;</span>
    <img class="septiani-lightbox-content" id="septiani-lightbox-img" alt="">
    <div class="septiani-lightbox-caption"></div>
</div>

<?php $this->need('footer.php'); ?>
