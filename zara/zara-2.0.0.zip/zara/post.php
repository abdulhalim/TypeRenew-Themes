<?php $this->need('header.php'); ?>

<?php
$zaraCid = (int)$this->cid;
$zaraViews = zara_views($zaraCid);
$zaraLikes = zara_likes($zaraCid);
$zaraLiked = zara_is_liked($zaraCid);
$zaraShowViews = zara_opt('zaraShowViews', '1') === '1';
$zaraShowLikes = zara_opt('zaraShowLikes', '1') === '1';
?>

<main class="container my-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <?php $cover = themePostCover($this); ?>
            <?php if ($cover): ?>
                <div class="septiani-post-cover mb-4">
                    <img src="<?php echo htmlspecialchars($cover); ?>" alt="<?php $this->title(); ?>" class="img-fluid">
                </div>
            <?php endif; ?>

            <article class="septiani-post">
                <h1 class="septiani-entry-title text-center"><?php $this->title(); ?></h1>
                <div class="septiani-post-meta-full text-center text-muted mb-4">
                    <span><i class="fas fa-calendar-alt"></i>
                        <?php echo getLocalizedDate((int)$this->created, 'Y/m/d'); ?>
                    </span>
                    <span class="ms-3"><i class="fas fa-user"></i> <?php $this->author(); ?></span>
                    <?php if ($zaraShowViews): ?>
                    <span class="ms-3 zara-meta-views"><i class="fa-solid fa-eye"></i> <?php echo zara_num($zaraViews); ?> بازدید</span>
                    <?php endif; ?>
                    <?php if ($zaraShowLikes): ?>
                    <span class="ms-3 zara-meta-likes"><i class="fa-solid fa-heart"></i> <?php echo zara_num($zaraLikes); ?> پسند</span>
                    <?php endif; ?>
                </div>

                <?php if (!empty($this->categories)): ?>
                    <div class="zara-post-categories text-center mb-4">
                        <?php foreach ($this->categories as $cat): ?>
                            <a href="<?php echo htmlspecialchars($cat['permalink']); ?>" class="zara-cat-chip">
                                <i class="fa-solid <?php echo getCategoryIcon($cat['slug']); ?>"></i>
                                <?php echo htmlspecialchars($cat['name']); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="septiani-post-content">
                    <?php echo zara_image_grid((string)$this->content); ?>
                </div>

                <?php if (!empty($this->tags)): ?>
                    <div class="septiani-post-tags text-center mt-5">
                        <?php foreach ($this->tags as $tag): ?>
                            <a href="<?php echo htmlspecialchars($tag['permalink']); ?>" class="septiani-tag">#<?php echo htmlspecialchars($tag['name']); ?></a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($zaraShowLikes): ?>
                <div class="zara-like-box text-center mt-4" aria-label="پسندیدن نوشته">
                    <button type="button"
                            class="zara-like-btn<?php echo $zaraLiked ? ' is-liked' : ''; ?>"
                            id="zara-like-btn"
                            data-cid="<?php echo $zaraCid; ?>"
                            data-likes="<?php echo $zaraLikes; ?>"
                            data-liked="<?php echo $zaraLiked ? '1' : '0'; ?>"
                            aria-pressed="<?php echo $zaraLiked ? 'true' : 'false'; ?>">
                        <i class="fa-solid fa-heart"></i>
                        <span class="zara-like-count"><?php echo zara_num($zaraLikes); ?></span>
                        <span class="zara-like-label"><?php echo $zaraLiked ? 'پسندیدی' : 'این نوشته را بپسند'; ?></span>
                    </button>
                </div>
                <?php endif; ?>
            </article>

            <?php
            /* ناوبری نوشتهٔ قبلی / بعدی — مثل پوسته‌های دیگر، پایین نوشتهٔ اصلی */
            ob_start();
            $this->thePrev();
            $zaraPrevLink = trim((string)ob_get_clean());
            ob_start();
            $this->theNext();
            $zaraNextLink = trim((string)ob_get_clean());
            ?>
            <?php if ($zaraPrevLink !== '' || $zaraNextLink !== ''): ?>
            <nav class="zara-post-nav" aria-label="ناوبری نوشته‌ها">
                <?php if ($zaraPrevLink !== ''): ?>
                <div class="zara-post-nav-card zara-post-nav-prev">
                    <span class="zara-post-nav-label">
                        <i class="fa-solid fa-arrow-right-long" aria-hidden="true"></i> نوشتهٔ قبلی
                    </span>
                    <span class="zara-post-nav-title"><?php echo $zaraPrevLink; ?></span>
                </div>
                <?php endif; ?>
                <?php if ($zaraNextLink !== ''): ?>
                <div class="zara-post-nav-card zara-post-nav-next">
                    <span class="zara-post-nav-label">
                        نوشتهٔ بعدی <i class="fa-solid fa-arrow-left-long" aria-hidden="true"></i>
                    </span>
                    <span class="zara-post-nav-title"><?php echo $zaraNextLink; ?></span>
                </div>
                <?php endif; ?>
            </nav>
            <?php endif; ?>

            <?php
            /* کارت‌های مطالب مرتبط — بر اساس برچسب‌های مشترک (استاندارد تایپ‌چو) */
            $zaraRelated = $this->related(3);
            ?>
            <?php if ($zaraRelated->have()): ?>
            <section class="zara-related" aria-label="مطالب مرتبط">
                <h3 class="zara-related-title">
                    <i class="fa-solid fa-layer-group" aria-hidden="true"></i>
                    مطالب مرتبط
                </h3>
                <div class="zara-related-grid">
                    <?php while ($zaraRelated->next()): ?>
                    <?php $zaraRelThumb = themePostCover($zaraRelated); ?>
                    <a class="zara-related-card" href="<?php echo htmlspecialchars($zaraRelated->permalink); ?>">
                        <div class="zara-related-thumb<?php echo $zaraRelThumb ? '' : ' is-empty'; ?>">
                            <?php if ($zaraRelThumb): ?>
                            <img src="<?php echo htmlspecialchars($zaraRelThumb); ?>"
                                 alt="<?php echo htmlspecialchars($zaraRelated->title); ?>"
                                 loading="lazy"
                                 onerror="this.onerror=null;this.style.display='none';this.closest('.zara-related-thumb').classList.add('is-empty');">
                            <?php endif; ?>
                            <i class="fa-solid fa-feather-alt" aria-hidden="true"></i>
                        </div>
                        <div class="zara-related-body">
                            <h4 class="zara-related-name"><?php echo htmlspecialchars($zaraRelated->title); ?></h4>
                            <p class="zara-related-excerpt"><?php echo themeExcerpt($zaraRelated->excerpt, 68); ?></p>
                            <span class="zara-related-date">
                                <i class="fa-regular fa-calendar" aria-hidden="true"></i>
                                <?php echo getLocalizedDate((int)$zaraRelated->created, 'Y/m/d'); ?>
                            </span>
                        </div>
                    </a>
                    <?php endwhile; ?>
                </div>
            </section>
            <?php endif; ?>

            <?php echo getAuthorBox(); ?>
            <?php $this->need('comments.php'); ?>
        </div>
    </div>
</main>

<div class="septiani-lightbox" id="septiani-lightbox">
    <span class="septiani-lightbox-close">&times;</span>
    <img class="septiani-lightbox-content" id="septiani-lightbox-img" alt="">
    <div class="septiani-lightbox-caption"></div>
</div>

<?php $this->need('footer.php'); ?>
