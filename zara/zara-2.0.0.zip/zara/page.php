<?php $this->need('header.php'); ?>

<main class="container my-5">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <?php $cover = themePostCover($this); ?>
            <?php if ($cover): ?>
                <div class="septiani-page-cover mb-4">
                    <img src="<?php echo htmlspecialchars($cover); ?>" alt="<?php $this->title(); ?>" class="img-fluid">
                </div>
            <?php endif; ?>

            <article class="septiani-page">
                <h1 class="septiani-entry-title text-center"><?php $this->title(); ?></h1>
                <div class="septiani-page-content">
                    <?php $this->content(); ?>
                </div>
            </article>
        </div>
    </div>
</main>

<div class="septiani-lightbox" id="septiani-lightbox">
    <span class="septiani-lightbox-close">&times;</span>
    <img class="septiani-lightbox-content" id="septiani-lightbox-img" alt="">
    <div class="septiani-lightbox-caption"></div>
</div>

<?php $this->need('footer.php'); ?>
