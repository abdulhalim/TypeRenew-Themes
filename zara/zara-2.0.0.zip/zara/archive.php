<?php $this->need('header.php'); ?>

<div class="septiani-fade-edges">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <?php if ($this->have()): ?>
                    <?php while($this->next()): ?>
                    <div class="septiani-post-preview text-center">
                        <a href="<?php $this->permalink(); ?>">
                            <h2 class="septiani-entry-title"><?php $this->title(); ?></h2>
                        </a>
                        <span class="septiani-post-meta d-block mb-2">
                            <i class="fas fa-calendar-alt"></i>
                            <?php echo getLocalizedDate((int)$this->created, 'Y/m/d'); ?>
                        </span>
                        <p class="septiani-post-excerpt text-muted">
                            <?php echo themeExcerpt($this->excerpt, 140); ?>
                        </p>
                        <?php if ($this->sequence != $this->total): ?>
                            <hr class="septiani-post-separator">
                        <?php endif; ?>
                    </div>
                    <?php endwhile; ?>

                    <!-- صفحه‌بندی -->
                    <div class="septiani-pagination">
                        <?php
                        ob_start();
                        $this->pageNav();
                        echo zara_nav_fa((string)ob_get_clean());
                        ?>
                    </div>

                <?php else: ?>
                    <p class="text-center"><?php _e('هیچ پستی یافت نشد.'); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $this->need('footer.php'); ?>
