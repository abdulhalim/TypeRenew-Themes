<?php
/**
 * زهرا - یک پوسته برای وبلاگ‌های شخصی
 *
 * @package زهرا
 * @author پوردریایی
 * @version 2.0.0
 * @link http://pourdaryaei.ir
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<?php $this->need('header.php'); ?>

<div class="septiani-fade-edges">
    <div class="container">
        <p class="text-center text-muted septiani-latest-posts">آخرین نوشته‌های وبلاگ</p>

        <?php if ($this->have()): ?>
            <?php while($this->next()): ?>
            <div class="col-lg-8 mx-auto my-5 border-0 septiani-post-preview">
                <div class="p-0 text-center">
                    <a class="text-dark" href="<?php $this->permalink(); ?>">
                        <h2 class="septiani-entry-title"><?php $this->title(); ?></h2>
                    </a>
                    <span class="mb-2 text-muted septiani-post-meta">
                        <i class="fas fa-calendar-alt"></i>
                        <?php echo getLocalizedDate((int)$this->created, 'Y/m/d'); ?>
                    </span>
                    <p class="septiani-post-excerpt text-muted">
                        <?php echo themeExcerpt($this->excerpt, 140); ?>
                    </p>
                </div>
            </div>
            <?php if ($this->sequence != $this->total): ?>
                <div class="text-center">
                    <hr class="septiani-post-separator">
                </div>
            <?php endif; ?>
            <?php endwhile; ?>

            <div class="septiani-pagination">
                <?php
                ob_start();
                $this->pageNav();
                echo zara_nav_fa((string)ob_get_clean());
                ?>
            </div>

        <?php else: ?>
            <p class="text-center"><?php _e('هیچ پستی یافت نشد.'); ?></p>
        <?php endif; ?>
    </div>
</div>

<?php $this->need('footer.php'); ?>
