<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

function zara_version()
{
    return '2.0.0';
}

/* ================================================================
 *  ۱) ابزارهای عمومی
 * ================================================================ */

/** خواندن تنظیم پوسته با مقدار پیش‌فرض */
function zara_opt($name, $default = null)
{
    try {
        $value = Typecho_Widget::widget('Widget_Options')->{$name};
    } catch (Exception $e) {
        $value = null;
    }
    return ($value === null || $value === '') ? $default : $value;
}

/** تبدیل ارقام لاتین به فارسی */
function toPersianNumbers($num)
{
    $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return str_replace(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], $persian, (string)$num);
}

/** تبدیل ارقام فارسی/عربی به لاتین (برای tel: و ...) */
function zara_latin_digits($text)
{
    $fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $ar = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    $en = range(0, 9);
    return str_replace($fa, $en, str_replace($ar, $en, (string)$text));
}

/** عدد با جداکنندهٔ هزارگان فارسی: 1234 → ۱٬۲۳۴ */
function zara_num($num)
{
    return toPersianNumbers(str_replace(',', '٬', number_format(max(0, (int)$num))));
}

/* ================================================================
 *  ۲) تاریخ شمسی داخلی (بدون نیاز به افزونه)
 * ================================================================ */

/** تبدیل میلادی به جلالی */
function zara_to_jalali($gy, $gm, $gd)
{
    $gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

    $jy = ($gy <= 1600) ? 0 : 979;
    $gy -= ($gy <= 1600) ? 621 : 1600;

    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = (365 * $gy)
        + intdiv($gy2 + 3, 4)
        - intdiv($gy2 + 99, 100)
        + intdiv($gy2 + 399, 400)
        - 80
        + $gd
        + $gdm[$gm - 1];

    $jy += 33 * intdiv($days, 12053);
    $days %= 12053;
    $jy += 4 * intdiv($days, 1461);
    $days %= 1461;

    if ($days > 365) {
        $jy += intdiv($days - 1, 365);
        $days = ($days - 1) % 365;
    }

    if ($days < 186) {
        $jm = 1 + intdiv($days, 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + intdiv($days - 186, 30);
        $jd = 1 + (($days - 186) % 30);
    }

    return [$jy, $jm, $jd];
}

/** تاریخ شمسی — اگر افزونهٔ jalali_date موجود باشد از همان، وگرنه تبدیل داخلی */
function getLocalizedDate($timestamp, $format = 'Y/m/d')
{
    if (function_exists('jalali_date')) {
        return toPersianNumbers(jalali_date($format, $timestamp));
    }

    [$jy, $jm, $jd] = zara_to_jalali((int)date('Y', $timestamp), (int)date('n', $timestamp), (int)date('j', $timestamp));

    $out = str_replace(
        ['Y', 'm', 'd'],
        [sprintf('%04d', $jy), sprintf('%02d', $jm), sprintf('%02d', $jd)],
        $format
    );
    return toPersianNumbers($out);
}

/** سال جاری شمسی برای پاورقی */
function zara_jalali_year()
{
    if (function_exists('jalali_date')) {
        return toPersianNumbers(jalali_date('Y', time()));
    }
    [$jy] = zara_to_jalali((int)date('Y'), (int)date('n'), (int)date('j'));
    return toPersianNumbers((string)$jy);
}

/** ارقام فارسی خروجی HTML صفحه‌بندی */
function zara_nav_fa($html)
{
    return (string)preg_replace_callback(
        '/>([^<>]+)</u',
        function ($m) {
            return '>' . toPersianNumbers($m[1]) . '<';
        },
        (string)$html
    );
}

/* ================================================================
 *  ۳) خلاصه، تصویر و آیکون
 * ================================================================ */

/** خلاصه‌ای از محتوا */
function themeExcerpt($content, $length = 100)
{
    $content = strip_tags((string)$content);
    $content = trim(preg_replace('/\s+/u', ' ', $content));
    if (mb_strlen($content) > $length) {
        return mb_substr($content, 0, $length) . '…';
    }
    return $content;
}

/** تبدیل JSON آیکون‌ها به آرایه */
function parseCustomIcons($jsonString)
{
    if (empty($jsonString)) return [];
    $decoded = json_decode((string)$jsonString, true);
    return is_array($decoded) ? $decoded : [];
}

/** دریافت کلاس آیکون برای دسته‌بندی */
function getCategoryIcon($slug)
{
    static $icons = null;
    if ($icons === null) {
        try {
            $json = Typecho_Widget::widget('Widget_Options')->categoryIcons;
        } catch (Exception $e) {
            $json = null;
        }
        $icons = parseCustomIcons($json);
    }
    return isset($icons[$slug]) ? $icons[$slug] : 'fa-folder';
}

/** دریافت کلاس آیکون برای صفحه */
function getPageIcon($slug)
{
    static $icons = null;
    if ($icons === null) {
        try {
            $json = Typecho_Widget::widget('Widget_Options')->pageIcons;
        } catch (Exception $e) {
            $json = null;
        }
        $icons = parseCustomIcons($json);
    }
    return isset($icons[$slug]) ? $icons[$slug] : 'fa-file-lines';
}

/** نرمال‌سازی کلاس فونت‌آیکون: هر مقداری کار کند (fa-x / x / fa-solid fa-x / fas fa-x) */
function zara_fa_class($value, $default = 'fa-user')
{
    $v = trim((string)$value);
    if ($v === '') {
        $v = (string)$default;
    }
    // جدا کردن پیشوندها
    $v = preg_replace('/^(fa-solid|fa-regular|fa-brands|fas|far|fab|fa)\s+/iu', '', $v);
    $v = trim($v);
    if ($v === '') {
        $v = (string)$default;
    }
    if (!preg_match('/^fa-/iu', $v)) {
        $v = 'fa-' . $v;
    }
    return 'fas ' . $v;
}

/** اعتبار نشانی تصویر */
function zara_image_ok($url)
{
    $url = trim((string)$url);
    if ($url === '' || strlen($url) > 2048) return false;
    return (bool)preg_match('#^(https?://|/|data:image/)#i', $url);
}

/** آدرس تصویر شاخص نوشته: فیلد thumb → فیلد قدیمی cover → نخستین تصویر متن
 *  (نام thumb با بقیهٔ پوسته‌های تایپ‌چو یکسان است تا هنگام جابه‌جایی پوسته
 *  تصویر شاخص از دست نرود) */
function themePostCover($post)
{
    // فیلد استاندارد thumb
    if (isset($post->fields) && $post->fields->thumb) {
        $url = trim((string)$post->fields->thumb);
        if (zara_image_ok($url)) return $url;
    }
    // سازگاری با فیلد قدیمی cover
    if (isset($post->fields) && $post->fields->cover) {
        $url = trim((string)$post->fields->cover);
        if (zara_image_ok($url)) return $url;
    }
    try {
        $content = (string)$post->content;
        if (preg_match('/<img[^>]+src=["\']([^"\']+)["\']/iu', $content, $m)
            && zara_image_ok($m[1])) {
            return $m[1];
        }
    } catch (Exception $e) {
    }
    return null;
}

/* ================================================================
 *  ۴) تصاویر نویسنده و باکس نویسنده
 * ================================================================ */

/** دریافت آدرس تصویر پروفایل (برای صفحه اصلی و باکس نویسنده) */
function getProfileImage()
{
    $options = Typecho_Widget::widget('Widget_Options');
    if (!empty($options->profile_image)) {
        return $options->profile_image;
    }
    return $options->themeUrl . '/img/profile.jpg';
}

/** دریافت آدرس تصویر نویسنده (برای صفحه رزومه) */
function getAuthorImage()
{
    $options = Typecho_Widget::widget('Widget_Options');
    if (!empty($options->author_image)) {
        return $options->author_image;
    }
    return $options->themeUrl . '/img/author.jpg';
}

/** نمایش کادر نویسنده (برای پایین پست‌ها) */
function getAuthorBox()
{
    $options = Typecho_Widget::widget('Widget_Options');
    $name = $options->author_name ?: 'مدیر سایت';
    // بیوگرافی اختصاصی نویسنده؛ در صورت خالی‌بودن، توضیح کوتاه سایت
    $bio = $options->author_bio ?: ($options->description ?: 'نویسنده و علاقه‌مند به دنیای وب و فناوری.');
    $avatar = getProfileImage();

    $html = '<div class="septiani-author-box">';
    $html .= '<div class="septiani-author-avatar"><img src="' . htmlspecialchars($avatar) . '" alt="' . htmlspecialchars($name) . '"></div>';
    $html .= '<div class="septiani-author-info">';
    $html .= '<h3 class="septiani-author-name">' . htmlspecialchars($name) . '</h3>';
    $html .= '<p class="septiani-author-bio">' . htmlspecialchars($bio) . '</p>';
    $html .= '</div></div>';

    return $html;
}

/* ================================================================
 *  ۴-ب) گالری گرید دوتایی تصاویر محتوا
 *     پاراگراف‌های پیوستهٔ «فقط-تصویر» (تصاویر مارک‌داون، تصاویرِ
 *     لینک‌شده و لینک‌های مستقیم تصویر) به گرید بندانگشتی دوتایی
 *     تبدیل می‌شوند — مثل پوسته‌های گالری‌دار.
 * ================================================================ */

/** آیا این نشانی به فایل تصویر اشاره می‌کند؟ */
function zara_is_image_url($url)
{
    return (bool)preg_match('~\.(jpe?g|png|gif|webp|avif|bmp|svg)(?:[?#]|$)~iu', (string)$url);
}

/** سلول‌های تصویرِ یک پاراگراف — null یعنی پاراگراف فقط-تصویر نیست
 *  خروجی: فهرستی از [imgElement|null, linkElement|null, src, href] */
function zara_para_image_cells($p)
{
    $cells = [];
    foreach ($p->childNodes as $ch) {
        // متن سفید-فاصله و <br> نادیده گرفته می‌شوند
        if ($ch instanceof DOMText) {
            if (trim($ch->wholeText) !== '') return null;
            continue;
        }
        if (!($ch instanceof DOMElement)) return null;
        if ($ch->nodeName === 'br') continue;

        if ($ch->nodeName === 'img') {
            $src = trim($ch->getAttribute('src'));
            if ($src === '') return null;
            $cells[] = ['img' => $ch, 'a' => null, 'src' => $src, 'href' => null];
            continue;
        }

        if ($ch->nodeName === 'a') {
            $href = trim($ch->getAttribute('href'));
            $imgs = [];
            $hasText = false;
            foreach ($ch->childNodes as $gch) {
                if ($gch instanceof DOMText) {
                    if (trim($gch->wholeText) !== '') $hasText = true;
                    continue;
                }
                if ($gch instanceof DOMElement && $gch->nodeName === 'img') {
                    $imgs[] = $gch;
                    continue;
                }
                return null; // عنصر دیگر داخل لینک
            }
            if (count($imgs) === 1 && !$hasText) {
                // [![بندانگشتی](thumb)](full) — تصویرِ لینک‌شده
                $src = trim($imgs[0]->getAttribute('src'));
                if ($src === '') return null;
                $cells[] = ['img' => $imgs[0], 'a' => $ch, 'src' => $src, 'href' => $href];
                continue;
            }
            if (count($imgs) === 0 && $href !== '' && zara_is_image_url($href)) {
                // لینک مستقیم تصویر: https://…/photo.jpg (متن لینک هرچه باشد)
                $cells[] = ['img' => null, 'a' => $ch, 'src' => $href, 'href' => $href];
                continue;
            }
            return null;
        }

        return null; // هر عنصر دیگر → پاراگراف معمولی
    }
    return $cells; // ممکن است خالی باشد (مثل <p><br></p>)
}

/** تبدیل محتوای HTML: گروه‌های پیوستهٔ تصویر → گرید دوتایی */
function zara_image_grid($html)
{
    $html = (string)$html;
    if ($html === '' || (stripos($html, '<img') === false && stripos($html, '<a') === false)) {
        return $html;
    }
    if (!class_exists('DOMDocument')) {
        return $html;
    }

    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $wrapped = '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head>'
        . '<body><div id="zara-grid-root">' . $html . '</div></body></html>';
    if (!$dom->loadHTML($wrapped, LIBXML_NONET)) {
        libxml_clear_errors();
        return $html;
    }
    libxml_clear_errors();

    $body = $dom->getElementsByTagName('body')->item(0);
    $root = $body ? $body->firstChild : null;
    if (!$root) {
        return $html;
    }

    // پیمایش فرزندان ریشه و یافتن گروه‌های پیوستهٔ فقط-تصویر
    $children = [];
    foreach ($root->childNodes as $node) {
        $children[] = $node;
    }

    $i = 0;
    $count = count($children);
    while ($i < $count) {
        $node = $children[$i];
        if (!($node instanceof DOMElement) || $node->nodeName !== 'p') {
            $i++;
            continue;
        }
        $cells = zara_para_image_cells($node);
        if (!is_array($cells) || count($cells) === 0) {
            $i++;
            continue;
        }

        // گروه را تا پاراگراف بعدی فقط-تصویر ادامه بده
        $groupNodes = [$node];
        $groupCells = $cells;
        $j = $i + 1;
        while ($j < $count) {
            $next = $children[$j];
            if (!($next instanceof DOMElement) || $next->nodeName !== 'p') break;
            $nextCells = zara_para_image_cells($next);
            if (!is_array($nextCells) || count($nextCells) === 0) break;
            $groupNodes[] = $next;
            $groupCells = array_merge($groupCells, $nextCells);
            $j++;
        }

        if (count($groupCells) >= 2) {
            // ساخت گرید
            $grid = $dom->createElement('div');
            $grid->setAttribute('class', 'zara-img-grid');
            $grid->setAttribute('data-count', (string)count($groupCells));

            foreach ($groupCells as $cell) {
                $cellDiv = $dom->createElement('div');
                $cellDiv->setAttribute('class', 'zara-grid-cell');

                $link = $dom->createElement('a');
                $link->setAttribute('class', 'zara-grid-link');
                $href = ($cell['href'] !== null && $cell['href'] !== '') ? $cell['href'] : $cell['src'];
                $link->setAttribute('href', $href);

                $img = $dom->createElement('img');
                $img->setAttribute('src', $cell['src']);
                $alt = $cell['img'] ? trim($cell['img']->getAttribute('alt')) : '';
                $title = $cell['img'] ? trim($cell['img']->getAttribute('title')) : '';
                if ($alt !== '') $img->setAttribute('alt', $alt); else $img->setAttribute('alt', '');
                if ($title !== '') $img->setAttribute('title', $title);
                $img->setAttribute('loading', 'lazy');

                $link->appendChild($img);
                $cellDiv->appendChild($link);
                $grid->appendChild($cellDiv);
            }

            // جای‌گذاری گرید به‌جای نخستین پاراگراف گروه و حذف بقیه
            $firstNode = $groupNodes[0];
            $firstNode->parentNode->insertBefore($grid, $firstNode);
            foreach ($groupNodes as $gn) {
                if ($gn->parentNode) $gn->parentNode->removeChild($gn);
            }
            $i = $j;
        } else {
            $i++;
        }
    }

    $parts = [];
    foreach ($root->childNodes as $child) {
        $parts[] = $dom->saveHTML($child);
    }
    $out = implode('', $parts);
    return ($out === '') ? $html : $out;
}

/* ================================================================
 *  ۵) آمار: ستون‌های views و likes جدول محتوا
 *     (هم‌راستا با نیلوفر/زیبا — شمارش‌ها هنگام جابه‌جایی پوسته می‌مانند)
 * ================================================================ */

/** اطمینان از وجود ستون‌های views و likes */
function zara_stats_ready()
{
    static $ready = null;
    if ($ready !== null) return $ready;

    $ready = false;
    try {
        $db = Typecho_Db::get();
        $prefix = $db->getPrefix();

        $columns = [];
        try {
            $rows = $db->fetchAll("SHOW COLUMNS FROM `{$prefix}contents`");
            foreach ($rows as $row) {
                $columns[] = is_array($row) ? (string)reset($row) : (string)$row->Field;
            }
        } catch (Exception $e) {
            $columns = [];
        }

        if (empty($columns)) {
            foreach (['views', 'likes'] as $col) {
                try {
                    $db->fetchRow($db->select("table.contents.{$col}")->from('table.contents')->limit(1));
                } catch (Exception $e) {
                    $db->query("ALTER TABLE `{$prefix}contents` ADD `{$col}` INT DEFAULT 0");
                }
            }
        } else {
            foreach (['views', 'likes'] as $col) {
                if (!in_array($col, $columns, true)) {
                    $db->query("ALTER TABLE `{$prefix}contents` ADD `{$col}` INT DEFAULT 0");
                }
            }
        }

        $ready = true;
    } catch (Exception $e) {
        $ready = false;
    }
    return $ready;
}

/** تعداد بازدید نوشته */
function zara_views($archive)
{
    static $cache = [];
    $cid = is_object($archive) ? (int)$archive->cid : (int)$archive;
    if ($cid < 1) return 0;
    if (!isset($cache[$cid])) {
        $cache[$cid] = 0;
        if (zara_stats_ready()) {
            try {
                $db = Typecho_Db::get();
                $row = $db->fetchRow(
                    $db->select('table.contents.views')->from('table.contents')->where('table.contents.cid = ?', $cid)
                );
                $cache[$cid] = $row ? max(0, (int)$row['views']) : 0;
            } catch (Exception $e) {
            }
        }
    }
    return $cache[$cid];
}

/** تعداد لایک نوشته */
function zara_likes($archive)
{
    static $cache = [];
    $cid = is_object($archive) ? (int)$archive->cid : (int)$archive;
    if ($cid < 1) return 0;
    if (!isset($cache[$cid])) {
        $cache[$cid] = 0;
        if (zara_stats_ready()) {
            try {
                $db = Typecho_Db::get();
                $row = $db->fetchRow(
                    $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
                );
                $cache[$cid] = $row ? max(0, (int)$row['likes']) : 0;
            } catch (Exception $e) {
            }
        }
    }
    return $cache[$cid];
}

/* ================================================================
 *  ۶) شمارش بازدید
 * ================================================================ */

/** شمارش بازدید صفحات تکی با کوکی ضد تکرار */
function zara_count_view($archive)
{
    // اگر پلاگین ViewsCounter فعال است، پوسته کنار می‌کشد
    try {
        $activated = Typecho_Widget::widget('Widget_Options')->plugins;
        if (is_array($activated) && isset($activated['activated']['ViewsCounter'])) {
            return;
        }
    } catch (Exception $e) {
    }

    // بازدید مدیر، طبق تنظیم
    try {
        $countAdmin = Typecho_Widget::widget('Widget_Options')->zaraCountAdminViews;
        if (Typecho_Widget::widget('Widget_User')->hasLogin() && !$countAdmin) {
            return;
        }
    } catch (Exception $e) {
    }

    if (!is_object($archive) || !method_exists($archive, 'is') || !$archive->is('single')) {
        return;
    }

    $cid = (int)$archive->cid;
    if ($cid < 1 || !zara_stats_ready()) return;

    // بازدید تکراری همین بازدیدکننده تا ۶ ساعت شمرده نمی‌شود
    try {
        $viewed = (string)Typecho_Cookie::get('zaraViews', '');
        if ($viewed !== '') {
            $ids = explode(',', $viewed);
            if (in_array((string)$cid, $ids, true)) return;
            $ids[] = (string)$cid;
            if (count($ids) > 100) $ids = array_slice($ids, -100);
            Typecho_Cookie::set('zaraViews', implode(',', $ids), time() + 21600);
        } else {
            Typecho_Cookie::set('zaraViews', (string)$cid, time() + 21600);
        }
    } catch (Exception $e) {
    }

    try {
        $db = Typecho_Db::get();
        $db->query(
            $db->update('table.contents')
                ->expression('views', 'views + 1')
                ->where('table.contents.cid = ?', $cid)
        );
    } catch (Exception $e) {
    }
}

/* ================================================================
 *  ۷) لایک — ستون likes + نقطهٔ پایانی AJAX
 * ================================================================ */

/** شناسه‌های لایک‌شدهٔ این بازدیدکننده (کوکی zaraLikes) */
function zara_user_likes()
{
    $raw = (string)Typecho_Cookie::get('zaraLikes', '');
    if ($raw === '') return [];
    $ids = [];
    foreach (explode(',', $raw) as $id) {
        $id = trim($id);
        if ($id !== '' && ctype_digit($id) && !in_array($id, $ids, true)) {
            $ids[] = $id;
        }
    }
    return $ids;
}

/** آیا این بازدیدکننده این نوشته را لایک کرده؟ */
function zara_is_liked($cid)
{
    return $cid > 0 && in_array((string)$cid, zara_user_likes(), true);
}

/** خروجی JSON و پایان درخواست */
function zara_json($payload, $status = 200)
{
    try {
        $response = Typecho_Response::getInstance();
        $response->setStatus($status);
        $response->setContentType('application/json');
        $response->addResponder(function () use ($payload) {
            echo json_encode($payload, JSON_UNESCAPED_UNICODE);
        });
        $response->respond();
    } catch (Exception $e) {
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=UTF-8', true, $status);
        }
        echo json_encode($payload, JSON_UNESCAPED_UNICODE);
        exit;
    }
    exit;
}

/** پردازش درخواست لایک — POST با پارامتر zaraLike=<cid> */
function zara_handle_like($request)
{
    $cid = (int)(string)$request->get('zaraLike');

    if ($cid < 1) {
        zara_json(['ok' => false, 'error' => 'bad-request'], 400);
        return;
    }

    // جلوگیری ساده از CSRF
    $siteHost = (string)parse_url((string)Typecho_Widget::widget('Widget_Options')->siteUrl, PHP_URL_HOST);
    $referer = (string)($_SERVER['HTTP_REFERER'] ?? '');
    if ($referer !== '' && $siteHost !== '' && stripos($referer, $siteHost) === false) {
        zara_json(['ok' => false, 'error' => 'cross-origin'], 403);
        return;
    }

    if (!zara_stats_ready()) {
        zara_json(['ok' => false, 'error' => 'db-error'], 500);
        return;
    }

    try {
        $db = Typecho_Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.type', 'table.contents.status', 'table.contents.password', 'table.contents.created')
                ->from('table.contents')
                ->where('table.contents.cid = ?', $cid)
        );

        $valid = is_array($row)
            && $row['status'] === 'publish'
            && in_array($row['type'], ['post', 'page'], true)
            && empty($row['password'])
            && (int)$row['created'] <= Typecho_Widget::widget('Widget_Options')->time;

        if (!$valid) {
            zara_json(['ok' => false, 'error' => 'not-found'], 404);
            return;
        }

        $likedIds = zara_user_likes();
        $wasLiked = in_array((string)$cid, $likedIds, true);

        if ($wasLiked) {
            $likedIds = array_values(array_filter(
                $likedIds,
                function ($id) use ($cid) {
                    return $id !== (string)$cid;
                }
            ));
            $delta = -1;
        } else {
            $likedIds[] = (string)$cid;
            $delta = 1;
        }

        if (count($likedIds) > 200) {
            $likedIds = array_slice($likedIds, -200);
        }
        Typecho_Cookie::set('zaraLikes', implode(',', $likedIds), time() + 31536000);

        $current = (int)$db->fetchObject(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        )->likes;

        if ($delta > 0 || $current > 0) {
            $db->query(
                $db->update('table.contents')
                    ->expression('likes', $delta > 0 ? 'likes + 1' : 'likes - 1')
                    ->where('table.contents.cid = ?', $cid)
            );
        }

        $newLikes = (int)$db->fetchObject(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        )->likes;

        zara_json([
            'ok'    => true,
            'likes' => $newLikes,
            'liked' => !$wasLiked,
        ]);
    } catch (Exception $e) {
        zara_json(['ok' => false, 'error' => 'server-error'], 500);
    }
}

/* ================================================================
 *  ۸) راه‌انداز پوسته
 * ================================================================ */

function themeInit($archive)
{
    // هوک شمارش بازدید قبل از رندر
    Typecho_Plugin::factory('Widget\Archive')->beforeRender = 'zara_count_view';

    if ($archive->request->isPost() && $archive->request->is('zaraLike')) {
        zara_handle_like($archive->request);
    }
}

/* ================================================================
 *  ۹) تنظیمات پوسته
 * ================================================================ */

/** ساخت دادهٔ انتخابگر آیکون (بدون خروجی) — با کش درخواست */
function zara_icon_picker_data()
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    $cats = [];
    try {
        // نمونهٔ اختصاصی با پسوند @ تا با پیمایشگرهای فرم/منو تداخل نکند
        $categories = Typecho_Widget::widget('Widget_Metas_Category_List@zara-icon-picker');
        if ($categories->have()) {
            while ($categories->next()) {
                $cats[] = ['slug' => (string)$categories->slug, 'name' => (string)$categories->name];
            }
        }
    } catch (Exception $e) {
    }

    $pages = [];
    try {
        $pageList = Typecho_Widget::widget('Widget_Contents_Page_List@zara-icon-picker');
        if ($pageList->have()) {
            while ($pageList->next()) {
                $pages[] = ['slug' => (string)$pageList->slug, 'name' => (string)$pageList->title];
            }
        }
    } catch (Exception $e) {
    }

    $cache = ['categories' => $cats, 'pages' => $pages];
    return $cache;
}

/** HTML انتخابگر آیکون برای فیلد JSON (دسته‌ها یا صفحات) */
function zara_icon_picker_html($targetField, $defaultIcon, $title)
{
    $options = Typecho_Widget::widget('Widget_Options');
    $data = zara_icon_picker_data();
    $items = ($targetField === 'categoryIcons') ? $data['categories'] : $data['pages'];

    if (empty($items)) {
        return '<span class="zara-picker-root" data-target="' . htmlspecialchars($targetField) . '" '
            . 'data-default="' . htmlspecialchars($defaultIcon) . '" data-themeurl="' . htmlspecialchars((string)$options->themeUrl) . '" '
            . 'data-title="' . htmlspecialchars($title) . '"></span>'
            . zara_picker_script_tag((string)$options->themeUrl);
    }

    return '<span class="zara-picker-root" data-target="' . htmlspecialchars($targetField) . '" '
        . 'data-default="' . htmlspecialchars($defaultIcon) . '" '
        . 'data-items="' . htmlspecialchars(json_encode($items, JSON_UNESCAPED_UNICODE), ENT_QUOTES) . '" '
        . 'data-themeurl="' . htmlspecialchars((string)$options->themeUrl) . '" '
        . 'data-title="' . htmlspecialchars($title) . '"></span>'
        . zara_picker_script_tag((string)$options->themeUrl);
}

/** HTML انتخابگر آیکون برای فیلد متن تکی (لوگو) */
function zara_single_icon_picker_html($targetField, $defaultIcon, $title)
{
    $options = Typecho_Widget::widget('Widget_Options');

    return '<span class="zara-picker-root" data-target="' . htmlspecialchars($targetField) . '" '
        . 'data-default="' . htmlspecialchars($defaultIcon) . '" data-single="1" '
        . 'data-themeurl="' . htmlspecialchars((string)$options->themeUrl) . '" '
        . 'data-title="' . htmlspecialchars($title) . '"></span>'
        . zara_picker_script_tag((string)$options->themeUrl);
}

/** تگ اسکریپت انتخابگر (یک‌بار در هر درخواست تزریق می‌شود) */
function zara_picker_script_tag($themeUrl)
{
    if (!empty($GLOBALS['zara_picker_script_included'])) {
        return '';
    }
    $GLOBALS['zara_picker_script_included'] = true;
    return '<script defer src="' . htmlspecialchars($themeUrl) . '/js/admin-icon-picker.js"></script>';
}

function themeConfig($form)
{
    $yes = 'روشن';
    $no  = 'خاموش';

    // ========== تصاویر ==========
    $profile_image = new Typecho_Widget_Helper_Form_Element_Text(
        'profile_image',
        null,
        null,
        'آدرس تصویر پروفایل',
        'تصویری که در صفحه اصلی و باکس نویسنده نمایش داده می‌شود. در صورت خالی بودن، profile.jpg استفاده می‌شود.'
    );
    $form->addInput($profile_image);

    $author_image = new Typecho_Widget_Helper_Form_Element_Text(
        'author_image',
        null,
        null,
        'آدرس تصویر نویسنده',
        'تصویری که در صفحه رزومه نویسنده نمایش داده می‌شود. در صورت خالی بودن، author.jpg استفاده می‌شود.'
    );
    $form->addInput($author_image);

    $logo_url = new Typecho_Widget_Helper_Form_Element_Text(
        'logo_url',
        null,
        null,
        'تصویر سربرگ صفحه اصلی',
        'تصویری که بالای صفحه اول نمایش داده می‌شود. در صورت خالی بودن، از تصویر پروفایل استفاده می‌شود.'
    );
    $form->addInput($logo_url);

    // ========== آیکون کنار لوگو (با انتخابگر) ==========
    $logo_icon = new Typecho_Widget_Helper_Form_Element_Text(
        'logo_icon',
        null,
        'fa-feather-alt',
        'کلاس آیکون کنار لوگو',
        zara_single_icon_picker_html('logo_icon', 'fa-feather-alt', 'انتخاب آیکون لوگو')
    );
    $form->addInput($logo_icon);

    // ========== نمایش ==========
    $defaultTheme = new Typecho_Widget_Helper_Form_Element_Select(
        'zaraDefaultTheme',
        ['auto' => 'خودکار (از سیستم کاربر)', 'light' => 'روشن', 'dark' => 'تیره'],
        'auto',
        'حالت نمایش پیش‌فرض',
        'بازدیدکننده می‌تواند از دکمهٔ ماه/خورشید در نوار بالا حالت را عوض کند؛ انتخاب او در مرورگرش ذخیره می‌شود.'
    );
    $form->addInput($defaultTheme);

    // ========== الگوی پس‌زمینه (مینیمال — جایگزین ذرات) ==========
    $bgPattern = new Typecho_Widget_Helper_Form_Element_Select(
        'zaraBgPattern',
        [
            'grid' => 'شبکهٔ مربعی (پیش‌فرض)',
            'dots' => 'نقطه‌ای مینیمال',
            'none' => 'بدون الگو'
        ],
        'grid',
        'الگوی پس‌زمینهٔ صفحات',
        'یک الگوی بسیار ظریف روی پس‌زمینه — پیش‌فرض شبکهٔ مربعی کم‌رنگ است. کاملاً CSS است و بار اضافه ندارد.'
    );
    $form->addInput($bgPattern);

    // ========== آمار: بازدید و لایک ==========
    $showViews = new Typecho_Widget_Helper_Form_Element_Radio(
        'zaraShowViews',
        ['1' => $yes, '0' => $no],
        '1',
        'نمایش شمار بازدید',
        'شمار بازدید فقط در صفحهٔ خود نوشته (زیر عنوان) نمایش داده می‌شود — نه در فهرست‌ها.'
    );
    $form->addInput($showViews);

    $showLikes = new Typecho_Widget_Helper_Form_Element_Radio(
        'zaraShowLikes',
        ['1' => $yes, '0' => $no],
        '1',
        'دکمهٔ لایک (پسند)',
        'دکمهٔ پسند فقط در صفحهٔ خود نوشته نمایش داده می‌شود؛ شمارش در جدول نوشته‌ها نگه داشته می‌شود.'
    );
    $form->addInput($showLikes);

    $countAdminViews = new Typecho_Widget_Helper_Form_Element_Radio(
        'zaraCountAdminViews',
        ['1' => $yes, '0' => $no],
        '0',
        'شمارش بازدید مدیر',
        'اگر روشن باشد، بازدید کاربران واردشده (خودتان) هم شمرده می‌شود.'
    );
    $form->addInput($countAdminViews);

    // ========== اطلاعات نویسنده (برای صفحه نویسنده) ==========
    $author_name = new Typecho_Widget_Helper_Form_Element_Text(
        'author_name',
        null,
        'مدیر سایت',
        'نام نویسنده',
        'نامی که در صفحه نویسنده نمایش داده می‌شود.'
    );
    $form->addInput($author_name);

    $author_bio = new Typecho_Widget_Helper_Form_Element_Textarea(
        'author_bio',
        null,
        'نویسنده و علاقه‌مند به دنیای وب و فناوری. خلق تجربه‌های دیجیتال زیبا و کارآمد.',
        'بیوگرافی نویسنده',
        'توضیحات کوتاه درباره نویسنده — در صفحه درباره من و باکس نویسنده پایین پست‌ها نمایش داده می‌شود.'
    );
    $form->addInput($author_bio);

    $author_job = new Typecho_Widget_Helper_Form_Element_Text(
        'author_job',
        null,
        'نویسنده و توسعه‌دهنده وب',
        'شغل نویسنده',
        'مثال: «نویسنده و توسعه‌دهنده وب». اگر می‌خواهید توضیح بیشتری نمایش داده شود، آن را با خط عمودی جدا کنید: «تکنولوژی | شغل اول من درباره کامپیوتر است» — بخش دوم به صورت توضیح (tooltip) زیر عنوان نمایش داده می‌شود.'
    );
    $form->addInput($author_job);

    $author_email = new Typecho_Widget_Helper_Form_Element_Text(
        'author_email',
        null,
        'info@example.com',
        'ایمیل نویسنده',
        'ایمیل برای نمایش در صفحه نویسنده'
    );
    $form->addInput($author_email);

    $author_url = new Typecho_Widget_Helper_Form_Element_Text(
        'author_url',
        null,
        'https://example.com',
        'وب‌سایت نویسنده',
        'آدرس وب‌سایت شخصی'
    );
    $form->addInput($author_url);

    $author_phone = new Typecho_Widget_Helper_Form_Element_Text(
        'author_phone',
        null,
        '',
        'شماره تماس',
        'شماره تماس برای نمایش در صفحه نویسنده (اختیاری). اگر این فیلد خالی باشد، دکمه تماس نمایش داده نمی‌شود.'
    );
    $form->addInput($author_phone);

    // ========== انتخاب منو ==========
    // دریافت لیست صفحات
    $pages = Typecho_Widget::widget('Widget_Contents_Page_List');
    $pageOptions = [];
    if ($pages->have()) {
        while ($pages->next()) {
            $pageOptions[$pages->permalink] = $pages->title;
        }
    }

    // دریافت لیست دسته‌بندی‌ها
    $categories = Typecho_Widget::widget('Widget_Metas_Category_List');
    $catOptions = [];
    if ($categories->have()) {
        while ($categories->next()) {
            $catOptions[$categories->slug] = $categories->name;
        }
    }

    // دسته‌بندی‌های منوی بالا
    $navCategories = new Typecho_Widget_Helper_Form_Element_Checkbox(
        'navCategories',
        $catOptions,
        [],
        'دسته‌بندی‌های منوی بالا',
        'دسته‌بندی‌هایی که در نوار بالا نمایش داده شوند.'
    );
    $form->addInput($navCategories->multiMode());

    // صفحات منوی بالا
    $navPages = new Typecho_Widget_Helper_Form_Element_Checkbox(
        'navPages',
        $pageOptions,
        [],
        'صفحات منوی بالا',
        'صفحاتی که در نوار بالا نمایش داده شوند.'
    );
    $form->addInput($navPages->multiMode());

    // آیکون‌های دسته‌بندی — با انتخابگر گرافیکی
    $categoryIcons = new Typecho_Widget_Helper_Form_Element_Textarea(
        'categoryIcons',
        null,
        null,
        'آیکون‌های دسته‌بندی',
        zara_icon_picker_html('categoryIcons', 'fa-folder', 'آیکون دسته‌بندی‌ها')
    );
    $form->addInput($categoryIcons);

    // آیکون‌های صفحات — با انتخابگر گرافیکی
    $pageIcons = new Typecho_Widget_Helper_Form_Element_Textarea(
        'pageIcons',
        null,
        null,
        'آیکون‌های صفحات',
        zara_icon_picker_html('pageIcons', 'fa-file-lines', 'آیکون برگه‌ها')
    );
    $form->addInput($pageIcons);

    // ========== شبکه‌های اجتماعی ==========
    $socials = [
        'instagram' => 'اینستاگرام',
        'twitter'   => 'توییتر',
        'facebook'  => 'فیسبوک',
        'youtube'   => 'یوتیوب',
        'telegram'  => 'تلگرام',
        'whatsapp'  => 'واتساپ'
    ];
    foreach ($socials as $key => $label) {
        $input = new Typecho_Widget_Helper_Form_Element_Text(
            $key,
            null,
            null,
            $label,
            'آدرس کامل پروفایل'
        );
        $form->addInput($input);
    }

    // ========== دکمه CTA ==========
    $ctaLink = new Typecho_Widget_Helper_Form_Element_Text(
        'ctaLink',
        null,
        null,
        'لینک دکمه CTA',
        'آدرس صفحه یا لینک مورد نظر برای دکمه فراخوانی'
    );
    $form->addInput($ctaLink);

    $ctaText = new Typecho_Widget_Helper_Form_Element_Text(
        'ctaText',
        null,
        'من را دنبال کنید',
        'متن دکمه CTA',
        'متن نمایشی روی دکمه — اگر خالی بماند، «من را دنبال کنید» نمایش داده می‌شود.'
    );
    $form->addInput($ctaText);

    // ========== آیکون دکمه CTA (با انتخابگر) ==========
    $ctaIcon = new Typecho_Widget_Helper_Form_Element_Text(
        'ctaIcon',
        null,
        'fa-user',
        'آیکون دکمه CTA',
        zara_single_icon_picker_html('ctaIcon', 'fa-user', 'انتخاب آیکون دکمه CTA')
    );
    $form->addInput($ctaIcon);
}

/* ================================================================
 *  ۱۰) فیلدهای سفارشی (تصویر شاخص با نام استاندارد thumb)
 * ================================================================ */

function themeFields($layout)
{
    // نام thumb با بقیهٔ پوسته‌های تایپ‌چو یکسان است (یکپارچگی هنگام تعویض پوسته)
    $thumb = new Typecho_Widget_Helper_Form_Element_Text(
        'thumb',
        null,
        null,
        'تصویر شاخص (thumb)',
        'آدرس کامل تصویر شاخص (اختیاری) — بالای عنوان نوشته نمایش داده می‌شود. اگر خالی باشد، نخستین تصویر متن نوشته استفاده می‌شود.'
    );
    $layout->addItem($thumb);
}

/* ================================================================
 *  ۱۱) ساختار دیدگاه‌ها — تخت (بدون تو در تویی)
 *     پاسخ‌ها به‌صورت خواهر/برادر زیر والد رندر می‌شوند و به‌جای
 *     تورفتگی، چیپ «در پاسخ به …» می‌گیرند (بدون بیرون‌زدگی از کادر)
 *     آواتار: تصویر پروفایل پوسته (محلی، بدون گراواتار)
 * ================================================================ */

/** نام نویسندهٔ دیدگاه والد (برای چیپ «در پاسخ به …») — با کش ایستا */
function zara_comment_parent_author($coid)
{
    static $cache = [];
    $coid = (int)$coid;
    if ($coid <= 0) {
        return '';
    }
    if (isset($cache[$coid])) {
        return $cache[$coid];
    }
    $name = '';
    try {
        $db = Typecho_Db::get();
        $row = $db->fetchRow($db->select('author')->from('table.comments')->where('coid = ?', $coid));
        if ($row && isset($row['author'])) {
            $name = trim((string)$row['author']);
        }
    } catch (Exception $e) {
        $name = '';
    }
    $cache[$coid] = $name;
    return $name;
}

function threadedComments($comments, $options)
{
    $author = trim((string)$comments->author);
    $avatarSize = 50;

    $isAuthor = false;
    try {
        $isAuthor = $comments->authorId && $comments->authorId == $comments->ownerId;
    } catch (Exception $e) {
    }

    /* نام نویسندهٔ والد برای چیپ «در پاسخ به …» (نمایش تخت) */
    $parentAuthor = '';
    $parentId = 0;
    try {
        $parentId = (int)$comments->parent;
    } catch (Exception $e) {
    }
    if ($parentId > 0) {
        $parentAuthor = zara_comment_parent_author($parentId);
    }

    /* تصویر پروفایل به‌عنوان آواتار پیش‌فرض دیدگاه‌ها — محلی و آفلاین */
    $avatarUrl = getProfileImage();
    $avatarFallback = $avatarUrl;
    try {
        $themeUrl = Typecho_Widget::widget('Widget_Options')->themeUrl;
        if ((string)$themeUrl !== '' && $avatarUrl !== (string)$themeUrl . '/img/profile.jpg') {
            $avatarFallback = (string)$themeUrl . '/img/profile.jpg';
        }
    } catch (Exception $e) {
    }
    ?>
    <li id="<?php $comments->theId(); ?>" class="septiani-comment-item<?php
        if ($isAuthor) echo ' septiani-comment-by-author';
    ?>">
        <div class="septiani-comment-avatar">
            <img src="<?php echo htmlspecialchars($avatarUrl); ?>" alt="<?php echo htmlspecialchars($author ?: 'مهمان'); ?>" width="<?php echo $avatarSize; ?>" height="<?php echo $avatarSize; ?>" loading="lazy" onerror="this.onerror=null;this.src='<?php echo htmlspecialchars($avatarFallback, ENT_QUOTES); ?>';">
        </div>
        <div class="septiani-comment-body">
            <div class="septiani-comment-header">
                <div class="septiani-comment-author">
                    <span class="septiani-author-name"><?php echo htmlspecialchars($author ?: 'مهمان'); ?></span>
                    <?php if ($isAuthor): ?>
                        <span class="septiani-author-badge">نویسنده</span>
                    <?php endif; ?>
                    <?php if ($parentAuthor !== ''): ?>
                        <span class="septiani-reply-context">
                            <i class="fa-solid fa-reply" aria-hidden="true"></i>
                            در پاسخ به <?php echo htmlspecialchars($parentAuthor); ?>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="septiani-comment-meta">
                    <time datetime="<?php echo date('c', (int)$comments->created); ?>">
                        <i class="fa-regular fa-calendar"></i> <?php echo getLocalizedDate((int)$comments->created); ?>
                    </time>
                </div>
            </div>
            <div class="septiani-comment-text">
                <?php $comments->content(); ?>
            </div>
            <div class="septiani-comment-actions">
                <?php $comments->reply('<i class="fa-solid fa-reply"></i> پاسخ'); ?>
            </div>
        </div>
    </li>
    <?php
    /* فرزندان بعد از بستن <li> رندر می‌شوند تا «زیر هم» و هم‌عرض
       باشند — فهرست تخت، بدون تو در تویی و بدون تورفتگی */
    if ($comments->children) {
        $comments->threadedComments();
    }
    ?>
    <?php
}
