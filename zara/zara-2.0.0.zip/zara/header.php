<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="generator" content="Typecho">

    <title><?php $this->archiveTitle(array(
            'category'  =>  _t('دسته‌بندی %s'),
            'search'    =>  _t('جستجوی %s'),
            'tag'       =>  _t('برچسب %s'),
            'author'    =>  _t('نوشته‌های %s'),
            'date'      =>  _t('آرشیو %s')
        ), '', ' - '); ?><?php $this->options->title(); ?></title>

    <meta name="description" content="<?php $this->options->description(); ?>">
    <meta name="theme-color" content="#faf7f2" id="zara-meta-theme">

    <?php
    // حالت نمایش پیش‌فرض (از تنظیمات پوسته) — قبل از رنگ‌آمیزی صفحه اعمال می‌شود
    $zaraDefaultTheme = zara_opt('zaraDefaultTheme', 'auto');
    if (!in_array($zaraDefaultTheme, ['auto', 'light', 'dark'], true)) {
        $zaraDefaultTheme = 'auto';
    }
    ?>
    <script>
    (function () {
        var fallback = '<?php echo $zaraDefaultTheme; ?>';
        var saved = null;
        try { saved = localStorage.getItem('zara-theme'); } catch (e) {}
        var mode = saved === 'dark' || saved === 'light'
            ? saved
            : (fallback === 'dark' || fallback === 'light'
                ? fallback
                : (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
        if (mode === 'dark') { document.documentElement.classList.add('dark'); }
        document.documentElement.setAttribute('data-zara-theme', mode);
    })();
    </script>

    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="<?php $this->options->themeUrl('img/favicon.svg'); ?>">

    <!-- فونت‌های آفلاین -->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/fonts.css'); ?>">
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/all.css'); ?>">

    <!-- Main Theme CSS -->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/style.css'); ?>">

    <?php $this->header(); ?>
</head>
<body class="septiani-body farsi-digit<?php
    /* الگوی پس‌زمینهٔ مینیمال (شبکهٔ مربعی / نقطه / هیچ) — از تنظیمات پوسته */
    $zaraBgPattern = zara_opt('zaraBgPattern', 'grid');
    if (!in_array($zaraBgPattern, ['grid', 'dots', 'none'], true)) {
        $zaraBgPattern = 'grid';
    }
    echo ' zara-pattern-' . $zaraBgPattern;
    /* آیکون دکمهٔ CTA — قابل انتخاب از تنظیمات (پیش‌فرض: پیکر) */
    $zaraCtaIcon = zara_fa_class($this->options->ctaIcon, 'fa-user');
    /* آیکون لوگو — نرمال‌سازی برای هر مقداری */
    $zaraLogoIcon = zara_fa_class($this->options->logo_icon, 'fa-feather-alt');
?>">

<!-- نوار ناوبری -->
<nav class="septiani-navbar">
    <div class="container">
        <div class="septiani-navbar-content">
            <!-- لوگو (سمت راست) -->
            <div class="septiani-logo">
                <a href="<?php $this->options->siteUrl(); ?>">
                    <?php if ($this->options->logo_icon): ?>
                        <i class="<?php echo $zaraLogoIcon; ?>"></i>
                    <?php endif; ?>
                    <span><?php $this->options->title(); ?></span>
                </a>
            </div>

            <!-- بخش چپ (منو + دکمه‌ها) -->
            <div class="septiani-nav-left">
                <!-- منوی اصلی (فقط دسکتاپ) -->
                <ul class="septiani-nav-menu">

                    <?php
                    // دسته‌بندی‌های منو
                    $selectedCats = $this->options->navCategories;
                    $customIcons = parseCustomIcons($this->options->categoryIcons);

                    if (!empty($selectedCats) && is_array($selectedCats)):
                        $this->widget('Widget_Metas_Category_List')->to($navCats);
                        while($navCats->next()):
                            if (in_array($navCats->slug, $selectedCats)):
                                $icon = isset($customIcons[$navCats->slug]) ? $customIcons[$navCats->slug] : 'fa-folder';
                    ?>
                                <li>
                                    <a href="<?php $navCats->permalink(); ?>" class="<?php if($this->is('category', $navCats->slug)): ?>active<?php endif; ?>">
                                        <i class="fa-solid <?php echo $icon; ?>"></i> <?php $navCats->name(); ?>
                                    </a>
                                </li>
                    <?php
                            endif;
                        endwhile;
                    endif;
                    ?>

                    <?php
                    // صفحات منو
                    $selectedPages = $this->options->navPages;
                    $pageIcons = parseCustomIcons($this->options->pageIcons);

                    if (!empty($selectedPages) && is_array($selectedPages)):
                        $this->widget('Widget_Contents_Page_List')->to($pages);
                        while($pages->next()):
                            if (in_array($pages->permalink, $selectedPages)):
                                $slug = $pages->slug;
                                $icon = isset($pageIcons[$slug]) ? $pageIcons[$slug] : 'fa-file-lines';
                    ?>
                                <li>
                                    <a href="<?php $pages->permalink(); ?>" class="<?php if($this->is('page', $slug)): ?>active<?php endif; ?>">
                                        <i class="fa-solid <?php echo $icon; ?>"></i> <?php $pages->title(); ?>
                                    </a>
                                </li>
                    <?php
                            endif;
                        endwhile;
                    endif;
                    ?>
                </ul>

                <!-- دکمه‌های کناری (جستجو، دارک‌مود و CTA) -->
                <div class="septiani-nav-actions">
                    <?php if ($this->options->ctaLink): ?>
                        <a href="<?php $this->options->ctaLink(); ?>" target="_blank" class="septiani-cta">
                            <i class="<?php echo $zaraCtaIcon; ?>"></i>
                            <span><?php echo htmlspecialchars($this->options->ctaText ?: 'من را دنبال کنید'); ?></span>
                        </a>
                    <?php endif; ?>
                    <button class="septiani-theme-toggle" type="button" id="zara-theme-toggle" aria-label="تغییر حالت روشن/تیره" title="تغییر حالت روشن/تیره">
                        <i class="fa-solid fa-sun"></i>
                        <i class="fa-solid fa-moon"></i>
                    </button>
                    <button class="septiani-search-btn" type="button" onclick="toggleSearchPanel()">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </div>

                <!-- دکمه همبرگر (فقط موبایل) -->
                <button class="septiani-mobile-menu-btn" type="button" onclick="toggleMobileMenu()">
                    <span></span><span></span><span></span>
                </button>
            </div>
        </div>
    </div>
</nav>

<!-- منوی آف‌کانواس (موبایل) -->
<div class="septiani-offcanvas" id="mobileMenu">
    <div class="septiani-offcanvas-header">
        <div class="septiani-offcanvas-logo">
            <a href="<?php $this->options->siteUrl(); ?>">
                <?php if ($this->options->logo_icon): ?>
                    <i class="<?php echo $zaraLogoIcon; ?>"></i>
                <?php endif; ?>
                <span><?php $this->options->title(); ?></span>
            </a>
        </div>
        <div class="septiani-offcanvas-tools">
            <button class="septiani-theme-toggle" type="button" onclick="zaraToggleTheme()" aria-label="تغییر حالت روشن/تیره" title="تغییر حالت روشن/تیره">
                <i class="fa-solid fa-sun"></i>
                <i class="fa-solid fa-moon"></i>
            </button>
            <button class="septiani-offcanvas-close" onclick="toggleMobileMenu()">&times;</button>
        </div>
    </div>
    <div class="septiani-offcanvas-body">
        <ul class="septiani-offcanvas-nav">

            <?php
            // دسته‌بندی‌ها — نمونهٔ مجزا با پسوند @ برای شمارش دوباره (رفع باگ منوی موبایل)
            if (!empty($selectedCats) && is_array($selectedCats)):
                $this->widget('Widget_Metas_Category_List@zara-offcanvas')->to($navCatsMobile);
                while($navCatsMobile->next()):
                    if (in_array($navCatsMobile->slug, $selectedCats)):
                        $icon = isset($customIcons[$navCatsMobile->slug]) ? $customIcons[$navCatsMobile->slug] : 'fa-folder';
            ?>
                <li>
                    <a href="<?php $navCatsMobile->permalink(); ?>">
                        <i class="fa-solid <?php echo $icon; ?>"></i> <?php $navCatsMobile->name(); ?>
                    </a>
                </li>
            <?php
                    endif;
                endwhile;
            endif;

            // صفحات — نمونهٔ مجزا با پسوند @
            if (!empty($selectedPages) && is_array($selectedPages)):
                $this->widget('Widget_Contents_Page_List@zara-offcanvas')->to($pagesMobile);
                while($pagesMobile->next()):
                    if (in_array($pagesMobile->permalink, $selectedPages)):
                        $slug = $pagesMobile->slug;
                        $icon = isset($pageIcons[$slug]) ? $pageIcons[$slug] : 'fa-file-lines';
            ?>
                <li>
                    <a href="<?php $pagesMobile->permalink(); ?>">
                        <i class="fa-solid <?php echo $icon; ?>"></i> <?php $pagesMobile->title(); ?>
                    </a>
                </li>
            <?php
                    endif;
                endwhile;
            endif;
            ?>
        </ul>

        <?php if ($this->options->ctaLink): ?>
        <a href="<?php $this->options->ctaLink(); ?>" target="_blank" class="septiani-cta septiani-cta--offcanvas">
            <i class="<?php echo $zaraCtaIcon; ?>"></i>
            <span><?php echo htmlspecialchars($this->options->ctaText ?: 'من را دنبال کنید'); ?></span>
        </a>
        <?php endif; ?>
    </div>
</div>

<!-- پنل جستجو (مخفی در ابتدا) -->
<div class="septiani-search-panel" id="searchPanel">
    <div class="septiani-search-panel-content">
        <button class="septiani-search-panel-close" onclick="toggleSearchPanel()">&times;</button>
        <form method="post" action="<?php $this->options->siteUrl(); ?>" class="septiani-search-form">
            <input type="text" name="s" placeholder="عبارت جستجو..." autocomplete="off">
            <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
        </form>
    </div>
</div>

<!-- هدر بر اساس نوع صفحه -->
<?php if ($this->is('index')): ?>
    <!-- ====== HEADER صفحه اصلی ====== -->
    <header class="septiani-site-header position-relative overflow-hidden">
        <div class="container text-center position-relative" style="z-index: 2;">
            <div class="septiani-logo-container">
                <?php if ($this->options->logo_url): ?>
                    <img class="septiani-logo-img mx-auto d-block" src="<?php $this->options->logo_url(); ?>" alt="">
                <?php else: ?>
                    <img class="septiani-logo-img mx-auto d-block" src="<?php $this->options->themeUrl('img/profile.jpg'); ?>" alt="">
                <?php endif; ?>
                <h1 class="septiani-site-title"><?php $this->options->title(); ?></h1>
                <h2 class="septiani-site-slogan"><?php $this->options->description(); ?></h2>
            </div>
        </div>
        <!-- الگوی پس‌زمینه فقط از طریق کلاس zara-pattern-* روی <body> اعمال می‌شود
             (حذف لایهٔ ::before سربرگ در ۲.۲.۱ — رفع دوبار رندر شدن الگو در ایندکس/جستجو) -->
    </header>


            <?php elseif ($this->is('category') || $this->is('tag') || $this->is('search') || $this->is('author') || $this->is('date')): ?>
                <!-- ====== HEADER صفحات آرشیو ====== -->
                <header class="septiani-site-header septiani-archive-header position-relative overflow-hidden">
                    <div class="container text-center position-relative" style="z-index: 2;">
                        <h1 class="septiani-archive-hero-title">
                            <?php if ($this->is('category') && method_exists($this, 'getArchiveSlug')): ?>
                                <i class="fa-solid <?php echo getCategoryIcon($this->getArchiveSlug()); ?> septiani-archive-hero-icon"></i>
                            <?php endif; ?>
                            <?php $this->archiveTitle(array(
                                'category'  =>  _t('دسته‌بندی: %s'),
                                'search'    =>  _t('جستجو: %s'),
                                'tag'       =>  _t('برچسب: %s'),
                                'author'    =>  _t('نویسنده: %s'),
                                'date'      =>  _t('بایگانی: %s')
                            ), '', ''); ?>
                        </h1>
                    </div>
                </header>
            <?php endif; ?>

<!-- اسکریپت‌های منو و جستجو -->
<script>
function toggleMobileMenu() {
    const menu = document.getElementById('mobileMenu');
    menu.classList.toggle('show');
    if (menu.classList.contains('show')) {
        document.body.style.overflow = 'hidden';
    } else {
        document.body.style.overflow = '';
    }
}

function toggleSearchPanel() {
    const panel = document.getElementById('searchPanel');
    panel.classList.toggle('show');
    if (panel.classList.contains('show')) {
        document.body.style.overflow = 'hidden';
        setTimeout(() => panel.querySelector('input')?.focus(), 300);
    } else {
        document.body.style.overflow = '';
    }
}

// بستن منو با کلیک روی لینک‌ها
document.querySelectorAll('.septiani-offcanvas-nav a').forEach(link => {
    link.addEventListener('click', () => {
        document.getElementById('mobileMenu').classList.remove('show');
        document.body.style.overflow = '';
    });
});

// بستن پنل جستجو با Escape
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.getElementById('searchPanel').classList.remove('show');
        document.getElementById('mobileMenu').classList.remove('show');
        document.body.style.overflow = '';
    }
});
</script>
