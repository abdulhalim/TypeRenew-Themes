<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="error-page">
    <span class="error-art" aria-hidden="true">
        <svg width="72" height="72" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
    </span>
    <h2 class="error-code">۴۰۴</h2>
    <p class="error-message">این صفحه پیدا نشد. شاید پاک شده یا اصلاً وجود نداشته است.</p>
    <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="error-search">
        <input type="search" name="s" class="form-input" placeholder="جستجو…" aria-label="جستجو" autofocus />
        <button type="submit" class="btn-submit">بگرد</button>
    </form>
    <a class="read-more" href="<?php $this->options->siteUrl(); ?>">بازگشت به خانه</a>
</div>

<?php $this->need('footer.php'); ?>
