<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

use Typecho\Db;
use Typecho\Plugin;
use Widget\Archive;
use Widget\Options;
use Widget\User;

/**
 * تبدیل ارقام لاتین به فارسی
 */
function noorFaDigits(?string $text): string
{
    if ($text === null) {
        return '';
    }
    return strtr((string) $text, [
        '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
        '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
    ]);
}

/**
 * فیلتر خروجی نهایی صفحه:
 * فقط گره‌های متنیِ بیرون از تگ‌ها را به ارقام فارسی تبدیل می‌کند.
 * نشانی‌ها، مقدار ویژگی‌ها (مثل datetime) و محتوای کد دست‌نخورده می‌ماند.
 */
function noorDigitsFilter(string $html): string
{
    if ($html === '') {
        return $html;
    }

    $parts = preg_split('/(<[^>]+>)/', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
    if ($parts === false) {
        return $html;
    }

    $skipTags  = ['pre', 'code', 'kbd', 'samp', 'script', 'style', 'textarea'];
    $skipStack = [];
    $out       = '';

    foreach ($parts as $part) {
        if ($part === '') {
            continue;
        }

        if ($part[0] === '<') {
            if (preg_match('/^<\s*(\/?)\s*([a-zA-Z][a-zA-Z0-9-]*)/', $part, $m)) {
                $tag = strtolower($m[2]);
                if (in_array($tag, $skipTags, true)) {
                    if ($m[1] === '/') {
                        array_pop($skipStack);
                    } elseif (!preg_match('/\/\s*>$/', $part)) {
                        $skipStack[] = $tag;
                    }
                }
            }
            $out .= $part;
            continue;
        }

        if ($skipStack === []) {
            $out .= noorFaDigits($part);
        } else {
            $out .= $part;
        }
    }

    return $out;
}

// ثبت فیلتر تبدیل ارقام لاتین به فارسی روی خروجی صفحه.
// نکته: پاسخ AJAX دکمهٔ لایک نباید از این فیلتر بگذرد (رشتهٔ JSON را خراب می‌کند)
// پس در حالت درخواست لایک، بافر فعال نمی‌شود.
$noorIsLikeRequest = isset($_GET['noor-action']) && (string) $_GET['noor-action'] === 'like';
if (!$noorIsLikeRequest) {
    ob_start('noorDigitsFilter');
}

/**
 * تنظیمات پوسته (از بخش «تنظیمات پوسته» در مدیریت قابل ویرایش است)
 */
function themeConfig($form)
{
    $logoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'logoUrl',
        null,
        null,
        'نشانی لوگو',
        'اگه دوست داری به‌جای نام سایت، لوگوی خودت بالای صفحه نشون داده بشه، نشانی تصویرش رو این‌جا بذار. خالی بمونه فقط نام سایت نمایش داده می‌شه.'
    );
    $form->addInput($logoUrl->addRule('url', 'لطفاً یک نشانی (URL) معتبر وارد کن'));

    $colorSchema = new \Typecho\Widget\Helper\Form\Element\Select(
        'colorSchema',
        [
            'auto'  => 'خودکار (مثل تنظیمات دستگاه)',
            'light' => 'روز (روشن)',
            'dark'  => 'شب (تاریک)'
        ],
        'auto',
        'حالت نمایش',
        'پوسته رو روی روز، شب یا حالت خودکار بذار.'
    );
    $form->addInput($colorSchema);

    $accentColor = new \Typecho\Widget\Helper\Form\Element\Select(
        'accentColor',
        [
            'indigo' => 'نیلی (پیشنهادی)',
            'blue'   => 'آبی',
            'teal'   => 'سبز متمایل به آبی',
            'rose'   => 'صورتی ملایم',
            'amber'  => 'کهربایی گرم',
            'slate'  => 'سربی خنثی'
        ],
        'indigo',
        'رنگ تأکیدی',
        'یک رنگ برای لینک‌ها، دکمه‌ها و تأکیدها. بقیهٔ پوسته مینیمال و خنثی می‌مونه.'
    );
    $form->addInput($accentColor);

    $showStats = new \Typecho\Widget\Helper\Form\Element\Select(
        'showStats',
        [
            'yes' => 'نمایش بده',
            'no'  => 'نمایش نده'
        ],
        'yes',
        'نمایش آمار بازدید و لایک',
        'آمار بازدید و تعداد لایک هر نوشته کنار متادیتای آن نمایش داده بشه یا نه.'
    );
    $form->addInput($showStats);

    $countLoggedInViews = new \Typecho\Widget\Helper\Form\Element\Select(
        'countLoggedInViews',
        [
            '0' => 'شمرده نشه (پیشنهادی)',
            '1' => 'شمرده بشه'
        ],
        '0',
        'شمارش بازدید مدیر/نویسنده',
        'وقتی خودت وارد سامانه شدی، بازدیدت هم شمرده بشه یا نه.'
    );
    $form->addInput($countLoggedInViews);

    $viewsInterval = new \Typecho\Widget\Helper\Form\Element\Number(
        'viewsInterval',
        null,
        3600,
        'فاصلهٔ زمانی شمارش بازدید (ثانیه)',
        'برای جلوگیری از شمارش مضاعف، تا این ثانیه بازدید یک نوشته توسط یک بازدیدکننده دوباره شمرده نمی‌شه. صفر یعنی همیشه شمرده بشه.'
    );
    $form->addInput($viewsInterval);

    $defaultCover = new \Typecho\Widget\Helper\Form\Element\Text(
        'defaultCover',
        null,
        null,
        'تصویر شاخص پیش‌فرض',
        'اگه یه نوشته عکس نداشت و فیلد سفارشی هم براش گذاشته نشده بود، این عکس به‌عنوان کاور استفاده می‌شه. خالی بمونه بدون کاور نشون داده می‌شه.'
    );
    $form->addInput($defaultCover);
}

/**
 * کادر «تصویر شاخص» در ویرایشگر — مثل سایر پوسته‌های بسته.
 * مقدار به‌صورت فیلد سفارشی thumb ذخیره می‌شود.
 */
function themeFields($layout)
{
    $thumb = new \Typecho\Widget\Helper\Form\Element\Text(
        'thumb',
        null,
        null,
        'تصویر شاخص',
        'نشانی (لینک) عکسِ دلخواهت رو این‌جا کپی کن تا کاور نوشته‌ات بشه. خالی بمونه، اولین عکسِ داخل خود نوشته یا کاور پیش‌فرض تنظیمات نشون داده می‌شه.'
    );
    $layout->addItem($thumb);
}

/**
 * راه‌انداز پوسته:
 *  • ثبت قلاب شمارندهٔ بازدید
 *  • مدیریت درخواست AJAX برای لایک (از مسیر ?noor-action=like)
 */
function themeInit(Archive $archive)
{
    // ——— پایانهٔ AJAX دکمهٔ لایک ———
    $action = isset($_GET['noor-action']) ? (string) $_GET['noor-action'] : '';
    if ($action === 'like') {
        noorHandleLikeRequest();
        return;
    }

    // ——— شمارندهٔ بازدید یکپارچه ———
    Plugin::factory('Widget\Archive')->beforeRender = 'noorCountView';
}

/**
 * اطمینان از وجود ستون views و likes روی جدول contents.
 *  • views: شمارندهٔ بازدید (هم‌راستا با الگوی پلاگین ViewsCounter)
 *  • likes: شمارندهٔ لایک‌ها
 */
function noorSchemaReady(): bool
{
    static $ready = null;

    if ($ready !== null) {
        return $ready;
    }

    $ready = false;

    try {
        $db = Db::get();

        // بررسی views
        $viewsExists = true;
        try {
            $db->fetchRow($db->select('table.contents.views')->from('table.contents')->limit(1));
        } catch (\Throwable $e) {
            $viewsExists = false;
        }
        if (!$viewsExists) {
            $prefix = $db->getPrefix();
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT NOT NULL DEFAULT 0');
        }

        // بررسی likes
        $likesExists = true;
        try {
            $db->fetchRow($db->select('table.contents.likes')->from('table.contents')->limit(1));
        } catch (\Throwable $e) {
            $likesExists = false;
        }
        if (!$likesExists) {
            $prefix = $db->getPrefix();
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `likes` INT NOT NULL DEFAULT 0');
        }

        $ready = true;
    } catch (\Throwable $e) {
        $ready = false;
    }

    return $ready;
}

/**
 * شمارش بازدید صفحات تکی — با جلوگیری از شمارش مضاعف در بازهٔ زمانی کوتاه.
 */
function noorCountView($archive): void
{
    if (!noorSchemaReady()) {
        return;
    }

    // اگر پلاگین مستقل ViewsCounter فعال بود، خودش شمارش می‌کند
    $activatedPlugins = Options::alloc()->plugins;
    if (is_array($activatedPlugins) && isset($activatedPlugins['activated']['ViewsCounter'])) {
        return;
    }

    // شمارش فقط برای صفحات تکی
    if (!$archive instanceof Archive || !$archive->is('single')) {
        return;
    }

    // فقط نوشته‌ها (نه برگه‌ها) — اختیاری: می‌توان برگه‌ها را هم شمارید
    if (!in_array((string) $archive->type, ['post'], true)) {
        return;
    }

    // بازدید کاربران واردشده
    $countLoggedIn = ((string) (Options::alloc()->countLoggedInViews ?? '0')) === '1';
    if (User::alloc()->hasLogin() && !$countLoggedIn) {
        return;
    }

    $cid = intval($archive->cid);
    if ($cid < 1) {
        return;
    }

    $interval = (int) (Options::alloc()->viewsInterval ?? 3600);
    if ($interval > 0) {
        $viewed = (string) \Typecho\Cookie::get('noorViews', '');
        $viewedIds = $viewed === '' ? [] : explode(',', $viewed);

        if (in_array((string) $cid, $viewedIds, true)) {
            return;
        }

        $viewedIds[] = (string) $cid;
        if (count($viewedIds) > 100) {
            $viewedIds = array_slice($viewedIds, -100);
        }

        \Typecho\Cookie::set('noorViews', implode(',', $viewedIds), time() + $interval);
    }

    try {
        $db = Db::get();
        $db->query(
            $db->update('table.contents')
                ->expression('views', 'views + 1')
                ->where('cid = ?', $cid)
        );
    } catch (\Throwable $e) {
        // خطا در شمارش بازدید نباید نمایش صفحه را متوقف کند
    }
}

/**
 * دریافت تعداد بازدید یک آرشیو
 */
function noorGetViews(Archive $archive): int
{
    try {
        return max(0, (int) $archive->views);
    } catch (\Throwable $e) {
        return 0;
    }
}

/**
 * دریافت تعداد لایک یک آرشیو
 */
function noorGetLikes(Archive $archive): int
{
    try {
        return max(0, (int) $archive->likes);
    } catch (\Throwable $e) {
        return 0;
    }
}

/**
 * آیا کاربرِ فعلی این نوشته را لایک کرده؟ (بر اساس کوکی)
 */
function noorIsLiked(int $cid): bool
{
    $liked = (string) \Typecho\Cookie::get('noorLiked', '');
    if ($liked === '') {
        return false;
    }
    $ids = explode(',', $liked);
    return in_array((string) $cid, $ids, true);
}

/**
 * هش کوتاه از IP کاربر (sha1) برای جلوگیری از لایک مضاعفِ سمت سرور.
 * کاربران با IP یکسان در یک بازهٔ زمانی نمی‌توانند دوباره لایک کنند (toggle روی همان IP).
 */
function noorIpHash(): string
{
    $ip = '';
    foreach (['HTTP_X_FORWARDED_FOR', 'HTTP_CF_CONNECTING_IP', 'REMOTE_ADDR'] as $key) {
        if (!empty($_SERVER[$key])) {
            $ip = (string) $_SERVER[$key];
            $ip = trim(explode(',', $ip)[0]);
            if ($ip !== '') {
                break;
            }
        }
    }
    return $ip === '' ? 'anon' : substr(sha1($ip), 0, 16);
}

/**
 * مدیریت درخواست لایک:
 *  • پارامتر cid (integer)
 *  • خروجی JSON
 *
 * اگر کاربر قبلاً لایک کرده باشد، لایک لغو می‌شود (toggle).
 */
function noorHandleLikeRequest(): void
{
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('X-Robots-Tag: noindex, nofollow');

    $respond = function (int $status, array $payload) {
        http_response_code($status);
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    };

    if (!noorSchemaReady()) {
        $respond(503, ['ok' => false, 'error' => 'schema_unavailable']);
    }

    $cid = isset($_GET['cid']) ? intval($_GET['cid']) : 0;
    if ($cid < 1) {
        $respond(400, ['ok' => false, 'error' => 'invalid_cid']);
    }

    try {
        $db = Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.cid', 'table.contents.likes', 'table.contents.type', 'table.contents.status')
                ->from('table.contents')
                ->where('table.contents.cid = ?', $cid)
                ->limit(1)
        );

        if (!$row) {
            $respond(404, ['ok' => false, 'error' => 'not_found']);
        }

        // فقط روی نوشته‌های منتشرشده اجازه لایک بده
        if ((string) $row['type'] !== 'post' || (string) $row['status'] !== 'publish') {
            $respond(403, ['ok' => false, 'error' => 'not_likable']);
        }

        $currentLikes = (int) $row['likes'];
        $liked = noorIsLiked($cid);

        if ($liked) {
            // لغو لایک
            $newLikes = max(0, $currentLikes - 1);
            $db->query(
                $db->update('table.contents')
                    ->rows(['likes' => $newLikes])
                    ->where('cid = ?', $cid)
            );
            noorSetLiked($cid, false);
        } else {
            // افزودن لایک
            $newLikes = $currentLikes + 1;
            $db->query(
                $db->update('table.contents')
                    ->rows(['likes' => $newLikes])
                    ->where('cid = ?', $cid)
            );
            noorSetLiked($cid, true);
        }

        $respond(200, [
            'ok'        => true,
            'cid'       => $cid,
            'likes'     => $newLikes,
            'liked'     => !$liked,
            'likesText' => noorLikesText($newLikes),
        ]);
    } catch (\Throwable $e) {
        $respond(500, ['ok' => false, 'error' => 'server_error']);
    }
}

/**
 * ثبت/حذف کوکی لایک
 */
function noorSetLiked(int $cid, bool $liked): void
{
    $cookie = (string) \Typecho\Cookie::get('noorLiked', '');
    $ids = $cookie === '' ? [] : explode(',', $cookie);
    $ids = array_values(array_unique(array_map('strval', $ids)));

    if ($liked) {
        if (!in_array((string) $cid, $ids, true)) {
            $ids[] = (string) $cid;
        }
    } else {
        $ids = array_values(array_filter($ids, fn ($v) => $v !== (string) $cid));
    }

    if (count($ids) === 0) {
        \Typecho\Cookie::set('noorLiked', '', time() - 3600);
    } else {
        // ۵ سال — برای سادگی، لایک پایدار می‌ماند
        \Typecho\Cookie::set('noorLiked', implode(',', $ids), time() + 5 * 365 * 86400);
    }
}

/**
 * متن فارسی تعداد لایک با ارقام فارسی
 */
function noorLikesText(int $num): string
{
    if ($num <= 0) {
        return 'بدون لایک';
    }
    if ($num === 1) {
        return '۱ لایک';
    }
    return noorFaDigits((string) $num) . ' لایک';
}

/**
 * متن فارسی تعداد بازدید با ارقام فارسی
 */
function noorViewsText(int $num): string
{
    if ($num <= 0) {
        return 'بدون بازدید';
    }
    if ($num === 1) {
        return '۱ بازدید';
    }
    return noorFaDigits((string) $num) . ' بازدید';
}

/**
 * قالب‌بندی فشردهٔ اعداد بزرگ:
 *   ۹۹۹ → ۹۹۹ / ۱۰۰۰ → ۱ هزار / ۱۲۰۰۰۰۰ → ۱٫۲ میلیون
 */
function noorFormatCount(int $num): string
{
    if ($num >= 1000000) {
        return noorCompactNumber(round($num / 1000000, 1)) . ' م';
    }
    if ($num >= 1000) {
        $thousands = round($num / 1000, 1);
        if ($thousands >= 1000) {
            return noorCompactNumber(round($thousands / 1000, 1)) . ' م';
        }
        return noorCompactNumber($thousands) . ' ک';
    }
    return noorFaDigits((string) $num);
}

function noorCompactNumber(float $value): string
{
    $text = number_format($value, 1, '.', '');
    if (substr($text, -2) === '.0') {
        $text = substr($text, 0, -2);
    }
    return noorFaDigits(str_replace('.', '٫', $text));
}

/**
 * تصویر شاخص نوشته:
 *  ترتیب اولویت: فیلد سفارشی (thumb/cover/img) ← نخستین تصویر داخل نوشته
 *  ← تصویر پیش‌فرض تنظیمات پوسته ← خالی
 */
function noorThumbnail(Archive $archive, string $defaultCover = ''): string
{
    // ۱) فیلد سفارشی
    $fields = $archive->fields ?? null;
    if ($fields instanceof \Typecho\Config) {
        foreach (['thumb', 'cover', 'img', 'thumbnail'] as $field) {
            $value = $fields->{$field} ?? null;
            if (is_string($value) && trim($value) !== '') {
                return trim($value);
            }
        }
    }

    // ۲) نخستین تصویر داخل متن نوشته
    $text = (string) ($archive->text ?? '');
    if ($text !== '') {
        if (preg_match('/<img[^>]*\bsrc\s*=\s*["\']([^"\']+)["\']/i', $text, $m)) {
            return $m[1];
        }
        if (preg_match('/!\[[^\]]*\]\(\s*<?([^)\s>]+)>?\s*(?:"[^"]*")?\)/', $text, $m)) {
            return $m[1];
        }
    }

    // ۳) تصویر پیش‌فرض از تنظیمات
    $defaultCover = is_string($defaultCover) ? trim($defaultCover) : '';
    if ($defaultCover !== '') {
        return $defaultCover;
    }

    return '';
}

/**
 * متادیتای نوشته (عنوان + نویسنده + تاریخ + دسته + آمار)
 */
function postMeta(Archive $archive, string $metaType = 'archive')
{
    $titleTag = $metaType === 'archive' ? 'h2' : 'h1';
    $showStats = ((string) (Options::alloc()->showStats ?? 'yes')) !== 'no';
?>
    <<?php echo $titleTag ?> class="post-title" itemprop="name headline">
        <a itemprop="url" href="<?php $archive->permalink() ?>"><?php $archive->title() ?></a>
    </<?php echo $titleTag ?>>

    <?php if ($metaType !== 'page'): ?>
        <ul class="post-meta">
            <li itemprop="author" itemscope itemtype="http://schema.org/Person">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                <a itemprop="name" href="<?php $archive->author->permalink(); ?>" rel="author"><?php $archive->author(); ?></a>
            </li>
            <li>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                <time datetime="<?php $archive->date('c'); ?>" itemprop="datePublished"><?php $archive->date(); ?></time>
            </li>
            <li>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
                <?php $archive->category(','); ?>
            </li>
            <?php if ($metaType === 'archive'): ?>
                <li itemprop="interactionCount">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                    <a itemprop="discussionUrl" href="<?php $archive->permalink() ?>#comments"><?php $archive->commentsNum('بدون دیدگاه', '۱ دیدگاه', '%d دیدگاه'); ?></a>
                </li>
            <?php endif; ?>
            <?php if ($showStats): ?>
                <li class="meta-views" aria-label="تعداد بازدید">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                    <span><?php echo noorViewsText(noorGetViews($archive)); ?></span>
                </li>
                <li class="meta-likes" aria-label="تعداد لایک">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"></path></svg>
                    <span><?php echo noorLikesText(noorGetLikes($archive)); ?></span>
                </li>
            <?php endif; ?>
        </ul>
    <?php endif; ?>
<?php
}

/**
 * رندر نوشتهٔ تکی/برگه
 */
function renderSingle(Archive $archive, string $metaType = 'post'): void
{
    $showStats = ((string) (Options::alloc()->showStats ?? 'yes')) !== 'no';
    $cid = intval($archive->cid);
    $liked = $cid > 0 ? noorIsLiked($cid) : false;
    $likes = noorGetLikes($archive);
?>
    <article class="post post-single" itemscope itemtype="http://schema.org/BlogPosting">
        <?php postMeta($archive, $metaType); ?>
        <div class="post-content" itemprop="articleBody">
            <?php $archive->content(); ?>
        </div>
        <?php if ($metaType === 'post' && count($archive->tags) > 0): ?>
            <p itemprop="keywords" class="tags">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>
                <?php $archive->tags(' ', true, 'none'); ?>
            </p>
        <?php endif; ?>

        <?php if ($metaType === 'post' && $showStats): ?>
            <div class="post-actions">
                <button
                    type="button"
                    class="like-btn<?php echo $liked ? ' is-liked' : ''; ?>"
                    data-cid="<?php echo $cid; ?>"
                    data-liked="<?php echo $liked ? '1' : '0'; ?>"
                    data-likes="<?php echo $likes; ?>"
                    aria-label="لایک این نوشته"
                    title="لایک">
                    <svg class="like-icon" width="20" height="20" viewBox="0 0 24 24" fill="<?php echo $liked ? 'currentColor' : 'none'; ?>" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"></path></svg>
                    <span class="like-text"><?php echo noorLikesText($likes); ?></span>
                </button>
                <span class="post-views" aria-label="تعداد بازدید">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                    <span><?php echo noorViewsText(noorGetViews($archive)); ?></span>
                </span>
            </div>
        <?php endif; ?>
    </article>
<?php
}

/**
 * ظاهر دیدگاه‌ها (همان ساختار پایه)
 */
function threadedComments($comments, $options)
{
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
?>
    <li id="li-<?php $comments->theId(); ?>" class="comment-body<?php
    if ($comments->levels > 0) {
        echo ' comment-child';
        $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
    } else {
        echo ' comment-parent';
    }
    $comments->alt(' comment-odd', ' comment-even');
    echo $commentClass;
    ?>">
        <div id="<?php $comments->theId(); ?>" class="comment-inner">
            <div class="comment-author-avatar">
                <?php $comments->gravatar('40', ''); ?>
            </div>
            <div class="comment-main">
                <div class="comment-meta">
                    <cite class="comment-author" itemprop="creator" itemscope itemtype="http://schema.org/Person">
                        <?php $comments->author(); ?>
                    </cite>
                    <span class="comment-time">
                        <a href="<?php $comments->permalink(); ?>" itemprop="url">
                            <time datetime="<?php $comments->date('c'); ?>" itemprop="commentTime"><?php $comments->date('Y-m-d H:i'); ?></time>
                        </a>
                    </span>
                    <span class="comment-reply">
                        <?php $comments->reply('پاسخ'); ?>
                    </span>
                </div>
                <div class="comment-content" itemprop="commentText">
                    <?php $comments->content(); ?>
                </div>
            </div>
        </div>
        <?php if ($comments->children) { ?>
            <div class="comment-children">
                <?php $comments->threadedComments($options); ?>
            </div>
        <?php } ?>
    </li>
<?php
}
