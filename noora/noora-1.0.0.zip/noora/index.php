<?php
/**
 * نورا — پوسته‌ای سبک و ساده برای وبلاگ‌‌ نویسی
 *
 * @package نورا
 * @author پوردریایی
 * @version 1.0.0
 * @link https://www.pourdaryaeri.ir
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');
?>

<?php $noorIsFirstPage = $this->is('index') && max(1, intval($this->request->page ?? 1)) === 1; ?>

<?php if (!($this->is('index'))): ?>
    <h3 class="archive-title">
        <?php $this->archiveTitle([
            'category' => 'دستهٔ «%s»',
            'search'   => 'نتایج جستجو برای «%s»',
            'tag'      => 'نوشته‌های برچسب «%s»',
            'author'   => 'نوشته‌های %s'
        ], '', ''); ?>
    </h3>
<?php endif; ?>

<?php if ($noorIsFirstPage && trim((string) $this->options->description) !== '' && ((string) ($this->options->showHero ?? 'yes')) !== 'no'): ?>
<section class="hero" aria-label="معرفی کوتاه سایت">
    <h1 class="hero-title"><?php $this->options->title(); ?></h1>
    <p class="hero-desc"><?php $this->options->description(); ?></p>
</section>
<?php endif; ?>

<?php if ($this->have()): ?>
    <div class="post-list">
    <?php while ($this->next()): ?>
        <?php $noorCover = noorThumbnail($this, (string) ($this->options->defaultCover ?? '')); ?>
        <article class="post-card post" itemscope itemtype="http://schema.org/BlogPosting">
            <?php if ($noorCover !== ''): ?>
                <a class="post-cover" href="<?php $this->permalink(); ?>" tabindex="-1" aria-hidden="true">
                    <img itemprop="image" src="<?php echo htmlspecialchars($noorCover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars((string) $this->title, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy"/>
                </a>
            <?php endif; ?>
            <div class="post-card-body">
                <?php postMeta($this, 'archive'); ?>
                <div class="post-excerpt" itemprop="description">
                    <?php $this->excerpt(140, '…'); ?>
                </div>
                <a class="read-more" href="<?php $this->permalink(); ?>">
                    ادامه مطلب
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"></path></svg>
                </a>
            </div>
        </article>
    <?php endwhile; ?>
    </div>
<?php else: ?>
    <div class="empty-state">
        <span class="empty-art" aria-hidden="true">
            <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="9" y1="13" x2="15" y2="13"></line><line x1="9" y1="17" x2="13" y2="17"></line></svg>
        </span>
        <h2 class="empty-title">هنوز چیزی این‌جا نیست…</h2>
        <p>اولین نوشته‌ات را منتشر کن؛ اینجا منتظرت می‌ماند.</p>
    </div>
<?php endif; ?>

<nav class="pagination-area" aria-label="ناوبری صفحه‌ها">
    <?php $this->pageNav(
        '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18l6-6-6-6"/></svg>',
        '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>',
        3,
        '…'
    ); ?>
</nav>

<?php $this->need('footer.php'); ?>
