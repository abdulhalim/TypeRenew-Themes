<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
</main>

<footer class="site-footer" role="contentinfo">
    <div class="container">
        <p class="footer-meta">
            <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>
            · <?php echo noorFaDigits((string) date('Y')); ?>
        </p>
        <p class="footer-powered">قدرت‌گرفته از <a href="https://www.typerenew.ir" rel="noopener" target="_blank">TypeRenew</a> با پوستهٔ «نورا»</p>
    </div>
</footer>

<?php $this->footer(); ?>

<script>
    (function() {
        // ——— تعویض حالت روز/شب ———
        var btn = document.getElementById('theme-switch');
        if (btn) {
            var html = document.documentElement;
            var iconPath = btn.querySelector('path');
            var transitionTimeout;

            function updateIcon() {
                var isDark = html.getAttribute('data-theme') === 'dark';
                if (isDark) {
                    iconPath.setAttribute('d', 'M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42M17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0z');
                } else {
                    iconPath.setAttribute('d', 'M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z');
                }
            }

            updateIcon();

            btn.addEventListener('click', function() {
                var currentDark = html.getAttribute('data-theme') === 'dark';
                var newTheme = currentDark ? 'light' : 'dark';

                html.classList.add('theme-transition');
                html.setAttribute('data-theme', newTheme);
                try { localStorage.setItem('theme', newTheme); } catch (e) {}
                updateIcon();

                clearTimeout(transitionTimeout);
                transitionTimeout = setTimeout(function() {
                    html.classList.remove('theme-transition');
                }, 300);
            });

            var prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
            if (prefersDark && prefersDark.addEventListener) {
                prefersDark.addEventListener('change', function(e) {
                    var stored = null;
                    try { stored = localStorage.getItem('theme'); } catch (err) {}
                    if (!stored) {
                        html.classList.add('theme-transition');
                        html.setAttribute('data-theme', e.matches ? 'dark' : 'light');
                        updateIcon();
                        clearTimeout(transitionTimeout);
                        transitionTimeout = setTimeout(function() {
                            html.classList.remove('theme-transition');
                        }, 300);
                    }
                });
            }
        }

        // ——— دکمهٔ لایک ———
        var noorSiteUrl = <?php echo json_encode(rtrim((string) \Widget\Options::alloc()->siteUrl, '/') . '/', JSON_UNESCAPED_SLASHES); ?>;
        var likeButtons = document.querySelectorAll('.like-btn');
        if (likeButtons.length) {
            // درخواست CSRF-safe با GET روی همون نشانی پوسته (مستقل از واردبودن کاربر)
            likeButtons.forEach(function(btn) {
                var cid = btn.getAttribute('data-cid');
                if (!cid) return;

                // مقدار اولیه نمایش
                function setUi(liked, likes, likesText) {
                    btn.setAttribute('data-liked', liked ? '1' : '0');
                    btn.setAttribute('data-likes', String(likes));
                    btn.classList.toggle('is-liked', !!liked);
                    var icon = btn.querySelector('.like-icon');
                    if (icon) {
                        icon.setAttribute('fill', liked ? 'currentColor' : 'none');
                    }
                    var txt = btn.querySelector('.like-text');
                    if (txt) {
                        txt.textContent = likesText || (likes + ' لایک');
                    }
                }

                btn.addEventListener('click', function() {
                    if (btn.classList.contains('is-busy')) return;
                    btn.classList.add('is-busy');

                    var url = noorSiteUrl + '?noor-action=like&cid=' + encodeURIComponent(cid);

                    fetch(url, {
                        method: 'GET',
                        credentials: 'same-origin',
                        headers: { 'X-Requested-With': 'XMLHttpRequest' }
                    }).then(function(r) {
                        if (!r.ok) throw new Error('http_' + r.status);
                        return r.json();
                    }).then(function(data) {
                        if (data && data.ok) {
                            setUi(data.liked, data.likes, data.likesText);
                        }
                    }).catch(function() {
                        // خطا بی‌صرف نما؛ UI بدون تغییر می‌ماند
                    }).finally(function() {
                        btn.classList.remove('is-busy');
                    });
                });
            });
        }
    })();
</script>

</body>
</html>
