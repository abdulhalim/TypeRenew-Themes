<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $requireUrl = isset($this->options->commentsRequireUrl) ? $this->options->commentsRequireUrl : $this->options->commentsRequireURL; ?>

<div id="comments" class="comments-area">
    <?php $this->comments()->to($comments); ?>

    <div class="comments-wrapper">
        <?php if ($comments->have()): ?>
            <div class="comments-header">
                <?php $this->commentsNum('بدون دیدگاه', '۱ دیدگاه', '%d دیدگاه'); ?>
            </div>

            <div class="comments-body">
                <?php $comments->listComments([
                    'before'        => '<ul class="comment-list">',
                    'after'         => '</ul>',
                    'commentStatus' => 'در انتظار تأیید'
                ]); ?>

                <?php $comments->pageNav('&raquo;', '&laquo;'); ?>
            </div>
        <?php endif; ?>

        <?php if ($this->allow('comment')): ?>
            <div id="<?php $this->respondId(); ?>" class="respond">
                <div class="cancel-comment-reply">
                    <?php $comments->cancelReply(); ?>
                </div>

                <h3 id="response" class="respond-title">دیدگاه بنویس</h3>
                <form method="post" action="<?php $this->commentUrl() ?>" id="comment-form" role="form">
                    <?php $security = $this->widget('\Widget\Security'); ?>
                    <input type="hidden" name="_" value="<?php echo htmlspecialchars($security->getToken($this->request->getRequestUrl()), ENT_QUOTES, 'UTF-8'); ?>">
                    <?php if ($this->user->hasLogin()): ?>
                        <p class="respond-login">
                            سلام، <a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>!
                            <a href="<?php $this->options->logoutUrl(); ?>" title="خروج">خروج &raquo;</a>
                        </p>
                    <?php else: ?>
                        <div class="comment-form-grid">
                            <div class="form-group">
                                <input type="text" name="author" id="author" class="form-input" placeholder="نام *" aria-label="نام" value="<?php $this->remember('author'); ?>" required />
                            </div>
                            <div class="form-group">
                                <input type="email" name="mail" id="mail" class="form-input" placeholder="ایمیل<?php if ($this->options->commentsRequireMail): ?> *<?php endif; ?>" aria-label="ایمیل" value="<?php $this->remember('mail'); ?>"<?php if ($this->options->commentsRequireMail): ?> required<?php endif; ?> />
                            </div>
                            <div class="form-group">
                                <input type="url" name="url" id="url" class="form-input" placeholder="وب‌سایت<?php if ($requireUrl): ?> *<?php endif; ?>" aria-label="وب‌سایت" value="<?php $this->remember('url'); ?>"<?php if ($requireUrl): ?> required<?php endif; ?> />
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <textarea name="text" id="textarea" class="form-input" placeholder="دیدگاهت را بنویس…" aria-label="متن دیدگاه" required><?php $this->remember('text'); ?></textarea>
                    </div>
                    <div class="form-group form-actions">
                        <button type="submit" class="btn-submit">فرستادن</button>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <div class="comments-closed">
                دیدگاه‌ها بسته شده‌اند.
            </div>
        <?php endif; ?>
    </div>
</div>
