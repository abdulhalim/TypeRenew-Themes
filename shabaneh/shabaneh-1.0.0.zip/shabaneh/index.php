<?php
/**
 * شبانه — پوستهٔ کافی‌نت و مرکز خدمات اینترنتی
 *
 * @package شبانه
 * @author پوردریایی
 * @link https://pourdaryaei.ir
 * @version 1.0.3
 * @since 1.6.0
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');


if (shabaneh_is_front()):

    /* ================================================================
     *  صفحهٔ اصلی — لندینگ کافی‌نت
     * ================================================================ */

    // ---------- داده‌های هیرو ----------
    $shabanehHeroBadge    = shabaneh_opt('shabanehHeroBadge', 'پشتیبانی و رفع مشکل در تمام ساعات');
    $shabanehHeroTitle    = shabaneh_opt('shabanehHeroTitle', 'همهٔ خدمات اینترنتی، زیر یک سقف');
    $shabanehHeroSubtitle = trim((string)shabaneh_opt_raw('shabanehHeroSubtitle'));
    $shabanehHeroSubtitle = ($shabanehHeroSubtitle === '') ? "از چاپ و اسکن تا ثبت‌نام‌های اینترنتی و دانلود جزوات و مقالات آماده؛\nبا اینترنت پرسرعت و سیستم‌های به‌روز، کارهای اینترنتی‌تان را سریع و مطمئن انجام دهید." : $shabanehHeroSubtitle;
    $shabanehHeroImageRaw = trim((string)shabaneh_opt_raw('shabanehHeroImage'));
    $shabanehHeroImage    = ($shabanehHeroImageRaw !== '') ? shabaneh_resolve_url($shabanehHeroImageRaw) : shabaneh_asset('img/hero.jpg');
    $shabanehHeroBtn1Text = shabaneh_opt('shabanehHeroBtn1Text', 'دانلود مقالات');
    $shabanehHeroBtn1Url  = shabaneh_opt('shabanehHeroBtn1Url', '#downloads');
    // اتصال داینامیک: اگر «دستهٔ مقالات دانلودی» انتخاب شده باشد و آدرس دکمه
    // روی حالت پیش‌فرض باشد، دکمه به صفحهٔ همان دسته لینک می‌شود.
    $shabanehDlCat = shabaneh_download_category();
    if ($shabanehDlCat !== null && in_array(trim($shabanehHeroBtn1Url), ['', '#downloads'], true)) {
        $shabanehHeroBtn1Url = $shabanehDlCat['url'];
    }
    $shabanehHeroBtn2Text = shabaneh_opt_raw('shabanehHeroBtn2Text');
    $shabanehHeroBtn2Url  = shabaneh_opt_raw('shabanehHeroBtn2Url');
    if (trim((string)$shabanehHeroBtn2Text) === '') { $shabanehHeroBtn2Text = 'مشاهدهٔ تعرفه‌ها'; }
    if (trim((string)$shabanehHeroBtn2Url) === '') { $shabanehHeroBtn2Url = '#tariff'; }
    $shabanehHeroStats    = array_slice(shabaneh_parse_stats(shabaneh_opt_raw('shabanehHeroStats')), 0, 4);
    $shabanehHeroUptime   = shabaneh_opt('shabanehHeroUptime', '99.9');

    // عنوان: کلمات داخل *ستاره* → هایلایت کهربایی
    $shabanehHeroTitleHtml = preg_replace('/\*([^*]+)\*/u', '<span class="grad-text">$1</span>', htmlspecialchars($shabanehHeroTitle, ENT_QUOTES, 'UTF-8'));

    // ---------- وضعیت زنده ----------
    $shabanehIsOpen   = shabaneh_is_open();
    $shabanehOpenText = $shabanehIsOpen ? 'اکنون باز است' : 'اکنون بسته است';
    $shabanehNow      = shabaneh_now_tehran();
    $shabanehClock    = toPersianNumbers($shabanehNow['H'] . ':' . $shabanehNow['i_str']);
    $shabanehTodayList = array_slice(shabaneh_parse_services(shabaneh_opt_raw('shabanehServicesText')), 0, 3);

    // ---------- خدمات ----------
    $shabanehServices = shabaneh_parse_services(shabaneh_opt_raw('shabanehServicesText'));
    $shabanehServicesCount = count($shabanehServices);

    // ---------- دانلودها ----------
    $shabanehDlTitle    = shabaneh_opt('shabanehDownloadsTitle', 'مقالات و دانلودها');
    $shabanehDlSubtitle = shabaneh_opt('shabanehDownloadsSubtitle', 'جزوه‌ها، کاربرگه‌ها و تحقیق‌های آمادهٔ چاپ — رایگان یا ویژهٔ اعضا');
    $shabanehDlCount    = max(1, min(12, (int)shabaneh_to_en_digits(shabaneh_opt('shabanehDownloadsCount', '6'))));
    $shabanehDownloads  = shabaneh_recent_posts($shabanehDlCount, true);
    $shabanehShowViews  = shabaneh_opt('shabanehShowViews', '1') === '1';
    $shabanehLoggedIn   = shabaneh_user_logged_in();

    // ---------- تعرفه ----------
    $shabanehTariffRows = shabaneh_parse_tariffs(shabaneh_opt_raw('shabanehTariffRows'));

    // ---------- چرا شبانه ----------
    $shabanehAboutTitle    = shabaneh_opt('shabanehAboutTitle', 'چرا کافی‌نت شبانه؟');
    $shabanehAboutText    = shabaneh_opt_raw('shabanehAboutText');
    $shabanehAboutImageRaw = trim((string)shabaneh_opt_raw('shabanehAboutImage'));
    $shabanehAboutImage   = ($shabanehAboutImageRaw !== '') ? shabaneh_resolve_url($shabanehAboutImageRaw) : shabaneh_asset('img/about.jpg');
    $shabanehAboutBadge   = shabaneh_opt('shabanehAboutBadge', 'از ۱۳۹۲ در خدمت شما');
    $shabanehAboutFeatures = array_slice(shabaneh_parse_features(shabaneh_opt_raw('shabanehAboutFeatures')), 0, 6);
    $shabanehGlance       = array_slice(shabaneh_parse_glance(shabaneh_opt_raw('shabanehGlanceStats')), 0, 4);

    // ---------- نظرات ----------
    $shabanehTestimonials = shabaneh_parse_testimonials(shabaneh_opt_raw('shabanehTestimonials'));

    // ---------- وبلاگ ----------
    $shabanehBlogTitle = shabaneh_opt('shabanehBlogTitle', 'از وبلاگ شبانه');
    $shabanehBlogCount = max(1, min(6, (int)shabaneh_to_en_digits(shabaneh_opt('shabanehBlogCount', '3'))));
    $shabanehBlogPosts = shabaneh_recent_posts($shabanehBlogCount * 2, false);
    if (shabaneh_download_category() === null) {
        // حالت خودکار: نوشته‌های دارای فیلد دانلود، وبلاگ نیستند
        // (در حالت دسته‌ای، این تفکیک داخل recent_posts با عضویت در دسته انجام شده است)
        $shabanehBlogPosts = array_values(array_filter($shabanehBlogPosts, static function ($p) {
            return empty($p['download']['has']);
        }));
    }
    $shabanehBlogPosts = array_slice($shabanehBlogPosts, 0, $shabanehBlogCount);

    // ---------- پرسش‌های متداول ----------
    $shabanehFaqRows = shabaneh_parse_faq(shabaneh_opt_raw('shabanehFaqRows'));

    // ---------- تماس ----------
    $shabanehPhone    = shabaneh_opt_raw('shabanehPhone');
    $shabanehEmail    = shabaneh_opt_raw('shabanehEmail');
    $shabanehAddress  = shabaneh_opt_raw('shabanehAddress');
    $shabanehMapEmbed = trim((string)shabaneh_opt_raw('shabanehMapEmbed'));
?>

    <!-- ================================================================
         هیرو
         ================================================================ -->
    <section class="hero" id="home">
        <span class="hero-blob hero-blob-1" aria-hidden="true"></span>
        <span class="hero-blob hero-blob-2" aria-hidden="true"></span>
        <div class="container hero-inner">

            <div class="hero-content">
                <span class="hero-badge"><?php echo shabaneh_icon('wifi', 16); ?><?php echo htmlspecialchars($shabanehHeroBadge, ENT_QUOTES); ?></span>

                <h1 class="hero-title"><?php echo $shabanehHeroTitleHtml; ?></h1>

                <p class="hero-subtitle"><?php echo nl2br(htmlspecialchars($shabanehHeroSubtitle, ENT_QUOTES)); ?></p>

                <div class="hero-actions">
                    <?php if (trim($shabanehHeroBtn1Text) !== ''): ?>
                    <a href="<?php echo htmlspecialchars(shabaneh_link_url($shabanehHeroBtn1Url), ENT_QUOTES); ?>" class="btn btn-primary btn-lg">
                        <?php echo shabaneh_icon('download', 18); ?>
                        <span><?php echo htmlspecialchars($shabanehHeroBtn1Text, ENT_QUOTES); ?></span>
                    </a>
                    <?php endif; ?>
                    <?php if (trim((string)$shabanehHeroBtn2Text) !== ''): ?>
                    <a href="<?php echo htmlspecialchars(shabaneh_link_url((string)$shabanehHeroBtn2Url), ENT_QUOTES); ?>" class="btn btn-ghost btn-lg">
                        <?php echo shabaneh_icon('badge-percent', 18); ?>
                        <span><?php echo htmlspecialchars((string)$shabanehHeroBtn2Text, ENT_QUOTES); ?></span>
                    </a>
                    <?php endif; ?>
                </div>

                <?php if (!empty($shabanehHeroStats)): ?>
                <div class="hero-stats">
                    <?php foreach ($shabanehHeroStats as $shabanehStat): ?>
                    <div class="hero-stat">
                        <?php echo shabaneh_icon('zap', 20); ?>
                        <div class="hero-stat-text">
                            <b><?php echo htmlspecialchars(toPersianNumbers($shabanehStat['num']), ENT_QUOTES); ?></b>
                            <span><?php echo htmlspecialchars($shabanehStat['label'], ENT_QUOTES); ?></span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- پنل وضعیت زندهٔ کافی‌نت -->
            <div class="hero-visual" aria-hidden="false">
                <div class="hb-board" id="heroBoard">
                    <div class="hb-head">
                        <span class="hb-dots" aria-hidden="true"><i></i><i></i><i></i></span>
                        <span class="hb-title"><?php echo htmlspecialchars(shabaneh_opt('shabanehCafeName', 'کافی‌نت شبانه'), ENT_QUOTES); ?></span>
                        <span class="hb-status <?php echo $shabanehIsOpen ? 'is-open' : 'is-closed'; ?>" id="hbStatus"
                              data-open="<?php echo $shabanehIsOpen ? '1' : '0'; ?>"
                              data-open-hour="<?php echo (int)shabaneh_hours()['open']; ?>" data-close-hour="<?php echo (int)shabaneh_hours()['close']; ?>">
                            <span class="hb-status-dot" aria-hidden="true"></span>
                            <span id="hbStatusText"><?php echo $shabanehOpenText; ?></span>
                        </span>
                    </div>

                    <div class="hb-body">
                        <div class="hb-photo">
                            <img src="<?php echo htmlspecialchars($shabanehHeroImage, ENT_QUOTES); ?>" alt="فضای داخلی <?php echo htmlspecialchars(shabaneh_opt('shabanehCafeName', 'کافی‌نت شبانه'), ENT_QUOTES); ?>" loading="eager">
                            <span class="hb-photo-grad" aria-hidden="true"></span>
                            <span class="hb-photo-chip">
                                <span>
                                    <b>پایداری اینترنت</b>
                                    <span>دو خط پشتیبان اختصاصی</span>
                                </span>
                                <span class="hb-chip-num" data-counter="<?php echo htmlspecialchars(toPersianNumbers($shabanehHeroUptime), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($shabanehHeroUptime), ENT_QUOTES); ?>٪</span>
                            </span>
                        </div>

                        <div class="hb-side">
                            <div class="hb-clock-card">
                                <span class="hb-clock-label">ساعت تهران</span>
                                <span class="hb-clock" id="hbClock"><?php echo $shabanehClock; ?></span>
                                <span class="hb-clock-date"><?php echo shabaneh_jalali_date(time(), 'l j F Y'); ?></span>
                            </div>
                            <div class="hb-today">
                                <span class="hb-today-title"><?php echo shabaneh_icon('zap', 13); ?> پرطرفدارترین خدمات</span>
                                <ul class="hb-today-list">
                                    <?php foreach ($shabanehTodayList as $shabanehSvc): ?>
                                    <li>
                                        <b><?php echo htmlspecialchars($shabanehSvc['title'], ENT_QUOTES); ?></b>
                                        <span class="hb-mini-badge">فعال</span>
                                    </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="hb-foot">
                        <?php echo shabaneh_icon('coffee', 22); ?>
                        <span class="hb-foot-text">
                            <b>ساعات کاری: <?php echo htmlspecialchars(toPersianNumbers(shabaneh_hours_label()), ENT_QUOTES); ?></b>
                            <span>وضعیت به وقت تهران، به‌صورت زنده محاسبه می‌شود</span>
                        </span>
                        <span class="hb-foot-num" id="hbFootStatus"><?php echo $shabanehIsOpen ? '●' : '○'; ?></span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ================================================================
         خدمات کافی‌نت
         ================================================================ -->
    <?php if (!empty($shabanehServices)): ?>
    <section class="services-section section" id="services">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo shabaneh_icon('coffee', 15); ?> خدمات شبانه</span>
                <h2 class="section-title"><?php echo htmlspecialchars(shabaneh_opt('shabanehServicesTitle', 'خدمات شبانه'), ENT_QUOTES); ?></h2>
                <p class="section-subtitle">هر کاری که اینترنت و کامپیوتر لازم دارد، همین‌جا انجام می‌شود</p>
            </div>
            <div class="services-grid">
                <?php foreach ($shabanehServices as $shabanehService): ?>
                <article class="service-card">
                    <span class="service-ic"><?php echo shabaneh_icon($shabanehService['icon'], 26); ?></span>
                    <h3 class="service-title"><?php echo htmlspecialchars($shabanehService['title'], ENT_QUOTES); ?></h3>
                    <p class="service-desc"><?php echo htmlspecialchars($shabanehService['desc'], ENT_QUOTES); ?></p>
                    <?php if ($shabanehService['foot'] !== ''): ?>
                    <span class="service-foot"><?php echo shabaneh_icon('check-circle', 14); ?><?php echo htmlspecialchars($shabanehService['foot'], ENT_QUOTES); ?></span>
                    <?php endif; ?>
                </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- ================================================================
         مقالات و دانلودها
         ================================================================ -->
    <?php if (!empty($shabanehDownloads)): ?>
    <section class="downloads-section section" id="downloads">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo shabaneh_icon('download', 15); ?> مرکز دانلود</span>
                <h2 class="section-title"><?php echo htmlspecialchars($shabanehDlTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($shabanehDlSubtitle, ENT_QUOTES); ?></p>
            </div>

            <div class="dl-grid">
                <?php foreach ($shabanehDownloads as $shabanehDl): ?>
                <?php $shabanehDlHas = $shabanehDl['download']['has']; ?>
                <article class="dl-card">
                    <a class="dl-media" href="<?php echo htmlspecialchars($shabanehDl['url'], ENT_QUOTES); ?>">
                        <img class="dl-img" src="<?php echo htmlspecialchars($shabanehDl['thumb'], ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($shabanehDl['title'], ENT_QUOTES); ?>" loading="lazy">
                        <?php if ($shabanehDlHas): ?>
                        <span class="dl-badge"><?php echo shabaneh_icon('file-down', 13); ?> <?php echo htmlspecialchars($shabanehDl['download']['format'], ENT_QUOTES); ?></span>
                        <span class="dl-access <?php echo $shabanehDl['download']['access'] === 'member' ? 'acc-member' : 'acc-all'; ?>">
                            <?php echo shabaneh_icon($shabanehDl['download']['access'] === 'member' ? 'lock' : 'unlock', 13); ?>
                            <?php echo shabaneh_access_label($shabanehDl['download']['access']); ?>
                        </span>
                        <?php else: ?>
                        <span class="dl-badge"><?php echo shabaneh_icon('file-text', 13); ?> مقاله</span>
                        <?php endif; ?>
                    </a>
                    <div class="dl-body">
                        <h3 class="dl-title"><a href="<?php echo htmlspecialchars($shabanehDl['url'], ENT_QUOTES); ?>"><?php echo shabaneh_fa_title((object)['title' => $shabanehDl['title']]); ?></a></h3>
                        <div class="dl-meta">
                            <span><?php echo shabaneh_icon('clock', 14); ?><?php echo htmlspecialchars(toPersianNumbers($shabanehDl['readingTime'] !== '' ? $shabanehDl['readingTime'] : '۵'), ENT_QUOTES); ?> دقیقه</span>
                            <?php if ($shabanehShowViews): ?>
                            <span><?php echo shabaneh_icon('eye', 14); ?><?php echo shabaneh_num($shabanehDl['views']); ?> بازدید</span>
                            <?php endif; ?>
                        </div>
                        <p class="dl-desc"><?php echo htmlspecialchars(mb_substr($shabanehDl['excerpt'], 0, 110, 'UTF-8') . (mb_strlen($shabanehDl['excerpt'], 'UTF-8') > 110 ? '…' : ''), ENT_QUOTES); ?></p>
                        <div class="dl-foot">
                            <?php if ($shabanehDlHas): ?>
                            <span class="dl-file">
                                <span class="dl-file-format"><?php echo shabaneh_icon('file-text', 14); ?> <?php echo htmlspecialchars($shabanehDl['download']['format'], ENT_QUOTES); ?></span>
                                <span class="dl-file-size"><?php echo shabaneh_icon('hdd', 13); ?> <?php echo htmlspecialchars(toPersianNumbers($shabanehDl['download']['size']), ENT_QUOTES); ?></span>
                            </span>
                            <a class="btn-dl" href="<?php echo htmlspecialchars($shabanehDl['url'], ENT_QUOTES); ?>">
                                <span><?php echo ($shabanehDl['download']['access'] === 'member' && !$shabanehLoggedIn) ? 'مشاهدهٔ فایل' : 'دانلود'; ?></span>
                                <?php echo shabaneh_icon('chevron-left', 15); ?>
                            </a>
                            <?php else: ?>
                            <span class="dl-file">
                                <span class="dl-file-format"><?php echo shabaneh_icon('clock', 14); ?> <?php echo htmlspecialchars(toPersianNumbers($shabanehDl['readingTime'] !== '' ? $shabanehDl['readingTime'] : '۵'), ENT_QUOTES); ?> دقیقه مطالعه</span>
                            </span>
                            <a class="btn-dl" href="<?php echo htmlspecialchars($shabanehDl['url'], ENT_QUOTES); ?>">
                                <span>مشاهدهٔ مقاله</span>
                                <?php echo shabaneh_icon('chevron-left', 15); ?>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>

            <div class="section-more">
                <a href="<?php echo htmlspecialchars(shabaneh_downloads_url(), ENT_QUOTES); ?>" class="btn btn-ghost">
                    <?php echo shabaneh_icon('file-text', 17); ?>
                    <span>همهٔ مقالات و فایل‌ها</span>
                </a>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- ================================================================
         تعرفهٔ خدمات
         ================================================================ -->
    <?php if (!empty($shabanehTariffRows)): ?>
    <section class="classes-section section" id="tariff">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo shabaneh_icon('badge-percent', 15); ?> شفاف و بی‌هزینهٔ پنهان</span>
                <h2 class="section-title"><?php echo htmlspecialchars(shabaneh_opt('shabanehTariffTitle', 'تعرفهٔ خدمات'), ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars(shabaneh_opt('shabanehTariffSubtitle', 'قیمت‌ها شفاف و اعلام‌شده؛ بدون هزینهٔ پنهان'), ENT_QUOTES); ?></p>
            </div>

            <div class="tariff-table" role="table" aria-label="تعرفهٔ خدمات">
                <div class="tariff-row tariff-head-row" role="row">
                    <span class="tf-cell tf-service"><?php echo shabaneh_icon('coffee', 14); ?> خدمت</span>
                    <span class="tf-cell tf-detail">جزئیات</span>
                    <span class="tf-cell tf-unit">واحد</span>
                    <span class="tf-cell tf-price">قیمت (تومان)</span>
                </div>
                <?php foreach ($shabanehTariffRows as $shabanehRow): ?>
                <div class="tariff-row" role="row">
                    <span class="tf-cell tf-service" role="cell">
                        <span class="tf-service-ic"><?php echo shabaneh_icon($shabanehRow['icon'], 19); ?></span>
                        <b><?php echo htmlspecialchars($shabanehRow['service'], ENT_QUOTES); ?></b>
                    </span>
                    <span class="tf-cell tf-detail" role="cell"><?php echo htmlspecialchars($shabanehRow['detail'], ENT_QUOTES); ?></span>
                    <span class="tf-cell tf-unit" role="cell"><?php echo htmlspecialchars($shabanehRow['unit'], ENT_QUOTES); ?></span>
                    <span class="tf-cell tf-price tf-price-row" role="cell"><?php echo htmlspecialchars(toPersianNumbers($shabanehRow['price']), ENT_QUOTES); ?></span>
                </div>
                <?php endforeach; ?>
            </div>

            <p class="tariff-note">
                <?php echo shabaneh_icon('info', 16); ?>
                <span><?php echo htmlspecialchars(shabaneh_opt('shabanehTariffNote', ''), ENT_QUOTES); ?></span>
            </p>
        </div>
    </section>
    <?php endif; ?>

    <!-- ================================================================
         چرا شبانه + نوار آمار
         ================================================================ -->
    <section class="about-section section" id="about">
        <div class="container about-inner">
            <div class="about-visual">
                <div class="about-img-frame">
                    <img class="about-img" src="<?php echo htmlspecialchars($shabanehAboutImage, ENT_QUOTES); ?>" alt="محیط <?php echo htmlspecialchars(shabaneh_opt('shabanehCafeName', 'کافی‌نت شبانه'), ENT_QUOTES); ?>" loading="lazy">
                </div>
                <?php if ($shabanehAboutBadge !== ''): ?>
                <span class="about-card"><?php echo shabaneh_icon('award', 18); ?> <?php echo htmlspecialchars(toPersianNumbers($shabanehAboutBadge), ENT_QUOTES); ?></span>
                <?php endif; ?>
            </div>

            <div class="about-content">
                <span class="section-tag"><?php echo shabaneh_icon('sparkles', 15); ?> چرا شبانه</span>
                <h2 class="section-title about-title"><?php echo htmlspecialchars($shabanehAboutTitle, ENT_QUOTES); ?></h2>
                <div class="about-text">
                    <?php foreach (preg_split('/\r\n|\r|\n/', (string)$shabanehAboutText) as $shabanehPara): if (trim($shabanehPara) !== ''): ?>
                    <p><?php echo htmlspecialchars(trim($shabanehPara), ENT_QUOTES); ?></p>
                    <?php endif; endforeach; ?>
                </div>

                <?php if (!empty($shabanehAboutFeatures)): ?>
                <div class="about-features">
                    <?php foreach ($shabanehAboutFeatures as $shabanehFeature): ?>
                    <div class="about-feature">
                        <span class="about-feature-ic"><?php echo shabaneh_icon($shabanehFeature['icon'], 19); ?></span>
                        <div>
                            <b><?php echo htmlspecialchars($shabanehFeature['title'], ENT_QUOTES); ?></b>
                            <span><?php echo htmlspecialchars($shabanehFeature['desc'], ENT_QUOTES); ?></span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- نوار «شبانه در یک نگاه» -->
    <?php if (!empty($shabanehGlance)): ?>
    <section class="stats-band-section section">
        <div class="container">
            <div class="stats-band">
                <?php foreach ($shabanehGlance as $shabanehG): ?>
                <div class="stat-box">
                    <span class="stat-icon"><?php echo shabaneh_icon($shabanehG['icon'], 26); ?></span>
                    <div>
                        <span class="stat-num" data-glance="<?php echo htmlspecialchars(toPersianNumbers($shabanehG['value']), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($shabanehG['value']), ENT_QUOTES); ?></span>
                        <span class="stat-label"><?php echo htmlspecialchars($shabanehG['label'], ENT_QUOTES); ?></span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- ================================================================
         نظرات مشتریان
         ================================================================ -->
    <?php if (!empty($shabanehTestimonials)): ?>
    <section class="testimonials-section section" id="testimonials">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo shabaneh_icon('heart', 15); ?> نظرات واقعی</span>
                <h2 class="section-title"><?php echo htmlspecialchars(shabaneh_opt('shabanehTestimonialsTitle', 'مشتریان شبانه چه می‌گویند'), ENT_QUOTES); ?></h2>
            </div>

            <div class="testimonials-carousel" id="testimonialsCarousel"<?php echo count($shabanehTestimonials) === 1 ? ' data-single="1"' : ''; ?>>
                <div class="t-stage">
                    <?php foreach ($shabanehTestimonials as $shabanehT): ?>
                    <figure class="testimonial-card">
                        <div class="testimonial-meta">
                            <span class="testimonial-role"><?php echo htmlspecialchars($shabanehT['meta'], ENT_QUOTES); ?></span>
                        </div>
                        <blockquote class="testimonial-text">
                            <?php echo shabaneh_icon('quote', 22); ?>
                            <p><?php echo htmlspecialchars($shabanehT['text'], ENT_QUOTES); ?></p>
                        </blockquote>
                        <figcaption class="testimonial-author">
                            <?php if ($shabanehT['photo'] !== ''): ?>
                                <img class="testimonial-photo" src="<?php echo htmlspecialchars($shabanehT['photo'], ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($shabanehT['name'], ENT_QUOTES); ?>" loading="lazy">
                            <?php else: ?>
                                <span class="testimonial-avatar" aria-hidden="true"><?php echo htmlspecialchars(shabaneh_initial($shabanehT['name']), ENT_QUOTES); ?></span>
                            <?php endif; ?>
                            <b><?php echo htmlspecialchars($shabanehT['name'], ENT_QUOTES); ?></b>
                        </figcaption>
                    </figure>
                    <?php endforeach; ?>
                </div>
                <div class="t-controls">
                    <button type="button" class="t-arrow t-prev" aria-label="نظر قبلی"><?php echo shabaneh_icon('chevron-right', 19); ?></button>
                    <div class="t-dots" aria-label="انتخاب نظر"></div>
                    <button type="button" class="t-arrow t-next" aria-label="نظر بعدی"><?php echo shabaneh_icon('chevron-left', 19); ?></button>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- ================================================================
         وبلاگ
         ================================================================ -->
    <?php if (!empty($shabanehBlogPosts)): ?>
    <section class="blog-section section" id="blog">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo shabaneh_icon('file-text', 15); ?> وبلاگ</span>
                <h2 class="section-title"><?php echo htmlspecialchars($shabanehBlogTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle">آموزش‌ها و ترفندهای کاربردی اینترنت و کامپیوتر</p>
            </div>
            <div class="blog-grid">
                <?php foreach ($shabanehBlogPosts as $shabanehPost): ?>
                <article class="blog-card">
                    <a class="blog-card-thumb" href="<?php echo htmlspecialchars($shabanehPost['url'], ENT_QUOTES); ?>">
                        <img src="<?php echo htmlspecialchars($shabanehPost['thumb'], ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($shabanehPost['title'], ENT_QUOTES); ?>" loading="lazy">
                    </a>
                    <div class="blog-card-body">
                        <div class="blog-card-meta">
                            <span><?php echo shabaneh_icon('calendar', 14); ?> <?php echo shabaneh_jalali_date($shabanehPost['created'], 'j F Y'); ?></span>
                            <?php if ($shabanehShowViews): ?>
                            <span><?php echo shabaneh_icon('eye', 14); ?> <?php echo shabaneh_num($shabanehPost['views']); ?></span>
                            <?php endif; ?>
                        </div>
                        <h3 class="blog-card-title"><a href="<?php echo htmlspecialchars($shabanehPost['url'], ENT_QUOTES); ?>"><?php echo shabaneh_fa_title((object)['title' => $shabanehPost['title']]); ?></a></h3>
                        <p class="blog-card-excerpt"><?php echo htmlspecialchars(mb_substr($shabanehPost['excerpt'], 0, 95, 'UTF-8') . (mb_strlen($shabanehPost['excerpt'], 'UTF-8') > 95 ? '…' : ''), ENT_QUOTES); ?></p>
                        <a class="blog-card-more" href="<?php echo htmlspecialchars($shabanehPost['url'], ENT_QUOTES); ?>">ادامهٔ مطلب <?php echo shabaneh_icon('arrow-left', 15); ?></a>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
            <div class="section-more">
                <a href="<?php echo htmlspecialchars(shabaneh_blog_url(), ENT_QUOTES); ?>" class="btn btn-ghost">
                    <?php echo shabaneh_icon('file-text', 17); ?>
                    <span>همهٔ نوشته‌ها</span>
                </a>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- ================================================================
         پرسش‌های متداول
         ================================================================ -->
    <?php if (!empty($shabanehFaqRows)): ?>
    <section class="faq-section section" id="faq">
        <div class="container faq-inner">
            <div class="section-head">
                <span class="section-tag"><?php echo shabaneh_icon('info', 15); ?> راهنما</span>
                <h2 class="section-title"><?php echo htmlspecialchars(shabaneh_opt('shabanehFaqTitle', 'پرسش‌های متداول'), ENT_QUOTES); ?></h2>
            </div>
            <div class="faq-list">
                <?php foreach ($shabanehFaqRows as $shabanehI => $shabanehFaq): ?>
                <details class="faq-item<?php echo $shabanehI === 0 ? ' open-default' : ''; ?>" <?php echo $shabanehI === 0 ? 'open' : ''; ?>>
                    <summary class="faq-q">
                        <?php echo shabaneh_icon('message-square', 17); ?>
                        <span><?php echo htmlspecialchars($shabanehFaq['q'], ENT_QUOTES); ?></span>
                        <span class="faq-chevron"><?php echo shabaneh_icon('chevron-down', 17); ?></span>
                    </summary>
                    <div class="faq-a"><?php echo nl2br(htmlspecialchars($shabanehFaq['a'], ENT_QUOTES)); ?></div>
                </details>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- ================================================================
         تماس و نقشه
         ================================================================ -->
    <section class="contact-section section" id="contact">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo shabaneh_icon('map-pin', 15); ?> ما را پیدا کنید</span>
                <h2 class="section-title">تماس با <?php echo htmlspecialchars(shabaneh_opt('shabanehCafeName', 'کافی‌نت شبانه'), ENT_QUOTES); ?></h2>
                <p class="section-subtitle">حضوری، تلفنی یا آنلاین — در خدمت شما هستیم</p>
            </div>

            <div class="contact-grid">
                <!-- ستون نقشه -->
                <div class="contact-map">
                    <?php if ($shabanehMapEmbed !== ''): ?>
                        <?php echo $shabanehMapEmbed; ?>
                    <?php else: ?>
                    <div class="map-fallback" role="img" aria-label="نقشهٔ مسیر">
                        <?php echo shabaneh_icon('map-pin', 44); ?>
                        <span><?php echo htmlspecialchars(toPersianNumbers((string)$shabanehAddress), ENT_QUOTES); ?></span>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- ستون اطلاعات تماس -->
                <div class="contact-info">
                    <ul class="contact-list">
                        <?php if ($shabanehAddress !== null && trim($shabanehAddress) !== ''): ?>
                        <li>
                            <span class="contact-ic"><?php echo shabaneh_icon('map-pin', 19); ?></span>
                            <div class="contact-text">
                                <b>نشانی</b>
                                <span><?php echo htmlspecialchars(toPersianNumbers($shabanehAddress), ENT_QUOTES); ?></span>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php if ($shabanehPhone !== null && trim($shabanehPhone) !== ''): ?>
                        <li>
                            <span class="contact-ic"><?php echo shabaneh_icon('phone-call', 19); ?></span>
                            <div class="contact-text">
                                <b>تلفن</b>
                                <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $shabanehPhone), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($shabanehPhone), ENT_QUOTES); ?></a>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php if ($shabanehEmail !== null && trim($shabanehEmail) !== ''): ?>
                        <li>
                            <span class="contact-ic"><?php echo shabaneh_icon('mail', 19); ?></span>
                            <div class="contact-text">
                                <b>ایمیل</b>
                                <a href="mailto:<?php echo htmlspecialchars($shabanehEmail, ENT_QUOTES); ?>"><?php echo htmlspecialchars($shabanehEmail, ENT_QUOTES); ?></a>
                            </div>
                        </li>
                        <?php endif; ?>
                        <li>
                            <span class="contact-ic"><?php echo shabaneh_icon('clock', 19); ?></span>
                            <div class="contact-text">
                                <b>ساعات کاری</b>
                                <span><?php echo htmlspecialchars(toPersianNumbers(shabaneh_hours_label()), ENT_QUOTES); ?> — <span class="open-status-inline <?php echo $shabanehIsOpen ? 'is-open' : 'is-closed'; ?>"><?php echo $shabanehOpenText; ?></span></span>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

<?php

/* ================================================================
 *  سایر صفحات: فهرست وبلاگ
 * ================================================================ */
else:
    $shabanehPageHead = 'مقالات';
    try {
        $shabanehArchiveType = (string)$this->getArchiveType();
        if ($shabanehArchiveType === 'category') {
            $shabanehPageHead = 'دسته: ' . $this->getArchiveSlug();
        } elseif ($shabanehArchiveType === 'search') {
            $shabanehPageHead = 'نتیجهٔ جستجو';
        }
    } catch (\Throwable $e) {
    }
    // واژهٔ جستجوی جاری (برای پر کردن فیلد جستجو)
    $shabanehSearchQ = '';
    try {
        $shabanehSearchQ = (string)($this->request->keywords ?? $this->request->s ?? '');
    } catch (\Throwable $e) {
    }
?>

    <div class="container archive-wrap">
        <header class="page-head">
            <h1 class="page-title"><?php echo shabaneh_icon('file-text', 26); ?> <?php echo htmlspecialchars($shabanehPageHead, ENT_QUOTES); ?></h1>
            <?php if ($this->getDescription()): ?>
            <p class="archive-desc"><?php $this->description(); ?></p>
            <?php endif; ?>
        </header>

        <?php shabaneh_search_form($shabanehSearchQ); ?>

        <?php if ($this->have()): ?>
        <div class="archive-grid">
            <?php while ($this->next()): ?>
            <article class="blog-card<?php echo shabaneh_has_download($this) ? ' has-dl' : ''; ?>">
                <a class="blog-card-thumb" href="<?php $this->permalink(); ?>">
                    <?php $shabanehCover = shabaneh_thumbnail($this); if ($shabanehCover !== ''): ?>
                    <img src="<?php echo htmlspecialchars($shabanehCover, ENT_QUOTES); ?>" alt="<?php echo shabaneh_fa_title($this); ?>" loading="lazy">
                    <?php endif; ?>
                    <?php if (shabaneh_has_download($this)): ?>
                    <?php $shabanehDlMini = shabaneh_download_data($this); ?>
                    <span class="dl-badge"><?php echo shabaneh_icon('file-down', 13); ?> <?php echo htmlspecialchars($shabanehDlMini['format'], ENT_QUOTES); ?></span>
                    <span class="dl-access <?php echo $shabanehDlMini['access'] === 'member' ? 'acc-member' : 'acc-all'; ?>">
                        <?php echo shabaneh_icon($shabanehDlMini['access'] === 'member' ? 'lock' : 'unlock', 13); ?>
                        <?php echo shabaneh_access_label($shabanehDlMini['access']); ?>
                    </span>
                    <?php endif; ?>
                </a>
                <div class="blog-card-body">
                    <div class="blog-card-meta">
                        <span><?php echo shabaneh_icon('calendar', 14); ?> <?php echo shabaneh_post_date($this, 'j F Y'); ?></span>
                        <?php if (shabaneh_opt('shabanehShowViews', '1') === '1'): ?>
                        <span><?php echo shabaneh_icon('eye', 14); ?> <?php echo shabaneh_num(shabaneh_views($this)); ?></span>
                        <?php endif; ?>
                    </div>
                    <h2 class="blog-card-title"><a href="<?php $this->permalink(); ?>"><?php echo shabaneh_fa_title($this); ?></a></h2>
                    <?php $shabanehExcerpt = trim(strip_tags((string)$this->excerpt)); ?>
                    <p class="blog-card-excerpt"><?php echo htmlspecialchars(mb_substr($shabanehExcerpt, 0, 95, 'UTF-8') . (mb_strlen($shabanehExcerpt, 'UTF-8') > 95 ? '…' : ''), ENT_QUOTES); ?></p>
                    <a class="blog-card-more" href="<?php $this->permalink(); ?>"><?php echo shabaneh_has_download($this) ? 'مشاهده و دانلود' : 'ادامهٔ مطلب'; ?> <?php echo shabaneh_icon('arrow-left', 15); ?></a>
                </div>
            </article>
            <?php endwhile; ?>
        </div>

        <?php shabaneh_page_nav($this); ?>

        <?php else: ?>
        <div class="archive-empty">
            <?php echo shabaneh_icon('search', 40); ?>
            <p>هنوز نوشته‌ای منتشر نشده است.</p>
            <a class="btn btn-primary" href="<?php $this->options->siteUrl(); ?>">بازگشت به خانه</a>
        </div>
        <?php endif; ?>
    </div>

<?php endif; ?>

<?php $this->need('footer.php'); ?>
