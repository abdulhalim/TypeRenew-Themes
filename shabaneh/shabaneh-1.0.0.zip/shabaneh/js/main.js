/**
 * شبانه — اسکریپت اصلی پوسته
 * نسخهٔ ۱.۰.۰
 */
(function () {
    'use strict';

    function faNum(str) {
        var map = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return String(str).replace(/[0-9]/g, function (d) { return map[+d]; });
    }

    function enNum(str) {
        return String(str)
            .replace(/[۰-۹]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); })
            .replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); });
    }

    var reduceMotion = false;
    try {
        reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    } catch (e) {}

    /* ================================================================
     *  منوی موبایل
     * ================================================================ */
    var menu = document.getElementById('mobileMenu');
    var overlay = document.getElementById('menuOverlay');
    var toggle = document.getElementById('menuToggle');
    var closeBtn = document.getElementById('menuClose');

    function openMenu() {
        if (!menu) { return; }
        menu.classList.add('is-open');
        if (overlay) { overlay.classList.add('is-visible'); }
        menu.setAttribute('aria-hidden', 'false');
        if (toggle) { toggle.setAttribute('aria-expanded', 'true'); }
        document.body.style.overflow = 'hidden';
    }

    function closeMenu() {
        if (!menu) { return; }
        menu.classList.remove('is-open');
        if (overlay) { overlay.classList.remove('is-visible'); }
        menu.setAttribute('aria-hidden', 'true');
        if (toggle) { toggle.setAttribute('aria-expanded', 'false'); }
        document.body.style.overflow = '';
    }

    if (toggle) { toggle.addEventListener('click', openMenu); }
    if (closeBtn) { closeBtn.addEventListener('click', closeMenu); }
    if (overlay) { overlay.addEventListener('click', closeMenu); }

    document.querySelectorAll('.mobile-nav a[data-close]').forEach(function (link) {
        link.addEventListener('click', closeMenu);
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') { closeMenu(); }
    });

    /* ================================================================
     *  هدر چسبان و دکمهٔ بازگشت به بالا
     * ================================================================ */
    var header = document.getElementById('siteHeader');
    var backToTop = document.getElementById('backToTop');

    function onScroll() {
        var y = window.pageYOffset || document.documentElement.scrollTop || 0;
        if (header) {
            if (y > 8) { header.classList.add('is-scrolled'); }
            else { header.classList.remove('is-scrolled'); }
        }
        if (backToTop) {
            if (y > 480) { backToTop.classList.add('is-visible'); }
            else { backToTop.classList.remove('is-visible'); }
        }
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    if (backToTop) {
        backToTop.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    /* ================================================================
     *  پرسش‌های متداول — آکاردئون تک‌بازشو
     * ================================================================ */
    (function initFaqAccordion() {
        var items = document.querySelectorAll('.faq-list details');
        if (!items.length) { return; }
        items.forEach(function (item) {
            item.addEventListener('toggle', function () {
                if (item.open) {
                    items.forEach(function (other) {
                        if (other !== item) { other.open = false; }
                    });
                }
            });
        });
    })();

    /* ================================================================
     *  آواتار: یا گراواتار واقعی یا آواتار الفبایی — نه هر دو
     * ================================================================ */
    (function initAvatars() {
        function sync(box) {
            if (!box) { return; }
            var img = box.querySelector('img');
            if (!img) { return; }
            function showImg() { box.classList.add('has-img'); }
            function hideImg() { img.classList.add('is-hidden'); }
            if (img.complete) {
                if (img.naturalWidth > 0) { showImg(); } else { hideImg(); }
                return;
            }
            img.addEventListener('load', showImg);
            img.addEventListener('error', hideImg);
        }
        document.querySelectorAll('.comment-avatar, .author-avatar').forEach(sync);
    })();

    /* ================================================================
     *  پنل زندهٔ هیرو: ساعت تهران + وضعیت باز/بستهٔ کافی‌نت
     *  (ساعت با Intl و منطقهٔ Asia/Tehran — مستقل از ساعت دستگاه کاربر)
     * ================================================================ */
    (function initLivePanel() {
        var clockEl = document.getElementById('hbClock');
        var statusEl = document.getElementById('hbStatus');
        var statusTextEl = document.getElementById('hbStatusText');
        var footStatusEl = document.getElementById('hbFootStatus');

        // ---------- ساعت زندهٔ تهران ----------
        var tehranTime = null;
        try {
            tehranTime = new Intl.DateTimeFormat('en-GB', {
                timeZone: 'Asia/Tehran',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
            });
        } catch (e) {}

        var tehranParts = null;
        try {
            tehranParts = new Intl.DateTimeFormat('en-US', {
                timeZone: 'Asia/Tehran',
                hour: 'numeric', minute: 'numeric', hour12: false
            });
        } catch (e) {}

        function updateClock() {
            if (!clockEl || !tehranTime) { return; }
            var now = new Date();
            var hhmm = tehranTime.format(now).replace(/^24:/, '00:');
            clockEl.textContent = faNum(hhmm);
        }

        if (clockEl && tehranTime) {
            updateClock();
            window.setInterval(updateClock, 1000);
        }

        // ---------- وضعیت باز/بسته (هر ۳۰ ثانیه بازبینی) ----------
        var openHour = statusEl ? parseInt(enNum(statusEl.getAttribute('data-open-hour') || ''), 10) : NaN;
        var closeHour = statusEl ? parseInt(enNum(statusEl.getAttribute('data-close-hour') || ''), 10) : NaN;
        var wasOpen = statusEl ? statusEl.getAttribute('data-open') === '1' : null;

        function isOpenNow() {
            if (isNaN(openHour) || isNaN(closeHour)) { return wasOpen; }
            if (openHour === 0 && closeHour >= 24) { return true; } // شبانه‌روزی
            if (!tehranParts) { return wasOpen; }
            var parts = tehranParts.formatToParts(new Date());
            var h = 0, m = 0;
            parts.forEach(function (p) {
                if (p.type === 'hour') { h = parseInt(p.value, 10) || 0; }
                if (p.type === 'minute') { m = parseInt(p.value, 10) || 0; }
            });
            if (h === 24) { h = 0; }
            var cur = h + (m >= 30 ? 0.5 : 0);
            return (cur >= openHour && cur < closeHour);
        }

        function updateStatus() {
            if (!statusEl) { return; }
            var open = isOpenNow();
            if (open === wasOpen) { return; }
            wasOpen = open;
            statusEl.classList.toggle('is-open', open);
            statusEl.classList.toggle('is-closed', !open);
            if (statusTextEl) {
                statusTextEl.textContent = open ? 'اکنون باز است' : 'اکنون بسته است';
            }
            if (footStatusEl) {
                footStatusEl.textContent = open ? '●' : '○';
            }
            document.querySelectorAll('.open-status-inline').forEach(function (el) {
                el.classList.toggle('is-open', open);
                el.classList.toggle('is-closed', !open);
                el.textContent = open ? 'اکنون باز است' : 'اکنون بسته است';
            });
        }

        if (statusEl) {
            window.setInterval(updateStatus, 30000);
        }
    })();

    /* ================================================================
     *  شمارندهٔ انیمیشنی «پایداری اینترنت» (چیپ هیرو)
     * ================================================================ */
    (function initUptimeCounter() {
        var el = document.querySelector('.hb-chip-num[data-counter]');
        if (!el) { return; }
        var raw = enNum(el.getAttribute('data-counter') || '').trim();
        var target = parseFloat(raw);
        if (isNaN(target) || target <= 0 || reduceMotion) { return; }
        var duration = 1500;
        var start = null;
        function frame(ts) {
            if (!start) { start = ts; }
            var p = Math.min((ts - start) / duration, 1);
            var eased = 1 - Math.pow(1 - p, 3);
            var val = target * eased;
            el.textContent = faNum(val.toFixed(1)) + '٪';
            if (p < 1) { window.requestAnimationFrame(frame); }
        }
        window.setTimeout(function () {
            window.requestAnimationFrame(frame);
        }, 650);
    })();

    /* ================================================================
     *  تیلت سه‌بعدی پنل هیرو با ماوس (فقط پوینتر دقیق)
     * ================================================================ */
    (function initHeroTilt() {
        var board = document.getElementById('heroBoard');
        if (!board || reduceMotion) { return; }
        var fine = false;
        try {
            fine = window.matchMedia('(pointer: fine)').matches;
        } catch (e) {}
        if (!fine) { return; }

        var raf = null;
        var curX = 0, curY = 0, tgtX = 0, tgtY = 0;

        function loop() {
            curX += (tgtX - curX) * 0.12;
            curY += (tgtY - curY) * 0.12;
            board.style.transform = 'rotateX(' + curX.toFixed(2) + 'deg) rotateY(' + curY.toFixed(2) + 'deg)';
            if (Math.abs(curX - tgtX) > 0.02 || Math.abs(curY - tgtY) > 0.02) {
                raf = window.requestAnimationFrame(loop);
            } else {
                raf = null;
            }
        }

        board.addEventListener('mousemove', function (e) {
            var rect = board.getBoundingClientRect();
            var px = (e.clientX - rect.left) / rect.width - 0.5;
            var py = (e.clientY - rect.top) / rect.height - 0.5;
            tgtX = (-py * 4.5);
            tgtY = (px * 5.5);
            if (!raf) { raf = window.requestAnimationFrame(loop); }
        });

        board.addEventListener('mouseleave', function () {
            tgtX = 0;
            tgtY = 0;
            if (!raf) { raf = window.requestAnimationFrame(loop); }
        });
    })();

    /* ================================================================
     *  نظرات مشتریان — کاروسل خودگردان تک‌کارت
     * ================================================================ */
    (function initTestimonials() {
        var carousel = document.getElementById('testimonialsCarousel');
        if (!carousel) { return; }
        var cards = Array.prototype.slice.call(carousel.querySelectorAll('.testimonial-card'));
        if (!cards.length) { return; }
        if (cards.length === 1) {
            cards[0].classList.add('is-active');
            carousel.classList.add('is-single');
            var c = carousel.querySelector('.t-controls');
            if (c) { c.style.display = 'none'; }
            return;
        }

        var dotsWrap = carousel.querySelector('.t-dots');
        var current = 0;
        var timer = null;
        var interval = 6500;
        var dots = [];

        cards.forEach(function (card, i) {
            card.setAttribute('data-index', String(i));
        });

        if (dotsWrap) {
            cards.forEach(function (card, i) {
                var dot = document.createElement('button');
                dot.type = 'button';
                dot.className = 't-dot' + (i === 0 ? ' is-active' : '');
                dot.setAttribute('aria-label', 'نظر ' + faNum(i + 1));
                dot.addEventListener('click', function () {
                    goTo(i);
                    restart();
                });
                dotsWrap.appendChild(dot);
                dots.push(dot);
            });
        }

        goTo(0);

        function goTo(index) {
            current = (index + cards.length) % cards.length;
            cards.forEach(function (card, i) {
                card.classList.toggle('is-active', i === current);
                card.setAttribute('aria-hidden', i === current ? 'false' : 'true');
            });
            dots.forEach(function (dot, i) {
                dot.classList.toggle('is-active', i === current);
            });
        }

        function next() { goTo(current + 1); }
        function prev() { goTo(current - 1); }
        function start() {
            stop();
            timer = window.setInterval(next, interval);
        }
        function stop() {
            if (timer) {
                window.clearInterval(timer);
                timer = null;
            }
        }
        function restart() {
            stop();
            start();
        }

        var nextBtn = carousel.querySelector('.t-next');
        var prevBtn = carousel.querySelector('.t-prev');
        if (nextBtn) { nextBtn.addEventListener('click', function () { next(); restart(); }); }
        if (prevBtn) { prevBtn.addEventListener('click', function () { prev(); restart(); }); }

        carousel.addEventListener('mouseenter', stop);
        carousel.addEventListener('mouseleave', start);

        // پشتیبانی لمسی ساده
        var touchX = null;
        carousel.addEventListener('touchstart', function (e) {
            touchX = e.touches[0].clientX;
            stop();
        }, { passive: true });
        carousel.addEventListener('touchend', function (e) {
            if (touchX === null) { return; }
            var dx = e.changedTouches[0].clientX - touchX;
            if (Math.abs(dx) > 40) {
                if (dx > 0) { next(); } else { prev(); }
            }
            touchX = null;
            start();
        }, { passive: true });

        start();
    })();
})();
