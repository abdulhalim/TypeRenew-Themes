<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="<?php $this->options->charset(); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php if ($this->options->favicon): ?>
    <link rel="icon" href="<?php $this->options->favicon(); ?>">
<?php endif; ?>
<title><?php $this->archiveTitle([
            'category' => _t('دستهٔ %s'),
            'search'   => _t('نتایج جستجوی %s'),
            'tag'      => _t('برچسب %s'),
            'author'   => _t('نوشته‌های %s')
        ], '', ' - '); ?><?php $this->options->title(); ?></title>
<?php
// ---------- توضیحات متا (فقط صفحهٔ اول) ----------
$shabanehMetaDesc = '';
try {
    if (shabaneh_is_front()) {
        $shabanehMetaDesc = trim((string)shabaneh_opt_raw('shabanehHeroSubtitle'));
        $shabanehMetaDesc = $shabanehMetaDesc !== '' ? trim(preg_replace('/\s+/', ' ', strip_tags(str_replace("\n", ' ', $shabanehMetaDesc)))) : '';
        if (mb_strlen($shabanehMetaDesc) > 160) {
            $shabanehMetaDesc = mb_substr($shabanehMetaDesc, 0, 157, 'UTF-8') . '...';
        }
    }
} catch (\Throwable $e) {
}
if ($shabanehMetaDesc !== ''):
?>
<meta name="description" content="<?php echo htmlspecialchars($shabanehMetaDesc, ENT_QUOTES); ?>">
<?php endif; ?>
<?php $this->header(); ?>

<?php
// ---------- رنگ‌های داینامیک ----------
$shabanehPrimary   = shabaneh_opt('shabanehPrimaryColor', '#f59e0b');
$shabanehSecondary = shabaneh_opt('shabanehSecondaryColor', '#92400e');
if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $shabanehPrimary)) { $shabanehPrimary = '#f59e0b'; }
if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $shabanehSecondary)) { $shabanehSecondary = '#92400e'; }
?>

<style>:root{--primary:<?php echo $shabanehPrimary; ?>;--secondary:<?php echo $shabanehSecondary; ?>;}</style>

<!-- ---------- استایل‌های اصلی (با نسخه برای جلوگیری از کش) ---------- -->
<link rel="stylesheet" href="<?php $this->options->themeUrl('css/style.css'); ?>?v=1.0.3">
<link rel="stylesheet" href="<?php $this->options->themeUrl('css/fonts.css'); ?>?v=1.0.3">
</head>
<body class="shabaneh-body farsi-digits">
<a href="#main" class="skip-link">رفتن به محتوای اصلی</a>

<?php
// ---------- داده‌های مشترک ----------
$shabanehCafeName   = shabaneh_opt('shabanehCafeName', (string)$this->options->title);
$shabanehTagline    = shabaneh_opt('shabanehTagline', 'مرکز خدمات اینترنتی و دانلود');
$shabanehLogoUrl    = shabaneh_logo_url();
$shabanehPhone      = shabaneh_opt_raw('shabanehPhone');
$shabanehShowTopbar = shabaneh_opt('shabanehShowTopbar', '1') === '1';
$shabanehOnHome     = shabaneh_is_front();
$shabanehBlogUrl    = shabaneh_blog_url();
$shabanehIsBlogPage = in_array(shabaneh_route(), ['archive', 'archive_page', 'index_page'], true);

// دستهٔ مقالات دانلودی (اگر در تنظیمات انتخاب شده باشد)
$shabanehDlCat = shabaneh_download_category();
$shabanehDlNavUrl = ($shabanehDlCat !== null)
    ? $shabanehDlCat['url']
    : shabaneh_link_url('#downloads', $shabanehOnHome);
$shabanehSocial = [
    'instagram' => shabaneh_opt_raw('shabanehInstagram'),
    'telegram'  => shabaneh_opt_raw('shabanehTelegram'),
];
$shabanehHoursLine  = shabaneh_hours_label();

// ---------- وضعیت کاربر (برای دانلودهای ویژهٔ اعضا) ----------
$shabanehUser = null;
$shabanehLoggedIn = false;
try {
    $shabanehUser = \Widget\User::alloc();
    $shabanehLoggedIn = (bool)$shabanehUser->hasLogin();
} catch (\Throwable $e) {
}
$shabanehLoginUrl  = shabaneh_login_url();
$shabanehLogoutUrl = '';
$shabanehUserName = '';
try {
    $shabanehLogoutUrl = (string)$this->options->logoutUrl;
} catch (\Throwable $e) {
}
if ($shabanehLoggedIn && $shabanehUser) {
    try {
        $shabanehUserName = (string)$shabanehUser->screenName;
    } catch (\Throwable $e) {
    }
}
?>

<!-- ---------- نوار بالای هدر ---------- -->
<?php if ($shabanehShowTopbar): ?>
<div class="topbar">
    <div class="container topbar-inner">
        <div class="topbar-item topbar-phone">
            <?php echo shabaneh_icon('phone', 15); ?>
            <?php if ($shabanehPhone !== null && trim($shabanehPhone) !== ''): ?>
                <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $shabanehPhone), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($shabanehPhone), ENT_QUOTES); ?></a>
            <?php endif; ?>
        </div>
        <?php if ($shabanehHoursLine !== ''): ?>
        <div class="topbar-item topbar-hours">
            <?php echo shabaneh_icon('clock', 15); ?>
            <span><?php echo htmlspecialchars(toPersianNumbers($shabanehHoursLine), ENT_QUOTES); ?></span>
        </div>
        <?php endif; ?>
        <div class="topbar-social">
            <?php foreach ($shabanehSocial as $shabanehNet => $shabanehUrl): if (trim((string)$shabanehUrl) !== ''): ?>
                <a href="<?php echo htmlspecialchars('https://' . $shabanehNet . '.com/' . ltrim(trim((string)$shabanehUrl), '@'), ENT_QUOTES); ?>" target="_blank" rel="noopener" aria-label="<?php echo ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام'][$shabanehNet]; ?>">
                    <?php echo shabaneh_icon($shabanehNet === 'telegram' ? 'send' : $shabanehNet, 15); ?>
                </a>
            <?php endif; endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ---------- هدر اصلی ---------- -->
<header class="site-header<?php echo $shabanehShowTopbar ? '' : ' no-topbar'; ?>" id="siteHeader">
    <div class="container nav-container">

        <!-- بخش راست: لوگو -->
        <div class="nav-logo">
            <a href="<?php $this->options->siteUrl(); ?>" class="logo-link">
                <?php if ($shabanehLogoUrl !== ''): ?>
                    <img src="<?php echo htmlspecialchars($shabanehLogoUrl, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($shabanehCafeName, ENT_QUOTES); ?>" class="logo-img">
                <?php else: ?>
                    <span class="logo-mark" aria-hidden="true"><?php echo shabaneh_icon('coffee', 22); ?></span>
                <?php endif; ?>
                <span class="logo-text">
                    <span class="logo-main"><?php echo htmlspecialchars($shabanehCafeName, ENT_QUOTES); ?></span>
                    <span class="logo-sub"><?php echo htmlspecialchars($shabanehTagline, ENT_QUOTES); ?></span>
                </span>
            </a>
        </div>

        <!-- بخش وسط: منوی اصلی -->
        <nav class="main-nav" aria-label="منوی اصلی">
            <ul class="nav-links">
                <li><a href="<?php $this->options->siteUrl(); ?>" <?php if ($shabanehOnHome): ?>class="active" aria-current="page"<?php endif; ?>><?php echo shabaneh_icon('home', 15); ?> خانه</a></li>
                <li><a href="<?php echo htmlspecialchars(shabaneh_link_url('#services', $shabanehOnHome), ENT_QUOTES); ?>"><?php echo shabaneh_icon('coffee', 15); ?> خدمات</a></li>
                <li><a href="<?php echo htmlspecialchars($shabanehDlNavUrl, ENT_QUOTES); ?>" <?php if ($shabanehDlCat !== null && $this->is('category', $shabanehDlCat['slug'])): ?>class="active" aria-current="page"<?php endif; ?>><?php echo shabaneh_icon('download', 15); ?> دانلودها</a></li>
                <li><a href="<?php echo htmlspecialchars(shabaneh_link_url('#tariff', $shabanehOnHome), ENT_QUOTES); ?>"><?php echo shabaneh_icon('badge-percent', 15); ?> تعرفه‌ها</a></li>
                <li><a href="<?php echo htmlspecialchars($shabanehOnHome ? '#blog' : $shabanehBlogUrl, ENT_QUOTES); ?>" <?php if (!$shabanehOnHome && ($shabanehIsBlogPage || $this->is('archive') || $this->is('post'))): ?>class="active" aria-current="page"<?php endif; ?>><?php echo shabaneh_icon('file-text', 15); ?> مقالات</a></li>
                <?php
                // ---------- برگه‌های منو ----------
                $shabanehNavPages = \Widget\Contents\Page\Rows::alloc();
                $shabanehNavCount = 0;
                while ($shabanehNavPages->next()):
                    $shabanehNavCount++;
                    if ($shabanehNavCount > 2) { break; } // حداکثر ۲ برگه در منو
                ?>
                    <li><a href="<?php $shabanehNavPages->permalink(); ?>" <?php if ($this->is('page', $shabanehNavPages->slug)): ?>class="active" aria-current="page"<?php endif; ?>><?php echo shabaneh_icon('file-text', 15); ?> <?php echo shabaneh_fa_title($shabanehNavPages); ?></a></li>
                <?php endwhile; ?>
                <li><a href="<?php echo htmlspecialchars(shabaneh_link_url('#contact', $shabanehOnHome), ENT_QUOTES); ?>"><?php echo shabaneh_icon('phone', 15); ?> تماس</a></li>
            </ul>
        </nav>

        <!-- بخش چپ: ورود اعضا + دکمهٔ CTA -->
        <div class="nav-actions">
            <?php if ($shabanehLoggedIn): ?>
                <?php if ($shabanehLogoutUrl !== ''): ?>
                <a href="<?php echo htmlspecialchars($shabanehLogoutUrl, ENT_QUOTES); ?>" class="nav-user-btn is-in" title="خروج از حساب">
                    <?php echo shabaneh_icon('user', 16); ?>
                    <span><?php echo htmlspecialchars($shabanehUserName !== '' ? $shabanehUserName : 'حساب من', ENT_QUOTES); ?></span>
                    <?php echo shabaneh_icon('log-in', 13); ?>
                </a>
                <?php endif; ?>
            <?php else: ?>
                <a href="<?php echo htmlspecialchars($shabanehLoginUrl, ENT_QUOTES); ?>" class="nav-user-btn">
                    <?php echo shabaneh_icon('log-in', 16); ?>
                    <span>ورود / ثبت‌نام</span>
                </a>
            <?php endif; ?>
            <?php
            $shabanehCtaText = shabaneh_opt('shabanehHeroBtn1Text', 'دانلود مقالات');
            $shabanehCtaUrl  = shabaneh_opt('shabanehHeroBtn1Url', '#downloads');
            // اتصال داینامیک: اگر «دستهٔ مقالات دانلودی» انتخاب شده باشد و آدرس
            // دکمه روی حالت پیش‌فرض باشد، دکمه به صفحهٔ همان دسته لینک می‌شود.
            if ($shabanehDlCat !== null && in_array(trim((string)$shabanehCtaUrl), ['', '#downloads'], true)) {
                $shabanehCtaUrl = $shabanehDlCat['url'];
            }
            if (trim($shabanehCtaText) !== '' && trim((string)$shabanehCtaUrl) !== ''):
            ?>
            <a href="<?php echo htmlspecialchars(shabaneh_link_url($shabanehCtaUrl, $shabanehOnHome), ENT_QUOTES); ?>" class="nav-cta">
                <?php echo shabaneh_icon('download', 16); ?>
                <span><?php echo htmlspecialchars($shabanehCtaText, ENT_QUOTES); ?></span>
            </a>
            <?php endif; ?>
            <button type="button" class="menu-toggle" id="menuToggle" aria-label="باز کردن منو" aria-expanded="false" aria-controls="mobileMenu">
                <?php echo shabaneh_icon('menu', 22); ?>
            </button>
        </div>
    </div>
</header>

<!-- ---------- منوی موبایل ---------- -->
<div class="mobile-menu" id="mobileMenu" aria-hidden="true">
    <div class="mobile-menu-head">
        <span class="logo-mark" aria-hidden="true"><?php echo shabaneh_icon('coffee', 20); ?></span>
        <span class="mobile-menu-title"><?php echo htmlspecialchars($shabanehCafeName, ENT_QUOTES); ?></span>
        <button type="button" class="mobile-menu-close" id="menuClose" aria-label="بستن منو">
            <?php echo shabaneh_icon('x', 20); ?>
        </button>
    </div>
    <nav class="mobile-nav" aria-label="منوی موبایل">
        <a href="<?php $this->options->siteUrl(); ?>" <?php if ($shabanehOnHome): ?>class="active" aria-current="page"<?php endif; ?>><?php echo shabaneh_icon('home', 18); ?> خانه</a>
        <a href="<?php echo htmlspecialchars(shabaneh_link_url('#services', $shabanehOnHome), ENT_QUOTES); ?>" data-close><?php echo shabaneh_icon('coffee', 18); ?> خدمات</a>
        <a href="<?php echo htmlspecialchars($shabanehDlNavUrl, ENT_QUOTES); ?>" data-close <?php if ($shabanehDlCat !== null && $this->is('category', $shabanehDlCat['slug'])): ?>class="active" aria-current="page"<?php endif; ?>><?php echo shabaneh_icon('download', 18); ?> دانلودها</a>
        <a href="<?php echo htmlspecialchars(shabaneh_link_url('#tariff', $shabanehOnHome), ENT_QUOTES); ?>" data-close><?php echo shabaneh_icon('badge-percent', 18); ?> تعرفه‌ها</a>
        <a href="<?php echo htmlspecialchars(shabaneh_link_url('#about', $shabanehOnHome), ENT_QUOTES); ?>" data-close><?php echo shabaneh_icon('sparkles', 18); ?> چرا شبانه</a>
        <a href="<?php echo htmlspecialchars($shabanehOnHome ? '#blog' : $shabanehBlogUrl, ENT_QUOTES); ?>" data-close <?php if (!$shabanehOnHome && ($shabanehIsBlogPage || $this->is('archive') || $this->is('post'))): ?>class="active" aria-current="page"<?php endif; ?>><?php echo shabaneh_icon('file-text', 18); ?> مقالات</a>
        <?php
        $shabanehNavPagesM = \Widget\Contents\Page\Rows::allocWithAlias('shabanehMobile');
        while ($shabanehNavPagesM->next()):
        ?>
            <a href="<?php $shabanehNavPagesM->permalink(); ?>"><?php echo shabaneh_icon('file-text', 18); ?> <?php echo shabaneh_fa_title($shabanehNavPagesM); ?></a>
        <?php endwhile; ?>
        <a href="<?php echo htmlspecialchars(shabaneh_link_url('#contact', $shabanehOnHome), ENT_QUOTES); ?>" data-close class="nav-contact-link"><?php echo shabaneh_icon('phone', 18); ?> تماس با ما</a>
        <?php if (!$shabanehLoggedIn): ?>
        <a href="<?php echo htmlspecialchars($shabanehLoginUrl, ENT_QUOTES); ?>" data-close><?php echo shabaneh_icon('log-in', 18); ?> ورود / ثبت‌نام</a>
        <?php else: ?>
        <a href="<?php echo htmlspecialchars($shabanehLogoutUrl, ENT_QUOTES); ?>" data-close><?php echo shabaneh_icon('log-in', 18); ?> خروج از حساب</a>
        <?php endif; ?>
    </nav>
    <?php if (trim((string)$shabanehCtaUrl) !== '' && trim($shabanehCtaText) !== ''): ?>
    <a href="<?php echo htmlspecialchars(shabaneh_link_url($shabanehCtaUrl, $shabanehOnHome), ENT_QUOTES); ?>" class="mobile-cta">
        <?php echo shabaneh_icon('download', 18); ?>
        <?php echo htmlspecialchars($shabanehCtaText, ENT_QUOTES); ?>
    </a>
    <?php endif; ?>
    <?php if ($shabanehPhone !== null && trim($shabanehPhone) !== ''): ?>
    <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $shabanehPhone), ENT_QUOTES); ?>" class="mobile-cta mobile-cta-phone">
        <?php echo shabaneh_icon('phone-call', 18); ?>
        <?php echo htmlspecialchars(toPersianNumbers($shabanehPhone), ENT_QUOTES); ?>
    </a>
    <?php endif; ?>
</div>
<div class="menu-overlay" id="menuOverlay" aria-hidden="true"></div>

<main id="main" class="site-main">
