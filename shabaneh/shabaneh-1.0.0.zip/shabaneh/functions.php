<?php

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/* ================================================================
 *  شبانه — پوستهٔ کافی‌نت و مرکز خدمات اینترنتی برای تایپ‌رینیو
 *  معماری بر اساس پوسته‌های نهال/سپیده/فرزانه و سازوکار افزونهٔ Booking
 * ================================================================ */

/* ================================================================
 *  ۱) ابزارهای عمومی
 * ================================================================ */

/** خواندن تنظیم پوسته با مقدار پیش‌فرض (مقدار خالی → پیش‌فرض) */
function shabaneh_opt(string $name, ?string $default = null): string
{
    try {
        $value = \Widget\Options::alloc()->{$name};
    } catch (\Throwable $e) {
        $value = null;
    }
    return ($value === null || $value === '') ? (string)$default : (string)$value;
}

/** مانند shabaneh_opt اما «مقدار خالی» را نیز برمی‌گرداند (تمایز تنظیم‌نشده/خالی‌شده) */
function shabaneh_opt_raw(string $name): ?string
{
    try {
        $value = \Widget\Options::alloc()->{$name};
    } catch (\Throwable $e) {
        return null;
    }
    return ($value === null) ? null : (string)$value;
}

/** تبدیل ارقام لاتین به فارسی */
if (!function_exists('toPersianNumbers')) {
    function toPersianNumbers($num)
    {
        $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return str_replace(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], $persian, (string)$num);
    }
}

/** تبدیل ارقام فارسی/عربی به لاتین (برای شمارندهٔ انیمیشنی و محاسبات) */
function shabaneh_to_en_digits(string $text): string
{
    $fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $ar = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    $text = str_replace($fa, array_keys($fa), $text);
    return str_replace($ar, array_keys($ar), $text);
}

/** عدد فارسی با جداکنندهٔ هزارگان: 1234 → ۱٬۲۳۴ */
function shabaneh_num($num): string
{
    return toPersianNumbers(str_replace(',', '٬', number_format(max(0, (float)$num))));
}

/** عنوان محتوا برای نمایش: HTML-escaped + ارقام فارسی */
function shabaneh_fa_title($widget): string
{
    $title = '';
    try {
        $title = (string)$widget->title;
    } catch (\Throwable $e) {
        $title = '';
    }
    return toPersianNumbers(htmlspecialchars($title, ENT_QUOTES, 'UTF-8'));
}

/** نرمال‌سازی آدرس تصویر (نسبی → مطلق) — آدرس‌های دارای scheme دست‌نخورده می‌مانند */
function shabaneh_resolve_url(string $url): string
{
    $url = trim($url);
    if ($url === '' || preg_match('#^(data:|[a-z][a-z0-9+.\-]*:|//)#i', $url)) {
        return $url;
    }
    try {
        $base = rtrim((string)\Widget\Options::alloc()->siteUrl, '/');
    } catch (\Throwable $e) {
        $base = '';
    }
    return $base . '/' . ltrim($url, '/');
}

/**
 * آدرس نهایی دکمه‌ها و لینک‌های منو:
 *  - «#hash» فقط در صفحهٔ اول همان اسکرول درون‌صفحه است؛ در صفحات دیگر به «siteUrl/#hash» تبدیل می‌شود
 *  - آدرس‌های دارای scheme (tel: / mailto: / https: …) و // و data: عیناً حفظ می‌شوند
 */
function shabaneh_link_url(string $url, bool $onHome = true): string
{
    $url = trim($url);
    if ($url === '') {
        return '';
    }
    if (preg_match('#^(data:|[a-z][a-z0-9+.\-]*:|//)#i', $url)) {
        return $url;
    }
    if ($url[0] === '#') {
        if ($onHome) {
            return $url;
        }
        try {
            $base = rtrim((string)\Widget\Options::alloc()->siteUrl, '/');
        } catch (\Throwable $e) {
            $base = '';
        }
        return $base . '/' . $url;
    }
    return shabaneh_resolve_url($url);
}

/** نام مسیر (route) جاری تایپ‌رینیو؛ در نبود روتر خالی برمی‌گردد */
function shabaneh_route(): string
{
    try {
        if (class_exists('\Typecho\Router') && isset(\Typecho\Router::$current)) {
            return (string)\Typecho\Router::$current;
        }
    } catch (\Throwable $e) {
    }
    return '';
}

/** آیا همین صفحه «صفحهٔ اول» سایت است؟ (بر مبنای مسیر جاری)
 *  توجه: index_page (یعنی /page/2/ و بعدی) صفحهٔ اول نیست — در تنظیم
 *  پیش‌فرض (فهرست = نوشته‌های اخیر)، صفحه‌های ۲ به بعد فهرست مقالات‌اند؛
 *  اگر هم لندینگ رندر می‌شدند، صفحه‌بندی لیست مقالات بی‌کارکرد می‌شد. */
function shabaneh_is_front(): bool
{
    $route = shabaneh_route();
    if (in_array($route, ['index', 'do', ''], true)) {
        if ($route === 'do') {
            try {
                $path = '/' . trim((string)\Widget\Archive::alloc()->request->getPathInfo(), '/');
                if (!in_array($path, ['/', '/index.php', '/index.html'], true)) {
                    return false;
                }
            } catch (\Throwable $e) {
            }
        }
        return true;
    }
    return false;
}

/** آدرس پویای فایل‌های پوسته (نسخه‌دار برای کش) */
function shabaneh_asset(string $path): string
{
    try {
        $base = rtrim((string)\Widget\Options::alloc()->themeUrl, '/');
        $file = dirname(__DIR__) . '/' . ltrim($path, '/');
        $v = is_file($file) ? (string)filemtime($file) : SHABANEH_VERSION;
        return $base . '/' . ltrim($path, '/') . '?v=' . $v;
    } catch (\Throwable $e) {
        return $path;
    }
}

/** خروجی امن HTML (htmlspecialchars میان‌بر) */
function shabaneh_esc($text): string
{
    return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8');
}

/** حرف اول نام — برای آواتار الفبایی */
function shabaneh_initial(string $name): string
{
    $name = trim($name);
    return ($name === '') ? '؟' : mb_substr($name, 0, 1, 'UTF-8');
}

/** نسخهٔ پوسته */
define('SHABANEH_VERSION', '1.0.3');

/** صفحه‌بندی فارسی‌شدهٔ فهرست‌ها */
function shabaneh_page_nav($archive): void
{
    if ($archive === null || !method_exists($archive, 'pageNav')) {
        return;
    }
    ob_start();
    $archive->pageNav(
        toPersianNumbers('قبلی'),
        toPersianNumbers('بعدی'),
        2,
        '…',
        [
            'wrapTag'      => 'nav',
            'wrapClass'    => 'pagination',
            'itemTag'      => '',
            'textTag'      => 'span',
            'currentClass' => 'page-current',
            'prevClass'    => 'page-prev',
            'nextClass'    => 'page-next',
        ]
    );
    $html = (string)ob_get_clean();
    if ($html === '') {
        return;
    }
    echo preg_replace_callback(
        '/>([^<>]*)</',
        function ($m) {
            return '>' . toPersianNumbers($m[1]) . '<';
        },
        $html
    );
}

/**
 * فرم جستجوی فهرست مقالات (بالای لیست).
 * فرم با POST به آدرس سایت فرستاده می‌شود؛ هستهٔ تایپ‌رینیو آن را به
 * صفحهٔ /search/[واژه]/ هدایت می‌کند. واژهٔ جاری برای پرکردن فیلد پاس می‌شود.
 */
function shabaneh_search_form(string $currentQuery = ''): void
{
    $currentQuery = htmlspecialchars($currentQuery, ENT_QUOTES, 'UTF-8');
    try {
        $action = (string)\Widget\Options::alloc()->siteUrl;
    } catch (\Throwable $e) {
        $action = '/';
    }
    ?>
    <form class="archive-search" method="post" action="<?php echo htmlspecialchars($action, ENT_QUOTES); ?>" role="search">
        <span class="archive-search-ic" aria-hidden="true"><?php echo shabaneh_icon('search', 18); ?></span>
        <input type="search" name="s" class="archive-search-input" placeholder="جستجو در مقالات و دانلودها…"
               value="<?php echo $currentQuery; ?>" aria-label="جستجو در مقالات" autocomplete="off">
        <button type="submit" class="archive-search-btn"><?php echo shabaneh_icon('arrow-left', 17); ?></button>
    </form>
    <?php
}

/* ================================================================
 *  ۲) آیکون‌های Lucide (SVG درون‌خطی — بدون نیاز به اینترنت)
 * ================================================================ */

/** فهرست آیکون‌های Lucide آموزش اینترنت/کافی‌نت */
function shabaneh_icons(): array
{
    static $icons = null;
    if ($icons !== null) {
        return $icons;
    }
    $icons = [
        // برند و خدمات کافی‌نت
        'coffee' => '<path d="M10 2v2"/><path d="M14 2v2"/><path d="M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1"/><path d="M6 2v2"/>',
        'wifi' => '<path d="M5 13a10 10 0 0 1 14 0"/><path d="M8.5 16.5a5 5 0 0 1 7 0"/><path d="M2 8.82a15 15 0 0 1 20 0"/><line x1="12" y1="20" x2="12.01" y2="20"/>',
        'printer' => '<path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8" rx="1"/>',
        'scan-line' => '<path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><line x1="7" y1="12" x2="17" y2="12"/>',
        'keyboard' => '<rect width="20" height="16" x="2" y="4" rx="2" ry="2"/><path d="M6 8h.001"/><path d="M10 8h.001"/><path d="M14 8h.001"/><path d="M18 8h.001"/><path d="M8 12h.001"/><path d="M12 12h.001"/><path d="M16 12h.001"/><path d="M7 16h10"/>',
        'gamepad-2' => '<line x1="6" y1="11" x2="10" y2="11"/><line x1="8" y1="9" x2="8" y2="13"/><line x1="15" y1="12" x2="15.01" y2="12"/><line x1="18" y1="10" x2="18.01" y2="10"/><path d="M17.32 5H6.68a4 4 0 0 0-3.978 3.59c-.006.052-.01.101-.017.152C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258-.007-.05-.011-.1-.017-.151A4 4 0 0 0 17.32 5z"/>',
        'monitor' => '<rect width="20" height="14" x="2" y="3" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>',
        'file-down' => '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M12 18v-6"/><path d="m9 15 3 3 3-3"/>',
        'download' => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
        'usb' => '<path d="M2 7v10"/><path d="M6 5v11"/><path d="M10 9v10"/><path d="M14 5v5"/><path d="M18 9v6"/><path d="M22 7l-4 4-4-4"/>',
        'zap' => '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
        'gauge' => '<path d="m12 14 4-4"/><path d="M3.34 19a10 10 0 1 1 17.32 0"/>',
        'hourglass' => '<path d="M5 22h14"/><path d="M5 2h14"/><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"/><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/>',
        'shield-check' => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1 1 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
        // عمومی
        'user' => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'users' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'calendar' => '<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
        'clock' => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
        'phone' => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
        'phone-call' => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/><path d="M14.05 2a9 9 0 0 1 8 7.94"/><path d="M14.05 6A5 5 0 0 1 18 10"/>',
        'mail' => '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>',
        'map-pin' => '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
        'message-square' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
        'send' => '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
        'check-circle' => '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>',
        'star' => '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
        'award' => '<circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/>',
        'quote' => '<path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"/><path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"/>',
        'file-text' => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/>',
        'folder' => '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
        'tag' => '<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.83z"/><line x1="7" y1="7" x2="7.01" y2="7"/>',
        'eye' => '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
        'heart' => '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>',
        'arrow-up' => '<line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/>',
        'arrow-left' => '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
        'chevron-left' => '<polyline points="15 18 9 12 15 6"/>',
        'chevron-right' => '<polyline points="9 18 15 12 9 6"/>',
        'chevron-down' => '<polyline points="6 9 12 15 18 9"/>',
        'menu' => '<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
        'x' => '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
        'check' => '<polyline points="20 6 9 17 4 12"/>',
        'lock' => '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
        'unlock' => '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>',
        'log-in' => '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/>',
        'home' => '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
        'search' => '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
        'info' => '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
        'external-link' => '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>',
        'trending-up' => '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
        'lightbulb' => '<path d="M9 18h6"/><path d="M10 22h4"/><path d="M15.09 14c.18-.98.65-1.74 1.41-2.5A4.65 4.65 0 0 0 18 8 6 6 0 0 0 6 8c0 1 .23 2.23 1.5 3.5A4.61 4.61 0 0 1 8.91 14"/>',
        'sparkles' => '<path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/>',
        'moon' => '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
        'sun' => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',
        'clipboard-list' => '<rect x="8" y="2" width="8" height="4" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/>',
        'hdd' => '<line x1="22" y1="12" x2="2" y2="12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/><line x1="6" y1="16" x2="6.01" y2="16"/><line x1="10" y1="16" x2="10.01" y2="16"/>',
        'mouse-pointer' => '<path d="m3 3 7.07 16.97 2.51-7.39 7.39-2.51L3 3z"/><path d="m13 13 6 6"/>',
        'badge-percent' => '<line x1="19" y1="5" x2="5" y2="19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>',
        'instagram' => '<rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>',
        'youtube' => '<path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/><path d="m10 15 5-3-5-3z"/>',
        'send-horizontal' => '<path d="m3 3 3 9-3 9 19-9Z"/><path d="M6 12h16"/>',
    ];
    return $icons;
}

/** رندر آیکون Lucide — خروجی SVG درون‌خطی */
function shabaneh_icon(string $name, int $size = 24, string $class = ''): string
{
    $icons = shabaneh_icons();
    $path = $icons[$name] ?? $icons['coffee'];
    $classAttr = $class !== '' ? ' class="' . htmlspecialchars($class, ENT_QUOTES) . '"' : '';
    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"' . $classAttr . '>' . $path . '</svg>';
}

/** آیا نام آیکون معتبر است؟ (برای اعتبارسنجی ورودی) */
function shabaneh_icon_exists(string $name): bool
{
    return array_key_exists($name, shabaneh_icons());
}

/* ================================================================
 *  ۳) تاریخ شمسی
 * ================================================================ */

/** میلادی → جلالی (الگوریتم استاندارد) */
function shabaneh_to_jalali(int $gy, int $gm, int $gd): array
{
    $g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100))
        + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
    $jy = -1595 + (33 * ((int)($days / 12053)));
    $days %= 12053;
    $jy += 4 * ((int)($days / 1461));
    $days %= 1461;
    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + (int)($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }
    return [$jy, $jm, $jd];
}

/**
 * تاریخ/ساعت شمسی بر اساس وقت تهران — مستقل از تنظیمات سرور.
 *
 * تمام نمایش‌های تاریخ و ساعت پوسته (از جمله ساعت ثبت درخواست‌های ثبت‌نام در
 * برگهٔ مدیریت) با منطقهٔ زمانی Asia/Tehran محاسبه می‌شوند؛ بنابراین حتی اگر
 * سرور روی UTC یا منطقهٔ دیگری باشد، ساعت‌ها همیشه به وقت ایران نمایش داده می‌شوند.
 * (ایران از سال ۱۴۰۱ تغییر ساعت ندارد؛ DateTimeZone قواعد تاریخی DST را هم درست رعایت می‌کند.)
 */
function shabaneh_tehran(int $timestamp): \DateTimeImmutable
{
    static $tz = null;
    try {
        if ($tz === null) {
            $tz = new \DateTimeZone('Asia/Tehran');
        }
        return (new \DateTimeImmutable('@' . $timestamp))->setTimezone($tz);
    } catch (\Throwable $e) {
        return new \DateTimeImmutable('@' . $timestamp);
    }
}

/** تاریخ شمسی از timestamp — همیشه به وقت تهران */
function shabaneh_jalali_date($timestamp = null, string $format = 'Y/m/d'): string
{
    if ($timestamp === null) {
        $timestamp = time();
    }
    $timestamp = (int)$timestamp;
    if ($timestamp <= 0) {
        $timestamp = time();
    }
    return shabaneh_format_jalali($timestamp, $format);
}

/** قالب‌بندی تاریخ شمسی — اجزای میلادی از DateTime منطقهٔ تهران خوانده می‌شوند */
function shabaneh_format_jalali(int $timestamp, string $format): string
{
    $dt = shabaneh_tehran($timestamp);
    $gy = (int)$dt->format('Y');
    $gm = (int)$dt->format('n');
    $gd = (int)$dt->format('j');
    [$jy, $jm, $jd] = shabaneh_to_jalali($gy, $gm, $gd);

    $months = [
        1 => 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
    ];

    $out = $format;
    $out = str_replace('Y', (string)$jy, $out);
    $out = str_replace('y', substr((string)$jy, -2), $out);
    $out = str_replace('m', str_pad((string)$jm, 2, '0', STR_PAD_LEFT), $out);
    $out = str_replace('n', (string)$jm, $out);
    $out = str_replace('d', str_pad((string)$jd, 2, '0', STR_PAD_LEFT), $out);
    $out = str_replace('j', (string)$jd, $out);
    $out = str_replace('F', $months[$jm], $out);
    // روز هفته: N = ۱(دوشنبه) … ۷(یکشنبه)
    $weekdays = [1 => 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه', 'یکشنبه'];
    $out = str_replace('l', $weekdays[(int)$dt->format('N')], $out);
    $out = str_replace('H', $dt->format('H'), $out);
    $out = str_replace('i', $dt->format('i'), $out);
    return toPersianNumbers($out);
}

/** تاریخ ISO 8601 هماهنگ با وقت تهران (برای ویژگی datetime تگ time) */
function shabaneh_iso_date(int $timestamp): string
{
    return shabaneh_tehran($timestamp)->format('c');
}

/** تاریخ انتشار محتوا به شمسی */
function shabaneh_post_date($archive, string $format = 'j F Y'): string
{
    try {
        $timestamp = (int)$archive->created;
    } catch (\Throwable $e) {
        $timestamp = time();
    }
    return shabaneh_jalali_date($timestamp, $format);
}

/** سال شمسی جاری برای کپی‌رایت */
function shabaneh_jalali_year(): string
{
    return shabaneh_jalali_date(time(), 'Y');
}

/* ================================================================
 *  ۴) بازدید و لایک
 * ================================================================ */

/** آیا افزونهٔ ViewsCounter فعال است؟ */
function shabaneh_views_counter_active(): bool
{
    try {
        $plugins = \Widget\Options::alloc()->plugins;
        if (is_array($plugins) && isset($plugins['activated']) && is_array($plugins['activated'])) {
            foreach (array_keys($plugins['activated']) as $key) {
                if (stripos((string)$key, 'views') !== false) {
                    return true;
                }
            }
        }
    } catch (\Throwable $e) {
    }
    return false;
}

/** اطمینان از وجود ستون‌های views و likes (در نبود، ساخته می‌شوند) */
function shabaneh_stats_ready(): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }

    $ready = false;
    try {
        $db = \Typecho\Db::get();
        $prefix = $db->getPrefix();

        $columns = [];
        try {
            // MySQL
            $rows = $db->fetchAll("SHOW COLUMNS FROM `{$prefix}contents`");
            foreach ($rows as $row) {
                $columns[] = is_array($row) ? (string)reset($row) : (string)$row->Field;
            }
        } catch (\Throwable $e) {
            $columns = [];
        }

        if (empty($columns)) {
            foreach (['views', 'likes'] as $col) {
                try {
                    $db->fetchRow($db->select("table.contents.{$col}")->from('table.contents')->limit(1));
                } catch (\Throwable $e) {
                    try {
                        $db->query("ALTER TABLE `{$prefix}contents` ADD `{$col}` INT DEFAULT 0");
                    } catch (\Throwable $e2) {
                    }
                }
            }
        } else {
            foreach (['views', 'likes'] as $col) {
                if (!in_array($col, $columns, true)) {
                    try {
                        $db->query("ALTER TABLE `{$prefix}contents` ADD `{$col}` INT DEFAULT 0");
                    } catch (\Throwable $e) {
                    }
                }
            }
        }

        $ready = true;
    } catch (\Throwable $e) {
        $ready = false;
    }
    return $ready;
}

/** تعداد بازدید نوشته */
function shabaneh_views($archive): int
{
    if (shabaneh_views_counter_active()) {
        try {
            $v = (int)$archive->views;
            if ($v > 0) {
                return $v;
            }
        } catch (\Throwable $e) {
        }
    }
    try {
        $cid = (int)$archive->cid;
        if ($cid < 1 || !shabaneh_stats_ready()) {
            return 0;
        }
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.views')->from('table.contents')->where('table.contents.cid = ?', $cid)
        );
        return (int)($row['views'] ?? 0);
    } catch (\Throwable $e) {
        return 0;
    }
}

/** تعداد لایک نوشته */
function shabaneh_likes($archive): int
{
    try {
        $cid = (int)$archive->cid;
        if ($cid < 1 || !shabaneh_stats_ready()) {
            return 0;
        }
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        );
        return (int)($row['likes'] ?? 0);
    } catch (\Throwable $e) {
        return 0;
    }
}

/** شمارش بازدید صفحات تکی با کوکی ضد تکرار */
function shabaneh_count_view($archive): void
{
    try {
        if (!method_exists($archive, 'is') || !$archive->is('single')) {
            return;
        }
        if (shabaneh_opt('shabanehCountAdminViews', '0') !== '1') {
            try {
                $user = \Widget\User::alloc();
                if ($user->hasLogin() && $user->pass('administrator', true)) {
                    return;
                }
            } catch (\Throwable $e) {
            }
        }
        $cid = (int)$archive->cid;
        if ($cid < 1 || !shabaneh_stats_ready()) {
            return;
        }
        $cookieName = 'shabanehV' . $cid;
        if (isset($_COOKIE[$cookieName])) {
            return;
        }
        $db = \Typecho\Db::get();
        $db->query(
            $db->update('table.contents')
                ->expression('views', 'views + 1')
                ->where('table.contents.cid = ?', $cid)
        );
        \Typecho\Cookie::set($cookieName, '1', time() + 86400);
    } catch (\Throwable $e) {
    }
}

/** شناسه‌های لایک‌شدهٔ این بازدیدکننده (کوکی shabanehLikes) */
function shabaneh_user_likes(): array
{
    $raw = $_COOKIE['shabanehLikes'] ?? '';
    $ids = array_filter(array_map('trim', explode(',', (string)$raw)));
    $out = [];
    foreach ($ids as $id) {
        if (ctype_digit((string)$id)) {
            $out[] = (string)(int)$id;
        }
    }
    return $out;
}

/** آیا این بازدیدکننده این نوشته را لایک کرده؟ */
function shabaneh_is_liked($cid): bool
{
    return in_array((string)(int)$cid, shabaneh_user_likes(), true);
}

/** خروجی JSON و پایان درخواست — سخت‌سازی‌شده (الگو از افزونهٔ Booking) */
function shabaneh_json(array $payload, int $status = 200): void
{
    /*
     * هر بافر خروجی باز (حتی هشدارهای PHP در حالت display_errors) پاک می‌شود تا
     * پاسخ همیشه JSON خالص باشد و سمت کلاینت res.json() هرگز شکست نخورد.
     */
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('X-Content-Type-Options: nosniff');
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** پردازش درخواست لایک — POST با پارامتر shabanehLike=<cid> */
function shabaneh_handle_like($request): void
{
    $cid = (int)(string)$request->get('shabanehLike');
    if ($cid < 1) {
        shabaneh_json(['ok' => false, 'error' => 'bad-request'], 400);
        return;
    }

    // جلوگیری ساده از CSRF
    try {
        $siteHost = (string)parse_url((string)\Widget\Options::alloc()->siteUrl, PHP_URL_HOST);
        $referer = (string)($_SERVER['HTTP_REFERER'] ?? '');
        if ($referer !== '' && $siteHost !== '' && stripos($referer, $siteHost) === false) {
            shabaneh_json(['ok' => false, 'error' => 'cross-origin'], 403);
            return;
        }
    } catch (\Throwable $e) {
    }

    if (!shabaneh_stats_ready()) {
        shabaneh_json(['ok' => false, 'error' => 'db-error'], 500);
        return;
    }

    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        );
        if (!$row) {
            shabaneh_json(['ok' => false, 'error' => 'not-found'], 404);
            return;
        }

        $likes = max(0, (int)$row['likes']);
        $likedIds = shabaneh_user_likes();
        $wasLiked = in_array((string)$cid, $likedIds, true);

        if ($wasLiked) {
            $likes = max(0, $likes - 1);
            $likedIds = array_values(array_diff($likedIds, [(string)$cid]));
        } else {
            $likes = $likes + 1;
            $likedIds[] = (string)$cid;
        }

        try {
            \Typecho\Cookie::set('shabanehLikes', implode(',', $likedIds), time() + 31536000);
        } catch (\Throwable $e) {
        }

        $db->query(
            $db->update('table.contents')
                ->expression('likes', 'likes + ' . ($wasLiked ? -1 : 1))
                ->where('table.contents.cid = ?', $cid)
        );

        shabaneh_json([
            'ok'    => true,
            'cid'   => $cid,
            'likes' => $likes,
            'liked' => !$wasLiked,
        ]);
    } catch (\Throwable $e) {
        shabaneh_json(['ok' => false, 'error' => 'server-error'], 500);
    }
}

/* ================================================================
 *  ۵) سیستم دانلود — قلب پوستهٔ کافی‌نت
 *  فیلدهای اختصاصی نوشته: downloadUrl / downloadSize /
 *  downloadFormat / downloadAccess (all|member)
 * ================================================================ */

/** آیا کاربر فعلی وارد شده است؟ (برای دسترسی دانلودِ ویژهٔ اعضا) */
function shabaneh_user_logged_in(): bool
{
    try {
        $user = \Widget\User::alloc();
        return (bool)$user->hasLogin();
    } catch (\Throwable $e) {
        return false;
    }
}

/** آدرس صفحهٔ ورود سایت (با بازگشت به همین صفحه) */
function shabaneh_login_url(): string
{
    try {
        $url = (string)\Widget\Options::alloc()->loginUrl;
        $back = '';
        try {
            $back = shabaneh_current_url();
        } catch (\Throwable $e) {
        }
        if ($back !== '' && strpos($url, '?') !== false) {
            return $url . '&referer=' . rawurlencode($back);
        }
        return $url;
    } catch (\Throwable $e) {
        return '#';
    }
}

/** آدرس کامل صفحهٔ جاری (برای referer ورود) */
function shabaneh_current_url(): string
{
    try {
        $options = \Widget\Options::alloc();
        $site = rtrim((string)$options->siteUrl, '/');
        $path = '';
        try {
            $req = \Widget\Archive::alloc()->request;
            $path = '/' . trim((string)$req->getRequestUri(), '/');
            $script = '/' . basename($_SERVER['SCRIPT_NAME'] ?? '');
            if ($script !== '/' && $script !== '/index.php' && substr($path, 0, strlen($script)) === $script) {
                $path = substr($path, strlen($script));
            }
        } catch (\Throwable $e) {
        }
        if ($path === '' || $path === '/') {
            $path = isset($_SERVER['REQUEST_URI']) ? (string)$_SERVER['REQUEST_URI'] : '/';
            if (preg_match('#^https?://[^/]+(.+)$#i', $path, $m)) {
                $path = $m[1];
            }
        }
        return $site . $path;
    } catch (\Throwable $e) {
        return '';
    }
}

/**
 * دادهٔ دانلود یک محتوا را از فیلدهای اختصاصی می‌خواند.
 *
 * خروجی:
 *  has     => bool  آیا فایل دانلودی دارد؟
 *  url     => string آدرس فایل
 *  size    => string حجم نمایشی (متنی)
 *  format  => string فرمت فایل (PDF / Word / ZIP …)
 *  access  => string all|member — نمایش برای همه یا فقط اعضا
 */
function shabaneh_download_data($content, ?array $fieldMap = null): array
{
    $empty = ['has' => false, 'url' => '', 'size' => '', 'format' => '', 'access' => 'all'];
    try {
        if (is_array($fieldMap)) {
            $url    = trim((string)($fieldMap['downloadUrl'] ?? ''));
            $size   = trim((string)($fieldMap['downloadSize'] ?? ''));
            $format = trim((string)($fieldMap['downloadFormat'] ?? ''));
            $access = trim((string)($fieldMap['downloadAccess'] ?? ''));
        } else {
            $fields = $content->fields;
            $url    = trim((string)($fields->downloadUrl ?? ''));
            $size   = trim((string)($fields->downloadSize ?? ''));
            $format = trim((string)($fields->downloadFormat ?? ''));
            $access = trim((string)($fields->downloadAccess ?? ''));
        }
    } catch (\Throwable $e) {
        return $empty;
    }

    if ($url === '') {
        return $empty;
    }
    if ($access !== 'member') {
        $access = 'all';
    }
    return [
        'has'    => true,
        'url'    => $url,
        'size'   => ($size !== '') ? $size : 'نامشخص',
        'format' => ($format !== '') ? $format : 'PDF',
        'access' => $access,
    ];
}

/** آیا این فایل برای این بازدیدکننده قابل دانلود است؟ (فقط اعضا → نیاز به ورود) */
function shabaneh_can_download(array $dl): bool
{
    if (!($dl['has'] ?? false)) {
        return false;
    }
    if (($dl['access'] ?? 'all') === 'member') {
        return shabaneh_user_logged_in();
    }
    return true;
}

/** برچسب فارسی سطح دسترسی */
function shabaneh_access_label(string $access): string
{
    return $access === 'member' ? 'ویژهٔ اعضا' : 'دانلود آزاد';
}

/** آیا این محتوا فایل دانلودی دارد؟ (چهارچوب سری برای قالب‌ها) */
function shabaneh_has_download($content): bool
{
    try {
        $fields = $content->fields;
        return trim((string)($fields->downloadUrl ?? '')) !== '';
    } catch (\Throwable $e) {
        return false;
    }
}

/* ================================================================
 *  ۶-ب) دستهٔ مقالات دانلودی (اتصال داینامیک از تنظیمات پوسته)
 * ================================================================
 *  اگر مدیر در تنظیمات پوسته دسته‌ای را به‌عنوان «دستهٔ مقالات دانلودی»
 *  انتخاب کند، منبع بخش «مقالات و دانلودها» فقط همان دسته می‌شود و
 *  دکمهٔ «دانلود مقالات» هیرو و منو نیز به صفحهٔ همان دسته متصل می‌شود.
 *  در حالت «خودکار» (پیش‌فرض) رفتار قبلی بر قرار است: نوشته‌هایی که
 *  فیلد اختصاصی «لینک دانلود» داشته باشند.
 * ================================================================ */

/** شناسهٔ دستهٔ دانلودهای منتخب (۰ = حالت خودکار بر اساس فیلد لینک دانلود) */
function shabaneh_download_category_mid(): int
{
    $mid = (int)shabaneh_to_en_digits(shabaneh_opt('shabanehDownloadCategory', '0'));
    return ($mid > 0) ? $mid : 0;
}

/**
 * اطلاعات دستهٔ دانلودهای منتخب: mid / slug / name / url
 * خروجی null یعنی دسته‌ای انتخاب نشده (یا معتبر نبود) و حالت خودکار فعال است.
 */
function shabaneh_download_category(): ?array
{
    static $resolved = false;
    static $cat = null;
    if ($resolved) {
        return $cat;
    }
    $resolved = true;

    $mid = shabaneh_download_category_mid();
    if ($mid < 1) {
        return null;
    }

    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('mid', 'slug', 'name')
                ->from('table.metas')
                ->where('mid = ?', $mid)
                ->where('type = ?', 'category')
                ->limit(1)
        );
        if (empty($row)) {
            return null;
        }

        // آدرس صفحهٔ دسته از جدول مسیریابی (مثل /category/[slug]/)
        $options = \Widget\Options::alloc();
        $siteBase = rtrim((string)$options->siteUrl, '/');
        $route = $options->routingTable['category'] ?? null;
        $pattern = is_string($route) ? $route : (is_array($route) ? (string)($route['url'] ?? '') : '');
        if ($pattern === '') {
            $pattern = '/category/[slug]/';
        }
        $slug = rawurlencode((string)$row['slug']);
        $path = str_replace(['[slug:digital]', '[slug]'], $slug, $pattern);

        $cat = [
            'mid'  => (int)$row['mid'],
            'slug' => (string)$row['slug'],
            'name' => (string)$row['name'],
            'url'  => $siteBase . '/' . ltrim($path, '/'),
        ];
    } catch (\Throwable $e) {
        $cat = null;
    }
    return $cat;
}

/** شناسهٔ نوشته‌های منتسب به یک دسته (کوئری با کش ایستا) */
function shabaneh_category_cids(int $mid): array
{
    static $cache = [];
    if ($mid < 1) {
        return [];
    }
    if (isset($cache[$mid])) {
        return $cache[$mid];
    }
    $out = [];
    try {
        $db = \Typecho\Db::get();
        $rows = $db->fetchAll(
            $db->select('cid')->from('table.relationships')->where('mid = ?', $mid)
        );
        foreach ((array)$rows as $r) {
            $out[(int)$r['cid']] = true;
        }
    } catch (\Throwable $e) {
    }
    $cache[$mid] = $out;
    return $out;
}

/** مقصد «همهٔ مقالات و فایل‌ها»: صفحهٔ دستهٔ منتخب یا فهرست وبلاگ */
function shabaneh_downloads_url(): string
{
    $cat = shabaneh_download_category();
    if ($cat !== null) {
        return $cat['url'];
    }
    return shabaneh_blog_url();
}

/* ================================================================
 *  ۶) پارسرهای بخش‌های داینامیک
 * ================================================================ */

/** پارس خطوط «الف | ب | ج» — جداکننده فقط | */
function shabaneh_parse_lines(?string $text, int $minParts = 1): array
{
    $text = (string)$text;
    if (trim($text) === '') {
        return [];
    }
    $out = [];
    foreach (preg_split('/\r\n|\r|\n/', $text) as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        $parts = preg_split('/\s*\|\s*/', $line);
        $parts = array_map('trim', $parts);
        while (count($parts) > 0 && $parts[count($parts) - 1] === '') {
            array_pop($parts);
        }
        if (count($parts) >= $minParts) {
            $out[] = $parts;
        }
    }
    return $out;
}

/** پارس آمار هیرو: «عدد | عنوان» */
function shabaneh_parse_stats(?string $text): array
{
    $out = [];
    foreach (shabaneh_parse_lines($text, 2) as $parts) {
        $num = toPersianNumbers(preg_replace('/[^0-9+]/', '', $parts[0]));
        $out[] = ['num' => ($num !== '' ? $num : '۰'), 'label' => $parts[1]];
    }
    return $out;
}

/**
 * پارس آمار نوار «شبانه در یک نگاه»: «عنوان | مقدار | آیکون»
 *
 * مقدار متن آزاد است (مثل «۱۰۰ مگابیت»، «۴۵+» یا «۲۴ ساعته»)؛ اگر با عدد
 * شروع شود، بخش عددی برای شمارندهٔ انیمیشنی و باقی‌مانده پسوند جدا می‌شود.
 */
function shabaneh_parse_glance(?string $text): array
{
    $out = [];
    foreach (shabaneh_parse_lines($text, 2) as $parts) {
        $value = trim($parts[1] ?? '');
        $icon  = trim($parts[2] ?? '');
        if ($icon === '' || !shabaneh_icon_exists($icon)) {
            $icon = 'wifi';
        }
        $out[] = [
            'label' => $parts[0],
            'value' => ($value !== '') ? $value : '۰',
            'icon'  => $icon,
        ];
    }
    return $out;
}

/** پارس خدمات کافی‌نت: «آیکون | عنوان | توضیح | متن پابرگ» */
function shabaneh_parse_services(?string $text): array
{
    $out = [];
    foreach (shabaneh_parse_lines($text, 3) as $parts) {
        $icon = trim($parts[0]);
        if (!shabaneh_icon_exists($icon)) {
            $icon = 'wifi';
        }
        $out[] = [
            'icon'  => $icon,
            'title' => $parts[1],
            'desc'  => $parts[2],
            'foot'  => trim($parts[3] ?? ''),
        ];
    }
    return $out;
}

/**
 * پارس تعرفهٔ خدمات: «آیکون | خدمت | جزئیات | واحد | قیمت»
 * مثال: printer | چاپ سیاه\u200cوسفید | کاغذ A4 | هر برگ | ۱٬۰۰۰
 */
function shabaneh_parse_tariffs(?string $text): array
{
    $out = [];
    foreach (shabaneh_parse_lines($text, 4) as $parts) {
        $icon = trim($parts[0]);
        if (!shabaneh_icon_exists($icon)) {
            $icon = 'badge-percent';
        }
        $out[] = [
            'icon'    => $icon,
            'service' => $parts[1],
            'detail'  => $parts[2] ?? '',
            'unit'    => $parts[3] ?? '',
            'price'   => $parts[4] ?? 'توافقی',
        ];
    }
    return $out;
}

/** پارس ویژگی‌های «چرا شبانه»: «آیکون | عنوان | توضیح» */
function shabaneh_parse_features(?string $text): array
{
    $out = [];
    foreach (shabaneh_parse_lines($text, 1) as $parts) {
        $out[] = [
            'icon'  => shabaneh_icon_exists($parts[0]) ? $parts[0] : 'check-circle',
            'title' => $parts[1] ?? $parts[0],
            'desc'  => $parts[2] ?? '',
        ];
    }
    return $out;
}

/** پارس نظرات مشتریان: «نام | نقش | متن | عکس (اختیاری)» */
function shabaneh_parse_testimonials(?string $text): array
{
    $out = [];
    foreach (shabaneh_parse_lines($text, 3) as $parts) {
        $photo = trim($parts[3] ?? '');
        if ($photo !== '' && preg_match('#^(data:|https?://|//)#i', $photo) !== 1) {
            $photo = shabaneh_asset(ltrim($photo, '/'));
        }
        $out[] = [
            'name'  => $parts[0],
            'meta'  => $parts[1],
            'text'  => $parts[2],
            'photo' => $photo,
        ];
    }
    return $out;
}

/** پارس سوالات متداول: «سوال | پاسخ» */
function shabaneh_parse_faq(?string $text): array
{
    $out = [];
    foreach (shabaneh_parse_lines($text, 2) as $parts) {
        $out[] = ['q' => $parts[0], 'a' => $parts[1]];
    }
    return $out;
}

/* ================================================================
 *  ۷) تصویر شاخص، فیلدهای نوشته و پست‌های صفحهٔ اول
 * ================================================================ */

/** تصویر شاخص محتوا: فیلد thumb → اولین تصویر متن → پیش‌فرض */
function shabaneh_thumbnail($content, bool $fallback = true): string
{
    $custom = '';
    try {
        $fields = $content->fields;
        $custom = trim((string)($fields->thumb ?? ''));
    } catch (\Throwable $e) {
    }
    if ($custom !== '') {
        return shabaneh_resolve_url($custom);
    }
    try {
        $text = (string)$content->text;
        if (preg_match('#<img[^>]*\bsrc=["\']([^"\']+)["\']#iu', $text, $m)) {
            return shabaneh_resolve_url($m[1]);
        }
        if (preg_match('#!\[[^\]]*\]\(\s*<?([^)\s>]+)[^)]*\)#iu', $text, $m)) {
            return shabaneh_resolve_url($m[1]);
        }
    } catch (\Throwable $e) {
    }
    return $fallback ? shabaneh_asset('img/default-cover.jpg') : '';
}

/** فیلد زمان مطالعهٔ نوشته (دقیقه) — فیلد اختصاصی readingTime */
function shabaneh_reading_time($content): string
{
    try {
        $fields = $content->fields;
        $value = trim((string)($fields->readingTime ?? ''));
        if ($value !== '' && is_numeric($value)) {
            return toPersianNumbers($value);
        }
    } catch (\Throwable $e) {
    }
    return '';
}

/**
 * آخرین نوشته‌های منتشرشده برای صفحهٔ اول:
 * کوئری مستقیم شامل متن (برای چکیده) + فیلدهای اختصاصی
 * (تصویر/زمان مطالعه/دادهٔ دانلود) + بازدید.
 *
 * $onlyDownloads=true → نوشته‌های «دانلود»:
 *   - اگر در تنظیمات «دستهٔ مقالات دانلودی» انتخاب شده باشد، فقط نوشته‌های
 *     همان دسته (چهارچوب دسته‌ای)؛
 *   - در حالت خودکار، فقط نوشته‌های دارای فیلد downloadUrl.
 * $onlyDownloads=false → نوشته‌های «وبلاگ»؛ اگر دستهٔ دانلود انتخاب شده
 *   باشد، نوشته‌های آن دسته از نتیجه حذف می‌شوند (فیلتر مبتنی بر فیلد
 *   در index.php انجام می‌شود).
 */
function shabaneh_recent_posts(int $count = 3, bool $onlyDownloads = false): array
{
    $out = [];
    $count = max(1, min(12, $count));
    try {
        $db = \Typecho\Db::get();
        $hasStats = shabaneh_stats_ready();
        $cols = ['table.contents.cid', 'table.contents.title', 'table.contents.slug',
            'table.contents.created', 'table.contents.text'];
        if ($hasStats) {
            $cols[] = 'table.contents.views';
        }

        // حالت دسته‌ای: اگر دستهٔ دانلود انتخاب شده باشد، کوئری دانلودها
        // مستقیماً با join روی جدول relationships محدود به همان دسته می‌شود.
        $dlCat = shabaneh_download_category();
        $dlCids = ($dlCat !== null) ? shabaneh_category_cids($dlCat['mid']) : null;

        $query = $db->select(...$cols)
            ->from('table.contents')
            ->where('table.contents.status = ?', 'publish')
            ->where('table.contents.created < ?', \Widget\Options::alloc()->time)
            ->where('table.contents.type = ?', 'post')
            ->order('table.contents.created', \Typecho\Db::SORT_DESC);

        if ($onlyDownloads && $dlCat !== null) {
            $query = $query
                ->join('table.relationships', 'table.relationships.cid = table.contents.cid')
                ->where('table.relationships.mid = ?', $dlCat['mid'])
                ->limit($count);
        } else {
            $query = $query->limit(max($count * 3, $count));
        }

        $rows = $db->fetchAll($query);
        if (empty($rows)) {
            return $out;
        }

        // فیلدهای اختصاصی همهٔ نوشته‌ها در یک کوئری
        $cids = array_map(function ($r) { return (int)$r['cid']; }, $rows);
        $fieldMap = [];
        try {
            $frows = $db->fetchAll(
                $db->select()->from('table.fields')->where('cid IN ?', $cids)
            );
            foreach ((array)$frows as $f) {
                $val = ('json' == $f['type']) ? json_decode((string)$f['str_value'], true) : $f[$f['type'] . '_value'];
                $fieldMap[(int)$f['cid']][(string)$f['name']] = (string)$val;
            }
        } catch (\Throwable $e) {
        }

        // مسیر پیوندها
        $siteBase = rtrim((string)\Widget\Options::alloc()->siteUrl, '/');
        $route = \Widget\Options::alloc()->routingTable['post'];
        $routeUrl = is_string($route) ? $route : ($route['url'] ?? '');

        foreach ($rows as $row) {
            $cid = (int)$row['cid'];
            $fields = $fieldMap[$cid] ?? [];

            // دادهٔ دانلود از فیلدها
            $dl = shabaneh_download_data(null, $fields);
            if ($onlyDownloads) {
                // حالت دسته‌ای: عضویت در دسته ملاک است (نه فیلد دانلود)
                if ($dlCids !== null) {
                    if (!isset($dlCids[$cid])) {
                        continue;
                    }
                } elseif (!$dl['has']) {
                    continue;
                }
            } elseif ($dlCids !== null && isset($dlCids[$cid])) {
                // وبلاگ: نوشته‌های دستهٔ دانلود، وبلاگ نیستند
                continue;
            }

            $path = str_replace(['[slug:digital]', '[slug]', '[cid:digital]', '[cid]'],
                [(string)$row['slug'], (string)$row['slug'], (string)$cid, (string)$cid], $routeUrl);
            $text = (string)$row['text'];
            if (strpos($text, '<!--markdown-->') === 0) {
                $text = substr($text, 15);
            }

            // تصویر شاخص: فیلد → اولین تصویر متن → پیش‌فرض
            $thumb = '';
            foreach (['thumb', 'cover', 'img', 'thumbnail', 'banner'] as $key) {
                if (isset($fields[$key]) && trim($fields[$key]) !== '') {
                    $thumb = shabaneh_resolve_url(trim($fields[$key]));
                    break;
                }
            }
            if ($thumb === '' && preg_match('#<img[^>]*\bsrc=["\']([^"\']+)["\']#iu', $text, $m)) {
                $thumb = shabaneh_resolve_url($m[1]);
            } elseif ($thumb === '' && preg_match('#!\[[^\]]*\]\(\s*<?([^)\s>]+)[^)]*\)#iu', $text, $m)) {
                $thumb = shabaneh_resolve_url($m[1]);
            }
            if ($thumb === '') {
                $thumb = shabaneh_asset('img/default-cover.jpg');
            }

            $out[] = [
                'title'    => (string)$row['title'],
                'url'      => $siteBase . '/' . ltrim($path, '/'),
                'created'  => (int)$row['created'],
                'excerpt'  => trim(strip_tags($text)),
                'thumb'    => $thumb,
                'readingTime' => $fields['readingTime'] ?? '',
                'views'    => $hasStats ? (int)($row['views'] ?? 0) : 0,
                'download' => $dl,
            ];
            if (count($out) >= $count) {
                break;
            }
        }
    } catch (\Throwable $e) {
    }
    return $out;
}

/** نوشته‌های مرتبط بر اساس دستهٔ مشترک */
function shabaneh_related_posts($archive, int $count = 3): array
{
    $out = [];
    try {
        $cid = (int)$archive->cid;
        if ($cid < 1) {
            return $out;
        }
        $category = $archive->getCategory ? $archive->getCategory() : [];
        $mid = 0;
        if (is_array($category) && isset($category[0]['mid'])) {
            $mid = (int)$category[0]['mid'];
        }
        if ($mid < 1) {
            return $out;
        }

        $db = \Typecho\Db::get();
        $rows = $db->fetchAll(
            $db->select('table.contents.cid', 'table.contents.title', 'table.contents.slug', 'table.contents.created')
                ->from('table.contents')
                ->join('table.relationships', 'table.contents.cid = table.relationships.cid')
                ->where('table.relationships.mid = ?', $mid)
                ->where('table.contents.cid <> ?', $cid)
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', \Widget\Options::alloc()->time)
                ->where('table.contents.type = ?', 'post')
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit($count)
        );

        foreach ($rows as $row) {
            $route = \Widget\Options::alloc()->routingTable['post'];
            $path = str_replace('[slug:digital]', (string)$row['slug'], is_string($route) ? $route : ($route['url'] ?? ''));
            $path = str_replace(['[slug]', '[cid:digital]', '[cid]'], [(string)$row['slug'], (string)$row['cid'], (string)$row['cid']], $path);
            $out[] = [
                'title' => $row['title'],
                'url' => rtrim((string)\Widget\Options::alloc()->siteUrl, '/') . '/' . ltrim($path, '/'),
                'created' => (int)$row['created'],
            ];
        }
    } catch (\Throwable $e) {
    }
    return $out;
}

/** آدرس فهرست مقالات (مسیر آرشیو وبلاگ) */
function shabaneh_blog_url(): string
{
    $custom = shabaneh_opt_raw('shabanehBlogUrl');
    if ($custom !== null) {
        $custom = trim($custom);
        if ($custom !== '') {
            return shabaneh_resolve_url($custom);
        }
    }
    try {
        return rtrim((string)\Widget\Options::alloc()->siteUrl, '/') . '/blog/';
    } catch (\Throwable $e) {
        return '#';
    }
}

/* ================================================================
 *  ۸) وضعیت باز/بسته و ساعات کاری
 * ================================================================ */

/** اجزای ساعت فعلی به وقت تهران */
function shabaneh_now_tehran(): array
{
    try {
        $dt = new \DateTimeImmutable('now', new \DateTimeZone('Asia/Tehran'));
        return [
            'h' => (int)$dt->format('G'),
            'i' => (int)$dt->format('i'),
            's' => (int)$dt->format('s'),
            'H' => $dt->format('H'),
            'i_str' => $dt->format('i'),
            'date' => $dt->format('Y-m-d'),
            'weekday' => (int)$dt->format('w'), // 0=یکشنبه
            'ts' => $dt->getTimestamp(),
        ];
    } catch (\Throwable $e) {
        $t = getdate();
        return [
            'h' => (int)$t['hours'], 'i' => (int)$t['minutes'], 's' => (int)$t['seconds'],
            'H' => sprintf('%02d', (int)$t['hours']), 'i_str' => sprintf('%02d', (int)$t['minutes']),
            'date' => date('Y-m-d'), 'weekday' => (int)$t['wday'], 'ts' => time(),
        ];
    }
}

/** پارس ساعات کاری: «open | close» (مثل «8 | 24») — باز ۰ تا بسته ۲۴ یعنی شبانه‌روزی */
function shabaneh_hours(): array
{
    $open  = shabaneh_to_en_digits(shabaneh_opt('shabanehOpenHour', '8'));
    $close = shabaneh_to_en_digits(shabaneh_opt('shabanehCloseHour', '24'));
    $open  = max(0, min(23, (int)$open));
    $close = max(1, min(24, (int)$close));
    if ($close <= $open) {
        // بازهٔ نامعتبر → پیش‌فرض: ۸ صبح تا ۱۲ شب
        $open = 8;
        $close = 24;
    }
    return ['open' => $open, 'close' => $close];
}

/** آیا کافی‌نت شبانه‌روزی است؟ (باز ۰ / بسته ۲۴) */
function shabaneh_is_24h(): bool
{
    $hours = shabaneh_hours();
    return $hours['open'] === 0 && $hours['close'] >= 24;
}

/** آیا کافی‌نت الان باز است؟ (به وقت تهران) */
function shabaneh_is_open(): bool
{
    if (shabaneh_is_24h()) {
        return true;
    }
    $hours = shabaneh_hours();
    $now = shabaneh_now_tehran();
    $cur = $now['h'] + ($now['i'] >= 30 ? 0.5 : 0); // دقت نیم‌ساعت
    return ($cur >= $hours['open'] && $cur < $hours['close']);
}

/** متن ساعات کاری برای نمایش: «۸ صبح تا ۱۲ شب» یا «شبانه‌روزی» */
function shabaneh_hours_label(): string
{
    $hours = shabaneh_hours();
    if (shabaneh_is_24h()) {
        return 'شبانه‌روزی';
    }
    $label = static function (int $h): string {
        if ($h === 24 || $h === 0) {
            return '۱۲ شب';
        }
        if ($h < 5) {
            return toPersianNumbers($h) . ' بامداد';
        }
        if ($h < 12) {
            return toPersianNumbers($h) . ' صبح';
        }
        if ($h === 12) {
            return '۱۲ ظهر';
        }
        return toPersianNumbers($h - 12) . ($h < 17 ? ' بعدازظهر' : ($h < 20 ? ' عصر' : ' شب'));
    };
    return 'از ' . $label($hours['open']) . ' تا ' . $label($hours['close']);
}

/* ================================================================
 *  ۹) لوگو
 * ================================================================ */

/** آدرس لوگو: تنظیمات → فایل محلی img/logo.png → خالی (آیکون پیش‌فرض) */
function shabaneh_logo_url(): string
{
    $setting = shabaneh_opt_raw('shabanehLogoUrl');
    if ($setting !== null) {
        $setting = trim($setting);
        if ($setting !== '') {
            return shabaneh_resolve_url($setting);
        }
    }

    $local = __TYPECHO_ROOT_DIR__ . '/usr/themes/' . basename(__DIR__) . '/img/logo.png';
    if (is_file($local)) {
        return shabaneh_asset('img/logo.png');
    }
    return '';
}

/* ================================================================
 *  ۱۰) راه‌انداز پوسته
 * ================================================================ */

function themeInit($archive)
{
    /* نقاط پایانی پشتیبان‌گیری/بازیابی تنظیمات (قبل از هر خروجی) —
       با سوپرگلوبال‌ها تا از دسترسی protected بی‌نیاز باشد.
       بازیابی ممکن است با پارامتر URL (?shabanehImport=1) یا فیلد POST فرستاده شود. */
    if (isset($_GET['shabanehExport'])) {
        shabaneh_backup_export_endpoint();
    }
    if (isset($_GET['shabanehImport']) || isset($_POST['shabanehImport'])) {
        shabaneh_backup_import_endpoint();
    }

    // هوک شمارش بازدید قبل از رندر
    try {
        \Typecho\Plugin::factory('Widget\Archive')->beforeRender = 'shabaneh_count_view';
    } catch (\Throwable $e) {
    }

    /*
     * نکتهٔ مهم: پراپرتی‌های request و parameter ویجت «محافظت‌شده» (protected) هستند و
     * از یک تابع سراسری، Typecho\Widget::__get() برایشان null برمی‌گرداند؛ یعنی الگوی
     * $archive->request->isPost() هرگز اجرا نمی‌شود. برای همین، کل این بخش داخل یک
     * Closure متصل به اسکوپ کلاس Typecho\Widget اجرا می‌شود تا PHP اجازهٔ دسترسی بدهد.
     */
    try {
        \Closure::bind(function () {
            /** @var \Widget\Archive $this */

            // نقطهٔ پایانی AJAX لایک
            if ($this->request->isPost() && (string)$this->request->get('shabanehLike', '') !== '') {
                shabaneh_handle_like($this->request);
            }

            /*
             * فهرست وبلاگ روی مسیر آرشیو (پیش‌فرض /blog/):
             * هستهٔ تایپ‌رینیو مسیر archive را با ۴۰۴ می‌بندد؛ در حالت پیش‌فرض
             * (صفحهٔ نخست = نوشته‌های اخیر) نوع درخواست را به index تبدیل می‌کنیم تا
             * فهرست مقالات همیشه در /blog/ رندر شود و منوی «مقالات» کار کند.
             */
            $shabanehRouteType = (string)$this->parameter->type;
            if ($shabanehRouteType === 'archive' || $shabanehRouteType === 'archive_page') {
                $shabanehFrontPage = 'recent';
                $shabanehFrontArchive = 0;
                try {
                    $shabanehFrontPage = (string)\Widget\Options::alloc()->frontPage;
                    $shabanehFrontArchive = (int)\Widget\Options::alloc()->frontArchive;
                } catch (\Throwable $e) {
                }
                if ($shabanehFrontPage === 'recent' || $shabanehFrontArchive !== 1) {
                    $this->parameter->type = ($shabanehRouteType === 'archive_page') ? 'index_page' : 'index';
                }
            }
        }, $archive, \Typecho\Widget::class)();
    } catch (\Throwable $e) {
    }
}

/* ================================================================
 *  ۱۰-ب) پشتیبان‌گیری و بازیابی تنظیمات پوسته (JSON)
 * ================================================================
 *  هستهٔ تایپ‌رینیو هنگام تغییر/غیرفعال‌کردن پوسته، رکورد تنظیمات پوستهٔ
 *  قبلی را از دیتابیس حذف می‌کند (Widget\Themes\Edit::changeTheme)؛ برای
 *  همین دو نقطهٔ پایانی روی خود سایت تعبیه شده است:
 *   - خروجی:  siteUrl/?shabanehExport=1  → دانلود فایل JSON (فقط مدیر)
 *   - بازیابی: POST فایل به همان آدرس با فیلد shabanehImport (فقط مدیر)
 *  بازیابی فقط کلیدهای معتبرِ فرم پوسته را می‌پذیرد (لیست‌سفید).
 * ================================================================ */

/** آیا درخواست‌دهندهٔ فعلی مدیر سایت است؟ */
function shabaneh_is_admin_request(): bool
{
    try {
        $user = \Widget\User::alloc();
        return (bool)$user->hasLogin() && $user->pass('administrator', true);
    } catch (\Throwable $e) {
        return false;
    }
}

/** تنظیمات ذخیره‌شدهٔ فعلی پوسته (آرایهٔ name => value) */
function shabaneh_stored_settings(): array
{
    try {
        $raw = (string)\Widget\Options::alloc()->{'theme:shabaneh'};
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    } catch (\Throwable $e) {
        return [];
    }
}

/** مقدارهای پیش‌فرض فیلدهای فرم پوسته (همراه کلیدهای معتبر) */
function shabaneh_config_defaults(): array
{
    try {
        $form = new \Typecho\Widget\Helper\Form();
        themeConfig($form);
        $values = $form->getValues();
        return is_array($values) ? $values : [];
    } catch (\Throwable $e) {
        return [];
    }
}

/** ساختار فایل پشتیبان (آرایهٔ خروجی JSON) */
function shabaneh_backup_export_array(): array
{
    return [
        '_meta' => [
            'theme'      => 'shabaneh',
            'version'    => SHABANEH_VERSION,
            'exportedAt' => date('c'),
            'exportedAtJalali' => shabaneh_jalali_date(time(), 'Y/m/d — H:i'),
        ],
        'settings' => shabaneh_stored_settings(),
    ];
}

/**
 * اعمال فایل پشتیبان: فقط کلیدهای معتبر فرم پوسته پذیرفته می‌شود؛
 * کلیدهای ناموجود به پیش‌فرض برمی‌گردند. خروجی: [ok(bool), message].
 */
function shabaneh_apply_backup(array $data): array
{
    $settings = $data['settings'] ?? null;
    if (!is_array($settings)) {
        return [false, 'فایل پشتیبان معتبر نیست (بخش settings یافت نشد).'];
    }
    if (isset($data['_meta']['theme']) && (string)$data['_meta']['theme'] !== 'shabaneh') {
        return [false, 'این فایل پشتیبان متعلق به پوستهٔ دیگری است.'];
    }
    $defaults = shabaneh_config_defaults();
    if (empty($defaults)) {
        return [false, 'فرم تنظیمات پوسته در دسترس نیست.'];
    }

    $merged = $defaults;
    $count = 0;
    foreach (array_keys($defaults) as $key) {
        if (array_key_exists($key, $settings) && is_scalar($settings[$key])) {
            $merged[$key] = (string)$settings[$key];
            $count++;
        }
    }

    try {
        $db = \Typecho\Db::get();
        $value = \Typecho\Common::jsonEncode($merged, 0, '{}');
        $exists = $db->fetchRow($db->select('name')->from('table.options')->where('name = ?', 'theme:shabaneh'));
        if (!empty($exists)) {
            $db->query($db->update('table.options')->rows(['value' => $value])->where('name = ?', 'theme:shabaneh'));
        } else {
            $db->query($db->insert('table.options')->rows(['name' => 'theme:shabaneh', 'value' => $value, 'user' => 0]));
        }
    } catch (\Throwable $e) {
        return [false, 'ذخیره‌سازی در دیتابیس ناموفق بود.'];
    }
    return [true, 'تنظیمات با موفقیت بازیابی شد (' . toPersianNumbers((string)$count) . ' مورد).'];
}

/** نقطهٔ پایانی خروجی: دانلود JSON تنظیمات (فقط مدیر) */
function shabaneh_backup_export_endpoint(): void
{
    if (!shabaneh_is_admin_request()) {
        /* توجه: تایپ‌رینیو هنگام خروج (ob_start callback) وضعیت HTTP را با ۲۰۰
           بازنویسی می‌کند؛ برای همین وضعیت از خودِ Response ست می‌شود. */
        try {
            \Typecho\Response::getInstance()->setStatus(403);
        } catch (\Throwable $e) {
            http_response_code(403);
        }
        header('Content-Type: text/plain; charset=utf-8');
        exit('دسترسی مجاز نیست.');
    }
    $name = 'shabaneh-backup-' . shabaneh_jalali_date(time(), 'Ymd-Hi') . '.json';
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $name . '"');
    header('Cache-Control: no-store');
    echo json_encode(shabaneh_backup_export_array(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** نقطهٔ پایانی بازیابی: بارگزاری فایل JSON (فقط مدیر + هم‌مبدأ) */
function shabaneh_backup_import_endpoint(): void
{
    header('Content-Type: application/json; charset=utf-8');
    if (!shabaneh_is_admin_request()) {
        try {
            \Typecho\Response::getInstance()->setStatus(403);
        } catch (\Throwable $e) {
            http_response_code(403);
        }
        exit('{"ok":false,"message":"دسترسی مجاز نیست."}');
    }
    // محافظت سادهٔ هم‌مبدأ (CSRF) برای درخواست‌های دارای Referer
    $referer = (string)($_SERVER['HTTP_REFERER'] ?? '');
    if ($referer !== '') {
        $refHost = (string)parse_url($referer, PHP_URL_HOST);
        $siteHost = (string)parse_url((string)\Widget\Options::alloc()->siteUrl, PHP_URL_HOST);
        if ($refHost !== '' && $siteHost !== '' && strcasecmp($refHost, $siteHost) !== 0) {
            try {
                \Typecho\Response::getInstance()->setStatus(403);
            } catch (\Throwable $e) {
                http_response_code(403);
            }
            exit('{"ok":false,"message":"درخواست از دامنهٔ دیگری ارسال شده است."}');
        }
    }
    $file = $_FILES['shabanehBackupFile'] ?? null;
    if (!is_array($file) || !isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        exit('{"ok":false,"message":"فایلی انتخاب نشده است."}');
    }
    if ((int)($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        exit('{"ok":false,"message":"بارگزاری فایل ناموفق بود."}');
    }
    if ((int)($file['size'] ?? 0) > 1024 * 1024) {
        exit('{"ok":false,"message":"حجم فایل بیش از حد مجاز است (۱ مگابایت)."}');
    }
    $raw = file_get_contents($file['tmp_name']);
    $data = json_decode((string)$raw, true);
    if (!is_array($data)) {
        exit('{"ok":false,"message":"فایل JSON معتبر نیست."}');
    }
    [$ok, $msg] = shabaneh_apply_backup($data);
    exit(json_encode(['ok' => $ok, 'message' => $msg], JSON_UNESCAPED_UNICODE));
}

/** HTML جعبهٔ پشتیبان‌گیری/بازیابی برای صفحهٔ تنظیمات پوسته */
function shabaneh_backup_ui_html(): string
{
    try {
        $site = rtrim((string)\Widget\Options::alloc()->siteUrl, '/');
    } catch (\Throwable $e) {
        $site = '';
    }
    $exportUrl = $site . '/?shabanehExport=1';
    $importUrl = $site . '/?shabanehImport=1';

    return '<div class="shabaneh-backup" dir="rtl">'
        . '<div class="shabaneh-backup-row">'
        . '<a class="shabaneh-backup-btn is-dl" href="' . htmlspecialchars($exportUrl, ENT_QUOTES) . '" download>'
        . 'دانلود فایل پشتیبان (JSON)'
        . '</a>'
        . '<span class="shabaneh-backup-hint">همهٔ تنظیمات همین صفحه در یک فایل ذخیره می‌شود.</span>'
        . '</div>'
        . '<div class="shabaneh-backup-row">'
        . '<input type="file" id="shabanehBackupFile" name="shabanehBackupFile" accept="application/json,.json">'
        . '<button type="button" class="shabaneh-backup-btn is-restore" id="shabanehRestoreBtn">بازیابی از فایل</button>'
        . '<span class="shabaneh-backup-hint">فایل پشتیبان را انتخاب و بازیابی کنید؛ تنظیمات فعلی جایگزین می‌شود.</span>'
        . '</div>'
        . '<div class="shabaneh-backup-note">اگر پوسته را غیرفعال یا تغییر دهید، تایپ‌رینیو تنظیمات آن را حذف می‌کند — '
        . 'قبل از هر تغییر، فایل پشتیبان بگیرید تا با یک کلیک قابل بازگردانی باشد.</div>'
        . '<script>(function(){'
        . 'var btn=document.getElementById("shabanehRestoreBtn"),inp=document.getElementById("shabanehBackupFile");'
        . 'if(!btn||!inp){return;}'
        . 'btn.addEventListener("click",function(){'
        . 'var f=inp.files&&inp.files[0];'
        . 'if(!f){window.alert("ابتدا فایل پشتیبان JSON را انتخاب کنید.");return;}'
        . 'if(!/\\.json$/i.test(f.name)&&f.type!=="application/json"){window.alert("فقط فایل JSON پذیرفته می‌شود.");return;}'
        . 'var orig=btn.textContent;btn.disabled=true;btn.textContent="در حال بازیابی…";'
        . 'var fd=new FormData();fd.append("shabanehBackupFile",f);'
        . 'fetch(' . json_encode($importUrl) . ',{method:"POST",body:fd,credentials:"same-origin"})'
        . '.then(function(r){return r.text();})'
        . '.then(function(t){var d={};try{d=JSON.parse(t);}catch(e){}'
        . 'window.alert(d.message||(d.ok?"انجام شد.":"پاسخ نامعتبر از سرور."));'
        . 'if(d.ok){window.location.reload();}else{btn.disabled=false;btn.textContent=orig;}})'
        . '.catch(function(){window.alert("ارتباط با سرور برقرار نشد.");btn.disabled=false;btn.textContent=orig;});'
        . '});})();</script>'
        . '<style>'
        . '.shabaneh-backup{direction:rtl;text-align:right;display:flex;flex-direction:column;gap:12px;padding:2px 0;}'
        . '.shabaneh-backup-row{display:flex;align-items:center;gap:10px;flex-wrap:wrap;}'
        . '.shabaneh-backup-btn{display:inline-flex;align-items:center;gap:7px;padding:9px 18px;border-radius:10px;'
        . 'font-size:13px;font-weight:700;cursor:pointer;border:1.6px solid transparent;transition:all .2s;}'
        . '.shabaneh-backup-btn.is-dl{background:#f59e0b;color:#3b2a05;border-color:#f59e0b;}'
        . '.shabaneh-backup-btn.is-dl:hover{background:#d97706;}'
        . '.shabaneh-backup-btn.is-restore{background:#fff;color:#92400e;border-color:#f5c04e;}'
        . '.shabaneh-backup-btn.is-restore:hover{background:#fef3c7;}'
        . '.shabaneh-backup-btn:disabled{opacity:.6;cursor:default;}'
        . '.shabaneh-backup-hint{font-size:12px;color:#8a8a8a;}'
        . '.shabaneh-backup-note{font-size:12px;line-height:2;color:#7a6a4f;'
        . 'background:#fffbeb;border:1px solid #fde68a;border-radius:10px;padding:9px 13px;}'
        . '#shabanehBackupFile{max-width:300px;}'
        . '</style>'
        . '</div>';
}

/* ================================================================
 *  ۱۱) فرم تنظیمات پوسته
 * ================================================================ */

function themeConfig($form)
{
    /* ---------- بخش ۱: عمومی و هویت ---------- */

    $cafeName = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehCafeName',
        null,
        'کافی‌نت شبانه',
        _t('نام کافی‌نت'),
        _t('نام مرکز در هدر، فوتر و عنوان صفحهٔ اول نمایش داده می‌شود.')
    );
    $form->addInput($cafeName->addRule('xssCheck', _t('لطفاً نام معتبر وارد کنید')));

    $tagline = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehTagline',
        null,
        'مرکز خدمات اینترنتی و دانلود',
        _t('شعار کوتاه'),
        _t('زیر نام کافی‌نت در هدر و جاهای کم‌رنگ‌تر نمایش داده می‌شود.')
    );
    $form->addInput($tagline->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $logoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehLogoUrl',
        null,
        null,
        _t('آدرس لوگو'),
        _t('آدرس تصویر لوگو (اختیاری). اگر خالی باشد و فایل img/logo.png داخل پوسته باشد از آن استفاده می‌شود؛ در غیر این صورت آیکون فنجان قهوه نمایش داده می‌شود.')
    );
    $form->addInput($logoUrl->addRule('xssCheck', _t('لطفاً یک آدرس معتبر وارد کنید')));

    $primaryColor = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehPrimaryColor',
        null,
        '#f59e0b',
        _t('رنگ اصلی (کهربایی کافه)'),
        _t('کد HEX مثل #f59e0b — برای دکمه‌ها، لینک‌ها و تاکیدها.')
    );
    $form->addInput($primaryColor->addRule('xssCheck', _t('کد رنگ HEX وارد کنید (مثل #f59e0b)')));

    $secondaryColor = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehSecondaryColor',
        null,
        '#92400e',
        _t('رنگ دوم (قهوه‌ای تیره)'),
        _t('کد HEX مثل #92400e — برای گرادیان‌ها و نوارهای برجسته.')
    );
    $form->addInput($secondaryColor->addRule('xssCheck', _t('کد رنگ HEX وارد کنید (مثل #92400e)')));

    $showTopbar = new \Typecho\Widget\Helper\Form\Element\Radio(
        'shabanehShowTopbar',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('نوار بالای هدر'),
        _t('نوار باریک بالای هدر شامل تلفن، ساعات کاری و شبکه‌های اجتماعی.')
    );
    $form->addInput($showTopbar);

    /* ---------- بخش ۲: ساعات کاری ---------- */

    $openHour = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehOpenHour',
        null,
        '8',
        _t('ساعت باز شدن'),
        _t('عدد ۰ تا ۲۳ — مثلاً ۸ یعنی ۸ صبح. برای شبانه‌روزی، باز را ۰ و بسته را ۲۴ بگذارید.')
    );
    $form->addInput($openHour->addRule('xssCheck', _t('عدد ۰ تا ۲۳ وارد کنید')));

    $closeHour = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehCloseHour',
        null,
        '24',
        _t('ساعت بسته شدن'),
        _t('عدد ۱ تا ۲۴ — مثلاً ۲۴ یعنی ۱۲ شب. وضعیت «اکنون باز است» هیرو به وقت تهران و بر اساس این دو مقدار محاسبه می‌شود.')
    );
    $form->addInput($closeHour->addRule('xssCheck', _t('عدد ۱ تا ۲۴ وارد کنید')));

    /* ---------- بخش ۳: هیرو ---------- */

    $heroBadge = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehHeroBadge',
        null,
        'پشتیبانی و رفع مشکل در تمام ساعات',
        _t('برچسب بالای عنوان هیرو'),
        _t('متن کوتاه بج بالای عنوان اصلی صفحهٔ اول.')
    );
    $form->addInput($heroBadge->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $heroTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehHeroTitle',
        null,
        'همهٔ خدمات اینترنتی، زیر یک سقف',
        _t('عنوان اصلی هیرو'),
        _t('عنوان بزرگ صفحهٔ اول؛ کلمهٔ ستاره‌دار (*) کهربایی رنگ می‌شود. مثال: خدمات اینترنتی، *بی‌دردسر* و سریع')
    );
    $form->addInput($heroTitle->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $heroSubtitle = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'shabanehHeroSubtitle',
        null,
        "از چاپ و اسکن تا ثبت‌نام‌های اینترنتی و دانلود جزوات و مقالات آماده؛\nبا اینترنت پرسرعت و سیستم‌های به‌روز، کارهای اینترنتی‌تان را سریع و مطمئن انجام دهید.",
        _t('زیرعنوان هیرو'),
        _t('متن معرفی کافی‌نت زیر عنوان اصلی.')
    );
    $form->addInput($heroSubtitle);

    $heroImage = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehHeroImage',
        null,
        null,
        _t('تصویر پنل هیرو'),
        _t('آدرس تصویر کافی‌نت برای پنل سمت چپ (اختیاری؛ خالی = img/hero.jpg پوسته).')
    );
    $form->addInput($heroImage->addRule('xssCheck', _t('لطفاً یک آدرس معتبر وارد کنید')));

    $heroBtn1Text = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehHeroBtn1Text',
        null,
        'دانلود مقالات',
        _t('متن دکمهٔ اول هیرو'),
        _t('دکمهٔ اصلی؛ پیشنهاد: دانلود مقالات.')
    );
    $form->addInput($heroBtn1Text->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $heroBtn1Url = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehHeroBtn1Url',
        null,
        '#downloads',
        _t('آدرس دکمهٔ اول هیرو'),
        _t('مثال: #downloads یا آدرس کامل صفحه.')
    );
    $form->addInput($heroBtn1Url->addRule('xssCheck', _t('لطفاً آدرس معتبر وارد کنید')));

    $heroBtn2Text = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehHeroBtn2Text',
        null,
        'مشاهدهٔ تعرفه‌ها',
        _t('متن دکمهٔ دوم هیرو'),
        _t('دکمهٔ فرعی؛ پیشنهاد: مشاهدهٔ تعرفه‌ها.')
    );
    $form->addInput($heroBtn2Text->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $heroBtn2Url = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehHeroBtn2Url',
        null,
        '#tariff',
        _t('آدرس دکمهٔ دوم هیرو'),
        _t('مثال: #tariff یا آدرس کامل صفحه.')
    );
    $form->addInput($heroBtn2Url->addRule('xssCheck', _t('لطفاً آدرس معتبر وارد کنید')));

    $heroStats = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'shabanehHeroStats',
        null,
        "100 | سرعت اینترنت (مگابیت)\n12 | سیستم به‌روز و سریع\n24/7 | پشتیبانی پاسخگو\n3500+ | دانش‌آموز و دانشجو",
        _t('آمار کوچک هیرو'),
        _t('هر خط: «عدد | عنوان» — حداکثر ۴ مورد.')
    );
    $form->addInput($heroStats);

    $heroUptime = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehHeroUptime',
        null,
        '99.9',
        _t('درصد پایداری اینترنت (چیپ روی تصویر هیرو)'),
        _t('عدد بدون علامت ٪ — نمایش داده‌شده روی تصویر پنل هیرو.')
    );
    $form->addInput($heroUptime->addRule('xssCheck', _t('عدد وارد کنید')));

    /* ---------- بخش ۴: خدمات ---------- */

    $servicesTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehServicesTitle',
        null,
        'خدمات شبانه',
        _t('عنوان بخش خدمات'),
        _t('عنوان بخش کارت‌های خدمات.')
    );
    $form->addInput($servicesTitle->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $servicesText = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'shabanehServicesText',
        null,
        "wifi | اینترنت پرسرعت | اینترنت پایدار و بدون قطعی روی همهٔ سیستم‌ها | مناسب کارهای حساس\nprinter | چاپ و پرینت | چاپ سیاه‌وسفید و رنگی اسناد، تصاویر و صفحات وب | کاغذ A4 و A5\nscan-line | اسکن مدارک | اسکن رنگی و سیاه‌وسفید مدارک و برگه‌ها با کیفیت بالا | خروجی PDF و عکس\nkeyboard | تایپ و تحقیق | تایپ پایان‌نامه، جزوه و تحقیقات دانش‌آموزی و دانشجویی | تحویل سریع\nclipboard-list | ثبت‌نام‌های اینترنتی | ثبت‌نام کنکور، دانشگاه، بیمه، یارانه و پروانه کسب | بدون معطلی\ngamepad-2 | گیمینگ آنلاین | سیستم‌های قدرتمند با پین مناسب بازی‌های آنلاین | راگ صفر",
        _t('کارت‌های خدمات'),
        _t('هر خط: «آیکون | عنوان | توضیح | متن پابرگ» — آیکون‌ها از مجموعهٔ Lucide پوسته.')
    );
    $form->addInput($servicesText);

    /* ---------- بخش ۵: تعرفهٔ خدمات ---------- */

    $tariffTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehTariffTitle',
        null,
        'تعرفهٔ خدمات',
        _t('عنوان بخش تعرفه'),
        _t('عنوان جدول قیمت خدمات.')
    );
    $form->addInput($tariffTitle->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $tariffSubtitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehTariffSubtitle',
        null,
        'قیمت‌ها شفاف و اعلام‌شده؛ بدون هزینهٔ پنهان',
        _t('زیرعنوان بخش تعرفه'),
        _t('متن کوتاه زیر عنوان بخش تعرفه.')
    );
    $form->addInput($tariffSubtitle->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $tariffRows = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'shabanehTariffRows',
        null,
        "wifi | استفاده از اینترنت | سیستم سریع با مانیتور مناسب | ربع ساعت | ۴٬۰۰۰\nwifi | استفاده از اینترنت | نیم‌ساعت | نیم ساعت | ۶٬۰۰۰\nwifi | استفاده از اینترنت | یک‌ساعت کامل | هر ساعت | ۱۰٬۰۰۰\nprinter | چاپ سیاه‌وسفید | کاغذ A4 معمولی | هر برگ | ۱٬۰۰۰\nprinter | چاپ رنگی | کاغذ A4 گلاسه | هر برگ | ۳٬۰۰۰\nscan-line | اسکن | خروجی PDF یا تصویر | هر برگ | ۲٬۰۰۰\nkeyboard | تایپ فارسی | با صفحه‌آرایی و ویرایش | هر صفحه | ۸٬۰۰۰\nclipboard-list | ثبت‌نام اینترنتی | کنکور، دانشگاه، بیمه و… | هر مورد | ۱۵٬۰۰۰",
        _t('ردیف‌های جدول تعرفه'),
        _t('هر خط: «آیکون | خدمت | جزئیات | واحد | قیمت» — قیمت‌ها به تومان.')
    );
    $form->addInput($tariffRows);

    $tariffNote = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehTariffNote',
        null,
        'نرخ‌ها بر اساس نرخنامهٔ اتحادیهٔ فناوران رایانه تنظیم شده و ممکن است تغییر کند.',
        _t('یادداشت زیر جدول'),
        _t('متن توضیح زیر جدول تعرفه.')
    );
    $form->addInput($tariffNote->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    /* ---------- بخش ۶: مقالات و دانلودها ---------- */

    // دسته‌های موجود برای انتخاب «دستهٔ مقالات دانلودی»
    $shabanehCategoryOptions = ['0' => _t('خودکار — نوشته‌های دارای فیلد «لینک دانلود»')];
    try {
        $shabanehDb = \Typecho\Db::get();
        $shabanehCats = $shabanehDb->fetchAll(
            $shabanehDb->select('mid', 'name')
                ->from('table.metas')
                ->where('type = ?', 'category')
                ->order('table.metas.order', \Typecho\Db::SORT_ASC)
        );
        foreach ((array)$shabanehCats as $shabanehCat) {
            $shabanehCategoryOptions[(string)$shabanehCat['mid']] =
                $shabanehCat['name'] . ' (' . toPersianNumbers($shabanehCat['mid']) . ')';
        }
    } catch (\Throwable $e) {
    }

    $dlCategory = new \Typecho\Widget\Helper\Form\Element\Select(
        'shabanehDownloadCategory',
        $shabanehCategoryOptions,
        '0',
        _t('دستهٔ مقالات دانلودی'),
        _t('با انتخاب یک دسته، بخش «مقالات و دانلودها»، دکمهٔ «دانلود مقالات» و آیتم «دانلودها»ی منو همگی به همان دسته متصل می‌شوند و فقط نوشته‌های همان دسته به‌عنوان مقالات دانلودی نمایش داده می‌شوند. در حالت «خودکار» نوشته‌هایی که فیلد «لینک دانلود» داشته باشند نمایش داده می‌شوند.')
    );
    $form->addInput($dlCategory);

    $dlTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehDownloadsTitle',
        null,
        'مقالات و دانلودها',
        _t('عنوان بخش دانلودها'),
        _t('در حالت «خودکار» نوشته‌هایی که فیلد «لینک دانلود» داشته باشند به‌صورت خودکار این‌جا نمایش داده می‌شوند؛ در حالت دسته‌ای، آخرین نوشته‌های دستهٔ منتخب.')
    );
    $form->addInput($dlTitle->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $dlSubtitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehDownloadsSubtitle',
        null,
        'جزوه‌ها، کاربرگه‌ها و تحقیق‌های آمادهٔ چاپ — رایگان یا ویژهٔ اعضا',
        _t('زیرعنوان بخش دانلودها'),
        _t('متن کوتاه زیر عنوان بخش دانلودها.')
    );
    $form->addInput($dlSubtitle->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $dlCount = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehDownloadsCount',
        null,
        '6',
        _t('تعداد کارت دانلود'),
        _t('حداکثر تعداد نوشتهٔ دانلودی صفحهٔ اول (۱ تا ۱۲).')
    );
    $form->addInput($dlCount->addRule('xssCheck', _t('عدد وارد کنید')));

    /* ---------- بخش ۷: چرا شبانه ---------- */

    $aboutTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehAboutTitle',
        null,
        'چرا کافی‌نت شبانه؟',
        _t('عنوان بخش «چرا شبانه»'),
        _t('عنوان بخش معرفی با تصویر.')
    );
    $form->addInput($aboutTitle->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $aboutText = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'shabanehAboutText',
        null,
        "شبانه از سال ۱۳۹۲ در محله، کنار شماست؛ جایی برای انجام سریع کارهای اینترنتی.\nما ساده‌ترین راه را برایتان می‌خواهیم: بدون نوبت‌دهی پیچیده و بدون هزینهٔ پنهان.",
        _t('متن بخش «چرا شبانه»'),
        _t('متن معرفی کافی‌نت کنار تصویر.')
    );
    $form->addInput($aboutText);

    $aboutImage = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehAboutImage',
        null,
        null,
        _t('تصویر بخش «چرا شبانه»'),
        _t('آدرس تصویر (اختیاری؛ خالی = img/about.jpg پوسته).')
    );
    $form->addInput($aboutImage->addRule('xssCheck', _t('لطفاً یک آدرس معتبر وارد کنید')));

    $aboutBadge = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehAboutBadge',
        null,
        'از ۱۳۹۲ در خدمت شما',
        _t('برچسب شناور روی تصویر'),
        _t('متن کارت شناور گوشهٔ تصویر.')
    );
    $form->addInput($aboutBadge->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $aboutFeatures = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'shabanehAboutFeatures',
        null,
        "zap | اینترنت بدون قطعی | دو خط اختصاصی با پشتیبانِ همیشه‌روشن\nmonitor | سیستم‌های به‌روز | سخت‌افزار تازه و مانیتورهای چشم‌نواز\nshield-check | امنیت اطلاعات | مرور امن و پاک‌شدن خودکار اطلاعات پس از هر نشست\nusers | همراه‌یادگیرنده | کارکنی که صبورانه راهنماییتان می‌کند",
        _t('ویژگی‌های «چرا شبانه»'),
        _t('هر خط: «آیکون | عنوان | توضیح» — ۴ مورد پیشنهاد می‌شود.')
    );
    $form->addInput($aboutFeatures);

    $glanceStats = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'shabanehGlanceStats',
        null,
        "دانلود فایل | ۱۲ هزار | file-down\nمشتری راضی | ۹۸٪ | heart\nسال سابقه | ۱۳ | award\nساعت کار در هفته | ۱۶۸ | clock",
        _t('نوار «شبانه در یک نگاه»'),
        _t('هر خط: «عنوان | مقدار | آیکون» — مقدار متن آزاد است (مثل ۹۸٪ یا ۱۶۸).')
    );
    $form->addInput($glanceStats);

    /* ---------- بخش ۸: نظرات مشتریان ---------- */

    $testimonialsTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehTestimonialsTitle',
        null,
        'مشتریان شبانه چه می‌گویند',
        _t('عنوان بخش نظرات'),
        _t('عنوان کاروسل نظرات مشتریان.')
    );
    $form->addInput($testimonialsTitle->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $testimonials = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'shabanehTestimonials',
        null,
        "امیر رضایی | دانشجو | برای چاپ پایان‌نامه‌ام همیشه به شبانه می‌آیم؛ هم سریع است هم کیفیت چاپ عالیه.\nمریم کاظمی | دانش‌آموز | کاربرگه‌ها و تحقیق‌هایم را از بخش دانلود سایتشان می‌گیرم؛ همه‌چیز مرتب و آمادهٔ چاپه.\nحسین موسوی | مشتری ثابت | ثبت‌نام کنکورم را اینجا انجام دادم؛ خانم پشت میز با حوصله همه‌چیز را راهنمایی کرد.\nنگار احمدی | دانشجوی ارشد | اسکن مدارکم با کیفیت عالی و در چند دقیقه انجام شد. از سرعت کار اینجا همیشه شگفت‌زده می‌شوم.",
        _t('نظرات مشتریان'),
        _t('هر خط: «نام | نقش | متن | عکس (اختیاری)» — عکس در صورت خالی‌بودن، حرف اول نام نمایش داده می‌شود.')
    );
    $form->addInput($testimonials);

    /* ---------- بخش ۹: وبلاگ ---------- */

    $blogTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehBlogTitle',
        null,
        'از وبلاگ شبانه',
        _t('عنوان بخش وبلاگ'),
        _t('آخرین نوشته‌های بدون فایل دانلود.')
    );
    $form->addInput($blogTitle->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $blogUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehBlogUrl',
        null,
        null,
        _t('آدرس فهرست مقالات'),
        _t('اختیاری — پیش‌فرض /blog/ است.')
    );
    $form->addInput($blogUrl->addRule('xssCheck', _t('لطفاً آدرس معتبر وارد کنید')));

    $blogCount = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehBlogCount',
        null,
        '3',
        _t('تعداد کارت وبلاگ'),
        _t('۱ تا ۶ — نوشته‌های دارای فایل دانلود در این بخش نمایش داده نمی‌شوند.')
    );
    $form->addInput($blogCount->addRule('xssCheck', _t('عدد وارد کنید')));

    /* ---------- بخش ۱۰: پرسش‌های متداول ---------- */

    $faqTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehFaqTitle',
        null,
        'پرسش‌های متداول',
        _t('عنوان بخش پرسش‌ها'),
        _t('عنوان آکاردئون پرسش‌های متداول.')
    );
    $form->addInput($faqTitle->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $faqRows = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'shabanehFaqRows',
        null,
        "دانلود مقالات هزینه دارد؟ | خیر؛ فایل‌های «دانلود آزاد» برای همه رایگان است. فایل‌های «ویژهٔ اعضا» هم رایگان‌اند، فقط باید در سایت عضو شوید و وارد حساب خود شوید.\nچطور در سایت عضو شوم؟ | از دکمهٔ «ورود / ثبت‌نام» بالای صفحه اقدام کنید؛ ثبت‌نام فقط با یک ایمیل انجام می‌شود و کمتر از یک دقیقه وقت می‌گیرد.\nفایل دانلودی روی گوشی هم باز می‌شود؟ | بله؛ فایل‌ها عمدتاً PDF هستند و روی گوشی، تبلت و کامپیوتر باز می‌شوند. برای چاپ هم می‌توانید فایل را برای ما بفرستید.\nترجیح می‌دهم حضوری بیایم؛ ساعات کاری شما چطور است؟ | ساعت کاری در بالای صفحه نمایش داده می‌شود؛ همچنین وضعیت «اکنون باز است / بسته است» به‌صورت زنده بر اساس ساعت تهران محاسبه می‌شود.\nبرای چاپ پایان‌نامه نوبت می‌خواهد؟ | خیر؛ اما برای فایل‌های حجیم (بالای ۱۰۰ صفحه) بهتر است از قبل فایل را برای ما پیامک یا ایمیل کنید تا آماده باشد.",
        _t('پرسش‌ها و پاسخ‌ها'),
        _t('هر خط: «پرسش | پاسخ» — ترتیب حفظ می‌شود.')
    );
    $form->addInput($faqRows);

    /* ---------- بخش ۱۱: تماس و اطلاعات ---------- */

    $phone = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehPhone',
        null,
        '۰۲۱-۱۲۳۴۵۶۷۸',
        _t('شماره تلفن'),
        _t('شمارهٔ تماس کافی‌نت — در نوار بالا و بخش تماس نمایش داده می‌شود.')
    );
    $form->addInput($phone->addRule('xssCheck', _t('لطفاً شماره معتبر وارد کنید')));

    $email = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehEmail',
        null,
        'hello@shabaneh.ir',
        _t('ایمیل'),
        _t('نشانی ایمیل کافی‌نت.')
    );
    $form->addInput($email->addRule('xssCheck', _t('لطفاً ایمیل معتبر وارد کنید')));

    $address = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehAddress',
        null,
        'تهران، خیابان انقلاب، کوچهٔ دانش، پلاک ۱۲',
        _t('نشانی'),
        _t('نشانی کامل کافی‌نت برای بخش تماس.')
    );
    $form->addInput($address->addRule('xssCheck', _t('لطفاً نشانی معتبر وارد کنید')));

    $mapEmbed = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'shabanehMapEmbed',
        null,
        null,
        _t('کد iframe نقشه (اختیاری)'),
        _t('کد جاگذاری نقشه از نشان/بلد/گوگل — خالی باشد، قالب نقشهٔ ساده‌ای نمایش می‌دهد.')
    );
    $form->addInput($mapEmbed);

    $instagram = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehInstagram',
        null,
        null,
        _t('آیدی اینستاگرام'),
        _t('فقط آیدی بدون @ (اختیاری).')
    );
    $form->addInput($instagram->addRule('xssCheck', _t('لطفاً آیدی معتبر وارد کنید')));

    $telegram = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehTelegram',
        null,
        null,
        _t('آیدی تلگرام'),
        _t('فقط آیدی بدون @ (اختیاری).')
    );
    $form->addInput($telegram->addRule('xssCheck', _t('لطفاً آیدی معتبر وارد کنید')));

    /* ---------- بخش ۱۲: نمایش ---------- */

    $showViews = new \Typecho\Widget\Helper\Form\Element\Radio(
        'shabanehShowViews',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('شمارندهٔ بازدید'),
        _t('نمایش تعداد بازدید در کارت‌ها و صفحهٔ نوشته.')
    );
    $form->addInput($showViews);

    $showLikes = new \Typecho\Widget\Helper\Form\Element\Radio(
        'shabanehShowLikes',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('دکمهٔ پسندیدن'),
        _t('نمایش دکمهٔ لایک در صفحهٔ نوشته.')
    );
    $form->addInput($showLikes);

    $showRelated = new \Typecho\Widget\Helper\Form\Element\Radio(
        'shabanehShowRelated',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('نوشته‌های مرتبط'),
        _t('نمایش نوشته‌های هم‌دسته در صفحهٔ نوشته.')
    );
    $form->addInput($showRelated);

    $showAuthorBox = new \Typecho\Widget\Helper\Form\Element\Radio(
        'shabanehShowAuthorBox',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('جعبهٔ نویسنده'),
        _t('نمایش معرفی نویسنده در انتهای نوشته.')
    );
    $form->addInput($showAuthorBox);

    /* ---------- بخش ۱۳: فوتر ---------- */

    $footerAbout = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'shabanehFooterAbout',
        null,
        "شبانه، کافی‌نت محلهٔ شما برای تمام کارهای اینترنتی؛\nاز چاپ یک برگه تا دانلود هزار مقاله.",
        _t('متن معرفی فوتر'),
        _t('متن کوتاه معرفی در ستون اول فوتر.')
    );
    $form->addInput($footerAbout);

    $footerCopyright = new \Typecho\Widget\Helper\Form\Element\Text(
        'shabanehFooterCopyright',
        null,
        'تمامی حقوق برای کافی‌نت شبانه محفوظ است.',
        _t('متن کپی‌رایت'),
        _t('متر آخر فوتر.')
    );
    $form->addInput($footerCopyright->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    /* ---------- بخش ۱۴: پشتیبان‌گیری و بازیابی تنظیمات ---------- */

    $backupBox = new class(null, null, null, _t('پشتیبان‌گیری و بازیابی تنظیمات'), _t('ذخیرهٔ همهٔ تنظیمات پوسته در فایل JSON و بازگردانی آن‌ها — برای وقتی که پوسته را غیرفعال یا تغییر می‌دهید.')) extends \Typecho\Widget\Helper\Form\Element {
        public function input(?string $name = null, ?array $options = null): ?\Typecho\Widget\Helper\Layout
        {
            $box = new \Typecho\Widget\Helper\Layout('div', ['class' => 'shabaneh-backup-wrap']);
            $box->html(shabaneh_backup_ui_html());
            $this->container($box);
            return $box;
        }

        /** المان فقط نمایشی است — مقداری برای ذخیره ندارد */
        protected function inputValue($value)
        {
        }
    };
    $form->addItem($backupBox);
}

/* ================================================================
 *  ۱۲) فیلدهای اختصاصی نوشته — سیستم دانلود
 * ================================================================ */

function themeFields($layout)
{
    $thumb = new \Typecho\Widget\Helper\Form\Element\Text(
        'thumb',
        null,
        null,
        _t('تصویر شاخص'),
        _t('آدرس تصویر شاخص این نوشته (اختیاری؛ خالی = اولین تصویر متن).')
    );
    $layout->addItem($thumb->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $readingTime = new \Typecho\Widget\Helper\Form\Element\Text(
        'readingTime',
        null,
        null,
        _t('زمان مطالعه (دقیقه)'),
        _t('مدت زمان مطالعهٔ مطلب — به‌صورت بج روی کارت و صفحهٔ نوشته نمایش داده می‌شود. (اختیاری)')
    );
    $layout->addItem($readingTime->addRule('xssCheck', _t('عدد وارد کنید')));

    $downloadUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'downloadUrl',
        null,
        null,
        _t('لینک دانلود فایل'),
        _t('آدرس فایل (مثال: https://example.com/file.pdf یا مسیر داخل سایت). اگر پر شود، «باکس دانلود» در صفحهٔ نوشته و کارت آن در بخش «مقالات و دانلودها» صفحهٔ اول نمایش داده می‌شود. (اختیاری)')
    );
    $layout->addItem($downloadUrl->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $downloadSize = new \Typecho\Widget\Helper\Form\Element\Text(
        'downloadSize',
        null,
        null,
        _t('حجم فایل'),
        _t('مثال: ۲٫۴ مگابایت — در باکس دانلود و روی کارت نمایش داده می‌شود. (اختیاری)')
    );
    $layout->addItem($downloadSize->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $downloadFormat = new \Typecho\Widget\Helper\Form\Element\Text(
        'downloadFormat',
        null,
        null,
        _t('فرمت فایل'),
        _t('مثال: PDF یا Word یا ZIP — بج فرمت روی باکس دانلود و کارت. خالی = PDF. (اختیاری)')
    );
    $layout->addItem($downloadFormat->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $downloadAccess = new \Typecho\Widget\Helper\Form\Element\Radio(
        'downloadAccess',
        [
            'all'    => _t('همهٔ بازدیدکنندگان (دانلود آزاد)'),
            'member' => _t('فقط اعضای واردشده (ویژهٔ اعضا)'),
        ],
        'all',
        _t('دسترسی دانلود'),
        _t('چه کسانی می‌توانند فایل را دانلود کنند؟ فایل‌های «ویژهٔ اعضا» برای مهمان‌ها قفل نمایش داده می‌شوند و دکمهٔ ورود به حساب نشان می‌دهند.')
    );
    $layout->addItem($downloadAccess);
}

/* ================================================================
 *  ۱۳) رندر ریسه‌ای دیدگاه‌ها
 * ================================================================ */

function threadedComments($comments, $options)
{
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
    ?>
    <li id="li-<?php $comments->theId(); ?>" class="comment-item<?php
    if ($comments->levels > 0) {
        echo ' comment-child';
        $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
    } else {
        echo ' comment-parent';
    }
    $comments->alt(' comment-odd', ' comment-even');
    echo $commentClass;
    ?>">
        <div id="<?php $comments->theId(); ?>" class="comment-inner">
            <div class="comment-avatar" aria-hidden="true">
                <?php /* d=404: اگر گراواتار واقعی نباشد تصویر لود نمی‌شود و فقط آواتار الفبایی می‌ماند */ ?>
                <?php $comments->gravatar(96, '404', true); ?>
                <span class="comment-avatar-fallback"><?php echo htmlspecialchars(shabaneh_initial((string)$comments->author), ENT_QUOTES); ?></span>
            </div>
            <div class="comment-main">
                <div class="comment-meta">
                    <?php $comments->author(true); ?>
                    <?php if ($comments->authorId == $comments->ownerId): ?>
                    <span class="comment-badge-owner">نویسنده</span>
                    <?php endif; ?>
                    <?php if ($comments->status === 'waiting'): ?>
                    <span class="comment-badge-waiting">در انتظار تأیید</span>
                    <?php endif; ?>
                    <span class="comment-time">
                        <?php echo shabaneh_icon('clock', 13); ?>
                        <time datetime="<?php echo shabaneh_iso_date((int)$comments->created); ?>"><?php echo shabaneh_jalali_date((int)$comments->created, 'j F Y'); ?></time>
                    </span>
                </div>
                <div class="comment-content">
                    <?php $comments->content(); ?>
                </div>
                <div class="comment-reply">
                    <?php $comments->reply(); ?>
                </div>
            </div>
        </div>
        <?php if ($comments->children): ?>
        <ol class="comment-children">
            <?php threadedComments($comments->children, $options); ?>
        </ol>
        <?php endif; ?>
    </li>
    <?php
}

