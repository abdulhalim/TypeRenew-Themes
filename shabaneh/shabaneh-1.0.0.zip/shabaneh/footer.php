<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
</main>

<!-- ---------- فوتر سایت ---------- -->
<footer class="site-footer">
    <?php
    // ---------- داده‌های فوتر ----------
    $shabanehCafeName   = shabaneh_opt('shabanehCafeName', (string)$this->options->title);
    $shabanehLogoUrl    = shabaneh_logo_url();
    $shabanehFooterText = shabaneh_opt('shabanehFooterAbout', 'شبانه، کافی‌نت محلهٔ شما برای تمام کارهای اینترنتی؛ از چاپ یک برگه تا دانلود هزار مقاله.');
    $shabanehPhone      = shabaneh_opt_raw('shabanehPhone');
    $shabanehEmail      = shabaneh_opt_raw('shabanehEmail');
    $shabanehAddress    = shabaneh_opt_raw('shabanehAddress');
    $shabanehHoursLine  = shabaneh_hours_label();
    $shabanehSocial = [
        'instagram' => shabaneh_opt_raw('shabanehInstagram'),
        'telegram'  => shabaneh_opt_raw('shabanehTelegram'),
    ];
    $shabanehSocialNames = ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام'];
    ?>

    <!-- بخش اصلی فوتر -->
    <div class="container">
        <div class="footer-grid">

            <!-- ستون ۱: لوگو و معرفی -->
            <div class="footer-col footer-about">
                <div class="footer-logo">
                    <a href="<?php $this->options->siteUrl(); ?>" class="footer-logo-link">
                        <?php if ($shabanehLogoUrl !== ''): ?>
                            <img src="<?php echo htmlspecialchars($shabanehLogoUrl, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($shabanehCafeName, ENT_QUOTES); ?>" class="footer-logo-img">
                        <?php else: ?>
                            <span class="footer-logo-mark" aria-hidden="true"><?php echo shabaneh_icon('coffee', 20); ?></span>
                        <?php endif; ?>
                        <span class="footer-logo-text"><?php echo htmlspecialchars($shabanehCafeName, ENT_QUOTES); ?></span>
                    </a>
                </div>
                <p class="footer-desc"><?php echo htmlspecialchars($shabanehFooterText, ENT_QUOTES); ?></p>
                <div class="footer-social">
                    <?php foreach ($shabanehSocial as $shabanehNet => $shabanehUrl): if (trim((string)$shabanehUrl) !== ''): ?>
                        <a href="<?php echo htmlspecialchars('https://' . $shabanehNet . '.com/' . ltrim(trim((string)$shabanehUrl), '@'), ENT_QUOTES); ?>" target="_blank" rel="noopener" aria-label="<?php echo $shabanehSocialNames[$shabanehNet]; ?>">
                            <?php echo shabaneh_icon($shabanehNet === 'telegram' ? 'send' : $shabanehNet, 17); ?>
                        </a>
                    <?php endif; endforeach; ?>
                </div>
            </div>

            <!-- ستون ۲: لینک‌های سریع -->
            <div class="footer-col">
                <h3 class="footer-title"><?php echo shabaneh_icon('zap', 17); ?> دسترسی سریع</h3>
                <ul class="footer-links">
                    <li><a href="<?php echo htmlspecialchars(shabaneh_link_url('#services', shabaneh_is_front()), ENT_QUOTES); ?>">خدمات کافی‌نت</a></li>
                    <li><a href="<?php echo htmlspecialchars(shabaneh_link_url('#downloads', shabaneh_is_front()), ENT_QUOTES); ?>">مقالات و دانلودها</a></li>
                    <li><a href="<?php echo htmlspecialchars(shabaneh_link_url('#tariff', shabaneh_is_front()), ENT_QUOTES); ?>">تعرفهٔ خدمات</a></li>
                    <li><a href="<?php echo htmlspecialchars(shabaneh_link_url('#about', shabaneh_is_front()), ENT_QUOTES); ?>">چرا شبانه؟</a></li>
                    <li><a href="<?php echo htmlspecialchars(shabaneh_blog_url(), ENT_QUOTES); ?>">وبلاگ</a></li>
                    <?php
                    $shabanehFooterPages = \Widget\Contents\Page\Rows::allocWithAlias('shabanehFooter');
                    $shabanehFooterPageCount = 0;
                    while ($shabanehFooterPages->next()):
                        $shabanehFooterPageCount++;
                        if ($shabanehFooterPageCount > 4) { break; }
                    ?>
                        <li><a href="<?php $shabanehFooterPages->permalink(); ?>"><?php echo shabaneh_fa_title($shabanehFooterPages); ?></a></li>
                    <?php endwhile; ?>
                </ul>
            </div>

            <!-- ستون ۳: اطلاعات تماس -->
            <div class="footer-col footer-contact-col">
                <h3 class="footer-title"><?php echo shabaneh_icon('phone-call', 17); ?> تماس با ما</h3>
                <ul class="footer-contact">
                    <?php if ($shabanehAddress !== null && trim($shabanehAddress) !== ''): ?>
                    <li>
                        <?php echo shabaneh_icon('map-pin', 16); ?>
                        <span><?php echo htmlspecialchars($shabanehAddress, ENT_QUOTES); ?></span>
                    </li>
                    <?php endif; ?>
                    <?php if ($shabanehPhone !== null && trim($shabanehPhone) !== ''): ?>
                    <li>
                        <?php echo shabaneh_icon('phone', 16); ?>
                        <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $shabanehPhone), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($shabanehPhone), ENT_QUOTES); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if ($shabanehEmail !== null && trim($shabanehEmail) !== ''): ?>
                    <li>
                        <?php echo shabaneh_icon('mail', 16); ?>
                        <a href="mailto:<?php echo htmlspecialchars($shabanehEmail, ENT_QUOTES); ?>"><?php echo htmlspecialchars($shabanehEmail, ENT_QUOTES); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if ($shabanehHoursLine !== ''): ?>
                    <li>
                        <?php echo shabaneh_icon('clock', 16); ?>
                        <span><?php echo htmlspecialchars(toPersianNumbers($shabanehHoursLine), ENT_QUOTES); ?></span>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>

    <!-- خط جداکننده و کپی‌رایت -->
    <div class="footer-bottom">
        <div class="container footer-bottom-inner">
            <div class="copyright">
                <span>© <?php echo shabaneh_jalali_year(); ?> <?php echo htmlspecialchars($shabanehCafeName, ENT_QUOTES); ?> — <?php echo htmlspecialchars(shabaneh_opt('shabanehFooterCopyright', 'تمامی حقوق محفوظ است.'), ENT_QUOTES); ?></span>
            </div>
            <div class="footer-powered">
                <span>قدرت گرفته از <a href="https://typerenew.com" target="_blank" rel="noopener">تایپ‌رینیو</a></span>
            </div>
        </div>
    </div>
</footer>

<!-- ---------- دکمهٔ بازگشت به بالا ---------- -->
<button type="button" class="back-to-top" id="backToTop" aria-label="بازگشت به بالا" title="بازگشت به بالا">
    <?php echo shabaneh_icon('arrow-up', 19); ?>
</button>

<!-- ---------- اسکریپت‌ها ---------- -->
<script src="<?php $this->options->themeUrl('js/main.js'); ?>?v=1.0.3"></script>
<?php if (isset($GLOBALS['shabanehPostJs']) && $GLOBALS['shabanehPostJs']): ?>
<!-- لایک — فقط صفحات نوشته -->
<script src="<?php $this->options->themeUrl('js/likes.js'); ?>?v=1.0.3"></script>
<?php endif; ?>

<?php $this->footer(); ?>
</body>
</html>
