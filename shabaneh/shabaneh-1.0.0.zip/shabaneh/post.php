<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$GLOBALS['shabanehPostJs'] = true;

$this->need('header.php');

$shabanehShowViews = shabaneh_opt('shabanehShowViews', '1') === '1';
$shabanehShowLikes = shabaneh_opt('shabanehShowLikes', '1') === '1';
$shabanehShowRelated = shabaneh_opt('shabanehShowRelated', '1') === '1';
$shabanehShowAuthorBox = shabaneh_opt('shabanehShowAuthorBox', '1') === '1';
$shabanehCafeName = shabaneh_opt('shabanehCafeName', (string)$this->options->title);
$shabanehPostReading = shabaneh_reading_time($this);

// ---------- دادهٔ دانلود این نوشته ----------
$shabanehDl = shabaneh_download_data($this);
$shabanehCanDl = shabaneh_can_download($shabanehDl);
$shabanehLoginUrl = shabaneh_login_url();
?>

<article class="post-wrap container" itemscope itemtype="https://schema.org/BlogPosting">

    <!-- ---------- سربرگ نوشته ---------- -->
    <header class="post-head">
        <nav class="post-breadcrumb" aria-label="مسیر">
            <a href="<?php $this->options->siteUrl(); ?>">خانه</a>
            <span class="crumb-sep">/</span>
            <a href="<?php echo htmlspecialchars(shabaneh_blog_url(), ENT_QUOTES); ?>">مقالات</a>
            <span class="crumb-sep">/</span>
            <span aria-current="page"><?php echo shabaneh_fa_title($this); ?></span>
        </nav>

        <h1 class="post-title" itemprop="name headline"><?php echo shabaneh_fa_title($this); ?></h1>

        <div class="post-meta">
            <span class="post-meta-item" itemprop="author" itemscope itemtype="https://schema.org/Person">
                <?php echo shabaneh_icon('user', 15); ?>
                <span itemprop="name"><?php $this->author(); ?></span>
            </span>
            <span class="post-meta-item">
                <?php echo shabaneh_icon('calendar', 15); ?>
                <time datetime="<?php $this->date('c'); ?>" itemprop="datePublished"><?php echo shabaneh_post_date($this, 'j F Y'); ?></time>
            </span>
            <span class="post-meta-item">
                <?php echo shabaneh_icon('folder', 15); ?>
                <?php $this->category(','); ?>
            </span>
            <?php if ($shabanehPostReading !== ''): ?>
            <span class="post-meta-item post-meta-badge">
                <?php echo shabaneh_icon('clock', 15); ?>
                <?php echo $shabanehPostReading; ?> دقیقه مطالعه
            </span>
            <?php endif; ?>
            <?php if ($shabanehShowViews): ?>
            <span class="post-meta-item post-views" id="postViews">
                <?php echo shabaneh_icon('eye', 15); ?>
                <?php echo shabaneh_num(shabaneh_views($this)); ?> بازدید
            </span>
            <?php endif; ?>
            <span class="post-meta-item">
                <?php echo shabaneh_icon('message-square', 15); ?>
                <a href="#comments"><?php ob_start(); $this->commentsNum('بدون دیدگاه', '۱ دیدگاه', '%d دیدگاه'); echo toPersianNumbers(ob_get_clean()); ?></a>
            </span>
        </div>
    </header>

    <!-- ---------- تصویر شاخص ---------- -->
    <?php $shabanehCover = shabaneh_thumbnail($this, false); if ($shabanehCover !== ''): ?>
    <figure class="post-cover">
        <img src="<?php echo htmlspecialchars($shabanehCover, ENT_QUOTES); ?>" alt="<?php echo shabaneh_fa_title($this); ?>" itemprop="image">
    </figure>
    <?php endif; ?>

    <!-- ---------- باکس دانلود (بالای محتوا) ---------- -->
    <?php if ($shabanehDl['has']): ?>
    <aside class="dl-box<?php echo $shabanehCanDl ? '' : ' is-locked'; ?>" aria-label="فایل ضمیمهٔ دانلودی">
        <div class="dl-box-head">
            <span class="dl-box-ic"><?php echo shabaneh_icon($shabanehCanDl ? 'file-down' : 'lock', 24); ?></span>
            <div class="dl-box-titles">
                <h2 class="dl-box-title">
                    فایل دانلودی این نوشته
                    <span class="dl-box-format"><?php echo shabaneh_icon('file-text', 12); ?><?php echo htmlspecialchars($shabanehDl['format'], ENT_QUOTES); ?></span>
                    <span class="dl-access-chip <?php echo $shabanehDl['access'] === 'member' ? 'is-member' : 'is-all'; ?>">
                        <?php echo shabaneh_icon($shabanehDl['access'] === 'member' ? 'lock' : 'unlock', 12); ?>
                        <?php echo shabaneh_access_label($shabanehDl['access']); ?>
                    </span>
                </h2>
                <p class="dl-box-sub"><?php echo $shabanehCanDl ? 'فایل آمادهٔ دانلود است؛ برای چاپ هم می‌توانید فایل را برای ما بفرستید.' : 'این فایل فقط برای اعضای واردشده قابل دانلود است.'; ?></p>
            </div>
        </div>

        <div class="dl-box-body">
            <span class="dl-box-item">
                <?php echo shabaneh_icon('hdd', 17); ?>
                <span>
                    <small>حجم فایل</small>
                    <b><?php echo htmlspecialchars(toPersianNumbers($shabanehDl['size']), ENT_QUOTES); ?></b>
                </span>
            </span>
            <span class="dl-box-item">
                <?php echo shabaneh_icon('file-text', 17); ?>
                <span>
                    <small>فرمت</small>
                    <b><?php echo htmlspecialchars($shabanehDl['format'], ENT_QUOTES); ?></b>
                </span>
            </span>
            <span class="dl-box-item">
                <?php echo shabaneh_icon($shabanehDl['access'] === 'member' ? 'lock' : 'unlock', 17); ?>
                <span>
                    <small>سطح دسترسی</small>
                    <b><?php echo shabaneh_access_label($shabanehDl['access']); ?></b>
                </span>
            </span>
        </div>

        <?php if ($shabanehCanDl): ?>
        <div class="dl-box-actions">
            <a class="btn-download" href="<?php echo htmlspecialchars($shabanehDl['url'], ENT_QUOTES); ?>" rel="nofollow" target="_blank">
                <?php echo shabaneh_icon('download', 19); ?>
                <span>دانلود فایل</span>
            </a>
            <span class="dl-box-note"><?php echo shabaneh_icon('info', 14); ?> اگر دانلود شروع نشد، روی لینک راست‌کلیک و «Save link as…» بزنید.</span>
        </div>
        <?php else: ?>
        <div class="dl-locked-note">
            <?php echo shabaneh_icon('lock', 17); ?>
            <span><b>دانلود این فایل ویژهٔ اعضاست.</b> عضویت رایگان است و فقط با یک ایمیل انجام می‌شود؛ پس از ورود، دکمهٔ دانلود همین‌جا فعال می‌شود.</span>
        </div>
        <div class="dl-box-actions">
            <a class="btn-login-cta" href="<?php echo htmlspecialchars($shabanehLoginUrl, ENT_QUOTES); ?>">
                <?php echo shabaneh_icon('log-in', 19); ?>
                <span>ورود / ثبت‌نام رایگان</span>
            </a>
            <span class="dl-box-note"><?php echo shabaneh_icon('shield-check', 14); ?> عضویت کمتر از یک دقیقه وقت می‌گیرد.</span>
        </div>
        <?php endif; ?>
    </aside>
    <?php endif; ?>

    <!-- ---------- محتوای نوشته ---------- -->
    <div class="post-content" itemprop="articleBody">
        <?php $this->content(); ?>
    </div>

    <!-- ---------- تگ‌ها ---------- -->
    <?php if ($this->tags): ?>
    <div class="post-tags">
        <?php echo shabaneh_icon('tag', 15); ?>
        <?php $this->tags(' ', true, ''); ?>
    </div>
    <?php endif; ?>

    <!-- ---------- لایک ---------- -->
    <?php if ($shabanehShowLikes): ?>
    <?php
    $shabanehLikes = shabaneh_likes($this);
    $shabanehLiked = shabaneh_is_liked((int)$this->cid) ? '1' : '0';
    ?>
    <div class="post-like-row" id="shabanehLikeFloat">
        <button type="button" class="like-btn<?php echo $shabanehLiked === '1' ? ' is-liked' : ''; ?>" id="shabanehLikeBtn"
                data-cid="<?php echo (int)$this->cid; ?>" data-likes="<?php echo $shabanehLikes; ?>" data-liked="<?php echo $shabanehLiked; ?>"
                aria-pressed="<?php echo $shabanehLiked === '1' ? 'true' : 'false'; ?>">
            <?php echo shabaneh_icon('heart', 18); ?>
            <span class="like-label"><?php echo $shabanehLiked === '1' ? 'پسندیدید' : 'این مطلب را پسندیدید؟'; ?></span>
            <span class="like-count"><?php echo shabaneh_num($shabanehLikes); ?></span>
        </button>
    </div>
    <?php endif; ?>

    <!-- ---------- نویسنده ---------- -->
    <?php if ($shabanehShowAuthorBox): ?>
    <aside class="author-box">
        <span class="author-avatar">
            <?php /* d=404: اگر گراواتار واقعی نباشد تصویر لود نمی‌شود و فقط آواتار الفبایی می‌ماند */ ?>
            <?php $this->author->gravatar(96, 'X', '404'); ?>
            <span class="author-avatar-fallback" aria-hidden="true"><?php echo htmlspecialchars(shabaneh_initial((string)$this->author->screenName), ENT_QUOTES); ?></span>
        </span>
        <div class="author-info">
            <strong class="author-name"><a href="<?php $this->author->permalink(); ?>" rel="author"><?php $this->author(); ?></a></strong>
            <span class="author-role">نویسنده در <?php echo htmlspecialchars($shabanehCafeName, ENT_QUOTES); ?></span>
            <?php if (trim((string)$this->author->description) !== ''): ?>
            <p class="author-desc"><?php $this->author->description(); ?></p>
            <?php endif; ?>
        </div>
    </aside>
    <?php endif; ?>

    <!-- ---------- نوشته‌های مرتبط ---------- -->
    <?php
    $shabanehRelated = $shabanehShowRelated ? shabaneh_related_posts($this, 3) : [];
    if (!empty($shabanehRelated)):
    ?>
    <section class="related-posts">
        <h2 class="related-title"><?php echo shabaneh_icon('file-text', 18); ?> نوشته‌های مرتبط</h2>
        <div class="related-grid">
            <?php foreach ($shabanehRelated as $shabanehRelatedPost): ?>
            <a href="<?php echo htmlspecialchars($shabanehRelatedPost['url'], ENT_QUOTES); ?>" class="related-card">
                <span class="related-card-title"><?php echo toPersianNumbers(htmlspecialchars($shabanehRelatedPost['title'], ENT_QUOTES)); ?></span>
                <span class="related-card-date"><?php echo shabaneh_jalali_date($shabanehRelatedPost['created'], 'j F Y'); ?></span>
                <span class="related-card-more">خواندن <?php echo shabaneh_icon('arrow-left', 14); ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- ---------- نظرات ---------- -->
    <?php $this->need('comments.php'); ?>

</article>

<?php $this->need('footer.php'); ?>
