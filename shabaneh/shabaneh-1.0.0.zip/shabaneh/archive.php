<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

// واژهٔ جستجوی جاری (برای پر کردن فیلد جستجو در صفحهٔ نتایج)
$shabanehArcSearchQ = '';
try {
    $shabanehArcSearchQ = (string)($this->request->keywords ?? $this->request->s ?? '');
} catch (\Throwable $e) {
}
?>

<div class="container archive-wrap">
    <header class="archive-head">
        <span class="section-tag"><?php echo shabaneh_icon('file-text', 14); ?> وبلاگ</span>
        <h1 class="archive-title">
            <?php $this->archiveTitle([
                'category' => _t('دستهٔ %s'),
                'search'   => _t('نتایج جستجوی %s'),
                'tag'      => _t('برچسب %s'),
                'author'   => _t('نوشته‌های %s'),
                'date'     => _t('آرشیو %s'),
            ], '', ''); ?>
        </h1>
    </header>

    <?php shabaneh_search_form($shabanehArcSearchQ); ?>

    <?php if ($this->have()): ?>
    <div class="archive-grid">
        <?php while ($this->next()): ?>
        <article class="blog-card<?php echo shabaneh_has_download($this) ? ' has-dl' : ''; ?>">
            <a href="<?php $this->permalink(); ?>" class="blog-card-link">
                <div class="blog-card-thumb">
                    <img src="<?php echo htmlspecialchars(shabaneh_thumbnail($this), ENT_QUOTES); ?>" alt="<?php echo shabaneh_fa_title($this); ?>" loading="lazy">
                    <?php
                    $shabanehArcReading = shabaneh_reading_time($this);
                    $shabanehArcDl = shabaneh_download_data($this);
                    ?>
                    <?php if ($shabanehArcDl['has']): ?>
                    <span class="blog-card-badge"><?php echo shabaneh_icon('file-down', 13); ?> <?php echo htmlspecialchars($shabanehArcDl['format'], ENT_QUOTES); ?> — <?php echo shabaneh_access_label($shabanehArcDl['access']); ?></span>
                    <?php elseif ($shabanehArcReading !== ''): ?>
                    <span class="blog-card-badge"><?php echo shabaneh_icon('clock', 13); ?> <?php echo $shabanehArcReading; ?> دقیقه مطالعه</span>
                    <?php endif; ?>
                </div>
                <div class="blog-card-body">
                    <div class="blog-card-meta">
                        <span><?php echo shabaneh_icon('calendar', 13); ?> <?php echo shabaneh_post_date($this, 'j F Y'); ?></span>
                        <?php if (shabaneh_opt('shabanehShowViews', '1') === '1'): ?>
                        <span><?php echo shabaneh_icon('eye', 13); ?> <?php echo shabaneh_num(shabaneh_views($this)); ?></span>
                        <?php endif; ?>
                    </div>
                    <h2 class="blog-card-title"><?php echo shabaneh_fa_title($this); ?></h2>
                    <p class="blog-card-excerpt"><?php echo toPersianNumbers(htmlspecialchars(mb_substr(trim(strip_tags((string)$this->excerpt)), 0, 100, 'UTF-8') . '...', ENT_QUOTES, 'UTF-8')); ?></p>
                    <span class="blog-card-more"><?php echo shabaneh_has_download($this) ? 'مشاهده و دانلود' : 'ادامه مطلب'; ?> <?php echo shabaneh_icon('arrow-left', 14); ?></span>
                </div>
            </a>
        </article>
        <?php endwhile; ?>
    </div>

    <?php shabaneh_page_nav($this); ?>
    <?php else: ?>
    <div class="archive-empty">
        <?php echo shabaneh_icon('search', 44); ?>
        <p><?php echo ($shabanehArcSearchQ !== '') ? 'چیزی با این عبارت پیدا نشد؛ عبارت دیگری را امتحان کنید.' : 'چیزی برای نمایش پیدا نشد.'; ?></p>
        <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-ghost">بازگشت به خانه</a>
    </div>
    <?php endif; ?>
</div>

<?php $this->need('footer.php'); ?>
