<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="layout layout-single">
    <div class="layout-primary">

        <?php renderSingle($this, 'page'); ?>

        <?php $this->need('comments.php'); ?>

    </div>
    <?php $this->need('sidebar.php'); ?>
</div>

<?php $this->need('footer.php'); ?>
