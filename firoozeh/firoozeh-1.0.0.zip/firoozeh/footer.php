<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
</main>

<footer class="site-footer" role="contentinfo">
    <div class="container">
        <div class="footer-inner">
            <div class="footer-brand">
                <a class="footer-title" href="<?php $this->options->siteUrl(); ?>">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l2.4 7.6L22 12l-7.6 2.4L12 22l-2.4-7.6L2 12l7.6-2.4z"/></svg>
                    <span><?php $this->options->title(); ?></span>
                </a>
                <p class="footer-desc"><?php echo htmlspecialchars((string) $this->options->description, ENT_QUOTES, 'UTF-8'); ?></p>
            </div>

            <?php if (($this->options->showFooterPoem ?? '1') === '1'): ?>
                <?php $footerPoem = firoozehRandomPoem(); ?>
                <figure class="footer-poem">
                    <blockquote><?php echo $footerPoem['verse']; ?></blockquote>
                    <figcaption>— <?php echo $footerPoem['poet']; ?></figcaption>
                </figure>
            <?php endif; ?>

            <div class="footer-meta">
                <p>&copy; <?php echo toPersianDigits(date('Y')); ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a> · <?php _e('تمام حقوق محفوظ است'); ?></p>
                <p><?php _e('قدرت‌گرفته از'); ?> <a href="https://www.typerenew.ir" rel="nofollow">TypeRenew</a> · <?php _e('پوستهٔ'); ?> <a href="https://pourdaryaei.ir" rel="noopener">پرنیان</a> </p>
            </div>
        </div>
        <div class="footer-divider" aria-hidden="true"></div>
    </div>
</footer>

<button type="button" id="back-to-top" class="back-to-top" aria-label="<?php _e('بازگشت به بالای صفحه'); ?>" title="<?php _e('بازگشت به بالا'); ?>">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>
</button>

<?php $this->footer(); ?>

<script>
    (function() {
        /* ---------- تعویض حالت روشن و تیره ---------- */
        var btn = document.getElementById('theme-switch');
        var html = document.documentElement;
        var iconPath = btn ? btn.querySelector('path') : null;
        var transitionTimeout;
        var SUN_PATH = 'M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42M17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0z';
        var MOON_PATH = 'M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z';

        function updateIcon() {
            if (!iconPath) return;
            var isDark = html.getAttribute('data-theme') === 'dark';
            iconPath.setAttribute('d', isDark ? SUN_PATH : MOON_PATH);
        }

        updateIcon();

        if (btn) {
            btn.addEventListener('click', function() {
                var currentDark = html.getAttribute('data-theme') === 'dark';
                var newTheme = currentDark ? 'light' : 'dark';

                html.classList.add('theme-transition');
                html.setAttribute('data-theme', newTheme);
                try { localStorage.setItem('firoozeh-theme', newTheme); } catch (e) {}
                updateIcon();

                clearTimeout(transitionTimeout);
                transitionTimeout = setTimeout(function() {
                    html.classList.remove('theme-transition');
                }, 400);
            });
        }

        var prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
        if (prefersDark.addEventListener) {
            prefersDark.addEventListener('change', function(e) {
                var stored = null;
                try { stored = localStorage.getItem('firoozeh-theme'); } catch (err) {}
                if (!stored) {
                    html.classList.add('theme-transition');
                    html.setAttribute('data-theme', e.matches ? 'dark' : 'light');
                    updateIcon();
                    clearTimeout(transitionTimeout);
                    transitionTimeout = setTimeout(function() {
                        html.classList.remove('theme-transition');
                    }, 400);
                }
            });
        }

        /* ---------- نوار پیشرفت مطالعه ---------- */
        var progressWrap = document.querySelector('.reading-progress');
        var progressBar = progressWrap ? progressWrap.querySelector('.reading-progress-bar') : null;

        function updateProgress() {
            if (!progressBar) return;
            var doc = document.documentElement;
            var scrollable = doc.scrollHeight - window.innerHeight;
            if (scrollable <= 0) {
                progressBar.style.transform = 'scaleX(1)';
                return;
            }
            var ratio = Math.min(1, Math.max(0, window.pageYOffset / scrollable));
            progressBar.style.transform = 'scaleX(' + ratio + ')';
            if (ratio > 0.02) {
                progressWrap.classList.add('is-active');
            } else {
                progressWrap.classList.remove('is-active');
            }
        }

        var ticking = false;
        window.addEventListener('scroll', function() {
            if (!ticking) {
                window.requestAnimationFrame(function() {
                    updateProgress();
                    updateBackToTop();
                    ticking = false;
                });
                ticking = true;
            }
        }, { passive: true });

        /* ---------- بازگشت به بالا ---------- */
        var backBtn = document.getElementById('back-to-top');
        function updateBackToTop() {
            if (!backBtn) return;
            if (window.pageYOffset > 480) {
                backBtn.classList.add('is-visible');
            } else {
                backBtn.classList.remove('is-visible');
            }
        }
        if (backBtn) {
            backBtn.addEventListener('click', function() {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }

        /* ---------- بستن منوی موبایل با کلیک بیرون ---------- */
        var navToggle = document.getElementById('nav-toggle');
        if (navToggle) {
            document.addEventListener('click', function(e) {
                if (navToggle.checked && !e.target.closest('.site-nav')) {
                    navToggle.checked = false;
                }
            });
        }

        updateProgress();
        updateBackToTop();
    })();
</script>

</body>
</html>
