<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php $this->archiveTitle([
            'category' => _t('نوشته‌های دسته «%s»'),
            'search'   => _t('نتایج جستجو برای «%s»'),
            'tag'      => _t('نوشته‌های برچسب «%s»'),
            'author'   => _t('نوشته‌های %s')
        ], '', ' — '); ?><?php $this->options->title(); ?></title>

    <?php
        $defaultSchema = $this->options->colorSchema ?? 'auto';
        $defaultSchemaJson = \Typecho\Common::jsonEncode(
            (string) $defaultSchema,
            JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP,
            '"auto"'
        );
        $accentPreset = (string) ($this->options->accentPreset ?? 'turquoise');
        $allowedAccents = ['turquoise', 'lapis', 'saffron'];
        if (!in_array($accentPreset, $allowedAccents, true)) {
            $accentPreset = 'turquoise';
        }
        echo "<script>
            (function() {
                var stored = null;
                try {
                    stored = localStorage.getItem('firoozeh-theme');
                } catch (e) {
                    stored = null;
                }
                var def = {$defaultSchemaJson};
                var isDark = false;
                if (stored === 'dark' || stored === 'light') {
                    isDark = (stored === 'dark');
                } else if (def === 'dark') {
                    isDark = true;
                } else if (def === 'auto' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                    isDark = true;
                }
                if (isDark) {
                    document.documentElement.setAttribute('data-theme', 'dark');
                }
            })();
        </script>";
    ?>

    <link rel="stylesheet" href="<?php $this->options->themeUrl('style.css'); ?>">
    <?php $this->header(); ?>
</head>
<body class="fz-<?php echo htmlspecialchars($accentPreset, ENT_QUOTES, 'UTF-8'); ?>">
<div class="reading-progress" aria-hidden="true"><span class="reading-progress-bar"></span></div>

<header class="site-header">
    <div class="container header-inner">
        <div class="site-branding">
            <?php if ($this->options->logoUrl): ?>
                <a class="site-logo" href="<?php $this->options->siteUrl(); ?>">
                    <img src="<?php $this->options->logoUrl() ?>" alt="<?php $this->options->title() ?>"/>
                </a>
            <?php else: ?>
                <a class="site-title" href="<?php $this->options->siteUrl(); ?>">
                    <svg class="site-title-ornament" width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l2.4 7.6L22 12l-7.6 2.4L12 22l-2.4-7.6L2 12l7.6-2.4z"/></svg>
                    <span><?php $this->options->title() ?></span>
                </a>
            <?php endif; ?>
        </div>
        <nav class="site-nav" aria-label="<?php _e('ناوبری اصلی'); ?>">
            <input type="checkbox" id="nav-toggle" class="nav-toggle-input" aria-label="<?php _e('گشودن ناوبری'); ?>">
            <label for="nav-toggle" class="nav-toggle-label" aria-hidden="true">
                <span class="nav-toggle-bar"></span>
                <span class="nav-toggle-bar"></span>
                <span class="nav-toggle-bar"></span>
            </label>
            <ul class="nav-menu" role="menubar">
                <li role="none"><a role="menuitem" <?php if ($this->is('index')): ?> class="active"<?php endif; ?> href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a></li>
                <?php \Widget\Contents\Page\Rows::alloc()->to($pages); ?>
                <?php while ($pages->next()): ?>
                    <li role="none"><a role="menuitem" <?php if ($this->is('page', $pages->slug)): ?> class="active"<?php endif; ?> href="<?php $pages->permalink(); ?>"><?php $pages->title(); ?></a></li>
                <?php endwhile; ?>

                <li role="none" class="nav-tools">
                    <form id="search" method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="search-form">
                        <svg class="search-icon" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                        <?php $searchQuery = htmlspecialchars((string) ($this->request->keywords ?? $this->request->s ?? ''), ENT_QUOTES, 'UTF-8'); ?>
                        <input type="search" id="s" name="s" class="search-input" placeholder="<?php _e('جستجو…'); ?>" aria-label="<?php _e('جستجو'); ?>" value="<?php echo $searchQuery; ?>" required />
                        <button type="submit" class="search-submit" aria-label="<?php _e('جستجو'); ?>">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                        </button>
                    </form>
                </li>

                <li role="none" class="nav-tools">
                    <button type="button" id="theme-switch" class="theme-switch" aria-label="<?php _e('تغییر حالت روشن و تیره'); ?>" title="<?php _e('تغییر حالت روشن و تیره'); ?>">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="theme-icon" aria-hidden="true">
                            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                        </svg>
                    </button>
                </li>
            </ul>
        </nav>
    </div>
</header>

<?php if ($this->is('index') && ($this->options->showHero ?? '1') === '1'): ?>
    <?php
        $heroTagline = trim((string) ($this->options->heroTagline ?? ''));
        if ($heroTagline === '') {
            $heroTagline = (string) $this->options->description;
        }

        // انتخاب آمار هرو از چک‌باکس تنظیمات (سازگار با showStats نسخه‌های پیشین)
        $heroStatsSelected = firoozehHeroStatsSelection($this->options);
        $heroStats = !empty($heroStatsSelected) ? firoozehStats() : null;

        // آمارهای منتخب با قالب‌بندی خلاصهٔ اجتماعی (۱ هزار / ۱۰ هزار)
        $heroStatItems = [];
        if (is_array($heroStats)) {
            if (in_array('posts', $heroStatsSelected, true)) {
                $heroStatItems[] = [firoozehFormatCount($heroStats['posts']), _t('نوشته')];
            }
            if (in_array('comments', $heroStatsSelected, true)) {
                $heroStatItems[] = [firoozehFormatCount($heroStats['comments']), _t('دیدگاه')];
            }
            if (in_array('views', $heroStatsSelected, true)) {
                $heroStatItems[] = [firoozehFormatCount($heroStats['views']), _t('بازدید')];
            }
            if (empty($heroStatItems)) {
                $heroStats = null;
            }
        }

        $heroPoem = firoozehRandomPoem();

        $heroMediaMode = (string) ($this->options->heroMedia ?? 'pattern');
        $heroImageUrl = trim((string) ($this->options->heroImageUrl ?? ''));
        $heroVideoUrl = trim((string) ($this->options->heroVideoUrl ?? ''));
        $heroHasImage = ($heroMediaMode === 'image' && $heroImageUrl !== '');
        $heroHasVideo = ($heroMediaMode === 'video' && $heroVideoUrl !== '');
        $heroHasMedia = $heroHasImage || $heroHasVideo;
    ?>
    <section class="hero<?php echo $heroHasMedia ? ' hero-has-media' : ''; ?>">
        <?php if ($heroHasImage): ?>
            <img class="hero-media" src="<?php echo htmlspecialchars($heroImageUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="" aria-hidden="true" />
        <?php elseif ($heroHasVideo): ?>
            <video class="hero-media" autoplay muted loop playsinline preload="auto"<?php if ($heroImageUrl !== ''): ?> poster="<?php echo htmlspecialchars($heroImageUrl, ENT_QUOTES, 'UTF-8'); ?>"<?php endif; ?> aria-hidden="true">
                <source src="<?php echo htmlspecialchars($heroVideoUrl, ENT_QUOTES, 'UTF-8'); ?>" type="video/mp4" />
            </video>
        <?php endif; ?>
        <div class="hero-pattern" aria-hidden="true"></div>
        <div class="container hero-inner">
            <div class="hero-badge"><?php _e('دفترچه‌ی یک ایرانی'); ?></div>
            <h1 class="hero-title">
                <?php if ($this->options->logoUrl): ?>
                    <img class="hero-logo" src="<?php $this->options->logoUrl() ?>" alt="<?php $this->options->title() ?>"/>
                <?php endif; ?>
                <span><?php $this->options->title() ?></span>
            </h1>
            <?php if ($heroTagline !== ''): ?>
                <p class="hero-tagline"><?php echo htmlspecialchars($heroTagline, ENT_QUOTES, 'UTF-8'); ?></p>
            <?php endif; ?>
            <?php if (is_array($heroStats) && !empty($heroStatItems)): ?>
                <div class="hero-stats">
                    <?php foreach ($heroStatItems as $heroStatIndex => [$heroStatValue, $heroStatLabel]): ?>
                        <?php if ($heroStatIndex > 0): ?>
                            <span class="hero-stat-divider" aria-hidden="true"></span>
                        <?php endif; ?>
                        <div class="hero-stat">
                            <strong><?php echo $heroStatValue; ?></strong>
                            <span><?php echo $heroStatLabel; ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <div class="hero-poem">
                <span class="hero-poem-verse"><?php echo $heroPoem['verse']; ?></span>
                <span class="hero-poem-poet"><?php echo $heroPoem['poet']; ?></span>
            </div>
            <a class="hero-scroll-hint" href="#content" aria-label="<?php _e('رفتن به نوشته‌ها'); ?>">
                <span><?php _e('آغاز مطالعه'); ?></span>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"></line><polyline points="19 12 12 19 5 12"></polyline></svg>
            </a>
        </div>
    </section>
<?php endif; ?>

<main id="content" class="site-main container">
