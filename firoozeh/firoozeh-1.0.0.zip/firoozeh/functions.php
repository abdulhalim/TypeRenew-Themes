<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * تبدیل ارقام لاتین به فارسی
 */
function toPersianDigits(?string $text): string
{
    return str_replace(
        ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
        ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'],
        (string) $text
    );
}

/**
 * تخمین زمان مطالعه بر اساس طول متن (دقیقه)
 */
function firoozehReadingTime(string $text): int
{
    $plain = trim(strip_tags((string) $text));
    $count = (int) preg_match_all('/[\p{L}\p{N}]+/u', $plain, $matches);
    if ($count < 1) {
        $parts = preg_split('/\s+/u', $plain);
        $count = max(1, is_array($parts) ? count($parts) : 1);
    }
    return max(1, (int) ceil($count / 180));
}

/**
 * گنجینه اشعار ایرانی — بیت تصادفی برای نمایش در پوسته
 */
function firoozehPoems(): array
{
    return [
        ['الا یا أیُّها السّاقی أدِر کأساً و ناوِلها / که عشق آسان نمود اوّل ولی افتاد مشکل‌ها', 'حافظ'],
        ['یوسف گمگشته بازآید به کنعان غم مخور / کلبه‌ی احزان شود روزی گلستان غم مخور', 'حافظ'],
        ['سال‌ها دل طلب جام جم از ما می‌کرد / آن‌چه خود داشت ز بیگانه تمنّا می‌کرد', 'حافظ'],
        ['درخت دوستی بنشان که کام دل به بار آرد / نهال دشمنی برکن که رنج بی‌شمار آرد', 'حافظ'],
        ['ما ز یاران چشم یاری داشتیم / خود غلط بود آن‌چه ما پنداشتیم', 'حافظ'],
        ['مژده ای دل که مسیحا نفسی می‌آید / که ز انفاس خوشش بوی کسی می‌آید', 'حافظ'],
        ['بنی‌آدم اعضای یکدیگرند / که در آفرینش ز یک گوهرند', 'سعدی'],
        ['سعدیا مرد نکونام نمیرد هرگز / مرد نکونام زنده بی‌قران است', 'سعدی'],
        ['بشنو این نی چون شکایت می‌کند / از جدایی‌ها حکایت می‌کند', 'مولانا'],
        ['از جمادی مُردم و نامی شدم / وز نما مُردم به حیوان برزدم', 'مولانا'],
        ['این جهان کوه است و فعل ما ندا / سوی ما آید نداها را صدا', 'مولانا'],
        ['توانا بود هر که دانا بود / ز دانش دل پیر برنا بود', 'فردوسی'],
        ['بسی رنج بردم در این سال سی / عجم زنده کردم بدین پارسی', 'فردوسی'],
        ['این کوزه چو من عاشق زاری بوده است / در بند سر زلف نگاری بوده است', 'خیام'],
    ];
}

/**
 * دریافت یک بیت تصادفی
 */
function firoozehRandomPoem(): array
{
    $poems = firoozehPoems();
    [$verse, $poet] = $poems[mt_rand(0, count($poems) - 1)];
    return ['verse' => $verse, 'poet' => $poet];
}

/**
 * قالب‌بندی خلاصهٔ اعداد به سبک شبکه‌های اجتماعی با ارقام فارسی:
 * ۹۹۹ → ۹۹۹ / ۱۰۰۰ → ۱ هزار / ۱۵۰۰ → ۱٫۵ هزار / ۱۰۰۰۰ → ۱۰ هزار / ۱۲۰۰۰۰۰ → ۱٫۲ میلیون
 */
function firoozehFormatCount(int $num): string
{
    if ($num >= 1000000) {
        return firoozehCompactNumber(round($num / 1000000, 1)) . ' ' . _t('میلیون');
    }

    if ($num >= 1000) {
        $thousands = round($num / 1000, 1);

        // گردشدن به ۱۰۰۰ هزار (مثل ۹۹۹۹۹۹) باید «۱ میلیون» نمایش دهد
        if ($thousands >= 1000) {
            return firoozehCompactNumber(round($thousands / 1000, 1)) . ' ' . _t('میلیون');
        }

        return firoozehCompactNumber($thousands) . ' ' . _t('هزار');
    }

    return toPersianDigits($num);
}

/**
 * عدد اعشاری خلاصه با ارقام فارسی؛ رقم اعشار تنها در صورت نیاز (۱٫۵ و نه ۱٫۰)
 */
function firoozehCompactNumber(float $value): string
{
    $text = number_format($value, 1, '.', '');

    if (substr($text, -2) === '.0') {
        $text = substr($text, 0, -2);
    }

    return toPersianDigits(str_replace('.', '٫', $text));
}

/**
 * متن فارسی تعداد دیدگاه با ارقام فارسی
 */
function firoozehCommentsCountText(int $num): string
{
    if ($num <= 0) {
        return _t('بدون دیدگاه');
    }

    if ($num === 1) {
        return _t('۱ دیدگاه');
    }

    return toPersianDigits($num) . ' ' . _t('دیدگاه');
}

/**
 * تبدیل ارقام لاتین متن خروجی صفحه‌بندی به فارسی؛
 * فقط متنِ میان تگ‌ها تبدیل می‌شود تا نشانی لینک‌ها دست‌نخورده بماند.
 */
function firoozehConvertNavDigits(string $html): string
{
    return (string) preg_replace_callback(
        '/>([^<>]+)</u',
        function (array $matches): string {
            return '>' . toPersianDigits($matches[1]) . '<';
        },
        $html
    );
}

/**
 * تعداد بازدید نوشته از ستون views جدول محتوا
 */
function firoozehGetViews(\Widget\Archive $archive): int
{
    try {
        return max(0, (int) $archive->views);
    } catch (\Throwable $e) {
        return 0;
    }
}

/**
 * اطمینان از وجود ستون views در جدول محتوا — یکپارچه‌سازی خودکار
 * شمارنده بازدید (الگوی پلاگین ViewsCounter) بدون نیاز به نصب پلاگین مجزا.
 * آمار نسخه‌های پیشین (فیلد views در جدول fields) در نخستین اجرا منتقل می‌شود.
 */
function firoozehViewsSchemaReady(): bool
{
    static $ready = null;

    if ($ready !== null) {
        return $ready;
    }

    $ready = false;

    try {
        $db = \Typecho\Db::get();

        try {
            $db->fetchRow($db->select('table.contents.views')->from('table.contents')->limit(1));
            $columnExists = true;
        } catch (\Throwable $e) {
            $columnExists = false;
        }

        if (!$columnExists) {
            $prefix = $db->getPrefix();
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT DEFAULT 0');

            // انتقال آمار بازدید نسخه‌های پیشین پوسته
            try {
                $db->query(
                    'UPDATE `' . $prefix . 'contents` SET views = COALESCE((SELECT SUM(f.int_value)'
                    . ' FROM `' . $prefix . 'fields` f WHERE f.cid = `' . $prefix
                    . 'contents`.cid AND f.name = \'views\' AND f.type = \'int\'), 0)'
                );
                $db->query('DELETE FROM `' . $prefix . 'fields` WHERE name = \'views\' AND type = \'int\'');
            } catch (\Throwable $e) {
                // انتقال آمار اختیاری است و نباید نمایش صفحه را متوقف کند
            }
        }

        $ready = true;
    } catch (\Throwable $e) {
        // نبود دسترسی کافی به دیتابیس نباید سایت را از کار بیندازد
        $ready = false;
    }

    return $ready;
}

/**
 * شمارش بازدید صفحات تکی — یکپارچه با پلاگین ViewsCounter؛
 * با فعال بودن پوسته به‌طور خودکار اجرا می‌شود (قلاب beforeRender،
 * مستقل از قالب نشانی: با cid یا slug کار می‌کند).
 */
function firoozehCountView($archive): void
{
    // اگر پلاگین مستقل ViewsCounter فعال باشد، خودش شمارش می‌کند (شمارش مضاعف نمی‌شود)
    $activatedPlugins = \Widget\Options::alloc()->plugins;
    if (is_array($activatedPlugins) && isset($activatedPlugins['activated']['ViewsCounter'])) {
        return;
    }

    // بازدید کاربران واردشده (مدیر و اعضا) طبق تنظیم پوسته شمرده می‌شود یا نه
    $countLoggedIn = ((string) (\Widget\Options::alloc()->countLoggedInViews ?? '0')) === '1';
    if (\Widget\User::alloc()->hasLogin() && !$countLoggedIn) {
        return;
    }

    // شمارش فقط برای صفحات تکی انجام می‌شود
    if (!$archive instanceof \Widget\Archive || !$archive->is('single')) {
        return;
    }

    $cid = intval($archive->cid);

    if ($cid < 1) {
        return;
    }

    // فاصله زمانی جلوگیری از شمارش بازدیدهای مکرر
    $interval = (int) (\Widget\Options::alloc()->viewsInterval ?? 3600);

    if ($interval > 0) {
        $viewed = (string) \Typecho\Cookie::get('firoozehViews', '');
        $viewedIds = $viewed === '' ? [] : explode(',', $viewed);

        if (in_array((string) $cid, $viewedIds, true)) {
            return;
        }

        $viewedIds[] = (string) $cid;

        // جلوگیری از بزرگ‌شدن بی‌رویه کوکی
        if (count($viewedIds) > 100) {
            $viewedIds = array_slice($viewedIds, -100);
        }

        \Typecho\Cookie::set('firoozehViews', implode(',', $viewedIds), time() + $interval);
    }

    if (!firoozehViewsSchemaReady()) {
        return;
    }

    try {
        $db = \Typecho\Db::get();
        $db->query(
            $db->update('table.contents')
                ->expression('views', 'views + 1')
                ->where('cid = ?', $cid)
        );
    } catch (\Throwable $e) {
        // خطا در شمارش بازدید نباید نمایش صفحه را متوقف کند
    }
}

/**
 * راه‌انداز پوسته — ثبت قلاب شمارنده بازدید یکپارچه
 */
function themeInit(\Widget\Archive $archive)
{
    // شمارنده بازدید در همه قالب‌های نشانی (cid یا slug) به‌صورت خودکار فعال است
    \Typecho\Plugin::factory('Widget\Archive')->beforeRender = 'firoozehCountView';
}

/**
 * آمار کلی سایت برای بخش هرو — نوشته، دیدگاه و مجموع بازدیدها.
 *
 * بازدیدها از ستون views جدول محتوا خوانده می‌شود؛ این ستون مستقل از
 * پوسته است و با غیرفعال‌شدن یا تعویض پوسته حذف نمی‌شود (هم‌راستا با
 * پلاگین ViewsCounter که در همین ستون می‌نویسد).
 */
function firoozehStats(): array
{
    $posts = 0;
    $comments = 0;
    $views = 0;

    try {
        $db = \Typecho\Db::get();
        $posts = (int) $db->fetchObject(
            $db->select(['COUNT(table.contents.cid)' => 'num'])
                ->from('table.contents')
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.status = ?', 'publish')
        )->num;
        $comments = (int) $db->fetchObject(
            $db->select(['COUNT(table.comments.coid)' => 'num'])
                ->from('table.comments')
                ->where('table.comments.type = ?', 'comment')
                ->where('table.comments.status = ?', 'approved')
        )->num;

        if (firoozehViewsSchemaReady()) {
            $views = (int) $db->fetchObject(
                $db->select(['COALESCE(SUM(table.contents.views), 0)' => 'total'])
                    ->from('table.contents')
                    ->where('table.contents.status = ?', 'publish')
            )->total;
        }
    } catch (\Exception $e) {
        // نبود دسترسی کافی به دیتابیس نباید نمایش هرو را از کار بیندازد
    }

    return ['posts' => $posts, 'comments' => $comments, 'views' => $views];
}

/**
 * انتخاب کاربر برای آمار هرو (چک‌باکس)؛ سازگار با تنظیم showStats نسخه‌های پیشین:
 * اگر heroStats هنوز ذخیره نشده باشد، مقدار قدیمی showStats تعیین‌کننده است.
 */
function firoozehHeroStatsSelection($options): array
{
    $selected = $options->heroStats ?? null;

    if (!is_array($selected)) {
        // نسخه‌های پیشین پوسته — showStats: 1 = نوشته و دیدگاه، 0 = مخفی کامل
        return (($options->showStats ?? '1') === '1') ? ['posts', 'comments'] : [];
    }

    $valid = [];
    foreach (['posts', 'comments', 'views'] as $key) {
        if (in_array($key, $selected, true)) {
            $valid[] = $key;
        }
    }

    return $valid;
}

/**
 * تنظیمات پوسته در پیشخوان
 */
function themeConfig($form)
{
    $logoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'logoUrl',
        null,
        null,
        _t('نشانی لوگو'),
        _t('نشانی یک تصویر را وارد کنید تا در کنار عنوان سایت نمایش داده شود')
    );
    $form->addInput($logoUrl->addRule('url', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $colorSchema = new \Typecho\Widget\Helper\Form\Element\Select(
        'colorSchema',
        [
            'auto'  => _t('خودکار (پیروی از سیستم)'),
            'light' => _t('روشن'),
            'dark'  => _t('تیره'),
        ],
        'auto',
        _t('حالت رنگی'),
        _t('حالت پیش‌فرض رنگی پوسته')
    );
    $form->addInput($colorSchema);

    $accentPreset = new \Typecho\Widget\Helper\Form\Element\Select(
        'accentPreset',
        [
            'turquoise' => _t('فیروزه‌ای (پیشنهادی)'),
            'lapis'     => _t('لاجوردی'),
            'saffron'   => _t('زعفرانی'),
        ],
        'turquoise',
        _t('رنگ تأکیدی'),
        _t('رنگ اصلی لینک‌ها، دکمه‌ها و نوار پیشرفت مطالعه')
    );
    $form->addInput($accentPreset);

    $showHero = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showHero',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('هرو صفحه اصلی'),
        _t('نمایش بخش معرفی تمام‌عرض در بالای صفحه اصلی')
    );
    $form->addInput($showHero);

    $heroTagline = new \Typecho\Widget\Helper\Form\Element\Text(
        'heroTagline',
        null,
        null,
        _t('شعار هرو'),
        _t('متنی کوتاه و زیبا برای هرو؛ اگر خالی بماند، توضیحات سایت نمایش داده می‌شود')
    );
    $form->addInput($heroTagline);

    $heroMedia = new \Typecho\Widget\Helper\Form\Element\Select(
        'heroMedia',
        [
            'pattern' => _t('نقش هندسی (پیش‌فرض)'),
            'image'   => _t('تصویر'),
            'video'   => _t('ویدئوی کوتاه'),
        ],
        'pattern',
        _t('پس‌زمینه هرو'),
        _t('نوع پس‌زمینه بخش هرو؛ با انتخاب تصویر یا ویدئو، به‌جای نقش هندسی نمایش داده می‌شود')
    );
    $form->addInput($heroMedia);

    $heroImageUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'heroImageUrl',
        null,
        null,
        _t('نشانی تصویر هرو'),
        _t('تصویر پس‌زمینه هرو (الزامی وقتی نوع پس‌زمینه «تصویر» است)؛ برای ویدئو هم به‌عنوان تصویر پیش‌نمایش به‌کار می‌رود')
    );
    $form->addInput($heroImageUrl);

    $heroVideoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'heroVideoUrl',
        null,
        null,
        _t('نشانی ویدئوی هرو'),
        _t('ویدئوی کوتاه MP4 برای پس‌زمینه هرو (الزامی وقتی نوع پس‌زمینه «ویدئو» است)؛ بی‌صدا و خودکار پخش و در پایان تکرار می‌شود')
    );
    $form->addInput($heroVideoUrl);

    $heroStats = new \Typecho\Widget\Helper\Form\Element\Checkbox(
        'heroStats',
        [
            'posts'    => _t('تعداد نوشته‌ها'),
            'comments' => _t('تعداد دیدگاه‌ها'),
            'views'    => _t('مجموع بازدیدها'),
        ],
        ['posts', 'comments', 'views'],
        _t('آمار هرو'),
        _t('انتخاب کنید کدام آمار در هرو صفحه اصلی نمایش داده شود؛ اگر هیچ‌کدام انتخاب نشود، بخش آمار به‌طور کامل از هرو حذف می‌شود. مجموع بازدیدها از شمارندهٔ یکپارچهٔ پوسته خوانده می‌شود و مثل شبکه‌های اجتماعی خلاصه نمایش داده می‌شود (۱ هزار / ۱۰ هزار)')
    );
    $form->addInput($heroStats);

    $countLoggedInViews = new \Typecho\Widget\Helper\Form\Element\Radio(
        'countLoggedInViews',
        ['0' => _t('شمرده نشود (پیشنهادی)'), '1' => _t('شمرده شود')],
        '0',
        _t('بازدید کاربران واردشده'),
        _t('اگر «شمرده نشود» باشد، بازدید مدیر و کاربران واردشده از صفحات تکی در آمار ثبت نمی‌شود (رفتار پیش‌فرض و هم‌راستا با پلاگین ViewsCounter)')
    );
    $form->addInput($countLoggedInViews);

    $sidebarBio = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'sidebarBio',
        null,
        null,
        _t('بیوگرافی نویسنده'),
        _t('متنی کوتاه درباره خودتان برای کارت نویسنده در ستون کناری')
    );
    $form->addInput($sidebarBio);

    $popularCount = new \Typecho\Widget\Helper\Form\Element\Select(
        'popularCount',
        ['3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶'],
        '5',
        _t('تعداد نوشته‌های محبوب'),
        _t('نوشته‌های محبوب برای نمایش در ستون کناری (۰ = مخفی)')
    );
    $form->addInput($popularCount);

    $popularBasis = new \Typecho\Widget\Helper\Form\Element\Select(
        'popularBasis',
        [
            'views'    => _t('بیشترین بازدید (پیشنهادی)'),
            'comments' => _t('بیشترین دیدگاه'),
        ],
        'views',
        _t('پایه محبوبیت نوشته‌ها'),
        _t('محبوب‌ترین نوشته‌ها بر پایه بازدید شمرده‌شده فهرست می‌شوند؛ تا زمانی که هنوز آمار بازدیدی ثبت نشده باشد، خودکار بر پایه بیشترین دیدگاه مرتب می‌شود')
    );
    $form->addInput($popularBasis);

    $viewsInterval = new \Typecho\Widget\Helper\Form\Element\Select(
        'viewsInterval',
        [
            '3600'   => _t('۱ ساعت (پیشنهادی)'),
            '21600'  => _t('۶ ساعت'),
            '86400'  => _t('۲۴ ساعت'),
            '0'      => _t('بدون فاصله؛ هر بازدید شمرده شود'),
        ],
        '3600',
        _t('فاصله شمارش بازدید مکرر'),
        _t('بازدید تکراری یک نوشته در این بازه فقط یک بار شمرده می‌شود (الگوی پلاگین ViewsCounter)؛ بازدید کاربران واردشده هرگز شمرده نمی‌شود')
    );
    $form->addInput($viewsInterval);

    $showFooterPoem = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showFooterPoem',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('بیت تصادفی در پانوشت'),
        _t('نمایش بیت تصادفی از شاعران بزرگ ایران در پانوشت سایت')
    );
    $form->addInput($showFooterPoem);

    $showReadingTime = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showReadingTime',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('زمان مطالعه'),
        _t('نمایش تخمین زمان مطالعه در اطلاعات هر نوشته')
    );
    $form->addInput($showReadingTime);
}

/**
 * کادر سفارشی «تصویر شاخص» در پیشخوان نوشته و برگه
 */
function themeFields($layout)
{
    $thumb = new \Typecho\Widget\Helper\Form\Element\Text(
        'thumb',
        null,
        null,
        _t('تصویر شاخص'),
        _t('نشانی تصویر شاخص این نوشته را وارد کنید تا با قاب اختصاصی در فهرست و ابتدای نوشته نمایش داده شود')
    );
    $layout->addItem($thumb);
}

/**
 * ویجت نوشته‌های محبوب — بر پایه بیشترین بازدید (ستون views)،
 * با جایگزینی خودکار بر پایه بیشترین دیدگاه هنگام نبود آمار بازدید
 */
if (!class_exists('FiroozehPopularPosts')) {
    class FiroozehPopularPosts extends \Widget\Base\Contents
    {
        public function execute()
        {
            $this->parameter->setDefault(['pageSize' => 5]);
            $limit = max(1, intval($this->parameter->pageSize));

            // پایه محبوبیت از تنظیمات پوسته
            $basis = (string) ($this->options->popularBasis ?? 'views');
            if (!in_array($basis, ['views', 'comments'], true)) {
                $basis = 'views';
            }

            $schemaReady = firoozehViewsSchemaReady();

            // در نبود هرگونه آمار بازدید، به‌طور خودکار بر پایه دیدگاه مرتب می‌شود
            if ($basis === 'views' && $schemaReady) {
                try {
                    $totalViews = (int) $this->db->fetchObject(
                        $this->db->select(['COALESCE(SUM(table.contents.views), 0)' => 'total'])
                            ->from('table.contents')
                            ->where('table.contents.type = ?', 'post')
                            ->where('table.contents.status = ?', 'publish')
                    )->total;
                } catch (\Throwable $e) {
                    $totalViews = 0;
                }

                if ($totalViews < 1) {
                    $basis = 'comments';
                }
            } elseif ($basis === 'views') {
                $basis = 'comments';
            }

            $select = $this->select('table.contents.*')
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', $this->options->time)
                ->where('table.contents.type = ?', 'post')
                ->where("table.contents.password IS NULL OR table.contents.password = ''")
                ->order(
                    $basis === 'views' ? 'table.contents.views' : 'table.contents.commentsNum',
                    \Typecho\Db::SORT_DESC
                )
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit($limit);

            $this->db->fetchAll($select, [$this, 'push']);
        }
    }
}

/**
 * نشانی تصویر شاخص نوشته از فیلد سفارشی thumb
 */
function firoozehPostThumb(\Widget\Archive $archive): string
{
    $thumb = '';
    $fields = $archive->fields;

    if ($fields instanceof \Typecho\Config && isset($fields->thumb)) {
        $thumb = trim((string) $fields->thumb);
    }

    if ($thumb === '' || !preg_match('#^(https?://|/)#i', $thumb)) {
        return '';
    }

    return $thumb;
}

/**
 * اطلاعات هر نوشته: عنوان، نویسنده، تاریخ، دسته، زمان مطالعه و دیدگاه
 */
function postMeta(\Widget\Archive $archive, string $metaType = 'archive')
{
    $titleTag = $metaType === 'archive' ? 'h2' : 'h1';
    $showReadingTime = ($archive->options->showReadingTime ?? '1') === '1';
    $postViews = firoozehGetViews($archive);
?>
    <<?php echo $titleTag; ?> class="post-title" itemprop="name headline">
        <a itemprop="url" href="<?php $archive->permalink(); ?>"><?php $archive->title(); ?></a>
    </<?php echo $titleTag; ?>>

    <?php if ($metaType !== 'page'): ?>
        <ul class="post-meta">
            <li itemprop="author" itemscope itemtype="http://schema.org/Person">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                <a itemprop="name" href="<?php $archive->author->permalink(); ?>" rel="author"><?php $archive->author(); ?></a>
            </li>
            <li>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                <time datetime="<?php $archive->date('c'); ?>" itemprop="datePublished"><?php echo toPersianDigits($archive->date->format('Y/m/d')); ?></time>
            </li>
            <li>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
                <?php $archive->category(','); ?>
            </li>
            <?php if ($showReadingTime): ?>
                <li class="meta-reading-time">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                    <?php echo toPersianDigits(firoozehReadingTime((string) $archive->text)); ?> دقیقه مطالعه
                </li>
            <?php endif; ?>
            <?php if ($metaType === 'post' && $postViews > 0): ?>
                <li class="meta-views">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                    <?php echo toPersianDigits($postViews); ?> بازدید
                </li>
            <?php endif; ?>
            <?php if ($metaType === 'archive'): ?>
                <li itemprop="interactionCount">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                    <a itemprop="discussionUrl" href="<?php $archive->permalink(); ?>#comments"><?php echo firoozehCommentsCountText((int) $archive->commentsNum); ?></a>
                </li>
            <?php endif; ?>
        </ul>
    <?php endif; ?>
<?php
}

/**
 * رندر محتوای نوشته یا برگه
 */
function renderSingle(\Widget\Archive $archive, string $metaType = 'post'): void
{
    $thumb = firoozehPostThumb($archive);
?>
    <article class="post" itemscope itemtype="http://schema.org/BlogPosting">
        <?php postMeta($archive, $metaType); ?>
        <?php if ($thumb !== ''): ?>
            <figure class="post-hero-image" itemprop="image" itemscope itemtype="http://schema.org/ImageObject">
                <img src="<?php echo htmlspecialchars($thumb, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($archive->title, ENT_QUOTES, 'UTF-8'); ?>" itemprop="url" />
            </figure>
        <?php endif; ?>
        <div class="post-content" itemprop="articleBody">
            <?php $archive->content(); ?>
        </div>
        <?php if ($metaType === 'post' && count($archive->tags) > 0): ?>
            <p itemprop="keywords" class="tags">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>
                <?php $archive->tags('، ', true, 'none'); ?>
            </p>
        <?php endif; ?>
    </article>
<?php
}

/**
 * کارت نوشته در فهرست
 */
function renderPostCard(\Widget\Archive $archive): void
{
    $thumb = firoozehPostThumb($archive);
?>
    <article class="post-card" itemscope itemtype="http://schema.org/BlogPosting">
        <?php if ($thumb !== ''): ?>
            <a class="post-card-thumb" href="<?php $archive->permalink(); ?>" tabindex="-1" aria-hidden="true">
                <img src="<?php echo htmlspecialchars($thumb, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($archive->title, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy" itemprop="image" />
            </a>
        <?php endif; ?>
        <div class="post-card-body">
            <?php postMeta($archive, 'archive'); ?>
            <div class="post-excerpt" itemprop="description">
                <?php $archive->excerpt(200, '…'); ?>
            </div>
            <div class="post-card-actions">
                <a class="read-more" href="<?php $archive->permalink(); ?>" itemprop="url">
                    <span><?php _e('ادامه مطلب'); ?></span>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
                </a>
            </div>
        </div>
    </article>
<?php
}

/**
 * دیدگاه‌های درختی
 */
function threadedComments($comments, $options)
{
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
?>
    <li id="li-<?php $comments->theId(); ?>" class="comment-body<?php
    if ($comments->levels > 0) {
        echo ' comment-child';
        $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
    } else {
        echo ' comment-parent';
    }
    $comments->alt(' comment-odd', ' comment-even');
    echo $commentClass;
    ?>">
        <div id="<?php $comments->theId(); ?>" class="comment-inner">
            <div class="comment-author-avatar">
                <?php $comments->gravatar('40', ''); ?>
            </div>
            <div class="comment-main">
                <div class="comment-meta">
                    <cite class="comment-author" itemprop="creator" itemscope itemtype="http://schema.org/Person">
                        <?php $comments->author(); ?>
                    </cite>
                    <span class="comment-time">
                        <a href="<?php $comments->permalink(); ?>" itemprop="url">
                            <time datetime="<?php $comments->date('c'); ?>" itemprop="commentTime"><?php echo toPersianDigits($comments->date->format('Y/m/d')); ?></time>
                        </a>
                    </span>
                    <span class="comment-reply">
                        <?php $comments->reply(_t('پاسخ')); ?>
                    </span>
                </div>
                <div class="comment-content" itemprop="commentText">
                    <?php $comments->content(); ?>
                </div>
            </div>
        </div>
        <?php if ($comments->children) { ?>
            <div class="comment-children">
                <?php $comments->threadedComments($options); ?>
            </div>
        <?php } ?>
    </li>
<?php
}
