<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $requireUrl = isset($this->options->commentsRequireUrl) ? $this->options->commentsRequireUrl : $this->options->commentsRequireURL; ?>

<div id="comments" class="comments-area">
    <?php $this->comments()->to($comments); ?>

    <div class="comments-wrapper">
        <?php if ($comments->have()): ?>
            <div class="comments-header">
                <h3 class="comments-title">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                    <?php $commentsCount = (int) $this->commentsNum; ?>
                    <?php echo $commentsCount < 1 ? _t('هنوز دیدگاهی نیست') : firoozehCommentsCountText($commentsCount); ?>
                </h3>
            </div>

            <div class="comments-body">
                <?php $comments->listComments([
                    'before'        => '<ul class="comment-list">',
                    'after'         => '</ul>',
                    'commentStatus' => _t('در انتظار تأیید')
                ]); ?>

                <?php
                    ob_start();
                    $comments->pageNav('«', '»');
                    echo firoozehConvertNavDigits((string) ob_get_clean());
                ?>
            </div>
        <?php endif; ?>

        <?php if ($this->allow('comment')): ?>
            <div id="<?php $this->respondId(); ?>" class="respond">
                <div class="cancel-comment-reply">
                    <?php $comments->cancelReply(); ?>
                </div>

                <h3 id="response" class="respond-title"><?php _e('دیدگاه خود را بنویسید'); ?></h3>
                <form method="post" action="<?php $this->commentUrl() ?>" id="comment-form" role="form">
                    <?php $security = $this->widget('\Widget\Security'); ?>
                    <input type="hidden" name="_" value="<?php echo htmlspecialchars($security->getToken($this->request->getRequestUrl()), ENT_QUOTES, 'UTF-8'); ?>">
                    <?php if ($this->user->hasLogin()): ?>
                        <p class="respond-login-note">
                            <?php _e('خوش آمدید'); ?>، <a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>.
                            <a href="<?php $this->options->logoutUrl(); ?>" title="Logout"><?php _e('خروج'); ?> »</a>
                        </p>
                    <?php else: ?>
                        <div class="respond-fields">
                            <div class="form-group">
                                <input type="text" name="author" id="author" class="form-input" placeholder="<?php _e('نام شما *'); ?>" aria-label="<?php _e('نام'); ?>" value="<?php $this->remember('author'); ?>" required />
                            </div>
                            <div class="form-group">
                                <input type="email" name="mail" id="mail" class="form-input" placeholder="<?php _e('ایمیل' . ($this->options->commentsRequireMail ? ' *' : '')); ?>" aria-label="<?php _e('ایمیل'); ?>" value="<?php $this->remember('mail'); ?>"<?php if ($this->options->commentsRequireMail): ?> required<?php endif; ?> />
                            </div>
                            <div class="form-group">
                                <input type="url" name="url" id="url" class="form-input" placeholder="<?php _e('وب‌سایت' . ($requireUrl ? ' *' : '')); ?>" aria-label="<?php _e('وب‌سایت'); ?>" value="<?php $this->remember('url'); ?>"<?php if ($requireUrl): ?> required<?php endif; ?> />
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <textarea name="text" id="textarea" class="form-input" rows="5" placeholder="<?php _e('آنچه در ذهن دارید را با ما بنویسید…'); ?>" aria-label="<?php _e('متن دیدگاه'); ?>" required><?php $this->remember('text'); ?></textarea>
                    </div>
                    <div class="form-group form-submit">
                        <button type="submit" class="btn-primary">
                            <span><?php _e('فرستادن دیدگاه'); ?></span>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                        </button>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <div class="comments-closed">
                <?php _e('نوشتن دیدگاه برای این مطلب بسته شده است.'); ?>
            </div>
        <?php endif; ?>
    </div>
</div>
