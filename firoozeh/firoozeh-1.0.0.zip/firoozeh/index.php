<?php
/**
 * فیروزه — پوسته‌ای مدرن با الهام از فرهنگ ایران
 *
 * @package فیروزه
 * @author پوردریایی
 * @version 1.0.0
 * @link https://pourdaryaei.ir
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');
?>

<div class="layout<?php echo $this->is('index') ? ' layout-index' : ''; ?>">
    <div class="layout-primary">

        <?php if (!($this->is('index')) && !($this->is('post'))): ?>
            <div class="archive-header">
                <span class="archive-header-icon" aria-hidden="true">
                    <?php if ($this->is('category')): ?>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
                    <?php elseif ($this->is('search')): ?>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    <?php elseif ($this->is('tag')): ?>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>
                    <?php else: ?>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                    <?php endif; ?>
                </span>
                <?php $this->archiveTitle([
                    'category' => _t('%s'),
                    'search'   => _t('%s'),
                    'tag'      => _t('%s'),
                    'author'   => _t('%s')
                ], '<h2 class="archive-title">', '</h2>'); ?>
                <?php if ($this->is('search') || $this->is('category') || $this->is('tag')): ?>
                    <p class="archive-subtitle"><?php _e('همه نوشته‌های این بخش، از تازه‌ترین آغاز می‌شوند'); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if ($this->have()): ?>
            <div class="post-list">
                <?php while ($this->next()): ?>
                    <?php renderPostCard($this); ?>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <div class="empty-state-ornament" aria-hidden="true">
                    <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                </div>
                <h2 class="empty-state-title"><?php _e('چیزی این‌جا نیست'); ?></h2>
                <p class="empty-state-text">
                    <?php $this->archiveTitle([
                        'category' => _t('هنوز در دسته «%s» نوشته‌ای منتشر نشده است.'),
                        'search'   => _t('برای «%s» نتیجه‌ای پیدا نشد؛ عبارت دیگری را بیازمایید.'),
                        'tag'      => _t('هنوز نوشته‌ای با برچسب «%s» منتشر نشده است.'),
                        'author'   => _t('هنوز %s نوشته‌ای منتشر نکرده است.')
                    ], '', ''); ?>
                </p>
                <a class="btn-primary" href="<?php $this->options->siteUrl(); ?>">
                    <span><?php _e('بازگشت به خانه'); ?></span>
                </a>
            </div>
        <?php endif; ?>

        <nav class="pagination-area" aria-label="<?php _e('صفحه‌بندی'); ?>">
            <?php
                ob_start();
                $this->pageNav(
                    '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18l6-6-6-6"></path></svg>',
                    '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"></path></svg>',
                    3,
                    '…'
                );
                echo firoozehConvertNavDigits((string) ob_get_clean());
            ?>
        </nav>

    </div>
    <?php $this->need('sidebar.php'); ?>
</div>

<?php $this->need('footer.php'); ?>
