<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<aside class="layout-sidebar" aria-label="<?php _e('ستون کناری'); ?>">

    <?php $sidebarBio = trim((string) ($this->options->sidebarBio ?? '')); ?>
    <section class="widget widget-author">
        <h3 class="widget-title">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
            <?php _e('درباره نویسنده'); ?>
        </h3>
        <div class="author-card">
            <div class="author-avatar" aria-hidden="true">
                <svg width="34" height="34" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l2.4 7.6L22 12l-7.6 2.4L12 22l-2.4-7.6L2 12l7.6-2.4z"/></svg>
            </div>
            <p class="author-name"><?php $this->options->title(); ?></p>
            <?php if ($sidebarBio !== ''): ?>
                <p class="author-bio"><?php echo htmlspecialchars($sidebarBio, ENT_QUOTES, 'UTF-8'); ?></p>
            <?php else: ?>
                <p class="author-bio"><?php _e('به این دفترچه خوش آمدید؛ جایی برای ثبت داستان‌های کوچک و بزرگ ایرانی.'); ?></p>
            <?php endif; ?>
        </div>
    </section>

    <?php
        $popularCount = intval($this->options->popularCount ?? '5');
        if ($popularCount > 0):
            FiroozehPopularPosts::alloc('pageSize=' . $popularCount)->to($popular);
            if ($popular->have()):
    ?>
    <section class="widget widget-popular">
        <h3 class="widget-title">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 17.75L6.16 21l1.12-6.5L2 9.24l6.54-.95L12 2l3.46 6.29 6.54.95-5.28 5.25L17.84 21z"></path></svg>
            <?php _e('محبوب‌ترین نوشته‌ها'); ?>
        </h3>
        <ol class="popular-list">
            <?php $rank = 0; while ($popular->next()): $rank++; ?>
                <li class="popular-item">
                    <span class="popular-rank" aria-hidden="true"><?php echo toPersianDigits($rank); ?></span>
                    <div class="popular-item-main">
                        <a class="popular-item-title" href="<?php $popular->permalink(); ?>"><?php $popular->title(); ?></a>
                        <span class="popular-item-meta">
                            <?php echo toPersianDigits(max(0, (int) $popular->views)); ?> بازدید
                            <span class="popular-meta-sep" aria-hidden="true">·</span>
                            <?php echo firoozehCommentsCountText((int) $popular->commentsNum); ?>
                        </span>
                    </div>
                </li>
            <?php endwhile; ?>
        </ol>
    </section>
    <?php endif; endif; ?>

    <?php \Widget\Metas\Category\Rows::alloc()->to($categories); ?>
    <?php if ($categories->have()): ?>
    <section class="widget widget-categories">
        <h3 class="widget-title">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
            <?php _e('دسته‌بندی‌ها'); ?>
        </h3>
        <ul class="category-list">
            <?php while ($categories->next()): ?>
                <li class="category-item">
                    <a href="<?php $categories->permalink(); ?>"><?php $categories->name(); ?></a>
                    <span class="category-count"><?php echo toPersianDigits($categories->count); ?></span>
                </li>
            <?php endwhile; ?>
        </ul>
    </section>
    <?php endif; ?>

    <?php $sidebarPoem = firoozehRandomPoem(); ?>
    <section class="widget widget-poem">
        <h3 class="widget-title">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
            <?php _e('فال حافظ'); ?>
        </h3>
        <figure class="poem-card">
            <blockquote class="poem-verse"><?php echo $sidebarPoem['verse']; ?></blockquote>
            <figcaption class="poem-poet"><?php echo $sidebarPoem['poet']; ?></figcaption>
        </figure>
    </section>

</aside>
