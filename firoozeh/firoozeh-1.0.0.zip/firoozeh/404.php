<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="layout">
    <div class="layout-primary">

        <div class="empty-state empty-404">
            <div class="empty-state-ornament" aria-hidden="true">
                <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l2.4 7.6L22 12l-7.6 2.4L12 22l-2.4-7.6L2 12l7.6-2.4z"/></svg>
            </div>
            <h2 class="empty-state-code"><?php _e('۴۰۴'); ?></h2>
            <p class="empty-state-text">
                <?php _e('این صفحه در دیوان ما ثبت نشده است؛ شاید در نوبت طبع بعدی بیاید.'); ?>
            </p>
            <?php $poem404 = firoozehRandomPoem(); ?>
            <figure class="poem-404">
                <blockquote><?php echo $poem404['verse']; ?></blockquote>
                <figcaption>— <?php echo $poem404['poet']; ?></figcaption>
            </figure>
            <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="search-404">
                <input type="search" name="s" class="search-input" placeholder="<?php _e('شاید بتوانید پیدایش کنید…'); ?>" aria-label="<?php _e('جستجو'); ?>" autofocus />
                <button type="submit" class="btn-primary"><?php _e('جستجو'); ?></button>
            </form>
        </div>

    </div>
    <?php $this->need('sidebar.php'); ?>
</div>

<?php $this->need('footer.php'); ?>
