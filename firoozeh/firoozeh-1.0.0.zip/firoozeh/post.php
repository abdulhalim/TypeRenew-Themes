<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="layout layout-single">
    <div class="layout-primary">

        <?php renderSingle($this, 'post'); ?>

        <?php
            $showReadingTime = ($this->options->showReadingTime ?? '1') === '1';
            if ($showReadingTime):
        ?>
        <div class="reading-time-note" aria-hidden="true">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
            <span><?php _e('مطالعه این نوشته حدود'); ?> <?php echo toPersianDigits(firoozehReadingTime((string) $this->text)); ?> <?php _e('دقیقه طول می‌کشد'); ?> · <?php _e('نوشته را با آرامش بخوانید'); ?></span>
        </div>
        <?php endif; ?>

        <nav class="post-near" aria-label="<?php _e('ناوبری نوشته‌ها'); ?>">
            <div class="post-near-grid">
                <?php $this->thePrev(
                    '<div class="post-near-item post-near-prev"><span class="post-near-label">' . _t('نوشتهٔ قدیمی‌تر') . '</span><span class="post-near-link">%s</span></div>',
                    '<div class="post-near-item post-near-empty"></div>',
                    ['tagClass' => 'post-near-anchor']
                ); ?>
                <?php $this->theNext(
                    '<div class="post-near-item post-near-next"><span class="post-near-label">' . _t('نوشتهٔ تازه‌تر') . '</span><span class="post-near-link">%s</span></div>',
                    '<div class="post-near-item post-near-empty"></div>',
                    ['tagClass' => 'post-near-anchor']
                ); ?>
            </div>
        </nav>

        <?php $this->need('comments.php'); ?>

    </div>
    <?php $this->need('sidebar.php'); ?>
</div>

<?php $this->need('footer.php'); ?>
