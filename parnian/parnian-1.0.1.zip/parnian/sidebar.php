<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<aside class="sidebar" role="complementary" aria-label="<?php _e('ستون کناری'); ?>">

    <?php if (parnian_opt('showSidebarSearch', '1') === '1'): ?>
        <section class="widget widget-search reveal">
            <h2 class="widget-title">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7.5"></circle><line x1="21" y1="21" x2="16.5" y2="16.5"></line></svg>
                <?php _e('جستجو'); ?>
            </h2>
            <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="widget-search-form">
                <input type="search" name="s" placeholder="<?php _e('جستجو در نوشته‌ها…'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" value="<?php echo htmlspecialchars((string) ($this->request->keywords ?? $this->request->s ?? ''), ENT_QUOTES, 'UTF-8'); ?>">
                <button type="submit" aria-label="<?php _e('جستجو'); ?>">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7.5"></circle><line x1="21" y1="21" x2="16.5" y2="16.5"></line></svg>
                </button>
            </form>
        </section>
    <?php endif; ?>

    <section class="widget widget-about reveal">
        <h2 class="widget-title">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><path d="M12 8v.01M12 11.5v5"></path></svg>
            <?php _e('درباره'); ?>
        </h2>
        <div class="about-avatar">
            <?php
                $aboutAvatar = trim((string) parnian_opt('avatarUrl'));
                if ($aboutAvatar !== ''):
            ?>
                <img src="<?php echo htmlspecialchars(parnian_resolve_url($aboutAvatar), ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->options->title(); ?>" width="72" height="72" loading="lazy">
            <?php else: ?>
                <span class="about-avatar-fallback" aria-hidden="true">
                    <svg viewBox="0 0 48 48" width="30" height="30" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round">
                        <rect x="14" y="14" width="20" height="20"/>
                        <rect x="14" y="14" width="20" height="20" transform="rotate(45 24 24)"/>
                    </svg>
                </span>
            <?php endif; ?>
        </div>
        <p class="about-text">
            <?php
                $about = trim((string) parnian_opt('aboutText'));
                echo nl2br($about !== '' ? htmlspecialchars($about, ENT_QUOTES, 'UTF-8') : htmlspecialchars((string) $this->options->description, ENT_QUOTES, 'UTF-8'));
            ?>
        </p>
        <div class="about-social">
            <?php
                $socials = [
                    ['socialTelegram', 'M21.9 4.6l-3.1 14.7c-.2 1-.8 1.3-1.7.8l-4.7-3.5-2.3 2.2c-.25.25-.47.47-.94.47l.33-4.8L18.2 6.6c.37-.33-.08-.52-.58-.19L6.9 13.7l-4.6-1.44c-1-.31-1-1 .21-1.48L20.6 3.1c.83-.3 1.56.2 1.3 1.5z', 'تلگرام', false],
                    ['socialGithub', 'M12 .5A11.5 11.5 0 0 0 .5 12a11.5 11.5 0 0 0 7.86 10.91c.58.11.79-.25.79-.56v-2.17c-3.2.7-3.87-1.36-3.87-1.36-.53-1.34-1.28-1.7-1.28-1.7-1.05-.72.08-.7.08-.7 1.16.08 1.77 1.19 1.77 1.19 1.03 1.77 2.7 1.26 3.36.96.1-.75.4-1.26.73-1.55-2.55-.29-5.23-1.28-5.23-5.68 0-1.26.45-2.28 1.19-3.09-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.17 1.18a11 11 0 0 1 5.77 0c2.2-1.49 3.16-1.18 3.16-1.18.63 1.59.24 2.76.12 3.05.74.81 1.18 1.83 1.18 3.09 0 4.41-2.68 5.38-5.24 5.67.41.35.78 1.05.78 2.11v3.13c0 .31.2.68.8.56A11.5 11.5 0 0 0 23.5 12 11.5 11.5 0 0 0 12 .5z', 'گیت‌هاب', false],
                    ['socialInstagram', null, 'اینستاگرام', true],
                    ['socialLinkedin', 'M4.98 3.5C4.98 4.88 3.87 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1s2.48 1.12 2.48 2.5zM.22 8.1h4.56V23H.22V8.1zM8.34 8.1h4.37v2.03h.06c.61-1.15 2.1-2.37 4.32-2.37 4.62 0 5.47 3.04 5.47 7v8.24h-4.55v-7.3c0-1.74-.03-3.98-2.43-3.98-2.43 0-2.8 1.9-2.8 3.85V23H8.34V8.1z', 'لینکدین', false],
                ];
                foreach ($socials as [$key, $path, $label, $isStrokeIcon]):
                    $url = trim((string) parnian_opt($key));
                    if ($url === '') {
                        continue;
                    }
            ?>
                <a href="<?php echo htmlspecialchars(parnian_resolve_url($url), ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" aria-label="<?php echo $label; ?>" title="<?php echo $label; ?>">
                    <?php if ($isStrokeIcon): ?>
                        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2.5" y="2.5" width="19" height="19" rx="5"></rect><circle cx="12" cy="12" r="4.5"></circle><circle cx="17.8" cy="6.2" r="1.1" fill="currentColor" stroke="none"></circle></svg>
                    <?php else: ?>
                        <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="<?php echo $path; ?>"/></svg>
                    <?php endif; ?>
                </a>
            <?php endforeach; ?>
            <a href="<?php $this->options->feedUrl(); ?>" target="_blank" rel="noopener" aria-label="RSS" title="RSS">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6.18 15.64a2.18 2.18 0 1 1 0 4.36 2.18 2.18 0 0 1 0-4.36zM4 4.44v2.83c7.03 0 12.73 5.7 12.73 12.73h2.83c0-8.59-6.97-15.56-15.56-15.56zm0 5.66v2.83c3.9 0 7.07 3.17 7.07 7.07h2.83c0-5.47-4.43-9.9-9.9-9.9z"/></svg>
            </a>
        </div>
    </section>

    <section class="widget widget-recent reveal">
        <h2 class="widget-title">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15.5 14"></polyline></svg>
            <?php _e('تازه‌ترین نوشته‌ها'); ?>
        </h2>
        <?php ParnianRecentPosts::allocWithAlias('parnian-recent', ['pageSize' => 5])->to($recentPosts); ?>
        <?php if ($recentPosts->have()): ?>
            <ul class="recent-list">
                <?php while ($recentPosts->next()): ?>
                    <li class="recent-item">
                        <a href="<?php $recentPosts->permalink(); ?>" class="recent-link">
                            <?php
                                $recentCover = parnian_thumbnail($recentPosts);
                                if ($recentCover !== ''):
                            ?>
                                <span class="recent-thumb">
                                    <img src="<?php echo htmlspecialchars($recentCover, ENT_QUOTES, 'UTF-8'); ?>" alt="" loading="lazy">
                                </span>
                            <?php else: ?>
                                <span class="recent-thumb recent-thumb-pattern" aria-hidden="true">
                                    <svg viewBox="0 0 48 48" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="14" y="14" width="20" height="20"/><rect x="14" y="14" width="20" height="20" transform="rotate(45 24 24)"/></svg>
                                </span>
                            <?php endif; ?>
                            <span class="recent-info">
                                <span class="recent-title"><?php $recentPosts->title(); ?></span>
                                <time class="recent-date" datetime="<?php echo date('c', (int) $recentPosts->created); ?>"><?php $recentPosts->date(); ?></time>
                            </span>
                        </a>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p class="widget-empty"><?php _e('هنوز نوشته‌ای منتشر نشده است.'); ?></p>
        <?php endif; ?>
    </section>

    <?php \Widget\Metas\Category\Rows::allocWithAlias('parnian-sidebar')->to($sidebarCategories); ?>
    <?php if ($sidebarCategories->have()): ?>
        <section class="widget widget-categories reveal">
            <h2 class="widget-title">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
                <?php _e('دسته‌ها'); ?>
            </h2>
            <ul class="category-list">
                <?php while ($sidebarCategories->next()): ?>
                    <?php if ((int) $sidebarCategories->count > 0): ?>
                        <li class="category-item">
                            <a class="category-link" href="<?php $sidebarCategories->permalink(); ?>">
                                <span class="category-dot" aria-hidden="true"></span>
                                <span class="category-name"><?php $sidebarCategories->name(); ?></span>
                                <span class="category-count"><?php echo parnian_fa_num((string) $sidebarCategories->count); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endwhile; ?>
            </ul>
        </section>
    <?php endif; ?>

    <?php \Widget\Metas\Tag\Cloud::allocWithAlias('parnian-sidebar', ['ignoreZeroCount' => true, 'limit' => 18, 'sort' => 'count', 'desc' => true])->to($sidebarTags); ?>
    <?php if ($sidebarTags->have()): ?>
        <section class="widget widget-tags reveal">
            <h2 class="widget-title">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>
                <?php _e('برچسب‌ها'); ?>
            </h2>
            <div class="tag-cloud">
                <?php while ($sidebarTags->next()): ?>
                    <a class="tag-pill" href="<?php $sidebarTags->permalink(); ?>"><?php $sidebarTags->name(); ?></a>
                <?php endwhile; ?>
            </div>
        </section>
    <?php endif; ?>

</aside>
