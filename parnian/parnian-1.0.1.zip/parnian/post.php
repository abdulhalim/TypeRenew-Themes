<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<?php $this->need('header.php'); ?>

<?php
    $showReadingTime = parnian_opt('showReadingTime', '1') === '1';
    $postCover = parnian_thumbnail($this);
    $categories = $this->categories;
?>

<div class="layout-grid layout-single">

    <div class="content-area">

        <article class="single-post reveal" itemscope itemtype="http://schema.org/BlogPosting">

            <nav class="breadcrumb" aria-label="<?php _e('مسیر صفحه'); ?>">
                <a href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a>
                <?php if (!empty($categories)): ?>
                    <span class="breadcrumb-sep" aria-hidden="true">/</span>
                    <a href="<?php echo htmlspecialchars($categories[0]['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                <?php endif; ?>
                <span class="breadcrumb-sep" aria-hidden="true">/</span>
                <span class="breadcrumb-current" aria-current="page"><?php $this->title(); ?></span>
            </nav>

            <header class="post-header">
                <h1 class="post-title" itemprop="name headline"><?php $this->title(); ?></h1>

                <div class="post-meta">
                    <span class="meta-item meta-author">
                        <?php if ($this->options->commentsAvatar): ?>
                            <span class="meta-author-avatar"><?php $this->author->gravatar(72); ?></span>
                        <?php endif; ?>
                        <a href="<?php $this->author->permalink(); ?>" rel="author" itemprop="author">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                            <?php $this->author(); ?>
                        </a>
                    </span>
                    <span class="meta-item">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2.5"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                        <time datetime="<?php echo date('c', (int) $this->created); ?>" itemprop="datePublished"><?php $this->date(); ?></time>
                    </span>
                    <?php if ($showReadingTime): ?>
                        <span class="meta-item">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15.5 14"></polyline></svg>
                            <?php echo parnian_fa_num((string) parnian_reading_time($this)); ?> <?php _e('دقیقه مطالعه'); ?>
                        </span>
                    <?php endif; ?>
                    <span class="meta-item">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                        <a href="<?php $this->permalink(); ?>#comments" itemprop="discussionUrl">
                            <?php $this->commentsNum(_t('بدون دیدگاه'), _t('یک دیدگاه'), _t('%d دیدگاه')); ?>
                        </a>
                    </span>
                </div>
            </header>

            <?php if ($postCover !== ''): ?>
                <figure class="post-hero" itemprop="image">
                    <img src="<?php echo htmlspecialchars($postCover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->title(); ?>" loading="eager">
                </figure>
            <?php endif; ?>

            <div class="post-content" itemprop="articleBody" data-plain>
                <?php $this->content(); ?>
            </div>

            <?php if ($this->tags): ?>
                <div class="post-tags" itemprop="keywords">
                    <span class="post-tags-label">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>
                        <?php _e('برچسب‌ها'); ?>:
                    </span>
                    <?php foreach ($this->tags as $tag): ?>
                        <a class="tag-pill" href="<?php echo htmlspecialchars($tag['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($tag['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="post-share">
                <span class="post-share-label"><?php _e('اشتراک‌گذاری'); ?>:</span>
                <button type="button" class="share-btn js-copy-link" title="<?php _e('کپی لینک نوشته'); ?>">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>
                    <?php _e('کپی لینک'); ?>
                </button>
                <a class="share-btn" href="https://t.me/share/url?url=<?php echo urlencode((string) $this->permalink); ?>" target="_blank" rel="noopener" title="<?php _e('اشتراک‌گذاری در تلگرام'); ?>">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.9 4.6l-3.1 14.7c-.2 1-.8 1.3-1.7.8l-4.7-3.5-2.3 2.2c-.25.25-.47.47-.94.47l.33-4.8L18.2 6.6c.37-.33-.08-.52-.58-.19L6.9 13.7l-4.6-1.44c-1-.31-1-1 .21-1.48L20.6 3.1c.83-.3 1.56.2 1.3 1.5z"/></svg>
                    <?php _e('تلگرام'); ?>
                </a>
                <?php if ($this->options->feedUrl): ?>
                    <a class="share-btn" href="<?php $this->options->feedUrl(); ?>" title="<?php _e('فید RSS'); ?>">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6.18 15.64a2.18 2.18 0 1 1 0 4.36 2.18 2.18 0 0 1 0-4.36zM4 4.44v2.83c7.03 0 12.73 5.7 12.73 12.73h2.83c0-8.59-6.97-15.56-15.56-15.56zm0 5.66v2.83c3.9 0 7.07 3.17 7.07 7.07h2.83c0-5.47-4.43-9.9-9.9-9.9z"/></svg>
                        RSS
                    </a>
                <?php endif; ?>
            </div>

        </article>

        <?php $authorBoxAvatar = trim((string) parnian_opt('avatarUrl')); ?>
        <div class="author-box reveal">
            <div class="author-box-avatar">
                <?php if ($authorBoxAvatar !== ''): ?>
                    <img src="<?php echo htmlspecialchars(parnian_resolve_url($authorBoxAvatar), ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->author(); ?>" width="72" height="72" loading="lazy">
                <?php elseif ($this->options->commentsAvatar): ?>
                    <?php $this->author->gravatar(96); ?>
                <?php else: ?>
                    <span class="about-avatar-fallback" aria-hidden="true">
                        <svg viewBox="0 0 48 48" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"><rect x="14" y="14" width="20" height="20"/><rect x="14" y="14" width="20" height="20" transform="rotate(45 24 24)"/></svg>
                    </span>
                <?php endif; ?>
            </div>
            <div class="author-box-info">
                <p class="author-box-role"><?php _e('نویسنده'); ?></p>
                <h3 class="author-box-name">
                    <a href="<?php $this->author->permalink(); ?>" rel="author"><?php $this->author(); ?></a>
                </h3>
                <a class="author-box-link" href="<?php $this->author->permalink(); ?>">
                    <?php _e('نوشته‌های این نویسنده'); ?>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="11 6 5 12 11 18"></polyline></svg>
                </a>
            </div>
        </div>

        <nav class="post-nav reveal" aria-label="<?php _e('ناوبری نوشته‌ها'); ?>">
            <div class="post-nav-item post-nav-prev">
                <span class="post-nav-label">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 6 15 12 9 18"></polyline></svg>
                    <?php _e('نوشتهٔ جدیدتر'); ?>
                </span>
                <div class="post-nav-link"><?php $this->theNext('%s', _t('نوشتهٔ جدیدتری نیست')); ?></div>
            </div>
            <div class="post-nav-item post-nav-next">
                <span class="post-nav-label">
                    <?php _e('نوشتهٔ قدیمی‌تر'); ?>
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 6 9 12 15 18"></polyline></svg>
                </span>
                <div class="post-nav-link"><?php $this->thePrev('%s', _t('نوشتهٔ قدیمی‌تری نیست')); ?></div>
            </div>
        </nav>

        <?php if (parnian_opt('showRelated', '1') === '1'): ?>
            <?php $this->related(3)->to($relatedPosts); ?>
            <?php if ($relatedPosts->have()): ?>
                <section class="related-posts reveal" aria-label="<?php _e('مطالب مرتبط'); ?>">
                    <h2 class="section-title">
                        <span class="section-title-ornament" aria-hidden="true">
                            <svg viewBox="0 0 48 48" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linejoin="round"><rect x="14" y="14" width="20" height="20"/><rect x="14" y="14" width="20" height="20" transform="rotate(45 24 24)"/></svg>
                        </span>
                        <?php _e('مطالب مرتبط'); ?>
                    </h2>
                    <div class="related-grid">
                        <?php while ($relatedPosts->next()): ?>
                            <?php $relatedCover = parnian_thumbnail($relatedPosts); ?>
                            <article class="related-card">
                                <a class="related-cover" href="<?php $relatedPosts->permalink(); ?>" aria-hidden="true" tabindex="-1">
                                    <?php if ($relatedCover !== ''): ?>
                                        <img src="<?php echo htmlspecialchars($relatedCover, ENT_QUOTES, 'UTF-8'); ?>" alt="" loading="lazy">
                                    <?php else: ?>
                                        <span class="card-cover-pattern" aria-hidden="true">
                                            <svg viewBox="0 0 48 48" width="34" height="34" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><rect x="14" y="14" width="20" height="20"/><rect x="14" y="14" width="20" height="20" transform="rotate(45 24 24)"/></svg>
                                        </span>
                                    <?php endif; ?>
                                </a>
                                <h3 class="related-title">
                                    <a href="<?php $relatedPosts->permalink(); ?>"><?php $relatedPosts->title(); ?></a>
                                </h3>
                                <time class="related-date" datetime="<?php echo date('c', (int) $relatedPosts->created); ?>"><?php $relatedPosts->date(); ?></time>
                            </article>
                        <?php endwhile; ?>
                    </div>
                </section>
            <?php endif; ?>
        <?php endif; ?>

        <?php $this->need('comments.php'); ?>

    </div>

    <?php $this->need('sidebar.php'); ?>

</div>

<?php $this->need('footer.php'); ?>
