<?php
/**
 * پرنیان — یک پوسته وبلاگی مدرن، جذاب و مینیمال
 *
 * @package پرنیان
 * @author  پوردریایی
 * @version 1.0.1
 * @link    https://www.pourdaryaei.ir
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$isHome = $this->is('index');
$heroEnabled = parnian_opt('heroPost', '1') === '1' && $isHome && $this->currentPage <= 1;
$showReadingTime = parnian_opt('showReadingTime', '1') === '1';
?>

<?php if (!$isHome): ?>
    <div class="archive-banner reveal">
        <div class="archive-banner-inner">
            <span class="archive-banner-icon" aria-hidden="true">
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <?php if ($this->is('search')): ?>
                        <circle cx="11" cy="11" r="7.5"></circle><line x1="21" y1="21" x2="16.5" y2="16.5"></line>
                    <?php elseif ($this->is('category')): ?>
                        <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
                    <?php elseif ($this->is('tag')): ?>
                        <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line>
                    <?php else: ?>
                        <circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15.5 14"></polyline>
                    <?php endif; ?>
                </svg>
            </span>
            <h1 class="archive-banner-title">
                <?php $this->archiveTitle([
                    'category' => _t('دستهٔ %s'),
                    'search'   => _t('نتایج جستجوی «%s»'),
                    'tag'      => _t('برچسب %s'),
                    'author'   => _t('نوشته‌های %s')
                ], '', ''); ?>
            </h1>
            <?php if ($this->getDescription()): ?>
                <p class="archive-banner-desc"><?php $this->getDescription(); ?></p>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<div class="layout-grid">

    <div class="content-area">

        <?php if ($this->have()): ?>

            <div class="posts-list">

            <?php
            $postIndex = 0;
            while ($this->next()):
                $postIndex++;

                // ---- کارت بزرگ تازه‌ترین نوشته (فقط صفحهٔ نخست خانه) ----
                if ($heroEnabled && $postIndex === 1):
                    $heroCover = parnian_thumbnail($this);
            ?>
                    <article class="hero-card reveal" itemscope itemtype="http://schema.org/BlogPosting">
                        <a class="hero-cover" href="<?php $this->permalink(); ?>" aria-hidden="true" tabindex="-1">
                            <?php if ($heroCover !== ''): ?>
                                <img src="<?php echo htmlspecialchars($heroCover, ENT_QUOTES, 'UTF-8'); ?>" alt="" loading="eager" itemprop="image">
                            <?php else: ?>
                                <span class="hero-cover-fallback" aria-hidden="true"></span>
                            <?php endif; ?>
                        </a>
                        <div class="hero-body">
                            <div class="hero-kicker">
                                <span class="chip chip-new"><?php _e('تازه‌ترین نوشته'); ?></span>
                                <?php if ($this->categories): ?>
                                    <a class="chip chip-category" href="<?php echo htmlspecialchars($this->categories[0]['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($this->categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                                <?php endif; ?>
                            </div>
                            <h2 class="hero-title" itemprop="name headline">
                                <a href="<?php $this->permalink(); ?>" itemprop="url"><?php $this->title(); ?></a>
                            </h2>
                            <?php $heroExcerpt = parnian_excerpt($this, 30); ?>
                            <?php if ($heroExcerpt !== ''): ?>
                                <p class="hero-excerpt"><?php echo htmlspecialchars($heroExcerpt, ENT_QUOTES, 'UTF-8'); ?></p>
                            <?php endif; ?>
                            <div class="hero-meta">
                                <span class="meta-item">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                                    <?php $this->author(); ?>
                                </span>
                                <span class="meta-item">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2.5"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                                    <time datetime="<?php echo date('c', (int) $this->created); ?>"><?php $this->date(); ?></time>
                                </span>
                                <?php if ($showReadingTime): ?>
                                    <span class="meta-item">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15.5 14"></polyline></svg>
                                        <?php echo parnian_fa_num((string) parnian_reading_time($this)); ?> <?php _e('دقیقه مطالعه'); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <a class="hero-more" href="<?php $this->permalink(); ?>">
                                <?php _e('ادامهٔ خواندن'); ?>
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="11 6 5 12 11 18"></polyline></svg>
                            </a>
                        </div>
                    </article>

                    <?php if ($this->length > 1): ?>
                        <div class="posts-heading reveal">
                            <h2 class="posts-heading-title"><?php _e('نوشته‌های دیگر'); ?></h2>
                        </div>
                    <?php endif; ?>
                <?php
                // ---- کارت‌های عادی ----
                else:
                    $cover = parnian_thumbnail($this);
                ?>
                    <article class="post-card reveal" itemscope itemtype="http://schema.org/BlogPosting">
                        <a class="card-cover" href="<?php $this->permalink(); ?>" aria-hidden="true" tabindex="-1">
                            <?php if ($cover !== ''): ?>
                                <img src="<?php echo htmlspecialchars($cover, ENT_QUOTES, 'UTF-8'); ?>" alt="" loading="lazy" itemprop="image">
                            <?php else: ?>
                                <span class="card-cover-pattern" aria-hidden="true">
                                    <svg viewBox="0 0 48 48" width="46" height="46" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round">
                                        <rect x="14" y="14" width="20" height="20"/>
                                        <rect x="14" y="14" width="20" height="20" transform="rotate(45 24 24)"/>
                                    </svg>
                                </span>
                            <?php endif; ?>
                        </a>
                        <div class="card-body">
                            <div class="card-kicker">
                                <?php if ($this->categories): ?>
                                    <a class="chip chip-category" href="<?php echo htmlspecialchars($this->categories[0]['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($this->categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                                <?php endif; ?>
                                <time class="card-date" datetime="<?php echo date('c', (int) $this->created); ?>"><?php $this->date(); ?></time>
                            </div>
                            <h2 class="card-title" itemprop="name headline">
                                <a href="<?php $this->permalink(); ?>" itemprop="url"><?php $this->title(); ?></a>
                            </h2>
                            <?php $cardExcerpt = parnian_excerpt($this, 24); ?>
                            <?php if ($cardExcerpt !== ''): ?>
                                <p class="card-excerpt"><?php echo htmlspecialchars($cardExcerpt, ENT_QUOTES, 'UTF-8'); ?></p>
                            <?php endif; ?>
                            <div class="card-meta">
                                <span class="meta-item meta-author">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                                    <?php $this->author(); ?>
                                </span>
                                <?php if ($showReadingTime): ?>
                                    <span class="meta-item">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15.5 14"></polyline></svg>
                                        <?php echo parnian_fa_num((string) parnian_reading_time($this)); ?> <?php _e('دقیقه'); ?>
                                    </span>
                                <?php endif; ?>
                                <?php if ($this->commentsNum && (int) $this->commentsNum > 0): ?>
                                    <span class="meta-item">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                                        <?php echo parnian_fa_num((string) $this->commentsNum); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </article>
                <?php endif; ?>
            <?php endwhile; ?>

            </div>

            <nav class="pagination-area reveal" aria-label="<?php _e('ناوبری صفحات'); ?>">
                <?php $this->pageNav(
                    '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 6 15 12 9 18"></polyline></svg>',
                    '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 6 9 12 15 18"></polyline></svg>',
                    2,
                    '…'
                ); ?>
            </nav>

        <?php else: ?>

            <div class="empty-state reveal">
                <div class="empty-ornament" aria-hidden="true">
                    <svg viewBox="0 0 48 48" width="64" height="64" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round">
                        <rect x="14" y="14" width="20" height="20"/>
                        <rect x="14" y="14" width="20" height="20" transform="rotate(45 24 24)"/>
                    </svg>
                </div>
                <h2 class="empty-title"><?php _e('چیزی اینجا پیدا نشد'); ?></h2>
                <p class="empty-desc"><?php _e('هنوز نوشته‌ای در این بخش منتشر نشده یا عبارت جستجو با مطلبی مطابقت نداشت.'); ?></p>
                <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="empty-search-form">
                    <input type="search" name="s" placeholder="<?php _e('مثلاً: دستور پخت قیمه'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>">
                    <button type="submit"><?php _e('جستجو'); ?></button>
                </form>
            </div>

        <?php endif; ?>

    </div>

    <?php $this->need('sidebar.php'); ?>

</div>

<?php $this->need('footer.php'); ?>
