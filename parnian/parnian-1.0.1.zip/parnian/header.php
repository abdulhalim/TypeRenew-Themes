<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title><?php $this->archiveTitle([
            'category' => _t('دستهٔ %s'),
            'search'   => _t('نتایج جستجوی «%s»'),
            'tag'      => _t('برچسب %s'),
            'author'   => _t('نوشته‌های %s')
        ], '', ' — '); ?><?php $this->options->title(); ?></title>

    <?php
        // تعیین حالت رنگی پیش از رندر (بدون پرش رنگ)
        $defaultSchema = $this->options->colorSchema ?? 'auto';
        $defaultSchemaJson = \Typecho\Common::jsonEncode(
            (string) $defaultSchema,
            JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP,
            '"auto"'
        );
        echo "<script>
        (function() {
            var stored = null;
            try { stored = localStorage.getItem('parnian-theme'); } catch (e) {}
            var def = {$defaultSchemaJson};
            var isDark = false;
            if (stored === 'dark' || stored === 'light') {
                isDark = (stored === 'dark');
            } else if (def === 'dark') {
                isDark = true;
            } else if (def === 'auto' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                isDark = true;
            }
            if (isDark) {
                document.documentElement.setAttribute('data-theme', 'dark');
            }
        })();
        </script>";
    ?>

    <link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/parnian.css?v=1.0.1'); ?>">
    <?php $this->header(); ?>
</head>
<body<?php
    $bodyClasses = [];
    if ($this->is('index')) {
        $bodyClasses[] = 'is-home';
    }
    if ($this->is('archive')) {
        $bodyClasses[] = 'is-archive';
    }
    if ($this->is('post')) {
        $bodyClasses[] = 'is-single is-post';
    }
    if ($this->is('page')) {
        $bodyClasses[] = 'is-single is-page';
    }
    if ($this->is('search')) {
        $bodyClasses[] = 'is-search';
    }
    if ($this->is('404')) {
        $bodyClasses[] = 'is-404';
    }
    $bodyClasses[] = 'cards-' . (parnian_opt('postCardStyle', 'list') === 'grid' ? 'grid' : 'list');
    echo ' class="' . implode(' ', $bodyClasses) . '"';
?>>

<a class="skip-link" href="#main"><?php _e('رفتن به محتوای اصلی'); ?></a>

<header class="site-header">
    <div class="container header-inner">

        <div class="site-branding">
            <?php if ($this->options->logoUrl): ?>
                <a class="site-logo" href="<?php $this->options->siteUrl(); ?>" rel="home">
                    <img src="<?php $this->options->logoUrl(); ?>" alt="<?php $this->options->title(); ?>" width="150" height="40">
                </a>
            <?php else: ?>
                <a class="site-title" href="<?php $this->options->siteUrl(); ?>" rel="home">
                    <span class="site-title-ornament" aria-hidden="true">
                        <svg viewBox="0 0 48 48" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linejoin="round">
                            <rect x="14" y="14" width="20" height="20"/>
                            <rect x="14" y="14" width="20" height="20" transform="rotate(45 24 24)"/>
                        </svg>
                    </span>
                    <span class="site-title-text"><?php $this->options->title(); ?></span>
                </a>
            <?php endif; ?>
        </div>

        <nav class="site-nav" aria-label="<?php _e('ناوبری اصلی'); ?>">
            <input type="checkbox" id="nav-toggle" class="nav-toggle-input" aria-label="<?php _e('باز کردن منو'); ?>">
            <label for="nav-toggle" class="nav-toggle-label" aria-hidden="true">
                <span class="nav-toggle-bar"></span>
                <span class="nav-toggle-bar"></span>
                <span class="nav-toggle-bar"></span>
                <span class="sr-only"><?php _e('منو'); ?></span>
            </label>

            <ul class="nav-menu" role="menubar">
                <li role="none">
                    <a role="menuitem" <?php if ($this->is('index')): ?> class="active" aria-current="page"<?php endif; ?> href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a>
                </li>
                <?php \Widget\Contents\Page\Rows::alloc()->to($pages); ?>
                <?php while ($pages->next()): ?>
                    <li role="none">
                        <a role="menuitem" <?php if ($this->is('page', $pages->slug)): ?> class="active" aria-current="page"<?php endif; ?> href="<?php $pages->permalink(); ?>"><?php $pages->title(); ?></a>
                    </li>
                <?php endwhile; ?>
            </ul>

            <div class="nav-actions">
                <button type="button" class="header-action-btn js-search-open" aria-label="<?php _e('جستجو'); ?>" title="<?php _e('جستجو'); ?>">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <circle cx="11" cy="11" r="7.5"></circle><line x1="21" y1="21" x2="16.5" y2="16.5"></line>
                        </svg>
                    </button>
                    <button type="button" class="header-action-btn theme-switch" aria-label="<?php _e('تغییر حالت روشن/تیره'); ?>" title="<?php _e('حالت روشن/تیره'); ?>">
                        <svg class="icon-moon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                        </svg>
                        <svg class="icon-sun" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <circle cx="12" cy="12" r="4.5"></circle>
                            <path d="M12 1.5v2.5M12 20v2.5M4.2 4.2l1.8 1.8M18 18l1.8 1.8M1.5 12h2.5M20 12h2.5M4.2 19.8l1.8-1.8M18 6l1.8-1.8"></path>
                        </svg>
                    </button>
            </div>
        </nav>

    </div>
</header>

<div class="reading-progress" aria-hidden="true"><span class="reading-progress-bar"></span></div>

<main id="main" class="site-main container">
