<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<?php $this->need('header.php'); ?>

<?php $pageCover = parnian_thumbnail($this); ?>

<div class="layout-grid layout-single">

    <div class="content-area">

        <article class="single-post single-page reveal" itemscope itemtype="http://schema.org/WebPage">

            <nav class="breadcrumb" aria-label="<?php _e('مسیر صفحه'); ?>">
                <a href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a>
                <span class="breadcrumb-sep" aria-hidden="true">/</span>
                <span class="breadcrumb-current" aria-current="page"><?php $this->title(); ?></span>
            </nav>

            <header class="post-header">
                <h1 class="post-title" itemprop="name headline"><?php $this->title(); ?></h1>
                <div class="post-meta">
                    <span class="meta-item">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2.5"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                        <time datetime="<?php echo date('c', (int) $this->created); ?>" itemprop="datePublished"><?php $this->date(); ?></time>
                    </span>
                </div>
            </header>

            <?php if ($pageCover !== ''): ?>
                <figure class="post-hero" itemprop="image">
                    <img src="<?php echo htmlspecialchars($pageCover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->title(); ?>" loading="eager">
                </figure>
            <?php endif; ?>

            <div class="post-content" itemprop="articleBody" data-plain>
                <?php $this->content(); ?>
            </div>

        </article>

        <?php $this->need('comments.php'); ?>

    </div>

    <?php $this->need('sidebar.php'); ?>

</div>

<?php $this->need('footer.php'); ?>
