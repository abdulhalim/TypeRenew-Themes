<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
</main>

<footer class="site-footer" role="contentinfo">
    <div class="footer-ornament" aria-hidden="true"></div>
    <div class="container footer-grid">

        <div class="footer-brand">
            <a class="footer-title" href="<?php $this->options->siteUrl(); ?>">
                <span class="site-title-ornament" aria-hidden="true">
                    <svg viewBox="0 0 48 48" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linejoin="round">
                        <rect x="14" y="14" width="20" height="20"/>
                        <rect x="14" y="14" width="20" height="20" transform="rotate(45 24 24)"/>
                    </svg>
                </span>
                <?php $this->options->title(); ?>
            </a>
            <?php if ($this->options->description): ?>
                <p class="footer-desc"><?php $this->options->description(); ?></p>
            <?php endif; ?>
            <div class="footer-social">
                <?php if (parnian_opt('socialTelegram')): ?>
                    <a href="<?php echo htmlspecialchars((string) parnian_opt('socialTelegram'), ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" aria-label="تلگرام" title="تلگرام">
                        <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.9 4.6l-3.1 14.7c-.2 1-.8 1.3-1.7.8l-4.7-3.5-2.3 2.2c-.25.25-.47.47-.94.47l.33-4.8L18.2 6.6c.37-.33-.08-.52-.58-.19L6.9 13.7l-4.6-1.44c-1-.31-1-1 .21-1.48L20.6 3.1c.83-.3 1.56.2 1.3 1.5z"/></svg>
                    </a>
                <?php endif; ?>
                <?php if (parnian_opt('socialGithub')): ?>
                    <a href="<?php echo htmlspecialchars((string) parnian_opt('socialGithub'), ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" aria-label="گیت‌هاب" title="گیت‌هاب">
                        <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 .5A11.5 11.5 0 0 0 .5 12a11.5 11.5 0 0 0 7.86 10.91c.58.11.79-.25.79-.56v-2.17c-3.2.7-3.87-1.36-3.87-1.36-.53-1.34-1.28-1.7-1.28-1.7-1.05-.72.08-.7.08-.7 1.16.08 1.77 1.19 1.77 1.19 1.03 1.77 2.7 1.26 3.36.96.1-.75.4-1.26.73-1.55-2.55-.29-5.23-1.28-5.23-5.68 0-1.26.45-2.28 1.19-3.09-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.17 1.18a11 11 0 0 1 5.77 0c2.2-1.49 3.16-1.18 3.16-1.18.63 1.59.24 2.76.12 3.05.74.81 1.18 1.83 1.18 3.09 0 4.41-2.68 5.38-5.24 5.67.41.35.78 1.05.78 2.11v3.13c0 .31.2.68.8.56A11.5 11.5 0 0 0 23.5 12 11.5 11.5 0 0 0 12 .5z"/></svg>
                    </a>
                <?php endif; ?>
                <?php if (parnian_opt('socialInstagram')): ?>
                    <a href="<?php echo htmlspecialchars((string) parnian_opt('socialInstagram'), ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" aria-label="اینستاگرام" title="اینستاگرام">
                        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2.5" y="2.5" width="19" height="19" rx="5"></rect><circle cx="12" cy="12" r="4.5"></circle><circle cx="17.8" cy="6.2" r="1.1" fill="currentColor" stroke="none"></circle></svg>
                    </a>
                <?php endif; ?>
                <?php if (parnian_opt('socialLinkedin')): ?>
                    <a href="<?php echo htmlspecialchars((string) parnian_opt('socialLinkedin'), ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" aria-label="لینکدین" title="لینکدین">
                        <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M4.98 3.5C4.98 4.88 3.87 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1s2.48 1.12 2.48 2.5zM.22 8.1h4.56V23H.22V8.1zM8.34 8.1h4.37v2.03h.06c.61-1.15 2.1-2.37 4.32-2.37 4.62 0 5.47 3.04 5.47 7v8.24h-4.55v-7.3c0-1.74-.03-3.98-2.43-3.98-2.43 0-2.8 1.9-2.8 3.85V23H8.34V8.1z"/></svg>
                    </a>
                <?php endif; ?>
                <a href="<?php $this->options->feedUrl(); ?>" target="_blank" rel="noopener" aria-label="فید RSS" title="فید RSS">
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6.18 15.64a2.18 2.18 0 1 1 0 4.36 2.18 2.18 0 0 1 0-4.36zM4 4.44v2.83c7.03 0 12.73 5.7 12.73 12.73h2.83c0-8.59-6.97-15.56-15.56-15.56zm0 5.66v2.83c3.9 0 7.07 3.17 7.07 7.07h2.83c0-5.47-4.43-9.9-9.9-9.9z"/></svg>
                </a>
            </div>
        </div>

        <nav class="footer-links" aria-label="<?php _e('پیوندهای فوتر'); ?>">
            <h3 class="footer-heading"><?php _e('دسترسی سریع'); ?></h3>
            <ul>
                <li><a href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a></li>
                <?php \Widget\Contents\Page\Rows::allocWithAlias('parnian-footer')->to($footerPages); ?>
                <?php while ($footerPages->next()): ?>
                    <li><a href="<?php $footerPages->permalink(); ?>"><?php $footerPages->title(); ?></a></li>
                <?php endwhile; ?>
            </ul>
        </nav>

        <div class="footer-note">
            <h3 class="footer-heading"><?php _e('دربارهٔ این سایت'); ?></h3>
            <?php if (parnian_opt('footerText')): ?>
                <p><?php echo nl2br(strip_tags((string) parnian_opt('footerText'))); ?></p>
            <?php else: ?>
                <p><?php _e('یادداشت‌ها و تجربه‌های ما؛ با عشق و دقت نوشته می‌شود.'); ?></p>
            <?php endif; ?>
        </div>

    </div>

    <div class="footer-bottom">
        <div class="container footer-bottom-inner">
            <p class="footer-copy">
                <?php echo parnian_fa_num((string) date('Y')); ?> &copy;
                <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>
            </p>
            <p class="footer-credit">
                <?php _e('پوستهٔ'); ?> <a href="https://pourdaryaei.ir" rel="noopener">پرنیان</a>
                <span class="footer-sep">·</span>
                <?php _e('قدرت‌گرفته از'); ?> <a href="https://www.typerenew.ir" rel="noopener">TypeRenew</a>
            </p>
        </div>
    </div>
</footer>

<div class="search-overlay" aria-hidden="true">
    <div class="search-overlay-backdrop"></div>
    <div class="search-overlay-panel" role="dialog" aria-modal="true" aria-label="<?php _e('جستجو در سایت'); ?>">
        <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="search-overlay-form">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <circle cx="11" cy="11" r="7.5"></circle><line x1="21" y1="21" x2="16.5" y2="16.5"></line>
            </svg>
            <input type="search" name="s" class="search-overlay-input" placeholder="<?php _e('دنبال چه چیزی می‌گردید؟'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" autocomplete="off">
            <button type="submit" class="search-overlay-submit"><?php _e('جستجو'); ?></button>
        </form>
        <button type="button" class="search-overlay-close" aria-label="<?php _e('بستن'); ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <line x1="5" y1="5" x2="19" y2="19"></line><line x1="19" y1="5" x2="5" y2="19"></line>
            </svg>
            <?php _e('بستن'); ?>
        </button>
    </div>
</div>

<button type="button" class="scroll-top" aria-label="<?php _e('بازگشت به بالای صفحه'); ?>">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <polyline points="18 15 12 9 6 15"></polyline>
    </svg>
</button>

<div class="parnian-toast" role="status" aria-live="polite"></div>

<?php $this->footer(); ?>

<script>
    window.PARNIAN = {
        siteUrl: <?php echo json_encode((string) $this->options->siteUrl); ?>,
        toc: <?php echo (parnian_opt('showToc', '1') === '1' && ($this->is('post'))) ? 'true' : 'false'; ?>,
        lightbox: <?php echo (parnian_opt('enableLightbox', '1') === '1') ? 'true' : 'false'; ?>,
        copyText: <?php echo json_encode('کپی شد!'); ?>,
        copyButton: <?php echo json_encode('کپی کد'); ?>,
        tocTitle: <?php echo json_encode('فهرست مطالب'); ?>
    };
</script>
<script src="<?php $this->options->themeUrl('assets/js/parnian.js?v=1.0.1'); ?>"></script>

</body>
</html>
