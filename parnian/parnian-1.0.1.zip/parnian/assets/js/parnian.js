(function () {
    'use strict';

    var config = window.PARNIAN || {};
    var doc = document;
    var html = doc.documentElement;

    function ready(fn) {
        if (doc.readyState !== 'loading') {
            fn();
        } else {
            doc.addEventListener('DOMContentLoaded', fn);
        }
    }

    function faDigits(text) {
        var fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return String(text).replace(/[0-9]/g, function (d) {
            return fa[+d];
        });
    }

    /* --------------------------------------------------------------
     *  حالت روشن / تیره
     * -------------------------------------------------------------- */

    function initThemeSwitch() {
        var btn = doc.querySelector('.theme-switch');
        if (!btn) {
            return;
        }

        var transitionTimeout;

        function setTheme(theme) {
            doc.body.classList.add('theme-transition');
            if (theme === 'dark') {
                html.setAttribute('data-theme', 'dark');
            } else {
                html.removeAttribute('data-theme');
            }
            try {
                localStorage.setItem('parnian-theme', theme);
            } catch (e) { /* دسترسی به localStorage ممکن نیست */ }

            clearTimeout(transitionTimeout);
            transitionTimeout = setTimeout(function () {
                doc.body.classList.remove('theme-transition');
            }, 400);
        }

        btn.addEventListener('click', function () {
            var isDark = html.getAttribute('data-theme') === 'dark';
            setTheme(isDark ? 'light' : 'dark');
        });

        // پیروی از سیستم، تنها زمانی که کاربر خودش انتخابی ثبت نکرده باشد
        if (window.matchMedia) {
            var media = window.matchMedia('(prefers-color-scheme: dark)');
            var onChange = function (e) {
                var stored = null;
                try {
                    stored = localStorage.getItem('parnian-theme');
                } catch (err) { /* noop */ }
                if (stored !== 'dark' && stored !== 'light') {
                    if (e.matches) {
                        html.setAttribute('data-theme', 'dark');
                    } else {
                        html.removeAttribute('data-theme');
                    }
                }
            };
            if (media.addEventListener) {
                media.addEventListener('change', onChange);
            } else if (media.addListener) {
                media.addListener(onChange);
            }
        }
    }

    /* --------------------------------------------------------------
     *  منوی موبایل — بستن با کلیک روی پیوندها
     * -------------------------------------------------------------- */

    function initMobileNav() {
        var toggle = doc.getElementById('nav-toggle');
        if (!toggle) {
            return;
        }

        var links = doc.querySelectorAll('.nav-menu a');
        Array.prototype.forEach.call(links, function (link) {
            link.addEventListener('click', function () {
                toggle.checked = false;
            });
        });
    }

    /* --------------------------------------------------------------
     *  پوشش جستجو
     * -------------------------------------------------------------- */

    function initSearchOverlay() {
        var overlay = doc.querySelector('.search-overlay');
        if (!overlay) {
            return;
        }

        var input = overlay.querySelector('.search-overlay-input');

        function open() {
            overlay.classList.add('is-open');
            overlay.setAttribute('aria-hidden', 'false');
            doc.body.style.overflow = 'hidden';
            if (input) {
                setTimeout(function () {
                    input.focus();
                }, 60);
            }
        }

        function close() {
            overlay.classList.remove('is-open');
            overlay.setAttribute('aria-hidden', 'true');
            doc.body.style.overflow = '';
        }

        Array.prototype.forEach.call(doc.querySelectorAll('.js-search-open'), function (btn) {
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                open();
            });
        });

        var closeBtn = overlay.querySelector('.search-overlay-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', close);
        }

        var backdrop = overlay.querySelector('.search-overlay-backdrop');
        if (backdrop) {
            backdrop.addEventListener('click', close);
        }

        doc.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' || e.keyCode === 27) {
                close();
                closeLightbox();
            }
        });
    }

    /* --------------------------------------------------------------
     *  نوار پیشرفت مطالعه + دکمهٔ بازگشت به بالا
     * -------------------------------------------------------------- */

    function initScrollFeatures() {
        var bar = doc.querySelector('.reading-progress-bar');
        var scrollBtn = doc.querySelector('.scroll-top');

        var ticking = false;

        function update() {
            var scrollTop = window.pageYOffset || html.scrollTop || 0;
            var height = html.scrollHeight - window.innerHeight;

            if (bar && height > 0) {
                var ratio = Math.min(1, Math.max(0, scrollTop / height));
                bar.style.transform = 'scaleX(' + ratio.toFixed(4) + ')';
            }

            if (scrollBtn) {
                if (scrollTop > 560) {
                    scrollBtn.classList.add('is-visible');
                } else {
                    scrollBtn.classList.remove('is-visible');
                }
            }

            ticking = false;
        }

        function onScroll() {
            if (!ticking) {
                ticking = true;
                window.requestAnimationFrame(update);
            }
        }

        window.addEventListener('scroll', onScroll, { passive: true });
        update();

        if (scrollBtn) {
            scrollBtn.addEventListener('click', function () {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }
    }

    /* --------------------------------------------------------------
     *  نمایان‌سازی نرم هنگام پیمایش
     * -------------------------------------------------------------- */

    function initReveal() {
        var items = doc.querySelectorAll('.reveal:not(.revealed)');
        if (items.length === 0) {
            return;
        }

        var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

        if (reduced || !('IntersectionObserver' in window)) {
            Array.prototype.forEach.call(items, function (item) {
                item.classList.add('revealed');
            });
            return;
        }

        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                    observer.unobserve(entry.target);
                }
            });
        }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });

        Array.prototype.forEach.call(items, function (item) {
            observer.observe(item);
        });
    }

    /* --------------------------------------------------------------
     *  فهرست مطالب خودکار
     * -------------------------------------------------------------- */

    function initToc() {
        if (!config.toc) {
            return;
        }

        var content = doc.querySelector('.post-content');
        if (!content) {
            return;
        }

        var headings = content.querySelectorAll('h2, h3');
        if (headings.length < 2) {
            return;
        }

        var toc = doc.createElement('details');
        toc.className = 'post-toc';

        var listHtml = '';
        var counter = 0;

        Array.prototype.forEach.call(headings, function (heading) {
            counter++;
            if (!heading.id) {
                heading.id = 'toc-' + counter;
            }
            var level = heading.tagName === 'H2' ? 2 : 3;
            listHtml += '<li class="toc-level-' + level + '">' +
                '<a href="#' + heading.id + '">' + heading.textContent + '</a></li>';
        });

        toc.innerHTML =
            '<summary>' +
            '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"></polyline></svg>' +
            (config.tocTitle || 'فهرست مطالب') +
            '</summary>' +
            '<div class="post-toc-body"><ol>' + listHtml + '</ol></div>';

        content.insertBefore(toc, content.firstChild);
    }

    /* --------------------------------------------------------------
     *  دکمهٔ کپی روی بلوک‌های کد + کپی لینک نوشته
     * -------------------------------------------------------------- */

    function showToast(message) {
        var toast = doc.querySelector('.parnian-toast');
        if (!toast) {
            return;
        }
        toast.textContent = message;
        toast.classList.add('is-visible');
        clearTimeout(showToast.timer);
        showToast.timer = setTimeout(function () {
            toast.classList.remove('is-visible');
        }, 2200);
    }

    function copyText(text, done) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(done, function () {
                legacyCopy(text, done);
            });
        } else {
            legacyCopy(text, done);
        }
    }

    function legacyCopy(text, done) {
        var ta = doc.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.position = 'absolute';
        ta.style.left = '-9999px';
        doc.body.appendChild(ta);
        ta.select();
        try {
            doc.execCommand('copy');
        } catch (e) { /* noop */ }
        doc.body.removeChild(ta);
        done();
    }

    function initCopyButtons() {
        var pres = doc.querySelectorAll('.post-content pre');
        Array.prototype.forEach.call(pres, function (pre) {
            var btn = doc.createElement('button');
            btn.type = 'button';
            btn.className = 'code-copy-btn';
            btn.textContent = config.copyButton || 'کپی کد';
            btn.setAttribute('aria-label', config.copyButton || 'کپی کد');
            btn.addEventListener('click', function () {
                var code = pre.querySelector('code');
                var text = code ? code.textContent : pre.textContent;
                copyText(text, function () {
                    btn.textContent = '✓ ' + faDigits('کپی شد');
                    btn.classList.add('is-copied');
                    showToast(config.copyText || 'کپی شد!');
                    setTimeout(function () {
                        btn.textContent = config.copyButton || 'کپی کد';
                        btn.classList.remove('is-copied');
                    }, 2000);
                });
            });
            pre.appendChild(btn);
        });

        var copyLink = doc.querySelector('.js-copy-link');
        if (copyLink) {
            copyLink.addEventListener('click', function () {
                copyText(window.location.href, function () {
                    showToast(config.copyText || 'کپی شد!');
                });
            });
        }
    }

    /* --------------------------------------------------------------
     *  لایت‌باکس تصاویر نوشته
     * -------------------------------------------------------------- */

    var lightbox = null;

    function closeLightbox() {
        if (lightbox) {
            lightbox.classList.remove('is-open');
            doc.body.style.overflow = '';
            setTimeout(function () {
                if (lightbox && lightbox.parentNode) {
                    lightbox.parentNode.removeChild(lightbox);
                }
                lightbox = null;
            }, 280);
        }
    }

    function openLightbox(img) {
        closeLightbox();

        lightbox = doc.createElement('div');
        lightbox.className = 'parnian-lightbox';
        lightbox.setAttribute('role', 'dialog');
        lightbox.setAttribute('aria-modal', 'true');
        lightbox.setAttribute('aria-label', 'نمایش بزرگ تصویر');

        var clone = img.cloneNode(false);
        clone.src = img.currentSrc || img.src;
        clone.removeAttribute('width');
        clone.removeAttribute('height');
        clone.removeAttribute('style');

        var closeBtn = doc.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'parnian-lightbox-close';
        closeBtn.setAttribute('aria-label', 'بستن');
        closeBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="5" x2="19" y2="19"></line><line x1="19" y1="5" x2="5" y2="19"></line></svg>';

        lightbox.appendChild(clone);
        lightbox.appendChild(closeBtn);
        doc.body.appendChild(lightbox);

        requestAnimationFrame(function () {
            lightbox.classList.add('is-open');
        });

        doc.body.style.overflow = 'hidden';
        lightbox.addEventListener('click', closeLightbox);
        closeBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            closeLightbox();
        });
    }

    function initLightbox() {
        if (!config.lightbox) {
            return;
        }

        var images = doc.querySelectorAll('.post-content img, .post-hero img');
        Array.prototype.forEach.call(images, function (img) {
            img.setAttribute('loading', 'lazy');
            img.classList.add('lightbox-ready');
            img.addEventListener('click', function () {
                openLightbox(img);
            });
        });
    }

    /* --------------------------------------------------------------
     *  بارگذاری تنبل تصاویر باقی‌مانده
     * -------------------------------------------------------------- */

    function initLazyImages() {
        var images = doc.querySelectorAll('.card-cover img, .recent-thumb img, .related-cover img');
        Array.prototype.forEach.call(images, function (img) {
            img.setAttribute('loading', 'lazy');
            img.setAttribute('decoding', 'async');
        });
    }

    /* --------------------------------------------------------------
     *  راه‌اندازی
     * -------------------------------------------------------------- */

    ready(function () {
        initThemeSwitch();
        initMobileNav();
        initSearchOverlay();
        initScrollFeatures();
        initReveal();
        initToc();
        initCopyButtons();
        initLightbox();
        initLazyImages();

        // اگر مرورگر hash داشت (مثلاً از فهرست مطالب)، بدون پرش نرم جابه‌جا شو
        if (window.location.hash) {
            var target = doc.getElementById(window.location.hash.slice(1));
            if (target) {
                setTimeout(function () {
                    target.scrollIntoView();
                }, 80);
            }
        }
    });
})();
