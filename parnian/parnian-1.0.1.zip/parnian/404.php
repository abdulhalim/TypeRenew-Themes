<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<?php $this->need('header.php'); ?>

<div class="error-page reveal">
    <div class="error-ornament" aria-hidden="true">
        <svg viewBox="0 0 48 48" width="120" height="120" fill="none" stroke="currentColor" stroke-width="1" stroke-linejoin="round">
            <rect x="14" y="14" width="20" height="20"/>
            <rect x="14" y="14" width="20" height="20" transform="rotate(45 24 24)"/>
            <rect x="19" y="19" width="10" height="10"/>
        </svg>
    </div>
    <h1 class="error-code"><?php _e('۴۰۴'); ?></h1>
    <h2 class="error-title"><?php _e('این صفحه در پرنیانِ وبلاگ پیدا نشد!'); ?></h2>
    <p class="error-desc">
        <?php _e('نشانی‌ای که دنبالش بودید یا حذف شده، یا جابه‌جا شده، یا از ابتدا هرگز وجود نداشته است. اما نگران نباشید؛'); ?>
    </p>
    <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="error-search-form">
        <input type="search" name="s" placeholder="<?php _e('جستجو کنید یا از خانه شروع کنید…'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" autofocus>
        <button type="submit"><?php _e('جستجو'); ?></button>
    </form>
    <div class="error-actions">
        <a class="btn-primary" href="<?php $this->options->siteUrl(); ?>">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 11.5L12 4l9 7.5"></path><path d="M5.5 10v9.5h13V10"></path></svg>
            <?php _e('بازگشت به خانه'); ?>
        </a>
        <a class="btn-ghost js-search-open" href="#"><?php _e('جستجوی پیشرفته'); ?></a>
    </div>
</div>

<?php $this->need('footer.php'); ?>
