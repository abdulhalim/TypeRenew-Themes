<?php

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/* --------------------------------------------------------------
 *  ابزارهای عمومی
 * -------------------------------------------------------------- */

/**
 * خواندن تنظیمات پوسته همراه با مقدار پیش‌فرض
 */
function parnian_opt(string $name, ?string $default = null): ?string
{
    $value = \Widget\Options::alloc()->{$name};
    return ($value === null || $value === '') ? $default : $value;
}

/**
 * تبدیل ارقام لاتین به فارسی
 */
function parnian_fa_num(string $text): string
{
    return strtr($text, [
        '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
        '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
    ]);
}

/**
 * نرمال‌سازی آدرس تصویر (نسبی → مطلق)
 */
function parnian_resolve_url(string $url): string
{
    $url = trim($url);
    if ($url === '') {
        return '';
    }

    // data-uri یا آدرس مطلق یا پروتکل‌نسبی
    if (preg_match('#^(data:|https?://|//)#i', $url)) {
        return $url;
    }

    $base = rtrim((string) \Widget\Options::alloc()->siteUrl, '/');
    return $base . '/' . ltrim($url, '/');
}

/**
 * پیدا کردن تصویر شاخص نوشته
 *
 * اولویت: ۱) فیلد اختصاصی (thumb / cover / img / thumbnail)
 *          ۲) نخستین تصویر داخل متن نوشته (HTML یا مارک‌داون)
 *          ۳) تصویر شاخص پیش‌فرض تنظیمات پوسته
 */
function parnian_thumbnail(\Widget\Base\Contents $content): string
{
    // ۱) فیلدهای اختصاصی
    foreach (['thumb', 'cover', 'img', 'thumbnail'] as $key) {
        $value = trim((string) ($content->fields->{$key} ?? ''));
        if ($value !== '') {
            return parnian_resolve_url($value);
        }
    }

    // ۲) نخستین تصویر متن خام (بدون اجرای موتور مارک‌داون — سریع است)
    $text = (string) $content->text;
    if ($text !== '') {
        if (preg_match('#<img[^>]*\bsrc=["\']([^"\']+)["\']#iu', $text, $matches)) {
            return parnian_resolve_url($matches[1]);
        }
        if (preg_match('#!\[[^\]]*\]\(\s*<?([^)\s>]+)[^)]*\)#iu', $text, $matches)) {
            return parnian_resolve_url($matches[1]);
        }
    }

    // ۳) تصویر پیش‌فرض پوسته
    $default = trim((string) parnian_opt('defaultCover'));
    if ($default !== '') {
        return parnian_resolve_url($default);
    }

    return '';
}

/**
 * برآورد زمان مطالعه (دقیقه) بر اساس تعداد واژه‌ها
 */
function parnian_reading_time(\Widget\Base\Contents $content): int
{
    $text = (string) $content->text;

    // حذف تصاویر، لینک‌ها و بلوک‌های کد از متن خام
    $text = preg_replace('#```.*?```#s', ' ', $text) ?? $text;
    $text = preg_replace('#`[^`]*`#', ' ', $text) ?? $text;
    $text = preg_replace('#!\[[^\]]*\]\([^)]*\)#', ' ', $text) ?? $text;
    $text = preg_replace('#\[[^\]]*\]\([^)]*\)#', '$1', $text) ?? $text;
    $text = preg_replace('#<[^>]+>#', ' ', $text) ?? $text;

    $words = preg_split('/\s+/u', trim($text), -1, PREG_SPLIT_NO_EMPTY);
    $count = is_array($words) ? count($words) : 0;

    if ($count === 0) {
        return 1;
    }

    // سرعت خواندن فارسی: حدود ۲۲۰ واژه در دقیقه
    return max(1, (int) ceil($count / 220));
}

/**
 * چکیدهٔ تمیز برای کارت‌های فهرست (با احترام به برش واژه‌ها)
 */
function parnian_excerpt(\Widget\Base\Contents $content, int $words = 24): string
{
    $text = trim((string) $content->excerpt);

    if ($text === '') {
        $text = trim((string) $content->plainExcerpt);
    }

    $text = trim(preg_replace('/\s+/u', ' ', strip_tags($text)) ?? '');
    $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');  // ✅ اضافه شود

    $parts = preg_split('/\s+/u', $text, $words + 1, PREG_SPLIT_NO_EMPTY);

    if (is_array($parts) && count($parts) > $words) {
        array_pop($parts);
        return implode(' ', $parts) . '…';
    }

    return $text;
}

/* --------------------------------------------------------------
 *  ویجت «تازه‌ترین نوشته‌ها» با دسترسی به متن (برای تصویر شاخص)
 * -------------------------------------------------------------- */

if (!class_exists('ParnianRecentPosts')) {
    class ParnianRecentPosts extends \Widget\Base\Contents
    {
        public function execute()
        {
            $this->parameter->setDefault(['pageSize' => 5]);

            $this->db->fetchAll($this->select()
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', $this->options->time)
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.password IS NULL OR table.contents.password = \'\'')
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit($this->parameter->pageSize), [$this, 'push']);
        }
    }
}

/* --------------------------------------------------------------
 *  تنظیمات پوسته (فروش در پیشخوان ← ظاهر ← تنظیمات پوسته)
 * -------------------------------------------------------------- */

function themeConfig($form)
{
    $yes = _t('نمایش');
    $no = _t('پنهان');

    /* --- هویت سایت --- */

    $logoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'logoUrl',
        null,
        null,
        _t('آدرس لوگوی سایت'),
        _t('آدرس تصویر لوگو؛ اگر خالی بماند، نام سایت با فونت وزیرمتن نمایش داده می‌شود.')
    );
    $form->addInput($logoUrl->addRule('xssCheck', _t('لطفاً یک آدرس معتبر وارد کنید')));

    $avatarUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'avatarUrl',
        null,
        null,
        _t('آواتار ویجت «درباره»'),
        _t('آدرس تصویر پروفایل برای ویجت «درباره» در ستون کناری؛ در صورت خالی‌بودن، آواتار گراواتار نویسندهٔ آخرین مطلب نمایش داده می‌شود.')
    );
    $form->addInput($avatarUrl->addRule('xssCheck', _t('لطفاً یک آدرس معتبر وارد کنید')));

    $aboutText = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'aboutText',
        null,
        null,
        _t('متن ویجت «درباره»'),
        _t('چند جمله دربارهٔ خودتان یا وبلاگ؛ در صورت خالی‌بودن، معرفی کوتاه سایت از تنظیمات عمومی استفاده می‌شود.')
    );
    $form->addInput($aboutText);

    /* --- تصویر شاخص --- */

    $defaultCover = new \Typecho\Widget\Helper\Form\Element\Text(
        'defaultCover',
        null,
        null,
        _t('تصویر شاخص پیش‌فرض'),
        _t('اگر نوشته‌ای نه فیلد تصویر شاخص داشت و نه تصویری در متنش بود، این تصویر نمایش داده می‌شود. خالی بماند تا به‌جای آن طرح تزئینی نمایش داده شود.')
    );
    $form->addInput($defaultCover->addRule('xssCheck', _t('لطفاً یک آدرس معتبر وارد کنید')));

    /* --- ظاهر و رفتار --- */

    $colorSchema = new \Typecho\Widget\Helper\Form\Element\Select(
        'colorSchema',
        [
            'auto'  => _t('خودکار (پیروی از تنظیمات سیستم کاربر)'),
            'light' => _t('روشن'),
            'dark'  => _t('تیره')
        ],
        'auto',
        _t('حالت رنگی پیش‌فرض'),
        _t('بازدیدکننده می‌تواند با دکمهٔ ماه/خورشید در سربرگ، حالت را عوض کند.')
    );
    $form->addInput($colorSchema);

    $postCardStyle = new \Typecho\Widget\Helper\Form\Element\Select(
        'postCardStyle',
        [
            'list' => _t('کارت‌های افقی (تصویر کنار متن)'),
            'grid' => _t('شبکه‌ای دوستونه (تصویر بالای متن)')
        ],
        'list',
        _t('چیدمان کارت‌های نوشته'),
        _t('در موبایل هر دو حالت به چیدمان تک‌ستونی تبدیل می‌شوند.')
    );
    $form->addInput($postCardStyle);

    $heroPost = new \Typecho\Widget\Helper\Form\Element\Radio(
        'heroPost',
        ['1' => $yes, '0' => $no],
        '1',
        _t('کارت بزرگ تازه‌ترین نوشته'),
        _t('در صفحهٔ نخست، تازه‌ترین نوشته به‌صورت یک کارت بزرگ و چشمگیر با تصویر شاخص نمایش داده شود.')
    );
    $form->addInput($heroPost);

    $showToc = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showToc',
        ['1' => $yes, '0' => $no],
        '1',
        _t('فهرست مطالب خودکار'),
        _t('اگر نوشته عنوان‌های میانی (H2/H3) داشته باشد، فهرست مطالب تاشویی در ابتدای متن ساخته می‌شود.')
    );
    $form->addInput($showToc);

    $enableLightbox = new \Typecho\Widget\Helper\Form\Element\Radio(
        'enableLightbox',
        ['1' => $yes, '0' => $no],
        '1',
        _t('بزرگ‌نمایی تصاویر'),
        _t('با کلیک روی تصاویر داخل متن نوشته، تصویر در حالت تمام‌صفحه نمایش داده شود.')
    );
    $form->addInput($enableLightbox);

    $showReadingTime = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showReadingTime',
        ['1' => $yes, '0' => $no],
        '1',
        _t('زمان مطالعه'),
        _t('نمایش برآورد زمان مطالعه در کارت‌ها و صفحهٔ نوشته.')
    );
    $form->addInput($showReadingTime);

    $showRelated = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showRelated',
        ['1' => $yes, '0' => $no],
        '1',
        _t('مطالب مرتبط'),
        _t('در انتهای هر نوشته، نوشته‌های مرتبط (بر اساس برچسب‌ها) نمایش داده شود.')
    );
    $form->addInput($showRelated);

    $showSidebarSearch = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showSidebarSearch',
        ['1' => $yes, '0' => $no],
        '1',
        _t('جعبهٔ جستجو در ستون کناری'),
        _t('علاوه بر دکمهٔ جستجوی سربرگ، یک جعبهٔ جستجو هم در ستون کناری نمایش داده شود.')
    );
    $form->addInput($showSidebarSearch);

    /* --- شبکه‌های اجتماعی --- */

    $socialTelegram = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialTelegram', null, null, _t('آدرس کانال/حساب تلگرام'), _t('مثال: https://t.me/example')
    );
    $form->addInput($socialTelegram->addRule('xssCheck', _t('لطفاً یک آدرس معتبر وارد کنید')));

    $socialGithub = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialGithub', null, null, _t('آدرس گیت‌هاب'), _t('مثال: https://github.com/example')
    );
    $form->addInput($socialGithub->addRule('xssCheck', _t('لطفاً یک آدرس معتبر وارد کنید')));

    $socialInstagram = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialInstagram', null, null, _t('آدرس اینستاگرام'), _t('مثال: https://instagram.com/example')
    );
    $form->addInput($socialInstagram->addRule('xssCheck', _t('لطفاً یک آدرس معتبر وارد کنید')));

    $socialLinkedin = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialLinkedin', null, null, _t('آدرس لینکدین'), _t('مثال: https://linkedin.com/in/example')
    );
    $form->addInput($socialLinkedin->addRule('xssCheck', _t('لطفاً یک آدرس معتبر وارد کنید')));

    /* --- فوتر --- */

    $footerText = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'footerText',
        null,
        null,
        _t('متن دلخواه فوتر'),
        _t('در صورت خالی‌بودن، فقط نام سایت و سال نمایش داده می‌شود.')
    );
    $form->addInput($footerText);
}

/* --------------------------------------------------------------
 *  فیلد اختصاصی «تصویر شاخص» در ویرایشگر نوشته
 * -------------------------------------------------------------- */

function themeFields($layout)
{
    $thumb = new \Typecho\Widget\Helper\Form\Element\Text(
        'thumb',
        null,
        null,
        _t('تصویر شاخص'),
        _t('آدرس کامل تصویر شاخص این نوشته (در کارت‌های فهرست و ابتدای صفحهٔ نوشته نمایش داده می‌شود). اگر خالی بماند، نخستین تصویر متن به‌طور خودکار استفاده می‌شود.')
    );
    $layout->addItem($thumb);
}

/* --------------------------------------------------------------
 *  ساختار دیدگاه‌ها
 * -------------------------------------------------------------- */

function threadedComments($comments, $options)
{
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
    ?>
    <li id="li-<?php $comments->theId(); ?>" class="comment-item<?php
    if ($comments->levels > 0) {
        echo ' comment-child';
        $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
    } else {
        echo ' comment-parent';
    }
    $comments->alt(' comment-odd', ' comment-even');
    echo $commentClass;
    ?>">
        <div id="<?php $comments->theId(); ?>" class="comment-inner">
            <div class="comment-avatar" aria-hidden="true">
                <?php $comments->gravatar(96, 'mp', true); ?>
            </div>
            <div class="comment-main">
                <div class="comment-meta">
                    <cite class="comment-author" itemprop="creator" itemscope itemtype="http://schema.org/Person">
                        <?php $comments->author(); ?>
                        <?php if ($comments->authorId && $comments->authorId == $comments->ownerId): ?>
                            <span class="comment-badge-owner"><?php _e('نویسنده'); ?></span>
                        <?php endif; ?>
                    </cite>
                    <span class="comment-time">
                        <a href="<?php $comments->permalink(); ?>" itemprop="url">
                            <time datetime="<?php echo date('c', (int) $comments->created); ?>" itemprop="commentTime"><?php $comments->date(); ?></time>
                        </a>
                    </span>
                    <?php if ($comments->status == 'waiting'): ?>
                        <span class="comment-badge-waiting"><?php _e('در انتظار تأیید'); ?></span>
                    <?php endif; ?>
                    <span class="comment-reply">
                        <?php $comments->reply(_t('پاسخ')); ?>
                    </span>
                </div>
                <div class="comment-content" itemprop="commentText">
                    <?php $comments->content(); ?>
                </div>
            </div>
        </div>
        <?php if ($comments->children) { ?>
            <div class="comment-children">
                <?php $comments->threadedComments($options); ?>
            </div>
        <?php } ?>
    </li>
    <?php
}
