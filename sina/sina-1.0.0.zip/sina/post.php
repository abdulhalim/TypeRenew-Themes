<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<?php $sinaShowDate = sina_opt('sinaShowDate', '1') === '1'; ?>

<main class="container">

    <!-- ---------- نوشتهٔ کامل ---------- -->
    <article class="post-single">

        <header class="post-single-header">

            <!-- ---------- عنوان ---------- -->
            <h1 class="post-single-title"><?php ob_start(); $this->title(); echo sina_fa_digits(ob_get_clean()); ?></h1>

            <!-- ---------- متادیتا: نویسنده، تاریخ، بازگشت ---------- -->
            <div class="post-single-meta">
                <div class="post-single-meta-info">
                    <span class="meta-author"><?php $this->author(); ?></span>
                    <span class="meta-dot">·</span>
                    <?php if ($sinaShowDate): ?>
                    <time datetime="<?php $this->date('c'); ?>"><?php echo getLocalizedDate($this->created); ?></time>
                    <?php endif; ?>
                    <?php if ($this->category): ?>
                    <span class="meta-dot">·</span>
                    <span class="meta-cats"><?php ob_start(); $this->category('، '); echo sina_fa_digits(ob_get_clean()); ?></span>
                    <?php endif; ?>
                </div>

                <!-- ---------- لینک بازگشت به خانه ---------- -->
                <a class="back-link" href="<?php $this->options->siteUrl(); ?>">
                    <svg aria-hidden="true" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                    <?php _e('بازگشت'); ?>
                </a>
            </div>
        </header>

        <!-- ---------- محتوای نوشته (ارقام فارسی، بجز بلوک کد) ---------- -->
        <div class="post-content">
            <?php ob_start(); $this->content(); echo sina_fa_digits(ob_get_clean()); ?>
        </div>

        <!-- ---------- برچسب‌ها ---------- -->
        <?php if ($this->tags): ?>
        <div class="post-tags">
            <?php foreach ($this->tags as $tag): ?>
            <a class="post-tag" href="<?php echo htmlspecialchars($tag['permalink']); ?>">#<?php echo htmlspecialchars($tag['name']); ?></a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </article>

    <!-- ---------- نظرات ---------- -->
    <?php $this->need('comments.php'); ?>

</main>

<?php $this->need('footer.php'); ?>
