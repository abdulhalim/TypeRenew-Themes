<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<?php

/** حداکثر عمق تورفتگی دیداری */
if (!defined('SINA_MAX_COMMENT_DEPTH')) {
    define('SINA_MAX_COMMENT_DEPTH', 2);
}

/** رندر بازگشتی یک نظر و پاسخ‌هایش */
function sinaRenderComment($c, $options, $commentsWidget = null)
{
    // ---------- داده‌های نظر (آرایه یا آبجکت) ----------
    $isRow       = is_array($c);
    $authorName  = $isRow ? $c['author'] : $c->author;
    $commentId   = $isRow ? $c['coid'] : $c->coid;
    $commentUrl  = $isRow ? $c['url'] : $c->url;
    $commentMail = $isRow ? $c['mail'] : $c->mail;
    $commentText = $isRow ? (string)$c['text'] : (string)$c->content;

    // ---------- آواتار گراواتار ----------
    $avatarUrl = sina_avatar($commentMail ?: 'guest@example.com', 64);

    // ---------- قالب‌بندی متن (مثل هستهٔ تایپچو) ----------
    if ($isRow && $commentsWidget && method_exists($commentsWidget, 'autoP')) {
        try {
            if ($options->commentsMarkdown && method_exists($commentsWidget, 'markdown')) {
                $commentText = $commentsWidget->markdown($commentText);
            } else {
                $commentText = $commentsWidget->autoP($commentText);
            }
            if (class_exists('Typecho_Common')) {
                $commentText = Typecho_Common::stripTags($commentText, '<p><br>' . $options->commentsHTMLTagAllowed);
            }
        } catch (Exception $e) {
            // متن خام بماند
        }
    }

    // ---------- سطح (برای تورفتگی پاسخ‌ها) ----------
    $level = 0;
    if ($isRow) {
        $level = isset($c['sinaLevel']) ? (int)$c['sinaLevel'] : 0;
    } else {
        $level = (int)$c->levels;
    }
    ?>

    <li id="comment-<?php echo (int)$commentId; ?>" class="comment-item<?php echo $level > 0 ? ' is-reply' : ''; ?>">
        <div class="comment-main">
            <img class="comment-avatar" src="<?php echo htmlspecialchars($avatarUrl); ?>" alt="<?php echo htmlspecialchars($authorName); ?>" loading="lazy">

            <div class="comment-body">
                <div class="comment-head">
                    <?php if (!empty($commentUrl) && preg_match('~^https?://~i', (string)$commentUrl)): ?>
                    <a class="comment-author" href="<?php echo htmlspecialchars($commentUrl); ?>" target="_blank" rel="noopener noreferrer nofollow"><?php echo sina_fa_digits(htmlspecialchars($authorName)); ?></a>
                    <?php else: ?>
                    <span class="comment-author"><?php echo sina_fa_digits(htmlspecialchars($authorName)); ?></span>
                    <?php endif; ?>

                    <span class="comment-date"><?php echo getLocalizedDate($isRow ? $c['created'] : $c->created); ?></span>

                    <a class="comment-reply-link" href="#comment-<?php echo (int)$commentId; ?>"
                       onclick="return TypechoComment.reply('comment-<?php echo (int)$commentId; ?>', <?php echo (int)$commentId; ?>);"><?php _e('پاسخ'); ?></a>
                </div>

                <div class="comment-content"><?php echo sina_fa_digits($commentText); ?></div>
            </div>
        </div>

    <?php
    // ---------- فرزندان (بازگشتی؛ زیر نظر والد، عمق حداکثر SINA_MAX_COMMENT_DEPTH) ----------
    try {
        $db = Typecho_Db::get();
        $children = $db->fetchAll(
            $db->select()->from('table.comments')
                ->where('cid = ?', $isRow ? $c['cid'] : $c->cid)
                ->where('parent = ?', $commentId)
                ->where('status = ?', 'approved')
                ->order('coid', Typecho_Db::SORT_ASC)
        );
        if (!empty($children)) {
            $childLevel = min($level + 1, SINA_MAX_COMMENT_DEPTH);
            echo '<ol class="comment-children">';
            foreach ($children as $childRow) {
                $childRow['sinaLevel'] = $childLevel;
                sinaRenderComment($childRow, $options, $commentsWidget);
            }
            echo '</ol>';
        }
    } catch (Exception $e) {
        // نادیده گرفته شود
    }
    ?>
    </li>
    <?php
}
?>

<div id="comments" class="comments-area">

    <?php
    // شناسهٔ فرم پاسخ برای theme.js
    $this->comments()->to($comments);
    ?>
    <script>window.respondId = '<?php $this->respondId(); ?>';</script>

    <?php if ($comments->have()): ?>
    <h3 class="comments-title"><?php ob_start(); $this->commentsNum(_t('بدون نظر'), _t('۱ نظر'), _t('%d نظر')); echo sina_fa_digits(ob_get_clean()); ?></h3>

    <ol class="comment-list">
        <?php while ($comments->next()): ?>
            <?php if ($comments->levels > 0) continue; // فقط والد‌ها؛ فرزندان بازگشتی رندر می‌شوند ?>
            <?php sinaRenderComment($comments, $this->options, $comments); ?>
        <?php endwhile; ?>
    </ol>

    <?php
    // ---------- صفحه‌بندی نظرات (ارقام فارسی) ----------
    ob_start();
    $comments->pageNav('«', '»', 3, '…', ['wrapTag' => 'div', 'wrapClass' => 'pagination', 'itemTag' => '', 'textTag' => 'span', 'currentClass' => 'current']);
    echo sina_fa_digits(ob_get_clean());
    ?>
    <?php else: ?>
    <h3 class="comments-title"><?php _e('هنوز نظری ثبت نشده است'); ?></h3>
    <?php endif; ?>

    <?php if ($this->allow('comment')): ?>

    <div id="<?php $this->respondId(); ?>" class="comment-respond">

        <?php $comments->cancelReply(); ?>

        <h3 id="response" class="comment-form-title"><?php _e('ارسال نظر'); ?></h3>

        <form method="post" action="<?php $this->commentUrl(); ?>" id="comment-form" class="comment-form">

            <?php if ($this->user->hasLogin()): ?>

            <p class="comment-logged-in">
                <?php _e('با نام'); ?>
                <a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>
                <?php _e('وارد شده‌اید.'); ?>
                <a href="<?php $this->options->logoutUrl(); ?>"><?php _e('(خروج)'); ?></a>
            </p>
            <input type="hidden" name="author" value="<?php $this->user->screenName(); ?>">
            <input type="hidden" name="mail" value="<?php $this->user->mail(); ?>">
            <input type="hidden" name="url" value="<?php $this->user->url(); ?>">

            <?php else: ?>

            <div class="comment-form-row">
                <p>
                    <label for="author"><?php _e('نام'); ?> <span class="req">*</span></label>
                    <input type="text" name="author" id="author" value="<?php $this->remember('author'); ?>" required>
                </p>
                <p>
                    <label for="mail"><?php _e('ایمیل'); ?><?php if ($this->options->commentsRequireMail): ?> <span class="req">*</span><?php endif; ?></label>
                    <input type="email" name="mail" id="mail" value="<?php $this->remember('mail'); ?>"<?php if ($this->options->commentsRequireMail): ?> required<?php endif; ?>>
                </p>
            </div>
            <p>
                <label for="url"><?php _e('وبسایت (اختیاری)'); ?></label>
                <input type="url" name="url" id="url" dir="ltr" placeholder="https://" value="<?php $this->remember('url'); ?>">
            </p>

            <?php endif; ?>

            <p>
                <label for="textarea"><?php _e('متن نظر'); ?> <span class="req">*</span></label>
                <textarea name="text" id="textarea" rows="5" required><?php $this->remember('text'); ?></textarea>
            </p>

            <p class="comment-form-submit">
                <button type="submit" class="comment-submit"><?php _e('ارسال نظر'); ?></button>
            </p>
        </form>
    </div>

    <?php else: ?>
    <p class="comments-closed"><?php _e('نظرات این نوشته بسته شده است.'); ?></p>
    <?php endif; ?>

</div>
