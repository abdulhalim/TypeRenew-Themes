<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<main class="container">

    <!-- ---------- برگهٔ ایستا ---------- -->
    <article class="post-single page-single">

        <header class="post-single-header">

            <h1 class="post-single-title"><?php ob_start(); $this->title(); echo sina_fa_digits(ob_get_clean()); ?></h1>

            <div class="post-single-meta">
                <div class="post-single-meta-info">
                    <?php if ($sinaShowDate = sina_opt('sinaShowDate', '1') === '1'): ?>
                    <time datetime="<?php $this->date('c'); ?>"><?php echo getLocalizedDate($this->created); ?></time>
                    <?php endif; ?>
                </div>

                <a class="back-link" href="<?php $this->options->siteUrl(); ?>">
                    <svg aria-hidden="true" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                    <?php _e('بازگشت'); ?>
                </a>
            </div>
        </header>

        <!-- ---------- محتوای برگه (ارقام فارسی، بجز بلوک کد) ---------- -->
        <div class="post-content">
            <?php ob_start(); $this->content(); echo sina_fa_digits(ob_get_clean()); ?>
        </div>
    </article>

    <!-- ---------- نظرات (در صورت فعال بودن برای برگه) ---------- -->
    <?php if ($this->allow('comment')): ?>
    <?php $this->need('comments.php'); ?>
    <?php endif; ?>

</main>

<?php $this->need('footer.php'); ?>
