(function () {
    'use strict';

    /* ============================================================
     *  حالت روشن/تاریک
     * ============================================================ */
    var KEY = 'sina-theme';

    function isDark() {
        return document.documentElement.classList.contains('dark');
    }

    function saveTheme(dark) {
        try {
            localStorage.setItem(KEY, dark ? 'dark' : 'light');
        } catch (e) {
            /* حافظهٔ محلی در دسترس نیست — بی‌خیال */
        }
    }

    var toggleBtn = document.getElementById('themeToggle');
    if (toggleBtn) {
        toggleBtn.addEventListener('click', function () {
            var dark = !isDark();
            document.documentElement.classList.toggle('dark', dark);
            saveTheme(dark);
        });
    }

    /* ============================================================
     *  پاسخ به نظرات (سازگار با هستهٔ تایپچو)
     * ============================================================ */
    if (typeof TypechoComment === 'undefined') {
        window.TypechoComment = {};
    }

    // شناسهٔ فرم پاسخ — تایپچو در پوسته با respondId() تعریفش می‌کند
    var respondId = window.respondId || 'respond';

    TypechoComment.reply = function (cid, coid) {
        var comment = document.getElementById(cid);
        var respond = document.getElementById(respondId);
        if (!comment || !respond) {
            return false;
        }

        // ورودی مخفی شناسهٔ والد
        var parent = document.getElementById('comment-parent');
        if (!parent) {
            parent = document.createElement('input');
            parent.type = 'hidden';
            parent.name = 'parent';
            parent.id = 'comment-parent';
            var form = respond.querySelector('form');
            if (!form) {
                return false;
            }
            form.appendChild(parent);
        }
        parent.value = coid;

        // عنوان فرم → «در حال پاسخ به …»
        var author = 'کاربر';
        var authorEl = comment.querySelector('.comment-author');
        if (authorEl) {
            author = authorEl.textContent || author;
        }
        var title = document.getElementById('response');
        if (title) {
            title.innerHTML = 'در حال پاسخ به <strong>' + author + '</strong>' +
                ' <a href="#comment-' + coid + '" onclick="return TypechoComment.cancelReply();">(لغو)</a>';
        }

        // اسکرول و فوکوس
        if (respond.scrollIntoView) {
            respond.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        var textarea = document.getElementById('textarea');
        if (textarea) {
            textarea.focus();
        }

        return false;
    };

    TypechoComment.cancelReply = function () {
        var parent = document.getElementById('comment-parent');
        if (parent) {
            parent.value = '';
        }
        var title = document.getElementById('response');
        if (title) {
            title.textContent = 'ارسال نظر';
        }
        return false;
    };
})();
