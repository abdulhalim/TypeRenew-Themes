<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<main class="container">

    <!-- ---------- صفحهٔ ۴۰۴ مینیمال ---------- -->
    <div class="empty-state not-found">
        <p class="not-found-code">۴۰۴</p>
        <h2><?php _e('صفحه پیدا نشد'); ?></h2>
        <p><?php _e('آدرسی که دنبالش بودید وجود ندارد یا جابه‌جا شده است.'); ?></p>
        <a class="post-item-more" href="<?php $this->options->siteUrl(); ?>">
            <?php _e('بازگشت به خانه'); ?>
            <svg aria-hidden="true" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
        </a>
    </div>

</main>

<?php $this->need('footer.php'); ?>
