<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * سینا — پوستهٔ مینیمال بلاگی ساده
 *
 * @package سینا
 * @version 1.0.0
 * @author پوردریایی
 * @link http://pourdaryaei.ir
 */
?>

<?php $this->need('header.php'); ?>

<main class="container">

<?php
// ---------- آیا صفحهٔ خانه است یا آرشیو (دسته/برچسب/جستجو/تاریخ/نویسنده)؟ ----------
$sinaHome = false;
try {
    $sinaHome = $this->is('index');
} catch (Exception $e) {
    $sinaHome = false;
}

$sinaShowExcerpt = sina_opt('sinaShowExcerpt', '1') === '1';
$sinaShowDate    = sina_opt('sinaShowDate', '1') === '1';
?>

<?php if (!$sinaHome): ?>
<!-- ---------- هدر آرشیو ---------- -->
<header class="archive-header">
    <h2 class="archive-title">
        <?php ob_start(); $this->archiveTitle([
            'category' => _t('دسته‌بندی: %s'),
            'search'   => _t('جستجو: %s'),
            'tag'      => _t('برچسب: %s'),
            'author'   => _t('نوشته‌های %s'),
            'date'     => _t('آرشیو: %s'),
        ], '', ''); echo sina_fa_digits(ob_get_clean()); ?>
    </h2>
    <?php if ($this->getDescription()): ?>
    <p class="archive-desc"><?php ob_start(); $this->getDescription(); echo sina_fa_digits(ob_get_clean()); ?></p>
    <?php endif; ?>
</header>
<?php endif; ?>

<?php if ($this->have()): ?>

<!-- ---------- فهرست نوشته‌ها ---------- -->
<div class="post-list">

    <?php while ($this->next()): ?>

    <article class="post-item">

        <!-- ---------- عنوان ---------- -->
        <h3 class="post-item-title">
            <a href="<?php $this->permalink(); ?>"><?php ob_start(); $this->title(); echo sina_fa_digits(ob_get_clean()); ?></a>
        </h3>

        <!-- ---------- خلاصه ---------- -->
        <?php if ($sinaShowExcerpt): ?>
        <?php ob_start(); $this->excerpt(150, '…'); ?>
        <p class="post-item-excerpt"><?php echo sina_fa_digits(ob_get_clean()); ?></p>
        <?php endif; ?>

        <!-- ---------- ادامه مطلب ---------- -->
        <a class="post-item-more" href="<?php $this->permalink(); ?>">
            <?php _e('ادامه مطلب'); ?>
            <svg aria-hidden="true" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
        </a>

        <!-- ---------- تاریخ (پایین آیتم) ---------- -->
        <?php if ($sinaShowDate): ?>
        <time class="post-item-date" datetime="<?php $this->date('c'); ?>"><?php echo getLocalizedDate($this->created); ?></time>
        <?php endif; ?>
    </article>

    <?php endwhile; ?>

</div>

<!-- ---------- صفحه‌بندی (ارقام فارسی) ---------- -->
<?php ob_start(); $this->pageNav(_t('قبلی'), _t('بعدی'), 3, '…', ['wrapTag' => 'nav', 'wrapClass' => 'pagination', 'itemTag' => '', 'textTag' => 'span', 'currentClass' => 'current']); echo sina_fa_digits(ob_get_clean()); ?>

<?php else: ?>

<!-- ---------- حالت خالی / بدون نتیجه ---------- -->
<div class="empty-state">
    <h2><?php _e('چیزی پیدا نشد'); ?></h2>
    <p><?php _e('موردی مطابق درخواست شما یافت نشد.'); ?></p>
    <a class="post-item-more" href="<?php $this->options->siteUrl(); ?>">
        <?php _e('بازگشت به خانه'); ?>
        <svg aria-hidden="true" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
    </a>
</div>

<?php endif; ?>

</main>

<?php $this->need('footer.php'); ?>
