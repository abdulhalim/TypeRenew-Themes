<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/* ================================================================
 *  ۱) ابزارهای عمومی
 * ================================================================ */

/** خواندن تنظیم پوسته با مقدار پیش‌فرض */
function sina_opt($name, $default = null)
{
    try {
        $value = Typecho_Widget::widget('Widget_Options')->{$name};
    } catch (Exception $e) {
        $value = null;
    }
    return ($value === null || $value === '') ? $default : $value;
}

/** تبدیل ارقام لاتین به فارسی */
if (!function_exists('toPersianNumbers')) {
    function toPersianNumbers($num)
    {
        $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return str_replace(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], $persian, (string)$num);
    }
}

/**
 * فارسی‌سازی ارقام در یک قطعهٔ HTML
 *
 * - ارقام لاتین (0-9) و عربی (٠-٩) هر بخش «متن» به فارسی (۰-۹) تبدیل می‌شوند.
 * - داخل بلوک کد (pre، code، kbd، samp) و همچنین script/style/textarea دست نمی‌زند.
 * - ارقام داخل تگ‌ها (ویژگی‌ها مثل href، id، class) و «موجودیت‌های عددی» (&#123;) دست‌نخورده می‌مانند.
 */
function sina_fa_digits($html)
{
    $html = (string)$html;
    if ($html === '') {
        return $html;
    }

    // مسیر سریع: اگر نه رقم لاتین دارد نه رقم عربی، تبدیلی لازم نیست
    if (!preg_match('~[0-9]~', $html) && !preg_match('~[\x{0660}-\x{0669}]~u', $html)) {
        return $html;
    }

    static $map = null;
    if ($map === null) {
        $map = [
            '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
            '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
            '٠' => '۰', '١' => '۱', '٢' => '۲', '٣' => '۳', '٤' => '۴',
            '٥' => '۵', '٦' => '۶', '٧' => '۷', '٨' => '۸', '٩' => '۹',
        ];
    }

    $skipTags = ['pre', 'code', 'kbd', 'samp', 'script', 'style', 'textarea'];
    $depth = 0;

    return preg_replace_callback(
        '~<!--.*?-->|<(/?)([a-zA-Z][a-zA-Z0-9]*)(?:\s[^>]*)?/?>|[^<]+~s',
        function ($m) use (&$depth, $skipTags, $map) {
            $chunk = $m[0];

            // تگ یا کامنت HTML → دست‌نخورده (فقط عمق بلوک‌های کد ردیابی می‌شود)
            if ($chunk[0] === '<') {
                if ($chunk[1] === '!') {
                    return $chunk; // کامنت HTML
                }
                $tag = strtolower(isset($m[2]) ? $m[2] : '');
                if (in_array($tag, $skipTags, true)) {
                    if ($m[1] === '/') {          // تگ پایانی
                        if ($depth > 0) {
                            $depth--;
                        }
                    } elseif (!preg_match('~/\s*>$~', $chunk)) { // تگ آغازین (خود-بسته نیست)
                        $depth++;
                    }
                }
                return $chunk;
            }

            // متن؛ اگر داخل بلوک کد است دست نمی‌زنیم
            if ($depth > 0) {
                return $chunk;
            }

            // موجودیت‌های عددی (&#48;) محافظت می‌شوند، بقیهٔ ارقام تبدیل
            return preg_replace_callback(
                '~&#\d+;|[0-9]|[\x{0660}-\x{0669}]~u',
                function ($d) use ($map) {
                    return $map[$d[0]] ?? $d[0];
                },
                $chunk
            );
        },
        $html
    );
}

/* ================================================================
 *  ۲) تاریخ شمسی (داخلی، بدون نیاز به افزونه)
 * ================================================================ */

/** تبدیل میلادی به جلالی */
function sina_to_jalali($gy, $gm, $gd)
{
    $gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

    $jy = ($gy <= 1600) ? 0 : 979;
    $gy -= ($gy <= 1600) ? 621 : 1600;

    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = (365 * $gy)
        + intdiv($gy2 + 3, 4)
        - intdiv($gy2 + 99, 100)
        + intdiv($gy2 + 399, 400)
        - 80
        + $gd
        + $gdm[$gm - 1];

    $jy += 33 * intdiv($days, 12053);
    $days %= 12053;
    $jy += 4 * intdiv($days, 1461);
    $days %= 1461;

    if ($days > 365) {
        $jy += intdiv($days - 1, 365);
        $days = ($days - 1) % 365;
    }

    if ($days < 186) {
        $jm = 1 + intdiv($days, 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + intdiv($days - 186, 30);
        $jd = 1 + (($days - 186) % 30);
    }

    return [$jy, $jm, $jd];
}

/** تاریخ شمسی — اگر افزونهٔ jalali_date موجود باشد از همان، وگرنه تبدیل داخلی */
if (!function_exists('getLocalizedDate')) {
    function getLocalizedDate($timestamp = NULL, $format = 'Y/m/d')
    {
        if ($timestamp === NULL) {
            $timestamp = time();
        } elseif (is_string($timestamp) && !is_numeric($timestamp)) {
            $timestamp = strtotime($timestamp);
        }

        if (function_exists('jalali_date')) {
            return toPersianNumbers(jalali_date($format, $timestamp));
        }

        [$jy, $jm, $jd] = sina_to_jalali((int)date('Y', $timestamp), (int)date('n', $timestamp), (int)date('j', $timestamp));

        $out = str_replace(
            ['Y', 'm', 'd'],
            [sprintf('%04d', $jy), sprintf('%02d', $jm), sprintf('%02d', $jd)],
            $format
        );
        return toPersianNumbers($out);
    }
}

/** سال جاری شمسی برای پاورقی */
function sina_jalali_year()
{
    if (function_exists('jalali_date')) {
        return toPersianNumbers(jalali_date('Y', time()));
    }
    [$jy] = sina_to_jalali((int)date('Y'), (int)date('n'), (int)date('j'));
    return toPersianNumbers((string)$jy);
}

/** آواتار گراواتار (مینیمال — بدون نیاز به فایل محلی) */
function sina_avatar($email, $size = 64)
{
    $hash = md5(strtolower(trim((string)$email)));
    return 'https://www.gravatar.com/avatar/' . $hash . '?s=' . (int)$size . '&d=mp&r=g';
}

/* ================================================================
 *  ۳) تنظیمات پوسته (عمداً مینیمال)
 * ================================================================ */

function themeConfig($form)
{
    // ---------- نام وبلاگ (عنوان خانهٔ اصلی) ----------
    $sinaTitle = new Typecho_Widget_Helper_Form_Element_Text(
        'sinaTitle',
        NULL,
        'وبلاگ',
        _t('نام وبلاگ'),
        _t('نام خانهٔ اصلی پوسته که در هدر و پاورقی نمایش داده می‌شود (پیش‌فرض: «وبلاگ»).')
    );
    $form->addInput($sinaTitle);

    // ---------- لینک وبسایت اصلی (فقط صفحهٔ خانه) ----------
    $mainSiteUrl = new Typecho_Widget_Helper_Form_Element_Text(
        'sinaMainSiteUrl',
        NULL,
        NULL,
        _t('آدرس وبسایت اصلی'),
        _t('این لینک فقط در صفحهٔ خانه (هدر) نمایش داده می‌شود — مانند لینک Homepage در وبلاگ‌های سازمانی. اگر خالی باشد هیچ لینکی نمایش داده نمی‌شود.')
    );
    $form->addInput($mainSiteUrl);

    $mainSiteText = new Typecho_Widget_Helper_Form_Element_Text(
        'sinaMainSiteText',
        NULL,
        'وبسایت اصلی',
        _t('متن لینک وبسایت اصلی'),
        _t('متن نمایشی لینک وبسایت اصلی در صفحهٔ خانه (پیش‌فرض: «وبسایت اصلی»).')
    );
    $form->addInput($mainSiteText);

    // ---------- حالت نمایش پیش‌فرض ----------
    $defaultMode = new Typecho_Widget_Helper_Form_Element_Radio(
        'sinaDefaultMode',
        [
            'auto'  => _t('هماهنگ با سیستم'),
            'light' => _t('روشن'),
            'dark'  => _t('تاریک'),
        ],
        'auto',
        _t('حالت نمایش پیش‌فرض'),
        _t('حالت رنگی صفحه هنگام نخستین بازدید (کاربر می‌تواند با دکمهٔ ماه/خورشید تغییر دهد و انتخابش ذخیره می‌شود).')
    );
    $form->addInput($defaultMode);

    // ---------- نمایش خلاصه در فهرست ----------
    $showExcerpt = new Typecho_Widget_Helper_Form_Element_Radio(
        'sinaShowExcerpt',
        [
            '1' => _t('نمایش'),
            '0' => _t('فقط عنوان'),
        ],
        '1',
        _t('خلاصهٔ نوشته در فهرست خانه'),
        _t('در فهرست خانه، خلاصهٔ هر نوشته نمایش داده شود یا فقط عنوان‌ها دیده شوند.')
    );
    $form->addInput($showExcerpt);

    // ---------- نمایش تاریخ ----------
    $showDate = new Typecho_Widget_Helper_Form_Element_Radio(
        'sinaShowDate',
        [
            '1' => _t('نمایش'),
            '0' => _t('عدم نمایش'),
        ],
        '1',
        _t('تاریخ نوشته‌ها'),
        _t('نمایش تاریخ (شمسی) در فهرست خانه و صفحهٔ نوشته.')
    );
    $form->addInput($showDate);

    // ---------- متن فوتر ----------
    $footerText = new Typecho_Widget_Helper_Form_Element_Textarea(
        'sinaFooterText',
        NULL,
        NULL,
        _t('متن اختیاری فوتر'),
        _t('اگر خالی باشد فقط نام وبلاگ و سال نمایش داده می‌شود.')
    );
    $form->addInput($footerText);

    /* ============================================================
     *  شبکه‌های اجتماعی پاورقی (هر کدام خالی باشد نمایش داده نمی‌شود)
     * ============================================================ */
    $socials = [
        'sinaSocialTelegram'  => ['تلگرام',   'https://t.me/username'],
        'sinaSocialInstagram' => ['اینستاگرام', 'https://instagram.com/username'],
        'sinaSocialX'         => ['ایکس (توییتر)', 'https://x.com/username'],
        'sinaSocialGithub'    => ['گیت‌هاب',   'https://github.com/username'],
        'sinaSocialLinkedin'  => ['لینکدین',   'https://linkedin.com/in/username'],
        'sinaSocialYoutube'   => ['یوتیوب',    'https://youtube.com/@channel'],
    ];

    foreach ($socials as $key => $info) {
        $el = new Typecho_Widget_Helper_Form_Element_Text(
            $key,
            NULL,
            NULL,
            _t('آدرس ' . $info[0]),
            _t('نمونه: ' . $info[1] . ' — اگر خالی باشد این آیکون در پاورقی نمایش داده نمی‌شود.')
        );
        $form->addInput($el);
    }

    $socialMail = new Typecho_Widget_Helper_Form_Element_Text(
        'sinaSocialEmail',
        NULL,
        NULL,
        _t('ایمیل (آیکون پاورقی)'),
        _t('نشانی ایمیل برای آیکون ایمیل در پاورقی (mailto). خالی = بدون نمایش.')
    );
    $form->addInput($socialMail);
}
