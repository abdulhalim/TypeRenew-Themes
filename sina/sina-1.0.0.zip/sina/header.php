<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php $this->archiveTitle([
        'post'     => '%s',
        'page'     => '%s',
        'category' => _t('دسته‌بندی: %s'),
        'search'   => _t('جستجو: %s'),
        'tag'      => _t('برچسب: %s'),
        'author'   => _t('نوشته‌های %s'),
        'date'     => _t('آرشیو: %s'),
        'archive'  => '%s',
    ], '', ' - '); ?><?php $this->options->title(); ?></title>

    <?php $this->header(); ?>

    <?php if ($this->options->favicon): ?>
    <link rel="icon" href="<?php $this->options->favicon(); ?>">
    <?php endif; ?>

    <!-- ---------- فونت وزیرمتن (آفلاین) ---------- -->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/fonts.css'); ?>">

    <!-- ---------- استایل اصلی (نسخه‌دار برای جلوگیری از کش) ---------- -->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/style.css'); ?>?v=1.1">

    <!-- ---------- تعیین حالت روشن/تاریک پیش از رندر (جلوگیری از فلش) ----------
         اولویت: انتخاب ذخیره‌شدهٔ کاربر → تنظیم پوسته → هماهنگ با سیستم -->
    <script>
    (function () {
        try {
            var stored = localStorage.getItem('sina-theme');
            var mode = '<?php echo sina_opt('sinaDefaultMode', 'auto'); ?>';
            var dark;
            if (stored === 'dark' || stored === 'light') {
                dark = (stored === 'dark');
            } else if (mode === 'dark') {
                dark = true;
            } else if (mode === 'light') {
                dark = false;
            } else {
                dark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
            }
            document.documentElement.classList.toggle('dark', dark);
        } catch (e) {}
    })();
    </script>
</head>
<body>

<?php
// ---------- داده‌های هدر ----------
$sinaTitle      = trim((string)sina_opt('sinaTitle', 'وبلاگ'));
if ($sinaTitle === '') {
    $sinaTitle = 'وبلاگ';
}
$sinaMainUrl    = trim((string)sina_opt('sinaMainSiteUrl', ''));
$sinaMainText   = trim((string)sina_opt('sinaMainSiteText', 'وبسایت اصلی'));
if ($sinaMainText === '') {
    $sinaMainText = 'وبسایت اصلی';
}
$sinaIsHome     = false;
try {
    // فقط صفحهٔ خانه (نه دسته/جستجو/برچسب/آرشیو)
    $sinaIsHome = $this->is('index');
} catch (Exception $e) {
    $sinaIsHome = false;
}
$sinaMainTarget = preg_match('~^https?://~i', $sinaMainUrl) ? ' target="_blank" rel="noopener noreferrer"' : '';
$sinaShowMain   = ($sinaIsHome && $sinaMainUrl !== '');

// ---------- مقدار جستجوی جاری (پیش‌پر کردن فیلد در صفحهٔ نتیجه) ----------
$sinaSearchValue = '';
try {
    if ($this->is('search')) {
        $sinaSearchValue = (string)$this->keywords;
    }
} catch (Exception $e) {
    $sinaSearchValue = '';
}
?>

<!-- ---------- هدر مینیمال ---------- -->
<header class="site-header">
    <div class="container header-inner">

        <!-- ---------- نام خانهٔ اصلی: «وبلاگ» ---------- -->
        <?php if ($sinaIsHome): ?>
        <h1 class="site-title"><a href="<?php $this->options->siteUrl(); ?>"><?php echo htmlspecialchars($sinaTitle); ?></a></h1>
        <?php else: ?>
        <p class="site-title"><a href="<?php $this->options->siteUrl(); ?>"><?php echo htmlspecialchars($sinaTitle); ?></a></p>
        <?php endif; ?>

        <!-- ---------- جستجو ---------- -->
        <form class="header-search" method="post" action="<?php $this->options->siteUrl(); ?>" role="search">
            <button type="submit" class="header-search-btn" aria-label="جستجو" title="جستجو">
                <svg aria-hidden="true" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.35-4.35"/></svg>
            </button>
            <input type="search" name="s" class="header-search-input" placeholder="جستجو…"
                   value="<?php echo htmlspecialchars($sinaSearchValue); ?>" aria-label="جستجو در وبلاگ">
        </form>

        <!-- ---------- ناوبری: لینک وبسایت اصلی (فقط صفحهٔ خانه) + دکمهٔ حالت ---------- -->
        <nav class="site-nav">
            <?php if ($sinaShowMain): ?>
            <a class="site-nav-link" href="<?php echo htmlspecialchars($sinaMainUrl); ?>"<?php echo $sinaMainTarget; ?>>
                <?php echo htmlspecialchars($sinaMainText); ?> <svg aria-hidden="true" viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17L17 7M7 7h10v10"/></svg>
            </a>
            <?php endif; ?>

            <button type="button" class="theme-toggle" id="themeToggle" aria-label="تغییر حالت روشن/تاریک" title="تغییر حالت روشن/تاریک">
                <!-- خورشید (در حالت تاریک دیده می‌شود) -->
                <svg class="icon-sun" aria-hidden="true" viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.41 1.41m11.32 11.32l1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>
                <!-- ماه (در حالت روشن دیده می‌شود) -->
                <svg class="icon-moon" aria-hidden="true" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg>
            </button>
        </nav>
    </div>
</header>
