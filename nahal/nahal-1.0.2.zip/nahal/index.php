<?php
/**
 * نهال — پوسته تخصصی تغذیه، سلامت و تندرستی
 *
 * @package نهال
 * @author پوردریایی
 * @link https://pourdaryaei.ir
 * @version 1.0.1
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');


if (nahal_is_front()):

    /* ================================================================
     *  صفحهٔ اصلی — لندینگ تغذیه و سلامت
     * ================================================================ */

    // ---------- داده‌های هیرو ----------
    $nahalHeroBadge    = nahal_opt('nahalHeroBadge', 'کلینیک تخصصی تغذیه و سلامت');
    $nahalHeroTitle    = nahal_opt('nahalHeroTitle', 'مسیر سلامتی‌ات را با علم تغذیه سبز کن');
    $nahalHeroSubtitle = trim((string)nahal_opt_raw('nahalHeroSubtitle'));
    $nahalHeroSubtitle = ($nahalHeroSubtitle === '') ? "در نهال، متخصصان تغذیه با برنامه‌های کاملاً شخصی‌سازی‌شده، ساده، علمی و اثبات‌شده، شما را به وزن ایده‌آل و سلامت پایدار می‌رسانند.\nهمین حالا BMI خود را محاسبه کنید و برنامهٔ مناسب خود را دریافت کنید." : $nahalHeroSubtitle;
    $nahalHeroImageRaw = trim((string)nahal_opt_raw('nahalHeroImage'));
    $nahalHeroImage    = ($nahalHeroImageRaw !== '') ? nahal_resolve_url($nahalHeroImageRaw) : nahal_asset('img/hero.jpg');
    $nahalHeroBtn1Text = nahal_opt('nahalHeroBtn1Text', 'دریافت برنامهٔ غذایی');
    $nahalHeroBtn1Url  = nahal_opt('nahalHeroBtn1Url', '#booking');
    $nahalHeroBtn2Text = nahal_opt_raw('nahalHeroBtn2Text');
    $nahalHeroBtn2Url  = nahal_opt_raw('nahalHeroBtn2Url');
    $nahalHeroStats    = nahal_parse_stats(nahal_opt_raw('nahalHeroStats'));
    $nahalHeroStats    = array_slice($nahalHeroStats, 0, 4);

    // ---------- داده‌های ماشین‌حساب BMI ----------
    $nahalBmiShow       = nahal_opt('nahalBmiShow', '1') === '1';
    $nahalBmiTitle      = nahal_opt('nahalBmiTitle', 'اندازه‌هایت را وارد کن!');
    $nahalBmiSubtitle   = nahal_opt('nahalBmiSubtitle', 'مشخصاتت را وارد کن تا BMI، وزن ایده‌آل و کالری روزانه‌ات محاسبه شود');
    $nahalBmiWaist      = nahal_opt('nahalBmiWaist', '1') === '1';

    // ---------- داده‌های بخش‌ها ----------
    $nahalServicesTitle = trim((string)nahal_opt_raw('nahalServicesTitle'));
    $nahalServices      = nahal_parse_services(nahal_opt_raw('nahalServices'));
    if (empty($nahalServices) && $nahalServicesTitle !== '') {
        $nahalServices = nahal_parse_services("trending-down | رژیم لاغری و کاهش وزن | برنامهٔ شخصی‌سازی‌شدهٔ کالری‌شمار با غذاهای موردعلاقهٔ خودتان\nweight | رژیم چاقی و افزایش وزن | رسیدن سالم و پایدار به وزن ایده‌آل با تغذیهٔ مقوی\nactivity | تغذیهٔ ورزشکاران | برنامهٔ فیزیولوژی ورزشی برای ریکاوری و عضله‌سازی\nheart-pulse | رژیم بیماری‌های زمینه‌ای | دیابت، فشار خون، کبد چرب و چربی خون");
    }
    $nahalServicesSubtitle = nahal_opt('nahalServicesSubtitle', 'برنامهٔ غذایی متناسب با بدن و سبک زندگی شما');

    $nahalAboutTitle = trim((string)nahal_opt_raw('nahalAboutTitle'));
    $nahalAboutText  = (string)nahal_opt('nahalAboutText', '');
    $nahalAboutImageRaw = trim((string)nahal_opt_raw('nahalAboutImage'));
    $nahalAboutImage = ($nahalAboutImageRaw !== '') ? nahal_resolve_url($nahalAboutImageRaw) : nahal_asset('img/about.jpg');
    $nahalAboutFeatures = nahal_parse_features(nahal_opt_raw('nahalAboutFeatures'));
    $nahalAboutBtnText = trim((string)nahal_opt_raw('nahalAboutBtnText'));
    $nahalAboutBtnUrl  = trim((string)nahal_opt_raw('nahalAboutBtnUrl'));
    if ($nahalAboutBtnUrl === '') { $nahalAboutBtnUrl = '#booking'; }

    $nahalPackagesTitle = trim((string)nahal_opt_raw('nahalPackagesTitle'));
    $nahalPackagesSubtitle = nahal_opt('nahalPackagesSubtitle', 'برای هر هدف و هر بودجه، یک برنامهٔ مناسب وجود دارد');
    $nahalPackages = nahal_parse_packages(nahal_opt_raw('nahalPackages'));

    $nahalTestTitle    = trim((string)nahal_opt_raw('nahalTestimonialsTitle'));
    $nahalTestSubtitle = nahal_opt('nahalTestimonialsSubtitle', 'نتیجهٔ واقعی افراد واقعی؛ بدون رتوش');
    $nahalTestimonials = nahal_parse_testimonials(nahal_opt_raw('nahalTestimonials'));

    $nahalTeamTitle    = trim((string)nahal_opt_raw('nahalTeamTitle'));
    $nahalTeamSubtitle = nahal_opt('nahalTeamSubtitle', 'تیمی که سلامتی‌تان را به آن می‌سپارید');
    $nahalTeam         = nahal_parse_team(nahal_opt_raw('nahalTeam'));

    $nahalBlogShow = nahal_opt('nahalBlogShow', '1') === '1';
    $nahalBlogTitle = nahal_opt('nahalBlogTitle', 'مقالات تخصصی تغذیه');
    $nahalBlogSubtitle = nahal_opt('nahalBlogSubtitle', 'آخرین راهنمایی‌ها و نکات علمی تغذیه و سلامت');
    $nahalBlogCount = max(1, min(6, (int)nahal_opt('nahalBlogCount', '3')));

    $nahalFaqShow = nahal_opt('nahalFaqShow', '1') === '1';
    $nahalFaqTitle = nahal_opt('nahalFaqTitle', 'سوالات متداول');
    $nahalFaq      = nahal_parse_faq(nahal_opt_raw('nahalFaq'));

    // ---------- داده‌های رزرو و تماس ----------
    $nahalBookingTitle    = nahal_opt('nahalBookingTitle', 'درخواست مشاورهٔ رایگان');
    $nahalBookingSubtitle = nahal_opt('nahalBookingSubtitle', 'فرم را پر کنید؛ کارشناسان ما در اولین فرصت با شما تماس می‌گیرند');
    $nahalBookingServices = array_filter(array_map('trim', explode(',', (string)nahal_opt('nahalBookingServices', 'رژیم لاغری, رژیم چاقی, تغذیهٔ ورزشکاران, رژیم دیابت, تغذیهٔ بارداری, سایر موارد'))));
    $nahalBookingGoals    = array_filter(array_map('trim', explode(',', (string)nahal_opt('nahalBookingGoals', 'کاهش وزن, افزایش وزن, تناسب اندام, کنترل بیماری, سلامت عمومی'))));
    $nahalContactPhone  = nahal_opt_raw('nahalContactPhone');
    $nahalContactPhone2 = nahal_opt_raw('nahalContactPhone2');
    $nahalContactEmail  = nahal_opt_raw('nahalContactEmail');
    $nahalContactAddr   = nahal_opt_raw('nahalContactAddress');
    $nahalContactHours  = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string)nahal_opt_raw('nahalContactHours'))));
    $nahalMapEmbed = trim((string)nahal_opt_raw('nahalMapEmbed'));
?>

    <!-- ==================== هیرو ==================== -->
    <section class="hero" id="home">
        <div class="hero-decor hero-decor-1" aria-hidden="true"></div>
        <div class="hero-decor hero-decor-2" aria-hidden="true"></div>
        <div class="container hero-inner">
            <div class="hero-content">
                <?php if ($nahalHeroBadge !== ''): ?>
                <span class="hero-badge">
                    <?php echo nahal_icon('sparkles', 15); ?>
                    <?php echo htmlspecialchars($nahalHeroBadge, ENT_QUOTES); ?>
                </span>
                <?php endif; ?>
                <h1 class="hero-title"><?php echo htmlspecialchars($nahalHeroTitle, ENT_QUOTES); ?></h1>
                <div class="hero-subtitle">
                    <?php foreach (array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $nahalHeroSubtitle))) as $nahalHeroP): ?>
                    <p><?php echo htmlspecialchars($nahalHeroP, ENT_QUOTES); ?></p>
                    <?php endforeach; ?>
                </div>
                <div class="hero-actions">
                    <?php if (trim($nahalHeroBtn1Text) !== ''): ?>
                    <a href="<?php echo htmlspecialchars(nahal_link_url($nahalHeroBtn1Url), ENT_QUOTES); ?>" class="btn btn-primary btn-lg">
                        <?php echo nahal_icon('calendar-check', 18); ?>
                        <?php echo htmlspecialchars($nahalHeroBtn1Text, ENT_QUOTES); ?>
                    </a>
                    <?php endif; ?>
                    <?php if ($nahalHeroBtn2Text !== null && trim($nahalHeroBtn2Text) !== ''): ?>
                    <a href="<?php echo htmlspecialchars(nahal_link_url((string)$nahalHeroBtn2Url), ENT_QUOTES); ?>" class="btn btn-ghost btn-lg">
                        <?php echo nahal_icon('calculator', 17); ?>
                        <?php echo htmlspecialchars($nahalHeroBtn2Text, ENT_QUOTES); ?>
                    </a>
                    <?php endif; ?>
                </div>
                <?php if (!empty($nahalHeroStats)): ?>
                <div class="hero-stats">
                    <?php foreach ($nahalHeroStats as $nahalStat): ?>
                    <div class="hero-stat">
                        <span class="hero-stat-num"><?php echo toPersianNumbers(htmlspecialchars($nahalStat['num'], ENT_QUOTES)); ?></span>
                        <span class="hero-stat-label"><?php echo htmlspecialchars($nahalStat['label'], ENT_QUOTES); ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="hero-visual">
                <div class="hero-img-frame">
                    <img src="<?php echo htmlspecialchars($nahalHeroImage, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($nahalHeroTitle, ENT_QUOTES); ?>" class="hero-img" fetchpriority="high">
                </div>
                <div class="hero-card hero-card-1">
                    <?php echo nahal_icon('heart-pulse', 20); ?>
                    <div>
                        <strong>برنامهٔ کاملاً اختصاصی</strong>
                        <span>متناسب با بدن شما</span>
                    </div>
                </div>
                <div class="hero-card hero-card-2">
                    <?php echo nahal_icon('shield-check', 18); ?>
                    <div>
                        <strong>مبتنی بر علم روز</strong>
                        <span>راهکارهای اثبات‌شده</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php if ($nahalBmiShow): ?>
    <!-- ==================== ماشین‌حساب BMI ==================== -->
    <section class="section bmi-section" id="bmi">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo nahal_icon('calculator', 14); ?> ماشین‌حساب سلامت</span>
                <h2 class="section-title"><?php echo htmlspecialchars($nahalBmiTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($nahalBmiSubtitle, ENT_QUOTES); ?></p>
            </div>

            <div class="bmi-wrap">
                <div class="bmi-panel bmi-form-panel">

                    <!-- انتخاب جنسیت -->
                    <div class="bmi-gender" role="radiogroup" aria-label="جنسیت">
                        <button type="button" class="bmi-gender-btn is-active" id="bmiGenderFemale" data-gender="female" aria-pressed="true">
                            <?php echo nahal_icon('user', 20); ?>
                            <span>خانم هستم</span>
                        </button>
                        <button type="button" class="bmi-gender-btn" id="bmiGenderMale" data-gender="male" aria-pressed="false">
                            <?php echo nahal_icon('user', 20); ?>
                            <span>آقا هستم</span>
                        </button>
                    </div>

                    <!-- اسلایدرها -->
                    <div class="bmi-slider-row">
                        <div class="bmi-slider-head">
                            <label for="bmiAge"><?php echo nahal_icon('calendar', 15); ?> سن (سال)</label>
                            <output class="bmi-slider-val" id="bmiAgeOut">۳۰</output>
                        </div>
                        <input type="range" id="bmiAge" class="bmi-range" min="10" max="90" step="1" value="30">
                    </div>

                    <div class="bmi-slider-row">
                        <div class="bmi-slider-head">
                            <label for="bmiHeight"><?php echo nahal_icon('ruler', 15); ?> قد (سانتی‌متر)</label>
                            <output class="bmi-slider-val" id="bmiHeightOut">۱۶۵</output>
                        </div>
                        <input type="range" id="bmiHeight" class="bmi-range" min="120" max="220" step="1" value="165">
                    </div>

                    <div class="bmi-slider-row">
                        <div class="bmi-slider-head">
                            <label for="bmiWeight"><?php echo nahal_icon('weight', 15); ?> وزن (کیلوگرم)</label>
                            <output class="bmi-slider-val" id="bmiWeightOut">۷۰</output>
                        </div>
                        <input type="range" id="bmiWeight" class="bmi-range" min="30" max="200" step="0.5" value="70">
                    </div>

                    <?php if ($nahalBmiWaist): ?>
                    <div class="bmi-slider-row">
                        <div class="bmi-slider-head">
                            <label for="bmiWaist"><?php echo nahal_icon('activity', 15); ?> دور کمر (سانتی‌متر)</label>
                            <output class="bmi-slider-val" id="bmiWaistOut">۸۵</output>
                        </div>
                        <input type="range" id="bmiWaist" class="bmi-range" min="50" max="160" step="1" value="85">
                    </div>
                    <?php endif; ?>

                    <!-- سطح فعالیت -->
                    <div class="bmi-field">
                        <label for="bmiActivity"><?php echo nahal_icon('activity', 15); ?> سطح فعالیت روزانه</label>
                        <select id="bmiActivity" class="bmi-select">
                            <option value="1.2">بی‌تحرک (کار پشت میز، بدون ورزش)</option>
                            <option value="1.375" selected>کم‌تحرک (۱ تا ۳ روز ورزش در هفته)</option>
                            <option value="1.55">متعادل (۳ تا ۵ روز ورزش در هفته)</option>
                            <option value="1.725">پرتلاش (۶ تا ۷ روز ورزش در هفته)</option>
                            <option value="1.9">ورزشکار (تمرینات سنگین روزانه)</option>
                        </select>
                    </div>

                    <button type="button" class="btn btn-primary btn-lg btn-block" id="bmiCalcBtn">
                        <?php echo nahal_icon('zap', 18); ?>
                        محاسبه کن
                    </button>
                </div>

                <!-- نتایج -->
                <div class="bmi-panel bmi-result-panel" id="bmiResult" aria-live="polite">
                    <div class="bmi-result-empty" id="bmiResultEmpty">
                        <?php echo nahal_icon('gauge', 48); ?>
                        <p>مشخصاتت را انتخاب کن و دکمهٔ «محاسبه کن» را بزن؛<br>نتیجهٔ کامل همین‌جا نمایش داده می‌شود.</p>
                    </div>

                    <div class="bmi-result-body" id="bmiResultBody" hidden>
                        <!-- عدد بزرگ BMI + وضعیت -->
                        <div class="bmi-score-box">
                            <div class="bmi-score">
                                <span class="bmi-score-label">شاخص BMI شما</span>
                                <strong class="bmi-score-num" id="bmiScoreNum">—</strong>
                                <span class="bmi-score-cat" id="bmiScoreCat">—</span>
                            </div>
                        </div>

                        <!-- نوار رنگی وضعیت -->
                        <div class="bmi-gauge" aria-hidden="true">
                            <div class="bmi-gauge-bar"></div>
                            <span class="bmi-gauge-marker" id="bmiGaugeMarker"></span>
                        </div>
                        <div class="bmi-gauge-labels" aria-hidden="true">
                            <span>کم‌وزنی</span>
                            <span>نرمال</span>
                            <span>اضافه وزن</span>
                            <span>چاقی</span>
                        </div>

                        <!-- کارت‌های نتیجه -->
                        <div class="bmi-cards">
                            <div class="bmi-card">
                                <?php echo nahal_icon('target', 18); ?>
                                <div>
                                    <span class="bmi-card-label">وزن ایده‌آل شما</span>
                                    <strong class="bmi-card-val" id="bmiIdealVal">—</strong>
                                </div>
                            </div>
                            <div class="bmi-card">
                                <?php echo nahal_icon('flame', 18); ?>
                                <div>
                                    <span class="bmi-card-label">متابولیسم پایه (BMR)</span>
                                    <strong class="bmi-card-val" id="bmiBmrVal">—</strong>
                                </div>
                            </div>
                            <div class="bmi-card">
                                <?php echo nahal_icon('zap', 18); ?>
                                <div>
                                    <span class="bmi-card-label">کالری لازم روزانه</span>
                                    <strong class="bmi-card-val" id="bmiTdeeVal">—</strong>
                                </div>
                            </div>
                            <div class="bmi-card">
                                <?php echo nahal_icon('scale', 18); ?>
                                <div>
                                    <span class="bmi-card-label">محدودهٔ وزن سالم</span>
                                    <strong class="bmi-card-val" id="bmiRangeVal">—</strong>
                                </div>
                            </div>
                            <?php if ($nahalBmiWaist): ?>
                            <div class="bmi-card bmi-card-wide">
                                <?php echo nahal_icon('activity', 18); ?>
                                <div>
                                    <span class="bmi-card-label">نسبت کمر به قد</span>
                                    <strong class="bmi-card-val" id="bmiWhtrVal">—</strong>
                                    <span class="bmi-card-note" id="bmiWhtrNote"></span>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>

                        <p class="bmi-disclaimer" id="bmiNote"></p>

                        <a href="#booking" class="btn btn-primary btn-lg btn-block bmi-cta" id="bmiToBooking">
                            <?php echo nahal_icon('calendar-check', 18); ?>
                            دریافت برنامهٔ مناسب من
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    <?php if (!empty($nahalServices) && $nahalServicesTitle !== ''): ?>
    <!-- ==================== خدمات ==================== -->
    <section class="section services-section" id="services">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo nahal_icon('salad', 14); ?> خدمات ما</span>
                <h2 class="section-title"><?php echo htmlspecialchars($nahalServicesTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($nahalServicesSubtitle, ENT_QUOTES); ?></p>
            </div>
            <div class="services-grid">
                <?php foreach ($nahalServices as $nahalService): ?>
                <div class="service-card">
                    <span class="service-icon"><?php echo nahal_icon($nahalService['icon'], 26); ?></span>
                    <h3 class="service-title">
                        <?php if (trim($nahalService['url']) !== ''): ?>
                        <a href="<?php echo htmlspecialchars(nahal_link_url($nahalService['url']), ENT_QUOTES); ?>"><?php echo htmlspecialchars($nahalService['title'], ENT_QUOTES); ?></a>
                        <?php else: ?>
                        <?php echo htmlspecialchars($nahalService['title'], ENT_QUOTES); ?>
                        <?php endif; ?>
                    </h3>
                    <?php if ($nahalService['desc'] !== ''): ?>
                    <p class="service-desc"><?php echo htmlspecialchars($nahalService['desc'], ENT_QUOTES); ?></p>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($nahalAboutTitle !== '' && ($nahalAboutText !== '' || !empty($nahalAboutFeatures))): ?>
    <!-- ==================== چرا ما / درباره ==================== -->
    <section class="section about-section" id="about">
        <div class="container about-inner">
            <div class="about-visual">
                <div class="about-img-frame">
                    <img src="<?php echo htmlspecialchars($nahalAboutImage, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($nahalAboutTitle, ENT_QUOTES); ?>" class="about-img" loading="lazy">
                </div>
                <div class="about-card">
                    <?php echo nahal_icon('leaf', 22); ?>
                    <strong>مشاورهٔ اولیه رایگان</strong>
                </div>
            </div>
            <div class="about-content">
                <span class="section-tag"><?php echo nahal_icon('heart', 14); ?> چرا نهال</span>
                <h2 class="section-title about-title"><?php echo htmlspecialchars($nahalAboutTitle, ENT_QUOTES); ?></h2>
                <?php foreach (array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $nahalAboutText))) as $nahalAboutP): ?>
                <p class="about-text"><?php echo htmlspecialchars($nahalAboutP, ENT_QUOTES); ?></p>
                <?php endforeach; ?>
                <?php if (!empty($nahalAboutFeatures)): ?>
                <div class="about-features">
                    <?php foreach ($nahalAboutFeatures as $nahalFeature): ?>
                    <div class="about-feature">
                        <span class="about-feature-icon"><?php echo nahal_icon($nahalFeature['icon'], 19); ?></span>
                        <div class="about-feature-text">
                            <strong><?php echo htmlspecialchars($nahalFeature['title'], ENT_QUOTES); ?></strong>
                            <?php if ($nahalFeature['desc'] !== ''): ?>
                            <span><?php echo htmlspecialchars($nahalFeature['desc'], ENT_QUOTES); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                <?php if ($nahalAboutBtnText !== ''): ?>
                <a href="<?php echo htmlspecialchars(nahal_link_url($nahalAboutBtnUrl), ENT_QUOTES); ?>" class="btn btn-primary">
                    <?php echo nahal_icon('calendar-check', 16); ?>
                    <?php echo htmlspecialchars($nahalAboutBtnText, ENT_QUOTES); ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($nahalPackages) && $nahalPackagesTitle !== ''): ?>
    <!-- ==================== پکیج‌ها ==================== -->
    <section class="section packages-section" id="packages">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo nahal_icon('clipboard-list', 14); ?> تعرفه‌ها</span>
                <h2 class="section-title"><?php echo htmlspecialchars($nahalPackagesTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($nahalPackagesSubtitle, ENT_QUOTES); ?></p>
            </div>
            <div class="packages-grid">
                <?php foreach ($nahalPackages as $nahalPackage): ?>
                <div class="package-card<?php echo trim($nahalPackage['badge']) !== '' ? ' is-featured' : ''; ?>">
                    <?php if (trim($nahalPackage['badge']) !== ''): ?>
                    <span class="package-badge"><?php echo htmlspecialchars($nahalPackage['badge'], ENT_QUOTES); ?></span>
                    <?php endif; ?>
                    <h3 class="package-title"><?php echo htmlspecialchars($nahalPackage['title'], ENT_QUOTES); ?></h3>
                    <div class="package-price">
                        <?php if ($nahalPackage['price'] !== ''): ?>
                        <span class="package-price-current"><?php echo toPersianNumbers(htmlspecialchars($nahalPackage['price'], ENT_QUOTES)); ?></span>
                        <?php if ($nahalPackage['oldPrice'] !== ''): ?>
                        <span class="package-price-old"><?php echo toPersianNumbers(htmlspecialchars($nahalPackage['oldPrice'], ENT_QUOTES)); ?></span>
                        <?php endif; ?>
                        <?php else: ?>
                        <span class="package-price-current">تماس بگیرید</span>
                        <?php endif; ?>
                    </div>
                    <?php if ($nahalPackage['desc'] !== ''): ?>
                    <p class="package-desc"><?php echo htmlspecialchars($nahalPackage['desc'], ENT_QUOTES); ?></p>
                    <?php endif; ?>
                    <?php if (!empty($nahalPackage['items'])): ?>
                    <ul class="package-items">
                        <?php foreach ($nahalPackage['items'] as $nahalPackageItem): ?>
                        <li><?php echo nahal_icon('check-circle', 15); ?><span><?php echo htmlspecialchars($nahalPackageItem, ENT_QUOTES); ?></span></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                    <a href="<?php echo htmlspecialchars(nahal_link_url($nahalPackage['url'] !== '' ? $nahalPackage['url'] : '#booking'), ENT_QUOTES); ?>" class="btn btn-package<?php echo trim($nahalPackage['badge']) !== '' ? ' btn-primary' : ' btn-ghost'; ?>">
                        <?php echo nahal_icon('send', 15); ?>
                        <?php echo $nahalPackage['price'] !== '' ? 'سفارش پکیج' : 'استعلام قیمت'; ?>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($nahalTestimonials) && $nahalTestTitle !== ''): ?>
    <!-- ==================== تجربیات مراجعین ==================== -->
    <section class="section testimonials-section" id="testimonials">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo nahal_icon('star', 14); ?> نتایج واقعی</span>
                <h2 class="section-title"><?php echo htmlspecialchars($nahalTestTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($nahalTestSubtitle, ENT_QUOTES); ?></p>
            </div>
            <?php
            /* کاروسل تک‌کارت — هرچند تجربه تعریف شده باشد، یکی نمایش داده
               می‌شود و به‌صورت خودگردان با افکت محو/لغزش تعویض می‌شود */
            $nahalTestiCount = count($nahalTestimonials);
            ?>
            <div class="testimonials-carousel<?php echo $nahalTestiCount < 2 ? ' is-single' : ''; ?>" id="testimonialsCarousel">
                <div class="t-stage">
                    <?php foreach ($nahalTestimonials as $nahalTi => $nahalTestimonial): ?>
                    <figure class="testimonial-card<?php echo $nahalTi === 0 ? ' is-active' : ''; ?>"
                             data-name="تجربهٔ <?php echo htmlspecialchars($nahalTestimonial['name'], ENT_QUOTES); ?>"
                             aria-hidden="<?php echo $nahalTi === 0 ? 'false' : 'true'; ?>">
                        <div class="testimonial-meta">
                            <span class="testimonial-change"><?php echo toPersianNumbers(htmlspecialchars($nahalTestimonial['meta'], ENT_QUOTES)); ?></span>
                            <?php if (trim($nahalTestimonial['goal']) !== ''): ?>
                            <span class="testimonial-goal"><?php echo htmlspecialchars($nahalTestimonial['goal'], ENT_QUOTES); ?></span>
                            <?php endif; ?>
                        </div>
                        <blockquote class="testimonial-text">
                            <?php echo nahal_icon('quote', 20); ?>
                            <p><?php echo htmlspecialchars($nahalTestimonial['text'], ENT_QUOTES); ?></p>
                        </blockquote>
                        <figcaption class="testimonial-author">
                            <?php if (trim($nahalTestimonial['photo']) !== ''): ?>
                            <img src="<?php echo htmlspecialchars($nahalTestimonial['photo'], ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($nahalTestimonial['name'], ENT_QUOTES); ?>" class="testimonial-photo" loading="lazy">
                            <?php else: ?>
                            <span class="testimonial-avatar" aria-hidden="true"><?php echo htmlspecialchars(nahal_initial($nahalTestimonial['name']), ENT_QUOTES); ?></span>
                            <?php endif; ?>
                            <strong><?php echo htmlspecialchars($nahalTestimonial['name'], ENT_QUOTES); ?></strong>
                        </figcaption>
                    </figure>
                    <?php endforeach; ?>
                </div>
                <?php if ($nahalTestiCount > 1): ?>
                <div class="t-controls">
                    <button type="button" class="t-arrow t-prev" aria-label="تجربهٔ قبلی"><?php echo nahal_icon('chevron-right', 18); ?></button>
                    <div class="t-dots" role="tablist" aria-label="انتخاب تجربه"></div>
                    <button type="button" class="t-arrow t-next" aria-label="تجربهٔ بعدی"><?php echo nahal_icon('chevron-left', 18); ?></button>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($nahalTeam) && $nahalTeamTitle !== ''): ?>
    <!-- ==================== تیم متخصصین ==================== -->
    <section class="section team-section" id="team">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo nahal_icon('users', 14); ?> تیم ما</span>
                <h2 class="section-title"><?php echo htmlspecialchars($nahalTeamTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($nahalTeamSubtitle, ENT_QUOTES); ?></p>
            </div>
            <?php
            /* شبکهٔ داینامیک: ۴ کارت پیش‌فرض؛ با تعداد کمتر، کارت‌ها کش می‌آیند و
               جای کارت حذف‌شده را پر می‌کنند؛ یک متخصص به شکل ردیف (افقی) نمایش داده می‌شود */
            $nahalTeamCount = count($nahalTeam);
            $nahalTeamCols = max(1, min(4, $nahalTeamCount));
            ?>
            <div class="team-grid cols-<?php echo $nahalTeamCols; ?><?php echo $nahalTeamCount === 1 ? ' team-single' : ''; ?>">
                <?php foreach ($nahalTeam as $nahalMember): ?>
                <div class="team-card">
                    <?php if (trim($nahalMember['photo']) !== ''): ?>
                    <img src="<?php echo htmlspecialchars($nahalMember['photo'], ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($nahalMember['name'], ENT_QUOTES); ?>" class="team-photo" loading="lazy">
                    <?php else: ?>
                    <span class="team-avatar"><?php echo htmlspecialchars(nahal_initial($nahalMember['name']), ENT_QUOTES); ?></span>
                    <?php endif; ?>
                    <div class="team-info">
                        <strong class="team-name"><?php echo htmlspecialchars($nahalMember['name'], ENT_QUOTES); ?></strong>
                        <span class="team-role"><?php echo htmlspecialchars($nahalMember['role'], ENT_QUOTES); ?></span>
                        <?php if ($nahalMember['desc'] !== ''): ?>
                        <p class="team-desc"><?php echo htmlspecialchars($nahalMember['desc'], ENT_QUOTES); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($nahalBlogShow): ?>
    <!-- ==================== آخرین مقالات ==================== -->
    <section class="section blog-section" id="blog">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo nahal_icon('book-open', 14); ?> وبلاگ</span>
                <h2 class="section-title"><?php echo htmlspecialchars($nahalBlogTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($nahalBlogSubtitle, ENT_QUOTES); ?></p>
            </div>
            <?php
            // آخرین نوشته‌های منتشرشده (کوئری اختصاصی پوسته — شامل چکیده، تصویر و فیلدهای تغذیه‌ای)
            $nahalRecentPosts = nahal_recent_posts($nahalBlogCount);
            ?>
            <?php if (!empty($nahalRecentPosts)): ?>
            <div class="blog-grid">
                <?php foreach ($nahalRecentPosts as $nahalRecentPost): ?>
                <article class="blog-card">
                    <a href="<?php echo htmlspecialchars($nahalRecentPost['url'], ENT_QUOTES); ?>" class="blog-card-link">
                        <div class="blog-card-thumb">
                            <img src="<?php echo htmlspecialchars($nahalRecentPost['thumb'], ENT_QUOTES); ?>" alt="<?php echo toPersianNumbers(htmlspecialchars($nahalRecentPost['title'], ENT_QUOTES)); ?>" loading="lazy">
                            <?php if (is_numeric($nahalRecentPost['calories']) && (int)$nahalRecentPost['calories'] > 0): ?>
                            <span class="blog-card-badge"><?php echo nahal_icon('flame', 13); ?> <?php echo toPersianNumbers($nahalRecentPost['calories']); ?> کیلوکالری</span>
                            <?php elseif (is_numeric($nahalRecentPost['cookTime']) && (int)$nahalRecentPost['cookTime'] > 0): ?>
                            <span class="blog-card-badge"><?php echo nahal_icon('clock', 13); ?> <?php echo toPersianNumbers($nahalRecentPost['cookTime']); ?> دقیقه</span>
                            <?php endif; ?>
                        </div>
                        <div class="blog-card-body">
                            <div class="blog-card-meta">
                                <span><?php echo nahal_icon('calendar', 13); ?> <?php echo nahal_jalali_date($nahalRecentPost['created'], 'j F Y'); ?></span>
                                <?php if (nahal_opt('nahalShowViews', '1') === '1' && $nahalRecentPost['views'] > 0): ?>
                                <span><?php echo nahal_icon('eye', 13); ?> <?php echo nahal_num($nahalRecentPost['views']); ?></span>
                                <?php endif; ?>
                            </div>
                            <h3 class="blog-card-title"><?php echo toPersianNumbers(htmlspecialchars($nahalRecentPost['title'], ENT_QUOTES)); ?></h3>
                            <p class="blog-card-excerpt"><?php echo toPersianNumbers(mb_substr($nahalRecentPost['excerpt'], 0, 100, 'UTF-8') . '…'); ?></p>
                            <span class="blog-card-more">ادامه مطلب <?php echo nahal_icon('arrow-left', 14); ?></span>
                        </div>
                    </a>
                </article>
                <?php endforeach; ?>
            </div>
            <div class="section-more">
                <a href="<?php echo htmlspecialchars(nahal_blog_url(), ENT_QUOTES); ?>" class="btn btn-ghost">
                    مشاهدهٔ همهٔ مقالات
                    <?php echo nahal_icon('arrow-left', 15); ?>
                </a>
            </div>
            <?php else: ?>
            <div class="archive-empty">
                <?php echo nahal_icon('book-open', 44); ?>
                <p>هنوز مقاله‌ای منتشر نشده است.</p>
            </div>
            <?php endif; ?>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($nahalFaqShow && !empty($nahalFaq)): ?>
    <!-- ==================== سوالات متداول ==================== -->
    <section class="section faq-section" id="faq">
        <div class="container faq-inner">
            <div class="faq-head">
                <span class="section-tag"><?php echo nahal_icon('lightbulb', 14); ?> پرسش و پاسخ</span>
                <h2 class="section-title"><?php echo htmlspecialchars($nahalFaqTitle, ENT_QUOTES); ?></h2>
            </div>
            <div class="faq-list" id="faqList">
                <?php foreach ($nahalFaq as $nahalFaqItem): ?>
                <details class="faq-item">
                    <summary class="faq-q">
                        <?php echo nahal_icon('chevron-down', 17); ?>
                        <span><?php echo htmlspecialchars($nahalFaqItem['q'], ENT_QUOTES); ?></span>
                    </summary>
                    <div class="faq-a"><?php echo htmlspecialchars($nahalFaqItem['a'], ENT_QUOTES); ?></div>
                </details>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- ==================== رزرو و تماس ==================== -->
    <section class="section contact-section" id="booking">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo nahal_icon('calendar-check', 14); ?> رزرو مشاوره</span>
                <h2 class="section-title"><?php echo htmlspecialchars($nahalBookingTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($nahalBookingSubtitle, ENT_QUOTES); ?></p>
            </div>

            <div class="contact-grid" id="contact">
                <!-- اطلاعات تماس -->
                <div class="contact-info">
                    <h3 class="contact-info-title"><?php echo nahal_icon('phone-call', 18); ?> راه‌های ارتباطی</h3>
                    <ul class="contact-list">
                        <?php if ($nahalContactPhone !== null && trim($nahalContactPhone) !== ''): ?>
                        <li>
                            <span class="contact-ic"><?php echo nahal_icon('phone', 18); ?></span>
                            <div>
                                <strong>تلفن ثابت</strong>
                                <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $nahalContactPhone), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($nahalContactPhone), ENT_QUOTES); ?></a>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php if ($nahalContactPhone2 !== null && trim($nahalContactPhone2) !== ''): ?>
                        <li>
                            <span class="contact-ic"><?php echo nahal_icon('message-circle', 18); ?></span>
                            <div>
                                <strong>شمارهٔ همراه</strong>
                                <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $nahalContactPhone2), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($nahalContactPhone2), ENT_QUOTES); ?></a>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php if ($nahalContactEmail !== null && trim($nahalContactEmail) !== ''): ?>
                        <li>
                            <span class="contact-ic"><?php echo nahal_icon('mail', 18); ?></span>
                            <div>
                                <strong>ایمیل</strong>
                                <a href="mailto:<?php echo htmlspecialchars($nahalContactEmail, ENT_QUOTES); ?>"><?php echo htmlspecialchars($nahalContactEmail, ENT_QUOTES); ?></a>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php if ($nahalContactAddr !== null && trim($nahalContactAddr) !== ''): ?>
                        <li>
                            <span class="contact-ic"><?php echo nahal_icon('map-pin', 18); ?></span>
                            <div>
                                <strong>آدرس مرکز</strong>
                                <span><?php echo htmlspecialchars(toPersianNumbers($nahalContactAddr), ENT_QUOTES); ?></span>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php foreach ($nahalContactHours as $nahalHour): ?>
                        <li>
                            <span class="contact-ic"><?php echo nahal_icon('clock', 18); ?></span>
                            <div>
                                <strong>ساعت کاری</strong>
                                <span><?php echo htmlspecialchars(toPersianNumbers($nahalHour), ENT_QUOTES); ?></span>
                            </div>
                        </li>
                        <?php endforeach; ?>
                    </ul>

                    <?php
                    $nahalSocial = [
                        'instagram' => nahal_opt_raw('nahalSocialInstagram'),
                        'telegram'  => nahal_opt_raw('nahalSocialTelegram'),
                        'whatsapp'  => nahal_opt_raw('nahalSocialWhatsapp'),
                        'youtube'   => nahal_opt_raw('nahalSocialYoutube'),
                    ];
                    $nahalSocialActive = array_filter($nahalSocial, function ($u) { return trim((string)$u) !== ''; });
                    if (!empty($nahalSocialActive)):
                    ?>
                    <div class="contact-social">
                        <?php foreach ($nahalSocialActive as $nahalNet => $nahalUrl): ?>
                        <a href="<?php echo htmlspecialchars($nahalUrl, ENT_QUOTES); ?>" target="_blank" rel="noopener" aria-label="<?php echo ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام', 'whatsapp' => 'واتس‌اپ', 'youtube' => 'یوتیوب'][$nahalNet]; ?>">
                            <?php echo nahal_icon($nahalNet === 'telegram' ? 'send' : ($nahalNet === 'whatsapp' ? 'message-circle' : $nahalNet), 19); ?>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- فرم رزرو -->
                <div class="booking-panel">
                    <?php
                    /*
                     * ارسال به نقطهٔ پایانی اختصاصی /nahal-booking (الگو از افزونهٔ Booking)؛
                     * اگر مسیر هنوز ثبت نشده باشد، آدرس صفحهٔ جاری جایگزین می‌شود.
                     * توکن امنیتی _ مطابق Widget\Security::getToken برای همان صفحه تولید می‌شود
                     * و سمت سرور با getToken(referer) اعتبارسنجی می‌شود.
                     */
                    $nahalBookingAction = nahal_booking_endpoint();
                    try {
                        $nahalBookingToken = htmlspecialchars(
                            \Widget\Security::alloc()->getToken($this->request->getRequestUrl()),
                            ENT_QUOTES,
                            'UTF-8'
                        );
                    } catch (\Throwable $e) {
                        $nahalBookingToken = '';
                    }
                    ?>
                    <form class="booking-form" id="bookingForm" method="post"
                          action="<?php echo htmlspecialchars($nahalBookingAction, ENT_QUOTES); ?>" novalidate>
                        <input type="hidden" name="nahalBooking" value="1">
                        <?php if ($nahalBookingToken !== ''): ?>
                        <input type="hidden" name="_" value="<?php echo $nahalBookingToken; ?>">
                        <?php endif; ?>

                        <!-- تلهٔ هرزنامه — باید خالی بماند -->
                        <input type="text" name="nahalHp" class="hp-field" tabindex="-1" autocomplete="off" aria-hidden="true">

                        <div class="booking-form-row">
                            <div class="booking-field">
                                <label for="nahalName">نام و نام خانوادگی <span class="req">*</span></label>
                                <input type="text" id="nahalName" name="nahalName" class="booking-input" placeholder="مثلاً: سارا محمدی" required>
                            </div>
                            <div class="booking-field">
                                <label for="nahalPhone">شمارهٔ تلفن همراه <span class="req">*</span></label>
                                <input type="tel" id="nahalPhone" name="nahalPhone" class="booking-input" placeholder="۰۹۱۲۳۴۵۶۷۸۹" required>
                            </div>
                        </div>

                        <div class="booking-form-row">
                            <?php if (!empty($nahalBookingServices)): ?>
                            <div class="booking-field">
                                <label for="nahalService">نوع خدمت موردنیاز</label>
                                <select id="nahalService" name="nahalService" class="booking-input booking-select">
                                    <option value="">انتخاب کنید…</option>
                                    <?php foreach ($nahalBookingServices as $nahalBookingService): ?>
                                    <option value="<?php echo htmlspecialchars($nahalBookingService, ENT_QUOTES); ?>"><?php echo htmlspecialchars($nahalBookingService, ENT_QUOTES); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($nahalBookingGoals)): ?>
                            <div class="booking-field">
                                <label for="nahalGoal">هدف شما</label>
                                <select id="nahalGoal" name="nahalGoal" class="booking-input booking-select">
                                    <option value="">انتخاب کنید…</option>
                                    <?php foreach ($nahalBookingGoals as $nahalBookingGoal): ?>
                                    <option value="<?php echo htmlspecialchars($nahalBookingGoal, ENT_QUOTES); ?>"><?php echo htmlspecialchars($nahalBookingGoal, ENT_QUOTES); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="booking-form-row booking-form-row-3">
                            <div class="booking-field">
                                <label for="nahalAge">سن</label>
                                <input type="number" id="nahalAge" name="nahalAge" class="booking-input" min="2" max="120" placeholder="مثلاً: ۳۲">
                            </div>
                            <div class="booking-field">
                                <label for="nahalHeight">قد (cm)</label>
                                <input type="number" id="nahalHeight" name="nahalHeight" class="booking-input" min="120" max="220" placeholder="۱۶۵">
                            </div>
                            <div class="booking-field">
                                <label for="nahalWeight">وزن (kg)</label>
                                <input type="number" id="nahalWeight" name="nahalWeight" class="booking-input" min="30" max="200" placeholder="۷۰">
                            </div>
                        </div>
                        <input type="hidden" name="nahalBmi" id="nahalBmi" value="">

                        <div class="booking-field">
                            <label for="nahalNote">توضیحات (اختیاری)</label>
                            <textarea id="nahalNote" name="nahalNote" class="booking-input" rows="3" placeholder="هر نکته‌ای که لازم است بدانیم: بیماری زمینه‌ای، داروها، سبک زندگی…"></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg btn-block" id="bookingSubmitBtn">
                            <?php echo nahal_icon('send', 17); ?>
                            <span>ثبت درخواست مشاوره</span>
                        </button>

                        <p class="booking-form-note">
                            <?php echo nahal_icon('shield-check', 13); ?>
                            اطلاعات شما محفوظ است و فقط برای تماس کارشناسان استفاده می‌شود.
                        </p>

                        <div class="booking-alert booking-alert-success" id="bookingSuccess" hidden>
                            <?php echo nahal_icon('check-circle', 20); ?>
                            <div>
                                <strong>درخواست شما ثبت شد!</strong>
                                <span>کارشناسان ما در اولین فرصت با شما تماس می‌گیرند.</span>
                            </div>
                        </div>
                        <div class="booking-alert booking-alert-error" id="bookingError" hidden>
                            <?php echo nahal_icon('x', 20); ?>
                            <div>
                                <strong>خطا در ثبت درخواست!</strong>
                                <span id="bookingErrorText">لطفاً دوباره تلاش کنید.</span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <?php if ($nahalMapEmbed !== ''): ?>
            <div class="contact-map">
                <?php echo $nahalMapEmbed; ?>
            </div>
            <?php endif; ?>
        </div>
    </section>

<?php

else:

    /* ================================================================
     *  فهرست وبلاگ — مسیر آرشیو (/blog/) و صفحه‌بندی آن
     * ================================================================ */
?>
    <div class="container archive-wrap">
        <header class="archive-head">
            <span class="section-tag"><?php echo nahal_icon('file-text', 14); ?> وبلاگ</span>
            <h1 class="archive-title">
                <?php if ($this->is('archive')): ?>
                    <?php $this->archiveTitle(['category' => _t('دستهٔ %s'), 'search' => _t('جستجو: %s'), 'tag' => _t('برچسب %s'), 'author' => _t('نوشته‌های %s'), 'date' => _t('آرشیو %s')], '', ''); ?>
                <?php else: ?>
                    <?php echo htmlspecialchars(nahal_opt('nahalBlogTitle', 'مقالات تخصصی تغذیه') === 'مقالات تخصصی تغذیه' ? 'همهٔ مقالات' : nahal_opt('nahalBlogTitle', 'مقالات تخصصی تغذیه'), ENT_QUOTES); ?>
                <?php endif; ?>
            </h1>
            <p class="section-subtitle"><?php echo htmlspecialchars(nahal_opt('nahalBlogSubtitle', 'آخرین راهنمایی‌ها و نکات علمی تغذیه و سلامت'), ENT_QUOTES); ?></p>
        </header>

        <?php if ($this->have()): ?>
        <div class="archive-grid">
            <?php while ($this->next()): ?>
            <article class="blog-card">
                <a href="<?php $this->permalink(); ?>" class="blog-card-link">
                    <div class="blog-card-thumb">
                        <img src="<?php echo htmlspecialchars(nahal_thumbnail($this), ENT_QUOTES); ?>" alt="<?php echo nahal_fa_title($this); ?>" loading="lazy">
                        <?php
                        $nahalListCalories = nahal_calories($this);
                        $nahalListCook = nahal_cook_time($this);
                        ?>
                        <?php if ($nahalListCalories !== ''): ?>
                        <span class="blog-card-badge"><?php echo nahal_icon('flame', 13); ?> <?php echo $nahalListCalories; ?> کیلوکالری</span>
                        <?php elseif ($nahalListCook !== ''): ?>
                        <span class="blog-card-badge"><?php echo nahal_icon('clock', 13); ?> <?php echo $nahalListCook; ?> دقیقه</span>
                        <?php endif; ?>
                    </div>
                    <div class="blog-card-body">
                        <div class="blog-card-meta">
                            <span><?php echo nahal_icon('calendar', 13); ?> <?php echo nahal_post_date($this, 'j F Y'); ?></span>
                            <?php if (nahal_opt('nahalShowViews', '1') === '1'): ?>
                            <span><?php echo nahal_icon('eye', 13); ?> <?php echo nahal_num(nahal_views($this)); ?></span>
                            <?php endif; ?>
                        </div>
                        <h2 class="blog-card-title"><?php echo nahal_fa_title($this); ?></h2>
                        <p class="blog-card-excerpt"><?php echo toPersianNumbers(mb_substr(trim(strip_tags((string)$this->excerpt)), 0, 100, 'UTF-8') . '...'); ?></p>
                        <span class="blog-card-more">ادامه مطلب <?php echo nahal_icon('arrow-left', 14); ?></span>
                    </div>
                </a>
            </article>
            <?php endwhile; ?>
        </div>
        <?php else: ?>
        <div class="archive-empty">
            <?php echo nahal_icon('search', 44); ?>
            <p>هنوز مقاله‌ای منتشر نشده است.</p>
            <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-ghost">بازگشت به خانه</a>
        </div>
        <?php endif; ?>

        <?php nahal_page_nav($this); ?>
    </div>
<?php endif;

$this->need('footer.php');
