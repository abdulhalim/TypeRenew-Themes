<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="<?php $this->options->charset(); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php if ($this->options->favicon): ?>
    <link rel="icon" href="<?php $this->options->favicon(); ?>">
<?php endif; ?>
<title><?php $this->archiveTitle([
            'category' => _t('دستهٔ %s'),
            'search'   => _t('نتایج جستجوی %s'),
            'tag'      => _t('برچسب %s'),
            'author'   => _t('نوشته‌های %s')
        ], '', ' - '); ?><?php $this->options->title(); ?></title>
<?php
// ---------- توضیحات متا (فقط صفحهٔ اول) ----------
$nahalMetaDesc = '';
try {
    if (nahal_is_front()) {
        $nahalMetaDesc = trim((string)nahal_opt_raw('nahalHeroSubtitle'));
        $nahalMetaDesc = $nahalMetaDesc !== '' ? trim(preg_replace('/\s+/', ' ', strip_tags(str_replace("\n", ' ', $nahalMetaDesc)))) : '';
        if (mb_strlen($nahalMetaDesc) > 160) {
            $nahalMetaDesc = mb_substr($nahalMetaDesc, 0, 157, 'UTF-8') . '...';
        }
    }
} catch (\Throwable $e) {
}
if ($nahalMetaDesc !== ''):
?>
<meta name="description" content="<?php echo htmlspecialchars($nahalMetaDesc, ENT_QUOTES); ?>">
<?php endif; ?>
<?php $this->header(); ?>

<?php
// ---------- رنگ‌های داینامیک ----------
$nahalPrimary   = nahal_opt('nahalPrimaryColor', '#16a34a');
$nahalSecondary = nahal_opt('nahalSecondaryColor', '#14532d');
if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $nahalPrimary)) { $nahalPrimary = '#16a34a'; }
if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $nahalSecondary)) { $nahalSecondary = '#14532d'; }
?>

<style>:root{--primary:<?php echo $nahalPrimary; ?>;--secondary:<?php echo $nahalSecondary; ?>;}</style>

<!-- ---------- استایل‌های اصلی (با نسخه برای جلوگیری از کش) ---------- -->
<link rel="stylesheet" href="<?php $this->options->themeUrl('css/style.css'); ?>?v=1.0.0">
<link rel="stylesheet" href="<?php $this->options->themeUrl('css/fonts.css'); ?>?v=1.0.0">
</head>
<body class="nahal-body farsi-digits">
<a href="#main" class="skip-link">رفتن به محتوای اصلی</a>

<?php
// ---------- داده‌های مشترک ----------
$nahalClinicName = nahal_opt('nahalClinicName', (string)$this->options->title);
$nahalTagline    = nahal_opt('nahalTagline', 'تغذیهٔ سالم، زندگی سبز');
$nahalLogoUrl    = nahal_logo_url();
$nahalPhone      = nahal_opt_raw('nahalContactPhone');
$nahalShowTopbar = nahal_opt('nahalShowTopbar', '1') === '1';
$nahalOnHome     = nahal_is_front();
$nahalBlogUrl    = nahal_blog_url();
$nahalIsBlogPage = in_array(nahal_route(), ['archive', 'archive_page'], true);
$nahalSocial = [
    'instagram' => nahal_opt_raw('nahalSocialInstagram'),
    'telegram'  => nahal_opt_raw('nahalSocialTelegram'),
    'whatsapp'  => nahal_opt_raw('nahalSocialWhatsapp'),
    'youtube'   => nahal_opt_raw('nahalSocialYoutube'),
];
$nahalHoursLine = trim((string)nahal_opt_raw('nahalContactHours'));
$nahalHoursLine = ($nahalHoursLine !== '') ? trim(strtok($nahalHoursLine, "\n")) : '';
?>

<!-- ---------- نوار بالای هدر ---------- -->
<?php if ($nahalShowTopbar): ?>
<div class="topbar">
    <div class="container topbar-inner">
        <div class="topbar-item topbar-phone">
            <?php echo nahal_icon('phone', 15); ?>
            <?php if ($nahalPhone !== null && trim($nahalPhone) !== ''): ?>
                <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $nahalPhone), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($nahalPhone), ENT_QUOTES); ?></a>
            <?php endif; ?>
        </div>
        <?php if ($nahalHoursLine !== ''): ?>
        <div class="topbar-item topbar-hours">
            <?php echo nahal_icon('clock', 15); ?>
            <span><?php echo htmlspecialchars(toPersianNumbers($nahalHoursLine), ENT_QUOTES); ?></span>
        </div>
        <?php endif; ?>
        <div class="topbar-social">
            <?php foreach ($nahalSocial as $nahalNet => $nahalUrl): if (trim((string)$nahalUrl) !== ''): ?>
                <a href="<?php echo htmlspecialchars($nahalUrl, ENT_QUOTES); ?>" target="_blank" rel="noopener" aria-label="<?php echo ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام', 'whatsapp' => 'واتس‌اپ', 'youtube' => 'یوتیوب'][$nahalNet]; ?>">
                    <?php echo nahal_icon($nahalNet === 'telegram' ? 'send' : ($nahalNet === 'whatsapp' ? 'message-circle' : $nahalNet), 15); ?>
                </a>
            <?php endif; endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ---------- هدر اصلی ---------- -->
<header class="site-header<?php echo $nahalShowTopbar ? '' : ' no-topbar'; ?>" id="siteHeader">
    <div class="container nav-container">

        <!-- بخش راست: لوگو -->
        <div class="nav-logo">
            <a href="<?php $this->options->siteUrl(); ?>" class="logo-link">
                <?php if ($nahalLogoUrl !== ''): ?>
                    <img src="<?php echo htmlspecialchars($nahalLogoUrl, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($nahalClinicName, ENT_QUOTES); ?>" class="logo-img">
                <?php else: ?>
                    <span class="logo-mark" aria-hidden="true"><?php echo nahal_icon('leaf', 22); ?></span>
                <?php endif; ?>
                <span class="logo-text">
                    <span class="logo-main"><?php echo htmlspecialchars($nahalClinicName, ENT_QUOTES); ?></span>
                    <span class="logo-sub"><?php echo htmlspecialchars($nahalTagline, ENT_QUOTES); ?></span>
                </span>
            </a>
        </div>

        <!-- بخش وسط: منوی اصلی -->
        <nav class="main-nav" aria-label="منوی اصلی">
            <ul class="nav-links">
                <li><a href="<?php $this->options->siteUrl(); ?>" <?php if ($nahalOnHome): ?>class="active" aria-current="page"<?php endif; ?>><?php echo nahal_icon('home', 15); ?> خانه</a></li>
                <li><a href="<?php echo htmlspecialchars(nahal_link_url('#bmi', $nahalOnHome), ENT_QUOTES); ?>"><?php echo nahal_icon('calculator', 15); ?> محاسبهٔ BMI</a></li>
                <li><a href="<?php echo htmlspecialchars(nahal_link_url('#services', $nahalOnHome), ENT_QUOTES); ?>"><?php echo nahal_icon('salad', 15); ?> خدمات</a></li>
                <li><a href="<?php echo htmlspecialchars(nahal_link_url('#packages', $nahalOnHome), ENT_QUOTES); ?>"><?php echo nahal_icon('clipboard-list', 15); ?> پکیج‌ها</a></li>
                <li><a href="<?php echo htmlspecialchars($nahalOnHome ? '#blog' : $nahalBlogUrl, ENT_QUOTES); ?>" <?php if (!$nahalOnHome && ($nahalIsBlogPage || $this->is('archive') || $this->is('post'))): ?>class="active" aria-current="page"<?php endif; ?>><?php echo nahal_icon('file-text', 15); ?> مقالات</a></li>
                <?php
                // ---------- برگه‌های منو (برگهٔ دفتر رزرو حذف می‌شود) ----------
                $nahalNavPages = \Widget\Contents\Page\Rows::alloc();
                $nahalNavCount = 0;
                while ($nahalNavPages->next()):
                    if (nahal_is_reserve_cid((int)$nahalNavPages->cid)) { continue; }
                    $nahalNavCount++;
                    if ($nahalNavCount > 3) { break; } // حداکثر ۳ برگه در منو
                ?>
                    <li><a href="<?php $nahalNavPages->permalink(); ?>" <?php if ($this->is('page', $nahalNavPages->slug)): ?>class="active" aria-current="page"<?php endif; ?>><?php echo nahal_icon('file-text', 15); ?> <?php echo nahal_fa_title($nahalNavPages); ?></a></li>
                <?php endwhile; ?>
                <li><a href="<?php echo htmlspecialchars(nahal_link_url('#contact', $nahalOnHome), ENT_QUOTES); ?>"><?php echo nahal_icon('phone', 15); ?> تماس</a></li>
            </ul>
        </nav>

        <!-- بخش چپ: دکمهٔ رزرو -->
        <div class="nav-actions">
            <?php
            // بج مدیریت رزروها — همیشه برای مدیر/سردبیر نمایش داده می‌شود،
            // حتی اگر هنوز رزروی ثبت نشده باشد (شمارنده ۰ است)
            $nahalManageUrl = '';
            $nahalPending = 0;
            if (nahal_can_manage_bookings()) {
                $nahalPending = nahal_pending_bookings_count();
                $nahalManageUrl = nahal_manage_url();
            }
            if ($nahalManageUrl !== ''):
            ?>
            <a href="<?php echo htmlspecialchars($nahalManageUrl, ENT_QUOTES); ?>" class="nav-bookings-badge" title="مدیریت رزروها">
                <?php echo nahal_icon('calendar-check', 15); ?>
                <span>رزروها</span>
                <span class="badge-count"><?php echo toPersianNumbers($nahalPending); ?></span>
            </a>
            <?php endif; ?>
            <?php
            $nahalCtaText = nahal_opt('nahalHeroBtn1Text', 'دریافت برنامهٔ غذایی');
            $nahalCtaUrl  = nahal_opt('nahalHeroBtn1Url', '#booking');
            if (trim($nahalCtaText) !== '' && trim($nahalCtaUrl) !== ''):
            ?>
            <a href="<?php echo htmlspecialchars(nahal_link_url($nahalCtaUrl, $nahalOnHome), ENT_QUOTES); ?>" class="nav-cta">
                <?php echo nahal_icon('calendar-check', 16); ?>
                <span><?php echo htmlspecialchars($nahalCtaText, ENT_QUOTES); ?></span>
            </a>
            <?php endif; ?>
            <button type="button" class="menu-toggle" id="menuToggle" aria-label="باز کردن منو" aria-expanded="false" aria-controls="mobileMenu">
                <?php echo nahal_icon('menu', 22); ?>
            </button>
        </div>
    </div>
</header>

<!-- ---------- منوی موبایل ---------- -->
<div class="mobile-menu" id="mobileMenu" aria-hidden="true">
    <div class="mobile-menu-head">
        <span class="logo-mark" aria-hidden="true"><?php echo nahal_icon('leaf', 20); ?></span>
        <span class="mobile-menu-title"><?php echo htmlspecialchars($nahalClinicName, ENT_QUOTES); ?></span>
        <button type="button" class="mobile-menu-close" id="menuClose" aria-label="بستن منو">
            <?php echo nahal_icon('x', 20); ?>
        </button>
    </div>
    <nav class="mobile-nav" aria-label="منوی موبایل">
        <?php if ($nahalManageUrl !== ''): ?>
        <a href="<?php echo htmlspecialchars($nahalManageUrl, ENT_QUOTES); ?>" class="mobile-bookings-badge">
            <?php echo nahal_icon('calendar-check', 18); ?>
            مدیریت رزروها
            <span class="badge-count"><?php echo toPersianNumbers($nahalPending); ?></span>
        </a>
        <?php endif; ?>
        <a href="<?php $this->options->siteUrl(); ?>" <?php if ($nahalOnHome): ?>class="active" aria-current="page"<?php endif; ?>><?php echo nahal_icon('home', 18); ?> خانه</a>
        <a href="<?php echo htmlspecialchars(nahal_link_url('#bmi', $nahalOnHome), ENT_QUOTES); ?>" data-close><?php echo nahal_icon('calculator', 18); ?> محاسبهٔ BMI</a>
        <a href="<?php echo htmlspecialchars(nahal_link_url('#services', $nahalOnHome), ENT_QUOTES); ?>" data-close><?php echo nahal_icon('salad', 18); ?> خدمات</a>
        <a href="<?php echo htmlspecialchars(nahal_link_url('#packages', $nahalOnHome), ENT_QUOTES); ?>" data-close><?php echo nahal_icon('clipboard-list', 18); ?> پکیج‌ها</a>
        <a href="<?php echo htmlspecialchars(nahal_link_url('#testimonials', $nahalOnHome), ENT_QUOTES); ?>" data-close><?php echo nahal_icon('star', 18); ?> تجربیات مراجعین</a>
        <a href="<?php echo htmlspecialchars($nahalOnHome ? '#blog' : $nahalBlogUrl, ENT_QUOTES); ?>" data-close <?php if (!$nahalOnHome && ($nahalIsBlogPage || $this->is('archive') || $this->is('post'))): ?>class="active" aria-current="page"<?php endif; ?>><?php echo nahal_icon('file-text', 18); ?> مقالات</a>
        <?php
        $nahalNavPagesM = \Widget\Contents\Page\Rows::allocWithAlias('nahalMobile');
        while ($nahalNavPagesM->next()):
            if (nahal_is_reserve_cid((int)$nahalNavPagesM->cid)) { continue; }
        ?>
            <a href="<?php $nahalNavPagesM->permalink(); ?>"><?php echo nahal_icon('file-text', 18); ?> <?php echo nahal_fa_title($nahalNavPagesM); ?></a>
        <?php endwhile; ?>
        <a href="<?php echo htmlspecialchars(nahal_link_url('#contact', $nahalOnHome), ENT_QUOTES); ?>" data-close class="nav-contact-link"><?php echo nahal_icon('phone', 18); ?> تماس با ما</a>
    </nav>
    <?php if (trim((string)$nahalCtaUrl) !== '' && trim($nahalCtaText) !== ''): ?>
    <a href="<?php echo htmlspecialchars(nahal_link_url($nahalCtaUrl, $nahalOnHome), ENT_QUOTES); ?>" class="mobile-cta">
        <?php echo nahal_icon('calendar-check', 18); ?>
        <?php echo htmlspecialchars($nahalCtaText, ENT_QUOTES); ?>
    </a>
    <?php endif; ?>
    <?php if ($nahalPhone !== null && trim($nahalPhone) !== ''): ?>
    <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $nahalPhone), ENT_QUOTES); ?>" class="mobile-cta mobile-cta-phone">
        <?php echo nahal_icon('phone-call', 18); ?>
        <?php echo htmlspecialchars(toPersianNumbers($nahalPhone), ENT_QUOTES); ?>
    </a>
    <?php endif; ?>
</div>
<div class="menu-overlay" id="menuOverlay" aria-hidden="true"></div>

<main id="main" class="site-main">
