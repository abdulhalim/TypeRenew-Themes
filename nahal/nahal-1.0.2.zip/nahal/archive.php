<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');
?>

<div class="container archive-wrap">
    <header class="archive-head">
        <span class="section-tag"><?php echo nahal_icon('file-text', 14); ?> وبلاگ</span>
        <h1 class="archive-title">
            <?php $this->archiveTitle([
                'category' => _t('دستهٔ %s'),
                'search'   => _t('نتایج جستجوی %s'),
                'tag'      => _t('برچسب %s'),
                'author'   => _t('نوشته‌های %s'),
                'date'     => _t('آرشیو %s'),
            ], '', ''); ?>
        </h1>
    </header>

    <?php if ($this->have()): ?>
    <div class="archive-grid">
        <?php while ($this->next()): ?>
        <article class="blog-card">
            <a href="<?php $this->permalink(); ?>" class="blog-card-link">
                <div class="blog-card-thumb">
                    <img src="<?php echo htmlspecialchars(nahal_thumbnail($this), ENT_QUOTES); ?>" alt="<?php echo nahal_fa_title($this); ?>" loading="lazy">
                    <?php
                    $nahalArcCalories = nahal_calories($this);
                    $nahalArcCook = nahal_cook_time($this);
                    ?>
                    <?php if ($nahalArcCalories !== ''): ?>
                    <span class="blog-card-badge"><?php echo nahal_icon('flame', 13); ?> <?php echo $nahalArcCalories; ?> کیلوکالری</span>
                    <?php elseif ($nahalArcCook !== ''): ?>
                    <span class="blog-card-badge"><?php echo nahal_icon('clock', 13); ?> <?php echo $nahalArcCook; ?> دقیقه</span>
                    <?php endif; ?>
                </div>
                <div class="blog-card-body">
                    <div class="blog-card-meta">
                        <span><?php echo nahal_icon('calendar', 13); ?> <?php echo nahal_post_date($this, 'j F Y'); ?></span>
                        <?php if (nahal_opt('nahalShowViews', '1') === '1'): ?>
                        <span><?php echo nahal_icon('eye', 13); ?> <?php echo nahal_num(nahal_views($this)); ?></span>
                        <?php endif; ?>
                    </div>
                    <h2 class="blog-card-title"><?php echo nahal_fa_title($this); ?></h2>
                    <p class="blog-card-excerpt"><?php echo toPersianNumbers(mb_substr(trim(strip_tags((string)$this->excerpt)), 0, 100, 'UTF-8') . '...'); ?></p>
                    <span class="blog-card-more">ادامه مطلب <?php echo nahal_icon('arrow-left', 14); ?></span>
                </div>
            </a>
        </article>
        <?php endwhile; ?>
    </div>

    <?php nahal_page_nav($this); ?>
    <?php else: ?>
    <div class="archive-empty">
        <?php echo nahal_icon('search', 44); ?>
        <p>چیزی برای نمایش پیدا نشد.</p>
        <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-ghost">بازگشت به خانه</a>
    </div>
    <?php endif; ?>
</div>

<?php $this->need('footer.php'); ?>
