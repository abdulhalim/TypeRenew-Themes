<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$GLOBALS['nahalPostJs'] = true;

$this->need('header.php');
?>

<article class="page-wrap container">
    <header class="page-head">
        <nav class="post-breadcrumb" aria-label="مسیر">
            <a href="<?php $this->options->siteUrl(); ?>">خانه</a>
            <span class="crumb-sep">/</span>
            <span aria-current="page"><?php echo nahal_fa_title($this); ?></span>
        </nav>
        <h1 class="page-title"><?php echo nahal_fa_title($this); ?></h1>
        <div class="post-meta">
            <span class="post-meta-item">
                <?php echo nahal_icon('calendar', 15); ?>
                <time datetime="<?php $this->date('c'); ?>"><?php echo nahal_post_date($this, 'j F Y'); ?></time>
            </span>
            <?php if (nahal_opt('nahalShowViews', '1') === '1'): ?>
            <span class="post-meta-item">
                <?php echo nahal_icon('eye', 15); ?>
                <?php echo nahal_num(nahal_views($this)); ?> بازدید
            </span>
            <?php endif; ?>
        </div>
    </header>

    <?php $nahalPageCover = nahal_thumbnail($this, false); if ($nahalPageCover !== ''): ?>
    <figure class="post-cover">
        <img src="<?php echo htmlspecialchars($nahalPageCover, ENT_QUOTES); ?>" alt="<?php echo nahal_fa_title($this); ?>">
    </figure>
    <?php endif; ?>

    <div class="post-content page-content">
        <?php $this->content(); ?>
    </div>

    <?php
    // برگهٔ دفتر رزرو — دیدگاه‌های عمومی نشان داده نمی‌شود
    if (!nahal_is_reserve_cid((int)$this->cid)):
    ?>
    <?php $this->need('comments.php'); ?>
    <?php endif; ?>
</article>

<?php $this->need('footer.php'); ?>
