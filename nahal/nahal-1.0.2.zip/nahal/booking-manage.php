<?php
/**
 * مدیریت رزروهای نهال — قالب سفارشی برگه
 *
 * نمایش و مدیریت درخواست‌های رزرو (فقط برای اعضای واردشده با دسترسی مدیر/سردبیر).
 * درخواست‌ها روی برگهٔ «دفتر رزرو» به‌صورت دیدگاه ذخیره شده‌اند؛ این قالب
 * آن‌ها را به‌صورت ساختاریافته (مثل افزونهٔ Booking) نمایش می‌دهد و دکمه‌های
 * تأیید/رد/حذف دارد که با AJAX به نقطهٔ پایانی /nahal-booking ارسال می‌شوند.
 *
 * @package custom
 * @author پوردریایی
 * @link https://pourdaryaei.ir
 * @version 1.0.0
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$nahalManageOk = nahal_can_manage_bookings();
$nahalBookings = $nahalManageOk ? nahal_bookings_list() : [];
$nahalStats = ['total' => 0, 'waiting' => 0, 'approved' => 0, 'spam' => 0];
foreach ($nahalBookings as $nahalB) {
    $nahalStats['total']++;
    if (isset($nahalStats[$nahalB['status']])) {
        $nahalStats[$nahalB['status']]++;
    }
}

$nahalStatusLabels = [
    'waiting'  => 'در انتظار بررسی',
    'approved' => 'تأیید شده',
    'spam'     => 'رد شده',
];
$nahalStatusClasses = [
    'waiting'  => 'bkst-waiting',
    'approved' => 'bkst-approved',
    'spam'     => 'bkst-rejected',
];

$nahalManageToken = '';
try {
    $nahalManageToken = htmlspecialchars(
        \Widget\Security::alloc()->getToken($this->request->getRequestUrl()),
        ENT_QUOTES,
        'UTF-8'
    );
} catch (\Throwable $e) {
}

$nahalManageEndpoint = nahal_booking_endpoint();
?>

<article class="page-wrap container bk-manage">

    <header class="page-head">
        <nav class="post-breadcrumb" aria-label="مسیر">
            <a href="<?php $this->options->siteUrl(); ?>">خانه</a>
            <span class="crumb-sep">/</span>
            <span aria-current="page">مدیریت رزروها</span>
        </nav>
        <h1 class="page-title">
            <?php echo nahal_icon('calendar-check', 22); ?>
            مدیریت رزروها
        </h1>
        <p class="bk-manage-sub">درخواست‌های مشاورهٔ ثبت‌شده از فرم سایت — جدیدترین در ابتدا؛ درخواست‌های در انتظار بررسی اولویت دارند.</p>
    </header>

    <?php if (!$nahalManageOk): ?>
    <div class="bk-manage-notice" role="alert">
        <?php echo nahal_icon('lock', 22); ?>
        <div>
            <strong>ورود لازم است</strong>
            <span>برای مشاهده و مدیریت رزروها باید با حساب مدیر یا سردبیر وارد سایت شوید.</span>
            <a class="btn btn-primary btn-sm" href="<?php echo htmlspecialchars((string)$this->options->loginUrl, ENT_QUOTES); ?>">ورود به حساب</a>
        </div>
    </div>
    <?php else: ?>

    <div class="bk-manage-stats">
        <div class="bk-stat">
            <span class="bk-stat-num"><?php echo toPersianNumbers($nahalStats['waiting']); ?></span>
            <span class="bk-stat-label">در انتظار بررسی</span>
        </div>
        <div class="bk-stat bk-stat-approved">
            <span class="bk-stat-num"><?php echo toPersianNumbers($nahalStats['approved']); ?></span>
            <span class="bk-stat-label">تأیید شده</span>
        </div>
        <div class="bk-stat bk-stat-rejected">
            <span class="bk-stat-num"><?php echo toPersianNumbers($nahalStats['spam']); ?></span>
            <span class="bk-stat-label">رد شده</span>
        </div>
        <div class="bk-stat bk-stat-total">
            <span class="bk-stat-num"><?php echo toPersianNumbers($nahalStats['total']); ?></span>
            <span class="bk-stat-label">مجموع</span>
        </div>
    </div>

    <div class="bk-manage-list" id="bkManageList">
        <?php if (empty($nahalBookings)): ?>
        <div class="bk-manage-empty">
            <?php echo nahal_icon('inbox', 40); ?>
            <p>هنوز درخواستی ثبت نشده است.</p>
            <p class="bk-manage-empty-sub">به‌محض ثبت اولین فرم مشاوره، اینجا نمایش داده می‌شود.</p>
        </div>
        <?php else: ?>
        <?php foreach ($nahalBookings as $nahalB): ?>
        <?php
        $nahalBPhone = trim((string)($nahalB['phone'] !== '' ? $nahalB['phone'] : $nahalB['url']));
        $nahalBTel = preg_replace('/[^0-9+]/', '', $nahalBPhone);
        ?>
        <div class="bk-card" data-coid="<?php echo (int)$nahalB['coid']; ?>">
            <div class="bk-card-head">
                <span class="bk-status <?php echo $nahalStatusClasses[$nahalB['status']] ?? 'bkst-other'; ?>">
                    <?php echo htmlspecialchars($nahalStatusLabels[$nahalB['status']] ?? $nahalB['status'], ENT_QUOTES); ?>
                </span>
                <span class="bk-card-date">
                    <?php echo nahal_icon('clock', 13); ?>
                    <?php echo nahal_jalali_date((int)$nahalB['created'], 'j F Y — H:i'); ?>
                </span>
            </div>

            <div class="bk-card-body">
                <div class="bk-card-main">
                    <div class="bk-card-name">
                        <?php echo nahal_icon('user', 16); ?>
                        <strong><?php echo htmlspecialchars((string)$nahalB['author'], ENT_QUOTES); ?></strong>
                    </div>
                    <?php if ($nahalBPhone !== ''): ?>
                    <div class="bk-card-field">
                        <?php echo nahal_icon('phone', 15); ?>
                        <a href="tel:<?php echo htmlspecialchars($nahalBTel, ENT_QUOTES); ?>" dir="ltr"><?php echo htmlspecialchars(toPersianNumbers($nahalBPhone), ENT_QUOTES); ?></a>
                    </div>
                    <?php endif; ?>
                    <?php if ($nahalB['mail'] !== ''): ?>
                    <div class="bk-card-field">
                        <?php echo nahal_icon('mail', 15); ?>
                        <a href="mailto:<?php echo htmlspecialchars($nahalB['mail'], ENT_QUOTES); ?>" dir="ltr"><?php echo htmlspecialchars($nahalB['mail'], ENT_QUOTES); ?></a>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="bk-card-side">
                    <?php if ($nahalB['service'] !== ''): ?>
                    <div class="bk-tag"><?php echo nahal_icon('salad', 13); ?> <?php echo htmlspecialchars($nahalB['service'], ENT_QUOTES); ?></div>
                    <?php endif; ?>
                    <?php if ($nahalB['goal'] !== ''): ?>
                    <div class="bk-tag"><?php echo nahal_icon('target', 13); ?> <?php echo htmlspecialchars($nahalB['goal'], ENT_QUOTES); ?></div>
                    <?php endif; ?>
                    <?php if ($nahalB['bmi'] !== ''): ?>
                    <div class="bk-tag bk-tag-bmi"><?php echo nahal_icon('activity', 13); ?> BMI: <?php echo htmlspecialchars($nahalB['bmi'], ENT_QUOTES); ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($nahalB['age'] !== '' || $nahalB['height'] !== '' || $nahalB['weight'] !== ''): ?>
            <div class="bk-card-metrics">
                <?php if ($nahalB['age'] !== ''): ?><span><?php echo nahal_icon('cake', 13); ?> سن: <strong><?php echo htmlspecialchars($nahalB['age'], ENT_QUOTES); ?></strong></span><?php endif; ?>
                <?php if ($nahalB['height'] !== ''): ?><span><?php echo nahal_icon('ruler', 13); ?> قد: <strong><?php echo htmlspecialchars($nahalB['height'], ENT_QUOTES); ?> سانتی‌متر</strong></span><?php endif; ?>
                <?php if ($nahalB['weight'] !== ''): ?><span><?php echo nahal_icon('scale', 13); ?> وزن: <strong><?php echo htmlspecialchars($nahalB['weight'], ENT_QUOTES); ?> کیلوگرم</strong></span><?php endif; ?>
            </div>
            <?php endif; ?>

            <?php if ($nahalB['note'] !== ''): ?>
            <div class="bk-card-note">
                <?php echo nahal_icon('message-square', 14); ?>
                <p><?php echo htmlspecialchars($nahalB['note'], ENT_QUOTES); ?></p>
            </div>
            <?php endif; ?>

            <div class="bk-card-actions">
                <?php if ($nahalB['status'] !== 'approved'): ?>
                <button type="button" class="bk-btn bk-btn-approve" data-mode="approve" data-coid="<?php echo (int)$nahalB['coid']; ?>">
                    <?php echo nahal_icon('check', 14); ?> تأیید
                </button>
                <?php endif; ?>
                <?php if ($nahalB['status'] !== 'spam'): ?>
                <button type="button" class="bk-btn bk-btn-reject" data-mode="reject" data-coid="<?php echo (int)$nahalB['coid']; ?>">
                    <?php echo nahal_icon('x', 14); ?> رد
                </button>
                <?php endif; ?>
                <button type="button" class="bk-btn bk-btn-delete" data-mode="delete" data-coid="<?php echo (int)$nahalB['coid']; ?>">
                    <?php echo nahal_icon('trash-2', 14); ?> حذف
                </button>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script>
    (function () {
        'use strict';
        var list = document.getElementById('bkManageList');
        if (!list) { return; }
        var endpoint = <?php echo json_encode($nahalManageEndpoint, JSON_UNESCAPED_SLASHES); ?>;
        var token = <?php echo json_encode($nahalManageToken); ?>;

        function setBusy(card, busy) {
            Array.prototype.forEach.call(card.querySelectorAll('.bk-btn'), function (b) {
                b.disabled = !!busy;
            });
        }

        list.addEventListener('click', function (e) {
            var btn = e.target.closest ? e.target.closest('.bk-btn') : null;
            if (!btn || btn.disabled) { return; }
            var card = btn.closest('.bk-card');
            if (!card) { return; }
            var coid = parseInt(btn.getAttribute('data-coid'), 10);
            var mode = btn.getAttribute('data-mode');
            if (!coid || !mode) { return; }

            if (mode === 'delete' && !window.confirm('این رزرو برای همیشه حذف شود؟')) { return; }

            setBusy(card, true);
            btn.classList.add('loading');

            var body = new URLSearchParams();
            body.append('nahalBooking', '1');
            body.append('mode', mode);
            body.append('coid', String(coid));
            if (token) { body.append('_', token); }

            fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' },
                body: body.toString(),
                credentials: 'same-origin'
            })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (data && data.ok) {
                        // ساده و مطمئن: بارگذاری مجدد صفحه
                        window.location.reload();
                    } else {
                        alert((data && data.error) ? data.error : 'خطا در به‌روزرسانی رزرو.');
                        setBusy(card, false);
                        btn.classList.remove('loading');
                    }
                })
                .catch(function () {
                    alert('خطای ارتباط با سرور؛ دوباره تلاش کنید.');
                    setBusy(card, false);
                    btn.classList.remove('loading');
                });
        });
    })();
    </script>
    <?php endif; ?>

</article>

<?php $this->need('footer.php'); ?>
