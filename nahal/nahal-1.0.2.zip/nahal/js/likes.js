(function () {
    'use strict';

    function faNum(n) {
        var map = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return String(n).replace(/[0-9]/g, function (d) { return map[+d]; });
    }

    function paintLike(btn, likes, liked) {
        var count = btn.querySelector('.like-count');
        var label = btn.querySelector('.like-label');
        if (count) { count.textContent = faNum(Math.max(0, likes)); }
        if (label) { label.textContent = liked ? 'پسندیدید' : 'این مطلب را پسندیدید؟'; }
        if (liked) { btn.classList.add('is-liked'); } else { btn.classList.remove('is-liked'); }
        btn.setAttribute('data-likes', String(Math.max(0, likes)));
        btn.setAttribute('data-liked', liked ? '1' : '0');
        btn.setAttribute('aria-pressed', liked ? 'true' : 'false');
    }

    function initLikeButton() {
        var likeBtn = document.getElementById('nahalLikeBtn');
        if (!likeBtn || !likeBtn.getAttribute('data-cid')) { return; }
        var likeBusy = false;

        likeBtn.addEventListener('click', function () {
            if (likeBusy) { return; }
            likeBusy = true;

            var cid = String(likeBtn.getAttribute('data-cid') || '');
            var before = {
                likes: parseInt(likeBtn.getAttribute('data-likes'), 10) || 0,
                liked: likeBtn.getAttribute('data-liked') === '1'
            };
            var delta = before.liked ? -1 : 1;

            // رابط خوش‌بینانه
            paintLike(likeBtn, before.likes + delta, !before.liked);
            if (delta > 0) {
                likeBtn.classList.add('pop');
                window.setTimeout(function () { likeBtn.classList.remove('pop'); }, 650);
            }

            var body = new URLSearchParams();
            body.append('nahalLike', cid);

            fetch(window.location.href, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: body.toString(),
                credentials: 'same-origin'
            })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (data && data.ok) {
                        paintLike(likeBtn, data.likes, data.liked);
                    } else {
                        // برگرداندن حالت قبل
                        paintLike(likeBtn, before.likes, before.liked);
                    }
                })
                .catch(function () {
                    paintLike(likeBtn, before.likes, before.liked);
                })
                .finally(function () {
                    likeBusy = false;
                });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initLikeButton);
    } else {
        initLikeButton();
    }
})();
