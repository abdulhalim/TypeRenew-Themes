/* ================================================================
 *  نهال — اسکریپت اصلی
 *  منو + ماشین‌حساب BMI + فرم رزرو + سوالات متداول (آکاردئونی)
 *  + کاروسل تجربیات مراجعین + ابزارهای عمومی
 * ================================================================ */
(function () {
    'use strict';

    /* ---------- تبدیل ارقام به فارسی ---------- */
    function faNum(str) {
        var map = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return String(str).replace(/[0-9]/g, function (d) { return map[+d]; });
    }

    /* ---------- عدد اعشاری فارسی با ممیز ٫ ---------- */
    function faDec(str) {
        return faNum(String(str).replace('.', '٫'));
    }

    /* ---------- تبدیل ارقام فارسی/عربی به لاتین ---------- */
    function enNum(str) {
        return String(str)
            .replace(/[۰-۹]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); })
            .replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); });
    }

    /* ---------- منوی موبایل ---------- */
    var menu = document.getElementById('mobileMenu');
    var overlay = document.getElementById('menuOverlay');
    var toggle = document.getElementById('menuToggle');
    var closeBtn = document.getElementById('menuClose');

    function openMenu() {
        if (!menu) { return; }
        menu.classList.add('open');
        if (overlay) { overlay.classList.add('show'); }
        menu.setAttribute('aria-hidden', 'false');
        if (toggle) { toggle.setAttribute('aria-expanded', 'true'); }
        document.body.style.overflow = 'hidden';
    }

    function closeMenu() {
        if (!menu) { return; }
        menu.classList.remove('open');
        if (overlay) { overlay.classList.remove('show'); }
        menu.setAttribute('aria-hidden', 'true');
        if (toggle) { toggle.setAttribute('aria-expanded', 'false'); }
        document.body.style.overflow = '';
    }

    if (toggle) { toggle.addEventListener('click', openMenu); }
    if (closeBtn) { closeBtn.addEventListener('click', closeMenu); }
    if (overlay) { overlay.addEventListener('click', closeMenu); }

    document.querySelectorAll('.mobile-nav a[data-close]').forEach(function (link) {
        link.addEventListener('click', closeMenu);
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') { closeMenu(); }
    });

    /* ---------- سایهٔ هدر بعد از اسکرول + دکمهٔ بالا ---------- */
    var header = document.getElementById('siteHeader');
    var backToTop = document.getElementById('backToTop');

    function onScroll() {
        var y = window.scrollY || window.pageYOffset;
        if (header) {
            if (y > 10) { header.classList.add('scrolled'); }
            else { header.classList.remove('scrolled'); }
        }
        if (backToTop) {
            if (y > 460) { backToTop.classList.add('show'); }
            else { backToTop.classList.remove('show'); }
        }
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    if (backToTop) {
        backToTop.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    /* ---------- سوالات متداول: بستن سوال قبلی هنگام بازشدن سوال جدید ---------- */
    (function initFaqAccordion() {
        var items = document.querySelectorAll('.faq-list details');
        if (items.length < 2) { return; }
        items.forEach(function (item) {
            item.addEventListener('toggle', function () {
                if (!item.open) { return; }
                items.forEach(function (other) {
                    if (other !== item && other.open) { other.open = false; }
                });
            });
        });
    })();

    /* ================================================================
     *  ماشین‌حساب BMI — کامل و مخصوص خانم‌ها و آقایان
     * ================================================================ */
    var bmiForm = document.getElementById('bmi');

    function initBmi() {
        var genderBtns = document.querySelectorAll('.bmi-gender-btn');
        var ageEl = document.getElementById('bmiAge');
        var heightEl = document.getElementById('bmiHeight');
        var weightEl = document.getElementById('bmiWeight');
        var waistEl = document.getElementById('bmiWaist');
        var activityEl = document.getElementById('bmiActivity');
        var calcBtn = document.getElementById('bmiCalcBtn');
        if (!calcBtn || !heightEl || !weightEl || !ageEl) { return; }

        var gender = 'female';
        var hasWaist = !!waistEl;

        // نمایش لحظه‌ای مقدار اسلایدرها + پرشدن مسیر
        function bindSlider(el, out) {
            if (!el || !out) { return; }
            var paint = function () {
                var raw = el.value;
                var shown = (el.step && parseFloat(el.step) % 1 !== 0)
                    ? parseFloat(raw).toFixed(1)
                    : String(Math.round(parseFloat(raw)));
                out.textContent = faNum(shown);
                var min = parseFloat(el.min), max = parseFloat(el.max), val = parseFloat(raw);
                var pct = ((val - min) / (max - min)) * 100;
                el.style.setProperty('--fill', pct + '%');
            };
            el.addEventListener('input', paint);
            paint();
        }

        bindSlider(ageEl, document.getElementById('bmiAgeOut'));
        bindSlider(heightEl, document.getElementById('bmiHeightOut'));
        bindSlider(weightEl, document.getElementById('bmiWeightOut'));
        if (hasWaist) { bindSlider(waistEl, document.getElementById('bmiWaistOut')); }

        // انتخاب جنسیت
        genderBtns.forEach(function (btn) {
            btn.addEventListener('click', function () {
                genderBtns.forEach(function (b) {
                    b.classList.remove('is-active');
                    b.setAttribute('aria-pressed', 'false');
                });
                btn.classList.add('is-active');
                btn.setAttribute('aria-pressed', 'true');
                gender = btn.getAttribute('data-gender') || 'female';
            });
        });

        // دسته‌بندی BMI
        function bmiCategory(v) {
            if (v < 18.5) { return { name: 'کم‌وزنی', color: '#38bdf8' }; }
            if (v < 25) { return { name: 'وزن نرمال', color: '#22c55e' }; }
            if (v < 30) { return { name: 'اضافه وزن', color: '#f59e0b' }; }
            if (v < 35) { return { name: 'چاقی درجه ۱', color: '#ef4444' }; }
            if (v < 40) { return { name: 'چاقی درجه ۲', color: '#dc2626' }; }
            return { name: 'چاقی درجه ۳', color: '#b91c1c' };
        }

        // جایگاه نشانگر روی نوار رنگی (BMI از ۱۵ تا ۴۰)
        function gaugePos(v) {
            var min = 15, max = 40;
            var pct = ((v - min) / (max - min)) * 100;
            return Math.max(2, Math.min(98, pct));
        }

        function calculate() {
            var age = parseInt(ageEl.value, 10);
            var hCm = parseFloat(heightEl.value);
            var wKg = parseFloat(weightEl.value);
            var waist = hasWaist ? parseFloat(waistEl.value) : 0;
            var activity = activityEl ? parseFloat(activityEl.value) : 1.375;

            var hM = hCm / 100;
            var bmi = wKg / (hM * hM);
            var cat = bmiCategory(bmi);

            // نمایش نتیجه
            var emptyEl = document.getElementById('bmiResultEmpty');
            var bodyEl = document.getElementById('bmiResultBody');
            if (emptyEl) { emptyEl.hidden = true; }
            if (bodyEl) { bodyEl.hidden = false; }

            var scoreNum = document.getElementById('bmiScoreNum');
            var scoreCat = document.getElementById('bmiScoreCat');
            var marker = document.getElementById('bmiGaugeMarker');
            if (scoreNum) { scoreNum.textContent = faDec(bmi.toFixed(1)); }
            if (scoreCat) {
                scoreCat.textContent = cat.name;
                scoreCat.style.background = cat.color;
            }
            if (marker) {
                marker.style.left = gaugePos(bmi) + '%';
                marker.style.borderColor = cat.color;
            }

            // وزن ایده‌آل (فرمول دِواین — مخصوص خانم‌ها و آقایان)
            var inchesOver5ft = Math.max(0, (hCm / 2.54) - 60);
            var ideal = (gender === 'male')
                ? 50 + 2.3 * inchesOver5ft
                : 45.5 + 2.3 * inchesOver5ft;

            // متابولیسم پایه (میفلین-سنت‌جور — مخصوص خانم‌ها و آقایان)
            var bmr = 10 * wKg + 6.25 * hCm - 5 * age + (gender === 'male' ? 5 : -161);
            var tdee = bmr * activity;

            // محدودهٔ وزن سالم
            var wMin = 18.5 * hM * hM;
            var wMax = 24.9 * hM * hM;

            var idealEl = document.getElementById('bmiIdealVal');
            var bmrEl = document.getElementById('bmiBmrVal');
            var tdeeEl = document.getElementById('bmiTdeeVal');
            var rangeEl = document.getElementById('bmiRangeVal');
            if (idealEl) { idealEl.textContent = faNum(Math.round(ideal)) + ' کیلوگرم'; }
            if (bmrEl) { bmrEl.textContent = faNum(Math.round(bmr)) + ' کیلوکالری'; }
            if (tdeeEl) { tdeeEl.textContent = faNum(Math.round(tdee)) + ' کیلوکالری'; }
            if (rangeEl) { rangeEl.textContent = faNum(Math.round(wMin)) + ' تا ' + faNum(Math.round(wMax)) + ' کیلوگرم'; }

            // نسبت کمر به قد
            var whtrEl = document.getElementById('bmiWhtrVal');
            var whtrNote = document.getElementById('bmiWhtrNote');
            if (hasWaist && whtrEl) {
                var whtr = waist / hCm;
                whtrEl.textContent = faDec(whtr.toFixed(2));
                if (whtrNote) {
                    if (whtr <= 0.4) {
                        whtrNote.textContent = 'از حد سلامت پایین‌تر است — با متخصص مشورت کنید.';
                    } else if (whtr <= 0.5) {
                        whtrNote.textContent = 'در محدودهٔ سلامت است. آفرین!';
                    } else if (whtr <= 0.6) {
                        whtrNote.textContent = 'کمی بالاتر از حد سلامت — خطر قلبی-عروقی متوسط.';
                    } else {
                        whtrNote.textContent = 'بالاتر از حد سلامت — توصیه می‌شود برنامهٔ کاهش چربی شکم بگیرید.';
                    }
                }
            }

            // پیام راهنما
            var note = document.getElementById('bmiNote');
            if (note) {
                var diff = wKg - ideal;
                var msg;
                if (Math.abs(diff) <= 2) {
                    msg = 'وزن شما تقریباً در محدودهٔ ایده‌آل است؛ حفظ این وضعیت با تغذیهٔ سالم توصیه می‌شود.';
                } else if (diff > 0) {
                    msg = 'حدود ' + faNum(Math.round(diff)) + ' کیلوگرم بالاتر از وزن ایده‌آل هستید. با یک برنامهٔ پایدار، کاهش ۰٫۵ تا ۱ کیلو در هفته سالم و ماندگار است.';
                } else {
                    msg = 'حدود ' + faNum(Math.round(-diff)) + ' کیلوگرم پایین‌تر از وزن ایده‌آل هستید. افزایش وزن سالم با تغذیهٔ مقوی قابل‌دسترسی است.';
                }
                note.textContent = msg;
            }

            // پرکردن خودکار فرم رزرو
            try {
                var fAge = document.getElementById('nahalAge');
                var fHeight = document.getElementById('nahalHeight');
                var fWeight = document.getElementById('nahalWeight');
                var fBmi = document.getElementById('nahalBmi');
                if (fAge) { fAge.value = age; }
                if (fHeight) { fHeight.value = Math.round(hCm); }
                if (fWeight) { fWeight.value = Math.round(wKg); }
                if (fBmi) { fBmi.value = bmi.toFixed(1); }
            } catch (e) { }
        }

        calcBtn.addEventListener('click', function () {
            calculate();
            // اسکرول نرم به پنل نتیجه در موبایل
            var panel = document.getElementById('bmiResult');
            if (panel && window.innerWidth < 920) {
                var top = panel.getBoundingClientRect().top + window.pageYOffset - (header ? header.offsetHeight : 0) - 14;
                window.scrollTo({ top: top, behavior: 'smooth' });
            }
        });

        // محاسبهٔ اولیه برای نمایش نمونه
        calculate();
    }

    if (bmiForm) { initBmi(); }

    /* ================================================================
     *  فرم رزرو — AJAX به نقطهٔ پایانی اختصاصی /nahal-booking
     *  (الگو از افزونهٔ Booking؛ توکن _ و تلهٔ هرزنامه همراه فرم ارسال می‌شود)
     * ================================================================ */
    function initBooking() {
        var form = document.getElementById('bookingForm');
        if (!form) { return; }

        var submitBtn = document.getElementById('bookingSubmitBtn');
        var successEl = document.getElementById('bookingSuccess');
        var errorEl = document.getElementById('bookingError');
        var errorText = document.getElementById('bookingErrorText');

        function showMsg(el, textEl, msg) {
            if (el) { el.hidden = false; }
            if (textEl && typeof msg === 'string' && msg !== '') { textEl.textContent = msg; }
            if (el) {
                try { el.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) { }
            }
        }

        form.addEventListener('submit', function (e) {
            e.preventDefault();

            // مخفی‌کردن پیام‌های قبلی
            if (successEl) { successEl.hidden = true; }
            if (errorEl) { errorEl.hidden = true; }

            // اعتبارسنجی سمت کلاینت
            var name = (form.querySelector('#nahalName') || {}).value || '';
            var phone = (form.querySelector('#nahalPhone') || {}).value || '';
            phone = enNum(String(phone)).replace(/[\s\-()]/g, '');

            if (name.trim().length < 2) {
                showMsg(errorEl, errorText, 'لطفاً نام خود را کامل وارد کنید.');
                return;
            }
            if (!/^(\+98|98|0098|0)?9\d{9}$/.test(phone) && !/^0\d{9,10}$/.test(phone)) {
                showMsg(errorEl, errorText, 'شمارهٔ تلفن معتبر نیست (مثال: ۰۹۱۲۳۴۵۶۷۸۹).');
                return;
            }

            // حالت بارگذاری
            if (submitBtn) {
                submitBtn.classList.add('loading');
                submitBtn.setAttribute('disabled', 'disabled');
            }

            // گردآوری همهٔ فیلدهای فرم (شامل توکن _ و تلهٔ هرزنامه)
            var body = new URLSearchParams();
            Array.prototype.forEach.call(form.elements, function (el) {
                if (!el.name || el.disabled) { return; }
                var tag = (el.tagName || '').toLowerCase();
                if (tag === 'select') {
                    body.append(el.name, el.value || '');
                } else if (el.type === 'checkbox' || el.type === 'radio') {
                    if (el.checked) { body.append(el.name, el.value || ''); }
                } else if (el.type !== 'file' && el.type !== 'button' && el.type !== 'submit') {
                    body.append(el.name, el.value || '');
                }
            });
            body.set('nahalBooking', '1');
            // شمارهٔ نرمال‌شده
            body.set('nahalPhone', phone);

            // نقطهٔ پایانی اختصاصی؛ در نبودش آدرس صفحهٔ جاری
            var endpoint = form.getAttribute('action') || window.location.href;
            if (!endpoint || endpoint === '#' || endpoint.charAt(0) === '#') {
                endpoint = window.location.href;
            }

            fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: body.toString(),
                credentials: 'same-origin',
                redirect: 'follow'
            })
                .then(function (res) {
                    // اگر پاسخ JSON نبود (مثلاً HTML)، متن را برای تشخیص خطا بخوان
                    var contentType = (res.headers.get('content-type') || '');
                    if (contentType.indexOf('application/json') !== -1) {
                        return res.json().then(function (data) { return data; });
                    }
                    return res.text().then(function () {
                        return { ok: false, error: 'پاسخ سرور قابل پردازش نبود؛ صفحه را رفرش کنید و دوباره تلاش کنید. (HTTP ' + res.status + ')' };
                    });
                })
                .then(function (data) {
                    if (data && data.ok) {
                        try { form.reset(); } catch (e) { }
                        if (successEl) { successEl.hidden = false; }
                        if (successEl) {
                            successEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                        }
                    } else {
                        var msg = (data && data.error && typeof data.error === 'string')
                            ? data.error
                            : 'ارسال درخواست ناموفق بود؛ لطفاً دوباره تلاش کنید.';
                        showMsg(errorEl, errorText, msg);
                    }
                })
                .catch(function () {
                    showMsg(errorEl, errorText, 'خطای ارتباط با سرور؛ اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.');
                })
                .finally(function () {
                    if (submitBtn) {
                        submitBtn.classList.remove('loading');
                        submitBtn.removeAttribute('disabled');
                    }
                });
        });
    }
    initBooking();

    /* ================================================================
     *  تجربیات مراجعین — کاروسل خودگردان تک‌کارت
     *  (هرچند کارت تعریف شده باشد، یک کارت در هر لحظه نمایش داده
     *   می‌شود و هر چند لحظه با افکت محو/لغزش تعویض می‌شود)
     * ================================================================ */
    function initTestimonials() {
        var wrap = document.getElementById('testimonialsCarousel');
        if (!wrap) { return; }

        var stage = wrap.querySelector('.t-stage');
        var cards = Array.prototype.slice.call(wrap.querySelectorAll('.testimonial-card'));
        var dotsWrap = wrap.querySelector('.t-dots');
        var prevBtn = wrap.querySelector('.t-prev');
        var nextBtn = wrap.querySelector('.t-next');
        if (!stage || cards.length === 0) { return; }

        var idx = 0;
        var timer = null;
        var INTERVAL = 6000;
        var single = cards.length < 2;
        var reducedMotion = false;
        try {
            reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        } catch (e) { }

        /* اندازه‌گیری بلندترین کارت و تنظیم ارتفاع صحنه
           تا هنگام تعویض، پرش ارتفاع رخ ندهد */
        var sizeStage = function () {
            var max = 0;
            cards.forEach(function (card) {
                max = Math.max(max, card.offsetHeight);
            });
            if (max > 0) { stage.style.height = max + 'px'; }
        };

        /* ساخت نقطه‌های ناوبری */
        var dots = [];
        if (dotsWrap && !single) {
            cards.forEach(function (card, i) {
                var dot = document.createElement('button');
                dot.type = 'button';
                dot.className = 't-dot' + (i === 0 ? ' is-active' : '');
                var name = (card.getAttribute('data-name') || ('تجربهٔ ' + faNum(i + 1)));
                dot.setAttribute('aria-label', 'نمایش ' + name);
                dot.addEventListener('click', function () { go(i, true); });
                dotsWrap.appendChild(dot);
                dots.push(dot);
            });
        }

        function go(n, byUser) {
            idx = ((n % cards.length) + cards.length) % cards.length;
            cards.forEach(function (card, i) {
                var active = i === idx;
                card.classList.toggle('is-active', active);
                card.setAttribute('aria-hidden', active ? 'false' : 'true');
            });
            dots.forEach(function (dot, i) {
                dot.classList.toggle('is-active', i === idx);
                dot.setAttribute('aria-current', i === idx ? 'true' : 'false');
            });
            if (byUser) { restart(); }
        }

        function next() { go(idx + 1); }
        function prev() { go(idx - 1); }

        function start() {
            if (single || reducedMotion || timer) { return; }
            timer = setInterval(next, INTERVAL);
        }
        function stop() {
            if (timer) { clearInterval(timer); timer = null; }
        }
        function restart() { stop(); start(); }

        /* توقف هنگام hovered/فوکوس */
        ['mouseenter', 'focusin'].forEach(function (ev) {
            wrap.addEventListener(ev, stop);
        });
        ['mouseleave', 'focusout'].forEach(function (ev) {
            wrap.addEventListener(ev, start);
        });

        /* کلیدهای جهت */
        wrap.setAttribute('tabindex', '0');
        wrap.addEventListener('keydown', function (e) {
            if (e.key === 'ArrowLeft') { e.preventDefault(); go(idx + 1, true); }   // در RTL چپ = بعدی
            else if (e.key === 'ArrowRight') { e.preventDefault(); go(idx - 1, true); }
        });

        /* کشیدن انگشت در موبایل */
        var touchX = null;
        stage.addEventListener('touchstart', function (e) {
            touchX = e.touches[0].clientX;
            stop();
        }, { passive: true });
        stage.addEventListener('touchend', function (e) {
            if (touchX === null) { return; }
            var dx = e.changedTouches[0].clientX - touchX;
            if (Math.abs(dx) > 45) {
                // در RTL کشیدن به چپ = رفتن به بعدی
                if (dx < 0) { go(idx + 1, true); } else { go(idx - 1, true); }
            }
            touchX = null;
            start();
        }, { passive: true });

        /* توقف هنگام خارج‌شدن از دید (صرفه‌جویی) */
        if ('IntersectionObserver' in window) {
            new IntersectionObserver(function (entries) {
                entries.forEach(function (en) {
                    if (en.isIntersecting) { start(); } else { stop(); }
                });
            }, { threshold: 0.25 }).observe(wrap);
        }

        document.addEventListener('visibilitychange', function () {
            if (document.hidden) { stop(); } else { start(); }
        });

        if (nextBtn) { nextBtn.addEventListener('click', function () { go(idx + 1, true); }); }
        if (prevBtn) { prevBtn.addEventListener('click', function () { go(idx - 1, true); }); }

        /* اندازه‌گیری اولیه + پس از بارگذاری فونت/تصاویر/تغییر اندازه */
        sizeStage();
        if (document.fonts && document.fonts.ready && document.fonts.ready.then) {
            document.fonts.ready.then(sizeStage);
        }
        window.addEventListener('load', sizeStage);
        var rsTimer = null;
        window.addEventListener('resize', function () {
            clearTimeout(rsTimer);
            rsTimer = setTimeout(sizeStage, 180);
        });

        start();
    }
    initTestimonials();

    /* ---------- دکمهٔ کپی کد ---------- */
    document.querySelectorAll('.post-content pre').forEach(function (pre) {
        var btn = pre.querySelector('.copy-code-btn');
        if (!btn) {
            btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'copy-code-btn';
            btn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg> کپی';
            pre.appendChild(btn);
        }
        btn.addEventListener('click', function () {
            var text = pre.querySelector('code') ? pre.querySelector('code').innerText : pre.innerText;
            var done = function () {
                btn.classList.add('copied');
                var old = btn.innerHTML;
                btn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 7 17l-5-5"/><path d="m22 10-7.5 7.5L13 16"/></svg> کپی شد';
                setTimeout(function () { btn.classList.remove('copied'); btn.innerHTML = old; }, 1600);
            };
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(done).catch(function () { });
            } else {
                var ta = document.createElement('textarea');
                ta.value = text;
                document.body.appendChild(ta);
                ta.select();
                try { document.execCommand('copy'); done(); } catch (e) { }
                document.body.removeChild(ta);
            }
        });
    });

    /* ---------- اسکرول نرم برای لینک‌های # ---------- */
    document.querySelectorAll('a[href^="#"]').forEach(function (link) {
        link.addEventListener('click', function (e) {
            var id = link.getAttribute('href');
            if (!id || id === '#' || id.length < 2) { return; }
            var target = document.querySelector(id);
            if (!target) { return; }
            e.preventDefault();
            closeMenu();
            var headerH = header ? header.offsetHeight : 0;
            var top = target.getBoundingClientRect().top + window.pageYOffset - headerH - 14;
            window.scrollTo({ top: top, behavior: 'smooth' });
        });
    });

    /* ---------- ورود با #hash از صفحهٔ دیگر ---------- */
    if (window.location.hash && window.location.hash.length > 1) {
        try {
            var hashTarget = document.querySelector(window.location.hash);
            if (hashTarget) {
                setTimeout(function () {
                    var headerH = header ? header.offsetHeight : 0;
                    var top = hashTarget.getBoundingClientRect().top + window.pageYOffset - headerH - 14;
                    window.scrollTo({ top: top, behavior: 'smooth' });
                }, 80);
            }
        } catch (e) { }
    }

})();
