<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$GLOBALS['nahalPostJs'] = true;

$this->need('header.php');

$nahalShowViews = nahal_opt('nahalShowViews', '1') === '1';
$nahalShowLikes = nahal_opt('nahalShowLikes', '1') === '1';
$nahalShowRelated = nahal_opt('nahalShowRelated', '1') === '1';
$nahalShowAuthorBox = nahal_opt('nahalShowAuthorBox', '1') === '1';
$nahalClinicName = nahal_opt('nahalClinicName', (string)$this->options->title);
$nahalPostCalories = nahal_calories($this);
$nahalPostCook = nahal_cook_time($this);
?>

<article class="post-wrap container" itemscope itemtype="https://schema.org/BlogPosting">

    <!-- ---------- سربرگ نوشته ---------- -->
    <header class="post-head">
        <nav class="post-breadcrumb" aria-label="مسیر">
            <a href="<?php $this->options->siteUrl(); ?>">خانه</a>
            <span class="crumb-sep">/</span>
            <a href="<?php echo htmlspecialchars(nahal_blog_url(), ENT_QUOTES); ?>">مقالات</a>
            <span class="crumb-sep">/</span>
            <span aria-current="page"><?php echo nahal_fa_title($this); ?></span>
        </nav>

        <h1 class="post-title" itemprop="name headline"><?php echo nahal_fa_title($this); ?></h1>

        <div class="post-meta">
            <span class="post-meta-item" itemprop="author" itemscope itemtype="https://schema.org/Person">
                <?php echo nahal_icon('user', 15); ?>
                <span itemprop="name"><?php $this->author(); ?></span>
            </span>
            <span class="post-meta-item">
                <?php echo nahal_icon('calendar', 15); ?>
                <time datetime="<?php $this->date('c'); ?>" itemprop="datePublished"><?php echo nahal_post_date($this, 'j F Y'); ?></time>
            </span>
            <span class="post-meta-item">
                <?php echo nahal_icon('folder', 15); ?>
                <?php $this->category(','); ?>
            </span>
            <?php if ($nahalPostCalories !== ''): ?>
            <span class="post-meta-item post-meta-badge">
                <?php echo nahal_icon('flame', 15); ?>
                <?php echo $nahalPostCalories; ?> کیلوکالری
            </span>
            <?php endif; ?>
            <?php if ($nahalPostCook !== ''): ?>
            <span class="post-meta-item post-meta-badge">
                <?php echo nahal_icon('clock', 15); ?>
                <?php echo $nahalPostCook; ?> دقیقه
            </span>
            <?php endif; ?>
            <?php if ($nahalShowViews): ?>
            <span class="post-meta-item post-views" id="postViews">
                <?php echo nahal_icon('eye', 15); ?>
                <?php echo nahal_num(nahal_views($this)); ?> بازدید
            </span>
            <?php endif; ?>
            <span class="post-meta-item">
                <?php echo nahal_icon('message-square', 15); ?>
                <a href="#comments"><?php ob_start(); $this->commentsNum('بدون دیدگاه', '۱ دیدگاه', '%d دیدگاه'); echo toPersianNumbers(ob_get_clean()); ?></a>
            </span>
        </div>
    </header>

    <!-- ---------- تصویر شاخص ---------- -->
    <?php $nahalCover = nahal_thumbnail($this, false); if ($nahalCover !== ''): ?>
    <figure class="post-cover">
        <img src="<?php echo htmlspecialchars($nahalCover, ENT_QUOTES); ?>" alt="<?php echo nahal_fa_title($this); ?>" itemprop="image">
    </figure>
    <?php endif; ?>

    <!-- ---------- محتوای نوشته ---------- -->
    <div class="post-content" itemprop="articleBody">
        <?php $this->content(); ?>
    </div>

    <!-- ---------- تگ‌ها ---------- -->
    <?php if ($this->tags): ?>
    <div class="post-tags">
        <?php echo nahal_icon('tag', 15); ?>
        <?php $this->tags(' ', true, ''); ?>
    </div>
    <?php endif; ?>

    <!-- ---------- لایک ---------- -->
    <?php if ($nahalShowLikes): ?>
    <?php
    $nahalLikes = nahal_likes($this);
    $nahalLiked = nahal_is_liked((int)$this->cid) ? '1' : '0';
    ?>
    <div class="post-like-row" id="nahalLikeFloat">
        <button type="button" class="like-btn<?php echo $nahalLiked === '1' ? ' is-liked' : ''; ?>" id="nahalLikeBtn"
                data-cid="<?php echo (int)$this->cid; ?>" data-likes="<?php echo $nahalLikes; ?>" data-liked="<?php echo $nahalLiked; ?>"
                aria-pressed="<?php echo $nahalLiked === '1' ? 'true' : 'false'; ?>">
            <?php echo nahal_icon('heart', 18); ?>
            <span class="like-label"><?php echo $nahalLiked === '1' ? 'پسندیدید' : 'این مطلب را پسندیدید؟'; ?></span>
            <span class="like-count"><?php echo nahal_num($nahalLikes); ?></span>
        </button>
    </div>
    <?php endif; ?>

    <!-- ---------- نویسنده ---------- -->
    <?php if ($nahalShowAuthorBox): ?>
    <aside class="author-box">
        <span class="author-avatar">
            <?php $this->author->gravatar(96); ?>
            <span class="author-avatar-fallback" aria-hidden="true"><?php echo htmlspecialchars(nahal_initial((string)$this->author->screenName), ENT_QUOTES); ?></span>
        </span>
        <div class="author-info">
            <strong class="author-name"><a href="<?php $this->author->permalink(); ?>" rel="author"><?php $this->author(); ?></a></strong>
            <span class="author-role">نویسنده در <?php echo htmlspecialchars($nahalClinicName, ENT_QUOTES); ?></span>
            <?php if (trim((string)$this->author->description) !== ''): ?>
            <p class="author-desc"><?php $this->author->description(); ?></p>
            <?php endif; ?>
        </div>
    </aside>
    <?php endif; ?>

    <!-- ---------- نوشته‌های مرتبط ---------- -->
    <?php
    $nahalRelated = $nahalShowRelated ? nahal_related_posts($this, 3) : [];
    if (!empty($nahalRelated)):
    ?>
    <section class="related-posts">
        <h2 class="related-title"><?php echo nahal_icon('file-text', 18); ?> نوشته‌های مرتبط</h2>
        <div class="related-grid">
            <?php foreach ($nahalRelated as $nahalRelatedPost): ?>
            <a href="<?php echo htmlspecialchars($nahalRelatedPost['url'], ENT_QUOTES); ?>" class="related-card">
                <span class="related-card-title"><?php echo toPersianNumbers(htmlspecialchars($nahalRelatedPost['title'], ENT_QUOTES)); ?></span>
                <span class="related-card-date"><?php echo nahal_post_date($nahalRelatedPost['created'], 'j F Y'); ?></span>
                <span class="related-card-more">خواندن <?php echo nahal_icon('arrow-left', 14); ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- ---------- نظرات ---------- -->
    <?php $this->need('comments.php'); ?>

</article>

<?php $this->need('footer.php'); ?>
