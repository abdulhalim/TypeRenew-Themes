<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
</main>

<!-- ---------- فوتر سایت ---------- -->
<footer class="site-footer">
    <?php
    // ---------- داده‌های فوتر ----------
    $nahalClinicName = nahal_opt('nahalClinicName', (string)$this->options->title);
    $nahalTagline    = nahal_opt('nahalTagline', 'تغذیهٔ سالم، زندگی سبز');
    $nahalLogoUrl    = nahal_logo_url();
    $nahalFooterText = nahal_opt('nahalFooterText', 'کلینیک تغذیهٔ نهال — علم روز تغذیه را با ذائقهٔ ایرانی ترکیب می‌کنیم تا سلامتی برای شما به یک عادت لذت‌بخش تبدیل شود.');
    $nahalPhone      = nahal_opt_raw('nahalContactPhone');
    $nahalPhone2     = nahal_opt_raw('nahalContactPhone2');
    $nahalEmail      = nahal_opt_raw('nahalContactEmail');
    $nahalAddress    = nahal_opt_raw('nahalContactAddress');
    $nahalHours      = (string)nahal_opt_raw('nahalContactHours');
    $nahalSocial = [
        'instagram' => nahal_opt_raw('nahalSocialInstagram'),
        'telegram'  => nahal_opt_raw('nahalSocialTelegram'),
        'whatsapp'  => nahal_opt_raw('nahalSocialWhatsapp'),
        'youtube'   => nahal_opt_raw('nahalSocialYoutube'),
    ];
    $nahalSocialNames = ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام', 'whatsapp' => 'واتس‌اپ', 'youtube' => 'یوتیوب'];
    ?>

    <!-- بخش اصلی فوتر -->
    <div class="container">
        <div class="footer-grid">

            <!-- ستون ۱: لوگو و معرفی -->
            <div class="footer-col footer-about">
                <div class="footer-logo">
                    <a href="<?php $this->options->siteUrl(); ?>" class="footer-logo-link">
                        <?php if ($nahalLogoUrl !== ''): ?>
                            <img src="<?php echo htmlspecialchars($nahalLogoUrl, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($nahalClinicName, ENT_QUOTES); ?>" class="footer-logo-img">
                        <?php else: ?>
                            <span class="footer-logo-mark" aria-hidden="true"><?php echo nahal_icon('leaf', 20); ?></span>
                        <?php endif; ?>
                        <span class="footer-logo-text"><?php echo htmlspecialchars($nahalClinicName, ENT_QUOTES); ?></span>
                    </a>
                </div>
                <p class="footer-desc"><?php echo htmlspecialchars($nahalFooterText, ENT_QUOTES); ?></p>
                <div class="footer-social">
                    <?php foreach ($nahalSocial as $nahalNet => $nahalUrl): if (trim((string)$nahalUrl) !== ''): ?>
                        <a href="<?php echo htmlspecialchars($nahalUrl, ENT_QUOTES); ?>" target="_blank" rel="noopener" aria-label="<?php echo $nahalSocialNames[$nahalNet]; ?>">
                            <?php echo nahal_icon($nahalNet === 'telegram' ? 'send' : ($nahalNet === 'whatsapp' ? 'message-circle' : $nahalNet), 17); ?>
                        </a>
                    <?php endif; endforeach; ?>
                </div>
            </div>

            <!-- ستون ۲: لینک‌های سریع -->
            <div class="footer-col">
                <h3 class="footer-title"><?php echo nahal_icon('zap', 17); ?> دسترسی سریع</h3>
                <ul class="footer-links">
                    <li><a href="<?php echo htmlspecialchars(nahal_link_url('#bmi', nahal_is_front()), ENT_QUOTES); ?>">محاسبهٔ BMI</a></li>
                    <li><a href="<?php echo htmlspecialchars(nahal_link_url('#services', nahal_is_front()), ENT_QUOTES); ?>">خدمات تغذیه</a></li>
                    <li><a href="<?php echo htmlspecialchars(nahal_link_url('#packages', nahal_is_front()), ENT_QUOTES); ?>">پکیج‌های رژیم</a></li>
                    <li><a href="<?php echo htmlspecialchars(nahal_link_url('#testimonials', nahal_is_front()), ENT_QUOTES); ?>">تجربیات مراجعین</a></li>
                    <li><a href="<?php echo htmlspecialchars(nahal_blog_url(), ENT_QUOTES); ?>">مقالات تخصصی</a></li>
                    <?php
                    $nahalFooterPages = \Widget\Contents\Page\Rows::allocWithAlias('nahalFooter');
                    $nahalFooterPageCount = 0;
                    while ($nahalFooterPages->next()):
                        if (nahal_is_reserve_cid((int)$nahalFooterPages->cid)) { continue; }
                        $nahalFooterPageCount++;
                        if ($nahalFooterPageCount > 4) { break; }
                    ?>
                        <li><a href="<?php $nahalFooterPages->permalink(); ?>"><?php echo nahal_fa_title($nahalFooterPages); ?></a></li>
                    <?php endwhile; ?>
                </ul>
            </div>

            <!-- ستون ۳: اطلاعات تماس -->
            <div class="footer-col footer-contact-col">
                <h3 class="footer-title"><?php echo nahal_icon('phone-call', 17); ?> تماس با ما</h3>
                <ul class="footer-contact">
                    <?php if ($nahalAddress !== null && trim($nahalAddress) !== ''): ?>
                    <li>
                        <?php echo nahal_icon('map-pin', 16); ?>
                        <span><?php echo htmlspecialchars($nahalAddress, ENT_QUOTES); ?></span>
                    </li>
                    <?php endif; ?>
                    <?php if ($nahalPhone !== null && trim($nahalPhone) !== ''): ?>
                    <li>
                        <?php echo nahal_icon('phone', 16); ?>
                        <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $nahalPhone), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($nahalPhone), ENT_QUOTES); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if ($nahalPhone2 !== null && trim($nahalPhone2) !== ''): ?>
                    <li>
                        <?php echo nahal_icon('message-circle', 16); ?>
                        <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $nahalPhone2), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($nahalPhone2), ENT_QUOTES); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if ($nahalEmail !== null && trim($nahalEmail) !== ''): ?>
                    <li>
                        <?php echo nahal_icon('mail', 16); ?>
                        <a href="mailto:<?php echo htmlspecialchars($nahalEmail, ENT_QUOTES); ?>"><?php echo htmlspecialchars($nahalEmail, ENT_QUOTES); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php foreach (array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $nahalHours))) as $nahalHour): ?>
                    <li>
                        <?php echo nahal_icon('clock', 16); ?>
                        <span><?php echo htmlspecialchars(toPersianNumbers($nahalHour), ENT_QUOTES); ?></span>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <!-- خط جداکننده و کپی‌رایت -->
    <div class="footer-bottom">
        <div class="container footer-bottom-inner">
            <div class="copyright">
                <span>© <?php echo nahal_jalali_year(); ?> <?php echo htmlspecialchars($nahalClinicName, ENT_QUOTES); ?> — تمامی حقوق محفوظ است.</span>
            </div>
            <div class="footer-powered">
                <span>قدرت گرفته از <a href="https://typerenew.com" target="_blank" rel="noopener">تایپ‌رینیو</a></span>
            </div>
        </div>
    </div>
</footer>

<!-- ---------- دکمهٔ بازگشت به بالا ---------- -->
<button type="button" class="back-to-top" id="backToTop" aria-label="بازگشت به بالا" title="بازگشت به بالا">
    <?php echo nahal_icon('arrow-up', 19); ?>
</button>

<!-- ---------- اسکریپت‌ها ---------- -->
<script src="<?php $this->options->themeUrl('js/main.js'); ?>?v=1.0.0"></script>
<?php if (isset($GLOBALS['nahalPostJs']) && $GLOBALS['nahalPostJs']): ?>
<!-- لایک — فقط صفحات نوشته -->
<script src="<?php $this->options->themeUrl('js/likes.js'); ?>?v=1.0.0"></script>
<?php endif; ?>

<?php $this->footer(); ?>
</body>
</html>
