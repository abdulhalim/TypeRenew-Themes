<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');
?>

<main id="main" class="wrap">

    <section class="empty-state lost-page">
        <p class="empty-rosette" aria-hidden="true"><?php echo elham_lucide('feather', 42); ?></p>
        <p class="lost-code"><?php _e('برگه پیدا نشد'); ?></p>
        <h1><?php _e('این برگه در دفتر نیست'); ?></h1>
        <p><?php _e('شاید پاره شده، شاید هرگز نوشته نشده؛ اما دفتر همان‌جاست و نوشته‌های دیگر در فهرست‌اند.'); ?></p>

        <form class="empty-search" method="post" action="<?php $this->options->siteUrl(); ?>" role="search">
            <input type="search" name="s" placeholder="<?php _e('دنبال چه چیزی بودی؟'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>">
            <button type="submit"><?php _e('جستجو'); ?></button>
        </form>

        <p class="empty-home"><a href="<?php $this->options->siteUrl(); ?>"><?php _e('بازگشت به خانهٔ دفتر'); ?></a></p>
    </section>

</main>

<?php $this->need('footer.php'); ?>
