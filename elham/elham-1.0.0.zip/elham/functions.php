<?php

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/** نسخهٔ پوسته */
const ELHAM_VERSION = '1.0.2';

/* ================================================================
 *  ۱) ابزارهای عمومی
 * ================================================================ */

/** نشانی یک دارایی داخل پوسته (بدون هیچ درخواست بیرونی) */
function elham_asset(string $path): string
{
    try {
        $base = rtrim((string) \Widget\Options::alloc()->themeUrl, '/');
    } catch (\Throwable $e) {
        $base = '';
    }
    return $base . '/' . ltrim($path, '/');
}

/** آیکون‌های Lucide (SVG درون‌خطی — سبک و بدون درخواست شبکه) */
function elham_lucide(string $name, int $size = 16, string $class = ''): string
{
    $icons = [
        // پرِ نویسندگی — نشان دفترِ الهام
        'feather' => '<path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z"/><line x1="16" y1="8" x2="2" y2="22"/><line x1="17.5" y1="15" x2="9" y2="15"/>',
        'book'    => '<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/>',
        'sparkles' => '<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.562l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/><path d="M20 3v4"/><path d="M22 5h-4"/><path d="M4 17v2"/><path d="M5 18H3"/>',
        'image'   => '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
        'menu'    => '<line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="18" x2="20" y2="18"/>',
        'x'       => '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    ];

    $body = $icons[$name] ?? $icons['feather'];
    $classAttr = $class !== '' ? ' class="' . htmlspecialchars($class, ENT_QUOTES, 'UTF-8') . '"' : '';

    return '<svg' . $classAttr . ' viewBox="0 0 24 24" width="' . $size . '" height="' . $size . '"'
        . ' fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"'
        . ' aria-hidden="true">' . $body . '</svg>';
}

/** خواندن تنظیم پوسته با مقدار پیش‌فرض */
function elham_opt(string $name, ?string $default = null): ?string
{
    try {
        $value = \Widget\Options::alloc()->{$name};
    } catch (\Throwable $e) {
        $value = null;
    }
    return ($value === null || $value === '') ? $default : $value;
}

/** آیا تنظیم روشن است؟ (مقدار ۱) */
function elham_on(string $name, string $default = '1'): bool
{
    return ((string) elham_opt($name, $default)) === '1';
}

/** تبدیل ارقام لاتین به فارسی */
function elham_fa(?string $text): string
{
    return strtr((string) $text, [
        '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
        '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
    ]);
}

/** عدد با جداکنندهٔ هزارگان فارسی: ۱۲۳۴ → ۱٬۲۳۴ */
function elham_num(int $num): string
{
    return elham_fa(str_replace(',', '٬', number_format(max(0, $num))));
}

/** خروجی JSON و پایان درخواست */
function elham_json(array $payload, int $status = 200): void
{
    try {
        $response = \Typecho\Response::getInstance();
        $response->setStatus($status);
        $response->setContentType('application/json');
        $response->addResponder(function () use ($payload): void {
            echo json_encode($payload, JSON_UNESCAPED_UNICODE);
        });
        $response->respond();
    } catch (\Throwable $e) {
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=UTF-8', true, $status);
        }
        echo json_encode($payload, JSON_UNESCAPED_UNICODE);
        exit;
    }
    exit;
}

/* ================================================================
 *  ۲) تاریخ شمسی
 * ================================================================ */

/** تبدیل میلادی به جلالی — الگوریتم استاندارد */
function elham_to_jalali(int $gy, int $gm, int $gd): array
{
    $gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

    $jy = ($gy <= 1600) ? 0 : 979;
    $gy -= ($gy <= 1600) ? 621 : 1600;

    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = (365 * $gy)
        + intdiv($gy2 + 3, 4)
        - intdiv($gy2 + 99, 100)
        + intdiv($gy2 + 399, 400)
        - 80
        + $gd
        + $gdm[$gm - 1];

    $jy += 33 * intdiv($days, 12053);
    $days %= 12053;
    $jy += 4 * intdiv($days, 1461);
    $days %= 1461;

    if ($days > 365) {
        $jy += intdiv($days - 1, 365);
        $days = ($days - 1) % 365;
    }

    if ($days < 186) {
        $jm = 1 + intdiv($days, 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + intdiv($days - 186, 30);
        $jd = 1 + (($days - 186) % 30);
    }

    return [$jy, $jm, $jd];
}

/** نام ماه‌های شمسی */
function elham_months(): array
{
    return [
        1  => 'فروردین', 2 => 'اردیبهشت', 3 => 'خرداد',
        4  => 'تیر', 5 => 'مرداد', 6 => 'شهریور',
        7  => 'مهر', 8 => 'آبان', 9 => 'آذر',
        10 => 'دی', 11 => 'بهمن', 12 => 'اسفند',
    ];
}

/** نام روز هفته */
function elham_weekday(int $ts): string
{
    $days = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
    return $days[(int) date('w', $ts)];
}

/** تاریخ بلند شمسی: ۱۱ شهریور ۱۴۰۵ */
function elham_date(int $ts): string
{
    [$jy, $jm, $jd] = elham_to_jalali((int) date('Y', $ts), (int) date('n', $ts), (int) date('j', $ts));
    $months = elham_months();
    return elham_fa((string) $jd) . ' ' . $months[$jm] . ' ' . elham_fa((string) $jy);
}

/** تاریخ کامل شمسی: پنجشنبه، ۱۱ شهریور ۱۴۰۵ */
function elham_date_full(int $ts): string
{
    return elham_weekday($ts) . '، ' . elham_date($ts);
}

/** سال جاری شمسی (برای پاورقی) */
function elham_year(int $ts = 0): string
{
    $ts = $ts > 0 ? $ts : (int) \Widget\Options::alloc()->time;
    [$jy] = elham_to_jalali((int) date('Y', $ts), (int) date('n', $ts), (int) date('j', $ts));
    return elham_fa((string) $jy);
}

/** تبدیل ارقام لینک‌های صفحه‌بندی به فارسی */
function elham_nav_fa(string $html): string
{
    return (string) preg_replace_callback(
        '/>([^<>]+)</u',
        function (array $m): string {
            return '>' . elham_fa($m[1]) . '<';
        },
        $html
    );
}

/* ================================================================
 *  ۳) آمار: ستون‌های views و likes جدول محتوا
 *     (هم‌راستا با نیلوفر/زیبا — شمارش‌ها هنگام جابه‌جایی پوسته می‌مانند)
 * ================================================================ */

/** اطمینان از وجود ستون‌های views و likes */
function elham_stats_ready(): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }

    $ready = false;
    try {
        $db = \Typecho\Db::get();
        $prefix = $db->getPrefix();

        $columns = [];
        try {
            $rows = $db->fetchAll("SHOW COLUMNS FROM `{$prefix}contents`");
            foreach ($rows as $row) {
                $columns[] = is_array($row) ? (string) reset($row) : (string) $row->Field;
            }
        } catch (\Throwable $e) {
            $columns = [];
        }

        // SQLite یا فایل‌های information_schema ناموجود — با پروب ستون‌ها
        if (empty($columns)) {
            foreach (['views', 'likes'] as $col) {
                try {
                    $db->fetchRow($db->select("table.contents.{$col}")->from('table.contents')->limit(1));
                } catch (\Throwable $e) {
                    $db->query("ALTER TABLE `{$prefix}contents` ADD `{$col}` INT DEFAULT 0");
                }
            }
        } else {
            foreach (['views', 'likes'] as $col) {
                if (!in_array($col, $columns, true)) {
                    $db->query("ALTER TABLE `{$prefix}contents` ADD `{$col}` INT DEFAULT 0");
                }
            }
        }

        $ready = true;
    } catch (\Throwable $e) {
        $ready = false;
    }

    return $ready;
}

/** تعداد بازدید (خوانش مستقیم با کش درخواست) */
function elham_views($archive): int
{
    static $cache = [];
    $cid = is_object($archive) ? (int) $archive->cid : (int) $archive;
    if ($cid < 1) {
        return 0;
    }
    if (!isset($cache[$cid])) {
        $cache[$cid] = 0;
        if (elham_stats_ready()) {
            try {
                $db = \Typecho\Db::get();
                $row = $db->fetchRow(
                    $db->select('table.contents.views')->from('table.contents')->where('table.contents.cid = ?', $cid)
                );
                $cache[$cid] = $row ? max(0, (int) $row['views']) : 0;
            } catch (\Throwable $e) {
            }
        }
    }
    return $cache[$cid];
}

/** تعداد الهام (پسند) نوشته */
function elham_likes($archive): int
{
    static $cache = [];
    $cid = is_object($archive) ? (int) $archive->cid : (int) $archive;
    if ($cid < 1) {
        return 0;
    }
    if (!isset($cache[$cid])) {
        $cache[$cid] = 0;
        if (elham_stats_ready()) {
            try {
                $db = \Typecho\Db::get();
                $row = $db->fetchRow(
                    $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
                );
                $cache[$cid] = $row ? max(0, (int) $row['likes']) : 0;
            } catch (\Throwable $e) {
            }
        }
    }
    return $cache[$cid];
}

/* ================================================================
 *  ۴) شمارش بازدید
 * ================================================================ */

/** شمارش بازدید صفحات تکی با کوکی ضد تکرار */
function elham_count_view($archive): void
{
    // اگر پلاگین ViewsCounter فعال است، پوسته کنار می‌کشد
    try {
        $activated = \Widget\Options::alloc()->plugins;
        if (is_array($activated) && isset($activated['activated']['ViewsCounter'])) {
            return;
        }
    } catch (\Throwable $e) {
    }

    if (!elham_on('elhamCountViews', '1') && \Widget\User::alloc()->hasLogin()) {
        return;
    }

    if (!$archive instanceof \Widget\Archive || !$archive->is('single')) {
        return;
    }

    $cid = (int) $archive->cid;
    if ($cid < 1 || !elham_stats_ready()) {
        return;
    }

    // بازدید تکراری همین بازدیدکننده تا ۶ ساعت شمرده نمی‌شود
    try {
        $viewed = (string) \Typecho\Cookie::get('elhamViews', '');
        if ($viewed !== '') {
            $ids = explode(',', $viewed);
            if (in_array((string) $cid, $ids, true)) {
                return;
            }
            $ids[] = (string) $cid;
            if (count($ids) > 100) {
                $ids = array_slice($ids, -100);
            }
            \Typecho\Cookie::set('elhamViews', implode(',', $ids), time() + 21600);
        } else {
            \Typecho\Cookie::set('elhamViews', (string) $cid, time() + 21600);
        }
    } catch (\Throwable $e) {
    }

    try {
        $db = \Typecho\Db::get();
        $db->query(
            $db->update('table.contents')
                ->expression('views', 'views + 1')
                ->where('table.contents.cid = ?', $cid)
        );
    } catch (\Throwable $e) {
        // خطای شمارش نباید نمایش صفحه را متوقف کند
    }
}

/* ================================================================
 *  ۵) الهام (لایک) — ستون likes + نقطهٔ پایانی AJAX
 * ================================================================ */

/** شناسه‌های الهام‌شدهٔ این بازدیدکننده (کوکی elhamLikes) */
function elham_user_likes(): array
{
    $raw = (string) \Typecho\Cookie::get('elhamLikes', '');
    if ($raw === '') {
        return [];
    }
    $ids = [];
    foreach (explode(',', $raw) as $id) {
        $id = trim($id);
        if ($id !== '' && ctype_digit($id) && !in_array($id, $ids, true)) {
            $ids[] = $id;
        }
    }
    return $ids;
}

/** آیا این بازدیدکننده این نوشته را الهام‌بخش یافته؟ */
function elham_is_liked(int $cid): bool
{
    return $cid > 0 && in_array((string) $cid, elham_user_likes(), true);
}

/** پردازش درخواست الهام — POST با پارامتر elhamLike=<cid> */
function elham_handle_like($request): void
{
    $cid = (int) (string) $request->get('elhamLike');

    if ($cid < 1) {
        elham_json(['ok' => false, 'error' => 'bad-request'], 400);
        return;
    }

    // جلوگیری ساده از CSRF
    $siteHost = (string) parse_url((string) \Widget\Options::alloc()->siteUrl, PHP_URL_HOST);
    $referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');
    if ($referer !== '' && $siteHost !== '' && stripos($referer, $siteHost) === false) {
        elham_json(['ok' => false, 'error' => 'cross-origin'], 403);
        return;
    }

    if (!elham_stats_ready()) {
        elham_json(['ok' => false, 'error' => 'db-error'], 500);
        return;
    }

    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.type', 'table.contents.status', 'table.contents.password', 'table.contents.created')
                ->from('table.contents')
                ->where('table.contents.cid = ?', $cid)
        );

        $valid = is_array($row)
            && $row['status'] === 'publish'
            && in_array($row['type'], ['post', 'page'], true)
            && empty($row['password'])
            && (int) $row['created'] <= \Widget\Options::alloc()->time;

        if (!$valid) {
            elham_json(['ok' => false, 'error' => 'not-found'], 404);
            return;
        }

        $likedIds = elham_user_likes();
        $wasLiked = in_array((string) $cid, $likedIds, true);

        if ($wasLiked) {
            $likedIds = array_values(array_filter(
                $likedIds,
                static function (string $id) use ($cid): bool {
                    return $id !== (string) $cid;
                }
            ));
            $delta = -1;
        } else {
            $likedIds[] = (string) $cid;
            $delta = 1;
        }

        if (count($likedIds) > 200) {
            $likedIds = array_slice($likedIds, -200);
        }
        \Typecho\Cookie::set('elhamLikes', implode(',', $likedIds), time() + 31536000);

        $current = (int) $db->fetchObject(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        )->likes;

        if ($delta > 0 || $current > 0) {
            $db->query(
                $db->update('table.contents')
                    ->expression('likes', $delta > 0 ? 'likes + 1' : 'likes - 1')
                    ->where('table.contents.cid = ?', $cid)
            );
        }

        $newLikes = (int) $db->fetchObject(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        )->likes;

        elham_json([
            'ok'    => true,
            'likes' => $newLikes,
            'liked' => !$wasLiked,
        ]);
    } catch (\Throwable $e) {
        elham_json(['ok' => false, 'error' => 'server-error'], 500);
    }
}

/* ================================================================
 *  ۶) متن، تصویر و زمان مطالعه
 * ================================================================ */

/** خلاصهٔ نوشته با محدودیت واژه (بدون HTML) */
function elham_excerpt($archive, int $words = 26): string
{
    $text = '';
    try {
        $text = trim((string) $archive->excerpt);
        if ($text === '') {
            $text = trim((string) $archive->plainExcerpt);
        }
    } catch (\Throwable $e) {
        $text = '';
    }
    $text = trim((string) preg_replace('/\s+/u', ' ', strip_tags($text)));
    $parts = preg_split('/\s+/u', $text, $words + 1, PREG_SPLIT_NO_EMPTY);
    if (is_array($parts) && count($parts) > $words) {
        array_pop($parts);
        return implode(' ', $parts) . '…';
    }
    return $text;
}

/** اعتبار نشانی تصویر */
function elham_image_ok(?string $url): bool
{
    $url = trim((string) $url);
    if ($url === '' || strlen($url) > 2048) {
        return false;
    }
    return (bool) preg_match('#^(https?://|/|data:image/)#i', $url);
}

/** تصویر شاخص: فیلد thumb → نخستین تصویر متن */
function elham_thumb($archive): string
{
    $url = '';
    try {
        $url = trim((string) $archive->fields->thumb);
    } catch (\Throwable $e) {
        $url = '';
    }
    if (!elham_image_ok($url)) {
        $url = '';
        try {
            $content = (string) $archive->content;
            if (preg_match('/<img[^>]+src=["\']([^"\']+)["\']/iu', $content, $m)) {
                if (elham_image_ok($m[1])) {
                    $url = $m[1];
                }
            }
        } catch (\Throwable $e) {
        }
    }
    return $url;
}

/** زمان مطالعه (دقیقه) — حدود ۱۸۰ واژه در دقیقه */
function elham_reading_time($archive): int
{
    try {
        $text = strip_tags((string) $archive->content);
        $count = count(preg_split('/\s+/u', trim($text), -1, PREG_SPLIT_NO_EMPTY) ?: []);
    } catch (\Throwable $e) {
        $count = 0;
    }
    return max(1, (int) ceil($count / 180));
}

/** تعداد نوشته‌های منتشرشدهٔ دفتر */
function elham_total_posts(): int
{
    static $total = null;
    if ($total !== null) {
        return $total;
    }
    $total = 0;
    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchObject(
            $db->select(['COUNT(table.contents.cid)' => 'num'])
                ->from('table.contents')
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.status = ?', 'publish')
        );
        $total = $row ? (int) $row->num : 0;
    } catch (\Throwable $e) {
    }
    return $total;
}

/* ================================================================
 *  ۷) پرالهام‌ترین‌ها — ویجت پاورقی
 * ================================================================ */

if (class_exists('\\Widget\\Base\\Contents')) {
    /**
     * فهرست پرالهام‌ترین نوشته‌ها (مرتب بر پایهٔ likes سپس views)
     */
    class ElhamPopular extends \Widget\Base\Contents
    {
        public function execute()
        {
            $limit = 5;
            try {
                $limit = max(3, min(8, (int) elham_opt('elhamPopularCount', '5')));
            } catch (\Throwable $e) {
            }

            if (!elham_stats_ready()) {
                return;
            }

            try {
                $select = $this->select('table.contents.*')
                    ->where('table.contents.type = ?', 'post')
                    ->where('table.contents.status = ?', 'publish')
                    ->where('table.contents.password IS NULL')
                    ->where('table.contents.created < ?', \Widget\Options::alloc()->time)
                    ->order('table.contents.likes', \Typecho\Db::SORT_DESC)
                    ->order('table.contents.views', \Typecho\Db::SORT_DESC)
                    ->limit($limit);

                // فقط نوشته‌هایی که آماری دارند
                $select->where('(table.contents.likes > 0 OR table.contents.views > 0)');

                \Typecho\Db::get()->fetchAll($select, [$this, 'push']);
            } catch (\Throwable $e) {
            }
        }
    }
}

/** فراخوانی ویجت پرالهام‌ترین‌ها (با نام مستعار جدا برای هر جای صفحه) */
function elham_popular(string $alias = 'elham-footer')
{
    try {
        return \Typecho\Widget::widget('ElhamPopular@' . $alias);
    } catch (\Throwable $e) {
        if (defined('ELHAM_SIM_DEBUG')) {
            fwrite(STDERR, 'POPULAR-ERR: ' . $e->getMessage() . ' @' . $e->getFile() . ':' . $e->getLine() . "\n");
        }
        return null;
    }
}

/* ================================================================
 *  ۸) راه‌انداز پوسته
 * ================================================================ */

function themeInit(\Widget\Archive $archive)
{
    \Typecho\Plugin::factory('Widget\Archive')->beforeRender = 'elham_count_view';

    if ($archive->request->isPost() && $archive->request->is('elhamLike')) {
        elham_handle_like($archive->request);
    }
}

/* ================================================================
 *  ۹) تنظیمات پوسته
 * ================================================================ */

function themeConfig($form)
{
    $yes = _t('روشن');
    $no = _t('خاموش');

    /* ---------- دفتر ---------- */

    $tagline = new \Typecho\Widget\Helper\Form\Element\Text(
        'elhamTagline',
        null,
        null,
        _t('توضیح کوتاه دفتر'),
        _t('زیر نام سایت در صفحهٔ اول نمایش داده می‌شود؛ مثلاً: «دفتری برای نوشته‌های کوتاه و بلند». در صورت خالی‌بودن، توضیح سایت استفاده می‌شود.')
    );
    $form->addInput($tagline);

    $intro = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'elhamIntro',
        null,
        null,
        _t('معرّفی صفحهٔ اول'),
        _t('یک بند کوتاه که بالای فهرست نوشته‌ها می‌نشیند. اگر خالی بماند، این متن نمایش داده می‌شود: «اینجا گوشه‌ای است برای نوشتن؛ هر چه که الهام می‌آورد، بی‌واسطه و بی‌حاشیه.»')
    );
    $form->addInput($intro);

    $introTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'elhamIntroTitle',
        null,
        null,
        _t('عنوان بزرگ صفحهٔ اول'),
        _t('سرتیترِ بالای فهرست نوشته‌ها. اگر خالی بماند، نام سایت نمایش داده می‌شود.')
    );
    $form->addInput($introTitle);

    $pattern = new \Typecho\Widget\Helper\Form\Element\Select(
        'elhamPattern',
        [
            'dots' => _t('نقطه‌ای (پیشنهادی)'),
            'grid' => _t('شبکه‌ای (گرید)'),
            'diag' => _t('خطوط مورب'),
            'none' => _t('ساده — بدون پترن'),
        ],
        'dots',
        _t('پترن پس‌زمینهٔ بالای صفحه'),
        _t('یک بافت لطیف کاغذی در بالای صفحه که به‌مرور محو می‌شود؛ رنگ آن با حالت روشن/تاریک هماهنگ است.')
    );
    $form->addInput($pattern);

    $logoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'elhamLogoUrl',
        null,
        null,
        _t('نشانی لوگو (اختیاری)'),
        _t('اگر پر شود، این تصویر جای نشان و نام سایت در سربرگ را می‌گیرد. ارتفاع پیشنهادی: حدود ۸۰ پیکسل با پس‌زمینهٔ شفاف.')
    );
    $form->addInput($logoUrl->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $faviconUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'elhamFaviconUrl',
        null,
        null,
        _t('نشانی فاوآیکون (اختیاری)'),
        _t('اگر پر شود، همان آیکون مرورگر می‌شود؛ در غیر این صورت نشانِ پرِ پوسته (SVG داخلی) استفاده می‌شود.')
    );
    $form->addInput($faviconUrl->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $accent = new \Typecho\Widget\Helper\Form\Element\Select(
        'elhamAccent',
        [
            'saffron'      => _t('زعفرانی (پیشنهادی)'),
            'turquoise'    => _t('فیروزه‌ای'),
            'pomegranate'  => _t('اناری'),
            'rose'         => _t('گل‌بهی'),
        ],
        'saffron',
        _t('رنگ تأکید دفتر'),
        _t('رنگ نشان‌ها، نقطه‌چین‌ها، پیوندها و ستارهٔ الهام.')
    );
    $form->addInput($accent);

    /* ---------- درباره ---------- */

    $aboutRole = new \Typecho\Widget\Helper\Form\Element\Text(
        'elhamAboutRole',
        null,
        null,
        _t('دربارهٔ نویسنده — معرفی یک‌خطی'),
        _t('زیر نام در صفحهٔ «درباره» می‌نشیند؛ مثلاً: «نویسنده، عکاس و شاهدِ روزهای ساده». فقط با قالب سفارشی «دربارهٔ نویسنده» نمایش داده می‌شود.')
    );
    $form->addInput($aboutRole);

    $aboutPhoto = new \Typecho\Widget\Helper\Form\Element\Text(
        'elhamAboutPhoto',
        null,
        null,
        _t('دربارهٔ نویسنده — تصویر پرتره'),
        _t('نشانی عکس نویسنده برای صفحهٔ «درباره»؛ دایره‌ای نمایش داده می‌شود. اگر خالی بماند، نشان پر جای آن می‌نشیند.')
    );
    $form->addInput($aboutPhoto);

    $aboutInterests = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'elhamAboutInterests',
        null,
        null,
        _t('دربارهٔ نویسنده — علایق'),
        _t('هر خط یک علاقه؛ به‌صورت نشان‌های کوچک در صفحهٔ «درباره» نمایش داده می‌شوند.')
    );
    $form->addInput($aboutInterests);

    $aboutWorks = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'elhamAboutWorks',
        null,
        null,
        _t('دربارهٔ نویسنده — کارها'),
        _t('هر خط یک کار به شکل «عنوان | توضیح | نشانی». توضیح زیر عنوان می‌نشیند و نشانی، عنوان را پیوند می‌کند؛ هر دو اختیاری‌اند. نشانی می‌تواند با https شروع شود یا www یا فقط دامنه باشد. نمونه: «تکنولوژی | شغل اول من دربارهٔ کامپیوتر است» یا «وب‌گاه من | نمونه‌کارها | www.example.com». اگر خالی بماند بخش «کارها» هیچ چیزی نمایش نمی‌دهد.')
    );
    $form->addInput($aboutWorks);

    $aboutPhotos = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'elhamAboutPhotos',
        null,
        null,
        _t('دربارهٔ نویسنده — گالری تصویرها'),
        _t('نشانی چند تصویر از نویسنده؛ هر خط یک نشانی. با کلیک، تصویر بزرگ می‌شود.')
    );
    $form->addInput($aboutPhotos);

    /* ---------- آمار ---------- */

    $showViews = new \Typecho\Widget\Helper\Form\Element\Radio(
        'elhamShowViews',
        ['1' => $yes, '0' => $no],
        '1',
        _t('نمایش شمار بازدید'),
        _t('شمار بازدید در فهرست و صفحهٔ نوشته نمایش داده می‌شود.')
    );
    $form->addInput($showViews);

    $showLikes = new \Typecho\Widget\Helper\Form\Element\Radio(
        'elhamShowLikes',
        ['1' => $yes, '0' => $no],
        '1',
        _t('دکمهٔ الهام (پسند)'),
        _t('خوانندگان می‌توانند با ستاره‌زدن نوشته را الهام‌بخش بدانند؛ شمارش در همان جدول نوشته‌ها نگه داشته می‌شود.')
    );
    $form->addInput($showLikes);

    $countViews = new \Typecho\Widget\Helper\Form\Element\Radio(
        'elhamCountViews',
        ['1' => $yes, '0' => $no],
        '0',
        _t('شمارش بازدید مدیر'),
        _t('اگر روشن باشد، بازدید کاربران واردشده هم شمرده می‌شود.')
    );
    $form->addInput($countViews);

    /* ---------- پاورقی ---------- */

    $showPopular = new \Typecho\Widget\Helper\Form\Element\Radio(
        'elhamShowPopular',
        ['1' => $yes, '0' => $no],
        '1',
        _t('پرالهام‌ترین‌ها در پاورقی'),
        _t('پنج نوشتهٔ پرستاره و پربازدید در پاورقی فهرست می‌شوند.')
    );
    $form->addInput($showPopular);

    $footerText = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'elhamFooterText',
        null,
        null,
        _t('یادداشت پاورقی'),
        _t('چند خط دربارهٔ شما یا این دفتر که در پاورقی می‌نشیند.')
    );
    $form->addInput($footerText);
}

/* ================================================================
 *  ۱۰) فیلدهای سفارشی
 * ================================================================ */
function themeFields($layout)
{
    $thumb = new \Typecho\Widget\Helper\Form\Element\Text(
        'thumb',
        null,
        null,
        _t('تصویر شاخص'),
        _t('نشانی تصویر شاخص این نوشته؛ در صفحهٔ نوشته بالای متن می‌نشیند. اگر خالی بماند، نخستین تصویر متن استفاده می‌شود.')
    );
    $layout->addItem($thumb);
}

/* ================================================================
 *  ۱۱) صفحهٔ «دربارهٔ نویسنده» — تجزیهٔ تنظیمات
 * ================================================================ */

/** فهرست خطوط یک تنظیم متنی (بدون خالی و تکراری) */
function elham_about_lines(string $setting): array
{
    $out = [];
    foreach (preg_split('/\r\n|\n|\r/u', trim((string) elham_opt($setting, ''))) ?: [] as $line) {
        $line = trim($line);
        if ($line !== '' && !in_array($line, $out, true)) {
            $out[] = $line;
        }
    }
    return $out;
}

/** علایق نویسنده — خط یا ویرگول‌جداشده */
function elham_about_interests(): array
{
    $raw = trim((string) elham_opt('elhamAboutInterests', ''));
    if ($raw === '') {
        return [];
    }
    $parts = preg_split('/\r\n|\n|\r|،|,/u', $raw) ?: [];
    $out = [];
    foreach ($parts as $part) {
        $part = trim($part);
        if ($part !== '' && !in_array($part, $out, true)) {
            $out[] = $part;
        }
    }
    return $out;
}

/** آیا این رشته شبیه نشانی وب است؟ (برای تشخیص ترتیبِ وارونه و نرمال‌سازی) */
function elham_url_like(string $value): bool
{
    $value = trim($value);
    if ($value === '' || preg_match('/\s/u', $value)) {
        return false;
    }
    return (bool) preg_match('~^(https?://|/|#|mailto:|tel:|www\.)~i', $value)
        || (bool) preg_match('~^[^/\s]+\.[^/\s]{2,}(/.*)?$~iu', $value); /* site.com/x */
}

/** نرمال‌سازی نشانی: نشانی بی‌پروتکل → https:// */
function elham_url_fix(string $url): string
{
    $url = trim($url);
    if ($url === '' || preg_match('~^(https?://|/|#|mailto:|tel:)~i', $url)) {
        return $url;
    }
    if (elham_url_like($url)) {
        return 'https://' . ltrim($url, '/');
    }
    return '';
}

/** کارهای نویسنده — هر خط: «عنوان | توضیح | نشانی» (توضیح و نشانی اختیاری؛ تجزیه‌گر بخشنده) */
function elham_about_works(): array
{
    $out = [];
    foreach (elham_about_lines('elhamAboutWorks') as $line) {
        /* جداساز: | یا ¦ یا ｜ یا ： */
        $parts = preg_split('/\s*[|¦｜：]\s*/u', $line) ?: [];
        $parts = array_values(array_filter(
            array_map('trim', $parts),
            static function ($p) {
                return $p !== '';
            }
        ));
        if (!$parts) {
            continue;
        }

        $title = '';
        $desc = '';
        $url = '';

        if (count($parts) === 1) {
            /* خطِ تک‌نشانی: نشانی هم عنوان می‌شود (بدون پروتکل و www) */
            if (elham_url_like($parts[0])) {
                $url = $parts[0];
                $title = (string) preg_replace('#^(https?://)?(www\.)?#i', '', $url);
            } else {
                $title = $parts[0];
            }
        } else {
            $title = array_shift($parts);

            /* اگر کاربر نشانی را اول نوشت (نشانی | عنوان …)، جای دو سو جابه‌جا می‌شود */
            if ($title !== '' && elham_url_like($title)) {
                foreach ($parts as $i => $p) {
                    if (!elham_url_like($p)) {
                        $url = $title;
                        $title = $p;
                        unset($parts[$i]);
                        $parts = array_values($parts);
                        break;
                    }
                }
            }

            /* نخستین بخشِ نشانی‌مانند → نشانی؛ نخستین بخشِ دیگر → توضیح */
            foreach ($parts as $p) {
                if ($url === '' && elham_url_like($p)) {
                    $url = $p;
                } elseif ($desc === '') {
                    $desc = $p;
                }
            }
        }

        $url = elham_url_fix($url);
        if ($title === '' && $url !== '') {
            $title = (string) preg_replace('#^(https?://)?(www\.)?#i', '', $url) ?: $url;
        }
        if ($title === '') {
            continue;
        }
        $out[] = ['title' => $title, 'desc' => $desc, 'url' => $url];
    }
    return $out;
}

/* ================================================================
 *  ۱۲) ساختار دیدگاه‌ها — آواتار پیش‌فرض محلی پوسته
 * ================================================================ */

function threadedComments($comments, $options)
{
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }

    $author = trim((string) $comments->author);
    $avatarAlt = $author !== '' ? $author : 'بازدیدکنندهٔ دفتر';
    $avatarUrl = elham_asset('assets/img/avatar.webp');
    ?>
    <li id="<?php $comments->theId(); ?>" class="comment-item<?php
        if ($comments->levels > 0) {
            echo ' comment-child';
            $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
        } else {
            echo ' comment-parent';
        }
        $comments->alt(' comment-odd', ' comment-even');
        echo $commentClass;
    ?>">
        <div class="comment-card">
            <img class="comment-avatar" src="<?php echo htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($avatarAlt, ENT_QUOTES, 'UTF-8'); ?>" width="80" height="80" loading="lazy" decoding="async">
            <div class="comment-main">
                <div class="comment-head">
                    <cite class="comment-author"><?php $comments->author(); ?></cite>
                    <?php if ($comments->authorId && $comments->authorId == $comments->ownerId): ?>
                        <span class="comment-owner-badge">نویسندهٔ دفتر</span>
                    <?php endif; ?>
                    <span class="comment-time"><?php echo elham_date((int) $comments->created); ?></span>
                </div>
                <div class="comment-text">
                    <?php $comments->content(); ?>
                </div>
                <span class="comment-reply"><?php $comments->reply('پاسخ'); ?></span>
            </div>
        </div>
        <?php if ($comments->children): ?>
            <div class="comment-children"><?php $comments->children(); ?></div>
        <?php endif; ?>
    </li>
    <?php
}
