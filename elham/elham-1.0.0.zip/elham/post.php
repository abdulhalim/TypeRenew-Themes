<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$elhamCid = (int) $this->cid;
$elhamViews = elham_on('elhamShowViews') ? elham_views($elhamCid) : 0;
$elhamLikes = elham_on('elhamShowLikes') ? elham_likes($elhamCid) : 0;
$elhamLiked = elham_is_liked($elhamCid);
$elhamThumb = elham_thumb($this);
$elhamRt = elham_reading_time($this);
$elhamCats = [];
try {
    $elhamCats = is_array($this->categories) ? $this->categories : [];
} catch (\Throwable $e) {
}
?>

<main id="main" class="wrap">

    <article class="post" itemscope itemtype="https://schema.org/BlogPosting">

        <header class="post-head">
            <p class="post-eyebrow">
                <span class="rosette" aria-hidden="true"><?php echo elham_lucide('feather', 14); ?></span>
                <time datetime="<?php echo date('c', (int) $this->created); ?>"><?php echo elham_date_full((int) $this->created); ?></time>
            </p>
            <h1 class="post-title" itemprop="headline"><?php $this->title(); ?></h1>
            <p class="post-meta">
                <span itemprop="author"><?php $this->author(); ?></span>
                <span class="dot" aria-hidden="true">·</span>
                <span><?php echo elham_fa((string) $elhamRt); ?> <?php _e('دقیقه خواندن'); ?></span>
                <?php if ($elhamViews > 0 || elham_on('elhamShowViews')): ?>
                    <span class="dot" aria-hidden="true">·</span>
                    <span><?php echo elham_num($elhamViews); ?> <?php _e('بازدید'); ?></span>
                <?php endif; ?>
                <?php if (!empty($elhamCats)): ?>
                    <span class="dot" aria-hidden="true">·</span>
                    <span class="post-cats"><?php $this->category('، '); ?></span>
                <?php endif; ?>
            </p>
        </header>

        <?php if ($elhamThumb !== ''): ?>
        <figure class="post-thumb">
            <img src="<?php echo htmlspecialchars($elhamThumb, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->title(); ?>" itemprop="image" loading="eager" decoding="async">
        </figure>
        <?php endif; ?>

        <div class="post-body" itemprop="articleBody">
            <?php $this->content(); ?>
        </div>

        <?php if ($this->tags): ?>
        <footer class="post-tags">
            <span class="tags-label"><?php _e('برچسب‌ها'); ?></span>
            <?php $this->tags('', true, ''); ?>
        </footer>
        <?php endif; ?>

        <?php if (elham_on('elhamShowLikes')): ?>
        <section class="like-box" aria-label="<?php _e('پسندیدن نوشته'); ?>">
            <p class="like-title"><?php _e('این نوشته برایت الهام‌بخش بود؟'); ?></p>
            <button type="button"
                    class="like-btn<?php echo $elhamLiked ? ' is-liked' : ''; ?>"
                    id="elham-like-btn"
                    data-cid="<?php echo $elhamCid; ?>"
                    data-likes="<?php echo $elhamLikes; ?>"
                    data-liked="<?php echo $elhamLiked ? '1' : '0'; ?>"
                    aria-pressed="<?php echo $elhamLiked ? 'true' : 'false'; ?>">
                <svg class="spark" viewBox="0 0 24 24" width="22" height="22" fill="currentColor" stroke="none" aria-hidden="true"><path d="M12 2l2.2 6.1L20.5 10l-6.3 1.9L12 18l-2.2-6.1L3.5 10l6.3-1.9L12 2z"/><path d="M19 15l.9 2.4 2.1.6-2.1.6-.9 2.4-.9-2.4-2.1-.6 2.1-.6.9-2.4z" opacity=".7"/></svg>
                <span class="like-count"><?php echo elham_num($elhamLikes); ?></span>
                <span class="like-label"><?php echo $elhamLiked ? _t('الهام‌بخش بود') : _t('ستاره بزن'); ?></span>
            </button>
            <p class="like-hint" id="elham-like-hint">
                <?php echo $elhamLikes > 0
                    ? elham_num($elhamLikes) . ' ' . _t('نفر این نوشته را الهام‌بخش یافتند')
                    : _t('اولین کس باش که این نوشته را ستاره می‌زند'); ?>
            </p>
        </section>
        <?php endif; ?>

        <nav class="post-nav" aria-label="<?php _e('نوشته‌های پیشین و پسین'); ?>">
            <div class="post-nav-item post-nav-newer">
                <span class="post-nav-label"><?php _e('نوشتهٔ تازه‌تر'); ?></span>
                <?php $this->theNext('%s', _t('نوشتهٔ تازه‌تری نیست')); ?>
            </div>
            <div class="post-nav-item post-nav-older">
                <span class="post-nav-label"><?php _e('نوشتهٔ پیشین'); ?></span>
                <?php $this->thePrev('%s', _t('نوشتهٔ پیشینی نیست')); ?>
            </div>
        </nav>

        <?php $this->need('comments.php'); ?>

    </article>

</main>

<?php $this->need('footer.php'); ?>
