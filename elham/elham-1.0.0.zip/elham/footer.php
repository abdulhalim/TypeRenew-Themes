<?php


if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$elhamFooterText = trim((string) elham_opt('elhamFooterText', ''));
?>

<footer class="site-foot">
    <div class="wrap">

        <?php if (elham_on('elhamShowPopular')):
            $popular = elham_popular();
            if ($popular && $popular->have()):
        ?>
        <section class="foot-popular" aria-label="<?php _e('پرالهام‌ترین نوشته‌ها'); ?>">
            <h2 class="foot-heading"><span class="spark-mini" aria-hidden="true"><?php echo elham_lucide('feather', 14); ?></span> <?php _e('پرالهام‌ترین‌ها'); ?></h2>
            <ol class="popular-list">
                <?php $rank = 0; while ($popular->next()): $rank++; ?>
                <li class="popular-item">
                    <a href="<?php $popular->permalink(); ?>">
                        <span class="popular-rank" aria-hidden="true"><?php echo elham_fa((string) $rank); ?></span>
                        <span class="popular-title"><?php $popular->title(); ?></span>
                        <span class="popular-stats">
                            <?php $pLikes = elham_likes($popular); ?>
                            <span<?php echo $pLikes > 0 ? ' class="has-likes"' : ''; ?>><?php echo $pLikes > 0 ? '✦ ' . elham_num($pLikes) : ''; ?></span>
                            <span><?php echo elham_num(elham_views($popular)); ?></span>
                        </span>
                    </a>
                </li>
                <?php endwhile; ?>
            </ol>
        </section>
            <?php endif; ?>
        <?php endif; ?>

        <div class="foot-cols">
            <section class="foot-about">
                <h2 class="foot-heading"><span class="rosette" aria-hidden="true"><?php echo elham_lucide('feather', 15); ?></span> <?php $this->options->title(); ?></h2>
                <p class="foot-text">
                    <?php
                    if ($elhamFooterText !== '') {
                        echo htmlspecialchars($elhamFooterText, ENT_QUOTES, 'UTF-8');
                    } else {
                        $this->options->description();
                    }
                    ?>
                </p>
            </section>
        </div>

        <div class="colophon">
            <p>
                <?php $this->options->title(); ?> · <?php echo elham_year(); ?>
            </p>
            <p class="colophon-credit">
                <?php _e('قدرت‌گرفته از'); ?>
                <a href="https://typerenew.ir" target="_blank" rel="noopener">TypeRenew</a>
                <span class="dot" aria-hidden="true">·</span>
                <?php _e('پوستهٔ «الهام»'); ?>
            </p>
        </div>

    </div>
</footer>

<button type="button" class="back-top" id="back-top" aria-label="<?php _e('بازگشت به بالای دفتر'); ?>">
    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 19V5M5 12l7-7 7 7"/></svg>
</button>

<?php $this->footer(); ?>
<script src="<?php $this->options->themeUrl('assets/js/elham.js?v=' . ELHAM_VERSION); ?>" defer></script>
</body>
</html>
