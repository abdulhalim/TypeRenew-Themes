<?php
/**
 * الهام — دفتری کتاب‌گونه برای نوشتن
 *
 * @package الهام
 * @author  پوردریایی
 * @version 1.0.0
 * @link    https://pourdaryaei.ir
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$elhamShowViews = elham_on('elhamShowViews');
$elhamShowLikes = elham_on('elhamShowLikes');
$elhamFirstPage = (int) $this->getCurrentPage() <= 1;
?>

<main id="main" class="wrap">

<?php if ($this->is('index') && $elhamFirstPage): ?>

    <?php
    $elhamTagline = trim((string) elham_opt('elhamTagline', ''));
    if ($elhamTagline === '') {
        $elhamTagline = trim((string) $this->options->description);
    }
    $elhamIntro = trim((string) elham_opt('elhamIntro', ''));
    if ($elhamIntro === '') {
        $elhamIntro = 'اینجا گوشه‌ای است برای نوشتن؛ هر چه که الهام می‌آورد، بی‌واسطه و بی‌حاشیه.';
    }
    $elhamIntroTitle = trim((string) elham_opt('elhamIntroTitle', ''));
    if ($elhamIntroTitle === '') {
        $elhamIntroTitle = trim((string) $this->options->title);
    }
    $elhamTotal = elham_total_posts();
    ?>

    <section class="front-intro">
        <p class="intro-eyebrow"><span class="rosette" aria-hidden="true"><?php echo elham_lucide('feather', 15); ?></span> <?php _e('دفترِ الهام'); ?></p>
        <h1 class="intro-title"><?php echo htmlspecialchars($elhamIntroTitle, ENT_QUOTES, 'UTF-8'); ?></h1>
        <?php if ($elhamTagline !== ''): ?>
            <p class="intro-tagline"><?php echo htmlspecialchars($elhamTagline, ENT_QUOTES, 'UTF-8'); ?></p>
        <?php endif; ?>
        <p class="intro-text"><?php echo htmlspecialchars($elhamIntro, ENT_QUOTES, 'UTF-8'); ?></p>
        <?php if ($elhamTotal > 0): ?>
            <p class="intro-stat"><?php echo elham_num($elhamTotal); ?> <?php _e('نوشته در این دفتر'); ?></p>
        <?php endif; ?>
    </section>

<?php elseif ($this->is('archive')): ?>

    <header class="archive-head">
        <p class="archive-eyebrow"><span class="rosette" aria-hidden="true"><?php echo elham_lucide('feather', 14); ?></span> <?php _e('بایگانی'); ?></p>
        <h1 class="archive-title"><?php $this->archiveTitle([
            'category' => _t('%s'),
            'search'   => _t('%s'),
            'tag'      => _t('%s'),
            'author'   => _t('%s'),
            'date'     => _t('%s'),
        ], '', ''); ?></h1>
        <?php if ($this->is('search')): ?>
            <p class="archive-note"><?php _e('هر چه در دفتر دربارهٔ این عبارت پیدا شد، اینجاست.'); ?></p>
        <?php else: ?>
            <p class="archive-note"><?php _e('نوشته‌های این بخش از دفتر، از تازه تا کهنه.'); ?></p>
        <?php endif; ?>
    </header>

<?php endif; ?>

<?php if ($this->have()): ?>

    <section class="index-section" aria-label="<?php _e('فهرست نوشته‌ها'); ?>">
        <h2 class="index-heading<?php echo ($this->is('index') && $elhamFirstPage) ? ' show' : ''; ?>"><?php _e('فهرست'); ?></h2>

        <ol class="index-list">
            <?php $i = 0; while ($this->next()): $i++; ?>
            <?php
            $elhamCid = (int) $this->cid;
            $elhamViews = $elhamShowViews ? elham_views($elhamCid) : 0;
            $elhamLikes = $elhamShowLikes ? elham_likes($elhamCid) : 0;
            $elhamCats = [];
            try {
                $elhamCats = is_array($this->categories) ? $this->categories : [];
            } catch (\Throwable $e) {
            }
            $elhamCat = '';
            if (!empty($elhamCats)) {
                $first = $elhamCats[0];
                $elhamCat = isset($first['title']) ? (string) $first['title'] : (isset($first['name']) ? (string) $first['name'] : '');
            }
            ?>
            <li class="index-item">
                <a class="index-row" href="<?php $this->permalink(); ?>">
                    <span class="index-num" aria-hidden="true"><?php echo elham_fa(sprintf('%02d', $i)); ?></span>
                    <span class="index-main">
                        <span class="index-title-line">
                            <span class="index-title"><?php $this->title(); ?></span>
                            <span class="index-leader" aria-hidden="true"></span>
                        </span>
                        <span class="index-excerpt"><?php echo htmlspecialchars(elham_excerpt($this, 22), ENT_QUOTES, 'UTF-8'); ?></span>
                        <span class="index-meta">
                            <time datetime="<?php echo date('c', (int) $this->created); ?>"><?php echo elham_date((int) $this->created); ?></time>
                            <span class="dot" aria-hidden="true">·</span>
                            <span><?php echo elham_fa((string) elham_reading_time($this)); ?> <?php _e('دقیقه'); ?></span>
                            <?php if ($elhamShowViews): ?>
                                <span class="dot" aria-hidden="true">·</span>
                                <span><?php echo elham_num($elhamViews); ?> <?php _e('بازدید'); ?></span>
                            <?php endif; ?>
                            <?php if ($elhamShowLikes && $elhamLikes > 0): ?>
                                <span class="dot" aria-hidden="true">·</span>
                                <span class="index-likes">✦ <?php echo elham_num($elhamLikes); ?></span>
                            <?php endif; ?>
                            <?php if ($elhamCat !== ''): ?>
                                <span class="dot" aria-hidden="true">·</span>
                                <span><?php _e('در'); ?> «<?php echo htmlspecialchars($elhamCat, ENT_QUOTES, 'UTF-8'); ?>»</span>
                            <?php endif; ?>
                        </span>
                    </span>
                    <svg class="index-go" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                </a>
            </li>
            <?php endwhile; ?>
        </ol>

        <?php
        ob_start();
        $this->pageNav(
            '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 6 15 12 9 18"></polyline></svg>',
            '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 6 9 12 15 18"></polyline></svg>',
            2,
            '…'
        );
        echo elham_nav_fa((string) ob_get_clean());
        ?>
    </section>

<?php else: ?>

    <section class="empty-state">
        <p class="empty-rosette" aria-hidden="true"><?php echo elham_lucide('feather', 42); ?></p>
        <h2><?php _e('هنوز چیزی نوشته نشده'); ?></h2>
        <?php if ($this->is('search')): ?>
            <p><?php _e('چیزی با این عنوان در دفتر پیدا نشد؛ عبارت دیگری را بیازمایید.'); ?></p>
        <?php else: ?>
            <p><?php _e('این برگهٔ دفتر هنوز سفید است؛ اولین نوشته را بنویسید.'); ?></p>
        <?php endif; ?>
        <form class="empty-search" method="post" action="<?php $this->options->siteUrl(); ?>" role="search">
            <input type="search" name="s" placeholder="<?php _e('جستجوی دیگری…'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>">
            <button type="submit"><?php _e('جستجو'); ?></button>
        </form>
        <p class="empty-home"><a href="<?php $this->options->siteUrl(); ?>"><?php _e('بازگشت به خانه'); ?></a></p>
    </section>

<?php endif; ?>

</main>

<?php $this->need('footer.php'); ?>
