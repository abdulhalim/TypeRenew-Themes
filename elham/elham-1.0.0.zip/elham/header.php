<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$elhamAccent = (string) elham_opt('elhamAccent', 'saffron');
if (!in_array($elhamAccent, ['saffron', 'turquoise', 'pomegranate', 'rose'], true)) {
    $elhamAccent = 'saffron';
}

$elhamPattern = (string) elham_opt('elhamPattern', 'dots');
if (!in_array($elhamPattern, ['dots', 'grid', 'diag', 'none'], true)) {
    $elhamPattern = 'dots';
}

$elhamLogoUrl = trim((string) elham_opt('elhamLogoUrl', ''));
if (!elham_image_ok($elhamLogoUrl)) {
    $elhamLogoUrl = '';
}

$elhamFaviconUrl = trim((string) elham_opt('elhamFaviconUrl', ''));
if (!elham_image_ok($elhamFaviconUrl)) {
    $elhamFaviconUrl = '';
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl" data-accent="<?php echo htmlspecialchars($elhamAccent, ENT_QUOTES, 'UTF-8'); ?>" data-pattern="<?php echo htmlspecialchars($elhamPattern, ENT_QUOTES, 'UTF-8'); ?>">
<head>
<meta charset="<?php $this->options->charset(); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#faf7f0" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#1a1611" media="(prefers-color-scheme: dark)">
<title><?php
    if ($this->is('archive', '404')) {
        _e('برگه پیدا نشد');
        echo ' — ';
        $this->options->title();
    } else {
        $this->archiveTitle([
            'category' => _t('دستهٔ %s'),
            'search'   => _t('جستجوی «%s»'),
            'tag'      => _t('برچسب %s'),
            'author'   => _t('دفترِ %s'),
            'date'     => _t('آرشیو %s'),
        ], '', ' — ');
        $this->options->title();
    }
?></title>
<?php $this->header(); ?>

<?php if ($elhamFaviconUrl !== '' && preg_match('#\.svg($|\?)#i', $elhamFaviconUrl)): ?>
<link rel="icon" type="image/svg+xml" href="<?php echo htmlspecialchars($elhamFaviconUrl, ENT_QUOTES, 'UTF-8'); ?>">
<?php elseif ($elhamFaviconUrl !== ''): ?>
<link rel="icon" href="<?php echo htmlspecialchars($elhamFaviconUrl, ENT_QUOTES, 'UTF-8'); ?>">
<?php else: ?>
<link rel="icon" type="image/svg+xml" href="<?php echo htmlspecialchars(elham_asset('assets/img/favicon.svg'), ENT_QUOTES, 'UTF-8'); ?>">
<?php endif; ?>

<link rel="preload" href="<?php $this->options->themeUrl('assets/fonts/Vazirmatn-Variable.woff2'); ?>" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/elham.css?v=' . ELHAM_VERSION); ?>">

<script>
(function () {
    var stored = null;
    try { stored = localStorage.getItem('elham-theme'); } catch (e) {}
    var dark = false;
    if (stored === 'dark' || stored === 'light') {
        dark = (stored === 'dark');
    } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        dark = true;
    }
    if (dark) {
        document.documentElement.setAttribute('data-theme', 'dark');
    }
})();
</script>
</head>

<body class="elham-body<?php echo $this->is('post') || $this->is('page') ? ' layout-single' : ''; ?>">
<a class="skip-link" href="#main"><?php _e('رفتن به نوشته‌ها'); ?></a>
<div class="reading-progress" id="reading-progress" aria-hidden="true"></div>

<header class="site-head">
    <div class="wrap head-row">
        <a class="brand" href="<?php $this->options->siteUrl(); ?>">
            <?php if ($elhamLogoUrl !== ''): ?>
                <img class="brand-logo" src="<?php echo htmlspecialchars($elhamLogoUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->options->title(); ?>" decoding="async">
            <?php else: ?>
                <span class="brand-mark" aria-hidden="true"><?php echo elham_lucide('feather', 22); ?></span>
                <span class="brand-name"><?php $this->options->title(); ?></span>
            <?php endif; ?>
        </a>

        <div class="head-tools">
            <form class="head-search" method="post" action="<?php $this->options->siteUrl(); ?>" role="search">
                <input type="search" name="s" placeholder="<?php _e('جستجو در دفتر…'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" value="<?php echo htmlspecialchars((string) ($this->request->keywords ?? $this->request->s ?? ''), ENT_QUOTES, 'UTF-8'); ?>" autocomplete="off">
            </form>

            <button type="button" class="theme-toggle" id="theme-toggle" aria-label="<?php _e('رفتن به حالت روشن یا تاریک'); ?>">
                <svg class="icon-sun" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>
                <svg class="icon-moon" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
            </button>

            <button type="button" class="nav-toggle" id="nav-toggle" aria-controls="site-nav" aria-expanded="false" aria-label="<?php _e('گشودن فهرست دفتر'); ?>">
                <svg class="icon-menu" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="18" x2="20" y2="18"/></svg>
                <svg class="icon-close" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
            </button>
        </div>
    </div>

    <nav class="site-nav wrap" id="site-nav" aria-label="<?php _e('ناوبری اصلی'); ?>">
        <a href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a>
        <?php
        // دسته‌های دفتر — میان خانه و برگه‌های ثابت
        try {
            $catsClass = class_exists('\\Widget\\Metas\\Category\\Rows') ? 'Widget\Metas\Category\Rows' : 'Widget_Metas_Category_List';
            $this->widget($catsClass)->to($elhamNavCats);
            while ($elhamNavCats->next()):
                ?>
                <a href="<?php $elhamNavCats->permalink(); ?>"><?php $elhamNavCats->name(); ?></a>
                <?php
            endwhile;
        } catch (\Throwable $e) {
        }
        ?>
        <?php
        try {
            $pagesClass = class_exists('\\Widget\\Contents\\Page\\Rows') ? 'Widget\Contents\Page\Rows' : 'Widget_Contents_Page_List';
            $this->widget($pagesClass)->to($pages);
            while ($pages->next()):
                ?>
                <a href="<?php $pages->permalink(); ?>"><?php $pages->title(); ?></a>
                <?php
            endwhile;
        } catch (\Throwable $e) {
        }
        ?>
    </nav>
</header>
