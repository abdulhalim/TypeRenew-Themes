(function (window, document) {
    'use strict';

    var docEl = document.documentElement;

    /* بدون جاوااسکریپت، عناصر «ورودِ آرام» باید دیده شوند */
    docEl.classList.add('reveal-off');

    /* ---------- حالت روشن / تاریک ---------- */

    var toggle = document.getElementById('theme-toggle');

    function applyTheme(dark) {
        if (dark) {
            docEl.setAttribute('data-theme', 'dark');
        } else {
            docEl.removeAttribute('data-theme');
        }
        try {
            localStorage.setItem('elham-theme', dark ? 'dark' : 'light');
        } catch (e) { /* حالت خصوصی مرورگر */ }
    }

    if (toggle) {
        toggle.addEventListener('click', function () {
            var dark = docEl.getAttribute('data-theme') === 'dark';
            applyTheme(!dark);
        });
    }

    /* ---------- نوار پیشرفت مطالعه ---------- */

    var progress = document.getElementById('reading-progress');

    if (progress) {
        var ticking = false;
        var updateProgress = function () {
            var h = document.documentElement.scrollHeight - window.innerHeight;
            var ratio = h > 0 ? Math.min(1, window.scrollY / h) : 0;
            progress.style.width = (ratio * 100).toFixed(2) + '%';
            ticking = false;
        };
        window.addEventListener('scroll', function () {
            if (!ticking) {
                ticking = true;
                window.requestAnimationFrame(updateProgress);
            }
        }, { passive: true });
        updateProgress();
    }

    /* ---------- ستارهٔ الهام (پسند) ---------- */

    var likeBtn = document.getElementById('elham-like-btn');
    var likeHint = document.getElementById('elham-like-hint');
    var likeBusy = false;

    function faNum(n) {
        var map = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return String(n).replace(/\d/g, function (d) { return map[+d]; });
    }

    function paintLike(btn, likes, liked) {
        var count = btn.querySelector('.like-count');
        var label = btn.querySelector('.like-label');
        if (count) { count.textContent = faNum(Math.max(0, likes)); }
        if (label) { label.textContent = liked ? 'الهام‌بخش بود' : 'ستاره بزن'; }
        if (liked) { btn.classList.add('is-liked'); } else { btn.classList.remove('is-liked'); }
        btn.setAttribute('data-likes', String(Math.max(0, likes)));
        btn.setAttribute('data-liked', liked ? '1' : '0');
        btn.setAttribute('aria-pressed', liked ? 'true' : 'false');
    }

    if (likeBtn) {
        likeBtn.addEventListener('click', function () {
            if (likeBusy) { return; }
            likeBusy = true;

            var cid = String(likeBtn.getAttribute('data-cid') || '');
            var before = {
                likes: parseInt(likeBtn.getAttribute('data-likes'), 10) || 0,
                liked: likeBtn.getAttribute('data-liked') === '1'
            };
            var optimistic = before.liked ? -1 : 1;

            paintLike(likeBtn, before.likes + optimistic, !before.liked);
            if (optimistic > 0) {
                likeBtn.classList.add('pop');
                window.setTimeout(function () { likeBtn.classList.remove('pop'); }, 600);
            }

            var body = new URLSearchParams();
            body.append('elhamLike', cid);

            fetch(window.location.href, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: body.toString(),
                credentials: 'same-origin'
            })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    likeBusy = false;
                    if (!data || !data.ok) {
                        paintLike(likeBtn, before.likes, before.liked);
                        return;
                    }
                    paintLike(likeBtn, data.likes, data.liked);
                    if (likeHint) {
                        likeHint.textContent = data.likes > 0
                            ? faNum(data.likes) + ' نفر این نوشته را الهام‌بخش یافتند'
                            : 'اولین کس باش که این نوشته را ستاره می‌زند';
                    }
                })
                .catch(function () {
                    likeBusy = false;
                    paintLike(likeBtn, before.likes, before.liked);
                });
        });
    }

    /* ---------- دکمهٔ همبرگری (وقتی فهرست منو شلوغ شود) ---------- */

    var head = document.querySelector('.site-head');
    var nav = document.getElementById('site-nav');
    var navToggle = document.getElementById('nav-toggle');
    var navTimer = null;

    function closeNav() {
        if (!head) { return; }
        head.classList.remove('nav-open');
        if (navToggle) { navToggle.setAttribute('aria-expanded', 'false'); }
    }

    /* اگر فهرست به بیش از یک سطر بپیچد، حالت همبرگری روشن می‌شود */
    function syncNav() {
        if (!nav || !navToggle || !head) { return; }
        closeNav();
        docEl.classList.remove('nav-crowded');
        void nav.offsetHeight; /* اعمال چیدمان یک‌ردیفی پیش از اندازه‌گیری */
        var crowded = nav.offsetHeight > 48;
        docEl.classList.toggle('nav-crowded', crowded);
        if (!crowded) { closeNav(); }
    }

    if (nav && navToggle && head) {
        navToggle.addEventListener('click', function () {
            var open = head.classList.toggle('nav-open');
            navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        });

        nav.addEventListener('click', function (event) {
            if (event.target && event.target.closest && event.target.closest('a')) {
                closeNav();
            }
        });

        document.addEventListener('click', function (event) {
            if (!head.classList.contains('nav-open')) { return; }
            if (head.contains(event.target)) { return; }
            closeNav();
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') { closeNav(); }
        });

        window.addEventListener('resize', function () {
            window.clearTimeout(navTimer);
            navTimer = window.setTimeout(syncNav, 160);
        }, { passive: true });

        window.addEventListener('load', syncNav);
        if (document.fonts && document.fonts.ready && document.fonts.ready.then) {
            document.fonts.ready.then(syncNav);
        }
        syncNav();
    }

    /* ---------- گالری صفحهٔ «درباره» — لایت‌باکس سبک ---------- */

    var gallery = document.querySelectorAll('.about-photo img');
    var lightbox = null;
    var lightboxImg = null;

    function ensureLightbox() {
        if (lightbox) { return; }
        lightbox = document.createElement('div');
        lightbox.className = 'elham-lightbox';
        lightbox.setAttribute('role', 'dialog');
        lightbox.setAttribute('aria-label', 'نمایش بزرگ تصویر');
        lightboxImg = document.createElement('img');
        lightboxImg.alt = '';
        lightbox.appendChild(lightboxImg);
        lightbox.addEventListener('click', function () {
            lightbox.classList.remove('open');
        });
        document.body.appendChild(lightbox);
    }

    for (var g = 0; g < gallery.length; g++) {
        (function (img) {
            img.addEventListener('click', function () {
                ensureLightbox();
                lightboxImg.src = img.currentSrc || img.src;
                lightboxImg.alt = img.alt || '';
                lightbox.classList.add('open');
            });
        })(gallery[g]);
    }

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && lightbox) {
            lightbox.classList.remove('open');
        }
    });

    /* ---------- بازگشت به بالا ---------- */

    var backTop = document.getElementById('back-top');

    if (backTop) {
        var shown = false;
        var updateBackTop = function () {
            var should = window.scrollY > 640;
            if (should !== shown) {
                shown = should;
                if (should) { backTop.classList.add('show'); } else { backTop.classList.remove('show'); }
            }
        };
        window.addEventListener('scroll', updateBackTop, { passive: true });
        updateBackTop();
        backTop.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    /* ---------- پاسخ به دیدگاه (استاندارد Typecho) ---------- */

    window.TypechoComment = {
        dom: function (id) {
            return document.getElementById(id);
        },

        create: function (tag, attr) {
            var el = document.createElement(tag);
            for (var key in attr) {
                if (Object.prototype.hasOwnProperty.call(attr, key)) {
                    el.setAttribute(key, attr[key]);
                }
            }
            return el;
        },

        reply: function (cid, coid) {
            var comment = this.dom(cid);
            var response = this.dom('respond');
            var input = this.dom('comment-parent');
            if (!comment || !response) { return false; }

            var parent = comment.parentNode;
            if (input) { input.setAttribute('value', coid); }

            if (null === this.dom('comment-form-place-holder')) {
                var holder = this.create('div', { 'id': 'comment-form-place-holder' });
                response.parentNode.insertBefore(holder, response);
            }

            parent.insertBefore(response, comment.nextSibling);
            return false;
        },

        cancelComment: function () {
            var response = this.dom('respond');
            var holder = this.dom('comment-form-place-holder');
            var input = this.dom('comment-parent');
            if (!response) { return false; }

            if (input) { input.setAttribute('value', '0'); }
            if (null === holder) { return true; }

            holder.parentNode.insertBefore(response, holder);
            holder.parentNode.removeChild(holder);
            return false;
        }
    };

    /* ---------- ورودِ آرام عناصر ---------- */

    if ('IntersectionObserver' in window) {
        docEl.classList.remove('reveal-off');
        var targets = document.querySelectorAll('.index-item, .front-intro, .archive-head, .post-head, .post-thumb, .like-box, .comment-item, [data-reveal]');
        if (targets.length) {
            var io = new IntersectionObserver(function (entries) {
                for (var i = 0; i < entries.length; i++) {
                    if (entries[i].isIntersecting) {
                        entries[i].target.classList.add('in');
                        io.unobserve(entries[i].target);
                    }
                }
            }, { rootMargin: '0px 0px -6% 0px', threshold: 0.04 });
            for (var j = 0; j < targets.length; j++) {
                targets[j].classList.add('reveal');
                io.observe(targets[j]);
            }
        } else {
            docEl.classList.add('reveal-off');
        }
    }

})(window, document);
