<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$elhamCid = (int) $this->cid;
$elhamViews = elham_on('elhamShowViews') ? elham_views($elhamCid) : 0;
?>

<main id="main" class="wrap">

    <article class="post" itemscope itemtype="https://schema.org/WebPage">

        <header class="post-head">
            <p class="post-eyebrow">
                <span class="rosette" aria-hidden="true"><?php echo elham_lucide('feather', 14); ?></span>
                <?php _e('برگهٔ دفتر'); ?>
            </p>
            <h1 class="post-title" itemprop="headline"><?php $this->title(); ?></h1>
            <?php if ($elhamViews > 0): ?>
            <p class="post-meta">
                <span><?php echo elham_num($elhamViews); ?> <?php _e('بازدید'); ?></span>
            </p>
            <?php endif; ?>
        </header>

        <div class="post-body" itemprop="mainEntityOfPage">
            <?php $this->content(); ?>
        </div>

        <?php $this->need('comments.php'); ?>

    </article>

</main>

<?php $this->need('footer.php'); ?>
