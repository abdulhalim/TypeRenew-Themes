<?php
/**
 * دربارهٔ نویسنده
 *
 * @package custom
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$elhamAboutRole = trim((string) elham_opt('elhamAboutRole', ''));
$elhamAboutPhoto = trim((string) elham_opt('elhamAboutPhoto', ''));
if (!elham_image_ok($elhamAboutPhoto)) {
    $elhamAboutPhoto = '';
}
$elhamAboutInterests = elham_about_interests();
$elhamAboutWorks = elham_about_works();
$elhamAboutPhotos = array_filter(elham_about_lines('elhamAboutPhotos'), 'elham_image_ok');
$elhamAboutPhotos = array_values($elhamAboutPhotos);

/* شمارهٔ بخش‌ها — پویا: بخشِ خالی شماره نمی‌گیرد و شماره‌های بعدی یک رقم کم می‌شوند */
$elhamSectionNo = 0;

/* متن خود برگه — زندگی‌نامهٔ نویسنده */
ob_start();
$this->content();
$elhamAboutContent = trim((string) ob_get_clean());
?>

<main id="main" class="wrap about-page">

    <article class="post about-article" itemscope itemtype="https://schema.org/AboutPage">

        <header class="about-hero" data-reveal>
            <span class="about-hero-mark" aria-hidden="true"><?php echo elham_lucide('feather', 150); ?></span>

            <div class="about-portrait<?php echo $elhamAboutPhoto === '' ? ' about-portrait-empty' : ''; ?>">
                <?php if ($elhamAboutPhoto !== ''): ?>
                    <img src="<?php echo htmlspecialchars($elhamAboutPhoto, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->title(); ?>" itemprop="image" decoding="async">
                <?php else: ?>
                    <span class="about-portrait-fallback" aria-hidden="true"><?php echo elham_lucide('feather', 64); ?></span>
                <?php endif; ?>
            </div>

            <h1 class="about-name" itemprop="name"><?php _e('دربارهٔ نویسنده'); ?>
                <svg class="about-scribble" viewBox="0 0 220 14" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true">
                    <path d="M4 10 C 58 3, 96 12, 136 7 S 198 3, 216 8"/>
                </svg>
            </h1>
            <?php if ($elhamAboutRole !== ''): ?>
                <p class="about-role"><?php echo htmlspecialchars($elhamAboutRole, ENT_QUOTES, 'UTF-8'); ?></p>
            <?php endif; ?>
        </header>

        <?php if ($elhamAboutContent !== ''): ?>
        <div class="post-body about-body" itemprop="text" data-reveal>
            <?php echo $elhamAboutContent; ?>
        </div>
        <?php endif; ?>

        <?php if (!empty($elhamAboutWorks)): $elhamSectionNo++; ?>
        <section class="about-section" aria-labelledby="about-works-title" data-reveal>
            <h2 class="about-section-title" id="about-works-title">
                <span class="about-sec-num" aria-hidden="true"><?php echo elham_fa(sprintf('%02d', $elhamSectionNo)); ?></span>
                <span class="rosette" aria-hidden="true"><?php echo elham_lucide('book', 14); ?></span>
                <?php _e('کارها'); ?>
            </h2>
            <ol class="about-works-list">
                <?php
                $wi = 0;
                foreach ($elhamAboutWorks as $work):
                    $wi++;
                    $workUrl = (string) $work['url'];
                    $workExternal = (bool) preg_match('~^(https?://|mailto:|tel:)~i', $workUrl);
                ?>
                <li class="about-work<?php echo $workUrl === '' ? ' about-work-plain' : ''; ?>">
                    <span class="about-work-num" aria-hidden="true"><?php echo elham_fa(sprintf('%02d', $wi)); ?></span>
                    <div class="about-work-main">
                        <h3 class="about-work-title">
                            <?php if ($workUrl !== ''): ?>
                            <a class="about-work-link" href="<?php echo htmlspecialchars($workUrl, ENT_QUOTES, 'UTF-8'); ?>"<?php echo $workExternal ? ' target="_blank" rel="noopener noreferrer"' : ''; ?>><?php echo htmlspecialchars($work['title'], ENT_QUOTES, 'UTF-8'); ?></a>
                            <?php else: ?>
                            <?php echo htmlspecialchars($work['title'], ENT_QUOTES, 'UTF-8'); ?>
                            <?php endif; ?>
                        </h3>
                        <?php if ((string) $work['desc'] !== ''): ?>
                        <p class="about-work-desc"><?php echo htmlspecialchars($work['desc'], ENT_QUOTES, 'UTF-8'); ?></p>
                        <?php endif; ?>
                    </div>
                    <?php if ($workUrl !== ''): ?>
                    <svg class="about-work-go" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                    <?php endif; ?>
                </li>
                <?php endforeach; ?>
            </ol>
        </section>
        <?php endif; ?>

        <?php if (!empty($elhamAboutInterests)): $elhamSectionNo++; ?>
        <section class="about-section" aria-labelledby="about-interests-title" data-reveal>
            <h2 class="about-section-title" id="about-interests-title">
                <span class="about-sec-num" aria-hidden="true"><?php echo elham_fa(sprintf('%02d', $elhamSectionNo)); ?></span>
                <span class="rosette" aria-hidden="true"><?php echo elham_lucide('sparkles', 14); ?></span>
                <?php _e('علایق'); ?>
            </h2>
            <div class="about-chips">
                <?php foreach ($elhamAboutInterests as $interest): ?>
                    <span class="about-chip"><?php echo htmlspecialchars($interest, ENT_QUOTES, 'UTF-8'); ?></span>
                <?php endforeach; ?>
            </div>
        </section>
        <?php endif; ?>

        <?php if (!empty($elhamAboutPhotos)): $elhamSectionNo++; ?>
        <section class="about-section" aria-labelledby="about-photos-title" data-reveal>
            <h2 class="about-section-title" id="about-photos-title">
                <span class="about-sec-num" aria-hidden="true"><?php echo elham_fa(sprintf('%02d', $elhamSectionNo)); ?></span>
                <span class="rosette" aria-hidden="true"><?php echo elham_lucide('image', 14); ?></span>
                <?php _e('تصویرها'); ?>
            </h2>
            <div class="about-gallery">
                <?php foreach ($elhamAboutPhotos as $photo): ?>
                <figure class="about-photo">
                    <img src="<?php echo htmlspecialchars($photo, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->title(); ?>" loading="lazy" decoding="async">
                </figure>
                <?php endforeach; ?>
            </div>
        </section>
        <?php endif; ?>

        <?php if ($elhamAboutContent !== '' || !empty($elhamAboutWorks) || !empty($elhamAboutInterests) || !empty($elhamAboutPhotos)): ?>
        <footer class="about-end" aria-hidden="true" data-reveal>
            <span class="about-end-rule"></span>
            <span class="about-end-feather"><?php echo elham_lucide('feather', 17); ?></span>
            <span class="about-end-rule"></span>
        </footer>
        <?php endif; ?>

    </article>

</main>

<?php $this->need('footer.php'); ?>
