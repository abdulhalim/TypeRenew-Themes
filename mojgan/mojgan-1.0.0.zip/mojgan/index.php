<?php
/**
 * مژگان — یک پوسته ساده خبری و مجله‌ی
 *
 * @package مژگان
 * @author  پوردریایی
 * @version 1.1.0
 * @link    https://pourdaryaei.ir
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$cardCount = (int) mojgan_opt('indexListStart', '3');
if (!in_array($cardCount, [0, 1, 3], true)) {
    $cardCount = 3;
}
// در حالت «بدون کارت» و «فقط یک شاخص»، همهٔ نوشته‌ها فهرستی دیده می‌شوند؛
// پس سرصفحهٔ جداکنندهٔ «مطالب بیشتر» نمایش داده نمی‌شود تا چیدمان یکدست بماند.
$showMoreHead = ($cardCount === 3);
$showReadingTime = mojgan_on('showReadingTime', '1');
$showSidebar = mojgan_show_sidebar($this);
?>

<div class="container">
    <div class="layout<?php echo $showSidebar ? '' : ' no-sidebar'; ?>">

        <?php /* ستون محتوا همیشه نخستین آیتم گرید است؛ سایدبار در ستون دوم (چپ) */ ?>
        <div class="content-area">

            <?php if ($this->have()): ?>

                <?php /* سرصفحهٔ بخش — داخل ستون محتوا تا جای‌گذاری گرید جابه‌جا نشود */ ?>
                <div class="section-head">
                    <h2 class="section-title"><?php _e('تازه‌ترین‌ها'); ?></h2>
                    <span class="section-line" aria-hidden="true"></span>
                </div>

                <?php if ($cardCount > 0): ?>
                <div class="featured-grid">
                <?php endif; ?>

                    <?php
                        $i = 0;
                        $listOpened = false;
                        while ($this->next()):
                            $i++;
                            $cover = mojgan_card_image($this);
                    ?>

                        <?php if ($i <= $cardCount): ?>

                            <?php if ($i === 1): /* ---------- کارت شاخص بزرگ: تازه‌ترین نوشته ---------- */ ?>
                                <article class="hero-card" itemscope itemtype="http://schema.org/BlogPosting">
                                    <a class="hero-cover" href="<?php $this->permalink(); ?>" aria-hidden="true" tabindex="-1" itemprop="image">
                                        <?php if ($cover !== ''): ?>
                                            <img src="<?php echo htmlspecialchars($cover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->title(); ?>" loading="eager" />
                                        <?php else: ?>
                                            <span class="cover-fallback" aria-hidden="true"><?php echo mojgan_icon('newspaper', 46); ?></span>
                                        <?php endif; ?>
                                        <span class="hero-badge"><?php _e('شاخص'); ?></span>
                                    </a>
                                    <div class="hero-body">
                                        <div class="hero-meta">
                                            <?php if ($this->categories): ?>
                                                <a class="card-cat" href="<?php echo htmlspecialchars($this->categories[0]['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($this->categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                                            <?php endif; ?>
                                            <time datetime="<?php echo date('c', (int) $this->created); ?>"><?php echo mojgan_date((int) $this->created); ?></time>
                                        </div>
                                        <h2 class="hero-title" itemprop="name headline">
                                            <a href="<?php $this->permalink(); ?>" itemprop="url"><?php $this->title(); ?></a>
                                        </h2>
                                        <?php $excerpt = mojgan_excerpt($this, 34); ?>
                                        <?php if ($excerpt !== ''): ?>
                                            <p class="hero-excerpt"><?php echo htmlspecialchars($excerpt, ENT_QUOTES, 'UTF-8'); ?></p>
                                        <?php endif; ?>
                                        <div class="hero-foot">
                                            <a class="card-author" href="<?php $this->author->permalink(); ?>">
                                                <?php echo mojgan_author_avatar($this, 30); ?>
                                                <span><?php $this->author(); ?></span>
                                            </a>
                                            <?php if ($showReadingTime): ?>
                                                <span class="hero-read">
                                                    <?php echo mojgan_icon('clock', 13); ?>
                                                    <?php echo mojgan_fa((string) mojgan_reading_time($this)); ?> <?php _e('دقیقه مطالعه'); ?>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </article>

                            <?php else: /* ---------- دو کارت کوچک ---------- */ ?>
                                <article class="mini-card" itemscope itemtype="http://schema.org/BlogPosting">
                                    <a class="mini-cover" href="<?php $this->permalink(); ?>" aria-hidden="true" tabindex="-1" itemprop="image">
                                        <?php if ($cover !== ''): ?>
                                            <img src="<?php echo htmlspecialchars($cover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->title(); ?>" loading="lazy" />
                                        <?php else: ?>
                                            <span class="cover-fallback" aria-hidden="true"><?php echo mojgan_icon('newspaper', 26); ?></span>
                                        <?php endif; ?>
                                    </a>
                                    <div class="mini-body">
                                        <div class="mini-meta">
                                            <?php if ($this->categories): ?>
                                                <a class="card-cat" href="<?php echo htmlspecialchars($this->categories[0]['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($this->categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                                            <?php endif; ?>
                                            <time datetime="<?php echo date('c', (int) $this->created); ?>"><?php echo mojgan_date((int) $this->created); ?></time>
                                        </div>
                                        <h3 class="mini-title" itemprop="name headline">
                                            <a href="<?php $this->permalink(); ?>" itemprop="url"><?php $this->title(); ?></a>
                                        </h3>
                                        <div class="mini-foot">
                                            <span class="card-author-inline"><?php $this->author(); ?></span>
                                        </div>
                                    </div>
                                </article>

                            <?php endif; ?>

                        <?php else: /* ---------- فهرست ادامهٔ نوشته‌ها ---------- */ ?>

                            <?php if (!$listOpened): $listOpened = true; ?>
                                <?php if ($cardCount > 0): ?>
                                </div><!-- /featured-grid -->
                                <?php endif; ?>
                                <?php if ($showMoreHead): ?>
                                <div class="section-head">
                                    <h2 class="section-title"><?php _e('مطالب بیشتر'); ?></h2>
                                    <span class="section-line" aria-hidden="true"></span>
                                </div>
                                <?php endif; ?>
                                <div class="posts-list">
                            <?php endif; ?>

                            <article class="post-row" itemscope itemtype="http://schema.org/BlogPosting">
                                <a class="post-row-thumb" href="<?php $this->permalink(); ?>" aria-hidden="true" tabindex="-1" itemprop="image">
                                    <?php if ($cover !== ''): ?>
                                        <img src="<?php echo htmlspecialchars($cover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->title(); ?>" loading="lazy" />
                                    <?php else: ?>
                                        <span class="cover-fallback" aria-hidden="true"><?php echo mojgan_icon('newspaper', 22); ?></span>
                                    <?php endif; ?>
                                </a>
                                <div class="post-row-body">
                                    <h3 class="post-row-title" itemprop="name headline">
                                        <a href="<?php $this->permalink(); ?>" itemprop="url"><?php $this->title(); ?></a>
                                    </h3>
                                    <div class="post-row-meta">
                                        <time datetime="<?php echo date('c', (int) $this->created); ?>"><?php echo mojgan_date((int) $this->created); ?></time>
                                        <?php if ($this->categories): ?>
                                            <span class="meta-sep" aria-hidden="true">·</span>
                                            <a class="post-row-cat" href="<?php echo htmlspecialchars($this->categories[0]['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($this->categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                                        <?php endif; ?>
                                        <span class="meta-sep" aria-hidden="true">·</span>
                                        <span class="post-row-author"><?php $this->author(); ?></span>
                                    </div>
                                    <?php $rowExcerpt = mojgan_excerpt($this, 18); ?>
                                    <?php if ($rowExcerpt !== ''): ?>
                                        <p class="post-row-excerpt"><?php echo htmlspecialchars($rowExcerpt, ENT_QUOTES, 'UTF-8'); ?></p>
                                    <?php endif; ?>
                                </div>
                            </article>

                        <?php endif; ?>

                    <?php endwhile; ?>

                </div><!-- /featured-grid یا /posts-list بسته به وضعیت حلقه -->

                <nav class="pagination-area" aria-label="<?php _e('ناوبری صفحات'); ?>">
                    <?php
                        ob_start();
                        $this->pageNav(
                            '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 6 15 12 9 18"></polyline></svg>',
                            '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 6 9 12 15 18"></polyline></svg>',
                            2,
                            '…'
                        );
                        echo mojgan_nav_fa((string) ob_get_clean());
                    ?>
                </nav>

            <?php else: ?>

                <div class="empty-state">
                    <div class="empty-ornament" aria-hidden="true"><?php echo mojgan_icon('newspaper', 64); ?></div>
                    <h2 class="empty-title"><?php _e('هنوز خبری نیست'); ?></h2>
                    <p class="empty-desc"><?php _e('اولین نوشته را منتشر کنید تا صفحهٔ نخست مجله پر شود؛ این جای خالی منتظر تازه‌ترین‌های شماست.'); ?></p>
                    <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="empty-search-form">
                        <input type="search" name="s" placeholder="<?php _e('یا چیزی جستجو کنید…'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" />
                        <button type="submit"><?php _e('جستجو'); ?></button>
                    </form>
                </div>

            <?php endif; ?>

        </div>

        <?php if ($showSidebar): ?>
            <?php $this->need('sidebar.php'); ?>
        <?php endif; ?>

    </div>
</div>

<?php $this->need('footer.php'); ?>
