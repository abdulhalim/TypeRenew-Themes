<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');
?>

<div class="error-page">
    <div class="error-ornament" aria-hidden="true">
        <?php echo mojgan_icon('newspaper', 96); ?>
    </div>
    <h1 class="error-code"><?php _e('۴۰۴'); ?></h1>
    <h2 class="error-title"><?php _e('این صفحه در مجله پیدا نشد!'); ?></h2>
    <p class="error-desc">
        <?php _e('نشانی‌ای که دنبالش بودید یا حذف شده، یا جابه‌جا شده، یا از ابتدا هرگز وجود نداشته است. با جستجو می‌توانید مطلب موردنظر را پیدا کنید.'); ?>
    </p>
    <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="error-search-form">
        <input type="search" name="s" placeholder="<?php _e('جستجو کنید…'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" autofocus>
        <button type="submit"><?php _e('جستجو'); ?></button>
    </form>
    <div class="error-actions">
        <a class="btn btn-primary" href="<?php $this->options->siteUrl(); ?>">
            <?php echo mojgan_icon('home', 16); ?>
            <?php _e('بازگشت به خانه'); ?>
        </a>
    </div>
</div>

<?php $this->need('footer.php'); ?>
