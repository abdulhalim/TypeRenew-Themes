<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/*
 * بافر خروجی کل صفحه — در پایان footer.php ارقام لاتینِ باقی‌مانده
 * به فارسی تبدیل می‌شوند (mojgan_fa_html). بلاک‌های کد دست‌نخورده می‌مانند.
 */
$GLOBALS['mojganFaBuffer'] = true;
ob_start();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php if ($this->is('archive', '404')): ?><?php _e('صفحه پیدا نشد'); ?> — <?php $this->options->title(); ?><?php else: ?><?php $this->archiveTitle([
            'category' => _t('نوشته‌های دستهٔ «%s»'),
            'search'   => _t('نتایج جستجو برای «%s»'),
            'tag'      => _t('نوشته‌های برچسب «%s»'),
            'author'   => _t('نوشته‌های %s')
        ], '', ' — '); ?><?php $this->options->title(); ?><?php endif; ?></title>

    <link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/mojgan.css?v=1.1.0'); ?>">
    <?php $this->header(); ?>
</head>
<?php
    $bodyClasses = [];
    if ($this->is('single')) {
        $bodyClasses[] = 'is-single';
    }
    if (!mojgan_on('showDatebar', '1')) {
        $bodyClasses[] = 'no-datebar';
    }
?>
<body<?php echo $bodyClasses ? ' class="' . implode(' ', $bodyClasses) . '"' : ''; ?>>
<?php if (mojgan_on('showReadingTime', '1') && $this->is('post')): ?>
<div class="reading-progress" aria-hidden="true"><span class="reading-progress-bar"></span></div>
<?php endif; ?>
<a class="skip-link" href="#content"><?php _e('رفتن به محتوا'); ?></a>

<header class="site-header" id="site-header">
    <div class="container header-inner">

        <a class="brand" href="<?php $this->options->siteUrl(); ?>">
            <?php $logo = trim((string) mojgan_opt('logoUrl')); ?>
            <?php if ($logo !== ''): ?>
                <span class="brand-logo"><img src="<?php echo htmlspecialchars(mojgan_resolve($logo), ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->options->title(); ?>" /></span>
            <?php else: ?>
                <span class="brand-mark" aria-hidden="true">
                    <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-4 0V9h2"></path>
                        <line x1="10" y1="7" x2="18" y2="7"></line>
                        <line x1="10" y1="11" x2="18" y2="11"></line>
                        <line x1="10" y1="15" x2="14" y2="15"></line>
                    </svg>
                </span>
            <?php endif; ?>
            <span class="brand-name"><?php $this->options->title(); ?></span>
        </a>

        <nav class="main-nav" aria-label="<?php _e('ناوبری اصلی'); ?>">
            <a <?php if ($this->is('index')): ?>class="active"<?php endif; ?> href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a>

            <?php /* دسته‌بندی‌ها — طبق تنظیمات: آیتم مستقل یا زیرمنوی بازشو */ ?>
            <?php $navCatMode = (string) mojgan_opt('navCategoriesMode', 'flat'); ?>
            <?php \Widget\Metas\Category\Rows::allocWithAlias('mojgan-header')->to($headerCategories); ?>
            <?php if ($headerCategories->have()): ?>
                <?php if ($navCatMode === 'dropdown'): ?>
                    <div class="nav-item nav-item-has-children">
                        <button type="button" class="nav-drop-toggle" aria-expanded="false" aria-haspopup="true">
                            <?php _e('دسته‌بندی‌ها'); ?>
                            <?php echo mojgan_icon('chevron-down', 14); ?>
                        </button>
                        <ul class="nav-dropdown">
                            <?php while ($headerCategories->next()): ?>
                                <li>
                                    <a <?php if ($this->is('category', $headerCategories->slug)): ?>class="active"<?php endif; ?> href="<?php $headerCategories->permalink(); ?>">
                                        <span><?php $headerCategories->name(); ?></span>
                                        <span class="cat-count"><?php echo mojgan_fa((string) $headerCategories->count); ?></span>
                                    </a>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    </div>
                <?php else: ?>
                    <?php while ($headerCategories->next()): ?>
                        <a <?php if ($this->is('category', $headerCategories->slug)): ?>class="active"<?php endif; ?> href="<?php $headerCategories->permalink(); ?>"><?php $headerCategories->name(); ?></a>
                    <?php endwhile; ?>
                <?php endif; ?>
            <?php endif; ?>

            <?php /* برگه‌ها — فقط برگه‌های تیک‌خورده در تنظیمات (پیش‌فرض: همه) */ ?>
            <?php \Widget\Contents\Page\Rows::alloc()->to($pages); ?>
            <?php while ($pages->next()): ?>
                <?php if (!mojgan_page_in_menu($pages, 'headerPages')) continue; ?>
                <a <?php if ($this->is('page', $pages->slug)): ?>class="active"<?php endif; ?> href="<?php $pages->permalink(); ?>"><?php $pages->title(); ?></a>
            <?php endwhile; ?>
        </nav>

        <div class="header-actions">
            <button type="button" class="icon-btn js-search-toggle" aria-label="<?php _e('جستجو'); ?>" title="<?php _e('جستجو'); ?>">
                <?php echo mojgan_icon('search', 19); ?>
            </button>
            <button type="button" class="icon-btn nav-toggle js-nav-toggle" aria-label="<?php _e('گشودن منو'); ?>" aria-expanded="false">
                <?php echo mojgan_icon('menu', 20); ?>
            </button>
        </div>

    </div>

    <div class="header-search js-header-search" hidden>
        <div class="container">
            <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="header-search-form">
                <?php echo mojgan_icon('search', 18); ?>
                <input type="search" name="s" class="header-search-input" placeholder="<?php _e('دنبال چه چیزی می‌گردید؟'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" value="<?php echo htmlspecialchars((string) ($this->request->keywords ?? $this->request->s ?? ''), ENT_QUOTES, 'UTF-8'); ?>" autocomplete="off" />
                <button type="button" class="header-search-close js-search-close" aria-label="<?php _e('بستن'); ?>"><?php echo mojgan_icon('close', 18); ?></button>
            </form>
        </div>
    </div>

    <?php if (mojgan_on('showDatebar', '1')): ?>
    <?php $tickerItems = mojgan_ticker_posts(); ?>
    <div class="datebar" role="contentinfo">
        <div class="container datebar-inner">
            <span class="datebar-date">
                <?php echo mojgan_icon('calendar', 14); ?>
                <?php echo mojgan_today_long(); ?>
            </span>
            <?php if ($tickerItems !== []): ?>
            <div class="datebar-ticker" aria-label="<?php _e('عنوان‌های تازهٔ سایت'); ?>">
                <div class="datebar-ticker-track">
                    <?php foreach ($tickerItems as $tickerItem): ?>
                        <a class="ticker-item" href="<?php echo htmlspecialchars($tickerItem['url'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($tickerItem['title'], ENT_QUOTES, 'UTF-8'); ?></a>
                        <span class="ticker-sep" aria-hidden="true"></span>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</header>

<main id="content" class="site-main">
