<?php

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/* ================================================================
 *  ابزارهای عمومی
 * ================================================================ */

/**
 * خواندن تنظیم پوسته با مقدار پیش‌فرض
 */
function mojgan_opt(string $name, ?string $default = null): ?string
{
    $value = \Widget\Options::alloc()->{$name};
    return ($value === null || $value === '') ? $default : $value;
}

/**
 * آیا تنظیم روشن است؟ (۱)
 */
function mojgan_on(string $name, string $default = '1'): bool
{
    return ((string) mojgan_opt($name, $default)) === '1';
}

/**
 * تبدیل ارقام لاتین به فارسی
 */
function mojgan_fa(?string $text): string
{
    return strtr((string) $text, [
        '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
        '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
    ]);
}

/**
 * خلاصه‌سازی اجتماعی اعداد با ارقام فارسی:
 * ۹۹۹ → ۹۹۹ / ۱۵۰۰ → ۱٫۵ هزار / ۱۲۰۰۰۰۰ → ۱٫۲ میلیون
 */
function mojgan_format_count(int $num): string
{
    if ($num >= 1000000) {
        return mojgan_compact(round($num / 1000000, 1)) . ' ' . _t('میلیون');
    }

    if ($num >= 1000) {
        $thousands = round($num / 1000, 1);
        if ($thousands >= 1000) {
            return mojgan_compact(round($thousands / 1000, 1)) . ' ' . _t('میلیون');
        }
        return mojgan_compact($thousands) . ' ' . _t('هزار');
    }

    return mojgan_fa((string) max(0, $num));
}

/**
 * عدد اعشاری خلاصه با ارقام فارسی (۱٫۵ و نه ۱٫۰)
 */
function mojgan_compact(float $value): string
{
    $text = number_format($value, 1, '.', '');
    if (substr($text, -2) === '.0') {
        $text = substr($text, 0, -2);
    }
    return mojgan_fa(str_replace('.', '٫', $text));
}

/**
 * تبدیل ارقام یک قطعهٔ متنی خالص به فارسی.
 * نشانی‌ها (http/https/www)، نشانی‌های ایمیلی و موجودیت‌های HTML
 * (مانند &#1705; و &amp;) دست‌نخورده می‌مانند تا خروجی سالم بماند.
 */
function mojgan_fa_text(string $text): string
{
    if ($text === '' || !preg_match('/[0-9]/', $text)) {
        return $text;
    }

    $parts = preg_split(
        '/(&(?:[a-zA-Z][a-zA-Z0-9]*|#[0-9]+|#x[0-9a-fA-F]+);|(?:https?:\/\/|www\.)[^\s<>"\']+|[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})/',
        $text,
        -1,
        PREG_SPLIT_DELIM_CAPTURE
    );

    if (!is_array($parts)) {
        return mojgan_fa($text);
    }

    $out = '';
    foreach ($parts as $i => $part) {
        $out .= ($i % 2 === 1) ? $part : mojgan_fa($part);
    }

    return $out;
}

/**
 * تبدیل ارقام لاتینِ خروجی HTML به فارسی — سراسری.
 *
 * چه چیزی تبدیل می‌شود: متنِ میان تگ‌ها (عنوان نوشته‌ها، مسیر راهنما،
 * شمارندهٔ دیدگاه‌ها، متن پست و…) و خصیصه‌های نمایشی alt و title.
 * چه چیزی دست‌نخورده می‌ماند:
 *   - بلوک‌های کد: pre، code، kbd، samp
 *   - اسکریپت، استایل و textarea (مقادیر فنی/عددی برای JS)
 *   - تگ‌ها و سایر خصیصه‌ها (href، src، datetime، data-* و…)
 *   - نشانی‌ها، ایمیل‌ها و موجودیت‌های HTML درون متن
 */
function mojgan_fa_html(string $html): string
{
    if ($html === '' || !preg_match('/[0-9]/', $html)) {
        return $html;
    }

    /* ۱) قفل‌گذاری بلوک‌های کد و قطعات فنی */
    $locks = [];
    $locked = preg_replace_callback(
        '#<(pre|code|kbd|samp|script|style|textarea)\b[^>]*>.*?</\1\s*>#is',
        static function (array $m) use (&$locks): string {
            $key = "\x01MOJGANLOCK" . str_repeat('i', count($locks)) . "\x01";
            $locks[$key] = $m[0];
            return $key;
        },
        $html
    );

    if (is_string($locked)) {
        $html = $locked;
    }

    /* ۲) خصیصه‌های نمایشی alt و title — درون تگ، دور از نشانی و سایر خصیصه‌ها */
    $tagged = preg_replace_callback(
        '#<[a-zA-Z][^<>]*>#',
        static function (array $m): string {
            $tag = $m[0];
            if (!preg_match('/[0-9]/', $tag) || !preg_match('/\s(?:alt|title)\s*=/i', $tag)) {
                return $tag;
            }

            $converted = preg_replace_callback(
                '#(\s(?:alt|title)\s*=\s*)(["\'])([^"\']*)(["\'])#i',
                static function (array $a): string {
                    return $a[1] . $a[2] . mojgan_fa_text($a[3]) . $a[4];
                },
                $tag
            );

            return is_string($converted) ? $converted : $tag;
        },
        $html
    );

    if (is_string($tagged)) {
        $html = $tagged;
    }

    /* ۳) فقط متنِ میان تگ‌ها (تگ‌ها و خصیصه‌ها دست‌نخورده می‌مانند) */
    $parts = preg_split('/(<[^>]+>)/', $html, -1, PREG_SPLIT_DELIM_CAPTURE);

    if (is_array($parts)) {
        $html = '';
        foreach ($parts as $i => $part) {
            $html .= ($i % 2 === 1) ? $part : mojgan_fa_text($part);
        }
    } else {
        $html = mojgan_fa_text($html);
    }

    /* ۴) بازگشایی بلوک‌های قفل‌شده */
    return $locks === [] ? $html : strtr($html, $locks);
}

/* ================================================================
 *  تاریخ شمسی
 * ================================================================ */

/**
 * تبدیل میلادی به جلالی — الگوریتم استاندارد
 *
 * @return array{0:int,1:int,2:int} [سال، ماه، روز]
 */
function mojgan_to_jalali(int $gy, int $gm, int $gd): array
{
    $gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

    $jy = ($gy <= 1600) ? 0 : 979;
    $gy -= ($gy <= 1600) ? 621 : 1600;

    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = (365 * $gy)
        + intdiv($gy2 + 3, 4)
        - intdiv($gy2 + 99, 100)
        + intdiv($gy2 + 399, 400)
        - 80
        + $gd
        + $gdm[$gm - 1];

    $jy += 33 * intdiv($days, 12053);
    $days %= 12053;
    $jy += 4 * intdiv($days, 1461);
    $days %= 1461;

    if ($days > 365) {
        $jy += intdiv($days - 1, 365);
        $days = ($days - 1) % 365;
    }

    if ($days < 186) {
        $jm = 1 + intdiv($days, 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + intdiv($days - 186, 30);
        $jd = 1 + (($days - 186) % 30);
    }

    return [$jy, $jm, $jd];
}

/**
 * نام ماه‌های شمسی
 */
function mojgan_jalali_months(): array
{
    return [
        1  => 'فروردین', 2  => 'اردیبهشت', 3 => 'خرداد',
        4  => 'تیر', 5  => 'مرداد', 6 => 'شهریور',
        7  => 'مهر', 8  => 'آبان', 9 => 'آذر',
        10 => 'دی', 11 => 'بهمن', 12 => 'اسفند',
    ];
}

/**
 * تاریخ کوتاه شمسی با ارقام فارسی: ۱۴۰۴/۰۶/۰۸
 */
function mojgan_date(int $timestamp): string
{
    [$jy, $jm, $jd] = mojgan_to_jalali((int) date('Y', $timestamp), (int) date('n', $timestamp), (int) date('j', $timestamp));

    return mojgan_fa(sprintf('%04d/%02d/%02d', $jy, $jm, $jd));
}

/**
 * تاریخ بلند شمسی: ۸ شهریور ۱۴۰۴
 */
function mojgan_date_long(int $timestamp): string
{
    [$jy, $jm, $jd] = mojgan_to_jalali((int) date('Y', $timestamp), (int) date('n', $timestamp), (int) date('j', $timestamp));
    $months = mojgan_jalali_months();

    return mojgan_fa((string) $jd) . ' ' . $months[$jm] . ' ' . mojgan_fa((string) $jy);
}

/**
 * تاریخ امروز برای نوار تاریخ هدر: شنبه، ۸ شهریور ۱۴۰۴
 */
function mojgan_today_long(): string
{
    $days = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
    $weekday = $days[(int) date('w')];

    return $weekday . '، ' . mojgan_date_long((int) time());
}

/**
 * تبدیل ارقام خروجی صفحه‌بندی به فارسی (نشانی لینک‌ها دست‌نخورده می‌ماند)
 */
function mojgan_nav_fa(string $html): string
{
    return (string) preg_replace_callback(
        '/>([^<>]+)</u',
        function (array $matches): string {
            return '>' . mojgan_fa($matches[1]) . '<';
        },
        $html
    );
}

/* ================================================================
 *  تصاویر
 * ================================================================ */

/**
 * اعتبار نشانی تصویر
 */
function mojgan_image_ok(?string $url): bool
{
    $url = trim((string) $url);
    if ($url === '' || strlen($url) > 2048) {
        return false;
    }
    return (bool) preg_match('#^(https?://|/|data:image/)#i', $url);
}

/**
 * نرمال‌سازی نشانی (نسبی → مطلق)
 */
function mojgan_resolve(?string $url): string
{
    $url = trim((string) $url);
    if ($url === '') {
        return '';
    }
    if (preg_match('#^(data:|https?://|//)#i', $url)) {
        return $url;
    }
    $base = rtrim((string) \Widget\Options::alloc()->siteUrl, '/');
    return $base . '/' . ltrim($url, '/');
}

/**
 * جدا کردن نشانی از آرگومان تصویر مارک‌داون
 */
function mojgan_md_url(string $raw): string
{
    $raw = trim($raw);
    if ($raw === '') {
        return '';
    }
    if ($raw[0] === '<') {
        $end = strpos($raw, '>');
        return trim($end === false ? substr($raw, 1) : substr($raw, 1, $end - 1));
    }
    return rtrim(substr($raw, 0, strcspn($raw, " \t")));
}

/**
 * نخستین تصویر متن نوشته — تگ img، مارک‌داون درون‌خطی و ارجاعی
 */
function mojgan_first_image(?string $text): string
{
    $text = str_replace("\r\n", "\n", (string) $text);
    if ($text === '') {
        return '';
    }

    $candidates = [];

    // ۱) تگ img در HTML
    if (preg_match_all('#<img\b[^>]*?(?<![\w-])src=["\']([^"\']+)["\']#i', $text, $m, PREG_OFFSET_CAPTURE)) {
        foreach ($m[1] as $hit) {
            $candidates[] = [$hit[1], $hit[0]];
        }
    }

    // ۲) مارک‌داون درون‌خطی ![alt](url)
    if (preg_match_all('#!\[[^\]\n]*\]\(\s*([^)\n]+)#', $text, $m, PREG_OFFSET_CAPTURE)) {
        foreach ($m[1] as $hit) {
            $candidates[] = [$hit[1], mojgan_md_url($hit[0])];
        }
    }

    // ۳) مارک‌داون ارجاعی ![alt][label] با تعریف [label]: url
    if (preg_match_all('#!\[([^\]\n]*)\](?:\[([^\]\n]*)\])?(?!\()#', $text, $m, PREG_OFFSET_CAPTURE)) {
        $defs = [];
        if (preg_match_all('#^[ \t]{0,3}\[([^\]\n]+)\]:[ \t]*(<?[^\s>]+>?)#m', $text, $d)) {
            foreach ($d[1] as $i => $label) {
                $defs[strtolower(trim((string) $label))] = mojgan_md_url((string) $d[2][$i]);
            }
        }
        foreach ($m[0] as $i => $hit) {
            $label = trim((string) $m[2][$i][0]) !== '' ? (string) $m[2][$i][0] : (string) $m[1][$i][0];
            $label = strtolower(trim($label));
            if ($label !== '' && isset($defs[$label])) {
                $candidates[] = [$hit[1], $defs[$label]];
            }
        }
    }

    if ($candidates === []) {
        return '';
    }

    usort($candidates, static function (array $a, array $b): int {
        return $a[0] <=> $b[0];
    });

    foreach ($candidates as $candidate) {
        $url = html_entity_decode(trim((string) $candidate[1]), ENT_QUOTES, 'UTF-8');
        if (mojgan_image_ok($url)) {
            return $url;
        }
    }

    return '';
}

/**
 * تصویر شاخص نوشته — فیلد سفارشی «thumb» (سازگار با cover/thumbnail)
 */
function mojgan_thumbnail($archive): string
{
    if (isset($archive->fields) && $archive->fields instanceof \Typecho\Config) {
        $thumb = trim((string) ($archive->fields->thumb ?? ''));
        if (mojgan_image_ok($thumb)) {
            return $thumb;
        }
    }

    // سازگاری با پوسته‌های دیگر (زیبا/نگارین/پرنیان)
    foreach (['cover', 'thumbnail'] as $key) {
        $value = trim((string) ($archive->fields->{$key} ?? ''));
        if (mojgan_image_ok($value)) {
            return $value;
        }
    }

    return '';
}

/**
 * تصویر کارت فهرست: تصویر شاخص ← نخستین تصویر متن ← تصویر پیش‌فرض تنظیمات
 */
function mojgan_card_image($archive): string
{
    $thumb = mojgan_thumbnail($archive);
    if ($thumb !== '') {
        return $thumb;
    }

    $first = mojgan_first_image((string) $archive->text);
    if ($first !== '') {
        return $first;
    }

    $default = trim((string) mojgan_opt('defaultCover'));
    if (mojgan_image_ok($default)) {
        return mojgan_resolve($default);
    }

    return '';
}

/* ================================================================
 *  متن و متاداده
 * ================================================================ */

/**
 * برآورد زمان مطالعه (دقیقه) — ۲۲۰ واژه در دقیقه
 */
function mojgan_reading_time($content): int
{
    $text = (string) $content->text;
    $text = preg_replace('#```.*?```#s', ' ', $text) ?? $text;
    $text = preg_replace('#`[^`]*`#', ' ', $text) ?? $text;
    $text = preg_replace('#!\[[^\]]*\]\([^)]*\)#', ' ', $text) ?? $text;
    $text = preg_replace('#<[^>]+>#', ' ', $text) ?? $text;

    $words = preg_split('/\s+/u', trim($text), -1, PREG_SPLIT_NO_EMPTY);
    $count = is_array($words) ? count($words) : 0;

    if ($count === 0) {
        return 1;
    }

    return max(1, (int) ceil($count / 220));
}

/**
 * چکیدهٔ تمیز با احترام به مرز واژه‌ها
 */
function mojgan_excerpt($content, int $words = 26): string
{
    $text = trim((string) $content->excerpt);
    if ($text === '') {
        $text = trim((string) $content->plainExcerpt);
    }

    $text = trim(preg_replace('/\s+/u', ' ', strip_tags($text)) ?? '');
    $parts = preg_split('/\s+/u', $text, $words + 1, PREG_SPLIT_NO_EMPTY);

    if (is_array($parts) && count($parts) > $words) {
        array_pop($parts);
        return implode(' ', $parts) . '…';
    }

    return $text;
}

/* ================================================================
 *  شمارش بازدید — ستون views جدول محتوا
 *  نمایش آمار فقط در صفحهٔ نوشته (خواستهٔ کاربر)؛ شمارش از همهٔ صفحات تکی
 * ================================================================ */

/**
 * اطمینان از وجود ستون views
 */
function mojgan_views_ready(): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }

    $ready = false;

    try {
        $db = \Typecho\Db::get();

        try {
            $db->fetchRow($db->select('table.contents.views')->from('table.contents')->limit(1));
            $columnExists = true;
        } catch (\Throwable $e) {
            $columnExists = false;
        }

        if (!$columnExists) {
            $prefix = $db->getPrefix();
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT DEFAULT 0');
        }

        $ready = true;
    } catch (\Throwable $e) {
        $ready = false;
    }

    return $ready;
}

/**
 * تعداد بازدید نوشته
 */
function mojgan_views($archive): int
{
    try {
        return max(0, (int) $archive->views);
    } catch (\Throwable $e) {
        return 0;
    }
}

/**
 * شمارش بازدید صفحات تکی با فاصلهٔ ضد تکرار (کوکی)
 */
function mojgan_count_view($archive): void
{
    // اگر پلاگین ViewsCounter فعال است، پوسته کنار می‌کشد
    $activated = \Widget\Options::alloc()->plugins;
    if (is_array($activated) && isset($activated['activated']['ViewsCounter'])) {
        return;
    }

    if (!mojgan_on('countLoggedInViews', '0') && \Widget\User::alloc()->hasLogin()) {
        return;
    }

    if (!$archive instanceof \Widget\Archive || !$archive->is('single')) {
        return;
    }

    // فقط نوشته‌ها شمرده می‌شوند، نه برگه‌ها
    if (!$archive->is('post')) {
        return;
    }

    $cid = (int) $archive->cid;
    if ($cid < 1) {
        return;
    }

    $interval = (int) mojgan_opt('viewsInterval', '3600');

    if ($interval > 0) {
        $viewed = (string) \Typecho\Cookie::get('mojganViews', '');
        $ids = $viewed === '' ? [] : explode(',', $viewed);

        if (in_array((string) $cid, $ids, true)) {
            return;
        }

        $ids[] = (string) $cid;
        if (count($ids) > 100) {
            $ids = array_slice($ids, -100);
        }

        \Typecho\Cookie::set('mojganViews', implode(',', $ids), time() + $interval);
    }

    if (!mojgan_views_ready()) {
        return;
    }

    try {
        $db = \Typecho\Db::get();
        $db->query(
            $db->update('table.contents')
                ->expression('views', 'views + 1')
                ->where('cid = ?', $cid)
        );
    } catch (\Throwable $e) {
        // خطای شمارش نباید نمایش صفحه را متوقف کند
    }
}

/* ================================================================
 *  پسند (لایک) — ستون likes جدول محتوا + نقطهٔ پایانی AJAX
 *  دکمهٔ پسند فقط در صفحهٔ نوشته رندر می‌شود
 * ================================================================ */

/**
 * اطمینان از وجود ستون likes
 */
function mojgan_likes_ready(): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }

    $ready = false;

    try {
        $db = \Typecho\Db::get();

        try {
            $db->fetchRow($db->select('table.contents.likes')->from('table.contents')->limit(1));
            $columnExists = true;
        } catch (\Throwable $e) {
            $columnExists = false;
        }

        if (!$columnExists) {
            $prefix = $db->getPrefix();
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `likes` INT DEFAULT 0');
        }

        $ready = true;
    } catch (\Throwable $e) {
        $ready = false;
    }

    return $ready;
}

/**
 * تعداد پسند نوشته
 */
function mojgan_likes($archive): int
{
    if (!mojgan_likes_ready()) {
        return 0;
    }
    try {
        return max(0, (int) $archive->likes);
    } catch (\Throwable $e) {
        return 0;
    }
}

/**
 * شناسه‌های پسندیده‌شدهٔ این بازدیدکننده (کوکی mojganLikes)
 */
function mojgan_user_likes(): array
{
    $raw = (string) \Typecho\Cookie::get('mojganLikes', '');
    if ($raw === '') {
        return [];
    }

    $ids = [];
    foreach (explode(',', $raw) as $id) {
        $id = trim($id);
        if ($id !== '' && ctype_digit($id) && !in_array($id, $ids, true)) {
            $ids[] = $id;
        }
    }
    return $ids;
}

/**
 * آیا این بازدیدکننده این نوشته را پسندیده؟
 */
function mojgan_is_liked(int $cid): bool
{
    return $cid > 0 && in_array((string) $cid, mojgan_user_likes(), true);
}

/**
 * خروجی JSON و پایان درخواست
 */
function mojgan_json(array $payload, int $status = 200): void
{
    $response = \Typecho\Response::getInstance();
    $response->setStatus($status);
    $response->setContentType('application/json');
    $response->addResponder(function () use ($payload): void {
        echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    });
    $response->respond();
}

/**
 * پردازش درخواست پسند — POST با پارامتر mojganLike=<cid>
 * پاسخ: {"ok":true,"likes":N,"liked":bool}
 */
function mojgan_handle_like($request): void
{
    $cid = (int) (string) $request->get('mojganLike');

    if ($cid < 1) {
        mojgan_json(['ok' => false, 'error' => 'bad-request'], 400);
        return;
    }

    // جلوگیری ساده از CSRF
    $siteHost = (string) parse_url((string) \Widget\Options::alloc()->siteUrl, PHP_URL_HOST);
    $referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');
    if ($referer !== '' && $siteHost !== '' && stripos($referer, $siteHost) === false) {
        mojgan_json(['ok' => false, 'error' => 'cross-origin'], 403);
        return;
    }

    if (!mojgan_likes_ready()) {
        mojgan_json(['ok' => false, 'error' => 'db-error'], 500);
        return;
    }

    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.type', 'table.contents.status', 'table.contents.password', 'table.contents.created')
                ->from('table.contents')
                ->where('table.contents.cid = ?', $cid)
        );

        // فقط نوشته‌های منتشرشدهٔ بدون رمز قابل پسند هستند
        $valid = is_array($row)
            && $row['status'] === 'publish'
            && $row['type'] === 'post'
            && empty($row['password'])
            && (int) $row['created'] <= \Widget\Options::alloc()->time;

        if (!$valid) {
            mojgan_json(['ok' => false, 'error' => 'not-found'], 404);
            return;
        }

        $likedIds = mojgan_user_likes();
        $wasLiked = in_array((string) $cid, $likedIds, true);

        if ($wasLiked) {
            $likedIds = array_values(array_filter(
                $likedIds,
                static function (string $id) use ($cid): bool {
                    return $id !== (string) $cid;
                }
            ));
            $delta = -1;
        } else {
            $likedIds[] = (string) $cid;
            $delta = 1;
        }

        if (count($likedIds) > 200) {
            $likedIds = array_slice($likedIds, -200);
        }
        \Typecho\Cookie::set('mojganLikes', implode(',', $likedIds), time() + 31536000);

        $current = (int) $db->fetchObject(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        )->likes;

        if ($delta > 0 || $current > 0) {
            $db->query(
                $db->update('table.contents')
                    ->expression('likes', $delta > 0 ? 'likes + 1' : 'likes - 1')
                    ->where('table.contents.cid = ?', $cid)
            );
        }

        $newLikes = (int) $db->fetchObject(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        )->likes;

        mojgan_json([
            'ok'    => true,
            'likes' => $newLikes,
            'liked' => !$wasLiked,
        ]);
    } catch (\Throwable $e) {
        mojgan_json(['ok' => false, 'error' => 'server-error'], 500);
    }
}

/**
 * راه‌انداز پوسته — قلاب شمارش بازدید + نقطهٔ پایانی AJAX پسند
 */
function themeInit(\Widget\Archive $archive)
{
    \Typecho\Plugin::factory('Widget\Archive')->beforeRender = 'mojgan_count_view';

    if ($archive->request->isPost() && $archive->request->is('mojganLike')) {
        mojgan_handle_like($archive->request);
    }
}

/* ================================================================
 *  آمار کلی سایت
 * ================================================================ */

function mojgan_stats(): array
{
    $posts = 0;
    $comments = 0;
    $views = 0;

    try {
        $db = \Typecho\Db::get();
        $posts = (int) $db->fetchObject(
            $db->select(['COUNT(table.contents.cid)' => 'num'])
                ->from('table.contents')
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.status = ?', 'publish')
        )->num;

        $comments = (int) $db->fetchObject(
            $db->select(['COUNT(table.comments.coid)' => 'num'])
                ->from('table.comments')
                ->where('table.comments.type = ?', 'comment')
                ->where('table.comments.status = ?', 'approved')
        )->num;

        if (mojgan_views_ready()) {
            $views = (int) $db->fetchObject(
                $db->select(['COALESCE(SUM(table.contents.views), 0)' => 'total'])
                    ->from('table.contents')
                    ->where('table.contents.status = ?', 'publish')
            )->total;
        }
    } catch (\Throwable $e) {
        // خطای دیتابیس نباید سایت را از کار بیندازد
    }

    return ['posts' => $posts, 'comments' => $comments, 'views' => $views];
}

/* ================================================================
 *  ویجت‌های ستون کناری
 * ================================================================ */

if (!class_exists('MojganRecentPosts')) {
    class MojganRecentPosts extends \Widget\Base\Contents
    {
        public function execute()
        {
            $this->parameter->setDefault(['pageSize' => 5]);
            $limit = max(1, (int) $this->parameter->pageSize);

            $this->db->fetchAll($this->select()
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', $this->options->time)
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.password IS NULL OR table.contents.password = \'\'')
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit($limit), [$this, 'push']);
        }
    }
}

if (!class_exists('MojganPopularPosts')) {
    class MojganPopularPosts extends \Widget\Base\Contents
    {
        public function execute()
        {
            $this->parameter->setDefault(['pageSize' => 5]);
            $limit = max(1, (int) $this->parameter->pageSize);

            $basis = 'views';
            if (!mojgan_views_ready()) {
                $basis = 'comments';
            } else {
                try {
                    $total = (int) $this->db->fetchObject(
                        $this->db->select(['COALESCE(SUM(table.contents.views), 0)' => 'total'])
                            ->from('table.contents')
                            ->where('table.contents.type = ?', 'post')
                            ->where('table.contents.status = ?', 'publish')
                    )->total;
                    if ($total < 1) {
                        $basis = 'comments';
                    }
                } catch (\Throwable $e) {
                    $basis = 'comments';
                }
            }

            $select = $this->select('table.contents.*')
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', $this->options->time)
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.password IS NULL OR table.contents.password = \'\'')
                ->order(
                    $basis === 'views' ? 'table.contents.views' : 'table.contents.commentsNum',
                    \Typecho\Db::SORT_DESC
                )
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit($limit);

            $this->db->fetchAll($select, [$this, 'push']);
        }
    }
}

/**
 * آخرین دیدگاه‌ها: متنِ خود دیدگاه + پیوند به نوشتهٔ مربوط
 */
function mojgan_recent_comments(int $limit = 5): array
{
    $items = [];

    try {
        $db = \Typecho\Db::get();
        $prefix = $db->getPrefix();
        $rating = (string) (\Widget\Options::alloc()->commentsAvatarRating ?? 'g');

        $rows = $db->fetchAll(
            'SELECT c.coid, c.author AS commentAuthor, c.mail AS commentMail,'
            . ' c.text AS commentText, c.created AS commentCreated, t.*'
            . ' FROM `' . $prefix . 'comments` c'
            . ' LEFT JOIN `' . $prefix . 'contents` t ON t.cid = c.cid'
            . ' WHERE c.status = \'approved\' AND c.type = \'comment\''
            . ' AND t.status = \'publish\' AND t.type IN (\'post\', \'page\')'
            . ' ORDER BY c.created DESC LIMIT ' . max(1, $limit)
        );

        foreach ((array) $rows as $row) {
            if (!empty($row['password'])) {
                continue;
            }

            $link = '#';
            try {
                $link = (string) \Typecho\Router::url($row['type'], $row, \Widget\Options::alloc()->siteUrl);
            } catch (\Throwable $e) {
                $link = '#';
            }
            $link .= '#comment-' . (int) $row['coid'];

            $items[] = [
                'coid'    => (int) $row['coid'],
                'author'  => (string) $row['commentAuthor'],
                'mail'    => trim((string) $row['commentMail']),
                'text'    => trim(strip_tags((string) $row['commentText'])),
                'created' => (int) $row['commentCreated'],
                'title'   => (string) $row['title'],
                'link'    => $link,
            ];
        }
    } catch (\Throwable $e) {
        // بی‌خطر
    }

    return $items;
}

/* ================================================================
 *  سایدبار — نمایش در کدام صفحه‌ها؟
 *  (آرشیو/جستجو/دسته/برچسب طبق خواستهٔ کاربر بدون سایدبار است)
 * ================================================================ */
function mojgan_show_sidebar($archive): bool
{
    if ($archive->is('index')) {
        return mojgan_on('sidebarIndex', '1');
    }

    if ($archive->is('single')) {
        return mojgan_on('sidebarPost', '1');
    }

    // دسته، برچسب، جستجو، نویسنده و آرشیو — پیش‌فرض بدون سایدبار
    return mojgan_on('sidebarArchive', '0');
}

/**
 * انتخاب ویجت‌های فعال از تنظیمات (چک‌باکس)
 */
function mojgan_widgets(): array
{
    $selected = \Widget\Options::alloc()->sidebarWidgets ?? null;

    if (!is_array($selected)) {
        // پیش‌فرض: همه فعال
        return ['recent', 'popular', 'categories', 'comments', 'tags'];
    }

    $valid = [];
    foreach (['recent', 'popular', 'categories', 'comments', 'tags'] as $widget) {
        if (in_array($widget, $selected, true)) {
            $valid[] = $widget;
        }
    }

    return $valid;
}

/* ================================================================
 *  فهرست برگه‌های منتشرشده — برای چک‌باکس‌های منوی بالا و پایین
 * ================================================================ */

/**
 * فهرست برگه‌های منتشرشده به‌صورت [cid => عنوان]
 */
function mojgan_pages_options(): array
{
    $options = [];

    try {
        $db = \Typecho\Db::get();
        $rows = $db->fetchAll(
            $db->select('table.contents.cid', 'table.contents.title')
                ->from('table.contents')
                ->where('table.contents.type = ?', 'page')
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.password IS NULL OR table.contents.password = \'\'')
                ->order('table.contents.order', \Typecho\Db::SORT_ASC)
        );

        foreach ((array) $rows as $row) {
            $title = trim(strip_tags((string) $row['title']));
            if ($title !== '') {
                $options[(string) (int) $row['cid']] = $title;
            }
        }
    } catch (\Throwable $e) {
        // بی‌خطر — فرم تنظیمات بدون فهرست برگه‌ها رندر می‌شود
    }

    return $options;
}

/**
 * برگه‌های انتخاب‌شدهٔ یک منو — null یعنی تنظیم ذخیره نشده (رفتار پیش‌فرض: همه)
 *
 * @return array|null فهرست cid های انتخابی یا null
 */
function mojgan_selected_pages(string $name): ?array
{
    $value = \Widget\Options::alloc()->{$name};

    if (!is_array($value)) {
        return null;
    }

    $selected = [];

    foreach ((array) $value as $cid) {
        $cid = trim((string) $cid);
        if ($cid !== '' && ctype_digit($cid)) {
            $selected[] = $cid;
        }
    }

    return $selected;
}

/**
 * آیا این برگه در این منو نمایش داده شود؟ (null = همه نمایش داده شوند)
 */
function mojgan_page_in_menu($pages, string $menu): bool
{
    $selected = mojgan_selected_pages($menu);

    if ($selected === null) {
        return true;
    }

    return in_array((string) (int) $pages->cid, $selected, true);
}

/* ================================================================
 *  عناوین تصادفی برای نوار متحرک (تیکر) سربرگ
 * ================================================================ */

/**
 * نوشته‌های تازه → ترتیب تصادفی → پیوند و عنوان برای تیکر
 *
 * @return array<int, array{title:string, url:string}>
 */
function mojgan_ticker_posts(int $fetch = 20, int $limit = 10): array
{
    $items = [];

    try {
        $db = \Typecho\Db::get();
        $rows = $db->fetchAll(
            $db->select('table.contents.*')
                ->from('table.contents')
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', \Widget\Options::alloc()->time)
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.password IS NULL OR table.contents.password = \'\'')
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit(max(1, $fetch))
        );

        shuffle($rows);

        foreach ((array) array_slice($rows, 0, max(1, $limit)) as $row) {
            $title = trim(strip_tags((string) $row['title']));

            if ($title === '') {
                continue;
            }

            try {
                $url = (string) \Typecho\Router::url($row['type'], $row, \Widget\Options::alloc()->siteUrl);
            } catch (\Throwable $e) {
                continue;
            }

            $items[] = ['title' => $title, 'url' => $url];
        }
    } catch (\Throwable $e) {
        // بی‌خطر — بدون تیکر رندر می‌شود
    }

    return $items;
}

/* ================================================================
 *  آیکون‌های خطی
 * ================================================================ */

function mojgan_icon(string $name, int $size = 18): string
{
    $paths = [
        'heart'     => '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>',
        'comment'   => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>',
        'eye'       => '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle>',
        'search'    => '<circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line>',
        'home'      => '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline>',
        'arrow-up'  => '<line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline>',
        'arrow-left' => '<line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline>',
        'arrow-right' => '<line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline>',
        'tag'       => '<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line>',
        'clock'     => '<circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline>',
        'user'      => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle>',
        'folder'    => '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>',
        'flame'     => '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"></path>',
        'calendar'  => '<rect x="3" y="4" width="18" height="18" rx="2.5"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line>',
        'link'      => '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>',
        'close'     => '<line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>',
        'menu'      => '<line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line>',
        'telegram'  => '<path d="M21.9 4.6l-3.1 14.7c-.2 1-.8 1.3-1.7.8l-4.7-3.5-2.3 2.2c-.25.25-.47.47-.94.47l.33-4.8L18.2 6.6c.37-.33-.08-.52-.58-.19L6.9 13.7l-4.6-1.44c-1-.31-1-1 .21-1.48L20.6 3.1c.83-.3 1.56.2 1.3 1.5z" fill="currentColor" stroke="none"></path>',
        'rss'       => '<path d="M6.18 15.64a2.18 2.18 0 1 1 0 4.36 2.18 2.18 0 0 1 0-4.36zM4 4.44v2.83c7.03 0 12.73 5.7 12.73 12.73h2.83c0-8.59-6.97-15.56-15.56-15.56zm0 5.66v2.83c3.9 0 7.07 3.17 7.07 7.07h2.83c0-5.47-4.43-9.9-9.9-9.9z" fill="currentColor" stroke="none"></path>',
        'newspaper' => '<path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-4 0V9h2"></path><line x1="10" y1="7" x2="18" y2="7"></line><line x1="10" y1="11" x2="18" y2="11"></line><line x1="10" y1="15" x2="18" y2="15"></line>',
        'pen'       => '<path d="M12 19l7-7 3 3-7 7-3-3z"></path><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path><line x1="2" y1="2" x2="9.586" y2="9.586"></line><circle cx="11" cy="11" r="2"></circle>',
        'chevron-down' => '<polyline points="6 9 12 15 18 9"></polyline>',
    ];

    $path = $paths[$name] ?? $paths['newspaper'];

    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
}

/* ================================================================
 *  آواتار — تصویر یا حرف آغازین
 * ================================================================ */

function mojgan_avatar_html(string $name, ?string $url = null, int $size = 44, string $extra = ''): string
{
    $url = trim((string) $url);
    $cls = 'avatar' . ($extra !== '' ? ' ' . $extra : '');

    if ($url !== '' && preg_match('#^(https?://|/)#i', $url)) {
        return '<span class="' . $cls . '" style="--avatar-size:' . $size . 'px">'
            . '<img src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" alt="' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '" loading="lazy" />'
            . '</span>';
    }

    $initial = mb_substr(trim($name) !== '' ? $name : '؟', 0, 1, 'UTF-8');

    return '<span class="' . $cls . ' avatar-fallback" style="--avatar-size:' . $size . 'px" aria-hidden="true">'
        . '<span>' . htmlspecialchars($initial, ENT_QUOTES, 'UTF-8') . '</span>'
        . '</span>';
}

/**
 * آواتار همه‌جای سایت (نویسنده و دیدگاه‌ها): تنظیم پوسته ← گراواتار ← حرف آغازین
 */
function mojgan_comment_avatar(string $name, ?string $mail = null, int $size = 44, string $extra = ''): string
{
    $custom = trim((string) mojgan_opt('authorAvatar'));
    if (mojgan_image_ok($custom)) {
        return mojgan_avatar_html($name, mojgan_resolve($custom), $size, $extra);
    }

    $mail = trim((string) $mail);
    if (filter_var($mail, FILTER_VALIDATE_EMAIL)) {
        // گراواتار با d=404 تا نبودِ حساب به حرف آغازین بیفتد (در مرورگر)
        $rating = (string) (\Widget\Options::alloc()->commentsAvatarRating ?? 'g');
        $url = \Typecho\Common::gravatarUrl($mail, $size * 2, $rating, '404', true);
        $initial = mb_substr(trim($name) !== '' ? $name : '؟', 0, 1, 'UTF-8');
        $cls = 'avatar' . ($extra !== '' ? ' ' . $extra : '');

        return '<span class="' . $cls . '" style="--avatar-size:' . $size . 'px"'
            . ' data-avatar-initial="' . htmlspecialchars($initial, ENT_QUOTES, 'UTF-8') . '">'
            . '<img src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" alt="' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '" loading="lazy" referrerpolicy="no-referrer" />'
            . '</span>';
    }

    return mojgan_avatar_html($name, null, $size, $extra);
}

/**
 * آواتار نویسندهٔ نوشته — از همان زنجیرهٔ اولویت آواتار سایت
 */
function mojgan_author_avatar($archive, int $size = 44): string
{
    return mojgan_comment_avatar(
        (string) $archive->author->screenName,
        trim((string) ($archive->author->mail ?? '')),
        $size
    );
}

/* ================================================================
 *  تنظیمات پوسته (پیشخوان ← ظاهر ← تنظیمات پوسته)
 * ================================================================ */

function themeConfig($form)
{
    $yes = _t('نمایش');
    $no = _t('پنهان');

    /* ---------- هویت و ظاهر ---------- */

    $logoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'logoUrl',
        null,
        null,
        _t('نشانی لوگوی سایت'),
        _t('در صورت خالی‌بودن، نام سایت با نشان مژگان نمایش داده می‌شود.')
    );
    $form->addInput($logoUrl->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $showDatebar = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showDatebar',
        ['1' => $yes, '0' => $no],
        '1',
        _t('نوار تاریخ شمسی زیر سربرگ'),
        _t('نمایش تاریخ و ساعت جاری سایت زیر نوار منو.')
    );
    $form->addInput($showDatebar);

    $tickerSpeed = new \Typecho\Widget\Helper\Form\Element\Select(
        'tickerSpeed',
        [
            '15' => _t('خیلی آهسته'),
            '30' => _t('آهسته (پیشنهادی)'),
            '45' => _t('معمولی'),
            '60' => _t('سریع'),
        ],
        '30',
        _t('سرعت نوار متحرک عناوین'),
        _t('سرعت چرخش عنوان‌های تازه در نوار زیر سربرگ بر حسب پیکسل بر ثانیه؛ هرچه عدد کمتر باشد حرکت آرام‌تر است. مقدار پیش‌فرض حدوداً نصف سرعت پیشین پوسته است.')
    );
    $form->addInput($tickerSpeed);

    $defaultCover = new \Typecho\Widget\Helper\Form\Element\Text(
        'defaultCover',
        null,
        null,
        _t('تصویر پیش‌فرض کارت‌ها'),
        _t('برای نوشته‌های بدون تصویر شاخص و بدون تصویر در متن؛ اگر خالی بماند، قاب خنثی نمایش داده می‌شود.')
    );
    $form->addInput($defaultCover->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    /* ---------- چیدمان صفحهٔ نخست ---------- */

    $featuredCount = new \Typecho\Widget\Helper\Form\Element\Select(
        'indexListStart',
        [
            '3' => _t('سه نوشتهٔ نخست (پیشنهادی)'),
            '1' => _t('فقط یک نوشتهٔ شاخص'),
            '0' => _t('بدون کارت؛ همه به‌صورت فهرست'),
        ],
        '3',
        _t('کارت‌های بخش بالای صفحهٔ نخست'),
        _t('یک نوشتهٔ شاخص بزرگ + دو کارت کوچک؛ سپس ادامهٔ نوشته‌ها به‌صورت فهرست. در حالت «فقط یک شاخص» و «بدون کارت»، سرصفحهٔ جداکنندهٔ «مطالب بیشتر» نمایش داده نمی‌شود تا فهرست یکدست بماند.')
    );
    $form->addInput($featuredCount);

    /* ---------- منوها ---------- */

    $navCategoriesMode = new \Typecho\Widget\Helper\Form\Element\Radio(
        'navCategoriesMode',
        [
            'flat'     => _t('آیتم‌های جداگانه (پیشنهادی)'),
            'dropdown' => _t('منوی آبشاری'),
        ],
        'flat',
        _t('نمایش دسته‌بندی‌ها در منوی بالا'),
        _t('دسته‌بندی‌ها هرکدام به‌صورت یک آیتم مستقل در نوار منو نمایش داده شوند یا در یک زیرمنوی بازشوی «دسته‌بندی‌ها» جمع شوند.')
    );
    $form->addInput($navCategoriesMode);

    /* چک‌باکس‌های برگه‌ها — فقط وقتی برگه‌ای موجود است */
    $pagesOptions = mojgan_pages_options();

    if ($pagesOptions !== []) {
        $pageDefaults = array_keys($pagesOptions);

        $headerPages = new \Typecho\Widget\Helper\Form\Element\Checkbox(
            'headerPages',
            $pagesOptions,
            $pageDefaults,
            _t('برگه‌های منوی بالا'),
            _t('تیک برگه‌هایی که باید در نوار منوی بالای سایت نمایش داده شوند؛ در حالت پیش‌فرض همهٔ برگه‌ها انتخاب شده‌اند. برداشتن تیک، برگه را از منوی بالا پنهان می‌کند.')
        );
        $form->addInput($headerPages);

        $footerPages = new \Typecho\Widget\Helper\Form\Element\Checkbox(
            'footerPages',
            $pagesOptions,
            $pageDefaults,
            _t('برگه‌های منوی پایین (فوتر)'),
            _t('تیک برگه‌هایی که باید در بخش «دسترسی سریع» فوتر نمایش داده شوند؛ در حالت پیش‌فرض همهٔ برگه‌ها انتخاب شده‌اند.')
        );
        $form->addInput($footerPages);
    }

    /* ---------- ستون کناری ---------- */

    $sidebarIndex = new \Typecho\Widget\Helper\Form\Element\Radio(
        'sidebarIndex',
        ['1' => $yes, '0' => $no],
        '1',
        _t('ستون کناری در صفحهٔ نخست'),
        _t('نمایش ستون کناری در صفحهٔ اصلی (ایندکس).')
    );
    $form->addInput($sidebarIndex);

    $sidebarPost = new \Typecho\Widget\Helper\Form\Element\Radio(
        'sidebarPost',
        ['1' => $yes, '0' => $no],
        '1',
        _t('ستون کناری در صفحهٔ نوشته و برگه'),
        _t('نمایش ستون کناری در صفحات تکی.')
    );
    $form->addInput($sidebarPost);

    $sidebarArchive = new \Typecho\Widget\Helper\Form\Element\Radio(
        'sidebarArchive',
        ['0' => _t('بدون سایدبار (پیشنهادی)'), '1' => $yes],
        '0',
        _t('ستون کناری در دسته/برچسب/جستجو'),
        _t('صفحات فهرستی به‌صورت پیش‌فرض تمام‌عرض و دوستونه هستند.')
    );
    $form->addInput($sidebarArchive);

    $sidebarWidgets = new \Typecho\Widget\Helper\Form\Element\Checkbox(
        'sidebarWidgets',
        [
            'recent'     => _t('جدیدترین پست‌ها'),
            'popular'    => _t('پربازدیدترین پست‌ها'),
            'categories' => _t('دسته‌بندی‌ها'),
            'comments'   => _t('آخرین دیدگاه‌ها'),
            'tags'       => _t('ابر برچسب‌ها'),
        ],
        ['recent', 'popular', 'categories', 'comments', 'tags'],
        _t('ویجت‌های ستون کناری'),
        _t('هر ویجت را که انتخاب کنید در ستون کناری نمایش داده می‌شود؛ برداشتن تیک، آن را پنهان می‌کند.')
    );
    $form->addInput($sidebarWidgets);

    /* ---------- بازدید و پسند ---------- */

    $showViews = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showViews',
        ['1' => $yes, '0' => $no],
        '1',
        _t('شمارندهٔ بازدید (فقط در نوشته‌ها)'),
        _t('نمایش تعداد بازدید فقط در صفحهٔ نوشته؛ آمار در دیتابیس ذخیره می‌شود.')
    );
    $form->addInput($showViews);

    $showLikes = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showLikes',
        ['1' => $yes, '0' => $no],
        '1',
        _t('دکمهٔ پسندیدن (فقط در نوشته‌ها)'),
        _t('نمایش دکمهٔ پسند فقط در صفحهٔ نوشته؛ با کلیک دوباره، پسند برداشته می‌شود.')
    );
    $form->addInput($showLikes);

    $countLoggedInViews = new \Typecho\Widget\Helper\Form\Element\Radio(
        'countLoggedInViews',
        ['0' => _t('شمرده نشود (پیشنهادی)'), '1' => _t('شمرده شود')],
        '0',
        _t('بازدید کاربران واردشده'),
        _t('آمار بازدید مدیر و اعضای واردشده ثبت شود یا نه.')
    );
    $form->addInput($countLoggedInViews);

    $viewsInterval = new \Typecho\Widget\Helper\Form\Element\Select(
        'viewsInterval',
        [
            '3600'   => _t('۱ ساعت (پیشنهادی)'),
            '21600'  => _t('۶ ساعت'),
            '86400'  => _t('۲۴ ساعت'),
            '0'      => _t('بدون فاصله؛ هر بازدید شمرده شود'),
        ],
        '3600',
        _t('فاصلهٔ شمارش بازدید مکرر'),
        _t('بازدید تکراری یک نوشته در این بازه فقط یک بار شمرده می‌شود.')
    );
    $form->addInput($viewsInterval);

    /* ---------- صفحهٔ نوشته ---------- */

    $showReadingTime = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showReadingTime',
        ['1' => $yes, '0' => $no],
        '1',
        _t('زمان مطالعه و نوار پیشرفت'),
        _t('نمایش برآورد دقیقهٔ مطالعه در نوشته و نوار پیشرفت خواندن در بالای صفحه.')
    );
    $form->addInput($showReadingTime);

    $showRelated = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showRelated',
        ['1' => $yes, '0' => $no],
        '1',
        _t('مطالب مرتبط'),
        _t('در پایان هر نوشته، سه نوشتهٔ مرتبط بر پایهٔ برچسب‌ها نمایش داده می‌شود.')
    );
    $form->addInput($showRelated);

    $showShare = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showShare',
        ['1' => $yes, '0' => $no],
        '1',
        _t('اشتراک‌گذاری نوشته'),
        _t('دکمه‌های اشتراک‌گذاری تلگرام و کپی لینک در پایین نوشته.')
    );
    $form->addInput($showShare);

    $showAuthorBox = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showAuthorBox',
        ['1' => $yes, '0' => $no],
        '1',
        _t('باکس نویسنده'),
        _t('نمایش کارت نویسنده با توضیحات در پایین هر نوشته.')
    );
    $form->addInput($showAuthorBox);

    $authorAvatar = new \Typecho\Widget\Helper\Form\Element\Text(
        'authorAvatar',
        null,
        null,
        _t('آواتار سایت (نشانی تصویر)'),
        _t('اولویت با این تصویر است و همه‌جای سایت به کار می‌رود: باکس نویسنده، کارت‌ها، فهرست دیدگاه‌ها و ویجت آخرین دیدگاه‌ها. خالی بماند تا گراواتار و در نبودِ آن، حرف آغازین نام نمایش داده شود.')
    );
    $form->addInput($authorAvatar->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $authorBio = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'authorBio',
        null,
        null,
        _t('توضیحات نویسنده'),
        _t('چند جمله دربارهٔ نویسنده برای باکس پایین نوشته‌ها؛ خالی بماند تا توضیحات سایت نمایش داده شود.')
    );
    $form->addInput($authorBio);

    /* ---------- شبکه‌های اجتماعی ---------- */

    $socialTelegram = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialTelegram', null, null, _t('نشانی تلگرام'), _t('مثال: https://t.me/example')
    );
    $form->addInput($socialTelegram->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $socialGithub = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialGithub', null, null, _t('نشانی گیت‌هاب'), _t('مثال: https://github.com/example')
    );
    $form->addInput($socialGithub->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $socialInstagram = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialInstagram', null, null, _t('نشانی اینستاگرام'), _t('مثال: https://instagram.com/example')
    );
    $form->addInput($socialInstagram->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    /* ---------- فوتر ---------- */

    $footerText = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'footerText',
        null,
        null,
        _t('متن دلخواه فوتر'),
        _t('در صورت خالی‌بودن، توضیحات سایت نمایش داده می‌شود.')
    );
    $form->addInput($footerText);
}

/* ================================================================
 *  فیلد اختصاصی «تصویر شاخص» در ویرایشگر
 * ================================================================ */

function themeFields($layout)
{
    $thumb = new \Typecho\Widget\Helper\Form\Element\Text(
        'thumb',
        null,
        null,
        _t('تصویر شاخص'),
        _t('نشانی تصویر شاخص این نوشته. در صفحهٔ نوشته بالای عنوان می‌نشیند و در کارت‌ها و فهرست‌های سایت به‌عنوان کاور به کار می‌رود؛ اگر خالی بماند، نخستین تصویر متن استفاده می‌شود.')
    );
    $layout->addItem($thumb);
}

/* ================================================================
 *  ساختار دیدگاه‌ها
 * ================================================================ */

function threadedComments($comments, $options)
{
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
    ?>
    <li id="li-<?php $comments->theId(); ?>" class="comment-item<?php
        if ($comments->levels > 0) {
            echo ' comment-child';
            $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
        } else {
            echo ' comment-parent';
        }
        $comments->alt(' comment-odd', ' comment-even');
        echo $commentClass;
    ?>">
        <div id="<?php $comments->theId(); ?>" class="comment-inner">
            <div class="comment-avatar-wrap">
                <?php echo mojgan_comment_avatar((string) $comments->author, (string) ($comments->mail ?? ''), 48); ?>
            </div>
            <div class="comment-main">
                <div class="comment-meta">
                    <cite class="comment-author" itemprop="creator" itemscope itemtype="http://schema.org/Person">
                        <?php $comments->author(); ?>
                        <?php if ($comments->authorId && $comments->authorId == $comments->ownerId): ?>
                            <span class="comment-badge-owner"><?php _e('نویسنده'); ?></span>
                        <?php endif; ?>
                    </cite>
                    <span class="comment-time">
                        <a href="<?php $comments->permalink(); ?>" itemprop="url">
                            <time datetime="<?php echo date('c', (int) $comments->created); ?>" itemprop="commentTime"><?php echo mojgan_date((int) $comments->created); ?></time>
                        </a>
                    </span>
                    <?php if ($comments->status == 'waiting'): ?>
                        <span class="comment-badge-waiting"><?php _e('در انتظار تأیید'); ?></span>
                    <?php endif; ?>
                    <span class="comment-reply">
                        <?php $comments->reply(_t('پاسخ')); ?>
                    </span>
                </div>
                <div class="comment-content" itemprop="commentText">
                    <?php $comments->content(); ?>
                </div>
            </div>
        </div>
        <?php if ($comments->children) { ?>
            <div class="comment-children">
                <?php $comments->threadedComments($options); ?>
            </div>
        <?php } ?>
    </li>
    <?php
}
