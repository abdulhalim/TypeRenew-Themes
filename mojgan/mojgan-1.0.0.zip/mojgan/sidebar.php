<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$widgets = mojgan_widgets();
?>

<aside class="sidebar" role="complementary" aria-label="<?php _e('ستون کناری'); ?>">

    <section class="widget widget-search">
        <h2 class="widget-title"><?php echo mojgan_icon('search', 15); ?><?php _e('جستجو'); ?></h2>
        <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="widget-search-form">
            <input type="search" name="s" placeholder="<?php _e('جستجو در نوشته‌ها…'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" value="<?php echo htmlspecialchars((string) ($this->request->keywords ?? $this->request->s ?? ''), ENT_QUOTES, 'UTF-8'); ?>" />
            <button type="submit" aria-label="<?php _e('جستجو'); ?>"><?php echo mojgan_icon('arrow-left', 15); ?></button>
        </form>
    </section>

    <?php if (in_array('recent', $widgets, true)): ?>
        <section class="widget widget-posts">
            <h2 class="widget-title"><?php echo mojgan_icon('clock', 15); ?><?php _e('جدیدترین پست‌ها'); ?></h2>
            <?php MojganRecentPosts::allocWithAlias('mojgan-recent', ['pageSize' => 5])->to($recentPosts); ?>
            <?php if ($recentPosts->have()): ?>
                <ul class="widget-post-list">
                    <?php $i = 0; while ($recentPosts->next()): $i++; ?>
                        <?php $recentCover = mojgan_card_image($recentPosts); ?>
                        <li class="widget-post-item">
                            <a href="<?php $recentPosts->permalink(); ?>" class="widget-post-link">
                                <span class="widget-post-num" aria-hidden="true"><?php echo mojgan_fa((string) $i); ?></span>
                                <span class="widget-post-thumb<?php echo $recentCover !== '' ? '' : ' cover-fallback'; ?>">
                                    <?php if ($recentCover !== ''): ?>
                                        <img src="<?php echo htmlspecialchars($recentCover, ENT_QUOTES, 'UTF-8'); ?>" alt="" loading="lazy" />
                                    <?php else: ?>
                                        <?php echo mojgan_icon('newspaper', 24); ?>
                                    <?php endif; ?>
                                </span>
                                <span class="widget-post-info">
                                    <span class="widget-post-name"><?php $recentPosts->title(); ?></span>
                                    <time class="widget-post-date"><?php echo mojgan_date((int) $recentPosts->created); ?></time>
                                </span>
                            </a>
                        </li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p class="widget-empty"><?php _e('هنوز نوشته‌ای منتشر نشده است.'); ?></p>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if (in_array('popular', $widgets, true)): ?>
        <section class="widget widget-posts widget-popular">
            <h2 class="widget-title"><?php echo mojgan_icon('flame', 15); ?><?php _e('پربازدیدترین پست‌ها'); ?></h2>
            <?php MojganPopularPosts::allocWithAlias('mojgan-popular', ['pageSize' => 5])->to($popularPosts); ?>
            <?php if ($popularPosts->have()): ?>
                <ul class="widget-post-list">
                    <?php $i = 0; while ($popularPosts->next()): $i++; ?>
                        <?php $popularCover = mojgan_card_image($popularPosts); ?>
                        <li class="widget-post-item">
                            <a href="<?php $popularPosts->permalink(); ?>" class="widget-post-link">
                                <span class="widget-post-num" aria-hidden="true"><?php echo mojgan_fa((string) $i); ?></span>
                                <span class="widget-post-thumb<?php echo $popularCover !== '' ? '' : ' cover-fallback'; ?>">
                                    <?php if ($popularCover !== ''): ?>
                                        <img src="<?php echo htmlspecialchars($popularCover, ENT_QUOTES, 'UTF-8'); ?>" alt="" loading="lazy" />
                                    <?php else: ?>
                                        <?php echo mojgan_icon('newspaper', 24); ?>
                                    <?php endif; ?>
                                </span>
                                <span class="widget-post-info">
                                    <span class="widget-post-name"><?php $popularPosts->title(); ?></span>
                                    <time class="widget-post-date">
                                        <?php echo mojgan_icon('eye', 12); ?> <?php echo mojgan_format_count(mojgan_views($popularPosts)); ?> <?php _e('بازدید'); ?>
                                    </time>
                                </span>
                            </a>
                        </li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p class="widget-empty"><?php _e('هنوز نوشته‌ای منتشر نشده است.'); ?></p>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if (in_array('categories', $widgets, true)): ?>
        <?php \Widget\Metas\Category\Rows::allocWithAlias('mojgan-sidebar')->to($sidebarCategories); ?>
        <?php if ($sidebarCategories->have()): ?>
            <section class="widget widget-categories">
                <h2 class="widget-title"><?php echo mojgan_icon('folder', 15); ?><?php _e('دسته‌بندی‌ها'); ?></h2>
                <ul class="category-list">
                    <?php while ($sidebarCategories->next()): ?>
                        <?php if ((int) $sidebarCategories->count > 0): ?>
                            <li class="category-item">
                                <a class="category-link" href="<?php $sidebarCategories->permalink(); ?>">
                                    <span class="category-name"><?php $sidebarCategories->name(); ?></span>
                                    <span class="category-count"><?php echo mojgan_fa((string) $sidebarCategories->count); ?></span>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endwhile; ?>
                </ul>
            </section>
        <?php endif; ?>
    <?php endif; ?>

    <?php if (in_array('comments', $widgets, true)): ?>
        <?php $recentComments = mojgan_recent_comments(5); ?>
        <?php if (!empty($recentComments)): ?>
            <section class="widget widget-comments">
                <h2 class="widget-title"><?php echo mojgan_icon('comment', 15); ?><?php _e('آخرین دیدگاه‌ها'); ?></h2>
                <ul class="widget-comment-list">
                    <?php foreach ($recentComments as $comment): ?>
                        <?php
                            $commentText = trim((string) $comment['text']);
                            if ($commentText === '') {
                                $commentText = _t('دیدگاهی بدون متن…');
                            }
                            $commentExcerpt = mb_substr($commentText, 0, 90, 'UTF-8') . (mb_strlen($commentText, 'UTF-8') > 90 ? '…' : '');
                            $commentAvatar = mojgan_comment_avatar($comment['author'], $comment['mail'], 34, 'widget-comment-avatar');
                        ?>
                        <li class="widget-comment-item">
                            <a class="widget-comment-link" href="<?php echo htmlspecialchars($comment['link'], ENT_QUOTES, 'UTF-8'); ?>" title="<?php echo htmlspecialchars($comment['title'], ENT_QUOTES, 'UTF-8'); ?>">
                                <?php echo $commentAvatar; ?>
                                <span class="widget-comment-body">
                                    <span class="widget-comment-text"><?php echo htmlspecialchars($commentExcerpt, ENT_QUOTES, 'UTF-8'); ?></span>
                                    <span class="widget-comment-meta">
                                        <strong><?php echo htmlspecialchars($comment['author'], ENT_QUOTES, 'UTF-8'); ?></strong>
                                        <span class="widget-comment-on"><?php _e('در'); ?> «<?php echo htmlspecialchars($comment['title'], ENT_QUOTES, 'UTF-8'); ?>»</span>
                                    </span>
                                </span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </section>
        <?php endif; ?>
    <?php endif; ?>

    <?php if (in_array('tags', $widgets, true)): ?>
        <?php \Widget\Metas\Tag\Cloud::allocWithAlias('mojgan-sidebar', ['ignoreZeroCount' => true, 'limit' => 22, 'sort' => 'count', 'desc' => true])->to($sidebarTags); ?>
        <?php if ($sidebarTags->have()): ?>
            <section class="widget widget-tags">
                <h2 class="widget-title"><?php echo mojgan_icon('tag', 15); ?><?php _e('ابر برچسب‌ها'); ?></h2>
                <div class="tag-cloud">
                    <?php while ($sidebarTags->next()): ?>
                        <a class="tag-pill" href="<?php $sidebarTags->permalink(); ?>"><?php $sidebarTags->name(); ?></a>
                    <?php endwhile; ?>
                </div>
            </section>
        <?php endif; ?>
    <?php endif; ?>

</aside>
