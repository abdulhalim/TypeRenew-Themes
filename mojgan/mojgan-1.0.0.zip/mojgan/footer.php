<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
?>

</main>

<footer class="site-footer" role="contentinfo">
    <div class="container">

        <div class="footer-top">
            <a class="footer-brand" href="<?php $this->options->siteUrl(); ?>">
                <span class="footer-mark" aria-hidden="true">
                    <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-4 0V9h2"></path>
                        <line x1="10" y1="7" x2="18" y2="7"></line>
                        <line x1="10" y1="11" x2="18" y2="11"></line>
                        <line x1="10" y1="15" x2="14" y2="15"></line>
                    </svg>
                </span>
                <span class="footer-name"><?php $this->options->title(); ?></span>
            </a>

            <div class="footer-social">
                <?php if (mojgan_opt('socialTelegram')): ?>
                    <a href="<?php echo htmlspecialchars(mojgan_resolve((string) mojgan_opt('socialTelegram')), ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" aria-label="تلگرام" title="تلگرام"><?php echo mojgan_icon('telegram', 18); ?></a>
                <?php endif; ?>
                <?php if (mojgan_opt('socialInstagram')): ?>
                    <a href="<?php echo htmlspecialchars(mojgan_resolve((string) mojgan_opt('socialInstagram')), ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" aria-label="اینستاگرام" title="اینستاگرام"><?php echo mojgan_icon('pen', 18); ?></a>
                <?php endif; ?>
                <?php if (mojgan_opt('socialGithub')): ?>
                    <a href="<?php echo htmlspecialchars(mojgan_resolve((string) mojgan_opt('socialGithub')), ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" aria-label="گیت‌هاب" title="گیت‌هاب"><?php echo mojgan_icon('link', 18); ?></a>
                <?php endif; ?>
            </div>
        </div>

        <div class="footer-grid">
            <div class="footer-about">
                <h3 class="footer-heading"><?php _e('دربارهٔ این مجله'); ?></h3>
                <?php $footerText = trim((string) mojgan_opt('footerText')); ?>
                <p><?php echo nl2br(strip_tags($footerText !== '' ? $footerText : (string) $this->options->description)); ?></p>
            </div>

            <?php /* دسترسی سریع — فقط برگه‌های تیک‌خورده در تنظیمات (پیش‌فرض: همه) */ ?>
            <?php \Widget\Contents\Page\Rows::allocWithAlias('mojgan-footer')->to($footerPages); ?>
            <?php ob_start(); ?>
            <?php while ($footerPages->next()): ?>
                <?php if (!mojgan_page_in_menu($footerPages, 'footerPages')) continue; ?>
                <li><a href="<?php $footerPages->permalink(); ?>"><?php $footerPages->title(); ?></a></li>
            <?php endwhile; ?>
            <?php $footerLinksHtml = trim((string) ob_get_clean()); ?>
            <?php if ($footerLinksHtml !== ''): ?>
                <nav class="footer-links" aria-label="<?php _e('پیوندهای فوتر'); ?>">
                    <h3 class="footer-heading"><?php _e('دسترسی سریع'); ?></h3>
                    <ul>
                        <?php echo $footerLinksHtml; ?>
                    </ul>
                </nav>
            <?php endif; ?>

            <?php $footerStats = mojgan_stats(); ?>
            <div class="footer-stats">
                <h3 class="footer-heading"><?php _e('آمار سایت'); ?></h3>
                <div class="footer-stats-grid">
                    <span class="footer-stat"><strong><?php echo mojgan_format_count($footerStats['posts']); ?></strong><span><?php _e('نوشته'); ?></span></span>
                    <span class="footer-stat"><strong><?php echo mojgan_format_count($footerStats['comments']); ?></strong><span><?php _e('دیدگاه'); ?></span></span>
                    <span class="footer-stat"><strong><?php echo mojgan_format_count($footerStats['views']); ?></strong><span><?php _e('بازدید'); ?></span></span>
                </div>
            </div>
        </div>

        <div class="footer-bottom">
            <p class="footer-copy">
                <?php
                    [$jy] = mojgan_to_jalali((int) date('Y'), (int) date('n'), (int) date('j'));
                    echo mojgan_fa((string) $jy);
                ?> &copy;
                <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>
                <span class="footer-sep" aria-hidden="true">·</span>
                <?php _e('همهٔ حقوق محفوظ است'); ?>
            </p>
            <p class="footer-credit">
                <?php _e('پوستهٔ'); ?> <a href="https://pourdaryaei.ir" rel="noopener">مژگان</a>
                <span class="footer-sep" aria-hidden="true">·</span>
                <?php _e('قدرت‌گرفته از'); ?> <a href="https://www.typerenew.ir" rel="noopener">TypeRenew</a>
            </p>
        </div>

    </div>
</footer>

<button type="button" class="back-to-top" aria-label="<?php _e('بازگشت به بالای صفحه'); ?>" title="<?php _e('بازگشت به بالا'); ?>">
    <?php echo mojgan_icon('arrow-up', 18); ?>
</button>

<div class="toast" id="mojgan-toast" role="status" aria-live="polite"></div>

<?php $this->footer(); ?>

<script>
    window.MOJGAN = {
        siteUrl: <?php echo json_encode((string) $this->options->siteUrl, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP); ?>,
        progress: <?php echo (mojgan_on('showReadingTime', '1') && $this->is('post')) ? 'true' : 'false'; ?>,
        tickerSpeed: <?php echo json_encode(max(5, min(200, (int) mojgan_opt('tickerSpeed', '30')))); ?>,
        toastCopied: <?php echo json_encode('پیوند نوشته کپی شد'); ?>,
        toastLikeFail: <?php echo json_encode('ذخیرهٔ پسند ممکن نشد؛ دوباره تلاش کنید'); ?>,
        toastOffline: <?php echo json_encode('اتصال اینترنت را بررسی کنید'); ?>
    };
</script>
<script src="<?php $this->options->themeUrl('assets/js/mojgan.js?v=1.1.0'); ?>"></script>

</body>
</html>
<?php
/*
 * پایان بافر خروجی header.php — ارقام لاتینِ متن‌ها به فارسی تبدیل می‌شوند؛
 * بلاک‌های کد (pre/code/kbd/samp) و اسکریپت‌ها دست‌نخورده می‌مانند.
 */
if (!empty($GLOBALS['mojganFaBuffer'])) {
    $GLOBALS['mojganFaBuffer'] = false;
    $mojganPageOutput = ob_get_clean();

    if (is_string($mojganPageOutput) && $mojganPageOutput !== '') {
        echo mojgan_fa_html($mojganPageOutput);
    }
}
?>
