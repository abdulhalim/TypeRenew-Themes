(function () {
    'use strict';

    var config = window.MOJGAN || {};
    var doc = document;
    var html = doc.documentElement;

    function ready(fn) {
        if (doc.readyState !== 'loading') {
            fn();
        } else {
            doc.addEventListener('DOMContentLoaded', fn);
        }
    }

    /* ---------- ارقام فارسی ---------- */

    var FA_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

    function toFa(value) {
        value = String(value);
        var out = '';
        for (var i = 0; i < value.length; i++) {
            out += FA_DIGITS[+value.charAt(i)] || value.charAt(i);
        }
        return out;
    }

    function compactFa(value) {
        var text = (Math.round(value * 10) / 10).toFixed(1);
        if (text.slice(-2) === '.0') {
            text = text.slice(0, -2);
        }
        return toFa(text.replace('.', '٫'));
    }

    function formatCount(num) {
        num = parseInt(num, 10) || 0;
        if (num < 0) {
            num = 0;
        }
        if (num >= 1000000) {
            return compactFa(num / 1000000) + ' میلیون';
        }
        if (num >= 1000) {
            var thousands = num / 1000;
            if (thousands >= 1000) {
                return compactFa(thousands / 1000) + ' میلیون';
            }
            return compactFa(thousands) + ' هزار';
        }
        return toFa(num);
    }

    /* ---------- اعلان کوچک ---------- */

    var toast = doc.getElementById('mojgan-toast');
    var toastTimer = null;

    function showToast(message) {
        if (!toast) {
            return;
        }
        toast.textContent = message;
        toast.classList.add('is-visible');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function () {
            toast.classList.remove('is-visible');
        }, 2600);
    }

    /* ---------- منوی موبایل ---------- */

    function initNav() {
        var toggle = doc.querySelector('.js-nav-toggle');
        var nav = doc.querySelector('.main-nav');

        if (!toggle || !nav) {
            return;
        }

        toggle.addEventListener('click', function () {
            var isOpen = nav.classList.toggle('is-open');
            toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        doc.addEventListener('click', function (e) {
            if (!nav.classList.contains('is-open')) {
                return;
            }
            if (nav.contains(e.target) || toggle.contains(e.target)) {
                return;
            }
            nav.classList.remove('is-open');
            toggle.setAttribute('aria-expanded', 'false');
        });
    }

    /* ---------- زیرمنوی دسته‌بندی‌ها ---------- */

    function initNavDropdown() {
        var items = doc.querySelectorAll('.nav-item-has-children');

        function closeAll(except) {
            for (var i = 0; i < items.length; i++) {
                if (items[i] === except) {
                    continue;
                }
                items[i].classList.remove('is-open');
                var t = items[i].querySelector('.nav-drop-toggle');
                if (t) {
                    t.setAttribute('aria-expanded', 'false');
                }
            }
        }

        for (var j = 0; j < items.length; j++) {
            (function (item) {
                var toggle = item.querySelector('.nav-drop-toggle');

                if (!toggle) {
                    return;
                }

                toggle.addEventListener('click', function (e) {
                    e.stopPropagation();
                    var open = item.classList.toggle('is-open');
                    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
                    closeAll(item);
                });
            })(items[j]);
        }

        doc.addEventListener('click', function (e) {
            for (var k = 0; k < items.length; k++) {
                if (items[k].contains(e.target)) {
                    continue;
                }
                items[k].classList.remove('is-open');
                var tg = items[k].querySelector('.nav-drop-toggle');
                if (tg) {
                    tg.setAttribute('aria-expanded', 'false');
                }
            }
        });

        doc.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                closeAll(null);
            }
        });
    }

    /* ---------- جستجوی سربرگ ---------- */

    function initHeaderSearch() {
        var toggle = doc.querySelector('.js-search-toggle');
        var bar = doc.querySelector('.js-header-search');
        var close = doc.querySelector('.js-search-close');
        var input = doc.querySelector('.header-search-input');

        if (!toggle || !bar) {
            return;
        }

        function open() {
            bar.hidden = false;
            toggle.classList.add('is-active');
            if (input) {
                setTimeout(function () {
                    input.focus();
                }, 60);
            }
        }

        function closeBar() {
            bar.hidden = true;
            toggle.classList.remove('is-active');
        }

        toggle.addEventListener('click', function () {
            if (bar.hidden) {
                open();
            } else {
                closeBar();
            }
        });

        if (close) {
            close.addEventListener('click', closeBar);
        }

        doc.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && !bar.hidden) {
                closeBar();
            }
        });
    }

    /* ---------- پسند (لایک) — فقط در صفحهٔ نوشته ---------- */

    function paintLikeButton(btn) {
        var liked = btn.getAttribute('data-liked') === '1';
        var likes = parseInt(btn.getAttribute('data-likes'), 10) || 0;
        var count = btn.querySelector('.like-count');
        var label = btn.querySelector('.like-label');

        btn.classList.toggle('is-liked', liked);
        btn.setAttribute('aria-pressed', liked ? 'true' : 'false');

        if (count) {
            count.textContent = formatCount(likes);
        }
        if (label) {
            label.textContent = liked ? 'پسندیدید' : 'پسندیدم';
        }
    }

    var likeBusy = {};

    function sendLike(cid, btn) {
        if (likeBusy[cid]) {
            return;
        }
        likeBusy[cid] = true;

        var before = {
            likes: btn.getAttribute('data-likes'),
            liked: btn.getAttribute('data-liked')
        };
        var optimistic = btn.getAttribute('data-liked') === '1' ? -1 : 1;

        var all = doc.querySelectorAll('.like-btn[data-cid="' + cid + '"]');
        for (var i = 0; i < all.length; i++) {
            all[i].setAttribute('data-likes', String(Math.max(0, (parseInt(all[i].getAttribute('data-likes'), 10) || 0) + optimistic)));
            all[i].setAttribute('data-liked', optimistic > 0 ? '1' : '0');
            paintLikeButton(all[i]);
        }

        var body = new URLSearchParams();
        body.append('mojganLike', cid);

        fetch(config.siteUrl || '/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: body.toString(),
            credentials: 'same-origin'
        })
            .then(function (res) {
                return res.json();
            })
            .then(function (data) {
                delete likeBusy[cid];
                if (!data || !data.ok) {
                    for (var j = 0; j < all.length; j++) {
                        all[j].setAttribute('data-likes', before.likes);
                        all[j].setAttribute('data-liked', before.liked);
                        paintLikeButton(all[j]);
                    }
                    showToast(config.toastLikeFail || 'ذخیرهٔ پسند ممکن نشد');
                    return;
                }
                for (var k = 0; k < all.length; k++) {
                    all[k].setAttribute('data-likes', String(data.likes));
                    all[k].setAttribute('data-liked', data.liked ? '1' : '0');
                    paintLikeButton(all[k]);
                }
            })
            .catch(function () {
                delete likeBusy[cid];
                for (var m = 0; m < all.length; m++) {
                    all[m].setAttribute('data-likes', before.likes);
                    all[m].setAttribute('data-liked', before.liked);
                    paintLikeButton(all[m]);
                }
                showToast(config.toastOffline || 'اتصال اینترنت را بررسی کنید');
            });
    }

    function initLikes() {
        var buttons = doc.querySelectorAll('.like-btn[data-cid]');

        for (var i = 0; i < buttons.length; i++) {
            (function (btn) {
                paintLikeButton(btn);
                btn.addEventListener('click', function () {
                    var cid = btn.getAttribute('data-cid');
                    if (cid) {
                        sendLike(cid, btn);
                    }
                });
            })(buttons[i]);
        }
    }

    /* ---------- کپی لینک ---------- */

    function initCopyLink() {
        var buttons = doc.querySelectorAll('.js-copy-link');

        function copy(btn) {
            var url = btn.getAttribute('data-url') || (window.location.href);
            var done = function () {
                showToast(config.toastCopied || 'پیوند نوشته کپی شد');
            };

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(url).then(done).catch(function () {
                    fallbackCopy(url, done);
                });
            } else {
                fallbackCopy(url, done);
            }
        }

        function fallbackCopy(text, done) {
            var input = doc.createElement('textarea');
            input.value = text;
            input.setAttribute('readonly', '');
            input.style.position = 'absolute';
            input.style.right = '-9999px';
            doc.body.appendChild(input);
            input.select();
            try {
                doc.execCommand('copy');
                done();
            } catch (e) {
                showToast(config.toastOffline || 'کپی ممکن نشد');
            }
            doc.body.removeChild(input);
        }

        for (var i = 0; i < buttons.length; i++) {
            (function (btn) {
                btn.addEventListener('click', function () {
                    copy(btn);
                });
            })(buttons[i]);
        }
    }

    /* ---------- نوار پیشرفت مطالعه ---------- */

    function initProgress() {
        if (!config.progress) {
            return;
        }

        var bar = doc.querySelector('.reading-progress-bar');
        var article = doc.querySelector('.single-post');

        if (!bar || !article) {
            return;
        }

        var ticking = false;

        function update() {
            var rect = article.getBoundingClientRect();
            var total = rect.height - window.innerHeight * 0.4;
            var read = Math.min(Math.max(-rect.top + window.innerHeight * 0.3, 0), Math.max(total, 1));
            bar.style.width = (read / Math.max(total, 1) * 100) + '%';
            ticking = false;
        }

        window.addEventListener('scroll', function () {
            if (!ticking) {
                ticking = true;
                window.requestAnimationFrame(update);
            }
        }, { passive: true });

        update();
    }

    /* ---------- بازگشت به بالا ---------- */

    function initBackToTop() {
        var btn = doc.querySelector('.back-to-top');

        if (!btn) {
            return;
        }

        var ticking = false;

        function update() {
            btn.classList.toggle('is-visible', window.scrollY > 600);
            ticking = false;
        }

        window.addEventListener('scroll', function () {
            if (!ticking) {
                ticking = true;
                window.requestAnimationFrame(update);
            }
        }, { passive: true });

        btn.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });

        update();
    }

    /* ---------- تصویر آواتار: اگر گراواتار نبود، حرف آغازین ---------- */

    function initAvatars() {
        var holders = doc.querySelectorAll('.avatar[data-avatar-initial]');

        for (var i = 0; i < holders.length; i++) {
            (function (holder) {
                var img = holder.querySelector('img');
                if (!img || img.getAttribute('data-avatar-checked')) {
                    return;
                }
                img.setAttribute('data-avatar-checked', '1');

                function fallback() {
                    if (img.parentNode) {
                        img.remove();
                    }
                    holder.classList.add('avatar-fallback');
                    if (!holder.querySelector('span')) {
                        var letter = doc.createElement('span');
                        letter.textContent = holder.getAttribute('data-avatar-initial') || '؟';
                        holder.appendChild(letter);
                    }
                }

                img.addEventListener('error', fallback);

                // تصویری که پیش از اجرای اسکریپت شکست خورده باشد
                if (img.complete && img.naturalWidth === 0) {
                    fallback();
                }
            })(holders[i]);
        }
    }

    /* ---------- تعادل شبکهٔ کارت‌های شاخص (صفحهٔ نخست) ---------- */

    function initFeaturedGrid() {
        var grid = doc.querySelector('.featured-grid');

        if (!grid) {
            return;
        }

        var minis = grid.querySelectorAll('.mini-card').length;

        if (minis === 0) {
            grid.classList.add('grid-hero-only');
        } else if (minis === 1) {
            grid.classList.add('grid-single-mini');
        }
    }

    /* ---------- تصاویر با نشانی خام (لینک مستقیم) در متن نوشته ---------- */

    var IMG_URL_RE = /(?:https?:\/\/|\/)[^\s"'<>()\[\]{}«»]+?\.(?:jpe?g|png|gif|webp|avif|bmp|svg)(?:\?[^\s"'<>()\[\]{}«»]*)?/gi;

    function imgUrlMatches(text) {
        var re = new RegExp(IMG_URL_RE.source, 'gi');
        var out = [];
        var m;

        while ((m = re.exec(text)) !== null) {
            out.push(m);
        }

        return out;
    }

    function buildDirectImage(url) {
        var img = doc.createElement('img');
        img.src = url;
        img.alt = '';
        img.loading = 'lazy';
        img.decoding = 'async';
        return img;
    }

    function initDirectImages() {
        var content = doc.querySelector('.post-content');

        if (!content) {
            return;
        }

        // ۱) پیوند خودکار: <a href="…/x.webp">…/x.webp</a> → پیوند تصویری
        var links = content.querySelectorAll('a[href]');
        var i;

        for (i = 0; i < links.length; i++) {
            var link = links[i];
            var href = link.getAttribute('href') || '';

            if (!imageishUrl(href) || link.querySelector('img')) {
                continue;
            }

            var linkText = (link.textContent || '').trim();

            // فقط وقتی متن پیوند خودِ نشانی است (یا خودش نشانی تصویر است)
            if (linkText === '' || linkText === href || imageishUrl(linkText)) {
                while (link.firstChild) {
                    link.removeChild(link.firstChild);
                }
                link.classList.add('post-direct-image');
                link.appendChild(buildDirectImage(href));
            }
        }

        // ۲) نشانی خام تصویر در متن ساده (بدون پیوند)
        var walker = doc.createTreeWalker(content, NodeFilter.SHOW_TEXT, null, false);
        var textNodes = [];
        var skipTags = { A: 1, CODE: 1, PRE: 1, SCRIPT: 1, STYLE: 1, FIGCAPTION: 1, TEXTAREA: 1, NOSCRIPT: 1, H1: 1, H2: 1, H3: 1, H4: 1, H5: 1, H6: 1 };

        while (walker.nextNode()) {
            var parent = walker.currentNode.parentNode;
            var tag = parent ? parent.nodeName : '';

            if (tag && skipTags[tag]) {
                continue;
            }

            textNodes.push(walker.currentNode);
        }

        for (i = 0; i < textNodes.length; i++) {
            var node = textNodes[i];
            var text = node.nodeValue;

            if (!text || text.indexOf('.') < 0) {
                continue;
            }

            var matches = imgUrlMatches(text);

            if (matches.length === 0) {
                continue;
            }

            var frag = doc.createDocumentFragment();
            var last = 0;

            for (var j = 0; j < matches.length; j++) {
                if (matches[j].index > last) {
                    frag.appendChild(doc.createTextNode(text.slice(last, matches[j].index)));
                }

                var directLink = doc.createElement('a');
                directLink.href = matches[j][0];
                directLink.className = 'post-direct-image';
                directLink.appendChild(buildDirectImage(matches[j][0]));
                frag.appendChild(directLink);

                last = matches[j].index + matches[j][0].length;
            }

            if (last < text.length) {
                frag.appendChild(doc.createTextNode(text.slice(last)));
            }

            if (node.parentNode) {
                node.parentNode.replaceChild(frag, node);
            }
        }
    }

    /* ---------- گالری دوستونهٔ تصاویر نوشته ---------- */

    function isImageOnlyNode(node) {
        if (!node || node.nodeType !== 1) {
            return false;
        }
        if (node.tagName !== 'P' && node.tagName !== 'FIGURE' && node.tagName !== 'DIV') {
            return false;
        }
        if (!node.querySelector('img')) {
            return false;
        }
        // فقط تصویر و فاصله/خط جدید؛ هر متن دیگری یعنی پاراگراف عادی است
        var hasText = false;
        for (var i = 0; i < node.childNodes.length; i++) {
            var child = node.childNodes[i];
            if (child.nodeType === 3 && child.nodeValue.trim() !== '') {
                hasText = true;
                break;
            }
            if (child.nodeType === 1 && child.tagName !== 'IMG' && child.tagName !== 'BR'
                && child.tagName !== 'SPAN' && child.tagName !== 'A' && child.tagName !== 'PICTURE') {
                hasText = true;
                break;
            }
            if (child.nodeType === 1 && child.tagName === 'A' && child.querySelector('img') === null) {
                hasText = true;
                break;
            }
        }
        return !hasText;
    }

    function initGallery() {
        var content = doc.querySelector('.post-content');

        if (!content) {
            return;
        }

        var children = Array.prototype.slice.call(content.children);
        var run = [];

        function flushRun() {
            if (run.length < 1) {
                run = [];
                return;
            }

            // شمارش کل تصاویر پیوسته؛ کمتر از ۲ یعنی تصویر تنها — دست نخورده
            var totalImgs = 0;
            var k;
            for (k = 0; k < run.length; k++) {
                totalImgs += run[k].querySelectorAll('img').length;
            }

            if (totalImgs < 2) {
                run = [];
                return;
            }

            var gallery = doc.createElement('div');
            gallery.className = 'post-gallery';
            run[0].parentNode.insertBefore(gallery, run[0]);

            for (k = 0; k < run.length; k++) {
                var imgs = run[k].querySelectorAll('img');
                for (var m = 0; m < imgs.length; m++) {
                    var figure = doc.createElement('figure');
                    figure.className = 'post-gallery-item';
                    figure.appendChild(imgs[m]);
                    gallery.appendChild(figure);
                }
                run[k].parentNode.removeChild(run[k]);
            }

            run = [];
        }

        for (var j = 0; j < children.length; j++) {
            if (isImageOnlyNode(children[j])) {
                run.push(children[j]);
            } else {
                flushRun();
            }
        }
        flushRun();
    }

    /* ---------- لایتباکس تصاویر ---------- */

    function imageishUrl(url) {
        if (!url) {
            return false;
        }
        if (/^data:image\//i.test(url)) {
            return true;
        }
        return /\.(jpe?g|png|gif|webp|avif|bmp|svg)([?#].*)?$/i.test(url.split('#')[0]);
    }

    function initLightbox() {
        var content = doc.querySelector('.post-content');

        if (!content) {
            return;
        }

        var overlay = null;
        var figure = null;
        var imgEl = null;
        var captionEl = null;
        var counterEl = null;
        var closeBtn = null;
        var prevBtn = null;
        var nextBtn = null;
        var images = [];
        var index = 0;
        var lastFocused = null;

        function fullSrc(img) {
            var link = img.closest ? img.closest('a') : null;
            if (link) {
                var href = link.getAttribute('href') || '';
                if (imageishUrl(href)) {
                    return href;
                }
            }
            return img.currentSrc || img.src || '';
        }

        function buildOverlay() {
            overlay = doc.createElement('div');
            overlay.className = 'lightbox';
            overlay.setAttribute('role', 'dialog');
            overlay.setAttribute('aria-modal', 'true');
            overlay.setAttribute('aria-label', 'نمایش تصویر');

            var svgChevron = function (points) {
                return '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="' + points + '"></polyline></svg>';
            };

            overlay.innerHTML =
                '<button type="button" class="lightbox-close" aria-label="بستن">'
                + '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>'
                + '</button>'
                + '<button type="button" class="lightbox-prev" aria-label="تصویر پیشین">' + svgChevron('9 6 15 12 9 18') + '</button>'
                + '<button type="button" class="lightbox-next" aria-label="تصویر بعدی">' + svgChevron('15 6 9 12 15 18') + '</button>'
                + '<figure class="lightbox-figure">'
                + '<img class="lightbox-img" alt="" />'
                + '<figcaption class="lightbox-caption"></figcaption>'
                + '</figure>'
                + '<span class="lightbox-counter"></span>';

            doc.body.appendChild(overlay);
            overlay.hidden = true;

            figure = overlay.querySelector('.lightbox-figure');
            imgEl = overlay.querySelector('.lightbox-img');
            captionEl = overlay.querySelector('.lightbox-caption');
            counterEl = overlay.querySelector('.lightbox-counter');
            closeBtn = overlay.querySelector('.lightbox-close');
            prevBtn = overlay.querySelector('.lightbox-prev');
            nextBtn = overlay.querySelector('.lightbox-next');

            closeBtn.addEventListener('click', close);
            prevBtn.addEventListener('click', function (e) { e.stopPropagation(); show(index - 1); });
            nextBtn.addEventListener('click', function (e) { e.stopPropagation(); show(index + 1); });
            figure.addEventListener('click', function (e) { e.stopPropagation(); });
            overlay.addEventListener('click', close);
        }

        function show(i) {
            if (images.length < 1) {
                return;
            }
            index = (i + images.length) % images.length;

            var item = images[index];
            imgEl.src = item.src;
            imgEl.alt = item.alt || '';
            captionEl.textContent = item.alt || '';
            captionEl.style.display = item.alt ? '' : 'none';
            counterEl.textContent = toFa(index + 1) + ' از ' + toFa(images.length);

            prevBtn.style.display = images.length > 1 ? '' : 'none';
            nextBtn.style.display = images.length > 1 ? '' : 'none';
        }

        function open(img) {
            if (!overlay) {
                buildOverlay();
            }

            images = [];
            var all = content.querySelectorAll('img');
            for (var i = 0; i < all.length; i++) {
                var src = fullSrc(all[i]);
                if (src) {
                    images.push({ src: src, alt: all[i].getAttribute('alt') || '' });
                }
            }

            var src = fullSrc(img);
            var startIndex = 0;
            for (var j = 0; j < images.length; j++) {
                if (images[j].src === src) {
                    startIndex = j;
                    break;
                }
            }

            if (images.length < 1) {
                images.push({ src: src, alt: img.getAttribute('alt') || '' });
            }

            lastFocused = doc.activeElement;
            overlay.hidden = false;
            doc.body.classList.add('lightbox-open');
            show(startIndex);
            closeBtn.focus();
        }

        function close() {
            if (!overlay || overlay.hidden) {
                return;
            }
            overlay.hidden = true;
            doc.body.classList.remove('lightbox-open');
            if (lastFocused && lastFocused.focus) {
                lastFocused.focus();
            }
        }

        function onKey(e) {
            if (!overlay || overlay.hidden) {
                return;
            }
            if (e.key === 'Escape') {
                close();
            } else if (e.key === 'ArrowLeft') {
                show(index + 1);
            } else if (e.key === 'ArrowRight') {
                show(index - 1);
            }
        }

        content.addEventListener('click', function (e) {
            var img = e.target;
            while (img && img !== content && img.tagName !== 'IMG') {
                img = img.parentNode;
            }
            if (!img || img.tagName !== 'IMG') {
                return;
            }

            // اگر تصویر پیوندی به صفحهٔ دیگری است، رفتار عادی حفظ شود
            var link = img.closest ? img.closest('a') : null;
            if (link) {
                var href = link.getAttribute('href') || '';
                if (!imageishUrl(href) && href !== '' && href !== fullSrc(img)) {
                    return;
                }
            }

            e.preventDefault();
            open(img);
        });

        doc.addEventListener('keydown', onKey);
    }

    /* ---------- نوار متحرک عناوین (تیکر) ---------- */

    function initTicker() {
        var ticker = doc.querySelector('.datebar-ticker');

        if (!ticker) {
            return;
        }

        var track = ticker.querySelector('.datebar-ticker-track');

        if (!track || track.children.length < 1) {
            return;
        }

        var containerW = ticker.clientWidth || 1;
        var baseItems = Array.prototype.slice.call(track.children);
        var baseW = Math.max(1, track.scrollWidth);

        // تکرار عناوین تا عرض نوار پر شود، سپس یک نسخهٔ کامل دیگر برای حلقهٔ بی‌درز
        var reps = Math.max(1, Math.ceil((containerW + 80) / baseW));
        var set = [];
        var i;

        for (i = 0; i < reps; i++) {
            for (var j = 0; j < baseItems.length; j++) {
                set.push(baseItems[j].cloneNode(true));
            }
        }

        while (track.firstChild) {
            track.removeChild(track.firstChild);
        }

        var frag = doc.createDocumentFragment();
        for (i = 0; i < set.length; i++) {
            frag.appendChild(set[i]);
        }
        for (i = 0; i < set.length; i++) {
            frag.appendChild(set[i].cloneNode(true));
        }
        track.appendChild(frag);

        // سرعت قابل تنظیم از تنظیمات پوسته (پیش‌فرض ۳۰ پیکسل بر ثانیه)
        var speed = parseFloat(config.tickerSpeed) || 30;
        if (speed < 5) {
            speed = 5;
        }
        if (speed > 200) {
            speed = 200;
        }

        var fullW = Math.max(1, track.scrollWidth);
        var duration = Math.max(12, Math.round(fullW / 2 / speed));
        track.style.setProperty('--ticker-duration', duration + 's');

        // ری‌استارت انیمیشن با محتوای تازه
        track.style.animation = 'none';
        void track.offsetWidth;
        track.style.animation = '';
    }

    /* ---------- راه‌اندازی ---------- */

    ready(function () {
        initNav();
        initNavDropdown();
        initHeaderSearch();
        initDirectImages();
        initGallery();
        initLightbox();
        initLikes();
        initCopyLink();
        initProgress();
        initBackToTop();
        initAvatars();
        initFeaturedGrid();
        initTicker();
    });
})();
