<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$showSidebar = mojgan_show_sidebar($this);
?>

<div class="container">
    <div class="layout<?php echo $showSidebar ? '' : ' no-sidebar'; ?>">

        <div class="content-area<?php echo $showSidebar ? '' : ' archive-full'; ?>">

            <header class="archive-banner">
                <span class="archive-banner-icon" aria-hidden="true">
                    <?php
                        if ($this->is('search')) {
                            echo mojgan_icon('search', 22);
                        } elseif ($this->is('category')) {
                            echo mojgan_icon('folder', 22);
                        } elseif ($this->is('tag')) {
                            echo mojgan_icon('tag', 22);
                        } elseif ($this->is('author')) {
                            echo mojgan_icon('user', 22);
                        } else {
                            echo mojgan_icon('calendar', 22);
                        }
                    ?>
                </span>
                <div class="archive-banner-text">
                    <h1 class="archive-banner-title">
                        <?php $this->archiveTitle([
                            'category' => _t('دستهٔ %s'),
                            'search'   => _t('نتایج جستجوی «%s»'),
                            'tag'      => _t('برچسب %s'),
                            'author'   => _t('نوشته‌های %s')
                        ], '', ''); ?>
                    </h1>
                    <?php if ($this->getDescription()): ?>
                        <p class="archive-banner-desc"><?php $this->getDescription(); ?></p>
                    <?php else: ?>
                        <p class="archive-banner-desc"><?php _e('فهرست نوشته‌های این بخش، از تازه‌ترین تا قدیمی‌ترین'); ?></p>
                    <?php endif; ?>
                </div>
                <?php $total = (int) $this->getTotal(); ?>
                <?php if ($total > 0): ?>
                    <span class="archive-banner-count"><?php echo mojgan_format_count($total); ?> <?php _e('نوشته'); ?></span>
                <?php endif; ?>
            </header>

            <?php if ($this->have()): ?>

                <div class="archive-grid">

                    <?php while ($this->next()): ?>
                        <?php $itemCover = mojgan_card_image($this); ?>
                        <article class="archive-item" itemscope itemtype="http://schema.org/BlogPosting">

                            <a class="archive-item-thumb" href="<?php $this->permalink(); ?>" aria-hidden="true" tabindex="-1" itemprop="image">
                                <?php if ($itemCover !== ''): ?>
                                    <img src="<?php echo htmlspecialchars($itemCover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->title(); ?>" loading="lazy" />
                                <?php else: ?>
                                    <span class="cover-fallback" aria-hidden="true"><?php echo mojgan_icon('newspaper', 24); ?></span>
                                <?php endif; ?>
                            </a>

                            <div class="archive-item-body">
                                <h2 class="archive-item-title" itemprop="name headline">
                                    <a href="<?php $this->permalink(); ?>" itemprop="url"><?php $this->title(); ?></a>
                                </h2>
                                <div class="archive-item-meta">
                                    <time datetime="<?php echo date('c', (int) $this->created); ?>"><?php echo mojgan_date((int) $this->created); ?></time>
                                    <?php if ($this->categories): ?>
                                        <span class="meta-sep" aria-hidden="true">·</span>
                                        <a class="archive-item-cat" href="<?php echo htmlspecialchars($this->categories[0]['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($this->categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                                    <?php endif; ?>
                                    <span class="meta-sep" aria-hidden="true">·</span>
                                    <span class="archive-item-author"><?php $this->author(); ?></span>
                                </div>
                                <?php $itemExcerpt = mojgan_excerpt($this, 16); ?>
                                <?php if ($itemExcerpt !== ''): ?>
                                    <p class="archive-item-excerpt"><?php echo htmlspecialchars($itemExcerpt, ENT_QUOTES, 'UTF-8'); ?></p>
                                <?php endif; ?>
                            </div>

                            <a class="archive-item-arrow" href="<?php $this->permalink(); ?>" aria-label="<?php $this->title(); ?>">
                                <?php echo mojgan_icon('arrow-left', 16); ?>
                            </a>
                        </article>
                    <?php endwhile; ?>

                </div>

                <nav class="pagination-area" aria-label="<?php _e('ناوبری صفحات'); ?>">
                    <?php
                        ob_start();
                        $this->pageNav(
                            '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 6 15 12 9 18"></polyline></svg>',
                            '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 6 9 12 15 18"></polyline></svg>',
                            2,
                            '…'
                        );
                        echo mojgan_nav_fa((string) ob_get_clean());
                    ?>
                </nav>

            <?php else: ?>

                <div class="empty-state">
                    <div class="empty-ornament" aria-hidden="true">
                        <?php echo mojgan_icon('search', 56); ?>
                    </div>
                    <h2 class="empty-title"><?php _e('چیزی پیدا نشد'); ?></h2>
                    <p class="empty-desc">
                        <?php $this->archiveTitle([
                            'category' => _t('هنوز در دستهٔ «%s» نوشته‌ای منتشر نشده است.'),
                            'search'   => _t('برای «%s» نتیجه‌ای پیدا نشد؛ عبارت دیگری را بیازمایید.'),
                            'tag'      => _t('هنوز نوشته‌ای با برچسب «%s» منتشر نشده است.'),
                            'author'   => _t('هنوز %s نوشته‌ای منتشر نکرده است.')
                        ], '', ''); ?>
                    </p>
                    <a class="btn btn-primary" href="<?php $this->options->siteUrl(); ?>"><?php _e('بازگشت به خانه'); ?></a>
                </div>

            <?php endif; ?>

        </div>

        <?php if ($showSidebar): ?>
            <?php $this->need('sidebar.php'); ?>
        <?php endif; ?>

    </div>
</div>

<?php $this->need('footer.php'); ?>
