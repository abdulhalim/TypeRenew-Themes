<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$pageCover = mojgan_thumbnail($this);
$showSidebar = mojgan_show_sidebar($this);
?>

<div class="container">
    <div class="layout<?php echo $showSidebar ? '' : ' no-sidebar'; ?>">

        <div class="content-area">

            <article class="single-post single-page" itemscope itemtype="http://schema.org/WebPage">

                <?php if ($pageCover !== ''): ?>
                    <figure class="post-hero" itemprop="image">
                        <img src="<?php echo htmlspecialchars($pageCover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->title(); ?>" loading="eager" />
                    </figure>
                <?php endif; ?>

                <nav class="breadcrumb" aria-label="<?php _e('مسیر صفحه'); ?>">
                    <a href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a>
                    <span class="breadcrumb-sep" aria-hidden="true">/</span>
                    <span class="breadcrumb-current" aria-current="page"><?php $this->title(); ?></span>
                </nav>

                <header class="post-header">
                    <h1 class="post-title" itemprop="name headline"><?php $this->title(); ?></h1>
                    <div class="post-meta">
                        <span class="post-meta-item">
                            <?php echo mojgan_icon('calendar', 15); ?>
                            <time datetime="<?php echo date('c', (int) $this->created); ?>" itemprop="datePublished"><?php echo mojgan_date_long((int) $this->created); ?></time>
                        </span>
                    </div>
                </header>

                <div class="post-content" itemprop="articleBody">
                    <?php $this->content(); ?>
                </div>

            </article>

            <?php $this->need('comments.php'); ?>

        </div>

        <?php if ($showSidebar): ?>
            <?php $this->need('sidebar.php'); ?>
        <?php endif; ?>

    </div>
</div>

<?php $this->need('footer.php'); ?>
