<?php
/**
 * دلتنگی — پوسته‌ای دخترانه و مدرن برای دفتر خاطرات روزانه
 * بر پایهٔ کد پوستهٔ پیش‌فرض TypeRenew
 *
 * @package دلتنگی
 * @author پوردریایی
 * @version 1.0.0
 * @link https://www.pourdaryaei.ir
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');
?>

<?php $deltangiShowHero = (string) ($this->options->showHero ?? 'yes') !== 'no'; ?>
<?php $deltangiIsFirstPage = $this->is('index') && max(1, intval($this->request->page ?? 1)) === 1; ?>
<?php $deltangiAvatar = trim((string) ($this->options->avatarUrl ?? '')); ?>

<?php if (!($this->is('index'))): ?>
    <h3 class="archive-title">
        <?php $this->archiveTitle([
            'category' => 'دلتنگی‌های دستهٔ «%s»',
            'search'   => 'نتایج جستجو برای «%s»',
            'tag'      => 'نوشته‌های برچسب «%s»',
            'author'   => 'نوشته‌های %s'
        ], '', ''); ?>
    </h3>
<?php endif; ?>

<?php if ($deltangiShowHero && $deltangiIsFirstPage): ?>
<section class="hero" aria-label="کارت خوش‌آمد">
    <span class="hero-deco hero-deco-1" aria-hidden="true">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"></path></svg>
    </span>
    <span class="hero-deco hero-deco-2" aria-hidden="true">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"></path></svg>
    </span>
    <span class="hero-deco hero-deco-3" aria-hidden="true">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M11.8 5.2C11.4 4 10.6 3 9.5 2.4M12.2 5.2c.4-1.2 1.2-2.2 2.3-2.8" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"></path><path d="M12 6.1c.44 0 .8.36.8.8v10.4a.8.8 0 0 1-1.6 0V6.9c0-.44.36-.8.8-.8z"></path><path d="M11.2 9.6C10.3 6.9 8 4 5.3 4.3 3 4.6 1.7 7.2 2.4 9.9c.6 2.3 2.6 4 5 4.4 1.4.2 2.8-.2 3.8-1.2V9.6z"></path><path d="M12.8 9.6c.9-2.7 3.2-5.6 5.9-5.3 2.3.3 3.6 2.9 2.9 5.6-.6 2.3-2.6 4-5 4.4-1.4.2-2.8-.2-3.8-1.2V9.6z"></path><path d="M11.2 14.3c-1.1-.9-2.9-1.2-4.3-.5-1.6.8-2.3 2.6-1.5 4.1.8 1.5 2.7 2.1 4.2 1.4 1-.5 1.7-1.5 1.7-2.6l-.1-2.4z"></path><path d="M12.8 14.3c1.1-.9 2.9-1.2 4.3-.5 1.6.8 2.3 2.6 1.5 4.1-.8 1.5-2.7 2.1-4.2 1.4-1-.5-1.7-1.5-1.7-2.6l.1-2.4z"></path></svg>
    </span>
    <span class="hero-deco hero-deco-4" aria-hidden="true">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>
    </span>

    <div class="hero-avatar">
        <?php if ($deltangiAvatar !== ''): ?>
            <img src="<?php echo htmlspecialchars($deltangiAvatar, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars((string) $this->options->title, ENT_QUOTES, 'UTF-8'); ?>"/>
        <?php else: ?>
            <img src="<?php $this->options->themeUrl('assets/img/avatar-default.webp'); ?>" alt=""/>
        <?php endif; ?>
    </div>
    <p class="hero-eyebrow">دفتر خاطرات کوچولوی من</p>
    <h1 class="hero-name"><?php $this->options->title(); ?></h1>
    <?php if (trim((string) $this->options->description) !== ''): ?>
        <p class="hero-desc"><?php $this->options->description(); ?></p>
    <?php endif; ?>
</section>
<?php endif; ?>

<?php if ($this->have()): ?>
    <div class="post-list">
    <?php while ($this->next()): ?>
        <?php $deltangiCover = deltangi_thumbnail($this, (string) ($this->options->defaultCover ?? '')); ?>
        <article class="post-card post" itemscope itemtype="http://schema.org/BlogPosting">
            <a class="post-cover" href="<?php $this->permalink(); ?>" tabindex="-1" aria-hidden="true">
                <?php if ($deltangiCover !== ''): ?>
                    <img itemprop="image" src="<?php echo htmlspecialchars($deltangiCover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars((string) $this->title, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy"/>
                <?php else: ?>
                    <img src="<?php $this->options->themeUrl('assets/img/cover-default.svg'); ?>" alt="" loading="lazy"/>
                <?php endif; ?>
            </a>
            <div class="post-card-body">
                <?php postMeta($this, 'archive'); ?>
                <div class="post-excerpt" itemprop="description">
                    <?php $this->excerpt(150, '…'); ?>
                </div>
                <a class="read-more" href="<?php $this->permalink(); ?>">
                    ادامهٔ دلتنگی
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"></path></svg>
                </a>
            </div>
        </article>
    <?php endwhile; ?>
    </div>
<?php else: ?>
    <div class="empty-state">
        <span class="empty-art" aria-hidden="true">
            <svg width="56" height="56" viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"></path></svg>
        </span>
        <h2 class="empty-title">هنوز چیزی این‌جا نیست…</h2>
        <p>اولین دلتنگیت رو بنویس؛ این دفتر منتظرته.</p>
    </div>
<?php endif; ?>

<nav class="pagination-area" aria-label="ناوبری صفحه‌ها">
    <?php $this->pageNav(
        '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18l6-6-6-6"/></svg>',
        '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>',
        3,
        '…'
    ); ?>
</nav>

<?php $this->need('footer.php'); ?>
