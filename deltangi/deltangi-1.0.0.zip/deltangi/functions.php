<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * ————————————————————————————————
 *  پوستهٔ «دلتنگی» — تنظیمات و توابع کمکی
 *  بر پایهٔ کد پوستهٔ پیش‌فرض TypeRenew
 * ————————————————————————————————
 */

/**
 * فرم تنظیمات پوسته (از بخش «تنظیمات پوسته» در مدیریت قابل ویرایش است)
 */
function themeConfig($form)
{
    $logoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'logoUrl',
        null,
        null,
        'نشانی لوگو',
        'اگه دوست داری به‌جای قلب کوچولو، لوگوی خودت بالای سایت نمایش داده بشه، نشانی تصویرش رو این‌جا بذار. خالی بذاری یه قلب دلتنگی نشون می‌دم.'
    );
    $form->addInput($logoUrl->addRule('url', 'لطفاً یک نشانی (URL) معتبر وارد کن'));

    $colorSchema = new \Typecho\Widget\Helper\Form\Element\Select(
        'colorSchema',
        [
            'auto'  => 'خودکار (مثل تنظیمات گوشی)',
            'light' => 'روز (روشن)',
            'dark'  => 'شب (تاریک)'
        ],
        'auto',
        'حالت نمایش',
        'پوسته رو روی روز بذاری یا شب، یا بذار مثل تنظیمات خود دستگاه باشه.'
    );
    $form->addInput($colorSchema);

    $palette = new \Typecho\Widget\Helper\Form\Element\Select(
        'palette',
        [
            'rose'     => 'صورتی رمانتیک (پیشنهادی)',
            'lavender' => 'بنفش لاوندر',
            'peach'    => 'هلویی غروب',
            'mint'     => 'نعنایی ملایم'
        ],
        'rose',
        'پالت رنگی',
        'رنگ و حال‌وهوای اصلی دفترت؛ هر وقت خواستی عوضش کن.'
    );
    $form->addInput($palette);

    $showHero = new \Typecho\Widget\Helper\Form\Element\Select(
        'showHero',
        [
            'yes' => 'نمایش بده',
            'no'  => 'نمایش نده'
        ],
        'yes',
        'کارت خوش‌آمد صفحهٔ اول',
        'همون کادر بالای صفحهٔ اول که عکس و معرفی کوچولوی توشه.'
    );
    $form->addInput($showHero);

    $avatarUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'avatarUrl',
        null,
        null,
        'نشانی عکس پروفایل',
        'عکس خودت رو این‌جا بذار تا تو کارت خوش‌آمد و صفحهٔ «درباره من» نشون داده بشه. خالی باشه یه دخترِ کوچولوی نقاشی‌شده می‌ذارم.'
    );
    $form->addInput($avatarUrl);

    $ownerName = new \Typecho\Widget\Helper\Form\Element\Text(
        'ownerName',
        null,
        null,
        'نام نمایشی',
        'اسمی که دوست داری باهاش صدات کنن؛ مثلاً «نیلا». خالی باشه از عنوان سایت استفاده می‌شه.'
    );
    $form->addInput($ownerName);

    $aboutBio = new \Typecho\Widget\Helper\Form\Element\Text(
        'aboutBio',
        null,
        null,
        'معرفی کوتاه',
        'یه خط دربارهٔ خودت؛ مثلاً «۱۶ ساله‌ام و عاشق بارونم». خالی باشه توضیحِ سایت نشون داده می‌شه.'
    );
    $form->addInput($aboutBio);

    $favorites = new \Typecho\Widget\Helper\Form\Element\Text(
        'favorites',
        null,
        null,
        'چیزهایی که دوست داری',
        'با ویرگول از هم جدا کن؛ مثلاً: صدای بارون، بستنی وانیلی، کتاب خوندن زیر پتو. تو صفحهٔ «درباره من» به‌صورت برچسب‌های کوچولو نشون داده می‌شه.'
    );
    $form->addInput($favorites);

    $instagramId = new \Typecho\Widget\Helper\Form\Element\Text(
        'instagramId',
        null,
        null,
        'شناسهٔ اینستاگرام',
        'مثلاً neela.diary — فقط شناسه، بدون آدرس کامل. برای صفحهٔ «درباره من».'
    );
    $form->addInput($instagramId);

    $telegramId = new \Typecho\Widget\Helper\Form\Element\Text(
        'telegramId',
        null,
        null,
        'شناسهٔ تلگرام',
        'مثلاً neela_diary — فقط شناسه، بدون آدرس کامل. برای صفحهٔ «درباره من».'
    );
    $form->addInput($telegramId);

    $contactEmail = new \Typecho\Widget\Helper\Form\Element\Text(
        'contactEmail',
        null,
        null,
        'ایمیل',
        'اگه دوست داری راه ارتباطی‌ات با مخاطب‌ها همین ایمیل باشه، بنویسش. برای صفحهٔ «درباره من».'
    );
    $form->addInput($contactEmail);

    $defaultCover = new \Typecho\Widget\Helper\Form\Element\Text(
        'defaultCover',
        null,
        null,
        'تصویر شاخص پیش‌فرض',
        'اگه یه نوشته‌ای عکس نداشت و فیلد سفارشی هم براش گذاشته نشده بود، این عکس براش استفاده می‌شه. خالی باشه یه تصویر دخترانهٔ آماده می‌ذارم.'
    );
    $form->addInput($defaultCover);
}

/**
 * ————————————————————————————————
 *  کادر خودکار «تصویر شاخص» در ویرایشگر
 *  با تشخیص این تابع، TypeRenew موقع نوشتن یا
 *  ویرایش هر نوشته/برگه، خودش کادر تصویر شاخص
 *  را نمایش می‌دهد؛ کاربر فقط نشانی عکس را در آن
 *  کپی می‌کند (بدون ساخت دستی فیلد سفارشی).
 *  مقدار آن به‌صورت فیلد سفارشی thumb ذخیره می‌شود
 *  و در deltangi_thumbnail با بالاترین اولویت خوانده می‌شود.
 * ————————————————————————————————
 */
function themeFields($layout)
{
    $thumb = new \Typecho\Widget\Helper\Form\Element\Text(
        'thumb',
        null,
        null,
        'تصویر شاخص',
        'فقط نشانی (لینک) عکسِ دلخواهت را این‌جا کپی کن تا کاور نوشته‌ات شود. اگه خالی بمونه، اولین عکسِ داخل خودِ نوشته یا کاور پیش‌فرض نشون داده می‌شه.'
    );
    $layout->addItem($thumb);
}

/**
 * ————————————————————————————————
 *  تبدیل خودکار ارقام لاتین به فارسی
 *  همهٔ اعدادِ متن (تاریخ‌ها، شمارهٔ صفحه‌ها، تعداد دیدگاه‌ها و…)
 *  فارسی می‌شن؛ فقط محتوای بلاک‌های کد (pre, code, kbd, samp)
 *  و اسکریپت‌ها و استایل‌ها دست‌نخورده و لاتین می‌مونن.
 * ————————————————————————————————
 */
function deltangi_fa_digits($text)
{
    if (!is_string($text) || $text === '') {
        return $text;
    }

    return strtr($text, [
        '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
        '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
    ]);
}

/**
 * فیلتر خروجی نهایی صفحه:
 * فقط «گره‌های متنی» بیرون از تگ‌ها تبدیل می‌شن؛
 * پس نشانی‌ها، مقدار ویژگی‌ها (مثل datetime) و کدها سالم می‌مونن.
 */
function deltangi_digits_filter($html)
{
    if (!is_string($html) || $html === '') {
        return $html;
    }

    $parts = preg_split('/(<[^>]+>)/', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
    if ($parts === false) {
        return $html;
    }

    $skipTags  = ['pre', 'code', 'kbd', 'samp', 'script', 'style'];
    $skipStack = [];
    $out       = '';

    foreach ($parts as $part) {
        if ($part === '') {
            continue;
        }

        // قطعه‌های تگ
        if ($part[0] === '<') {
            if (preg_match('/^<\s*(\/?)\s*([a-zA-Z][a-zA-Z0-9-]*)/', $part, $m)) {
                $tag = strtolower($m[2]);
                if (in_array($tag, $skipTags, true)) {
                    if ($m[1] === '/') {
                        array_pop($skipStack);
                    } elseif (!preg_match('/\/\s*>$/', $part)) {
                        $skipStack[] = $tag;
                    }
                }
            }
            $out .= $part;
            continue;
        }

        // قطعه‌های متنی: فقط وقتی داخل بلاک کد نیستیم
        if ($skipStack === []) {
            $out .= deltangi_fa_digits($part);
        } else {
            $out .= $part;
        }
    }

    return $out;
}

ob_start('deltangi_digits_filter');

/**
 * ————————————————————————————————
 *  تصویر شاخص
 *  ترتیب اولویت: فیلد سفارشی (thumb یا cover یا img)
 *  ← نخستین تصویر داخل نوشته ← تصویر پیش‌فرض تنظیمات ← کاور آمادهٔ پوسته
 * ————————————————————————————————
 */
function deltangi_thumbnail(\Widget\Archive $archive, $defaultCover = '')
{
    // ۱) فیلد سفارشی
    $fields = $archive->fields ?? null;
    if ($fields instanceof \Typecho\Config) {
        foreach (['thumb', 'cover', 'img', 'thumbnail'] as $field) {
            $value = $fields->{$field} ?? null;
            if (is_string($value) && trim($value) !== '') {
                return trim($value);
            }
        }
    }

    // ۲) نخستین تصویر داخل متن نوشته (اچ‌تی‌ام‌ال یا مارک‌داون)
    $text = (string) ($archive->text ?? '');
    if ($text !== '') {
        if (preg_match('/<img[^>]*\bsrc\s*=\s*["\']([^"\']+)["\']/i', $text, $m)) {
            return $m[1];
        }
        if (preg_match('/!\[[^\]]*\]\(\s*<?([^)\s>]+)>?\s*(?:"[^"]*")?\)/', $text, $m)) {
            return $m[1];
        }
    }

    // ۳) تصویر پیش‌فرض از تنظیمات پوسته
    $defaultCover = is_string($defaultCover) ? trim($defaultCover) : '';
    if ($defaultCover !== '') {
        return $defaultCover;
    }

    // ۴) خالی؛ قالب خودش کاور آمادهٔ پوسته را نشان می‌دهد
    return '';
}

/**
 * متادیتای نوشته — تاریخ دقیقاً مثل پوستهٔ پیش‌فرض رندر می‌شود
 */
function postMeta(\Widget\Archive $archive, string $metaType = 'archive')
{
    $titleTag = $metaType === 'archive' ? 'h2' : 'h1';
?>
    <<?php echo $titleTag ?> class="post-title" itemprop="name headline">
        <a itemprop="url" href="<?php $archive->permalink() ?>"><?php $archive->title() ?></a>
    </<?php echo $titleTag ?>>

    <?php if ($metaType !== 'page'): ?>
        <ul class="post-meta">
            <li itemprop="author" itemscope itemtype="http://schema.org/Person">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                <a itemprop="name" href="<?php $archive->author->permalink(); ?>" rel="author"><?php $archive->author(); ?></a>
            </li>
            <li>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                <time datetime="<?php $archive->date('c'); ?>" itemprop="datePublished"><?php $archive->date(); ?></time>
            </li>
            <li>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
                <?php $archive->category(','); ?>
            </li>
            <?php if ($metaType === 'archive'): ?>
                <li itemprop="interactionCount">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                    <a itemprop="discussionUrl" href="<?php $archive->permalink() ?>#comments"><?php $archive->commentsNum('هنوز دیدگاهی نیست', 'یک دیدگاه', '%d دیدگاه'); ?></a>
                </li>
            <?php endif; ?>
        </ul>
    <?php endif; ?>
<?php
}

/**
 * رندر نوشتهٔ تکی/برگه
 */
function renderSingle(\Widget\Archive $archive, string $metaType = 'post'): void
{
?>
    <article class="post" itemscope itemtype="http://schema.org/BlogPosting">
        <?php postMeta($archive, $metaType); ?>
        <div class="post-content" itemprop="articleBody">
            <?php $archive->content(); ?>
        </div>
        <?php if ($metaType === 'post' && count($archive->tags) > 0): ?>
            <p itemprop="keywords" class="tags">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>
                <?php $archive->tags(' ', true, 'none'); ?>
            </p>
        <?php endif; ?>
    </article>
<?php
}

/**
 * ظاهر دیدگاه‌ها (همان ساختار پوستهٔ پیش‌فرض)
 */
function threadedComments($comments, $options)
{
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
?>
    <li id="li-<?php $comments->theId(); ?>" class="comment-body<?php
    if ($comments->levels > 0) {
        echo ' comment-child';
        $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
    } else {
        echo ' comment-parent';
    }
    $comments->alt(' comment-odd', ' comment-even');
    echo $commentClass;
    ?>">
        <div id="<?php $comments->theId(); ?>" class="comment-inner">
            <div class="comment-author-avatar">
                <?php if ($comments->authorId && $comments->authorId == $comments->ownerId): ?>
                    <?php
                    // دیدگاه مدیر دفتر: آواتار از تنظیمات پوسته؛ در نبود آن، تصویر آمادهٔ پوسته
                    $deltangiOwnerAvatar = trim((string) (\Widget\Options::alloc()->avatarUrl ?? ''));
                    // نام نویسنده به‌صورت متن خام و امن برای ویژگی alt
                    // (author() لینک HTML می‌سازد و داخل ویژگی‌ها کافی نیست)
                    $deltangiAuthorName = htmlspecialchars(strip_tags((string) $comments->author), ENT_QUOTES, 'UTF-8');
                    ?>
                    <?php if ($deltangiOwnerAvatar !== ''): ?>
                        <img class="avatar" src="<?php echo htmlspecialchars($deltangiOwnerAvatar, ENT_QUOTES, 'UTF-8'); ?>" width="40" height="40" alt="<?php echo $deltangiAuthorName; ?>"/>
                    <?php else: ?>
                        <img class="avatar" src="<?php \Widget\Options::alloc()->themeUrl('assets/img/avatar-default.webp'); ?>" width="40" height="40" alt="<?php echo $deltangiAuthorName; ?>"/>
                    <?php endif; ?>
                <?php else: ?>
                    <?php $comments->gravatar('40', ''); ?>
                <?php endif; ?>
            </div>
            <div class="comment-main">
                <div class="comment-meta">
                    <cite class="comment-author" itemprop="creator" itemscope itemtype="http://schema.org/Person">
                        <?php $comments->author(); ?>
                    </cite>
                    <span class="comment-time">
                        <a href="<?php $comments->permalink(); ?>" itemprop="url">
                            <time datetime="<?php $comments->date('c'); ?>" itemprop="commentTime"><?php $comments->date('Y-m-d H:i'); ?></time>
                        </a>
                    </span>
                    <span class="comment-reply">
                        <?php $comments->reply('پاسخ'); ?>
                    </span>
                </div>
                <div class="comment-content" itemprop="commentText">
                    <?php $comments->content(); ?>
                </div>
            </div>
        </div>
        <?php if ($comments->children) { ?>
            <div class="comment-children">
                <?php $comments->threadedComments($options); ?>
            </div>
        <?php } ?>
    </li>
<?php
}
