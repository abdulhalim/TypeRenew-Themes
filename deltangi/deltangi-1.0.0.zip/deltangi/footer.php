<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
</main>

<footer class="site-footer" role="contentinfo">
    <div class="container">
        <p class="footer-love">
            <span class="footer-heart" aria-hidden="true">
                <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true">
                    <defs>
                        <linearGradient id="deltangi-foot-grad" x1="0" y1="0" x2="1" y2="1">
                            <stop offset="0" style="stop-color: var(--accent);"></stop>
                            <stop offset="1" style="stop-color: var(--accent-2);"></stop>
                        </linearGradient>
                    </defs>
                    <path fill="url(#deltangi-foot-grad)" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"></path>
                </svg>
            </span>
            <?php echo date('Y'); ?> · <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a> — همهٔ دلتنگی‌ها برای خودم محفوظ است
        </p>
        <p>قدرت‌گرفته از <a href="https://www.typerenew.ir">TypeRenew</a> با پوستهٔ «دلتنگی»</p>
    </div>
</footer>

<?php $this->footer(); ?>

<script>
    (function() {
        var btn = document.getElementById('theme-switch');
        if (!btn) return;

        var html = document.documentElement;
        var iconPath = btn.querySelector('path');
        var transitionTimeout;

        function updateIcon() {
            var isDark = html.getAttribute('data-theme') === 'dark';
            if (isDark) {
                iconPath.setAttribute('d', 'M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42M17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0z');
            } else {
                iconPath.setAttribute('d', 'M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z');
            }
        }

        updateIcon();

        btn.addEventListener('click', function() {
            var currentDark = html.getAttribute('data-theme') === 'dark';
            var newTheme = currentDark ? 'light' : 'dark';

            html.classList.add('theme-transition');
            html.setAttribute('data-theme', newTheme);
            try {
                localStorage.setItem('theme', newTheme);
            } catch (e) {}
            updateIcon();

            clearTimeout(transitionTimeout);
            transitionTimeout = setTimeout(function() {
                html.classList.remove('theme-transition');
            }, 300);
        });

        var prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
        prefersDark.addEventListener('change', function(e) {
            var stored = null;
            try {
                stored = localStorage.getItem('theme');
            } catch (err) {}
            if (!stored) {
                html.classList.add('theme-transition');
                html.setAttribute('data-theme', e.matches ? 'dark' : 'light');
                updateIcon();
                clearTimeout(transitionTimeout);
                transitionTimeout = setTimeout(function() {
                    html.classList.remove('theme-transition');
                }, 300);
            }
        });
    })();
</script>

</body>
</html>
