<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<?php $deltangiCover = deltangi_thumbnail($this, (string) ($this->options->defaultCover ?? '')); ?>
<?php if ($deltangiCover !== ''): ?>
<div class="post-banner">
    <img src="<?php echo htmlspecialchars($deltangiCover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars((string) $this->title, ENT_QUOTES, 'UTF-8'); ?>" itemprop="image"/>
</div>
<?php endif; ?>

<?php renderSingle($this, 'post'); ?>

<nav aria-label="نوشتهٔ قبل و بعد">
    <ul class="post-near">
        <li><strong>نوشتهٔ قبلی</strong> <?php $this->thePrev('%s', 'قبلی‌تری نیست'); ?></li>
        <li><strong>نوشتهٔ بعدی</strong> <?php $this->theNext('%s', 'بعدی‌تری نیست'); ?></li>
    </ul>
</nav>

<?php $this->need('comments.php'); ?>

<?php $this->need('footer.php'); ?>
