<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="error-page">
    <span class="error-art" aria-hidden="true">
        <svg width="72" height="72" viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"></path></svg>
    </span>
    <h2 class="error-code">404</h2>
    <p class="error-message">اوووپس… این صفحه تو دفترم پیدا نشد! شاید پاره شده یا اصلاً هیچ‌وقت نوشته نشده بوده.</p>
    <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="error-search">
        <input type="search" name="s" class="form-input" placeholder="یه چیزی برای جستجو بنویس…" aria-label="جستجو" autofocus />
        <button type="submit" class="btn-submit">بگرد پیداش کن</button>
    </form>
    <a class="read-more" href="<?php $this->options->siteUrl(); ?>">برگرد خونه</a>
</div>

<?php $this->need('footer.php'); ?>
