<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<?php if (in_array((string) ($this->slug ?? ''), ['about', 'about-me'], true)): ?>
    <?php $this->need('_about.php'); ?>
<?php else: ?>
    <?php renderSingle($this, 'page'); ?>
    <?php $this->need('comments.php'); ?>
<?php endif; ?>

<?php $this->need('footer.php'); ?>
