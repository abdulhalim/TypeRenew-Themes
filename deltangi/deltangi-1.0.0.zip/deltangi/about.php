<?php
/**
 * درباره من
 *
 * @package custom
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');
$this->need('_about.php');
$this->need('footer.php');
