<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * چیدمان صفحهٔ «درباره من»
 * هم از قالب سفارشی about.php استفاده می‌کند و هم اگر برگه‌ای
 * با نامک about یا about-me ساخته شود، خودکار همین چیدمان را می‌گیرد.
 */

$deltangiOptions   = $this->options;
$deltangiName      = trim((string) ($deltangiOptions->ownerName ?? '')) !== '' ? (string) $deltangiOptions->ownerName : (string) $deltangiOptions->title;
$deltangiBio       = trim((string) ($deltangiOptions->aboutBio ?? '')) !== '' ? (string) $deltangiOptions->aboutBio : (string) $deltangiOptions->description;
$deltangiAvatar    = trim((string) ($deltangiOptions->avatarUrl ?? ''));
$deltangiInstagram = trim((string) ($deltangiOptions->instagramId ?? ''));
$deltangiTelegram  = trim((string) ($deltangiOptions->telegramId ?? ''));
$deltangiEmail     = trim((string) ($deltangiOptions->contactEmail ?? ''));

$deltangiFavorites = [];
$deltangiFavRaw = (string) ($deltangiOptions->favorites ?? '');
if (trim($deltangiFavRaw) !== '') {
    $deltangiFavList = preg_split('/[،,]/u', $deltangiFavRaw);
    if (is_array($deltangiFavList)) {
        foreach ($deltangiFavList as $deltangiFavItem) {
            $deltangiFavItem = trim($deltangiFavItem);
            if ($deltangiFavItem !== '') {
                $deltangiFavorites[] = $deltangiFavItem;
            }
        }
    }
}

$deltangiStats = null;
if (class_exists('\Widget\Stat')) {
    try {
        $deltangiStatWidget = \Widget\Stat::alloc();
        $deltangiStats = [
            'posts'    => (int) $deltangiStatWidget->publishedPostsNum,
            'comments' => (int) $deltangiStatWidget->publishedCommentsNum,
        ];
    } catch (\Throwable $deltangiError) {
        $deltangiStats = null;
    }
}
?>

<section class="about-hero" aria-label="دربارهٔ من">
    <span class="hero-deco hero-deco-1" aria-hidden="true">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"></path></svg>
    </span>
    <span class="hero-deco hero-deco-3" aria-hidden="true">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="12" cy="5.9" r="2.7"></circle><circle cx="17.9" cy="10.2" r="2.7"></circle><circle cx="15.6" cy="17.1" r="2.7"></circle><circle cx="8.4" cy="17.1" r="2.7"></circle><circle cx="6.1" cy="10.2" r="2.7"></circle><circle cx="12" cy="11.8" r="2.2"></circle></svg>
    </span>

    <div class="about-avatar">
        <?php if ($deltangiAvatar !== ''): ?>
            <img src="<?php echo htmlspecialchars($deltangiAvatar, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($deltangiName, ENT_QUOTES, 'UTF-8'); ?>"/>
        <?php else: ?>
            <img src="<?php $this->options->themeUrl('assets/img/avatar-default.webp'); ?>" alt=""/>
        <?php endif; ?>
    </div>
    <p class="about-eyebrow">خوش اومدی به دفترم</p>
    <h1 class="about-name"><?php echo htmlspecialchars($deltangiName, ENT_QUOTES, 'UTF-8'); ?></h1>
    <?php if (trim((string) $deltangiBio) !== ''): ?>
        <p class="about-bio"><?php echo htmlspecialchars($deltangiBio, ENT_QUOTES, 'UTF-8'); ?></p>
    <?php endif; ?>

    <?php $deltangiSocials = []; ?>
    <?php if ($deltangiInstagram !== ''): ?>
        <?php $deltangiSocials[] = [
            'label' => 'اینستاگرام',
            'href'  => 'https://instagram.com/' . rawurlencode($deltangiInstagram),
            'svg'   => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>',
        ]; ?>
    <?php endif; ?>
    <?php if ($deltangiTelegram !== ''): ?>
        <?php $deltangiSocials[] = [
            'label' => 'تلگرام',
            'href'  => 'https://t.me/' . rawurlencode($deltangiTelegram),
            'svg'   => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21.5 4.5L2.9 11.7c-1 .4-1 1.5 0 1.8l4.6 1.5 1.7 5.2c.3.9 1.3 1 1.9.4l2.5-2.4 4.9 3.6c.8.5 1.8.1 2-.8l3-13.9c.2-1-.7-1.9-1.6-1.6z"></path></svg>',
        ]; ?>
    <?php endif; ?>
    <?php if ($deltangiEmail !== ''): ?>
        <?php $deltangiSocials[] = [
            'label' => 'ایمیل',
            'href'  => 'mailto:' . $deltangiEmail,
            'svg'   => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>',
        ]; ?>
    <?php endif; ?>

    <?php if ($deltangiSocials !== []): ?>
        <ul class="about-socials">
            <?php foreach ($deltangiSocials as $deltangiSocial): ?>
                <li>
                    <a href="<?php echo htmlspecialchars($deltangiSocial['href'], ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener noreferrer me" title="<?php echo htmlspecialchars($deltangiSocial['label'], ENT_QUOTES, 'UTF-8'); ?>" aria-label="<?php echo htmlspecialchars($deltangiSocial['label'], ENT_QUOTES, 'UTF-8'); ?>">
                        <?php echo $deltangiSocial['svg']; ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</section>

<article class="post about-post">
    <div class="post-content" itemprop="articleBody">
        <?php $this->content(); ?>
    </div>
</article>

<?php if ($deltangiFavorites !== []): ?>
<section class="about-block">
    <h2 class="about-block-title">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"></path></svg>
        چیزهایی که دوست دارم
    </h2>
    <ul class="about-favorites">
        <?php foreach ($deltangiFavorites as $deltangiFavorite): ?>
            <li><?php echo htmlspecialchars($deltangiFavorite, ENT_QUOTES, 'UTF-8'); ?></li>
        <?php endforeach; ?>
    </ul>
</section>
<?php endif; ?>

<?php if (is_array($deltangiStats) && ($deltangiStats['posts'] > 0 || $deltangiStats['comments'] > 0)): ?>
<section class="about-block">
    <h2 class="about-block-title">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"></path></svg>
        تا حالا توی این دفتر
    </h2>
    <ul class="stat-chips">
        <li><strong><?php echo $deltangiStats['posts']; ?></strong><span>دلتنگی نوشته‌شده</span></li>
        <li><strong><?php echo $deltangiStats['comments']; ?></strong><span>دیدگاه مهربون</span></li>
    </ul>
</section>
<?php endif; ?>

<div class="about-thanks">
    <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"></path></svg>
    <p>ممنون که تا این‌جا اومدی؛ هر وقت دلت تنگ شد، بیا.</p>
</div>
