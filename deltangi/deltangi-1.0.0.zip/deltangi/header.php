<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php
    $deltangiPalette = (string) ($this->options->palette ?? 'rose');
    if (!in_array($deltangiPalette, ['rose', 'lavender', 'peach', 'mint'], true)) {
        $deltangiPalette = 'rose';
    }
?>
<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars(str_replace('_', '-', (string) ($this->options->lang ?? 'fa_IR')), ENT_QUOTES, 'UTF-8'); ?>" dir="rtl" data-palette="<?php echo htmlspecialchars($deltangiPalette, ENT_QUOTES, 'UTF-8'); ?>">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php $this->archiveTitle([
            'category' => 'دستهٔ %s',
            'search'   => 'جستجو برای %s',
            'tag'      => 'برچسب %s',
            'author'   => 'نوشته‌های %s'
        ], '', ' - '); ?><?php $this->options->title(); ?></title>

    <?php
        $defaultSchema = $this->options->colorSchema ?? 'auto';
        $defaultSchemaJson = \Typecho\Common::jsonEncode(
            (string) $defaultSchema,
            JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP,
            '"auto"'
        );
        echo "<script>
            (function() {
                var stored = null;
                try {
                    stored = localStorage.getItem('theme');
                } catch (e) {
                    stored = null;
                }
                var def = {$defaultSchemaJson};
                var isDark = false;
                if (stored === 'dark' || stored === 'light') {
                    isDark = (stored === 'dark');
                } else if (def === 'dark') {
                    isDark = true;
                } else if (def === 'auto' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                    isDark = true;
                }
                if (isDark) {
                    document.documentElement.setAttribute('data-theme', 'dark');
                }
            })();
        </script>";
    ?>

    <link rel="stylesheet" href="<?php $this->options->themeUrl('style.css'); ?>">
    <?php $this->header(); ?>
</head>
<body>
<header class="site-header">
    <div class="container header-inner">
        <div class="site-branding">
            <?php if ($this->options->logoUrl): ?>
                <a class="site-logo" href="<?php $this->options->siteUrl(); ?>">
                    <img src="<?php $this->options->logoUrl() ?>" alt="<?php echo htmlspecialchars((string) $this->options->title, ENT_QUOTES, 'UTF-8'); ?>"/>
                </a>
            <?php else: ?>
                <a class="site-title" href="<?php $this->options->siteUrl(); ?>">
                    <span class="brand-mark" aria-hidden="true">
                        <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true">
                            <defs>
                                <linearGradient id="deltangi-brand-grad" x1="0" y1="0" x2="1" y2="1">
                                    <stop offset="0" style="stop-color: var(--accent);"></stop>
                                    <stop offset="1" style="stop-color: var(--accent-2);"></stop>
                                </linearGradient>
                            </defs>
                            <path fill="url(#deltangi-brand-grad)" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"></path>
                        </svg>
                    </span>
                    <?php $this->options->title() ?>
                </a>
            <?php endif; ?>
        </div>
        <nav class="site-nav" aria-label="ناوبری اصلی">
            <input type="checkbox" id="nav-toggle" class="nav-toggle-input" aria-label="باز و بسته کردن منو">
            <label for="nav-toggle" class="nav-toggle-label" aria-hidden="true">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
            </label>
            <ul class="nav-menu" role="menubar">
                <li role="none"><a role="menuitem" <?php if ($this->is('index')): ?> class="active"<?php endif; ?> href="<?php $this->options->siteUrl(); ?>">خانه</a></li>
                <?php \Widget\Contents\Page\Rows::alloc()->to($pages); ?>
                <?php while ($pages->next()): ?>
                    <li role="none"><a role="menuitem" <?php if ($this->is('page', $pages->slug)): ?> class="active"<?php endif; ?> href="<?php $pages->permalink(); ?>"><?php $pages->title(); ?></a></li>
                <?php endwhile; ?>

                <li role="none">
                    <form id="search" method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="search-form">
                        <svg class="search-icon" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                        <?php $searchQuery = htmlspecialchars((string) ($this->request->keywords ?? $this->request->s ?? ''), ENT_QUOTES, 'UTF-8'); ?>
                        <input type="search" id="s" name="s" class="search-input" placeholder="دنبال چی می‌گردی؟" aria-label="جستجو" value="<?php echo $searchQuery; ?>" required />
                    </form>
                </li>

                <li role="none">
                    <button type="button" id="theme-switch" class="theme-switch" aria-label="تغییر حالت روز و شب" title="حالت روز و شب">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="theme-icon" aria-hidden="true">
                            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                        </svg>
                    </button>
                </li>
            </ul>
        </nav>
    </div>
</header>
<main class="site-main container">
