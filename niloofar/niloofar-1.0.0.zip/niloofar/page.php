<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<?php $layoutMode = (string) niloofarOpt('layoutMode', 'single'); ?>

<div class="layout<?php echo $layoutMode === 'sidebar' ? ' layout-has-sidebar' : ' layout-single'; ?>">

    <div class="layout-primary">

        <article class="single-post single-page reveal" itemscope itemtype="http://schema.org/WebPage">

            <nav class="breadcrumb" aria-label="<?php _e('مسیر صفحه'); ?>">
                <a href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a>
                <span class="breadcrumb-sep" aria-hidden="true">/</span>
                <span class="breadcrumb-current" aria-current="page"><?php $this->title(); ?></span>
            </nav>

            <header class="post-header">
                <h1 class="post-title" itemprop="name headline"><?php $this->title(); ?></h1>
                <div class="meta-row post-meta-main">
                    <span class="meta-item">
                        <?php echo niloofarIcon('calendar'); ?>
                        <time datetime="<?php echo date('c', (int) $this->created); ?>" itemprop="datePublished"><?php echo niloofarDate($this); ?></time>
                    </span>
                </div>
            </header>

            <div class="post-content" itemprop="mainEntityOfPage" id="post-content">
                <?php $this->content(); ?>
            </div>

        </article>

        <?php $this->need('comments.php'); ?>

    </div>

    <?php if ($layoutMode === 'sidebar'): ?>
        <?php $this->need('sidebar.php'); ?>
    <?php endif; ?>

</div>

<?php $this->need('footer.php'); ?>
