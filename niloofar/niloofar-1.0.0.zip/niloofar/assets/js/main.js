(function () {
    'use strict';

    var doc = document;
    var win = window;

    var config = win.NILOOFAR || {};
    var strings = config.strings || {};
    var enabled = {
        gallery: config.gallery !== false,
        lightbox: config.lightbox !== false,
        toc: config.toc !== false,
        likes: config.likes !== false
    };

    function s(key, fallback) {
        return strings[key] || fallback;
    }

    /* --------------------------------------------------------------
     *  ابزارها
     * -------------------------------------------------------------- */

    /** تبدیل ارقام لاتین به فارسی */
    function faDigits(value) {
        var fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return String(value).replace(/[0-9]/g, function (d) {
            return fa[+d];
        });
    }

    var toastTimer = null;
    function toast(message) {
        var el = doc.getElementById('toast');
        if (!el || !message) return;
        el.textContent = message;
        el.classList.add('is-visible');
        if (toastTimer) clearTimeout(toastTimer);
        toastTimer = setTimeout(function () {
            el.classList.remove('is-visible');
        }, 2600);
    }

    /* --------------------------------------------------------------
     *  تعویض حالت روشن و تیره
     * -------------------------------------------------------------- */

    function initThemeSwitch() {
        var btn = doc.getElementById('theme-switch');
        var html = doc.documentElement;
        var transitionTimeout = null;

        function applyTransition() {
            doc.body.classList.add('theme-transition');
            if (transitionTimeout) clearTimeout(transitionTimeout);
            transitionTimeout = setTimeout(function () {
                doc.body.classList.remove('theme-transition');
            }, 400);
        }

        if (btn) {
            btn.addEventListener('click', function () {
                var currentDark = html.getAttribute('data-theme') === 'dark';
                var newTheme = currentDark ? 'light' : 'dark';

                applyTransition();
                html.setAttribute('data-theme', newTheme);
                try {
                    localStorage.setItem('niloofar-theme', newTheme);
                } catch (e) { /* حافظهٔ محلی در دسترس نیست */ }
            });
        }

        var prefersDark = win.matchMedia('(prefers-color-scheme: dark)');
        if (prefersDark.addEventListener) {
            prefersDark.addEventListener('change', function (e) {
                var stored = null;
                try {
                    stored = localStorage.getItem('niloofar-theme');
                } catch (err) { stored = null; }

                if (!stored) {
                    applyTransition();
                    if (e.matches) {
                        html.setAttribute('data-theme', 'dark');
                    } else {
                        html.removeAttribute('data-theme');
                    }
                }
            });
        }
    }

    /* --------------------------------------------------------------
     *  پوشش جستجو
     * -------------------------------------------------------------- */

    function initSearchOverlay() {
        var overlay = doc.getElementById('search-overlay');
        var toggle = doc.getElementById('search-toggle');
        var input = doc.getElementById('search-overlay-input');

        if (!overlay || !toggle) return;

        function open() {
            overlay.classList.add('is-open');
            overlay.setAttribute('aria-hidden', 'false');
            doc.body.style.overflow = 'hidden';
            if (input) {
                setTimeout(function () { input.focus(); }, 60);
            }
        }

        function close() {
            overlay.classList.remove('is-open');
            overlay.setAttribute('aria-hidden', 'true');
            doc.body.style.overflow = '';
        }

        toggle.addEventListener('click', open);

        var closers = overlay.querySelectorAll('[data-search-close]');
        Array.prototype.forEach.call(closers, function (el) {
            el.addEventListener('click', close);
        });

        doc.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && overlay.classList.contains('is-open')) {
                close();
            }
        });
    }

    /* --------------------------------------------------------------
     *  اسکرول: نوار پیشرفت، سایهٔ سربرگ، بازگشت به بالا
     * -------------------------------------------------------------- */

    function initScrollFeatures() {
        var progressWrap = doc.querySelector('.reading-progress');
        var progressBar = progressWrap ? progressWrap.querySelector('.reading-progress-bar') : null;
        var header = doc.getElementById('site-header');
        var backBtn = doc.getElementById('back-to-top');

        function update() {
            var docEl = doc.documentElement;
            var scrollable = docEl.scrollHeight - win.innerHeight;

            if (progressBar) {
                if (scrollable <= 0) {
                    progressBar.style.transform = 'scaleX(1)';
                } else {
                    var ratio = Math.min(1, Math.max(0, win.pageYOffset / scrollable));
                    progressBar.style.transform = 'scaleX(' + ratio + ')';
                }
            }

            if (header) {
                if (win.pageYOffset > 8) {
                    header.classList.add('is-scrolled');
                } else {
                    header.classList.remove('is-scrolled');
                }
            }

            if (backBtn) {
                if (win.pageYOffset > 480) {
                    backBtn.classList.add('is-visible');
                } else {
                    backBtn.classList.remove('is-visible');
                }
            }
        }

        var ticking = false;
        win.addEventListener('scroll', function () {
            if (!ticking) {
                win.requestAnimationFrame(function () {
                    update();
                    ticking = false;
                });
                ticking = true;
            }
        }, { passive: true });

        if (backBtn) {
            backBtn.addEventListener('click', function () {
                win.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }

        update();
    }

    /* --------------------------------------------------------------
     *  انیمیشن ظهور عناصر
     * -------------------------------------------------------------- */

    function initReveal() {
        var items = doc.querySelectorAll('.reveal');
        if (!items.length) return;

        if (!('IntersectionObserver' in win)) {
            Array.prototype.forEach.call(items, function (el) {
                el.classList.add('is-visible');
            });
            return;
        }

        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });

        Array.prototype.forEach.call(items, function (el) {
            observer.observe(el);
        });
    }

    /* --------------------------------------------------------------
     *  فهرست مطالب خودکار (H2/H3)
     * -------------------------------------------------------------- */

    function initToc() {
        if (!enabled.toc) return;

        var content = doc.getElementById('post-content');
        if (!content) return;

        var headings = content.querySelectorAll('h2, h3');
        if (headings.length < 3) return;

        // شناسهٔ یکتا برای هر عنوان
        var slugCounter = 0;
        Array.prototype.forEach.call(headings, function (h) {
            if (!h.id) {
                slugCounter++;
                h.id = 'nl-toc-' + slugCounter;
            }
        });

        // ساخت فهرست تو در تو
        var html = '<ul>';
        var openedSub = false;

        Array.prototype.forEach.call(headings, function (h) {
            var title = h.textContent.replace(/^\s+|\s+$/g, '');
            if (!title) return;

            if (h.tagName === 'H2') {
                if (openedSub) {
                    html += '</li></ul></li>';
                    openedSub = false;
                } else if (html !== '<ul>') {
                    html += '</li>';
                }
                html += '<li><a href="#' + h.id + '">' + escapeHtml(title) + '</a>';
            } else {
                if (!openedSub) {
                    html += '<ul>';
                    openedSub = true;
                }
                html += '<li class="toc-h3"><a href="#' + h.id + '">' + escapeHtml(title) + '</a></li>';
            }
        });

        if (openedSub) {
            html += '</ul></li>';
        }
        html += '</ul>';

        var toc = doc.createElement('nav');
        toc.className = 'post-toc';
        toc.setAttribute('aria-label', s('tocTitle', 'فهرست مطالب'));
        toc.innerHTML =
            '<button type="button" class="post-toc-head">' +
                '<span class="post-toc-title">' + s('tocTitle', 'فهرست مطالب') + '</span>' +
                '<span class="post-toc-arrow">' + chevronIcon(16) + '</span>' +
            '</button>' +
            '<div class="post-toc-list">' + html + '</div>';

        content.insertBefore(toc, content.firstChild);

        // باز/بسته کردن
        var head = toc.querySelector('.post-toc-head');
        if (head) {
            head.addEventListener('click', function () {
                toc.classList.toggle('is-open');
            });
        }

        // برجسته‌سازی عنوان فعال هنگام اسکرول
        if ('IntersectionObserver' in win) {
            var links = toc.querySelectorAll('a');
            var setActive = function (id) {
                Array.prototype.forEach.call(links, function (a) {
                    if (a.getAttribute('href') === '#' + id) {
                        a.classList.add('is-active');
                    } else {
                        a.classList.remove('is-active');
                    }
                });
            };

            var headingObserver = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        setActive(entry.target.id);
                    }
                });
            }, { rootMargin: '-15% 0px -70% 0px' });

            Array.prototype.forEach.call(headings, function (h) {
                headingObserver.observe(h);
            });
        }
    }

    function escapeHtml(text) {
        var div = doc.createElement('div');
        div.appendChild(doc.createTextNode(text));
        return div.innerHTML;
    }

    function chevronIcon(size) {
        return '<svg width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="currentColor"' +
            ' stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"></polyline></svg>';
    }

    /* --------------------------------------------------------------
     *  گالری تصاویر پشت‌سرهم
     * -------------------------------------------------------------- */

    /** نشانی‌هایی که به فایل تصویر ختم می‌شوند */
    var IMG_URL_RE = /\.(jpe?g|png|gif|webp|avif|bmp|svg)([?#].*)?$/i;

    /** ساخت تصویر تازه از نشانی — برای لینک‌های مستقیم تصویر */
    function makeGalleryImg(src, alt) {
        var img = doc.createElement('img');
        img.setAttribute('src', src);
        img.setAttribute('alt', alt || '');
        img.setAttribute('loading', 'lazy');
        img.setAttribute('decoding', 'async');
        return img;
    }

    /**
     * تحلیل یک عنصر محتوا: اگر تنها از تصویر، لینکِ تصویر یا
     * نشانیِ مستقیم تصویر (متن خالص) تشکیل شده باشد، فهرست
     * تصاویر آن را برمی‌گرداند؛ در غیر این صورت null.
     *
     * پشتیبانی:
     *  - <p><img><br><img>…</p>          (چند تصویر در یک پاراگراف)
     *  - <p><img></p><p><img></p>…       (پاراگراف‌های پشت‌سرهم)
     *  - <p><a href="a.webp">…</a>…</p>  (لینک مستقیم تصویر)
     *  - <p>http://…/a.webp<br>…</p>     (نشانی مستقیم به‌صورت متن)
     */
    function extractUnitImages(el) {
        if (!el || el.nodeType !== 1) return null;

        var tag = el.tagName;

        if (tag === 'IMG') {
            return el.getAttribute('src') ? [{ img: el, synthetic: false }] : null;
        }

        if (tag !== 'P' && tag !== 'FIGURE') return null;

        var found = [];
        var ok = true;

        Array.prototype.forEach.call(el.childNodes, function (node) {
            if (!ok) return;

            if (node.nodeType === 3) {
                // گرهٔ متنی: همهٔ توکن‌ها باید نشانی مستقیم تصویر باشند
                var text = node.textContent;
                if (!text.trim()) return;

                var tokens = text.trim().split(/\s+/);
                for (var i = 0; i < tokens.length; i++) {
                    if (!IMG_URL_RE.test(tokens[i])) {
                        ok = false;
                        return;
                    }
                    found.push({ img: makeGalleryImg(tokens[i], ''), synthetic: true });
                }
                return;
            }

            if (node.nodeType !== 1) return;

            var ntag = node.tagName;

            if (ntag === 'BR') return; // جداکنندهٔ خطوط

            if (ntag === 'IMG') {
                if (!node.getAttribute('src')) {
                    ok = false;
                    return;
                }
                found.push({ img: node, synthetic: false });
                return;
            }

            if (ntag === 'A') {
                var inner = node.querySelector('img');
                if (inner && inner.getAttribute('src')) {
                    // تصویرِ درون لینک (نشانی کامل از خود تصویر برداشته می‌شود)
                    found.push({ img: inner, synthetic: false });
                    return;
                }

                var href = node.getAttribute('href') || '';
                if (IMG_URL_RE.test(href)) {
                    // لینک مستقیم به فایل تصویر
                    found.push({ img: makeGalleryImg(href, node.textContent.trim()), synthetic: true });
                    return;
                }
            }

            ok = false; // هر محتوای دیگر یعنی پاراگراف گالری نیست
        });

        if (!ok || !found.length) return null;
        return found;
    }

    /**
     * تقسیم ردیف‌های گالری: حداکثر ۳ تصویر در هر ردیف؛
     * اگر ردیف آخر تنها بماند، با ردیف قبلی به‌صورت ۲+۲ متعادل می‌شود.
     */
    function chunkGalleryRows(count) {
        var rows = [];
        var remaining = count;

        while (remaining > 0) {
            var size = Math.min(3, remaining);
            // اگر بعد از این ردیف فقط یک تصویر می‌ماند و این ردیف بیش از ۲ دارد
            if (size === 3 && remaining - 3 === 1) {
                size = 2;
            }
            rows.push(size);
            remaining -= size;
        }

        return rows;
    }

    function initGallery() {
        if (!enabled.gallery) return;

        var content = doc.getElementById('post-content');
        if (!content) return;

        var children = Array.prototype.slice.call(content.children);
        var run = []; // واحدهای پشت‌سرهم: { el, images }

        function flushRun() {
            if (!run.length) return;

            var images = [];
            run.forEach(function (unit) {
                unit.images.forEach(function (entry) {
                    images.push(entry);
                });
            });

            if (images.length >= 2) {
                var anchor = run[0].el;
                var rows = chunkGalleryRows(images.length);
                var cursor = 0;

                Array.prototype.forEach.call(rows, function (rowSize) {
                    var row = doc.createElement('div');
                    row.className = 'post-gallery gallery-' + rowSize;

                    for (var i = 0; i < rowSize; i++) {
                        var entry = images[cursor++];
                        if (!entry) break;

                        var img = entry.img;
                        img.removeAttribute('width');
                        img.removeAttribute('height');
                        img.setAttribute('loading', 'lazy');
                        img.setAttribute('decoding', 'async');

                        var item = doc.createElement('figure');
                        item.className = 'post-gallery-item';
                        item.appendChild(img);
                        row.appendChild(item);
                    }

                    anchor.parentNode.insertBefore(row, anchor);
                });

                // عناصر مصرف‌شده کامل حذف می‌شوند (تصاویر منتقل شده‌اند)
                run.forEach(function (unit) {
                    if (unit.el.tagName === 'IMG') return; // خودِ تصویر جابه‌جا شده است
                    if (unit.el.parentNode) {
                        unit.el.parentNode.removeChild(unit.el);
                    }
                });
            } else if (images.length === 1 && images[0].synthetic) {
                // نشانی مستقیمِ تنها → در جای خود به تصویر تبدیل می‌شود
                var only = images[0].img;
                var target = run[0].el;
                if (target && target.parentNode) {
                    var wrapper = doc.createElement('p');
                    wrapper.appendChild(only);
                    target.parentNode.insertBefore(wrapper, target);
                    target.parentNode.removeChild(target);
                }
            }

            run = [];
        }

        children.forEach(function (child) {
            var images = extractUnitImages(child);
            if (images) {
                run.push({ el: child, images: images });
            } else {
                flushRun();
            }
        });
        flushRun();
    }

    /* --------------------------------------------------------------
     *  لایت‌باکس با ناوبری
     * -------------------------------------------------------------- */

    var lightboxState = {
        el: null,
        items: [],
        index: 0,
        lastFocus: null
    };

    function collectLightboxItems() {
        var items = [];
        var hero = doc.querySelector('.post-hero img');
        if (hero) {
            items.push({ src: hero.currentSrc || hero.src, alt: hero.alt || '' });
        }

        var content = doc.getElementById('post-content');
        if (content) {
            var imgs = content.querySelectorAll('img');
            Array.prototype.forEach.call(imgs, function (img) {
                items.push({ src: img.currentSrc || img.src, alt: img.alt || '' });
            });
        }

        return items;
    }

    function openLightbox(startIndex) {
        if (!enabled.lightbox) return;
        if (lightboxState.el) closeLightbox(true);

        lightboxState.items = collectLightboxItems();
        if (!lightboxState.items.length) return;

        lightboxState.index = Math.max(0, Math.min(startIndex, lightboxState.items.length - 1));
        lightboxState.lastFocus = doc.activeElement;

        var lb = doc.createElement('div');
        lb.className = 'lightbox';
        lb.setAttribute('role', 'dialog');
        lb.setAttribute('aria-modal', 'true');
        lb.setAttribute('aria-label', s('prevImage', 'نمایش بزرگ تصویر'));

        lb.innerHTML =
            '<figure class="lightbox-figure">' +
                '<img class="lightbox-img" src="" alt="" />' +
                '<figcaption class="lightbox-caption"></figcaption>' +
            '</figure>' +
            '<span class="lightbox-counter"></span>' +
            '<button type="button" class="lightbox-close" aria-label="' + s('close', 'بستن') + '">' +
                '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="5" x2="19" y2="19"></line><line x1="19" y1="5" x2="5" y2="19"></line></svg>' +
            '</button>' +
            '<button type="button" class="lightbox-prev" aria-label="' + s('prevImage', 'تصویر قبلی') + '">' +
                '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"></polyline></svg>' +
            '</button>' +
            '<button type="button" class="lightbox-next" aria-label="' + s('nextImage', 'تصویر بعدی') + '">' +
                '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"></polyline></svg>' +
            '</button>';

        doc.body.appendChild(lb);
        doc.body.style.overflow = 'hidden';

        lightboxState.el = lb;

        lb.querySelector('.lightbox-close').addEventListener('click', function () {
            closeLightbox();
        });
        lb.querySelector('.lightbox-prev').addEventListener('click', function (e) {
            e.stopPropagation();
            navigateLightbox(-1);
        });
        lb.querySelector('.lightbox-next').addEventListener('click', function (e) {
            e.stopPropagation();
            navigateLightbox(1);
        });
        lb.addEventListener('click', function (e) {
            if (e.target === lb) closeLightbox();
        });

        // پیمایش با کلیدهای جهت‌دار — در چیدمان راست‌به‌چپ، کلید چپ یعنی «بعدی»
        doc.addEventListener('keydown', lightboxKeydown);

        // پیمایش با لمس
        var touchStartX = null;
        lb.addEventListener('touchstart', function (e) {
            touchStartX = e.changedTouches[0].clientX;
        }, { passive: true });
        lb.addEventListener('touchend', function (e) {
            if (touchStartX === null) return;
            var dx = e.changedTouches[0].clientX - touchStartX;
            if (Math.abs(dx) > 45) {
                navigateLightbox(dx < 0 ? 1 : -1);
            }
            touchStartX = null;
        }, { passive: true });

        requestAnimationFrame(function () {
            lb.classList.add('is-open');
        });

        renderLightbox();
        var closeBtn = lb.querySelector('.lightbox-close');
        if (closeBtn) closeBtn.focus();
    }

    function lightboxKeydown(e) {
        if (!lightboxState.el) return;
        if (e.key === 'Escape') {
            e.preventDefault();
            closeLightbox();
        } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            navigateLightbox(1);
        } else if (e.key === 'ArrowRight') {
            e.preventDefault();
            navigateLightbox(-1);
        }
    }

    function navigateLightbox(step) {
        var total = lightboxState.items.length;
        if (!total) return;
        lightboxState.index = (lightboxState.index + step + total) % total;
        renderLightbox(true);
    }

    function renderLightbox(animate) {
        var lb = lightboxState.el;
        if (!lb) return;

        var item = lightboxState.items[lightboxState.index];
        if (!item) return;

        var img = lb.querySelector('.lightbox-img');
        var caption = lb.querySelector('.lightbox-caption');
        var counter = lb.querySelector('.lightbox-counter');

        if (animate) {
            lb.classList.remove('is-animating');
            void lb.offsetWidth;
            lb.classList.add('is-animating');
        }

        img.src = item.src;
        img.alt = item.alt;

        if (caption) {
            caption.textContent = item.alt || '';
            caption.style.display = item.alt ? '' : 'none';
        }

        if (counter) {
            counter.textContent = faDigits(lightboxState.index + 1) + ' ' +
                s('imageOf', 'از') + ' ' + faDigits(lightboxState.items.length);
        }

        // پیش‌بارگذاری تصاویر مجاور
        var total = lightboxState.items.length;
        [1, -1].forEach(function (offset) {
            var idx = (lightboxState.index + offset + total) % total;
            var next = lightboxState.items[idx];
            if (next) {
                var preload = new Image();
                preload.src = next.src;
            }
        });
    }

    function closeLightbox(immediate) {
        var lb = lightboxState.el;
        if (!lb) return;

        doc.removeEventListener('keydown', lightboxKeydown);

        function remove() {
            if (lb && lb.parentNode) {
                lb.parentNode.removeChild(lb);
            }
            if (!doc.querySelector('.search-overlay.is-open')) {
                doc.body.style.overflow = '';
            }
        }

        if (immediate) {
            remove();
        } else {
            lb.classList.remove('is-open');
            setTimeout(remove, 260);
        }

        lightboxState.el = null;

        if (lightboxState.lastFocus && lightboxState.lastFocus.focus) {
            try {
                lightboxState.lastFocus.focus();
            } catch (e) { /* عنصر حذف شده است */ }
        }
    }

    function initLightbox() {
        if (!enabled.lightbox) return;

        var heroImg = doc.querySelector('.post-hero img');
        if (heroImg) {
            heroImg.classList.add('lightbox-ready');
            heroImg.addEventListener('click', function () {
                openLightbox(0);
            });
        }

        var content = doc.getElementById('post-content');
        if (!content) return;

        var imgs = content.querySelectorAll('img');
        Array.prototype.forEach.call(imgs, function (img) {
            img.classList.add('lightbox-ready');
            img.addEventListener('click', function () {
                var hero = doc.querySelector('.post-hero img');
                var offset = hero ? 1 : 0;
                openLightbox(offset + Array.prototype.indexOf.call(imgs, img));
            });
        });
    }

    /* --------------------------------------------------------------
     *  دکمهٔ پسند (لایک)
     * -------------------------------------------------------------- */

    function initLikeButton() {
        if (!enabled.likes) return;

        var btn = doc.getElementById('like-button');
        if (!btn) return;

        var cid = parseInt(btn.getAttribute('data-cid'), 10) || 0;
        var token = btn.getAttribute('data-token') || '';
        var countEl = btn.querySelector('.like-count');
        var labelEl = btn.querySelector('.like-label');
        var storageKey = 'niloofarLikes';

        function readLikedIds() {
            try {
                var raw = JSON.parse(localStorage.getItem(storageKey) || '[]');
                return Array.isArray(raw) ? raw : [];
            } catch (e) {
                return [];
            }
        }

        function writeLikedIds(ids) {
            try {
                localStorage.setItem(storageKey, JSON.stringify(ids.slice(-200)));
            } catch (e) { /* حافظهٔ محلی در دسترس نیست */ }
        }

        function markLiked(withAnimation) {
            btn.classList.add('is-liked');
            btn.setAttribute('aria-pressed', 'true');
            if (labelEl) {
                labelEl.textContent = s('likeCount', 'پسند');
            }
            if (!withAnimation) {
                var icon = btn.querySelector('.like-icon');
                if (icon) {
                    icon.style.animation = 'none';
                }
            }
        }

        // بازیابی وضعیت پسند از حافظهٔ مرورگر
        if (readLikedIds().indexOf(cid) !== -1) {
            markLiked(false);
        }

        btn.addEventListener('click', function () {
            if (btn.classList.contains('is-busy')) return;

            if (btn.classList.contains('is-liked')) {
                toast(s('likeAlready', 'شما قبلاً این نوشته را پسندیده‌اید.'));
                return;
            }

            if (!cid || !token) {
                toast(s('likeFail', 'ثبت پسند ممکن نشد؛ دوباره بیازمایید.'));
                return;
            }

            btn.classList.add('is-busy');

            var body = 'niloofarLike=1&cid=' + encodeURIComponent(cid) + '&_=' + encodeURIComponent(token);

            fetch(win.location.href, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                },
                body: body
            })
                .then(function (response) {
                    return response.json();
                })
                .then(function (data) {
                    if (data && data.ok) {
                        if (countEl) {
                            countEl.textContent = faDigits(data.likes || 0);
                        }
                        markLiked(true);

                        if (data.status === 'liked') {
                            var ids = readLikedIds();
                            if (ids.indexOf(cid) === -1) {
                                ids.push(cid);
                                writeLikedIds(ids);
                            }
                            toast(data.message || s('likeOk', 'پسند شما ثبت شد؛ سپاسگزارم!'));
                        } else {
                            toast(data.message || s('likeAlready', 'شما قبلاً این نوشته را پسندیده‌اید.'));
                        }
                    } else {
                        toast((data && data.message) || s('likeFail', 'ثبت پسند ممکن نشد؛ دوباره بیازمایید.'));
                    }
                })
                .catch(function () {
                    toast(s('likeFail', 'ثبت پسند ممکن نشد؛ دوباره بیازمایید.'));
                })
                .then(function () {
                    btn.classList.remove('is-busy');
                });
        });
    }

    /* --------------------------------------------------------------
     *  کپی لینک نوشته
     * -------------------------------------------------------------- */

    function initCopyLink() {
        var btn = doc.querySelector('.js-copy-link');
        if (!btn) return;

        function done() {
            btn.classList.add('is-copied');
            var span = btn.querySelector('span');
            toast(s('copyOk', 'لینک نوشته کپی شد!'));
            setTimeout(function () {
                btn.classList.remove('is-copied');
            }, 2000);
        }

        function fallbackCopy() {
            var input = doc.createElement('textarea');
            input.value = win.location.href;
            input.setAttribute('readonly', '');
            input.style.position = 'absolute';
            input.style.left = '-9999px';
            doc.body.appendChild(input);
            input.select();
            try {
                doc.execCommand('copy');
                done();
            } catch (e) {
                toast(s('copyFail', 'کپی لینک ممکن نشد.'));
            }
            doc.body.removeChild(input);
        }

        btn.addEventListener('click', function () {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(win.location.href)
                    .then(done)
                    .catch(fallbackCopy);
            } else {
                fallbackCopy();
            }
        });
    }

    /* --------------------------------------------------------------
     *  بستن منوی موبایل با کلیک بیرون
     * -------------------------------------------------------------- */

    function initMobileNav() {
        var navToggle = doc.getElementById('nav-toggle');
        if (!navToggle) return;

        doc.addEventListener('click', function (e) {
            if (navToggle.checked && !e.target.closest('.site-nav') && !e.target.closest('.nav-burger')) {
                navToggle.checked = false;
            }
        });

        // بستن منو پس از انتخاب هر آیتم در موبایل
        var navLinks = doc.querySelectorAll('.nav-menu a');
        Array.prototype.forEach.call(navLinks, function (link) {
            link.addEventListener('click', function () {
                navToggle.checked = false;
            });
        });
    }

    /* --------------------------------------------------------------
     *  راه‌اندازی
     * -------------------------------------------------------------- */

    function ready(fn) {
        if (doc.readyState !== 'loading') {
            fn();
        } else {
            doc.addEventListener('DOMContentLoaded', fn);
        }
    }

    ready(function () {
        initThemeSwitch();
        initSearchOverlay();
        initScrollFeatures();
        initMobileNav();
        initGallery();
        initToc();
        initLightbox();
        initLikeButton();
        initCopyLink();
        initReveal();

        // پرش نرم به لینک‌های داخلی (فهرست مطالب)
        if (win.location.hash) {
            var target = doc.getElementById(win.location.hash.slice(1));
            if (target && target.scrollIntoView) {
                setTimeout(function () {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 120);
            }
        }
    });
})();
