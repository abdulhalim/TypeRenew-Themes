<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<aside class="layout-sidebar" aria-label="<?php _e('ستون کناری'); ?>">

    <?php $sidebarBio = trim((string) niloofarOpt('sidebarBio')); ?>
    <?php $siteAuthor = niloofarSiteAuthorInfo(); ?>
    <section class="widget widget-about">
        <h3 class="widget-title">
            <?php echo niloofarIcon('user', 15); ?>
            <?php _e('دربارهٔ نویسنده'); ?>
        </h3>
        <div class="about-card">
            <div class="about-card-avatar" aria-hidden="true">
                <?php echo niloofarSiteAuthorAvatar(64); ?>
            </div>
            <p class="about-card-name"><?php echo htmlspecialchars($siteAuthor['name'] !== '' ? $siteAuthor['name'] : (string) $this->options->title, ENT_QUOTES, 'UTF-8'); ?></p>
            <?php if ($sidebarBio !== ''): ?>
                <p class="about-card-bio"><?php echo htmlspecialchars($sidebarBio, ENT_QUOTES, 'UTF-8'); ?></p>
            <?php else: ?>
                <p class="about-card-bio"><?php _e('به این وبلاگ خوش آمدید؛ جایی برای ثبت داستان‌های کوچک و بزرگ.'); ?></p>
            <?php endif; ?>
        </div>
    </section>

    <?php
        $popularCount = intval((string) niloofarOpt('popularCount', '5'));
        if ($popularCount > 0):
            NiloofarPopularPosts::alloc('pageSize=' . $popularCount)->to($popular);
            if ($popular->have()):
    ?>
    <section class="widget widget-popular">
        <h3 class="widget-title">
            <?php echo niloofarIcon('flame', 15); ?>
            <?php _e('محبوب‌ترین نوشته‌ها'); ?>
        </h3>
        <ol class="popular-list">
            <?php $rank = 0; while ($popular->next()): $rank++; ?>
                <?php niloofarRenderPopularItem($popular, $rank); ?>
            <?php endwhile; ?>
        </ol>
    </section>
    <?php endif; endif; ?>

    <?php \Widget\Metas\Category\Rows::alloc()->to($categories); ?>
    <?php if ($categories->have()): ?>
    <section class="widget widget-categories">
        <h3 class="widget-title">
            <?php echo niloofarIcon('folder', 15); ?>
            <?php _e('دسته‌بندی‌ها'); ?>
        </h3>
        <ul class="category-list">
            <?php while ($categories->next()): ?>
                <li class="category-item">
                    <a href="<?php $categories->permalink(); ?>"><?php $categories->name(); ?></a>
                    <span class="category-count"><?php echo niloofarFa((string) $categories->count); ?></span>
                </li>
            <?php endwhile; ?>
        </ul>
    </section>
    <?php endif; ?>

</aside>
