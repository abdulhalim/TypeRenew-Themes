<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/* ============================================================
 * ۱) ابزارهای عمومی
 * ============================================================ */

/**
 * خواندن تنظیم پوسته همراه با مقدار پیش‌فرض
 */
function niloofarOpt(string $name, ?string $default = null): ?string
{
    $value = \Widget\Options::alloc()->{$name};
    return ($value === null || $value === '') ? $default : $value;
}

/**
 * تبدیل ارقام لاتین به فارسی
 */
function niloofarFa(?string $text): string
{
    return strtr((string) $text, [
        '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
        '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
    ]);
}

/**
 * تبدیل ارقام لاتین متن خروجی صفحه‌بندی به فارسی؛
 * فقط متنِ میان تگ‌ها تبدیل می‌شود تا نشانی لینک‌ها دست‌نخورده بماند.
 */
function niloofarNavDigits(string $html): string
{
    return (string) preg_replace_callback(
        '/>([^<>]+)</u',
        function (array $matches): string {
            return '>' . niloofarFa($matches[1]) . '<';
        },
        $html
    );
}

/**
 * قالب‌بندی خلاصهٔ اعداد به سبک شبکه‌های اجتماعی با ارقام فارسی:
 * ۹۹۹ → ۹۹۹ / ۱۰۰۰ → ۱ هزار / ۱۵۰۰ → ۱٫۵ هزار / ۱۰۰۰۰ → ۱۰ هزار / ۱۲۰۰۰۰۰ → ۱٫۲ میلیون
 */
function niloofarFormatCount(int $num): string
{
    if ($num >= 1000000) {
        return niloofarCompactNumber(round($num / 1000000, 1)) . ' ' . _t('میلیون');
    }

    if ($num >= 1000) {
        $thousands = round($num / 1000, 1);

        // گردشدن به ۱۰۰۰ هزار (مثل ۹۹۹۹۹۹) باید «۱ میلیون» نمایش دهد
        if ($thousands >= 1000) {
            return niloofarCompactNumber(round($thousands / 1000, 1)) . ' ' . _t('میلیون');
        }

        return niloofarCompactNumber($thousands) . ' ' . _t('هزار');
    }

    return niloofarFa((string) $num);
}

/**
 * عدد اعشاری خلاصه با ارقام فارسی؛ رقم اعشار تنها در صورت نیاز (۱٫۵ و نه ۱٫۰)
 */
function niloofarCompactNumber(float $value): string
{
    $text = number_format($value, 1, '.', '');

    if (substr($text, -2) === '.0') {
        $text = substr($text, 0, -2);
    }

    return niloofarFa(str_replace('.', '٫', $text));
}

/**
 * متن فارسی تعداد دیدگاه با ارقام فارسی
 */
function niloofarCommentsText(int $num): string
{
    if ($num <= 0) {
        return _t('بدون دیدگاه');
    }

    if ($num === 1) {
        return _t('۱ دیدگاه');
    }

    return niloofarFa((string) $num) . ' ' . _t('دیدگاه');
}

/**
 * نرمال‌سازی آدرس تصویر (نسبی → مطلق)
 */
function niloofarResolveUrl(string $url): string
{
    $url = trim($url);
    if ($url === '') {
        return '';
    }

    // data-uri یا آدرس مطلق یا پروتکل‌نسبی
    if (preg_match('#^(data:|https?://|//)#i', $url)) {
        return $url;
    }

    $base = rtrim((string) \Widget\Options::alloc()->siteUrl, '/');
    return $base . '/' . ltrim($url, '/');
}

/**
 * پیدا کردن تصویر شاخص نوشته
 *
 * اولویت: ۱) فیلد اختصاصی thumb
 *          ۲) نخستین تصویر داخل متن نوشته (HTML یا مارک‌داون)
 *          ۳) تصویر شاخص پیش‌فرض تنظیمات پوسته
 */
function niloofarThumbnail(\Widget\Base\Contents $content): string
{
    // ۱) فیلد اختصاصی
    $thumb = trim((string) ($content->fields->thumb ?? ''));
    if ($thumb !== '') {
        return niloofarResolveUrl($thumb);
    }

    // ۲) نخستین تصویر متن خام (بدون اجرای موتور مارک‌داون — سریع است)
    $text = (string) $content->text;
    if ($text !== '') {
        if (preg_match('#<img[^>]*\bsrc=["\']([^"\']+)["\']#iu', $text, $matches)) {
            return niloofarResolveUrl($matches[1]);
        }
        if (preg_match('#!\[[^\]]*\]\(\s*<?([^)\s>]+)[^)]*\)#iu', $text, $matches)) {
            return niloofarResolveUrl($matches[1]);
        }
    }

    // ۳) تصویر پیش‌فرض پوسته
    $default = trim((string) niloofarOpt('defaultCover'));
    if ($default !== '') {
        return niloofarResolveUrl($default);
    }

    return '';
}

/**
 * برآورد زمان مطالعه (دقیقه) بر اساس تعداد واژه‌ها
 */
function niloofarReadingTime(\Widget\Base\Contents $content): int
{
    $text = (string) $content->text;

    // حذف تصاویر، لینک‌ها و بلوک‌های کد از متن خام
    $text = preg_replace('#```.*?```#s', ' ', $text) ?? $text;
    $text = preg_replace('#`[^`]*`#', ' ', $text) ?? $text;
    $text = preg_replace('#!\[[^\]]*\]\([^)]*\)#', ' ', $text) ?? $text;
    $text = preg_replace('#<[^>]+>#', ' ', $text) ?? $text;

    $words = preg_split('/\s+/u', trim($text), -1, PREG_SPLIT_NO_EMPTY);
    $count = is_array($words) ? count($words) : 0;

    if ($count === 0) {
        return 1;
    }

    // سرعت خواندن فارسی: حدود ۲۲۰ واژه در دقیقه
    return max(1, (int) ceil($count / 220));
}

/**
 * چکیدهٔ تمیز برای کارت‌های فهرست (با احترام به برش واژه‌ها)
 */
function niloofarExcerpt(\Widget\Base\Contents $content, int $words = 26): string
{
    $text = trim((string) $content->excerpt);

    if ($text === '') {
        $text = trim((string) $content->plainExcerpt);
    }

    $text = trim(preg_replace('/\s+/u', ' ', strip_tags($text)) ?? '');
    $parts = preg_split('/\s+/u', $text, $words + 1, PREG_SPLIT_NO_EMPTY);

    if (is_array($parts) && count($parts) > $words) {
        array_pop($parts);
        return implode(' ', $parts) . '…';
    }

    return $text;
}

/**
 * ترجمهٔ نام ماه‌ها و روزهای هفتهٔ میلادی به فارسی.
 * پلاگین تاریخ شمسی (مثل JalaliDate) خودش نام‌های فارسی برمی‌گرداند و
 * این نگاشت روی آن اثری ندارد؛ فقط خروجی انگلیسیِ حالت پیش‌فرض را
 * فارسی می‌کند تا ترکیبی مانند «۳۰ August ۲۰۲۶» رخ ندهد.
 */
function niloofarFaCalendar(string $text): string
{
    static $map = null;

    if ($map === null) {
        $map = [
            'January'  => 'ژانویه', 'February' => 'فوریه', 'March'     => 'مارس',
            'April'    => 'آوریل',  'May'      => 'مه',     'June'      => 'ژوئن',
            'July'     => 'ژوئیه', 'August'   => 'اوت',    'September' => 'سپتامبر',
            'October'  => 'اکتبر', 'November' => 'نوامبر', 'December'  => 'دسامبر',
            'Jan' => 'ژانویه', 'Feb' => 'فوریه', 'Mar' => 'مارس',  'Apr' => 'آوریل',
            'Jun' => 'ژوئن',   'Jul' => 'ژوئیه', 'Aug' => 'اوت',   'Sep' => 'سپتامبر',
            'Oct' => 'اکتبر', 'Nov' => 'نوامبر', 'Dec' => 'دسامبر',
            'Monday'    => 'دوشنبه',   'Tuesday'  => 'سه‌شنبه', 'Wednesday' => 'چهارشنبه',
            'Thursday'  => 'پنجشنبه', 'Friday'   => 'جمعه',    'Saturday'  => 'شنبه',
            'Sunday'    => 'یکشنبه',
            'Mon' => 'دوشنبه', 'Tue' => 'سه‌شنبه', 'Wed' => 'چهارشنبه', 'Thu' => 'پنجشنبه',
            'Fri' => 'جمعه',   'Sat' => 'شنبه',    'Sun' => 'یکشنبه',
        ];
    }

    return strtr($text, $map);
}

/**
 * تاریخ سیستم با ارقام فارسی — سازگار با پلاگین تاریخ شمسی (JalaliDate).
 * از API استاندارد تاریخ TypeRenew استفاده می‌شود؛ پلاگین شمسی در صورت
 * فعال‌بودن، خودش خروجی را به تقویم جلالی تبدیل می‌کند.
 */
function niloofarDate(\Widget\Base\Contents $content, string $format = 'j F Y'): string
{
    try {
        return niloofarFa(niloofarFaCalendar($content->date->format($format)));
    } catch (\Throwable $e) {
        return niloofarFa(niloofarFaCalendar(date($format, (int) $content->created)));
    }
}

/**
 * تاریخ دیدگاه با ارقام فارسی (سازگار با پلاگین شمسی)
 */
function niloofarCommentDate($comments, string $format = 'j F Y، ساعت H:i'): string
{
    try {
        return niloofarFa(niloofarFaCalendar($comments->date->format($format)));
    } catch (\Throwable $e) {
        return niloofarFa(niloofarFaCalendar(date($format, (int) $comments->created)));
    }
}

/* ============================================================
 * ۲) آواتار — گراواتار با پیش‌فرض محلی پوسته
 * ============================================================ */

/**
 * نشانی آواتار پیش‌فرض پوسته (در پوشهٔ تصاویر پوسته)
 */
function niloofarDefaultAvatarUrl(): string
{
    $themeUrl = rtrim((string) \Widget\Options::alloc()->themeUrl, '/');
    return $themeUrl . '/assets/img/avatar.webp';
}

/**
 * نشانی آواتار: اگر کاربر گراواتار داشته باشد از گراواتار،
 * وگرنه آواتار پیش‌فرض محلی پوسته (بدون هیچ درخواست خارجی اجباری).
 */
function niloofarAvatarUrl(?string $mail, int $size = 48): string
{
    $mode = (string) niloofarOpt('avatarMode', 'gravatar');
    $default = niloofarDefaultAvatarUrl();

    if ($mode === 'local' || $mail === null || trim($mail) === '') {
        return $default;
    }

    try {
        $secure = \Typecho\Request::getInstance()->isSecure();
        return \Typecho\Common::gravatarUrl($mail, $size, 'g', $default, $secure);
    } catch (\Throwable $e) {
        return $default;
    }
}

/**
 * تصویر آواتار کامل برای نویسندهٔ نوشته
 */
function niloofarAuthorAvatar($archive, int $size = 56): string
{
    $mail = '';
    try {
        $mail = (string) $archive->author->mail;
    } catch (\Throwable $e) {
        $mail = '';
    }

    $name = '';
    try {
        $name = (string) $archive->author->screenName;
    } catch (\Throwable $e) {
        $name = '';
    }

    $url = niloofarAvatarUrl($mail, $size);

    return '<img class="avatar" src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '"'
        . ' alt="' . htmlspecialchars($name !== '' ? $name : _t('نویسنده'), ENT_QUOTES, 'UTF-8') . '"'
        . ' width="' . $size . '" height="' . $size . '" loading="lazy" decoding="async" />';
}

/**
 * اطلاعات نویسندهٔ اصلی سایت (نخستین کاربر — بنیان‌گذار وبلاگ)
 */
function niloofarSiteAuthorInfo(): array
{
    static $info = null;

    if ($info !== null) {
        return $info;
    }

    $info = ['name' => '', 'mail' => ''];

    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.users.screenName', 'table.users.mail')
                ->from('table.users')
                ->order('table.users.uid', \Typecho\Db::SORT_ASC)
                ->limit(1)
        );

        if ($row) {
            $info['name'] = (string) ($row['screenName'] ?? '');
            $info['mail'] = (string) ($row['mail'] ?? '');
        }
    } catch (\Throwable $e) {
        // بی‌خیال؛ آواتار پیش‌فرض محلی استفاده می‌شود
    }

    return $info;
}

/**
 * آواتار نویسندهٔ اصلی سایت (برای کارت «درباره» در پانوشت چیدمان تک‌ستونه)
 */
function niloofarSiteAuthorAvatar(int $size = 72): string
{
    $info = niloofarSiteAuthorInfo();
    $url = niloofarAvatarUrl($info['mail'] !== '' ? $info['mail'] : null, $size);

    return '<img class="avatar" src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '"'
        . ' alt="' . htmlspecialchars($info['name'] !== '' ? $info['name'] : _t('نویسنده'), ENT_QUOTES, 'UTF-8') . '"'
        . ' width="' . $size . '" height="' . $size . '" loading="lazy" decoding="async" />';
}

/**
 * تصویر آواتار کامل برای کاربر واردشده فعلی
 */
function niloofarUserAvatar(int $size = 36): string
{
    $user = \Widget\User::alloc();
    $mail = '';
    $name = '';

    try {
        if ($user->hasLogin()) {
            $mail = (string) $user->mail;
            $name = (string) $user->screenName;
        }
    } catch (\Throwable $e) {
        $mail = '';
    }

    $url = niloofarAvatarUrl($mail, $size);

    return '<img class="avatar" src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '"'
        . ' alt="' . htmlspecialchars($name !== '' ? $name : _t('کاربر'), ENT_QUOTES, 'UTF-8') . '"'
        . ' width="' . $size . '" height="' . $size . '" loading="lazy" decoding="async" />';
}

/**
 * تصویر آواتار کامل برای دیدگاه
 */
function niloofarCommentAvatar($comments, int $size = 48): string
{
    $mail = '';
    try {
        $mail = (string) $comments->mail;
    } catch (\Throwable $e) {
        $mail = '';
    }

    $name = '';
    try {
        $name = (string) $comments->author;
    } catch (\Throwable $e) {
        $name = '';
    }

    $url = niloofarAvatarUrl($mail, $size);

    return '<img class="avatar" src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '"'
        . ' alt="' . htmlspecialchars($name !== '' ? $name : _t('کاربر'), ENT_QUOTES, 'UTF-8') . '"'
        . ' width="' . $size . '" height="' . $size . '" loading="lazy" decoding="async" />';
}

/* ============================================================
 * ۳) سیستم آمار بازدید — ستون views (الگوی ViewsCounter)
 * ============================================================ */

/**
 * تعداد بازدید نوشته از ستون views جدول محتوا
 */
function niloofarGetViews($archive): int
{
    try {
        return max(0, (int) $archive->views);
    } catch (\Throwable $e) {
        return 0;
    }
}

/**
 * اطمینان از وجود ستون views در جدول محتوا — یکپارچه‌سازی خودکار.
 * آمار پوسته‌های پیشین (فیلد views در جدول fields) در نخستین اجرا منتقل می‌شود.
 */
function niloofarViewsSchemaReady(): bool
{
    static $ready = null;

    if ($ready !== null) {
        return $ready;
    }

    $ready = false;

    try {
        $db = \Typecho\Db::get();

        try {
            $db->fetchRow($db->select('table.contents.views')->from('table.contents')->limit(1));
            $columnExists = true;
        } catch (\Throwable $e) {
            $columnExists = false;
        }

        if (!$columnExists) {
            $prefix = $db->getPrefix();
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT DEFAULT 0');

            // انتقال آمار بازدید نسخه‌های پیشین
            try {
                $db->query(
                    'UPDATE `' . $prefix . 'contents` SET views = COALESCE((SELECT SUM(f.int_value)'
                    . ' FROM `' . $prefix . 'fields` f WHERE f.cid = `' . $prefix
                    . 'contents`.cid AND f.name = \'views\' AND f.type = \'int\'), 0)'
                );
                $db->query('DELETE FROM `' . $prefix . 'fields` WHERE name = \'views\' AND type = \'int\'');
            } catch (\Throwable $e) {
                // انتقال آمار اختیاری است و نباید نمایش صفحه را متوقف کند
            }
        }

        $ready = true;
    } catch (\Throwable $e) {
        // نبود دسترسی کافی به دیتابیس نباید سایت را از کار بیندازد
        $ready = false;
    }

    return $ready;
}

/**
 * شمارش بازدید صفحات تکی — یکپارچه با پلاگین ViewsCounter
 */
function niloofarCountView($archive): void
{
    // اگر پلاگین مستقل ViewsCounter فعال باشد، خودش شمارش می‌کند (شمارش مضاعف نمی‌شود)
    $activatedPlugins = \Widget\Options::alloc()->plugins;
    if (is_array($activatedPlugins) && isset($activatedPlugins['activated']['ViewsCounter'])) {
        return;
    }

    // بازدید کاربران واردشده (مدیر و اعضا) طبق تنظیم پوسته شمرده می‌شود یا نه
    $countLoggedIn = ((string) niloofarOpt('countLoggedInViews', '0')) === '1';
    if (\Widget\User::alloc()->hasLogin() && !$countLoggedIn) {
        return;
    }

    // شمارش فقط برای صفحات تکی انجام می‌شود
    if (!$archive instanceof \Widget\Archive || !$archive->is('single')) {
        return;
    }

    $cid = intval($archive->cid);

    if ($cid < 1) {
        return;
    }

    // فاصله زمانی جلوگیری از شمارش بازدیدهای مکرر
    $interval = (int) niloofarOpt('viewsInterval', '3600');

    if ($interval > 0) {
        $viewed = (string) \Typecho\Cookie::get('niloofarViews', '');
        $viewedIds = $viewed === '' ? [] : explode(',', $viewed);

        if (in_array((string) $cid, $viewedIds, true)) {
            return;
        }

        $viewedIds[] = (string) $cid;

        // جلوگیری از بزرگ‌شدن بی‌رویه کوکی
        if (count($viewedIds) > 100) {
            $viewedIds = array_slice($viewedIds, -100);
        }

        \Typecho\Cookie::set('niloofarViews', implode(',', $viewedIds), time() + $interval);
    }

    if (!niloofarViewsSchemaReady()) {
        return;
    }

    try {
        $db = \Typecho\Db::get();
        $db->query(
            $db->update('table.contents')
                ->expression('views', 'views + 1')
                ->where('cid = ?', $cid)
        );
    } catch (\Throwable $e) {
        // خطا در شمارش بازدید نباید نمایش صفحه را متوقف کند
    }
}

/* ============================================================
 * ۴) سیستم لایک نوشته‌ها — AJAX + ستون likes
 * ============================================================ */

/**
 * اطمینان از وجود ستون likes در جدول محتوا — یکپارچه‌سازی خودکار.
 * آمار احتمالی پوسته‌های دیگر (فیلد likes در جدول fields) منتقل می‌شود.
 */
function niloofarLikesSchemaReady(): bool
{
    static $ready = null;

    if ($ready !== null) {
        return $ready;
    }

    $ready = false;

    try {
        $db = \Typecho\Db::get();

        try {
            $db->fetchRow($db->select('table.contents.likes')->from('table.contents')->limit(1));
            $columnExists = true;
        } catch (\Throwable $e) {
            $columnExists = false;
        }

        if (!$columnExists) {
            $prefix = $db->getPrefix();
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `likes` INT DEFAULT 0');

            // انتقال آمار لایک نسخه‌های پیشین
            try {
                $db->query(
                    'UPDATE `' . $prefix . 'contents` SET likes = COALESCE((SELECT SUM(f.int_value)'
                    . ' FROM `' . $prefix . 'fields` f WHERE f.cid = `' . $prefix
                    . 'contents`.cid AND f.name = \'likes\' AND f.type = \'int\'), 0)'
                );
                $db->query('DELETE FROM `' . $prefix . 'fields` WHERE name = \'likes\' AND type = \'int\'');
            } catch (\Throwable $e) {
                // انتقال آمار اختیاری است
            }
        }

        $ready = true;
    } catch (\Throwable $e) {
        $ready = false;
    }

    return $ready;
}

/**
 * تعداد لایک نوشته از ستون likes جدول محتوا
 */
function niloofarGetLikes($archive): int
{
    try {
        return max(0, (int) $archive->likes);
    } catch (\Throwable $e) {
        return 0;
    }
}

/**
 * توکن امنیتی دکمهٔ لایک (HMAC سایت — الگوی امنیتی TypeRenew)
 */
function niloofarLikeToken(int $cid): string
{
    try {
        return (string) \Widget\Security::alloc()->getToken('niloofar-like-' . $cid);
    } catch (\Throwable $e) {
        return '';
    }
}

/**
 * خواندن تعداد فعلی لایک یک نوشته از دیتابیس
 */
function niloofarFetchLikes(int $cid): int
{
    try {
        $db = \Typecho\Db::get();
        return max(0, (int) $db->fetchObject(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        )->likes);
    } catch (\Throwable $e) {
        return 0;
    }
}

/**
 * پاسخ JSON و پایان اجرا — پیش از هر خروجی صفحه
 */
function niloofarJsonResponse(array $payload): void
{
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * رسیدگی به درخواست AJAX دکمهٔ لایک
 *
 * جریان: POST به نشانی خود نوشته با پارامترهای
 * niloofarLike=1 و cid و _ (توکن امنیتی)
 */
function niloofarHandleLikeRequest(\Widget\Archive $archive): void
{
    $cid = (int) $archive->request->filter('int')->get('cid', 0);
    $token = (string) $archive->request->get('_', '');

    $payload = ['ok' => false, 'status' => 'error', 'likes' => 0, 'message' => ''];

    do {
        if ($cid < 1) {
            $payload['message'] = _t('نوشتهٔ درخواستی نامعتبر است.');
            break;
        }

        // اعتبارسنجی توکن امنیتی (جلوگیری از جعل درخواست)
        if ($token === '' || !hash_equals(niloofarLikeToken($cid), $token)) {
            $payload['message'] = _t('درخواست نامعتبر است؛ صفحه را دوباره بارگذاری کنید.');
            break;
        }

        // بررسی وجود و انتشار نوشته
        try {
            $db = \Typecho\Db::get();
            $row = $db->fetchRow(
                $db->select('table.contents.cid', 'table.contents.type', 'table.contents.status')
                    ->from('table.contents')
                    ->where('table.contents.cid = ?', $cid)
            );
        } catch (\Throwable $e) {
            $row = null;
        }

        if (!$row || ($row['status'] ?? '') !== 'publish' || !in_array($row['type'] ?? '', ['post', 'page'], true)) {
            $payload['message'] = _t('نوشتهٔ درخواستی یافت نشد.');
            break;
        }

        if (!niloofarLikesSchemaReady()) {
            $payload['message'] = _t('خطا در دسترسی به پایگاه داده.');
            break;
        }

        // جلوگیری از لایک تکراری با کوکی (هر بازدیدکننده یک لایک برای هر نوشته)
        $liked = array_values(array_filter(explode(',', (string) \Typecho\Cookie::get('niloofarLikes', ''))));

        if (in_array((string) $cid, $liked, true)) {
            $payload = [
                'ok'      => true,
                'status'  => 'already',
                'likes'   => niloofarFetchLikes($cid),
                'message' => _t('شما قبلاً این نوشته را پسندیده‌اید.'),
            ];
            break;
        }

        // ثبت لایک
        try {
            $db = \Typecho\Db::get();
            $db->query(
                $db->update('table.contents')
                    ->expression('likes', 'likes + 1')
                    ->where('cid = ?', $cid)
            );

            $liked[] = (string) $cid;

            // نگهداری حداکثر ۲۰۰ شناسه در کوکی
            if (count($liked) > 200) {
                $liked = array_slice($liked, -200);
            }

            \Typecho\Cookie::set('niloofarLikes', implode(',', $liked), time() + 31536000);

            $payload = [
                'ok'      => true,
                'status'  => 'liked',
                'likes'   => niloofarFetchLikes($cid),
                'message' => _t('پسند شما ثبت شد؛ سپاسگزارم!'),
            ];
        } catch (\Throwable $e) {
            $payload['message'] = _t('ثبت پسند با خطا روبه‌رو شد؛ کمی بعد دوباره بیازمایید.');
        }
    } while (false);

    niloofarJsonResponse($payload);
}

/* ============================================================
 * ۵) راه‌انداز پوسته
 * ============================================================ */

function themeInit(\Widget\Archive $archive)
{
    // درخواست AJAX دکمهٔ لایک — پیش از هر خروجی پاسخ داده می‌شود
    if ($archive->request->isPost() && $archive->request->isAjax() && $archive->request->is('niloofarLike=1')) {
        niloofarHandleLikeRequest($archive);
    }

    // شمارندهٔ بازدید یکپارچه در همه قالب‌های نشانی (cid یا slug)
    \Typecho\Plugin::factory('Widget\Archive')->beforeRender = 'niloofarCountView';
}

/* ============================================================
 * ۶) آمار کلی سایت برای بخش هرو
 * ============================================================ */

function niloofarStats(): array
{
    $posts = 0;
    $comments = 0;
    $views = 0;
    $likes = 0;

    try {
        $db = \Typecho\Db::get();
        $posts = (int) $db->fetchObject(
            $db->select(['COUNT(table.contents.cid)' => 'num'])
                ->from('table.contents')
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.status = ?', 'publish')
        )->num;
        $comments = (int) $db->fetchObject(
            $db->select(['COUNT(table.comments.coid)' => 'num'])
                ->from('table.comments')
                ->where('table.comments.type = ?', 'comment')
                ->where('table.comments.status = ?', 'approved')
        )->num;

        if (niloofarViewsSchemaReady()) {
            $views = (int) $db->fetchObject(
                $db->select(['COALESCE(SUM(table.contents.views), 0)' => 'total'])
                    ->from('table.contents')
                    ->where('table.contents.status = ?', 'publish')
            )->total;
        }

        if (niloofarLikesSchemaReady()) {
            $likes = (int) $db->fetchObject(
                $db->select(['COALESCE(SUM(table.contents.likes), 0)' => 'total'])
                    ->from('table.contents')
                    ->where('table.contents.status = ?', 'publish')
            )->total;
        }
    } catch (\Throwable $e) {
        // خطای پایگاه داده نباید نمایش سایت را متوقف کند
    }

    return ['posts' => $posts, 'comments' => $comments, 'views' => $views, 'likes' => $likes];
}

/* ============================================================
 * ۷) تنظیمات پوسته در پیشخوان
 * ============================================================ */

function themeConfig($form)
{
    $yes = _t('نمایش');
    $no = _t('پنهان');

    /* --- هویت سایت --- */

    $logoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'logoUrl',
        null,
        null,
        _t('نشانی لوگو'),
        _t('نشانی یک تصویر را وارد کنید تا در کنار عنوان سایت نمایش داده شود؛ اگر خالی بماند، عنوان سایت با نشان نیلوفر نمایش داده می‌شود.')
    );
    $form->addInput($logoUrl->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    /* --- ظاهر --- */

    $colorSchema = new \Typecho\Widget\Helper\Form\Element\Select(
        'colorSchema',
        [
            'auto'  => _t('خودکار (پیروی از تنظیمات سیستم کاربر)'),
            'light' => _t('روشن'),
            'dark'  => _t('تیره'),
        ],
        'auto',
        _t('حالت رنگی پیش‌فرض'),
        _t('بازدیدکننده می‌تواند با دکمهٔ ماه/خورشید در سربرگ، حالت را عوض کند.')
    );
    $form->addInput($colorSchema);

    $accentPreset = new \Typecho\Widget\Helper\Form\Element\Select(
        'accentPreset',
        [
            'turquoise' => _t('فیروزه‌ای (پیشنهادی)'),
            'violet'    => _t('بنفش یاسی'),
            'amber'     => _t('کهربایی'),
        ],
        'turquoise',
        _t('پالت رنگی'),
        _t('رنگ اصلی لینک‌ها، دکمه‌ها، نشانگر پیشرفت مطالعه و عناصر تأکیدی پوسته.')
    );
    $form->addInput($accentPreset);

    $layoutMode = new \Typecho\Widget\Helper\Form\Element\Select(
        'layoutMode',
        [
            'single'  => _t('تک‌ستونهٔ مدرن (پیشنهادی)'),
            'sidebar' => _t('همراه با ستون کناری'),
        ],
        'single',
        _t('چیدمان صفحات'),
        _t('در حالت تک‌ستونه محتوا در مرکز صفحه قرار می‌گیرد و بخش‌های محبوب‌ترین‌ها و درباره در پایان صفحه نمایش داده می‌شوند؛ در حالت ستون کناری، ویجت‌ها در ستون کنار محتوا دیده می‌شوند.')
    );
    $form->addInput($layoutMode);

    /* --- هرو صفحه اصلی --- */

    $showHero = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showHero',
        ['1' => $yes, '0' => $no],
        '1',
        _t('هرو صفحه اصلی'),
        _t('نمایش بخش معرفی در بالای صفحه اصلی؛ شامل عنوان سایت، شعار و آمار.')
    );
    $form->addInput($showHero);

    $heroTagline = new \Typecho\Widget\Helper\Form\Element\Text(
        'heroTagline',
        null,
        null,
        _t('شعار هرو'),
        _t('متنی کوتاه برای هرو؛ اگر خالی بماند، توضیحات سایت از تنظیمات عمومی نمایش داده می‌شود.')
    );
    $form->addInput($heroTagline);

    $heroStats = new \Typecho\Widget\Helper\Form\Element\Checkbox(
        'heroStats',
        [
            'posts'    => _t('تعداد نوشته‌ها'),
            'comments' => _t('تعداد دیدگاه‌ها'),
            'views'    => _t('مجموع بازدیدها'),
            'likes'    => _t('مجموع پسندها'),
        ],
        ['posts', 'comments', 'views', 'likes'],
        _t('آمار هرو'),
        _t('انتخاب کنید کدام آمار در هرو صفحه اصلی نمایش داده شود؛ اگر هیچ‌کدام انتخاب نشود، بخش آمار به‌طور کامل حذف می‌شود. اعداد به‌صورت خلاصه و با ارقام فارسی نمایش داده می‌شوند (۱ هزار / ۱٫۲ میلیون).')
    );
    $form->addInput($heroStats);

    $heroImage = new \Typecho\Widget\Helper\Form\Element\Text(
        'heroImage',
        null,
        null,
        _t('تصویر پس‌زمینهٔ هرو'),
        _t('نشانی یک تصویر بزرگ وارد کنید تا در پس‌زمینهٔ بخش هرو (پشت عنوان سایت و آمار) نمایش داده شود. خالی بماند تا پس‌زمینهٔ گرادیانی ساده نمایش داده شود.')
    );
    $form->addInput($heroImage->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $heroOverlay = new \Typecho\Widget\Helper\Form\Element\Select(
        'heroOverlay',
        [
            'grid'  => _t('شبکه‌ای (پیشنهادی)'),
            'dots'  => _t('نقطه‌ای'),
            'none'  => _t('بدون روکش تزئینی'),
        ],
        'grid',
        _t('روکش تصویر هرو'),
        _t('الگوی تزئینیِ روی تصویر پس‌زمینهٔ هرو؛ در هر حالت یک لایهٔ تیرهٔ ملایم برای خوانایی متن نگه داشته می‌شود.')
    );
    $form->addInput($heroOverlay);

    /* --- آواتار --- */

    $avatarMode = new \Typecho\Widget\Helper\Form\Element\Select(
        'avatarMode',
        [
            'gravatar' => _t('گراواتار + پیش‌فرض محلی (پیشنهادی)'),
            'local'    => _t('همیشه آواتار محلی پوسته'),
        ],
        'gravatar',
        _t('حالت آواتار'),
        _t('در حالت اول، اگر کاربر گراواتار داشته باشد نمایش داده می‌شود و در غیر این صورت آواتار پیش‌فرض پوسته (پوشهٔ تصاویر پوسته) استفاده می‌شود؛ حالت دوم هیچ درخواستی به بیرون از سایت نمی‌فرستد.')
    );
    $form->addInput($avatarMode);

    /* --- تصویر شاخص --- */

    $defaultCover = new \Typecho\Widget\Helper\Form\Element\Text(
        'defaultCover',
        null,
        null,
        _t('تصویر شاخص پیش‌فرض'),
        _t('اگر نوشته‌ای نه فیلد تصویر شاخص داشت و نه تصویری در متنش بود، این تصویر نمایش داده می‌شود. خالی بماند تا به‌جای آن طرح تزئینی نیلوفر نمایش داده شود.')
    );
    $form->addInput($defaultCover->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    /* --- امکانات نوشته --- */

    $enableLikes = new \Typecho\Widget\Helper\Form\Element\Radio(
        'enableLikes',
        ['1' => $yes, '0' => $no],
        '1',
        _t('دکمهٔ پسند (لایک)'),
        _t('نمایش دکمهٔ قلب در پایان هر نوشته؛ هر بازدیدکننده یک بار می‌تواند نوشته را بپسندد.')
    );
    $form->addInput($enableLikes);

    $showReadingTime = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showReadingTime',
        ['1' => $yes, '0' => $no],
        '1',
        _t('زمان مطالعه'),
        _t('نمایش برآورد زمان مطالعه در کارت‌ها و صفحهٔ نوشته.')
    );
    $form->addInput($showReadingTime);

    $showToc = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showToc',
        ['1' => $yes, '0' => $no],
        '1',
        _t('فهرست مطالب خودکار'),
        _t('اگر نوشته عنوان‌های میانی (H2/H3) داشته باشد، فهرست مطالب تاشویی در ابتدای متن ساخته می‌شود.')
    );
    $form->addInput($showToc);

    $showRelated = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showRelated',
        ['1' => $yes, '0' => $no],
        '1',
        _t('مطالب مرتبط'),
        _t('در پایان هر نوشته، نوشته‌های مرتبط (بر پایهٔ برچسب‌ها) نمایش داده می‌شود.')
    );
    $form->addInput($showRelated);

    /* --- گالری و لایت‌باکس --- */

    $enableGallery = new \Typecho\Widget\Helper\Form\Element\Radio(
        'enableGallery',
        ['1' => $yes, '0' => $no],
        '1',
        _t('گالری تصاویر خودکار'),
        _t('اگر چند تصویر پشت‌سرهم در نوشته قرار گیرند، به‌صورت افقی کنار هم (دو یا حداکثر سه تصویر در هر ردیف) نمایش داده می‌شوند.')
    );
    $form->addInput($enableGallery);

    $enableLightbox = new \Typecho\Widget\Helper\Form\Element\Radio(
        'enableLightbox',
        ['1' => $yes, '0' => $no],
        '1',
        _t('لایت‌باکس تصاویر'),
        _t('با کلیک روی تصاویر نوشته، تصویر در حالت تمام‌صفحه با امکان ناوبری بین تصاویر (کلیدهای جهت‌دار، لمس و دکمه‌ها) نمایش داده می‌شود.')
    );
    $form->addInput($enableLightbox);

    /* --- آمار بازدید --- */

    $countLoggedInViews = new \Typecho\Widget\Helper\Form\Element\Radio(
        'countLoggedInViews',
        ['0' => _t('شمرده نشود (پیشنهادی)'), '1' => _t('شمرده شود')],
        '0',
        _t('بازدید کاربران واردشده'),
        _t('اگر «شمرده نشود» باشد، بازدید مدیر و کاربران واردشده از صفحات تکی در آمار ثبت نمی‌شود.')
    );
    $form->addInput($countLoggedInViews);

    $viewsInterval = new \Typecho\Widget\Helper\Form\Element\Select(
        'viewsInterval',
        [
            '3600'   => _t('۱ ساعت (پیشنهادی)'),
            '21600'  => _t('۶ ساعت'),
            '86400'  => _t('۲۴ ساعت'),
            '0'      => _t('بدون فاصله؛ هر بازدید شمرده شود'),
        ],
        '3600',
        _t('فاصله شمارش بازدید مکرر'),
        _t('بازدید تکراری یک نوشته در این بازه فقط یک بار شمرده می‌شود.')
    );
    $form->addInput($viewsInterval);

    /* --- محبوب‌ترین‌ها --- */

    $popularCount = new \Typecho\Widget\Helper\Form\Element\Select(
        'popularCount',
        ['0' => _t('مخفی'), '3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶'],
        '5',
        _t('تعداد نوشته‌های محبوب'),
        _t('نوشته‌های محبوب برای نمایش در ستون کناری (یا بخش پایان صفحه در چیدمان تک‌ستونه).')
    );
    $form->addInput($popularCount);

    $popularBasis = new \Typecho\Widget\Helper\Form\Element\Select(
        'popularBasis',
        [
            'views'    => _t('بیشترین بازدید (پیشنهادی)'),
            'likes'    => _t('بیشترین پسند'),
            'comments' => _t('بیشترین دیدگاه'),
        ],
        'views',
        _t('پایه محبوبیت نوشته‌ها'),
        _t('محبوب‌ترین نوشته‌ها بر پایهٔ آمار انتخابی فهرست می‌شوند؛ تا زمانی که آمار انتخابی ثبت نشده باشد، خودکار بر پایهٔ بازدید و سپس دیدگاه مرتب می‌شود.')
    );
    $form->addInput($popularBasis);

    /* --- درباره و شبکه‌های اجتماعی --- */

    $sidebarBio = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'sidebarBio',
        null,
        null,
        _t('دربارهٔ نویسنده'),
        _t('متنی کوتاه دربارهٔ خودتان برای کارت نویسنده.')
    );
    $form->addInput($sidebarBio);

    $socialTelegram = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialTelegram',
        null,
        null,
        _t('نشانی تلگرام'),
        _t('مثال: https://t.me/example')
    );
    $form->addInput($socialTelegram->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $socialGithub = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialGithub',
        null,
        null,
        _t('نشانی گیت‌هاب'),
        _t('مثال: https://github.com/example')
    );
    $form->addInput($socialGithub->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $socialInstagram = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialInstagram',
        null,
        null,
        _t('نشانی اینستاگرام'),
        _t('مثال: https://instagram.com/example')
    );
    $form->addInput($socialInstagram->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $socialLinkedin = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialLinkedin',
        null,
        null,
        _t('نشانی لینکدین'),
        _t('مثال: https://linkedin.com/in/example')
    );
    $form->addInput($socialLinkedin->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    /* --- پانوشت --- */

    $footerText = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'footerText',
        null,
        null,
        _t('متن دلخواه پانوشت'),
        _t('در صورت خالی‌بودن، فقط نام سایت و سال نمایش داده می‌شود.')
    );
    $form->addInput($footerText);
}

/* ============================================================
 * ۸) فیلد اختصاصی «تصویر شاخص» در ویرایشگر نوشته
 * ============================================================ */

function themeFields($layout)
{
    $thumb = new \Typecho\Widget\Helper\Form\Element\Text(
        'thumb',
        null,
        null,
        _t('تصویر شاخص'),
        _t('نشانی کامل تصویر شاخص این نوشته (در کارت‌های فهرست و ابتدای صفحهٔ نوشته نمایش داده می‌شود). اگر خالی بماند، نخستین تصویر متن به‌طور خودکار استفاده می‌شود.')
    );
    $layout->addItem($thumb);
}

/* ============================================================
 * ۹) ویجت نوشته‌های محبوب
 * ============================================================ */

if (!class_exists('NiloofarPopularPosts')) {
    class NiloofarPopularPosts extends \Widget\Base\Contents
    {
        public function execute()
        {
            $this->parameter->setDefault(['pageSize' => 5]);
            $limit = max(1, intval($this->parameter->pageSize));

            // پایه محبوبیت از تنظیمات پوسته
            $basis = (string) ($this->options->popularBasis ?? 'views');
            if (!in_array($basis, ['views', 'likes', 'comments'], true)) {
                $basis = 'views';
            }

            $viewsReady = niloofarViewsSchemaReady();
            $likesReady = niloofarLikesSchemaReady();

            // در نبود آمار هر پایه، به‌طور خودکار پایه‌های دیگر امتحان می‌شوند
            if ($basis === 'views' && $viewsReady) {
                $total = (int) $this->db->fetchObject(
                    $this->db->select(['COALESCE(SUM(table.contents.views), 0)' => 'total'])
                        ->from('table.contents')
                        ->where('table.contents.type = ?', 'post')
                        ->where('table.contents.status = ?', 'publish')
                )->total;

                if ($total < 1) {
                    $basis = ($likesReady && $this->niloofarTotalLikes() > 0) ? 'likes' : 'comments';
                }
            } elseif ($basis === 'likes') {
                $basis = ($likesReady && $this->niloofarTotalLikes() > 0) ? 'likes' : 'comments';
            }

            $orderColumn = 'table.contents.commentsNum';
            if ($basis === 'views' && $viewsReady) {
                $orderColumn = 'table.contents.views';
            } elseif ($basis === 'likes' && $likesReady) {
                $orderColumn = 'table.contents.likes';
            }

            $select = $this->select('table.contents.*')
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', $this->options->time)
                ->where('table.contents.type = ?', 'post')
                ->where("table.contents.password IS NULL OR table.contents.password = ''")
                ->order($orderColumn, \Typecho\Db::SORT_DESC)
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit($limit);

            $this->db->fetchAll($select, [$this, 'push']);
        }

        private function niloofarTotalLikes(): int
        {
            try {
                return (int) $this->db->fetchObject(
                    $this->db->select(['COALESCE(SUM(table.contents.likes), 0)' => 'total'])
                        ->from('table.contents')
                        ->where('table.contents.type = ?', 'post')
                        ->where('table.contents.status = ?', 'publish')
                )->total;
            } catch (\Throwable $e) {
                return 0;
            }
        }
    }
}

/* ============================================================
 * ۱۰) رندر اجزای مشترک
 * ============================================================ */

/**
 * نشان نیلوفر (SVG توپر) — لوگوی رسمی پوسته (شبدر آبی هشت‌گلبرگ)
 */
function niloofarLotusSvg(int $size = 20): string
{
    static $body = null;

    if ($body === null) {
        $body =
            '<path d="M256.004,222.135c-18.702,0-33.868,15.166-33.868,33.868c0,18.694,15.166,33.86,33.868,33.86c18.695,0,33.86-15.166,33.86-33.86C289.864,237.302,274.698,222.135,256.004,222.135z"></path>'
            . '<path d="M237.354,196.038c2.05,8.402,9.618,14.648,18.65,14.648c9.024,0,16.592-6.246,18.65-14.648l37.344-123.4c1.239-4.715,1.9-9.648,1.9-14.738c0-31.983-25.917-57.9-57.893-57.9c-31.976,0-57.9,25.917-57.9,57.9c0,5.09,0.668,10.023,1.899,14.738L237.354,196.038z"></path>'
            . '<path d="M274.653,315.946c-2.057-8.401-9.626-14.632-18.65-14.632c-9.032,0-16.6,6.231-18.65,14.632l-37.352,123.422c-1.231,4.708-1.899,9.64-1.899,14.738c0,31.969,25.924,57.894,57.9,57.894c31.976,0,57.893-25.925,57.893-57.894c0-5.098-0.66-10.03-1.9-14.738L274.653,315.946z"></path>'
            . '<path d="M86.746,165.932l113.669,60.859c7.403,4.482,17.164,3.559,23.552-2.823c6.382-6.396,7.313-16.15,2.831-23.552L165.939,86.746c-2.456-4.197-5.473-8.161-9.085-11.765c-22.606-22.614-59.26-22.614-81.874,0c-22.614,22.606-22.614,59.267,0,81.873C78.585,160.451,82.549,163.484,86.746,165.932z"></path>'
            . '<path d="M425.254,346.061l-113.67-60.859c-7.395-4.49-17.155-3.552-23.537,2.83c-6.396,6.396-7.327,16.15-2.845,23.552l60.866,113.67c2.455,4.204,5.466,8.161,9.076,11.756c22.614,22.615,59.268,22.615,81.874,0c22.621-22.598,22.614-59.26,0-81.866C433.415,351.542,429.466,348.516,425.254,346.061z"></path>'
            . '<path d="M196.046,274.653c8.402-2.057,14.64-9.626,14.64-18.65c0-9.032-6.239-16.6-14.64-18.658L72.638,200.002c-4.714-1.238-9.648-1.899-14.738-1.899c-31.976,0-57.9,25.924-57.9,57.9c0,31.976,25.925,57.893,57.9,57.893c5.09,0,10.024-0.668,14.738-1.9L196.046,274.653z"></path>'
            . '<path d="M454.106,198.103c-5.098,0-10.03,0.66-14.738,1.899l-123.414,37.344c-8.394,2.058-14.64,9.626-14.64,18.658c0,9.024,6.246,16.592,14.64,18.65l123.414,37.344c4.708,1.232,9.64,1.9,14.738,1.9c31.976,0,57.894-25.917,57.894-57.893C512,224.02,486.083,198.103,454.106,198.103z"></path>'
            . '<path d="M223.967,288.032c-6.389-6.382-16.15-7.32-23.552-2.83L86.746,346.061c-4.197,2.455-8.161,5.481-11.765,9.084c-22.614,22.606-22.614,59.268,0,81.866c22.614,22.615,59.268,22.615,81.874,0c3.596-3.596,6.629-7.552,9.077-11.756l60.866-113.67C231.28,304.182,230.349,294.428,223.967,288.032z"></path>'
            . '<path d="M288.047,223.953c6.382,6.396,16.142,7.32,23.537,2.838l113.67-60.851c4.212-2.456,8.161-5.474,11.764-9.085c22.614-22.606,22.621-59.267,0-81.873c-22.606-22.614-59.267-22.614-81.874,0c-3.611,3.604-6.622,7.568-9.076,11.765l-60.866,113.669C280.72,207.818,281.651,217.571,288.047,223.953z"></path>';
    }

    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 512 512" fill="currentColor"'
        . ' aria-hidden="true" focusable="false">' . $body . '</svg>';
}

/**
 * آیکن‌های خطی پرکاربرد (Feather-style)
 */
function niloofarIcon(string $name, int $size = 14): string
{
    $paths = [
        'user'    => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle>',
        'calendar'=> '<rect x="3" y="4" width="18" height="18" rx="2.5"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line>',
        'clock'   => '<circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15.5 14"></polyline>',
        'chat'    => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>',
        'eye'     => '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle>',
        'heart'   => '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>',
        'folder'  => '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>',
        'tag'     => '<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line>',
        'search'  => '<circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line>',
        'arrow-left'  => '<line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline>',
        'arrow-right' => '<line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline>',
        'chevron-left'  => '<polyline points="15 18 9 12 15 6"></polyline>',
        'chevron-right' => '<polyline points="9 18 15 12 9 6"></polyline>',
        'close'   => '<line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>',
        'menu'    => '<line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="18" x2="21" y2="18"></line>',
        'sun'     => '<circle cx="12" cy="12" r="4"></circle><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M5.64 17.66l-1.41 1.41M18.36 5.64l1.41-1.41"></path>',
        'moon'    => '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>',
        'up'      => '<line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline>',
        'link'    => '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>',
        'send'    => '<line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>',
        'rss'     => '<path d="M4 11a9 9 0 0 1 9 9"></path><path d="M4 4a16 16 0 0 1 16 16"></path><circle cx="5" cy="19" r="1"></circle>',
        'star'    => '<path d="M12 17.75L6.16 21l1.12-6.5L2 9.24l6.54-.95L12 2l3.46 6.29 6.54.95-5.28 5.25L17.84 21z"></path>',
        'flame'   => '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"></path>',
        'lotus'   => '<path d="M12 21c-4.5 0-8-2.5-9.5-6.5 2 0 4-.5 5.5-1.5C6.5 9.5 8 6 12 4c4 2 5.5 5.5 4 9 1.5 1 3.5 1.5 5.5 1.5C20 18.5 16.5 21 12 21z"></path><path d="M12 21c-1.5-2-2-4.5-1.5-7"></path><path d="M12 21c1.5-2 2-4.5 1.5-7"></path>',
    ];

    $path = $paths[$name] ?? $paths['star'];

    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor"'
        . ' stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
}

/* ============================================================
 * ۱۲) رندر ردیف اطلاعات نوشته
 * ============================================================ */

/**
 * اطلاعات هر نوشته: نویسنده (با آواتار)، تاریخ، زمان مطالعه، بازدید و دیدگاه
 */
function niloofarMetaRow($archive, string $context = 'card'): void
{
    $showReadingTime = ((string) niloofarOpt('showReadingTime', '1')) === '1';
    $views = niloofarGetViews($archive);
    $commentsNum = (int) $archive->commentsNum;
    ?>
    <div class="meta-row">
        <span class="meta-item meta-author">
            <span class="meta-avatar"><?php echo niloofarAuthorAvatar($archive, 24); ?></span>
            <a href="<?php $archive->author->permalink(); ?>" rel="author" itemprop="author"><?php $archive->author(); ?></a>
        </span>
        <span class="meta-item">
            <?php echo niloofarIcon('calendar'); ?>
            <time datetime="<?php echo date('c', (int) $archive->created); ?>" itemprop="datePublished"><?php echo niloofarDate($archive); ?></time>
        </span>
        <?php if ($showReadingTime): ?>
            <span class="meta-item">
                <?php echo niloofarIcon('clock'); ?>
                <?php echo niloofarFa((string) niloofarReadingTime($archive)); ?> <?php _e('دقیقه'); ?>
            </span>
        <?php endif; ?>
        <?php if ($views > 0): ?>
            <span class="meta-item meta-views">
                <?php echo niloofarIcon('eye'); ?>
                <?php echo niloofarFa((string) $views); ?> <?php _e('بازدید'); ?>
            </span>
        <?php endif; ?>
        <?php if ($context === 'card' || $context === 'hero'): ?>
            <span class="meta-item">
                <?php echo niloofarIcon('chat'); ?>
                <a href="<?php $archive->permalink(); ?>#comments" itemprop="discussionUrl"><?php echo niloofarCommentsText($commentsNum); ?></a>
            </span>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * قاب تصویر شاخص (تصویر واقعی یا طرح تزئینی نیلوفر)
 */
function niloofarCoverHtml(string $cover, string $title, string $loading = 'lazy'): string
{
    if ($cover !== '') {
        return '<img src="' . htmlspecialchars($cover, ENT_QUOTES, 'UTF-8') . '"'
            . ' alt="' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '"'
            . ' loading="' . $loading . '" decoding="async" itemprop="image" />';
    }

    return '<span class="card-cover-pattern" aria-hidden="true">' . niloofarLotusSvg(64) . '</span>';
}

/* ============================================================
 * ۱۳) کارت‌های نوشته در فهرست
 * ============================================================ */

/**
 * کارت بزرگ تازه‌ترین نوشته (صفحهٔ نخست خانه)
 */
function niloofarRenderHeroCard(\Widget\Archive $archive): void
{
    $cover = niloofarThumbnail($archive);
    ?>
    <article class="hero-card reveal" itemscope itemtype="http://schema.org/BlogPosting">
        <a class="hero-card-cover" href="<?php $archive->permalink(); ?>" aria-hidden="true" tabindex="-1">
            <?php echo niloofarCoverHtml($cover, (string) $archive->title, 'eager'); ?>
        </a>
        <div class="hero-card-body">
            <div class="card-kicker">
                <span class="chip chip-accent"><?php _e('تازه‌ترین نوشته'); ?></span>
                <?php if ($archive->categories): ?>
                    <a class="chip chip-category" href="<?php echo htmlspecialchars($archive->categories[0]['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($archive->categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                <?php endif; ?>
            </div>
            <h2 class="hero-card-title" itemprop="name headline">
                <a href="<?php $archive->permalink(); ?>" itemprop="url"><?php $archive->title(); ?></a>
            </h2>
            <?php $excerpt = niloofarExcerpt($archive, 34); ?>
            <?php if ($excerpt !== ''): ?>
                <p class="hero-card-excerpt"><?php echo htmlspecialchars($excerpt, ENT_QUOTES, 'UTF-8'); ?></p>
            <?php endif; ?>
            <?php niloofarMetaRow($archive, 'hero'); ?>
            <a class="read-more" href="<?php $archive->permalink(); ?>">
                <span><?php _e('ادامهٔ خواندن'); ?></span>
                <?php echo niloofarIcon('arrow-left', 16); ?>
            </a>
        </div>
    </article>
    <?php
}

/**
 * کارت افقی نوشته (تصویر کنار متن)
 */
function niloofarRenderCard(\Widget\Archive $archive): void
{
    $cover = niloofarThumbnail($archive);
    ?>
    <article class="post-card reveal" itemscope itemtype="http://schema.org/BlogPosting">
        <a class="post-card-cover" href="<?php $archive->permalink(); ?>" aria-hidden="true" tabindex="-1">
            <?php echo niloofarCoverHtml($cover, (string) $archive->title); ?>
        </a>
        <div class="post-card-body">
            <div class="card-kicker">
                <?php if ($archive->categories): ?>
                    <a class="chip chip-category" href="<?php echo htmlspecialchars($archive->categories[0]['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($archive->categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                <?php endif; ?>
            </div>
            <h2 class="post-card-title" itemprop="name headline">
                <a href="<?php $archive->permalink(); ?>" itemprop="url"><?php $archive->title(); ?></a>
            </h2>
            <?php $excerpt = niloofarExcerpt($archive, 24); ?>
            <?php if ($excerpt !== ''): ?>
                <p class="post-card-excerpt"><?php echo htmlspecialchars($excerpt, ENT_QUOTES, 'UTF-8'); ?></p>
            <?php endif; ?>
            <?php niloofarMetaRow($archive, 'card'); ?>
        </div>
    </article>
    <?php
}

/**
 * ردیف نوشتهٔ محبوب (ویجت ستون کناری و بخش پایان صفحه)
 */
function niloofarRenderPopularItem($popular, int $rank): void
{
    $views = 0;
    try {
        $views = max(0, (int) $popular->views);
    } catch (\Throwable $e) {
        $views = 0;
    }

    $likes = 0;
    try {
        $likes = max(0, (int) $popular->likes);
    } catch (\Throwable $e) {
        $likes = 0;
    }

    $basis = (string) niloofarOpt('popularBasis', 'views');
    ?>
    <li class="popular-item">
        <span class="popular-rank" aria-hidden="true"><?php echo niloofarFa((string) $rank); ?></span>
        <div class="popular-item-main">
            <a class="popular-item-title" href="<?php $popular->permalink(); ?>"><?php $popular->title(); ?></a>
            <span class="popular-item-meta">
                <?php if ($basis === 'likes' && $likes > 0): ?>
                    <?php echo niloofarIcon('heart', 13); ?>
                    <?php echo niloofarFa((string) $likes); ?> <?php _e('پسند'); ?>
                    <span class="popular-meta-sep" aria-hidden="true">·</span>
                <?php elseif ($views > 0): ?>
                    <?php echo niloofarIcon('eye', 13); ?>
                    <?php echo niloofarFa((string) $views); ?> <?php _e('بازدید'); ?>
                    <span class="popular-meta-sep" aria-hidden="true">·</span>
                <?php endif; ?>
                <?php echo niloofarCommentsText((int) $popular->commentsNum); ?>
            </span>
        </div>
    </li>
    <?php
}

/**
 * بخش «محبوب‌ترین نوشته‌ها» برای چیدمان تک‌ستونه (پایان صفحهٔ اصلی)
 */
function niloofarRenderPopularSection(): void
{
    $popularCount = intval((string) niloofarOpt('popularCount', '5'));
    if ($popularCount < 1) {
        return;
    }

    NiloofarPopularPosts::alloc('pageSize=' . $popularCount)->to($popular);
    if (!$popular->have()) {
        return;
    }
    ?>
    <section class="popular-section reveal" aria-label="<?php _e('محبوب‌ترین نوشته‌ها'); ?>">
        <h2 class="section-title">
            <span class="section-title-icon" aria-hidden="true"><?php echo niloofarIcon('flame', 18); ?></span>
            <?php _e('محبوب‌ترین نوشته‌ها'); ?>
        </h2>
        <ol class="popular-list popular-grid">
            <?php $rank = 0; while ($popular->next()): $rank++; ?>
                <?php niloofarRenderPopularItem($popular, $rank); ?>
            <?php endwhile; ?>
        </ol>
    </section>
    <?php
}

/* ============================================================
 * ۱۴) دیدگاه‌های درختی
 * ============================================================ */

function threadedComments($comments, $options)
{
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
    ?>
    <li id="li-<?php $comments->theId(); ?>" class="comment-item<?php
        if ($comments->levels > 0) {
            echo ' comment-child';
            $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
        } else {
            echo ' comment-parent';
        }
        $comments->alt(' comment-odd', ' comment-even');
        echo $commentClass;
    ?>">
        <div id="<?php $comments->theId(); ?>" class="comment-inner">
            <div class="comment-avatar" aria-hidden="true">
                <?php echo niloofarCommentAvatar($comments, 48); ?>
            </div>
            <div class="comment-main">
                <div class="comment-meta">
                    <cite class="comment-author" itemprop="creator" itemscope itemtype="http://schema.org/Person">
                        <?php $comments->author(); ?>
                        <?php if ($comments->authorId && $comments->authorId == $comments->ownerId): ?>
                            <span class="comment-badge comment-badge-owner"><?php _e('نویسنده'); ?></span>
                        <?php endif; ?>
                    </cite>
                    <span class="comment-time">
                        <a href="<?php $comments->permalink(); ?>" itemprop="url">
                            <time datetime="<?php echo date('c', (int) $comments->created); ?>" itemprop="commentTime"><?php echo niloofarCommentDate($comments); ?></time>
                        </a>
                    </span>
                    <?php if ($comments->status == 'waiting'): ?>
                        <span class="comment-badge comment-badge-waiting"><?php _e('در انتظار تأیید'); ?></span>
                    <?php endif; ?>
                    <span class="comment-reply">
                        <?php $comments->reply(_t('پاسخ')); ?>
                    </span>
                </div>
                <div class="comment-content" itemprop="commentText">
                    <?php $comments->content(); ?>
                </div>
            </div>
        </div>
        <?php if ($comments->children) { ?>
            <div class="comment-children">
                <?php $comments->threadedComments($options); ?>
            </div>
        <?php } ?>
    </li>
    <?php
}
