<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
</main>

<footer class="site-footer" role="contentinfo">
    <div class="container">

        <?php if ((string) niloofarOpt('layoutMode', 'single') !== 'sidebar'): ?>
            <?php $footerBio = trim((string) niloofarOpt('sidebarBio')); ?>
            <?php $siteAuthor = niloofarSiteAuthorInfo(); ?>
            <section class="footer-about">
                <div class="footer-about-avatar" aria-hidden="true"><?php echo niloofarSiteAuthorAvatar(72); ?></div>
                <div class="footer-about-main">
                    <p class="footer-about-role"><?php _e('نویسنده'); ?></p>
                    <h2 class="footer-about-name"><?php echo htmlspecialchars($siteAuthor['name'] !== '' ? $siteAuthor['name'] : (string) $this->options->title, ENT_QUOTES, 'UTF-8'); ?></h2>
                    <?php if ($footerBio !== ''): ?>
                        <p class="footer-about-bio"><?php echo htmlspecialchars($footerBio, ENT_QUOTES, 'UTF-8'); ?></p>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>

        <div class="footer-inner">
            <div class="footer-brand">
                <a class="footer-title" href="<?php $this->options->siteUrl(); ?>">
                    <span class="footer-title-mark" aria-hidden="true"><?php echo niloofarLotusSvg(15); ?></span>
                    <span><?php $this->options->title(); ?></span>
                </a>
                <p class="footer-desc"><?php echo htmlspecialchars((string) $this->options->description, ENT_QUOTES, 'UTF-8'); ?></p>
                <?php $footerText = trim((string) niloofarOpt('footerText')); ?>
                <?php if ($footerText !== ''): ?>
                    <p class="footer-custom-text"><?php echo htmlspecialchars($footerText, ENT_QUOTES, 'UTF-8'); ?></p>
                <?php endif; ?>
            </div>

            <?php
                $socials = [
                    'telegram'  => [(string) niloofarOpt('socialTelegram'), _t('تلگرام')],
                    'github'    => [(string) niloofarOpt('socialGithub'), _t('گیت‌هاب')],
                    'instagram' => [(string) niloofarOpt('socialInstagram'), _t('اینستاگرام')],
                    'linkedin'  => [(string) niloofarOpt('socialLinkedin'), _t('لینکدین')],
                ];
                $hasSocial = false;
                foreach ($socials as $item) {
                    if ($item[0] !== '') { $hasSocial = true; break; }
                }
            ?>
            <?php if ($hasSocial): ?>
            <nav class="footer-social" aria-label="<?php _e('شبکه‌های اجتماعی'); ?>">
                <?php if ($socials['telegram'][0] !== ''): ?>
                    <a class="social-btn" href="<?php echo htmlspecialchars($socials['telegram'][0], ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" title="<?php echo _t('تلگرام'); ?>">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.9 4.6l-3.1 14.7c-.2 1-.8 1.3-1.7.8l-4.7-3.5-2.3 2.2c-.25.25-.47.47-.94.47l.33-4.8L18.2 6.6c.37-.33-.08-.52-.58-.19L6.9 13.7l-4.6-1.44c-1-.31-1-1 .21-1.48L20.6 3.1c.83-.3 1.56.2 1.3 1.5z"/></svg>
                    </a>
                <?php endif; ?>
                <?php if ($socials['github'][0] !== ''): ?>
                    <a class="social-btn" href="<?php echo htmlspecialchars($socials['github'][0], ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" title="<?php echo _t('گیت‌هاب'); ?>">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.11.79-.25.79-.55 0-.27-.01-1.17-.02-2.12-3.2.7-3.88-1.36-3.88-1.36-.52-1.33-1.28-1.68-1.28-1.68-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.18 1.76 1.18 1.03 1.76 2.69 1.25 3.35.96.1-.75.4-1.25.72-1.54-2.55-.29-5.24-1.28-5.24-5.68 0-1.26.45-2.28 1.18-3.09-.12-.29-.51-1.46.11-3.05 0 0 .96-.31 3.15 1.18a10.9 10.9 0 0 1 5.74 0c2.19-1.49 3.15-1.18 3.15-1.18.62 1.59.23 2.76.11 3.05.73.81 1.18 1.83 1.18 3.09 0 4.41-2.69 5.38-5.25 5.67.41.35.77 1.05.77 2.12 0 1.53-.01 2.76-.01 3.14 0 .3.2.67.8.55A11.52 11.52 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5z"/></svg>
                    </a>
                <?php endif; ?>
                <?php if ($socials['instagram'][0] !== ''): ?>
                    <a class="social-btn" href="<?php echo htmlspecialchars($socials['instagram'][0], ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" title="<?php echo _t('اینستاگرام'); ?>">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
                    </a>
                <?php endif; ?>
                <?php if ($socials['linkedin'][0] !== ''): ?>
                    <a class="social-btn" href="<?php echo htmlspecialchars($socials['linkedin'][0], ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" title="<?php echo _t('لینکدین'); ?>">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20.45 20.45h-3.55v-5.57c0-1.33-.03-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.36V9h3.41v1.56h.05c.47-.9 1.63-1.85 3.36-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12zM7.12 20.45H3.56V9h3.56v11.45z"/></svg>
                    </a>
                <?php endif; ?>
            </nav>
            <?php endif; ?>

            <div class="footer-meta">
                <p>&copy; <?php echo niloofarFa(date('Y')); ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a> · <?php _e('تمام حقوق محفوظ است'); ?></p>
                <p><?php _e('قدرت‌گرفته از'); ?> <a href="https://www.typerenew.ir" rel="nofollow">TypeRenew</a> · <?php _e('پوستهٔ نیلوفر'); ?></p>
            </div>
        </div>

        <div class="footer-divider" aria-hidden="true"></div>
    </div>
</footer>

<button type="button" id="back-to-top" class="back-to-top" aria-label="<?php _e('بازگشت به بالای صفحه'); ?>" title="<?php _e('بازگشت به بالا'); ?>">
    <?php echo niloofarIcon('up', 18); ?>
</button>

<div class="toast" id="toast" role="status" aria-live="polite"></div>

<?php $this->footer(); ?>

<?php
    // پیکربندی جاوااسکریپت پوسته
    $niloofarJsConfig = [
        'gallery'  => ((string) niloofarOpt('enableGallery', '1')) === '1',
        'lightbox' => ((string) niloofarOpt('enableLightbox', '1')) === '1',
        'toc'      => ((string) niloofarOpt('showToc', '1')) === '1',
        'likes'    => ((string) niloofarOpt('enableLikes', '1')) === '1',
        'strings'  => [
            'copyOk'      => _t('لینک نوشته کپی شد!'),
            'copyFail'    => _t('کپی لینک ممکن نشد.'),
            'likeOk'      => _t('پسند شما ثبت شد؛ سپاسگزارم!'),
            'likeAlready' => _t('شما قبلاً این نوشته را پسندیده‌اید.'),
            'likeFail'    => _t('ثبت پسند ممکن نشد؛ دوباره بیازمایید.'),
            'likeCount'   => _t('پسند'),
            'tocTitle'    => _t('فهرست مطالب'),
            'imageOf'     => _t('از'),
            'close'       => _t('بستن'),
            'nextImage'   => _t('تصویر بعدی'),
            'prevImage'   => _t('تصویر قبلی'),
        ],
    ];
    echo '<script>window.NILOOFAR = ' . json_encode($niloofarJsConfig, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) . ';</script>' . "\n";
?>
<script src="<?php $this->options->themeUrl('assets/js/main.js'); ?>" defer></script>

</body>
</html>
