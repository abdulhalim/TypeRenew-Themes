<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="error-page">
    <div class="error-inner">
        <div class="error-code" aria-hidden="true">۴۰۴</div>
        <div class="error-ornament" aria-hidden="true"><?php echo niloofarLotusSvg(40); ?></div>
        <h1 class="error-title"><?php _e('این صفحه پیدا نشد'); ?></h1>
        <p class="error-text">
            <?php _e('نشانی‌ای که دنبالش بودید وجود ندارد یا به نشانی دیگری منتقل شده است؛ نگران نباشید، راه‌های بازگشت باز است.'); ?>
        </p>
        <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="empty-search-form">
            <input type="search" name="s" placeholder="<?php _e('در وبلاگ جستجو کنید…'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" required />
            <button type="submit"><?php _e('جستجو'); ?></button>
        </form>
        <a class="btn-primary" href="<?php $this->options->siteUrl(); ?>">
            <span><?php _e('بازگشت به خانه'); ?></span>
            <?php echo niloofarIcon('arrow-left', 16); ?>
        </a>
    </div>
</div>

<?php $this->need('footer.php'); ?>
