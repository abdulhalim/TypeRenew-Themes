<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<?php
    $layoutMode = (string) niloofarOpt('layoutMode', 'single');
    $postCover = niloofarThumbnail($this);
    $postLikes = niloofarGetLikes($this);
    $postViews = niloofarGetViews($this);
    $enableLikes = ((string) niloofarOpt('enableLikes', '1')) === '1';
    $showReadingTime = ((string) niloofarOpt('showReadingTime', '1')) === '1';
    $categories = $this->categories;
?>

<div class="layout<?php echo $layoutMode === 'sidebar' ? ' layout-has-sidebar' : ' layout-single'; ?>">

    <div class="layout-primary">

        <article class="single-post reveal" itemscope itemtype="http://schema.org/BlogPosting">

            <nav class="breadcrumb" aria-label="<?php _e('مسیر صفحه'); ?>">
                <a href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a>
                <?php if (!empty($categories)): ?>
                    <span class="breadcrumb-sep" aria-hidden="true">/</span>
                    <a href="<?php echo htmlspecialchars($categories[0]['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                <?php endif; ?>
                <span class="breadcrumb-sep" aria-hidden="true">/</span>
                <span class="breadcrumb-current" aria-current="page"><?php $this->title(); ?></span>
            </nav>

            <header class="post-header">
                <h1 class="post-title" itemprop="name headline"><?php $this->title(); ?></h1>

                <div class="meta-row post-meta-main">
                    <span class="meta-item meta-author">
                        <span class="meta-avatar"><?php echo niloofarAuthorAvatar($this, 44); ?></span>
                        <a href="<?php $this->author->permalink(); ?>" rel="author" itemprop="author"><?php $this->author(); ?></a>
                    </span>
                    <span class="meta-item">
                        <?php echo niloofarIcon('calendar'); ?>
                        <time datetime="<?php echo date('c', (int) $this->created); ?>" itemprop="datePublished"><?php echo niloofarDate($this); ?></time>
                    </span>
                    <?php if ($showReadingTime): ?>
                        <span class="meta-item">
                            <?php echo niloofarIcon('clock'); ?>
                            <?php echo niloofarFa((string) niloofarReadingTime($this)); ?> <?php _e('دقیقه مطالعه'); ?>
                        </span>
                    <?php endif; ?>
                    <?php if ($postViews > 0): ?>
                        <span class="meta-item meta-views">
                            <?php echo niloofarIcon('eye'); ?>
                            <?php echo niloofarFa((string) $postViews); ?> <?php _e('بازدید'); ?>
                        </span>
                    <?php endif; ?>
                    <?php if ($postLikes > 0): ?>
                        <span class="meta-item meta-likes">
                            <?php echo niloofarIcon('heart'); ?>
                            <?php echo niloofarFa((string) $postLikes); ?> <?php _e('پسند'); ?>
                        </span>
                    <?php endif; ?>
                    <span class="meta-item">
                        <?php echo niloofarIcon('chat'); ?>
                        <a href="<?php $this->permalink(); ?>#comments" itemprop="discussionUrl"><?php echo niloofarCommentsText((int) $this->commentsNum); ?></a>
                    </span>
                </div>
            </header>

            <?php if ($postCover !== ''): ?>
                <figure class="post-hero" itemprop="image">
                    <img src="<?php echo htmlspecialchars($postCover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->title(); ?>" loading="eager" decoding="async">
                </figure>
            <?php endif; ?>

            <div class="post-content" itemprop="articleBody" id="post-content">
                <?php $this->content(); ?>
            </div>

            <?php if ($this->tags): ?>
                <div class="post-tags" itemprop="keywords">
                    <span class="post-tags-label">
                        <?php echo niloofarIcon('tag', 15); ?>
                        <?php _e('برچسب‌ها'); ?>:
                    </span>
                    <?php foreach ($this->tags as $tag): ?>
                        <a class="tag-pill" href="<?php echo htmlspecialchars($tag['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($tag['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($enableLikes): ?>
                <div class="post-likes">
                    <button type="button" class="like-button" id="like-button"
                        data-cid="<?php echo intval($this->cid); ?>"
                        data-token="<?php echo htmlspecialchars(niloofarLikeToken(intval($this->cid)), ENT_QUOTES, 'UTF-8'); ?>"
                        data-likes="<?php echo $postLikes; ?>"
                        aria-pressed="false">
                        <span class="like-icon" aria-hidden="true"><?php echo niloofarIcon('heart', 16); ?></span>
                        <span class="like-text">
                            <strong class="like-count"><?php echo niloofarFa((string) $postLikes); ?></strong>
                            <span class="like-label"><?php _e('پسندیدید؟'); ?></span>
                        </span>
                    </button>
                </div>
            <?php endif; ?>

            <div class="post-share">
                <span class="post-share-label"><?php _e('اشتراک‌گذاری'); ?>:</span>
                <button type="button" class="share-btn js-copy-link" title="<?php _e('کپی لینک نوشته'); ?>">
                    <?php echo niloofarIcon('link', 16); ?>
                    <?php _e('کپی لینک'); ?>
                </button>
                <a class="share-btn" href="https://t.me/share/url?url=<?php echo urlencode((string) $this->permalink); ?>&amp;text=<?php echo urlencode((string) $this->title); ?>" target="_blank" rel="noopener" title="<?php _e('اشتراک‌گذاری در تلگرام'); ?>">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.9 4.6l-3.1 14.7c-.2 1-.8 1.3-1.7.8l-4.7-3.5-2.3 2.2c-.25.25-.47.47-.94.47l.33-4.8L18.2 6.6c.37-.33-.08-.52-.58-.19L6.9 13.7l-4.6-1.44c-1-.31-1-1 .21-1.48L20.6 3.1c.83-.3 1.56.2 1.3 1.5z"/></svg>
                    <?php _e('تلگرام'); ?>
                </a>
            </div>

        </article>

        <?php $authorBio = trim((string) niloofarOpt('sidebarBio')); ?>
        <div class="author-box reveal">
            <div class="author-box-avatar">
                <?php echo niloofarAuthorAvatar($this, 72); ?>
            </div>
            <div class="author-box-info">
                <p class="author-box-role"><?php _e('نویسنده'); ?></p>
                <h3 class="author-box-name">
                    <a href="<?php $this->author->permalink(); ?>" rel="author"><?php $this->author(); ?></a>
                </h3>
                <?php if ($authorBio !== ''): ?>
                    <p class="author-box-bio"><?php echo htmlspecialchars($authorBio, ENT_QUOTES, 'UTF-8'); ?></p>
                <?php endif; ?>
                <a class="author-box-link" href="<?php $this->author->permalink(); ?>">
                    <?php _e('نوشته‌های این نویسنده'); ?>
                    <?php echo niloofarIcon('arrow-left', 14); ?>
                </a>
            </div>
        </div>

        <nav class="post-nav reveal" aria-label="<?php _e('ناوبری نوشته‌ها'); ?>">
            <div class="post-nav-item post-nav-prev">
                <span class="post-nav-label"><?php _e('نوشتهٔ قدیمی‌تر'); ?></span>
                <div class="post-nav-link"><?php $this->thePrev('%s', _t('نوشتهٔ قدیمی‌تری نیست')); ?></div>
            </div>
            <div class="post-nav-item post-nav-next">
                <span class="post-nav-label"><?php _e('نوشتهٔ تازه‌تر'); ?></span>
                <div class="post-nav-link"><?php $this->theNext('%s', _t('نوشتهٔ تازه‌تری نیست')); ?></div>
            </div>
        </nav>

        <?php if (((string) niloofarOpt('showRelated', '1')) === '1'): ?>
            <?php $this->related(3)->to($relatedPosts); ?>
            <?php if ($relatedPosts->have()): ?>
                <section class="related-posts reveal" aria-label="<?php _e('مطالب مرتبط'); ?>">
                    <h2 class="section-title">
                        <span class="section-title-icon" aria-hidden="true"><?php echo niloofarIcon('star', 18); ?></span>
                        <?php _e('مطالب مرتبط'); ?>
                    </h2>
                    <div class="related-grid">
                        <?php while ($relatedPosts->next()): ?>
                            <?php $relatedCover = niloofarThumbnail($relatedPosts); ?>
                            <article class="related-card">
                                <a class="related-cover" href="<?php $relatedPosts->permalink(); ?>" aria-hidden="true" tabindex="-1">
                                    <?php echo niloofarCoverHtml($relatedCover, (string) $relatedPosts->title); ?>
                                </a>
                                <h3 class="related-title">
                                    <a href="<?php $relatedPosts->permalink(); ?>"><?php $relatedPosts->title(); ?></a>
                                </h3>
                                <time class="related-date" datetime="<?php echo date('c', (int) $relatedPosts->created); ?>"><?php echo niloofarDate($relatedPosts); ?></time>
                            </article>
                        <?php endwhile; ?>
                    </div>
                </section>
            <?php endif; ?>
        <?php endif; ?>

        <?php $this->need('comments.php'); ?>

    </div>

    <?php if ($layoutMode === 'sidebar'): ?>
        <?php $this->need('sidebar.php'); ?>
    <?php endif; ?>

</div>

<?php $this->need('footer.php'); ?>
