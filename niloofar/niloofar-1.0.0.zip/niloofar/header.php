<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php $this->archiveTitle([
            'category' => _t('نوشته‌های دستهٔ «%s»'),
            'search'   => _t('نتایج جستجو برای «%s»'),
            'tag'      => _t('نوشته‌های برچسب «%s»'),
            'author'   => _t('نوشته‌های %s')
        ], '', ' — '); ?><?php $this->options->title(); ?></title>

    <?php
        // حالت رنگی پیش‌فرض — پیشگیری از پرش رنگ هنگام بارگذاری (anti-FOUC)
        $defaultSchema = (string) ($this->options->colorSchema ?? 'auto');
        $defaultSchemaJson = \Typecho\Common::jsonEncode(
            $defaultSchema,
            JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP,
            '"auto"'
        );

        // پالت رنگی
        $accentPreset = (string) ($this->options->accentPreset ?? 'turquoise');
        if (!in_array($accentPreset, ['turquoise', 'violet', 'amber'], true)) {
            $accentPreset = 'turquoise';
        }

        // چیدمان صفحه
        $layoutMode = (string) ($this->options->layoutMode ?? 'single');
        if (!in_array($layoutMode, ['single', 'sidebar'], true)) {
            $layoutMode = 'single';
        }
        echo "<script>
            (function() {
                var stored = null;
                try {
                    stored = localStorage.getItem('niloofar-theme');
                } catch (e) {
                    stored = null;
                }
                var def = {$defaultSchemaJson};
                var isDark = false;
                if (stored === 'dark' || stored === 'light') {
                    isDark = (stored === 'dark');
                } else if (def === 'dark') {
                    isDark = true;
                } else if (def === 'auto' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                    isDark = true;
                }
                if (isDark) {
                    document.documentElement.setAttribute('data-theme', 'dark');
                }
            })();
        </script>";
    ?>

    <link rel="icon" type="image/svg+xml" href="<?php $this->options->themeUrl('assets/img/favicon.svg'); ?>">
    <link rel="stylesheet" href="<?php $this->options->themeUrl('style.css'); ?>">
    <?php $this->header(); ?>
</head>
<body class="accent-<?php echo htmlspecialchars($accentPreset, ENT_QUOTES, 'UTF-8'); ?> layout-<?php echo htmlspecialchars($layoutMode, ENT_QUOTES, 'UTF-8'); ?>">

<div class="reading-progress" aria-hidden="true"><span class="reading-progress-bar"></span></div>

<header class="site-header" id="site-header">
    <div class="container header-inner">
        <div class="site-branding">
            <?php if ($this->options->logoUrl): ?>
                <a class="site-logo" href="<?php $this->options->siteUrl(); ?>">
                    <img src="<?php $this->options->logoUrl() ?>" alt="<?php $this->options->title() ?>"/>
                </a>
            <?php else: ?>
                <a class="site-title" href="<?php $this->options->siteUrl(); ?>">
                    <span class="site-title-mark" aria-hidden="true"><?php echo niloofarLotusSvg(20); ?></span>
                    <span><?php $this->options->title() ?></span>
                </a>
            <?php endif; ?>
        </div>

        <nav class="site-nav" aria-label="<?php _e('ناوبری اصلی'); ?>">
            <input type="checkbox" id="nav-toggle" class="nav-toggle-input" aria-label="<?php _e('گشودن ناوبری'); ?>">
            <label for="nav-toggle" class="nav-toggle-label" aria-hidden="true">
                <span class="nav-toggle-bar"></span>
                <span class="nav-toggle-bar"></span>
                <span class="nav-toggle-bar"></span>
            </label>
            <ul class="nav-menu" role="menubar">
                <li role="none"><a role="menuitem" <?php if ($this->is('index')): ?> class="active"<?php endif; ?> href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a></li>
                <?php \Widget\Contents\Page\Rows::alloc()->to($pages); ?>
                <?php while ($pages->next()): ?>
                    <li role="none"><a role="menuitem" <?php if ($this->is('page', $pages->slug)): ?> class="active"<?php endif; ?> href="<?php $pages->permalink(); ?>"><?php $pages->title(); ?></a></li>
                <?php endwhile; ?>
            </ul>
        </nav>

        <div class="header-actions">
            <button type="button" id="search-toggle" class="header-icon-btn" aria-label="<?php _e('جستجو'); ?>" title="<?php _e('جستجو'); ?>">
                <?php echo niloofarIcon('search', 18); ?>
            </button>
            <button type="button" id="theme-switch" class="header-icon-btn" aria-label="<?php _e('تغییر حالت روشن و تیره'); ?>" title="<?php _e('تغییر حالت روشن و تیره'); ?>">
                <span class="theme-icon theme-icon-moon" aria-hidden="true"><?php echo niloofarIcon('moon', 18); ?></span>
                <span class="theme-icon theme-icon-sun" aria-hidden="true"><?php echo niloofarIcon('sun', 18); ?></span>
            </button>
            <label for="nav-toggle" class="header-icon-btn nav-burger" aria-hidden="true">
                <?php echo niloofarIcon('menu', 18); ?>
            </label>
        </div>
    </div>
</header>

<!-- پوشش جستجوی تمام‌صفحه -->
<div class="search-overlay" id="search-overlay" aria-hidden="true">
    <div class="search-overlay-backdrop" data-search-close></div>
    <div class="search-overlay-panel" role="dialog" aria-modal="true" aria-label="<?php _e('جستجو در سایت'); ?>">
        <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="search-overlay-form">
            <?php echo niloofarIcon('search', 22); ?>
            <input type="search" id="search-overlay-input" name="s" class="search-overlay-input" placeholder="<?php _e('چه چیزی را جستجو می‌کنید؟…'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" autocomplete="off" required />
            <button type="submit" class="search-overlay-submit"><?php _e('جستجو'); ?></button>
            <button type="button" class="search-overlay-close" data-search-close aria-label="<?php _e('بستن جستجو'); ?>"><?php echo niloofarIcon('close', 20); ?></button>
        </form>
        <p class="search-overlay-hint"><?php _e('با فشردن کلید Esc جستجو بسته می‌شود'); ?></p>
    </div>
</div>

<?php if ($this->is('index') && ((string) niloofarOpt('showHero', '1')) === '1' && $this->currentPage <= 1): ?>
    <?php
        $heroTagline = trim((string) niloofarOpt('heroTagline'));
        if ($heroTagline === '') {
            $heroTagline = (string) $this->options->description;
        }

        // آمار هرو از تنظیمات (چک‌باکس)
        $heroStatsSelected = [];
        if (is_array($this->options->heroStats ?? null)) {
            foreach (['posts', 'comments', 'views', 'likes'] as $key) {
                if (in_array($key, (array) $this->options->heroStats, true)) {
                    $heroStatsSelected[] = $key;
                }
            }
        } else {
            $heroStatsSelected = ['posts', 'comments', 'views', 'likes'];
        }

        $heroStats = !empty($heroStatsSelected) ? niloofarStats() : null;

        $heroStatItems = [];
        if (is_array($heroStats)) {
            if (in_array('posts', $heroStatsSelected, true)) {
                $heroStatItems[] = [niloofarFormatCount($heroStats['posts']), _t('نوشته')];
            }
            if (in_array('comments', $heroStatsSelected, true)) {
                $heroStatItems[] = [niloofarFormatCount($heroStats['comments']), _t('دیدگاه')];
            }
            if (in_array('views', $heroStatsSelected, true)) {
                $heroStatItems[] = [niloofarFormatCount($heroStats['views']), _t('بازدید')];
            }
            if (in_array('likes', $heroStatsSelected, true)) {
                $heroStatItems[] = [niloofarFormatCount($heroStats['likes']), _t('پسند')];
            }
            if (empty($heroStatItems)) {
                $heroStats = null;
            }
        }

        // تصویر پس‌زمینهٔ هرو (اختیاری) + نوع روکش تزئینی
        $heroImage = trim((string) niloofarOpt('heroImage', ''));
        if ($heroImage !== '') {
            $heroImage = niloofarResolveUrl($heroImage);
        }
        $heroOverlay = (string) niloofarOpt('heroOverlay', 'grid');
        if (!in_array($heroOverlay, ['grid', 'dots', 'none'], true)) {
            $heroOverlay = 'grid';
        }
    ?>
    <section class="hero<?php echo $heroImage !== '' ? ' hero--has-image' : ''; ?>">
        <?php if ($heroImage !== ''): ?>
            <div class="hero-bg" style="background-image:url('<?php echo htmlspecialchars($heroImage, ENT_QUOTES, 'UTF-8'); ?>')" aria-hidden="true"></div>
            <div class="hero-overlay hero-overlay--<?php echo htmlspecialchars($heroOverlay, ENT_QUOTES, 'UTF-8'); ?>" aria-hidden="true"></div>
        <?php endif; ?>
        <div class="hero-glow" aria-hidden="true">
            <span class="hero-glow-orb hero-glow-orb-1"></span>
            <span class="hero-glow-orb hero-glow-orb-2"></span>
            <span class="hero-glow-orb hero-glow-orb-3"></span>
        </div>
        <div class="container hero-inner">
            <div class="hero-badge"><?php echo niloofarLotusSvg(15); ?><span><?php _e('یک وبلاگِ فارسی'); ?></span></div>
            <h1 class="hero-title">
                <?php if ($this->options->logoUrl): ?>
                    <img class="hero-logo" src="<?php $this->options->logoUrl() ?>" alt="<?php $this->options->title() ?>"/>
                <?php endif; ?>
                <span><?php $this->options->title() ?></span>
            </h1>
            <?php if ($heroTagline !== ''): ?>
                <p class="hero-tagline"><?php echo htmlspecialchars($heroTagline, ENT_QUOTES, 'UTF-8'); ?></p>
            <?php endif; ?>
            <?php if (is_array($heroStats) && !empty($heroStatItems)): ?>
                <div class="hero-stats">
                    <?php foreach ($heroStatItems as $heroStatIndex => [$heroStatValue, $heroStatLabel]): ?>
                        <?php if ($heroStatIndex > 0): ?>
                            <span class="hero-stat-divider" aria-hidden="true"></span>
                        <?php endif; ?>
                        <div class="hero-stat">
                            <strong><?php echo $heroStatValue; ?></strong>
                            <span><?php echo $heroStatLabel; ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <a class="hero-scroll-hint" href="#content" aria-label="<?php _e('رفتن به نوشته‌ها'); ?>">
                <span><?php _e('آغاز مطالعه'); ?></span>
                <?php echo niloofarIcon('arrow-left', 15); ?>
            </a>
        </div>
    </section>
<?php endif; ?>

<main id="content" class="site-main container">
