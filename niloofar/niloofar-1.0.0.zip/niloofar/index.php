<?php
/**
 * نیلوفر — پوسته‌ای مینیمال و خوانا برای نوشتن بدون حاشیه
 *
 * @package نیلوفر
 * @author پوردریایی
 * @version 1.0.0
 * @link https://pourdaryaei.ir
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$isHome = $this->is('index');
$heroCardEnabled = $isHome && $this->currentPage <= 1;
$layoutMode = (string) niloofarOpt('layoutMode', 'single');
?>

<?php if (!$isHome): ?>
    <div class="archive-banner reveal">
        <div class="archive-banner-inner">
            <span class="archive-banner-icon" aria-hidden="true">
                <?php if ($this->is('search')): ?>
                    <?php echo niloofarIcon('search', 24); ?>
                <?php elseif ($this->is('category')): ?>
                    <?php echo niloofarIcon('folder', 24); ?>
                <?php elseif ($this->is('tag')): ?>
                    <?php echo niloofarIcon('tag', 24); ?>
                <?php else: ?>
                    <?php echo niloofarIcon('user', 24); ?>
                <?php endif; ?>
            </span>
            <h1 class="archive-banner-title">
                <?php $this->archiveTitle([
                    'category' => _t('%s'),
                    'search'   => _t('%s'),
                    'tag'      => _t('%s'),
                    'author'   => _t('%s')
                ], '', ''); ?>
            </h1>
            <?php if ($this->getDescription()): ?>
                <p class="archive-banner-desc"><?php $this->getDescription(); ?></p>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<div class="layout<?php echo $layoutMode === 'sidebar' ? ' layout-has-sidebar' : ' layout-single'; ?>">

    <div class="layout-primary">

        <?php if ($this->have()): ?>

            <div class="posts-list">

                <?php
                    $postIndex = 0;
                    while ($this->next()):
                        $postIndex++;

                        // ---- کارت بزرگ تازه‌ترین نوشته (فقط صفحهٔ نخست خانه) ----
                        if ($heroCardEnabled && $postIndex === 1):
                            niloofarRenderHeroCard($this);
                            if ($this->length > 1): ?>
                                <div class="posts-heading reveal">
                                    <h2 class="posts-heading-title"><?php _e('نوشته‌های دیگر'); ?></h2>
                                </div>
                            <?php endif;
                        else:
                            // ---- کارت‌های افقی ----
                            niloofarRenderCard($this);
                        endif;
                    endwhile;
                ?>

            </div>

            <nav class="pagination-area" aria-label="<?php _e('صفحه‌بندی'); ?>">
                <?php
                    ob_start();
                    $this->pageNav(
                        niloofarIcon('chevron-right', 16),
                        niloofarIcon('chevron-left', 16),
                        2,
                        '…'
                    );
                    echo niloofarNavDigits((string) ob_get_clean());
                ?>
            </nav>

            <?php if ($layoutMode !== 'sidebar' && $isHome && $this->currentPage <= 1): ?>
                <?php niloofarRenderPopularSection(); ?>
            <?php endif; ?>

        <?php else: ?>

            <div class="empty-state reveal">
                <div class="empty-state-ornament" aria-hidden="true">
                    <?php echo niloofarLotusSvg(56); ?>
                </div>
                <h2 class="empty-state-title"><?php _e('چیزی اینجا نیست'); ?></h2>
                <p class="empty-state-text">
                    <?php $this->archiveTitle([
                        'category' => _t('هنوز در دستهٔ «%s» نوشته‌ای منتشر نشده است.'),
                        'search'   => _t('برای «%s» نتیجه‌ای پیدا نشد؛ عبارت دیگری را بیازمایید.'),
                        'tag'      => _t('هنوز نوشته‌ای با برچسب «%s» منتشر نشده است.'),
                        'author'   => _t('هنوز %s نوشته‌ای منتشر نکرده است.')
                    ], '', ''); ?>
                </p>
                <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="empty-search-form">
                    <input type="search" name="s" placeholder="<?php _e('مثلاً: دستور پخت قیمه'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" required />
                    <button type="submit"><?php _e('جستجو'); ?></button>
                </form>
                <a class="btn-primary" href="<?php $this->options->siteUrl(); ?>">
                    <span><?php _e('بازگشت به خانه'); ?></span>
                </a>
            </div>

        <?php endif; ?>

    </div>

    <?php if ($layoutMode === 'sidebar'): ?>
        <?php $this->need('sidebar.php'); ?>
    <?php endif; ?>

</div>

<?php $this->need('footer.php'); ?>
