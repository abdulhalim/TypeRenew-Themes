<?php
/**
 * زیبا — پوستهٔ وبلاگی فارسی مینیمال ، مدرن و زیبا
 *
 * @package زیبا
 * @author  پوردریایی
 * @version 1.0.0
 * @link    https://pourdaryaei.ir
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$cardStyle = (string) ziba_opt('postCardStyle', 'grid');
if (!in_array($cardStyle, ['grid', 'list'], true)) {
    $cardStyle = 'grid';
}
$showReadingTime = ziba_on('showReadingTime', '1');
$showViews = ziba_on('showViews', '1');
$showSidebar = ziba_show_sidebar($this);
?>

<div class="container">
    <div class="layout<?php echo $showSidebar ? '' : ' no-sidebar'; ?>">

        <?php if ($this->have()): ?>

            <?php /* سرصفحهٔ بخش، بالای هر دو ستون: بدنهٔ اصلی و سایدبار */ ?>
            <div class="posts-heading">
                <h2 class="posts-heading-title"><?php _e('تازه‌ترین نوشته‌ها'); ?></h2>
                <span class="posts-heading-line" aria-hidden="true"></span>
            </div>

        <?php endif; ?>

        <div class="content-area">

            <?php if ($this->have()): ?>

                <div class="posts-<?php echo $cardStyle === 'list' ? 'list' : 'grid'; ?>">

                    <?php while ($this->next()): ?>
                        <?php
                            $cover = ziba_card_image($this);
                            $cid = (int) $this->cid;
                            $views = ziba_views($this);
                            $likes = ziba_likes($this);
                            $comments = (int) $this->commentsNum;
                        ?>
                        <article class="post-card reveal" data-cid="<?php echo $cid; ?>" itemscope itemtype="http://schema.org/BlogPosting">

                            <a class="card-cover" href="<?php $this->permalink(); ?>" aria-hidden="true" tabindex="-1">
                                <?php if ($cover !== ''): ?>
                                    <img src="<?php echo htmlspecialchars($cover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->title(); ?>" loading="lazy" itemprop="image" />
                                <?php else: ?>
                                    <span class="card-cover-fallback" aria-hidden="true">
                                        <svg viewBox="0 0 48 48" width="42" height="42" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round">
                                            <path d="M24 6 L28.5 18 L41 22.5 L28.5 27 L24 39 L19.5 27 L7 22.5 L19.5 18 Z"/>
                                        </svg>
                                    </span>
                                <?php endif; ?>
                                <?php if ($this->categories): ?>
                                    <span class="card-cat"><?php echo htmlspecialchars($this->categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></span>
                                <?php endif; ?>
                            </a>

                            <div class="card-body">
                                <div class="card-top">
                                    <time class="card-date" datetime="<?php echo date('c', (int) $this->created); ?>"><?php echo ziba_date((int) $this->created); ?></time>
                                    <?php if ($showReadingTime): ?>
                                        <span class="card-read"><?php echo ziba_icon('clock', 13); ?> <?php echo ziba_fa((string) ziba_reading_time($this)); ?> <?php _e('دقیقه'); ?></span>
                                    <?php endif; ?>
                                </div>

                                <h2 class="card-title" itemprop="name headline">
                                    <a href="<?php $this->permalink(); ?>" itemprop="url"><?php $this->title(); ?></a>
                                </h2>

                                <?php $excerpt = ziba_excerpt($this, 24); ?>
                                <?php if ($excerpt !== ''): ?>
                                    <p class="card-excerpt"><?php echo htmlspecialchars($excerpt, ENT_QUOTES, 'UTF-8'); ?></p>
                                <?php endif; ?>

                                <div class="card-meta">
                                    <a class="card-author" href="<?php $this->author->permalink(); ?>">
                                        <?php echo ziba_author_avatar($this, 28); ?>
                                        <span><?php $this->author(); ?></span>
                                    </a>
                                    <span class="card-stats">
                                        <?php if ($showViews): ?>
                                            <span class="stat-chip" title="<?php _e('بازدید'); ?>"><?php echo ziba_icon('eye', 14); ?><span><?php echo ziba_format_count($views); ?></span></span>
                                        <?php endif; ?>
                                        <?php if ($likes > 0): ?>
                                            <span class="stat-chip" title="<?php _e('پسند'); ?>"><?php echo ziba_icon('heart', 14); ?><span><?php echo ziba_format_count($likes); ?></span></span>
                                        <?php endif; ?>
                                        <?php if ($comments > 0): ?>
                                            <span class="stat-chip" title="<?php _e('دیدگاه'); ?>"><?php echo ziba_icon('comment', 14); ?><span><?php echo ziba_format_count($comments); ?></span></span>
                                        <?php endif; ?>
                                    </span>
                                </div>
                            </div>
                        </article>
                    <?php endwhile; ?>

                </div>

                <nav class="pagination-area reveal" aria-label="<?php _e('ناوبری صفحات'); ?>">
                    <?php
                        ob_start();
                        $this->pageNav(
                            '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 6 15 12 9 18"></polyline></svg>',
                            '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 6 9 12 15 18"></polyline></svg>',
                            2,
                            '…'
                        );
                        echo ziba_nav_fa((string) ob_get_clean());
                    ?>
                </nav>

            <?php else: ?>

                <div class="empty-state reveal">
                    <div class="empty-ornament" aria-hidden="true">
                        <svg viewBox="0 0 48 48" width="72" height="72" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round">
                            <path d="M24 6 L28.5 18 L41 22.5 L28.5 27 L24 39 L19.5 27 L7 22.5 L19.5 18 Z"/>
                        </svg>
                    </div>
                    <h2 class="empty-title"><?php _e('هنوز چیزی اینجا نیست'); ?></h2>
                    <p class="empty-desc"><?php _e('اولین نوشته را منتشر کنید تا جشن شروع شود؛ این جای خالی، منتظر زیباترین نوشته‌های شماست.'); ?></p>
                    <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="empty-search-form">
                        <input type="search" name="s" placeholder="<?php _e('یا چیزی جستجو کنید…'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" />
                        <button type="submit"><?php _e('جستجو'); ?></button>
                    </form>
                </div>

            <?php endif; ?>

        </div>

        <?php if ($showSidebar): ?>
            <?php $this->need('sidebar.php'); ?>
        <?php endif; ?>

    </div>
</div>

<?php $this->need('footer.php'); ?>
