<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
?>

</main>

<footer class="site-footer" role="contentinfo">
    <div class="footer-glow" aria-hidden="true"></div>
    <div class="container">

        <div class="footer-top">
            <a class="footer-brand" href="<?php $this->options->siteUrl(); ?>">
                <span class="footer-mark" aria-hidden="true">
                    <svg viewBox="0 0 48 48" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round">
                        <path d="M24 6 L28.5 18 L41 22.5 L28.5 27 L24 39 L19.5 27 L7 22.5 L19.5 18 Z"/>
                    </svg>
                </span>
                <span class="footer-name"><?php $this->options->title(); ?></span>
            </a>

            <div class="footer-social">
                <?php if (ziba_opt('socialTelegram')): ?>
                    <a href="<?php echo htmlspecialchars(ziba_resolve((string) ziba_opt('socialTelegram')), ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" aria-label="تلگرام" title="تلگرام"><?php echo ziba_icon('telegram', 18); ?></a>
                <?php endif; ?>
                <?php if (ziba_opt('socialInstagram')): ?>
                    <a href="<?php echo htmlspecialchars(ziba_resolve((string) ziba_opt('socialInstagram')), ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" aria-label="اینستاگرام" title="اینستاگرام"><?php echo ziba_icon('instagram', 18); ?></a>
                <?php endif; ?>
                <?php if (ziba_opt('socialGithub')): ?>
                    <a href="<?php echo htmlspecialchars(ziba_resolve((string) ziba_opt('socialGithub')), ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" aria-label="گیت‌هاب" title="گیت‌هاب"><?php echo ziba_icon('github', 18); ?></a>
                <?php endif; ?>
                <?php if (ziba_opt('socialLinkedin')): ?>
                    <a href="<?php echo htmlspecialchars(ziba_resolve((string) ziba_opt('socialLinkedin')), ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" aria-label="لینکدین" title="لینکدین"><?php echo ziba_icon('linkedin', 18); ?></a>
                <?php endif; ?>
            </div>
        </div>

        <div class="footer-grid">
            <div class="footer-about">
                <h3 class="footer-heading"><?php _e('دربارهٔ این وبلاگ'); ?></h3>
                <?php $footerText = trim((string) ziba_opt('footerText')); ?>
                <p><?php echo nl2br(strip_tags($footerText !== '' ? $footerText : (string) $this->options->description)); ?></p>
            </div>

            <nav class="footer-links" aria-label="<?php _e('پیوندهای فوتر'); ?>">
                <h3 class="footer-heading"><?php _e('دسترسی سریع'); ?></h3>
                <ul>
                    <li><a href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a></li>
                    <?php \Widget\Contents\Page\Rows::allocWithAlias('ziba-footer')->to($footerPages); ?>
                    <?php while ($footerPages->next()): ?>
                        <li><a href="<?php $footerPages->permalink(); ?>"><?php $footerPages->title(); ?></a></li>
                    <?php endwhile; ?>
                </ul>
            </nav>

            <?php $footerStats = ziba_stats(); ?>
            <div class="footer-stats">
                <h3 class="footer-heading"><?php _e('آمار زیبا'); ?></h3>
                <div class="footer-stats-grid">
                    <span class="footer-stat"><strong><?php echo ziba_format_count($footerStats['posts']); ?></strong><span><?php _e('نوشته'); ?></span></span>
                    <span class="footer-stat"><strong><?php echo ziba_format_count($footerStats['comments']); ?></strong><span><?php _e('دیدگاه'); ?></span></span>
                    <span class="footer-stat"><strong><?php echo ziba_format_count($footerStats['views']); ?></strong><span><?php _e('بازدید'); ?></span></span>
                </div>
            </div>
        </div>

        <div class="footer-bottom">
            <p class="footer-copy">
                <?php
                    [$jy] = ziba_to_jalali((int) date('Y'), (int) date('n'), (int) date('j'));
                    echo ziba_fa((string) $jy);
                ?> &copy;
                <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a>
                <span class="footer-sep" aria-hidden="true">·</span>
                <?php _e('همهٔ حقوق محفوظ است'); ?>
            </p>
            <p class="footer-credit">
                <?php _e('پوستهٔ'); ?> <a href="https://pourdaryaei.ir" rel="noopener">زیبا</a>
                <span class="footer-sep" aria-hidden="true">·</span>
                <?php _e('قدرت‌گرفته از'); ?> <a href="https://www.typerenew.ir" rel="noopener">TypeRenew</a>
            </p>
        </div>

    </div>
</footer>

<button type="button" class="back-to-top" aria-label="<?php _e('بازگشت به بالای صفحه'); ?>" title="<?php _e('بازگشت به بالا'); ?>">
    <?php echo ziba_icon('arrow-up', 18); ?>
</button>

<div class="toast" id="ziba-toast" role="status" aria-live="polite"></div>
<div class="lightbox" id="ziba-lightbox" hidden role="dialog" aria-modal="true" aria-label="<?php _e('نمایش تصویر'); ?>">
    <button type="button" class="lightbox-close" aria-label="<?php _e('بستن'); ?>"><?php echo ziba_icon('close', 22); ?></button>
    <button type="button" class="lightbox-nav lightbox-prev" aria-label="<?php _e('تصویر قبلی'); ?>" hidden><?php echo ziba_icon('chevron-right', 26); ?></button>
    <button type="button" class="lightbox-nav lightbox-next" aria-label="<?php _e('تصویر بعدی'); ?>" hidden><?php echo ziba_icon('chevron-left', 26); ?></button>
    <figure class="lightbox-figure">
        <img class="lightbox-img" src="" alt="" />
        <figcaption class="lightbox-caption" hidden></figcaption>
    </figure>
    <span class="lightbox-counter" dir="ltr" hidden></span>
</div>

<?php $this->footer(); ?>

<script>
    window.ZIBA = {
        siteUrl: <?php echo json_encode((string) $this->options->siteUrl, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP); ?>,
        lightbox: <?php echo ziba_on('enableLightbox', '1') ? 'true' : 'false'; ?>,
        progress: <?php echo (ziba_on('showReadingTime', '1') && $this->is('post')) ? 'true' : 'false'; ?>,
        toastCopied: <?php echo json_encode('پیوند نوشته کپی شد'); ?>,
        toastLikeFail: <?php echo json_encode('ذخیرهٔ پسند ممکن نشد؛ دوباره تلاش کنید'); ?>,
        toastOffline: <?php echo json_encode('اتصال اینترنت را بررسی کنید'); ?>
    };
</script>
<script src="<?php $this->options->themeUrl('assets/js/ziba.js?v=1.3.1'); ?>"></script>

</body>
</html>
