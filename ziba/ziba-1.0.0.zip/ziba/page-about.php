<?php
/**
 * صفحهٔ اختصاصی «درباره من»
 *
 * @package custom
 * @author  Ziba
 * @version 1.0.0
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

// تصویر بزرگ: تنظیم پوسته ← نخستین تصویر متن برگه
$aboutImage = trim((string) ziba_opt('aboutImage'));
if (!ziba_image_ok($aboutImage)) {
    $aboutImage = ziba_first_image((string) $this->text);
}
$aboutRole = trim((string) ziba_opt('aboutRole'));
$aboutSkills = ziba_about_skills();
$aboutInterests = ziba_about_interests();

// متن برگه — ساده و خوانا، در جریان صفحه
ob_start();
$this->content();
$aboutContent = trim((string) ob_get_clean());

$socials = [
    ['socialTelegram', 'telegram', 'تلگرام'],
    ['socialInstagram', 'instagram', 'اینستاگرام'],
    ['socialGithub', 'github', 'گیت‌هاب'],
    ['socialLinkedin', 'linkedin', 'لینکدین'],
];
?>

<div class="container">

    <section class="about-hero reveal">

        <div class="about-media<?php echo $aboutImage === '' ? ' about-media-empty' : ''; ?>">
            <?php if ($aboutImage !== ''): ?>
                <img src="<?php echo htmlspecialchars(ziba_resolve($aboutImage), ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->title(); ?>" />
            <?php else: ?>
                <span class="about-media-fallback" aria-hidden="true">
                    <svg viewBox="0 0 48 48" width="64" height="64" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round">
                        <path d="M24 6 L28.5 18 L41 22.5 L28.5 27 L24 39 L19.5 27 L7 22.5 L19.5 18 Z"/>
                    </svg>
                </span>
            <?php endif; ?>
            <span class="about-media-frame" aria-hidden="true"></span>
        </div>

        <div class="about-intro">
            <h1 class="about-kicker"><?php echo ziba_icon('sparkle', 15); ?><span><?php _e('درباره من'); ?></span></h1>
            <?php if ($aboutRole !== ''): ?>
                <p class="about-role"><?php echo htmlspecialchars($aboutRole, ENT_QUOTES, 'UTF-8'); ?></p>
            <?php endif; ?>

            <?php if (!empty($aboutSkills)): ?>
            <div class="about-skills">
                <span class="about-mini-title"><?php echo ziba_icon('sparkle', 14); ?><span><?php _e('مهارت‌های من'); ?></span></span>
                <?php foreach ($aboutSkills as $skillIndex => $skill): ?>
                    <div class="skill-item">
                        <div class="skill-head">
                            <span class="skill-name"><?php echo htmlspecialchars($skill['name'], ENT_QUOTES, 'UTF-8'); ?></span>
                            <?php if ($skill['level'] !== null): ?>
                                <span class="skill-level"><?php echo ziba_fa((string) $skill['level']); ?>٪</span>
                            <?php endif; ?>
                        </div>
                        <?php if ($skill['level'] !== null): ?>
                            <div class="skill-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo $skill['level']; ?>" aria-label="<?php echo htmlspecialchars($skill['name'], ENT_QUOTES, 'UTF-8'); ?>">
                                <span class="skill-fill" style="--skill:<?php echo $skill['level']; ?>%;--skill-delay:<?php echo $skillIndex * 90; ?>ms"></span>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if (!empty($aboutInterests)): ?>
            <div class="about-interests">
                <span class="about-interests-label"><?php _e('علاقه‌مندی‌ها'); ?></span>
                <?php foreach ($aboutInterests as $interestTag): ?>
                    <span class="about-interest"><?php echo htmlspecialchars($interestTag, ENT_QUOTES, 'UTF-8'); ?></span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <div class="about-social">
                <?php foreach ($socials as [$key, $icon, $label]): ?>
                    <?php $url = trim((string) ziba_opt($key)); ?>
                    <?php if ($url !== ''): ?>
                        <a href="<?php echo htmlspecialchars(ziba_resolve($url), ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" aria-label="<?php echo $label; ?>" title="<?php echo $label; ?>">
                            <?php echo ziba_icon($icon, 19); ?>
                        </a>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>

            <?php if ($aboutContent !== ''): ?>
                <div class="post-content about-text" itemprop="articleBody">
                    <?php echo $aboutContent; ?>
                </div>
            <?php endif; ?>
        </div>

    </section>

</div>

<?php $this->need('footer.php'); ?>
