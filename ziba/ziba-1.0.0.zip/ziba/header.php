<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php if ($this->is('archive', '404')): ?><?php _e('صفحه پیدا نشد'); ?> — <?php $this->options->title(); ?><?php else: ?><?php $this->archiveTitle([
            'category' => _t('نوشته‌های دستهٔ «%s»'),
            'search'   => _t('نتایج جستجو برای «%s»'),
            'tag'      => _t('نوشته‌های برچسب «%s»'),
            'author'   => _t('نوشته‌های %s')
        ], '', ' — '); ?><?php $this->options->title(); ?><?php endif; ?></title>

    <?php
        // حالت رنگی پیش از رنگ‌آمیزی صفحه (بدون پرش سفید)
        $defaultSchema = (string) ziba_opt('colorSchema', 'light');
        if (!in_array($defaultSchema, ['auto', 'light', 'dark'], true)) {
            $defaultSchema = 'light';
        }
        $schemaJson = \Typecho\Common::jsonEncode(
            $defaultSchema,
            JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP,
            '"light"'
        );
        echo "<script>
            (function() {
                var stored = null;
                try { stored = localStorage.getItem('ziba-theme'); } catch (e) {}
                var def = {$schemaJson};
                var isDark = false;
                if (stored === 'dark' || stored === 'light') {
                    isDark = (stored === 'dark');
                } else if (def === 'dark') {
                    isDark = true;
                } else if (def === 'auto' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                    isDark = true;
                }
                if (isDark) {
                    document.documentElement.setAttribute('data-theme', 'dark');
                }
            })();
        </script>";
    ?>

    <link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/ziba.css?v=1.3.1'); ?>">
    <?php $this->header(); ?>
</head>
<body<?php echo $this->is('single') ? ' class="is-single"' : ''; ?>>
<a class="skip-link" href="#content"><?php _e('رفتن به محتوا'); ?></a>

<header class="site-header" id="site-header">
    <div class="container header-inner">

        <a class="brand" href="<?php $this->options->siteUrl(); ?>">
            <?php $logo = trim((string) ziba_opt('logoUrl')); ?>
            <?php if ($logo !== ''): ?>
                <span class="brand-logo"><img src="<?php echo htmlspecialchars(ziba_resolve($logo), ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->options->title(); ?>" /></span>
            <?php else: ?>
                <span class="brand-mark" aria-hidden="true">
                    <svg viewBox="0 0 48 48" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round">
                        <path d="M24 6 L28.5 18 L41 22.5 L28.5 27 L24 39 L19.5 27 L7 22.5 L19.5 18 Z"/>
                    </svg>
                </span>
            <?php endif; ?>
            <span class="brand-name"><?php $this->options->title(); ?></span>
        </a>

        <nav class="main-nav" aria-label="<?php _e('ناوبری اصلی'); ?>">
            <a <?php if ($this->is('index')): ?>class="active"<?php endif; ?> href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a>
            <?php \Widget\Contents\Page\Rows::alloc()->to($pages); ?>
            <?php while ($pages->next()): ?>
                <a <?php if ($this->is('page', $pages->slug)): ?>class="active"<?php endif; ?> href="<?php $pages->permalink(); ?>"><?php $pages->title(); ?></a>
            <?php endwhile; ?>
        </nav>

        <div class="header-actions">
            <button type="button" class="icon-btn js-search-toggle" aria-label="<?php _e('جستجو'); ?>" title="<?php _e('جستجو'); ?>">
                <?php echo ziba_icon('search', 19); ?>
            </button>
            <button type="button" class="icon-btn theme-switch" aria-label="<?php _e('تغییر حالت روشن و تیره'); ?>" title="<?php _e('تغییر حالت روشن و تیره'); ?>">
                <span class="theme-icon" aria-hidden="true"></span>
            </button>
            <button type="button" class="icon-btn nav-toggle js-nav-toggle" aria-label="<?php _e('گشودن منو'); ?>" aria-expanded="false">
                <?php echo ziba_icon('menu', 20); ?>
            </button>
        </div>

    </div>

    <div class="header-search js-header-search" hidden>
        <div class="container">
            <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="header-search-form">
                <?php echo ziba_icon('search', 18); ?>
                <input type="search" name="s" class="header-search-input" placeholder="<?php _e('دنبال چه چیزی می‌گردید؟'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" value="<?php echo htmlspecialchars((string) ($this->request->keywords ?? $this->request->s ?? ''), ENT_QUOTES, 'UTF-8'); ?>" autocomplete="off" />
                <button type="button" class="header-search-close js-search-close" aria-label="<?php _e('بستن'); ?>"><?php echo ziba_icon('close', 18); ?></button>
            </form>
        </div>
    </div>
</header>

<?php
    // ---------- بخش هیرو (فقط صفحهٔ نخست) ----------
    $isHeroPage = $this->is('index') && (int) ($this->request->get('page', 1)) < 2;
    if ($isHeroPage && ziba_on('heroShow', '1')):
        $heroTitle = trim((string) ziba_opt('heroTitle'));
        if ($heroTitle === '') {
            $heroTitle = (string) $this->options->title;
        }
        $heroSubtitle = trim((string) ziba_opt('heroSubtitle'));
        if ($heroSubtitle === '') {
            $heroSubtitle = (string) $this->options->description;
        }
        $heroImage = trim((string) ziba_opt('heroImage'));
        $heroHasImage = ziba_image_ok($heroImage);
        $heroPattern = $heroHasImage ? 'none' : ziba_hero_pattern();
        $heroHeight = (string) ziba_opt('heroHeight', 'medium');
        if (!in_array($heroHeight, ['short', 'medium', 'tall'], true)) {
            $heroHeight = 'medium';
        }
        $stats = ziba_stats();
?>
<section class="hero hero-<?php echo htmlspecialchars($heroHeight, ENT_QUOTES, 'UTF-8'); ?><?php echo $heroHasImage ? ' has-image' : ' no-image'; ?>" aria-label="<?php _e('معرفی وبلاگ'); ?>">
    <div class="hero-bg"<?php if ($heroHasImage): ?> style="background-image:url('<?php echo htmlspecialchars(ziba_resolve($heroImage), ENT_QUOTES, 'UTF-8'); ?>')"<?php endif; ?>></div>
    <?php if (!$heroHasImage && $heroPattern !== 'none'): ?>
    <div class="hero-pattern hero-pattern-<?php echo htmlspecialchars($heroPattern, ENT_QUOTES, 'UTF-8'); ?>" aria-hidden="true"></div>
    <?php endif; ?>

    <div class="container hero-inner">
        <span class="hero-kicker"><?php echo ziba_icon('sparkle', 15); ?><span><?php _e('به دنیای زیبا خوش آمدید'); ?></span></span>
        <h1 class="hero-title"><?php echo htmlspecialchars($heroTitle, ENT_QUOTES, 'UTF-8'); ?></h1>
        <?php if ($heroSubtitle !== ''): ?>
            <p class="hero-subtitle"><?php echo htmlspecialchars($heroSubtitle, ENT_QUOTES, 'UTF-8'); ?></p>
        <?php endif; ?>

        <?php
            // آمار هیرو — گزینشی از تنظیمات (نوشته/بازدید/دیدگاه)
            $heroStatKeys = ziba_hero_stats();
            $heroStatLabels = [
                'posts'    => _t('نوشته'),
                'views'    => _t('بازدید'),
                'comments' => _t('دیدگاه'),
            ];
        ?>
        <?php if (!empty($heroStatKeys)): ?>
        <div class="hero-stats">
            <?php foreach ($heroStatKeys as $si => $statKey): ?>
                <?php if ($si > 0): ?>
                    <span class="hero-stat-sep" aria-hidden="true"></span>
                <?php endif; ?>
                <span class="hero-stat"><strong><?php echo ziba_format_count($stats[$statKey]); ?></strong><span><?php echo $heroStatLabels[$statKey]; ?></span></span>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <a class="hero-scroll" href="#content" aria-label="<?php _e('رفتن به نوشته‌ها'); ?>">
        <span class="hero-scroll-mouse" aria-hidden="true"><span></span></span>
        <span class="hero-scroll-text"><?php _e('اسکرول کنید'); ?></span>
    </a>
</section>
<?php endif; ?>

<main id="content" class="site-main">
