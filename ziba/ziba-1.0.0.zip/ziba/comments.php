<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$requireUrl = isset($this->options->commentsRequireUrl) ? $this->options->commentsRequireUrl : $this->options->commentsRequireURL;
?>

<div id="comments" class="comments-area reveal">

    <div class="comments-header">
        <h2 class="section-title">
            <span class="section-title-ornament" aria-hidden="true">
                <svg viewBox="0 0 48 48" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round">
                    <path d="M24 6 L28.5 18 L41 22.5 L28.5 27 L24 39 L19.5 27 L7 22.5 L19.5 18 Z"/>
                </svg>
            </span>
            <?php _e('دیدگاه‌ها'); ?>
            <span class="comments-count"><?php $this->commentsNum(_t('۰'), _t('۱'), _t('%d')); ?></span>
        </h2>
    </div>

    <?php $this->comments()->to($comments); ?>

    <?php if ($comments->have()): ?>
        <div class="comments-body">
            <?php $comments->listComments([
                'before'        => '<ol class="comment-list">',
                'after'         => '</ol>',
                'commentStatus' => _t('در انتظار تأیید')
            ]); ?>

            <?php
                ob_start();
                $comments->pageNav(
                    '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 6 15 12 9 18"></polyline></svg>',
                    '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 6 9 12 15 18"></polyline></svg>'
                );
                echo ziba_nav_fa((string) ob_get_clean());
            ?>
        </div>
    <?php endif; ?>

    <?php if ($this->allow('comment')): ?>
        <div id="<?php $this->respondId(); ?>" class="respond">
            <div class="cancel-comment-reply">
                <?php $comments->cancelReply(); ?>
            </div>

            <h3 id="response" class="respond-title"><?php _e('دیدگاه خود را بنویسید'); ?></h3>

            <form method="post" action="<?php $this->commentUrl(); ?>" id="comment-form" role="form" class="comment-form">
                <?php $security = \Widget\Security::alloc(); ?>
                <input type="hidden" name="_" value="<?php echo htmlspecialchars($security->getToken($this->request->getRequestUrl()), ENT_QUOTES, 'UTF-8'); ?>">

                <?php if ($this->user->hasLogin()): ?>
                    <p class="comment-logged-in">
                        <?php _e('ورود با حساب'); ?>:
                        <a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>
                        <a class="comment-logout" href="<?php $this->options->logoutUrl(); ?>"><?php _e('خروج'); ?></a>
                    </p>
                <?php else: ?>
                    <div class="comment-form-fields">
                        <div class="form-field">
                            <label for="author"><?php _e('نام'); ?> <span class="required">*</span></label>
                            <input type="text" name="author" id="author" placeholder="<?php _e('نام شما'); ?>" value="<?php $this->remember('author'); ?>" required>
                        </div>
                        <div class="form-field">
                            <label for="mail"><?php _e('ایمیل'); ?><?php if ($this->options->commentsRequireMail): ?> <span class="required">*</span><?php endif; ?></label>
                            <input type="email" name="mail" id="mail" class="ltr-input" placeholder="you@example.com" value="<?php $this->remember('mail'); ?>"<?php if ($this->options->commentsRequireMail): ?> required<?php endif; ?>>
                        </div>
                        <div class="form-field">
                            <label for="url"><?php _e('وب‌سایت'); ?><?php if ($requireUrl): ?> <span class="required">*</span><?php endif; ?></label>
                            <input type="url" name="url" id="url" class="ltr-input" placeholder="https://" value="<?php $this->remember('url'); ?>"<?php if ($requireUrl): ?> required<?php endif; ?>>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="form-field">
                    <label for="textarea"><?php _e('متن دیدگاه'); ?> <span class="required">*</span></label>
                    <textarea name="text" id="textarea" rows="6" placeholder="<?php _e('دیدگاه شما…'); ?>" required><?php $this->remember('text'); ?></textarea>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <?php echo ziba_icon('comment', 16); ?>
                        <?php _e('ارسال دیدگاه'); ?>
                    </button>
                </div>
            </form>
        </div>
    <?php else: ?>
        <div class="comments-closed">
            <?php echo ziba_icon('comment', 20); ?>
            <?php _e('امکان ارسال دیدگاه برای این نوشته بسته شده است.'); ?>
        </div>
    <?php endif; ?>

</div>
