<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$showViews = ziba_on('showViews', '1');
$showSidebar = ziba_show_sidebar($this);
?>

<div class="container">
    <div class="layout<?php echo $showSidebar ? '' : ' no-sidebar'; ?>">

        <div class="content-area">

            <header class="archive-banner reveal">
                <span class="archive-banner-icon" aria-hidden="true">
                    <?php
                        if ($this->is('search')) {
                            echo ziba_icon('search', 24);
                        } elseif ($this->is('category')) {
                            echo ziba_icon('folder', 24);
                        } elseif ($this->is('tag')) {
                            echo ziba_icon('tag', 24);
                        } elseif ($this->is('author')) {
                            echo ziba_icon('user', 24);
                        } else {
                            echo ziba_icon('calendar', 24);
                        }
                    ?>
                </span>
                <div class="archive-banner-text">
                    <h1 class="archive-banner-title">
                        <?php $this->archiveTitle([
                            'category' => _t('دستهٔ %s'),
                            'search'   => _t('نتایج جستجوی «%s»'),
                            'tag'      => _t('برچسب %s'),
                            'author'   => _t('نوشته‌های %s')
                        ], '', ''); ?>
                    </h1>
                    <?php if ($this->getDescription()): ?>
                        <p class="archive-banner-desc"><?php $this->getDescription(); ?></p>
                    <?php else: ?>
                        <p class="archive-banner-desc"><?php _e('فهرست مینیمال نوشته‌های این بخش، از تازه‌ترین تا قدیمی‌ترین'); ?></p>
                    <?php endif; ?>
                </div>
                <?php $total = (int) $this->getTotal(); ?>
                <?php if ($total > 0): ?>
                    <span class="archive-banner-count"><?php echo ziba_format_count($total); ?> <?php _e('نوشته'); ?></span>
                <?php endif; ?>
            </header>

            <?php if ($this->have()): ?>

                <div class="mini-list">

                    <?php while ($this->next()): ?>
                        <?php
                            $miniCover = ziba_card_image($this);
                            $miniViews = ziba_views($this);
                        ?>
                        <article class="mini-item reveal" itemscope itemtype="http://schema.org/BlogPosting">

                            <a class="mini-thumb" href="<?php $this->permalink(); ?>" aria-hidden="true" tabindex="-1">
                                <?php if ($miniCover !== ''): ?>
                                    <img src="<?php echo htmlspecialchars($miniCover, ENT_QUOTES, 'UTF-8'); ?>" alt="" loading="lazy" itemprop="image" />
                                <?php else: ?>
                                    <span class="mini-thumb-fallback" aria-hidden="true">
                                        <svg viewBox="0 0 48 48" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round">
                                            <path d="M24 6 L28.5 18 L41 22.5 L28.5 27 L24 39 L19.5 27 L7 22.5 L19.5 18 Z"/>
                                        </svg>
                                    </span>
                                <?php endif; ?>
                            </a>

                            <div class="mini-body">
                                <h2 class="mini-title" itemprop="name headline">
                                    <a href="<?php $this->permalink(); ?>" itemprop="url"><?php $this->title(); ?></a>
                                </h2>
                                <div class="mini-meta">
                                    <time datetime="<?php echo date('c', (int) $this->created); ?>"><?php echo ziba_date((int) $this->created); ?></time>
                                    <?php if ($this->categories): ?>
                                        <span class="mini-sep" aria-hidden="true">·</span>
                                        <a class="mini-cat" href="<?php echo htmlspecialchars($this->categories[0]['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($this->categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                                    <?php endif; ?>
                                    <?php if ($showViews && $miniViews > 0): ?>
                                        <span class="mini-sep" aria-hidden="true">·</span>
                                        <span class="mini-views"><?php echo ziba_icon('eye', 13); ?> <?php echo ziba_format_count($miniViews); ?> <?php _e('بازدید'); ?></span>
                                    <?php endif; ?>
                                    <?php if ((int) $this->commentsNum > 0): ?>
                                        <span class="mini-sep" aria-hidden="true">·</span>
                                        <span class="mini-comments"><?php echo ziba_format_count((int) $this->commentsNum); ?> <?php _e('دیدگاه'); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <a class="mini-arrow" href="<?php $this->permalink(); ?>" aria-label="<?php $this->title(); ?>">
                                <?php echo ziba_icon('arrow-left', 18); ?>
                            </a>
                        </article>
                    <?php endwhile; ?>

                </div>

                <nav class="pagination-area reveal" aria-label="<?php _e('ناوبری صفحات'); ?>">
                    <?php
                        ob_start();
                        $this->pageNav(
                            '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 6 15 12 9 18"></polyline></svg>',
                            '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 6 9 12 15 18"></polyline></svg>',
                            2,
                            '…'
                        );
                        echo ziba_nav_fa((string) ob_get_clean());
                    ?>
                </nav>

            <?php else: ?>

                <div class="empty-state reveal">
                    <div class="empty-ornament" aria-hidden="true">
                        <svg viewBox="0 0 48 48" width="72" height="72" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round">
                            <circle cx="21" cy="21" r="13"></circle>
                            <line x1="30" y1="30" x2="41" y2="41"></line>
                        </svg>
                    </div>
                    <h2 class="empty-title"><?php _e('چیزی پیدا نشد'); ?></h2>
                    <p class="empty-desc">
                        <?php $this->archiveTitle([
                            'category' => _t('هنوز در دستهٔ «%s» نوشته‌ای منتشر نشده است.'),
                            'search'   => _t('برای «%s» نتیجه‌ای پیدا نشد؛ عبارت دیگری را بیازمایید.'),
                            'tag'      => _t('هنوز نوشته‌ای با برچسب «%s» منتشر نشده است.'),
                            'author'   => _t('هنوز %s نوشته‌ای منتشر نکرده است.')
                        ], '', ''); ?>
                    </p>
                    <a class="btn btn-primary" href="<?php $this->options->siteUrl(); ?>"><?php _e('بازگشت به خانه'); ?></a>
                </div>

            <?php endif; ?>

        </div>

        <?php if ($showSidebar): ?>
            <?php $this->need('sidebar.php'); ?>
        <?php endif; ?>

    </div>
</div>

<?php $this->need('footer.php'); ?>
