<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');
?>

<div class="error-page reveal">
    <div class="error-ornament" aria-hidden="true">
        <svg viewBox="0 0 48 48" width="110" height="110" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round">
            <path d="M24 6 L28.5 18 L41 22.5 L28.5 27 L24 39 L19.5 27 L7 22.5 L19.5 18 Z"/>
            <circle cx="24" cy="22.5" r="19"></circle>
        </svg>
    </div>
    <h1 class="error-code"><?php _e('۴۰۴'); ?></h1>
    <h2 class="error-title"><?php _e('این صفحه در وبلاگ زیبا پیدا نشد!'); ?></h2>
    <p class="error-desc">
        <?php _e('نشانی‌ای که دنبالش بودید یا حذف شده، یا جابه‌جا شده، یا از ابتدا هرگز وجود نداشته است. اما نگران نباشید؛ این‌جا راه‌های زیادی برای ادامه هست.'); ?>
    </p>
    <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="error-search-form">
        <input type="search" name="s" placeholder="<?php _e('جستجو کنید…'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" autofocus>
        <button type="submit"><?php _e('جستجو'); ?></button>
    </form>
    <div class="error-actions">
        <a class="btn btn-primary" href="<?php $this->options->siteUrl(); ?>">
            <?php echo ziba_icon('home', 16); ?>
            <?php _e('بازگشت به خانه'); ?>
        </a>
    </div>
</div>

<?php $this->need('footer.php'); ?>
