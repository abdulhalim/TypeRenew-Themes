<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$showReadingTime = ziba_on('showReadingTime', '1');
$showViews = ziba_on('showViews', '1');
$showLikes = ziba_on('showLikes', '1');
$showRelated = ziba_on('showRelated', '1');
$showAuthorBox = ziba_on('showAuthorBox', '1');
$showSidebar = ziba_show_sidebar($this);

// تصویر شاخص — فقط فیلد thumb؛ بدون آن جای تصویر خالی می‌ماند
$postCover = ziba_thumbnail($this);
$cid = (int) $this->cid;
$views = ziba_views($this);
$likes = ziba_likes($this);
$liked = ziba_is_liked($cid);
$categories = $this->categories;
?>

<div class="container">
    <div class="layout<?php echo $showSidebar ? '' : ' no-sidebar'; ?>">

        <div class="content-area">

            <article class="single-post reveal" data-cid="<?php echo $cid; ?>" itemscope itemtype="http://schema.org/BlogPosting">

                <?php if ($postCover !== ''): ?>
                    <figure class="post-hero" itemprop="image" itemscope itemtype="http://schema.org/ImageObject">
                        <img src="<?php echo htmlspecialchars($postCover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->title(); ?>" itemprop="url" loading="eager" />
                        <span class="post-hero-heart" aria-hidden="true"><?php echo ziba_icon('heart', 56); ?></span>
                    </figure>
                <?php endif; ?>

                <nav class="breadcrumb" aria-label="<?php _e('مسیر صفحه'); ?>">
                    <a href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a>
                    <?php if (!empty($categories)): ?>
                        <span class="breadcrumb-sep" aria-hidden="true">/</span>
                        <a href="<?php echo htmlspecialchars($categories[0]['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                    <?php endif; ?>
                    <span class="breadcrumb-sep" aria-hidden="true">/</span>
                    <span class="breadcrumb-current" aria-current="page"><?php $this->title(); ?></span>
                </nav>

                <header class="post-header">
                    <h1 class="post-title" itemprop="name headline"><?php $this->title(); ?></h1>

                    <div class="post-meta">
                        <a class="post-author" href="<?php $this->author->permalink(); ?>" rel="author" itemprop="author">
                            <?php echo ziba_author_avatar($this, 40); ?>
                            <span class="post-author-info">
                                <span class="post-author-name"><?php $this->author(); ?></span>
                                <span class="post-author-role"><?php _e('نویسنده'); ?></span>
                            </span>
                        </a>
                        <span class="post-meta-item">
                            <?php echo ziba_icon('calendar', 15); ?>
                            <time datetime="<?php echo date('c', (int) $this->created); ?>" itemprop="datePublished"><?php echo ziba_date_long((int) $this->created); ?></time>
                        </span>
                        <?php if ($showReadingTime): ?>
                            <span class="post-meta-item">
                                <?php echo ziba_icon('clock', 15); ?>
                                <?php echo ziba_fa((string) ziba_reading_time($this)); ?> <?php _e('دقیقه مطالعه'); ?>
                            </span>
                        <?php endif; ?>
                        <?php if ($showViews): ?>
                            <span class="post-meta-item">
                                <?php echo ziba_icon('eye', 15); ?>
                                <?php echo ziba_format_count($views); ?> <?php _e('بازدید'); ?>
                            </span>
                        <?php endif; ?>
                        <span class="post-meta-item">
                            <?php echo ziba_icon('comment', 15); ?>
                            <a href="<?php $this->permalink(); ?>#comments"><?php $this->commentsNum(_t('بدون دیدگاه'), _t('یک دیدگاه'), _t('%d دیدگاه')); ?></a>
                        </span>
                    </div>
                </header>

                <div class="post-content" itemprop="articleBody">
                    <?php $this->content(); ?>
                </div>

                <?php if ($this->tags): ?>
                    <div class="post-tags" itemprop="keywords">
                        <span class="post-tags-label"><?php echo ziba_icon('tag', 15); ?><?php _e('برچسب‌ها'); ?></span>
                        <?php foreach ($this->tags as $tag): ?>
                            <a class="tag-pill" href="<?php echo htmlspecialchars($tag['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($tag['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="post-actions">
                    <?php if ($showLikes): ?>
                        <button type="button" class="like-btn<?php echo $liked ? ' is-liked' : ''; ?>" data-cid="<?php echo $cid; ?>" data-likes="<?php echo $likes; ?>"<?php echo $liked ? ' data-liked="1"' : ''; ?> aria-pressed="<?php echo $liked ? 'true' : 'false'; ?>">
                            <?php echo ziba_icon('heart', 20); ?>
                            <span class="like-count"><?php echo ziba_format_count($likes); ?></span>
                            <span class="like-label"><?php _e('پسندیدم'); ?></span>
                        </button>
                    <?php endif; ?>
                    <button type="button" class="act-btn js-copy-link" data-url="<?php $this->permalink(); ?>">
                        <?php echo ziba_icon('link', 18); ?>
                        <span><?php _e('کپی لینک'); ?></span>
                    </button>
                    <a class="act-btn" href="https://t.me/share/url?url=<?php echo urlencode((string) $this->permalink); ?>&text=<?php echo urlencode((string) $this->title); ?>" target="_blank" rel="noopener">
                        <?php echo ziba_icon('telegram', 18); ?>
                        <span><?php _e('هم‌رسانی'); ?></span>
                    </a>
                </div>

            </article>

            <?php if ($showAuthorBox): ?>
                <?php
                    $authorBio = trim((string) ziba_opt('authorBio'));
                    if ($authorBio === '') {
                        $authorBio = (string) $this->options->description;
                    }
                ?>
                <div class="author-box reveal">
                    <div class="author-box-avatar">
                        <?php echo ziba_author_avatar($this, 84); ?>
                    </div>
                    <div class="author-box-info">
                        <p class="author-box-role"><?php _e('نوشتهٔ'); ?> · <?php _e('نویسنده'); ?></p>
                        <h3 class="author-box-name">
                            <a href="<?php $this->author->permalink(); ?>" rel="author"><?php $this->author(); ?></a>
                        </h3>
                        <?php if ($authorBio !== ''): ?>
                            <p class="author-box-bio"><?php echo nl2br(htmlspecialchars($authorBio, ENT_QUOTES, 'UTF-8')); ?></p>
                        <?php endif; ?>
                        <a class="author-box-link" href="<?php $this->author->permalink(); ?>">
                            <?php _e('همهٔ نوشته‌های این نویسنده'); ?>
                            <?php echo ziba_icon('arrow-left', 15); ?>
                        </a>
                    </div>
                </div>
            <?php endif; ?>

            <nav class="post-nav reveal" aria-label="<?php _e('ناوبری نوشته‌ها'); ?>">
                <div class="post-nav-item post-nav-prev">
                    <span class="post-nav-label"><?php echo ziba_icon('arrow-right', 15); ?><?php _e('نوشتهٔ جدیدتر'); ?></span>
                    <div class="post-nav-link"><?php $this->theNext('%s', _t('نوشتهٔ جدیدتری نیست')); ?></div>
                </div>
                <div class="post-nav-item post-nav-next">
                    <span class="post-nav-label"><?php _e('نوشتهٔ قدیمی‌تر'); ?><?php echo ziba_icon('arrow-left', 15); ?></span>
                    <div class="post-nav-link"><?php $this->thePrev('%s', _t('نوشتهٔ قدیمی‌تری نیست')); ?></div>
                </div>
            </nav>

            <?php if ($showRelated): ?>
                <?php $this->related(3)->to($relatedPosts); ?>
                <?php if ($relatedPosts->have()): ?>
                    <section class="related-posts reveal" aria-label="<?php _e('مطالب مرتبط'); ?>">
                        <h2 class="section-title">
                            <span class="section-title-ornament" aria-hidden="true">
                                <svg viewBox="0 0 48 48" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round">
                                    <path d="M24 6 L28.5 18 L41 22.5 L28.5 27 L24 39 L19.5 27 L7 22.5 L19.5 18 Z"/>
                                </svg>
                            </span>
                            <?php _e('مطالب مرتبط'); ?>
                        </h2>
                        <div class="related-grid">
                            <?php while ($relatedPosts->next()): ?>
                                <?php $relatedCover = ziba_card_image($relatedPosts); ?>
                                <article class="related-card">
                                    <a class="related-cover" href="<?php $relatedPosts->permalink(); ?>" aria-hidden="true" tabindex="-1">
                                        <?php if ($relatedCover !== ''): ?>
                                            <img src="<?php echo htmlspecialchars($relatedCover, ENT_QUOTES, 'UTF-8'); ?>" alt="" loading="lazy" />
                                        <?php else: ?>
                                            <span class="card-cover-fallback" aria-hidden="true">
                                                <svg viewBox="0 0 48 48" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round">
                                                    <path d="M24 6 L28.5 18 L41 22.5 L28.5 27 L24 39 L19.5 27 L7 22.5 L19.5 18 Z"/>
                                                </svg>
                                            </span>
                                        <?php endif; ?>
                                    </a>
                                    <div class="related-body">
                                        <h3 class="related-title">
                                            <a href="<?php $relatedPosts->permalink(); ?>"><?php $relatedPosts->title(); ?></a>
                                        </h3>
                                        <time class="related-date" datetime="<?php echo date('c', (int) $relatedPosts->created); ?>"><?php echo ziba_date((int) $relatedPosts->created); ?></time>
                                    </div>
                                </article>
                            <?php endwhile; ?>
                        </div>
                    </section>
                <?php endif; ?>
            <?php endif; ?>

            <?php $this->need('comments.php'); ?>

        </div>

        <?php if ($showSidebar): ?>
            <?php $this->need('sidebar.php'); ?>
        <?php endif; ?>

    </div>
</div>

<?php $this->need('footer.php'); ?>
