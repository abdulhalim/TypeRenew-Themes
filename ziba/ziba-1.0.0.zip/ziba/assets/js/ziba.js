(function () {
    'use strict';

    var config = window.ZIBA || {};
    var doc = document;
    var html = doc.documentElement;

    function ready(fn) {
        if (doc.readyState !== 'loading') {
            fn();
        } else {
            doc.addEventListener('DOMContentLoaded', fn);
        }
    }

    /* ---------- ارقام فارسی ---------- */

    var FA_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

    function toFa(value) {
        value = String(value);
        var out = '';
        for (var i = 0; i < value.length; i++) {
            out += FA_DIGITS[+value.charAt(i)] || value.charAt(i);
        }
        return out;
    }

    function compactFa(value) {
        var text = (Math.round(value * 10) / 10).toFixed(1);
        if (text.slice(-2) === '.0') {
            text = text.slice(0, -2);
        }
        return toFa(text.replace('.', '٫'));
    }

    function formatCount(num) {
        num = parseInt(num, 10) || 0;
        if (num < 0) {
            num = 0;
        }
        if (num >= 1000000) {
            return compactFa(num / 1000000) + ' میلیون';
        }
        if (num >= 1000) {
            var thousands = num / 1000;
            if (thousands >= 1000) {
                return compactFa(thousands / 1000) + ' میلیون';
            }
            return compactFa(thousands) + ' هزار';
        }
        return toFa(num);
    }

    /* ---------- اعلان کوچک ---------- */

    var toast = doc.getElementById('ziba-toast');
    var toastTimer = null;

    function showToast(message) {
        if (!toast) {
            return;
        }
        toast.textContent = message;
        toast.classList.add('is-visible');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function () {
            toast.classList.remove('is-visible');
        }, 2600);
    }

    /* ---------- حالت روشن و تیره ---------- */

    var SUN_SVG = '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>';
    var MOON_SVG = '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>';

    function isDark() {
        return html.getAttribute('data-theme') === 'dark';
    }

    function updateThemeIcons() {
        var icons = doc.querySelectorAll('.theme-icon');
        for (var i = 0; i < icons.length; i++) {
            icons[i].innerHTML = isDark() ? SUN_SVG : MOON_SVG;
        }
    }

    function toggleTheme() {
        var next = isDark() ? 'light' : 'dark';
        doc.body.classList.add('theme-transition');
        html.setAttribute('data-theme', next);
        try {
            localStorage.setItem('ziba-theme', next);
        } catch (e) { /* noop */ }
        updateThemeIcons();
        setTimeout(function () {
            doc.body.classList.remove('theme-transition');
        }, 400);
    }

    /* ---------- پسند (لایک) با انفجار کامل ---------- */

    var HEART_PATH = 'M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z';
    var PARTICLE_COLORS = ['#B76E79', '#C98D93', '#D9A8A8', '#C9A86A', '#E4BBBF', '#9E5A66'];

    function heartSvg(size, filled) {
        return '<svg width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="' + (filled ? 'currentColor' : 'none') + '" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' + HEART_PATH + '"></path></svg>';
    }

    /** انفجار ذرات حول دکمه */
    function burstParticles(btn) {
        var count = 14;
        for (var i = 0; i < count; i++) {
            var p = doc.createElement('span');
            p.className = 'like-particle';
            var angle = (Math.PI * 2 * i) / count + (Math.random() * 0.6 - 0.3);
            var distance = 46 + Math.random() * 44;
            p.style.setProperty('--tx', (Math.cos(angle) * distance).toFixed(1) + 'px');
            p.style.setProperty('--ty', (Math.sin(angle) * distance - 16).toFixed(1) + 'px');
            var size = 5 + Math.round(Math.random() * 6);
            p.style.width = size + 'px';
            p.style.height = size + 'px';
            p.style.background = PARTICLE_COLORS[Math.floor(Math.random() * PARTICLE_COLORS.length)];
            if (Math.random() > 0.55) {
                p.style.borderRadius = '2px';
                p.style.transform = 'rotate(45deg)';
            }
            btn.appendChild(p);
            (function (el) {
                setTimeout(function () {
                    if (el.parentNode) {
                        el.parentNode.removeChild(el);
                    }
                }, 900);
            })(p);
        }
    }

    /** قلب‌های پرنده به بالا */
    function floatHearts(btn) {
        var count = 4;
        for (var i = 0; i < count; i++) {
            var f = doc.createElement('span');
            f.className = 'like-floater';
            f.innerHTML = heartSvg(14 + Math.round(Math.random() * 12), true);
            f.style.setProperty('--tx', (Math.random() * 72 - 36).toFixed(1) + 'px');
            f.style.animationDelay = (i * 0.14) + 's';
            f.style.color = PARTICLE_COLORS[i % PARTICLE_COLORS.length];
            btn.appendChild(f);
            (function (el) {
                setTimeout(function () {
                    if (el.parentNode) {
                        el.parentNode.removeChild(el);
                    }
                }, 1500 + i * 140);
            })(f);
        }
    }

    /** انیمیشن ضربان قلب روی دکمه */
    function animateLike(btn) {
        btn.classList.remove('is-animating');
        void btn.offsetWidth;
        btn.classList.add('is-animating');
        burstParticles(btn);
        floatHearts(btn);
    }

    /** قلب بزرگ روی تصویر نوشته (دو ضربه) */
    function popBigHeart(figure) {
        if (!figure) {
            return;
        }
        var heart = figure.querySelector('.post-hero-heart');
        if (heart) {
            heart.classList.remove('is-popped');
            void heart.offsetWidth;
            heart.classList.add('is-popped');
        }
    }

    function paintLikeButton(btn) {
        var countEl = btn.querySelector('.like-count');
        if (countEl) {
            countEl.textContent = formatCount(btn.getAttribute('data-likes'));
        }
        var liked = btn.getAttribute('data-liked') === '1';
        btn.classList.toggle('is-liked', liked);
        btn.setAttribute('aria-pressed', liked ? 'true' : 'false');
        var label = btn.querySelector('.like-label');
        if (label) {
            label.textContent = liked ? 'پسندیدی' : 'پسندیدم';
        }
    }

    var likeBusy = {};

    function sendLike(cid, btn) {
        if (likeBusy[cid]) {
            return;
        }
        likeBusy[cid] = true;

        var before = {
            likes: btn.getAttribute('data-likes'),
            liked: btn.getAttribute('data-liked')
        };
        var optimistic = btn.getAttribute('data-liked') === '1' ? -1 : 1;

        var all = doc.querySelectorAll('.like-btn[data-cid="' + cid + '"]');
        for (var i = 0; i < all.length; i++) {
            all[i].setAttribute('data-likes', String(Math.max(0, (parseInt(all[i].getAttribute('data-likes'), 10) || 0) + optimistic)));
            all[i].setAttribute('data-liked', optimistic > 0 ? '1' : '0');
            paintLikeButton(all[i]);
        }

        var body = new URLSearchParams();
        body.append('zibaLike', cid);

        fetch(config.siteUrl || '/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: body.toString(),
            credentials: 'same-origin'
        })
            .then(function (res) { return res.json(); })
            .then(function (data) {
                delete likeBusy[cid];
                if (!data || !data.ok) {
                    for (var j = 0; j < all.length; j++) {
                        all[j].setAttribute('data-likes', before.likes);
                        all[j].setAttribute('data-liked', before.liked);
                        paintLikeButton(all[j]);
                    }
                    showToast(config.toastLikeFail || 'ذخیرهٔ پسند ممکن نشد');
                    return;
                }
                for (var k = 0; k < all.length; k++) {
                    all[k].setAttribute('data-likes', String(data.likes));
                    all[k].setAttribute('data-liked', data.liked ? '1' : '0');
                    paintLikeButton(all[k]);
                }
            })
            .catch(function () {
                delete likeBusy[cid];
                for (var m = 0; m < all.length; m++) {
                    all[m].setAttribute('data-likes', before.likes);
                    all[m].setAttribute('data-liked', before.liked);
                    paintLikeButton(all[m]);
                }
                showToast(config.toastOffline || 'اتصال اینترنت را بررسی کنید');
            });
    }

    function likeNow(cid, btn) {
        var willLike = btn.getAttribute('data-liked') !== '1';
        sendLike(cid, btn);
        if (willLike) {
            animateLike(btn);
        }
    }

    /* ---------- دو ضربه روی تصویر نوشته = پسند ---------- */

    function bindDoubleTap(media) {
        var lastTap = 0;

        function handler(e) {
            if (e.target.closest && e.target.closest('.post-hero-heart')) {
                return;
            }
            var now = Date.now();
            if (now - lastTap < 350) {
                e.preventDefault();
                lastTap = 0;
                var article = media.closest('[data-cid]');
                var cid = article ? article.getAttribute('data-cid') : null;
                var btn = article ? article.querySelector('.like-btn[data-cid]') : null;

                popBigHeart(media);

                if (cid && btn) {
                    if (btn.getAttribute('data-liked') !== '1') {
                        likeNow(cid, btn);
                    }
                }
            } else {
                lastTap = now;
            }
        }

        media.addEventListener('click', handler);
    }

    /* ---------- لایت‌باکس با ناوبری ---------- */

    var lightbox = doc.getElementById('ziba-lightbox');
    var lightboxImg = lightbox ? lightbox.querySelector('.lightbox-img') : null;
    var lightboxCaption = lightbox ? lightbox.querySelector('.lightbox-caption') : null;
    var lightboxCounter = lightbox ? lightbox.querySelector('.lightbox-counter') : null;
    var lightboxPrev = lightbox ? lightbox.querySelector('.lightbox-prev') : null;
    var lightboxNext = lightbox ? lightbox.querySelector('.lightbox-next') : null;
    var lightboxCloseBtn = lightbox ? lightbox.querySelector('.lightbox-close') : null;
    var lightboxList = [];
    var lightboxIndex = 0;
    var lightboxLastFocus = null;
    var lightboxSwapTimer = null;

    /* فهرست تصاویرِ همان نوشته، به ترتیب سند */
    function lightboxItems(scope) {
        var imgs = (scope || doc).querySelectorAll('img');
        var list = [];
        for (var i = 0; i < imgs.length; i++) {
            if (!imgs[i].classList.contains('js-lightbox')) {
                continue;
            }
            var src = imgs[i].currentSrc || imgs[i].src;
            if (src) {
                list.push({ src: src, alt: imgs[i].alt || '' });
            }
        }
        return list;
    }

    function updateLightboxChrome() {
        if (!lightbox) {
            return;
        }
        var single = lightboxList.length < 2;
        if (lightboxPrev) {
            lightboxPrev.hidden = single;
        }
        if (lightboxNext) {
            lightboxNext.hidden = single;
        }
        if (lightboxCounter) {
            lightboxCounter.hidden = single;
            lightboxCounter.textContent = toFa(lightboxIndex + 1) + ' / ' + toFa(lightboxList.length);
        }
        if (lightboxCaption) {
            var item = lightboxList[lightboxIndex];
            var alt = item ? (item.alt || '') : '';
            lightboxCaption.textContent = alt;
            lightboxCaption.hidden = !alt;
        }
        /* پیش‌بارگذاری تصاویر همسایه */
        if (!single) {
            var len = lightboxList.length;
            new Image().src = lightboxList[(lightboxIndex + 1) % len].src;
            new Image().src = lightboxList[(lightboxIndex - 1 + len) % len].src;
        }
    }

    function showLightboxImage(item) {
        if (!lightboxImg || !item) {
            return;
        }
        lightboxImg.classList.add('is-fading');
        clearTimeout(lightboxSwapTimer);
        lightboxSwapTimer = setTimeout(function () {
            lightboxImg.src = item.src;
            lightboxImg.alt = item.alt || '';
            lightboxImg.classList.remove('is-fading');
        }, 110);
    }

    function stepLightbox(dir) {
        var len = lightboxList.length;
        if (!lightbox || lightbox.hidden || len < 2) {
            return;
        }
        lightboxIndex = (lightboxIndex + dir + len) % len;
        showLightboxImage(lightboxList[lightboxIndex]);
        updateLightboxChrome();
    }

    function openLightbox(list, index) {
        if (!lightbox || !lightboxImg || !list || !list.length) {
            return;
        }
        lightboxList = list;
        lightboxIndex = Math.max(0, Math.min(index || 0, list.length - 1));
        lightboxLastFocus = doc.activeElement;

        clearTimeout(lightboxSwapTimer);
        lightboxImg.classList.remove('is-fading');
        lightboxImg.src = list[lightboxIndex].src;
        lightboxImg.alt = list[lightboxIndex].alt || '';
        updateLightboxChrome();

        lightbox.hidden = false;
        requestAnimationFrame(function () {
            lightbox.classList.add('is-open');
        });
        doc.body.style.overflow = 'hidden';
        if (lightboxCloseBtn) {
            try {
                lightboxCloseBtn.focus();
            } catch (err) { /* noop */ }
        }
    }

    function closeLightbox() {
        if (!lightbox || lightbox.hidden) {
            return;
        }
        lightbox.classList.remove('is-open');
        doc.body.style.overflow = '';
        setTimeout(function () {
            lightbox.hidden = true;
        }, 320);
        if (lightboxLastFocus && lightboxLastFocus.focus) {
            try {
                lightboxLastFocus.focus();
            } catch (err) { /* noop */ }
            lightboxLastFocus = null;
        }
    }

    /* ---------- کپی لینک ---------- */

    function fallbackCopy(url) {
        var input = doc.createElement('textarea');
        input.value = url;
        input.style.position = 'fixed';
        input.style.opacity = '0';
        doc.body.appendChild(input);
        input.select();
        try {
            doc.execCommand('copy');
            showToast(config.toastCopied || 'کپی شد');
        } catch (err) {
            showToast(url);
        }
        doc.body.removeChild(input);
    }

    function copyLink(url) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(url).then(function () {
                showToast(config.toastCopied || 'کپی شد');
            }, function () {
                fallbackCopy(url);
            });
        } else {
            fallbackCopy(url);
        }
    }

    /* ---------- آواتار شکسته → حرف آغازین ---------- */

    function avatarFallback(img) {
        var wrap = img.closest('.avatar[data-avatar-initial]');

        if (!wrap) {
            var commentWrap = img.closest ? img.closest('.comment-avatar-wrap') : null;
            if (!commentWrap) {
                return;
            }
            var name = (img.getAttribute('alt') || '؟').trim();
            var hue = 0;
            for (var ci = 0; ci < name.length; ci++) {
                hue = (hue * 31 + name.charCodeAt(ci)) % 360;
            }
            var cspan = doc.createElement('span');
            cspan.className = 'avatar avatar-fallback';
            cspan.style.setProperty('--avatar-size', '48px');
            cspan.style.setProperty('--avatar-hue', String(hue));
            cspan.innerHTML = '<span>' + name.charAt(0) + '</span>';
            commentWrap.innerHTML = '';
            commentWrap.appendChild(cspan);
            return;
        }

        var span = doc.createElement('span');
        span.className = 'avatar avatar-fallback';
        span.style.setProperty('--avatar-size', wrap.style.getPropertyValue('--avatar-size') || '44px');
        span.style.setProperty('--avatar-hue', wrap.getAttribute('data-avatar-hue') || '330');
        span.setAttribute('aria-hidden', 'true');
        span.innerHTML = '<span>' + wrap.getAttribute('data-avatar-initial') + '</span>';
        if (wrap.parentNode) {
            wrap.parentNode.replaceChild(span, wrap);
        }
    }

    /* ---------- ظهور تدریجی عناصر ---------- */

    function initReveal() {
        var items = doc.querySelectorAll('.reveal');
        if (!('IntersectionObserver' in window)) {
            for (var i = 0; i < items.length; i++) {
                items[i].classList.add('is-in');
            }
            return;
        }

        var observer = new IntersectionObserver(function (entries) {
            for (var j = 0; j < entries.length; j++) {
                if (entries[j].isIntersecting) {
                    entries[j].target.classList.add('is-in');
                    observer.unobserve(entries[j].target);
                }
            }
        }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });

        for (var k = 0; k < items.length; k++) {
            observer.observe(items[k]);
        }
    }

    /* ---------- گالری تصاویر نوشته ---------- */

    /*
     * هر تصویری که به‌تنهایی روی یک «خط» ایستاده — چه با مارک‌داون
     * (![]())، چه با نشانیِ لخت تصویر (لینک خودکار یا متن ساده)، چه با
     * تگ HTML — پیدا می‌شود؛ لینک‌ها و نشانی‌های تصویری ابتدا به تگ
     * تصویر تبدیل می‌شوند و سپس تصاویر پشت‌سرهم، از قید پاراگراف‌ها
     * بیرون کشیده می‌شوند و کنار هم، در یک گرید گالری‌مانند می‌نشینند.
     */

    var IMG_EXT_RE = /\.(jpe?g|jpeg|png|gif|webp|avif|apng|bmp|svg|jfif|ico|heic)$/i;

    function isImageUrl(url) {
        if (!url) {
            return false;
        }
        var clean = String(url).trim().split(/[?#]/)[0];
        return IMG_EXT_RE.test(clean);
    }

    function fileTitle(url) {
        var name = String(url).split(/[?#]/)[0].split('/').pop() || '';
        try {
            name = decodeURIComponent(name);
        } catch (err) { /* noop */ }
        return name.replace(/\.[a-z0-9]+$/i, '') || 'تصویر';
    }

    /**
     * لینک‌هایی که نشانی‌شان به فایل تصویری می‌رسد — و متنِ لینک چیزی
     * جز خودِ نشانی (یا نام فایل) نیست — به تگ تصویر تبدیل می‌شوند.
     */
    function convertImageLinks(root) {
        var links = root.querySelectorAll('a[href]');
        for (var i = 0; i < links.length; i++) {
            var a = links[i];
            if (a.querySelector('img')) {
                continue;
            }
            var href = a.getAttribute('href') || '';
            if (!isImageUrl(href)) {
                continue;
            }
            var text = (a.textContent || '').trim();
            var bare = href.replace(/^https?:\/\//i, '').replace(/\/+$/, '');
            var textBare = text.replace(/^https?:\/\//i, '').replace(/\/+$/, '');
            if (text !== '' && textBare !== bare
                && textBare.indexOf(bare) === -1 && bare.indexOf(textBare) === -1) {
                /* متن دلخواه دارد؛ لینکِ متنی باقی می‌ماند */
                continue;
            }
            var img = doc.createElement('img');
            img.src = a.href;
            img.alt = a.title || fileTitle(href);
            if (a.parentNode) {
                a.parentNode.replaceChild(img, a);
            }
        }
    }

    /**
     * نشانی‌های تصویریِ لخت در متن — وقتی کلِ گرهٔ متنی فقط یک نشانیِ
     * کامل است — به تگ تصویر تبدیل می‌شوند.
     */
    function convertBareImageUrls(root) {
        var walker = doc.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false);
        var nodes = [];
        while (walker.nextNode()) {
            nodes.push(walker.currentNode);
        }
        for (var i = 0; i < nodes.length; i++) {
            var node = nodes[i];
            var parent = node.parentNode;
            if (!parent || !parent.tagName) {
                continue;
            }
            var tag = parent.tagName;
            if (tag === 'A' || tag === 'CODE' || tag === 'PRE' || tag === 'SCRIPT' || tag === 'STYLE') {
                continue;
            }
            var url = (node.nodeValue || '').trim();
            if (url === '' || !isImageUrl(url)) {
                continue;
            }
            /* فقط نشانی با طرح مشخص (http، https و…) یا مسیرِ مطلق نسبی */
            var src = url;
            if (/^www\./i.test(url)) {
                src = 'https://' + url;
            } else if (!/^[a-z][a-z0-9+.\-]*:\/\//i.test(url) && url.charAt(0) !== '/') {
                continue;
            }
            var img = doc.createElement('img');
            img.src = src;
            img.alt = fileTitle(url);
            parent.replaceChild(img, node);
        }
    }

    function isVisuallyEmpty(el) {
        if (!el || el.nodeType !== 1) {
            return false;
        }
        var tag = el.tagName;
        if (tag !== 'P' && tag !== 'DIV' && tag !== 'FIGURE') {
            return false;
        }
        if (el.getElementsByTagName('img').length > 0) {
            return false;
        }
        return (el.textContent || '').trim() === '';
    }

    function isImageBlock(el) {
        if (!el || el.nodeType !== 1) {
            return false;
        }
        var tag = el.tagName;
        if (tag === 'IMG') {
            /* تصویر لخت در متن (لینک مستقیم / HTML) */
            return true;
        }
        if (tag === 'A') {
            /* تصویرِ لینک‌شدهٔ لخت در سطح ریشه */
            return el.getElementsByTagName('img').length === 1 && (el.textContent || '').trim() === '';
        }
        if (tag !== 'P' && tag !== 'FIGURE' && tag !== 'DIV') {
            return false;
        }
        if ((el.textContent || '').trim() !== '') {
            /* متن هم دارد؛ بلوک تصویری خالص نیست */
            return false;
        }
        if (el.getElementsByTagName('img').length === 0) {
            return false;
        }
        var allowed = { IMG: 1, BR: 1, A: 1, SOURCE: 1, PICTURE: 1, SPAN: 1 };
        var inner = el.getElementsByTagName('*');
        for (var i = 0; i < inner.length; i++) {
            if (!allowed[inner[i].tagName]) {
                return false;
            }
            if (inner[i].tagName === 'A' && (inner[i].textContent || '').trim() !== '') {
                return false;
            }
        }
        return true;
    }

    function countImages(block) {
        return block.tagName === 'IMG' ? 1 : block.getElementsByTagName('img').length;
    }

    function collectImages(block) {
        if (block.tagName === 'IMG') {
            return [block];
        }
        return Array.prototype.slice.call(block.getElementsByTagName('img'));
    }

    function appendGalleryItem(gallery, img) {
        var item = doc.createElement('div');
        item.className = 'post-gallery-item';
        /* اگر تصویر داخل لینک است، خودِ لینک را منتقل می‌کنیم تا مقصد حفظ شود */
        var node = (img.parentNode && img.parentNode.tagName === 'A') ? img.parentNode : img;
        item.appendChild(node);
        gallery.appendChild(item);
    }

    function buildGalleries() {
        var roots = doc.querySelectorAll('.post-content');
        for (var r = 0; r < roots.length; r++) {
            var root = roots[r];

            /* ۱) لینک‌های تصویری و نشانی‌های لخت پیش از هر چیز به تصویر بدل شوند */
            convertImageLinks(root);
            convertBareImageUrls(root);

            var children = [];
            for (var c = 0; c < root.children.length; c++) {
                children.push(root.children[c]);
            }

            var i = 0;
            while (i < children.length) {
                if (!isImageBlock(children[i])) {
                    i++;
                    continue;
                }

                /* زنجیرهٔ پیوستهٔ بلوک‌های تصویری؛ بلوک‌های نامرئی گروه را نمی‌شکنند */
                var group = [];
                var j = i;
                while (j < children.length && (isImageBlock(children[j]) || isVisuallyEmpty(children[j]))) {
                    if (isImageBlock(children[j])) {
                        group.push(children[j]);
                    }
                    j++;
                }

                var imgCount = 0;
                for (var g = 0; g < group.length; g++) {
                    imgCount += countImages(group[g]);
                }

                if (imgCount >= 2) {
                    var gallery = doc.createElement('div');
                    gallery.className = 'post-gallery';
                    gallery.setAttribute('data-cols', String(Math.min(imgCount, 9)));
                    root.insertBefore(gallery, group[0]);

                    for (var m = 0; m < group.length; m++) {
                        var block = group[m];
                        var imgs = collectImages(block);
                        /* نخست بلوک از درخت جدا شود تا تصاویرِ خودِ بلوک (IMG لخت) پاک نشوند */
                        if (block.parentNode) {
                            block.parentNode.removeChild(block);
                        }
                        for (var q = 0; q < imgs.length; q++) {
                            appendGalleryItem(gallery, imgs[q]);
                        }
                    }

                    /* بلوک‌های نامرئیِ داخل بازه نیز پاک شوند */
                    for (var e = i; e < j; e++) {
                        var eb = children[e];
                        if (eb !== gallery && eb.parentNode && !isImageBlock(eb) && isVisuallyEmpty(eb)) {
                            eb.parentNode.removeChild(eb);
                        }
                    }
                }

                i = j;
            }
        }
    }

    /* ---------- راه‌اندازی ---------- */

    ready(function () {
        /* گالری‌سازی تصاویر پشت‌سرهم */
        buildGalleries();

        /* حالت تیره */
        updateThemeIcons();
        var switchBtns = doc.querySelectorAll('.theme-switch');
        for (var si = 0; si < switchBtns.length; si++) {
            switchBtns[si].addEventListener('click', toggleTheme);
        }

        var prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
        if (prefersDark.addEventListener) {
            prefersDark.addEventListener('change', function (e) {
                var stored = null;
                try {
                    stored = localStorage.getItem('ziba-theme');
                } catch (err) { /* noop */ }
                if (!stored) {
                    if (e.matches) {
                        html.setAttribute('data-theme', 'dark');
                    } else {
                        html.removeAttribute('data-theme');
                    }
                    updateThemeIcons();
                }
            });
        }

        /* سربرگ هنگام اسکرول */
        var header = doc.getElementById('site-header');
        var backBtn = doc.querySelector('.back-to-top');
        var progressWrap = null;
        var progressBar = null;

        if (config.progress) {
            progressWrap = doc.createElement('div');
            progressWrap.className = 'reading-progress';
            progressBar = doc.createElement('div');
            progressBar.className = 'reading-progress-bar';
            progressWrap.appendChild(progressBar);
            doc.body.appendChild(progressWrap);
        }

        var ticking = false;

        function onScroll() {
            if (ticking) {
                return;
            }
            ticking = true;
            window.requestAnimationFrame(function () {
                var y = window.pageYOffset || doc.documentElement.scrollTop;

                if (header) {
                    if (y > 10) {
                        header.classList.add('is-scrolled');
                    } else {
                        header.classList.remove('is-scrolled');
                    }
                }

                if (backBtn) {
                    if (y > 480) {
                        backBtn.classList.add('is-visible');
                    } else {
                        backBtn.classList.remove('is-visible');
                    }
                }

                if (progressBar) {
                    var total = doc.documentElement.scrollHeight - window.innerHeight;
                    var ratio = total > 0 ? Math.min(1, Math.max(0, y / total)) : 0;
                    progressBar.style.width = (ratio * 100).toFixed(2) + '%';
                }

                ticking = false;
            });
        }

        window.addEventListener('scroll', onScroll, { passive: true });
        onScroll();

        if (backBtn) {
            backBtn.addEventListener('click', function () {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }

        /* منوی موبایل */
        var navToggle = doc.querySelector('.js-nav-toggle');
        var nav = doc.querySelector('.main-nav');
        if (navToggle && nav) {
            navToggle.addEventListener('click', function () {
                var open = nav.classList.toggle('is-open');
                navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            });
        }

        /* جستجوی سربرگ */
        var searchToggle = doc.querySelector('.js-search-toggle');
        var searchBox = doc.querySelector('.js-header-search');
        var searchInput = searchBox ? searchBox.querySelector('.header-search-input') : null;
        var searchClose = doc.querySelector('.js-search-close');

        function openSearch() {
            if (!searchBox) {
                return;
            }
            searchBox.hidden = false;
            if (nav && nav.classList) {
                nav.classList.remove('is-open');
            }
            if (searchInput) {
                setTimeout(function () {
                    searchInput.focus();
                }, 60);
            }
        }

        function closeSearch() {
            if (searchBox) {
                searchBox.hidden = true;
            }
        }

        if (searchToggle) {
            searchToggle.addEventListener('click', function () {
                if (searchBox && searchBox.hidden) {
                    openSearch();
                } else {
                    closeSearch();
                }
            });
        }
        if (searchClose) {
            searchClose.addEventListener('click', closeSearch);
        }

        /* دکمه‌های پسند */
        var likeButtons = doc.querySelectorAll('.like-btn[data-cid]');
        for (var li = 0; li < likeButtons.length; li++) {
            paintLikeButton(likeButtons[li]);
            (function (btn) {
                btn.addEventListener('click', function (e) {
                    e.preventDefault();
                    likeNow(String(btn.getAttribute('data-cid')), btn);
                });
            })(likeButtons[li]);
        }

        /* دو ضربه روی تصویر نوشته */
        var mediaEls = doc.querySelectorAll('.post-hero');
        for (var mi = 0; mi < mediaEls.length; mi++) {
            bindDoubleTap(mediaEls[mi]);
        }

        /* کپی لینک */
        var copyBtns = doc.querySelectorAll('.js-copy-link');
        for (var ci = 0; ci < copyBtns.length; ci++) {
            (function (btn) {
                btn.addEventListener('click', function () {
                    copyLink(btn.getAttribute('data-url') || window.location.href);
                });
            })(copyBtns[ci]);
        }

        /* لایت‌باکس تصاویر نوشته — با ناوبری بین تصاویر همان نوشته */
        if (config.lightbox && lightbox && lightboxImg) {
            var contentImages = doc.querySelectorAll('.post-content img');
            for (var ii = 0; ii < contentImages.length; ii++) {
                (function (img) {
                    var link = img.closest ? img.closest('a') : null;
                    var href = link ? (link.getAttribute('href') || '') : '';
                    /* تصویری که به مقصدی غیرتصویری لینک شده را احترام می‌گذاریم */
                    if (link && href && !isImageUrl(href)) {
                        return;
                    }
                    img.classList.add('js-lightbox');
                    img.addEventListener('click', function (e) {
                        e.preventDefault();
                        var scope = img.closest('.post-content') || doc;
                        var list = lightboxItems(scope);
                        var src = img.currentSrc || img.src;
                        var idx = 0;
                        for (var k = 0; k < list.length; k++) {
                            if (list[k].src === src) {
                                idx = k;
                                break;
                            }
                        }
                        openLightbox(list, idx);
                    });
                })(contentImages[ii]);
            }

            if (lightboxCloseBtn) {
                lightboxCloseBtn.addEventListener('click', closeLightbox);
            }
            if (lightboxPrev) {
                lightboxPrev.addEventListener('click', function () {
                    stepLightbox(-1);
                });
            }
            if (lightboxNext) {
                lightboxNext.addEventListener('click', function () {
                    stepLightbox(1);
                });
            }
            lightbox.addEventListener('click', function (e) {
                if (e.target === lightbox) {
                    closeLightbox();
                }
            });

            /* کلیدها — راست‌به‌چپ: چپ یعنی بعدی، راست یعنی قبلی */
            doc.addEventListener('keydown', function (e) {
                if (!lightbox || lightbox.hidden) {
                    return;
                }
                if (e.key === 'Escape') {
                    e.preventDefault();
                    closeLightbox();
                } else if (e.key === 'ArrowLeft') {
                    e.preventDefault();
                    stepLightbox(1);
                } else if (e.key === 'ArrowRight') {
                    e.preventDefault();
                    stepLightbox(-1);
                }
            });

            /* کشیدن انگشت: به چپ یعنی بعدی، به راست یعنی قبلی */
            var touchStartX = null;
            var touchStartY = null;
            lightbox.addEventListener('touchstart', function (e) {
                if (e.touches.length === 1) {
                    touchStartX = e.touches[0].clientX;
                    touchStartY = e.touches[0].clientY;
                }
            }, { passive: true });
            lightbox.addEventListener('touchend', function (e) {
                if (touchStartX === null) {
                    return;
                }
                var dx = e.changedTouches[0].clientX - touchStartX;
                var dy = e.changedTouches[0].clientY - touchStartY;
                touchStartX = null;
                touchStartY = null;
                if (Math.abs(dx) > 44 && Math.abs(dx) > Math.abs(dy)) {
                    stepLightbox(dx < 0 ? 1 : -1);
                }
            }, { passive: true });
        }

        /* آواتار شکسته */
        window.addEventListener('error', function (e) {
            var img = e.target;
            if (img && img.tagName === 'IMG') {
                avatarFallback(img);
            }
        }, true);

        /* ظهور تدریجی */
        initReveal();
    });
})();
