<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$widgets = ziba_widgets('sidebarWidgets');
$showViews = ziba_on('showViews', '1');
?>

<aside class="sidebar" role="complementary" aria-label="<?php _e('ستون کناری'); ?>">

    <section class="widget widget-search">
        <h2 class="widget-title"><?php echo ziba_icon('search', 16); ?><?php _e('جستجو'); ?></h2>
        <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="widget-search-form">
            <input type="search" name="s" placeholder="<?php _e('جستجو در نوشته‌ها…'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" value="<?php echo htmlspecialchars((string) ($this->request->keywords ?? $this->request->s ?? ''), ENT_QUOTES, 'UTF-8'); ?>" />
            <button type="submit" aria-label="<?php _e('جستجو'); ?>"><?php echo ziba_icon('arrow-left', 16); ?></button>
        </form>
    </section>

    <?php if (in_array('recent', $widgets, true)): ?>
        <section class="widget widget-posts">
            <h2 class="widget-title"><?php echo ziba_icon('clock', 16); ?><?php _e('جدیدترین پست‌ها'); ?></h2>
            <?php ZibaRecentPosts::allocWithAlias('ziba-recent', ['pageSize' => 5])->to($recentPosts); ?>
            <?php if ($recentPosts->have()): ?>
                <ul class="widget-post-list">
                    <?php $i = 0; while ($recentPosts->next()): $i++; ?>
                        <?php $recentCover = ziba_card_image($recentPosts); ?>
                        <li class="widget-post-item">
                            <a href="<?php $recentPosts->permalink(); ?>" class="widget-post-link">
                                <span class="widget-post-num" aria-hidden="true"><?php echo ziba_fa((string) $i); ?></span>
                                <?php if ($recentCover !== ''): ?>
                                    <span class="widget-post-thumb"><img src="<?php echo htmlspecialchars($recentCover, ENT_QUOTES, 'UTF-8'); ?>" alt="" loading="lazy" /></span>
                                <?php endif; ?>
                                <span class="widget-post-info">
                                    <span class="widget-post-name"><?php $recentPosts->title(); ?></span>
                                    <time class="widget-post-date"><?php echo ziba_date((int) $recentPosts->created); ?></time>
                                </span>
                            </a>
                        </li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p class="widget-empty"><?php _e('هنوز نوشته‌ای منتشر نشده است.'); ?></p>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if (in_array('popular', $widgets, true)): ?>
        <section class="widget widget-posts widget-popular">
            <h2 class="widget-title"><?php echo ziba_icon('flame', 16); ?><?php _e('محبوب‌ترین پست‌ها'); ?></h2>
            <?php ZibaPopularPosts::allocWithAlias('ziba-popular', ['pageSize' => 5])->to($popularPosts); ?>
            <?php if ($popularPosts->have()): ?>
                <ul class="widget-post-list">
                    <?php $i = 0; while ($popularPosts->next()): $i++; ?>
                        <?php $popularCover = ziba_card_image($popularPosts); ?>
                        <li class="widget-post-item">
                            <a href="<?php $popularPosts->permalink(); ?>" class="widget-post-link">
                                <span class="widget-post-num" aria-hidden="true"><?php echo ziba_fa((string) $i); ?></span>
                                <?php if ($popularCover !== ''): ?>
                                    <span class="widget-post-thumb"><img src="<?php echo htmlspecialchars($popularCover, ENT_QUOTES, 'UTF-8'); ?>" alt="" loading="lazy" /></span>
                                <?php endif; ?>
                                <span class="widget-post-info">
                                    <span class="widget-post-name"><?php $popularPosts->title(); ?></span>
                                    <span class="widget-post-date">
                                        <?php if ($showViews): ?>
                                            <?php echo ziba_icon('eye', 12); ?> <?php echo ziba_format_count(ziba_views($popularPosts)); ?>
                                        <?php else: ?>
                                            <?php echo ziba_date((int) $popularPosts->created); ?>
                                        <?php endif; ?>
                                    </span>
                                </span>
                            </a>
                        </li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p class="widget-empty"><?php _e('هنوز نوشته‌ای منتشر نشده است.'); ?></p>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if (in_array('comments', $widgets, true)): ?>
        <?php $recentComments = ziba_recent_comments(5); ?>
        <?php if (!empty($recentComments)): ?>
            <section class="widget widget-comments">
                <h2 class="widget-title"><?php echo ziba_icon('comment', 16); ?><?php _e('آخرین دیدگاه‌ها'); ?></h2>
                <ul class="widget-comment-list">
                    <?php foreach ($recentComments as $comment): ?>
                        <?php
                            // متن دیدگاه — با کلیک روی آن به همان نوشته می‌رویم
                            $commentText = trim((string) $comment['text']);
                            if ($commentText === '') {
                                $commentText = _t('دیدگاهی بدون متن…');
                            }
                            $commentExcerpt = mb_substr($commentText, 0, 110, 'UTF-8') . (mb_strlen($commentText, 'UTF-8') > 110 ? '…' : '');
                        ?>
                        <li class="widget-comment-item">
                            <a class="widget-comment-link" href="<?php echo htmlspecialchars($comment['link'], ENT_QUOTES, 'UTF-8'); ?>" title="<?php echo htmlspecialchars($comment['title'], ENT_QUOTES, 'UTF-8'); ?>">
                                <?php echo $comment['avatar']; ?>
                                <span class="widget-comment-body">
                                    <span class="widget-comment-text"><?php echo htmlspecialchars($commentExcerpt, ENT_QUOTES, 'UTF-8'); ?></span>
                                    <span class="widget-comment-meta">
                                        <strong><?php echo htmlspecialchars($comment['author'], ENT_QUOTES, 'UTF-8'); ?></strong>
                                        <span class="widget-comment-on"><?php _e('در'); ?> «<?php echo htmlspecialchars($comment['title'], ENT_QUOTES, 'UTF-8'); ?>»</span>
                                    </span>
                                </span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </section>
        <?php endif; ?>
    <?php endif; ?>

    <?php if (in_array('tags', $widgets, true)): ?>
        <?php \Widget\Metas\Tag\Cloud::allocWithAlias('ziba-sidebar', ['ignoreZeroCount' => true, 'limit' => 24, 'sort' => 'count', 'desc' => true])->to($sidebarTags); ?>
        <?php if ($sidebarTags->have()): ?>
            <section class="widget widget-tags">
                <h2 class="widget-title"><?php echo ziba_icon('tag', 16); ?><?php _e('ابر برچسب‌ها'); ?></h2>
                <div class="tag-cloud">
                    <?php while ($sidebarTags->next()): ?>
                        <a class="tag-pill" href="<?php $sidebarTags->permalink(); ?>"><?php $sidebarTags->name(); ?></a>
                    <?php endwhile; ?>
                </div>
            </section>
        <?php endif; ?>
    <?php endif; ?>

</aside>
