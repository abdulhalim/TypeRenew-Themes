<?php

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/* ================================================================
 *  ابزارهای عمومی
 * ================================================================ */

/**
 * خواندن تنظیم پوسته با مقدار پیش‌فرض
 */
function ziba_opt(string $name, ?string $default = null): ?string
{
    $value = \Widget\Options::alloc()->{$name};
    return ($value === null || $value === '') ? $default : $value;
}

/**
 * آیا تنظیم روشن است؟ (۱ / yes)
 */
function ziba_on(string $name, string $default = '1'): bool
{
    return ((string) ziba_opt($name, $default)) === '1';
}

/**
 * تبدیل ارقام لاتین به فارسی
 */
function ziba_fa(?string $text): string
{
    return strtr((string) $text, [
        '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
        '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
    ]);
}

/**
 * خلاصه‌سازی اجتماعی اعداد با ارقام فارسی:
 * ۹۹۹ → ۹۹۹ / ۱۵۰۰ → ۱٫۵ هزار / ۱۲۰۰۰۰۰ → ۱٫۲ میلیون
 */
function ziba_format_count(int $num): string
{
    if ($num >= 1000000) {
        return ziba_compact(round($num / 1000000, 1)) . ' ' . _t('میلیون');
    }

    if ($num >= 1000) {
        $thousands = round($num / 1000, 1);
        if ($thousands >= 1000) {
            return ziba_compact(round($thousands / 1000, 1)) . ' ' . _t('میلیون');
        }
        return ziba_compact($thousands) . ' ' . _t('هزار');
    }

    return ziba_fa((string) max(0, $num));
}

/**
 * عدد اعشاری خلاصه با ارقام فارسی (۱٫۵ و نه ۱٫۰)
 */
function ziba_compact(float $value): string
{
    $text = number_format($value, 1, '.', '');
    if (substr($text, -2) === '.0') {
        $text = substr($text, 0, -2);
    }
    return ziba_fa(str_replace('.', '٫', $text));
}

/* ================================================================
 *  تاریخ شمسی
 * ================================================================ */

/**
 * تبدیل میلادی به جلالی — الگوریتم استاندارد
 *
 * @return array{0:int,1:int,2:int} [سال، ماه، روز]
 */
function ziba_to_jalali(int $gy, int $gm, int $gd): array
{
    $gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

    $jy = ($gy <= 1600) ? 0 : 979;
    $gy -= ($gy <= 1600) ? 621 : 1600;

    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = (365 * $gy)
        + intdiv($gy2 + 3, 4)
        - intdiv($gy2 + 99, 100)
        + intdiv($gy2 + 399, 400)
        - 80
        + $gd
        + $gdm[$gm - 1];

    $jy += 33 * intdiv($days, 12053);
    $days %= 12053;
    $jy += 4 * intdiv($days, 1461);
    $days %= 1461;

    if ($days > 365) {
        $jy += intdiv($days - 1, 365);
        $days = ($days - 1) % 365;
    }

    if ($days < 186) {
        $jm = 1 + intdiv($days, 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + intdiv($days - 186, 30);
        $jd = 1 + (($days - 186) % 30);
    }

    return [$jy, $jm, $jd];
}

/**
 * نام ماه‌های شمسی
 */
function ziba_jalali_months(): array
{
    return [
        1  => 'فروردین', 2  => 'اردیبهشت', 3 => 'خرداد',
        4  => 'تیر', 5  => 'مرداد', 6 => 'شهریور',
        7  => 'مهر', 8  => 'آبان', 9 => 'آذر',
        10 => 'دی', 11 => 'بهمن', 12 => 'اسفند',
    ];
}

/**
 * تاریخ کوتاه شمسی با ارقام فارسی: ۱۴۰۴/۰۶/۰۸
 */
function ziba_date(int $timestamp): string
{
    [$jy, $jm, $jd] = ziba_to_jalali((int) date('Y', $timestamp), (int) date('n', $timestamp), (int) date('j', $timestamp));

    return ziba_fa(sprintf('%04d/%02d/%02d', $jy, $jm, $jd));
}

/**
 * تاریخ بلند شمسی: ۸ شهریور ۱۴۰۴
 */
function ziba_date_long(int $timestamp): string
{
    [$jy, $jm, $jd] = ziba_to_jalali((int) date('Y', $timestamp), (int) date('n', $timestamp), (int) date('j', $timestamp));
    $months = ziba_jalali_months();

    return ziba_fa((string) $jd) . ' ' . $months[$jm] . ' ' . ziba_fa((string) $jy);
}

/**
 * نام روز هفته به فارسی
 */
function ziba_weekday(int $timestamp): string
{
    // 0=یکشنبه ... 6=شنبه (بر پایه w در PHP)
    $days = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
    return $days[(int) date('w', $timestamp)];
}

/**
 * تبدیل ارقام خروجی صفحه‌بندی به فارسی (نشانی لینک‌ها دست‌نخورده می‌ماند)
 */
function ziba_nav_fa(string $html): string
{
    return (string) preg_replace_callback(
        '/>([^<>]+)</u',
        function (array $matches): string {
            return '>' . ziba_fa($matches[1]) . '<';
        },
        $html
    );
}

/* ================================================================
 *  تصاویر
 * ================================================================ */

/**
 * اعتبار نشانی تصویر
 */
function ziba_image_ok(?string $url): bool
{
    $url = trim((string) $url);
    if ($url === '' || strlen($url) > 2048) {
        return false;
    }
    return (bool) preg_match('#^(https?://|/|data:image/)#i', $url);
}

/**
 * نرمال‌سازی نشانی (نسبی → مطلق)
 */
function ziba_resolve(?string $url): string
{
    $url = trim((string) $url);
    if ($url === '') {
        return '';
    }
    if (preg_match('#^(data:|https?://|//)#i', $url)) {
        return $url;
    }
    $base = rtrim((string) \Widget\Options::alloc()->siteUrl, '/');
    return $base . '/' . ltrim($url, '/');
}

/**
 * جدا کردن نشانی از آرگومان تصویر مارک‌داون
 */
function ziba_md_url(string $raw): string
{
    $raw = trim($raw);
    if ($raw === '') {
        return '';
    }
    if ($raw[0] === '<') {
        $end = strpos($raw, '>');
        return trim($end === false ? substr($raw, 1) : substr($raw, 1, $end - 1));
    }
    return rtrim(substr($raw, 0, strcspn($raw, " \t")));
}

/**
 * نخستین تصویر متن نوشته — تگ img، مارک‌داون درون‌خطی و ارجاعی
 */
function ziba_first_image(?string $text): string
{
    $text = str_replace("\r\n", "\n", (string) $text);
    if ($text === '') {
        return '';
    }

    $candidates = [];

    // ۱) تگ img در HTML
    if (preg_match_all('#<img\b[^>]*?(?<![\w-])src=["\']([^"\']+)["\']#i', $text, $m, PREG_OFFSET_CAPTURE)) {
        foreach ($m[1] as $hit) {
            $candidates[] = [$hit[1], $hit[0]];
        }
    }

    // ۲) مارک‌داون درون‌خطی ![alt](url)
    if (preg_match_all('#!\[[^\]\n]*\]\(\s*([^)\n]+)#', $text, $m, PREG_OFFSET_CAPTURE)) {
        foreach ($m[1] as $hit) {
            $candidates[] = [$hit[1], ziba_md_url($hit[0])];
        }
    }

    // ۳) مارک‌داون ارجاعی ![alt][label] با تعریف [label]: url
    if (preg_match_all('#!\[([^\]\n]*)\](?:\[([^\]\n]*)\])?(?!\()#', $text, $m, PREG_OFFSET_CAPTURE)) {
        $defs = [];
        if (preg_match_all('#^[ \t]{0,3}\[([^\]\n]+)\]:[ \t]*(<?[^\s>]+>?)#m', $text, $d)) {
            foreach ($d[1] as $i => $label) {
                $defs[strtolower(trim((string) $label))] = ziba_md_url((string) $d[2][$i]);
            }
        }
        foreach ($m[0] as $i => $hit) {
            $label = trim((string) $m[2][$i][0]) !== '' ? (string) $m[2][$i][0] : (string) $m[1][$i][0];
            $label = strtolower(trim($label));
            if ($label !== '' && isset($defs[$label])) {
                $candidates[] = [$hit[1], $defs[$label]];
            }
        }
    }

    if ($candidates === []) {
        return '';
    }

    usort($candidates, static function (array $a, array $b): int {
        return $a[0] <=> $b[0];
    });

    foreach ($candidates as $candidate) {
        $url = html_entity_decode(trim((string) $candidate[1]), ENT_QUOTES, 'UTF-8');
        if (ziba_image_ok($url)) {
            return $url;
        }
    }

    return '';
}

/**
 * تصویر شاخص نوشته — فقط فیلد سفارشی «thumb»؛
 * برای هرو صفحهٔ نوشته که بدون آن جای تصویر خالی می‌ماند.
 */
function ziba_thumbnail($archive): string
{
    if (isset($archive->fields) && $archive->fields instanceof \Typecho\Config) {
        $thumb = trim((string) ($archive->fields->thumb ?? ''));
        if (ziba_image_ok($thumb)) {
            return $thumb;
        }
    }

    // سازگاری با پوسته‌های دیگر (نگارین/پرنیان)
    foreach (['cover', 'thumbnail'] as $key) {
        $value = trim((string) ($archive->fields->{$key} ?? ''));
        if (ziba_image_ok($value)) {
            return $value;
        }
    }

    return '';
}

/**
 * تصویر کارت فهرست: تصویر شاخص ← نخستین تصویر متن ← تصویر پیش‌فرض تنظیمات
 */
function ziba_card_image($archive): string
{
    $thumb = ziba_thumbnail($archive);
    if ($thumb !== '') {
        return $thumb;
    }

    $first = ziba_first_image((string) $archive->text);
    if ($first !== '') {
        return $first;
    }

    $default = trim((string) ziba_opt('defaultCover'));
    if (ziba_image_ok($default)) {
        return ziba_resolve($default);
    }

    return '';
}

/* ================================================================
 *  متن و متاداده
 * ================================================================ */

/**
 * برآورد زمان مطالعه (دقیقه) — ۲۲۰ واژه در دقیقه
 */
function ziba_reading_time($content): int
{
    $text = (string) $content->text;
    $text = preg_replace('#```.*?```#s', ' ', $text) ?? $text;
    $text = preg_replace('#`[^`]*`#', ' ', $text) ?? $text;
    $text = preg_replace('#!\[[^\]]*\]\([^)]*\)#', ' ', $text) ?? $text;
    $text = preg_replace('#<[^>]+>#', ' ', $text) ?? $text;

    $words = preg_split('/\s+/u', trim($text), -1, PREG_SPLIT_NO_EMPTY);
    $count = is_array($words) ? count($words) : 0;

    if ($count === 0) {
        return 1;
    }

    return max(1, (int) ceil($count / 220));
}

/**
 * چکیدهٔ تمیز با احترام به مرز واژه‌ها
 */
function ziba_excerpt($content, int $words = 26): string
{
    $text = trim((string) $content->excerpt);
    if ($text === '') {
        $text = trim((string) $content->plainExcerpt);
    }

    $text = trim(preg_replace('/\s+/u', ' ', strip_tags($text)) ?? '');
    $parts = preg_split('/\s+/u', $text, $words + 1, PREG_SPLIT_NO_EMPTY);

    if (is_array($parts) && count($parts) > $words) {
        array_pop($parts);
        return implode(' ', $parts) . '…';
    }

    return $text;
}

/* ================================================================
 *  شمارش بازدید — ستون views جدول محتوا (هم‌راستا با نگارین و ViewsCounter)
 * ================================================================ */

/**
 * اطمینان از وجود ستون views
 */
function ziba_views_ready(): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }

    $ready = false;

    try {
        $db = \Typecho\Db::get();

        try {
            $db->fetchRow($db->select('table.contents.views')->from('table.contents')->limit(1));
            $columnExists = true;
        } catch (\Throwable $e) {
            $columnExists = false;
        }

        if (!$columnExists) {
            $prefix = $db->getPrefix();
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT DEFAULT 0');
        }

        $ready = true;
    } catch (\Throwable $e) {
        $ready = false;
    }

    return $ready;
}

/**
 * تعداد بازدید نوشته
 */
function ziba_views($archive): int
{
    try {
        return max(0, (int) $archive->views);
    } catch (\Throwable $e) {
        return 0;
    }
}

/**
 * شمارش بازدید صفحات تکی با فاصلهٔ ضد تکرار (کوکی)
 */
function ziba_count_view($archive): void
{
    // اگر پلاگین ViewsCounter فعال است، پوسته کنار می‌کشد
    $activated = \Widget\Options::alloc()->plugins;
    if (is_array($activated) && isset($activated['activated']['ViewsCounter'])) {
        return;
    }

    if (!ziba_on('countLoggedInViews', '0') && \Widget\User::alloc()->hasLogin()) {
        return;
    }

    if (!$archive instanceof \Widget\Archive || !$archive->is('single')) {
        return;
    }

    $cid = (int) $archive->cid;
    if ($cid < 1) {
        return;
    }

    $interval = (int) ziba_opt('viewsInterval', '3600');

    if ($interval > 0) {
        $viewed = (string) \Typecho\Cookie::get('zibaViews', '');
        $ids = $viewed === '' ? [] : explode(',', $viewed);

        if (in_array((string) $cid, $ids, true)) {
            return;
        }

        $ids[] = (string) $cid;
        if (count($ids) > 100) {
            $ids = array_slice($ids, -100);
        }

        \Typecho\Cookie::set('zibaViews', implode(',', $ids), time() + $interval);
    }

    if (!ziba_views_ready()) {
        return;
    }

    try {
        $db = \Typecho\Db::get();
        $db->query(
            $db->update('table.contents')
                ->expression('views', 'views + 1')
                ->where('cid = ?', $cid)
        );
    } catch (\Throwable $e) {
        // خطای شمارش نباید نمایش صفحه را متوقف کند
    }
}

/* ================================================================
 *  پسند (لایک) — ستون likes جدول محتوا + نقطهٔ پایانی AJAX
 * ================================================================ */

/**
 * اطمینان از وجود ستون likes
 */
function ziba_likes_ready(): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }

    $ready = false;

    try {
        $db = \Typecho\Db::get();

        try {
            $db->fetchRow($db->select('table.contents.likes')->from('table.contents')->limit(1));
            $columnExists = true;
        } catch (\Throwable $e) {
            $columnExists = false;
        }

        if (!$columnExists) {
            $prefix = $db->getPrefix();
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `likes` INT DEFAULT 0');
        }

        $ready = true;
    } catch (\Throwable $e) {
        $ready = false;
    }

    return $ready;
}

/**
 * تعداد پسند نوشته
 */
function ziba_likes($archive): int
{
    if (!ziba_likes_ready()) {
        return 0;
    }
    try {
        return max(0, (int) $archive->likes);
    } catch (\Throwable $e) {
        return 0;
    }
}

/**
 * شناسه‌های پسندیده‌شدهٔ این بازدیدکننده (کوکی zibaLikes)
 */
function ziba_user_likes(): array
{
    $raw = (string) \Typecho\Cookie::get('zibaLikes', '');
    if ($raw === '') {
        return [];
    }

    $ids = [];
    foreach (explode(',', $raw) as $id) {
        $id = trim($id);
        if ($id !== '' && ctype_digit($id) && !in_array($id, $ids, true)) {
            $ids[] = $id;
        }
    }
    return $ids;
}

/**
 * آیا این بازدیدکننده این نوشته را پسندیده؟
 */
function ziba_is_liked(int $cid): bool
{
    return $cid > 0 && in_array((string) $cid, ziba_user_likes(), true);
}

/**
 * خروجی JSON و پایان درخواست
 */
function ziba_json(array $payload, int $status = 200): void
{
    $response = \Typecho\Response::getInstance();
    $response->setStatus($status);
    $response->setContentType('application/json');
    $response->addResponder(function () use ($payload): void {
        echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    });
    $response->respond();
}

/**
 * پردازش درخواست پسند — POST با پارامتر zibaLike=<cid>
 * پاسخ: {"ok":true,"likes":N,"liked":bool}
 */
function ziba_handle_like($request): void
{
    $cid = (int) (string) $request->get('zibaLike');

    if ($cid < 1) {
        ziba_json(['ok' => false, 'error' => 'bad-request'], 400);
        return;
    }

    // جلوگیری ساده از CSRF
    $siteHost = (string) parse_url((string) \Widget\Options::alloc()->siteUrl, PHP_URL_HOST);
    $referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');
    if ($referer !== '' && $siteHost !== '' && stripos($referer, $siteHost) === false) {
        ziba_json(['ok' => false, 'error' => 'cross-origin'], 403);
        return;
    }

    if (!ziba_likes_ready()) {
        ziba_json(['ok' => false, 'error' => 'db-error'], 500);
        return;
    }

    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.type', 'table.contents.status', 'table.contents.password', 'table.contents.created')
                ->from('table.contents')
                ->where('table.contents.cid = ?', $cid)
        );

        $valid = is_array($row)
            && $row['status'] === 'publish'
            && in_array($row['type'], ['post', 'page'], true)
            && empty($row['password'])
            && (int) $row['created'] <= \Widget\Options::alloc()->time;

        if (!$valid) {
            ziba_json(['ok' => false, 'error' => 'not-found'], 404);
            return;
        }

        $likedIds = ziba_user_likes();
        $wasLiked = in_array((string) $cid, $likedIds, true);

        if ($wasLiked) {
            $likedIds = array_values(array_filter(
                $likedIds,
                static function (string $id) use ($cid): bool {
                    return $id !== (string) $cid;
                }
            ));
            $delta = -1;
        } else {
            $likedIds[] = (string) $cid;
            $delta = 1;
        }

        if (count($likedIds) > 200) {
            $likedIds = array_slice($likedIds, -200);
        }
        \Typecho\Cookie::set('zibaLikes', implode(',', $likedIds), time() + 31536000);

        $current = (int) $db->fetchObject(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        )->likes;

        if ($delta > 0 || $current > 0) {
            $db->query(
                $db->update('table.contents')
                    ->expression('likes', $delta > 0 ? 'likes + 1' : 'likes - 1')
                    ->where('table.contents.cid = ?', $cid)
            );
        }

        $newLikes = (int) $db->fetchObject(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        )->likes;

        ziba_json([
            'ok'    => true,
            'likes' => $newLikes,
            'liked' => !$wasLiked,
        ]);
    } catch (\Throwable $e) {
        ziba_json(['ok' => false, 'error' => 'server-error'], 500);
    }
}

/**
 * راه‌انداز پوسته — قلاب شمارش بازدید + نقطهٔ پایانی AJAX پسند
 */
function themeInit(\Widget\Archive $archive)
{
    \Typecho\Plugin::factory('Widget\Archive')->beforeRender = 'ziba_count_view';

    if ($archive->request->isPost() && $archive->request->is('zibaLike')) {
        ziba_handle_like($archive->request);
    }
}

/* ================================================================
 *  آمار کلی سایت
 * ================================================================ */

function ziba_stats(): array
{
    $posts = 0;
    $comments = 0;
    $views = 0;

    try {
        $db = \Typecho\Db::get();
        $posts = (int) $db->fetchObject(
            $db->select(['COUNT(table.contents.cid)' => 'num'])
                ->from('table.contents')
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.status = ?', 'publish')
        )->num;

        $comments = (int) $db->fetchObject(
            $db->select(['COUNT(table.comments.coid)' => 'num'])
                ->from('table.comments')
                ->where('table.comments.type = ?', 'comment')
                ->where('table.comments.status = ?', 'approved')
        )->num;

        if (ziba_views_ready()) {
            $views = (int) $db->fetchObject(
                $db->select(['COALESCE(SUM(table.contents.views), 0)' => 'total'])
                    ->from('table.contents')
                    ->where('table.contents.status = ?', 'publish')
            )->total;
        }
    } catch (\Throwable $e) {
        // خطای دیتابیس نباید سایت را از کار بیندازد
    }

    return ['posts' => $posts, 'comments' => $comments, 'views' => $views];
}

/* ================================================================
 *  ویجت‌های ستون کناری
 * ================================================================ */

if (!class_exists('ZibaRecentPosts')) {
    class ZibaRecentPosts extends \Widget\Base\Contents
    {
        public function execute()
        {
            $this->parameter->setDefault(['pageSize' => 5]);
            $limit = max(1, (int) $this->parameter->pageSize);

            $this->db->fetchAll($this->select()
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', $this->options->time)
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.password IS NULL OR table.contents.password = \'\'')
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit($limit), [$this, 'push']);
        }
    }
}

if (!class_exists('ZibaPopularPosts')) {
    class ZibaPopularPosts extends \Widget\Base\Contents
    {
        public function execute()
        {
            $this->parameter->setDefault(['pageSize' => 5]);
            $limit = max(1, (int) $this->parameter->pageSize);

            $basis = 'views';
            if (!ziba_views_ready()) {
                $basis = 'comments';
            } else {
                try {
                    $total = (int) $this->db->fetchObject(
                        $this->db->select(['COALESCE(SUM(table.contents.views), 0)' => 'total'])
                            ->from('table.contents')
                            ->where('table.contents.type = ?', 'post')
                            ->where('table.contents.status = ?', 'publish')
                    )->total;
                    if ($total < 1) {
                        $basis = 'comments';
                    }
                } catch (\Throwable $e) {
                    $basis = 'comments';
                }
            }

            $select = $this->select('table.contents.*')
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', $this->options->time)
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.password IS NULL OR table.contents.password = \'\'')
                ->order(
                    $basis === 'views' ? 'table.contents.views' : 'table.contents.commentsNum',
                    \Typecho\Db::SORT_DESC
                )
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit($limit);

            $this->db->fetchAll($select, [$this, 'push']);
        }
    }
}

/**
 * آخرین دیدگاه‌ها: متنِ خود دیدگاه + پیوند به نوشتهٔ مربوط
 */
function ziba_recent_comments(int $limit = 5): array
{
    $items = [];

    try {
        $db = \Typecho\Db::get();
        $prefix = $db->getPrefix();
        $rating = (string) (\Widget\Options::alloc()->commentsAvatarRating ?? 'g');

        // ستون‌های دیدگاه با نام مستعار انتخاب می‌شوند تا با ستون‌های همنامِ
        // نوشته (text، author، created و…) جای‌گذاری نشوند.
        $rows = $db->fetchAll(
            'SELECT c.coid, c.author AS commentAuthor, c.mail AS commentMail,'
            . ' c.text AS commentText, c.created AS commentCreated, t.*'
            . ' FROM `' . $prefix . 'comments` c'
            . ' LEFT JOIN `' . $prefix . 'contents` t ON t.cid = c.cid'
            . ' WHERE c.status = \'approved\' AND c.type = \'comment\''
            . ' AND t.status = \'publish\' AND t.type IN (\'post\', \'page\')'
            . ' ORDER BY c.created DESC LIMIT ' . max(1, $limit)
        );

        foreach ((array) $rows as $row) {
            if (!empty($row['password'])) {
                continue;
            }

            // نشانی نوشته از مسیریاب + لنگر خود دیدگاه
            $link = '#';
            try {
                $link = (string) \Typecho\Router::url($row['type'], $row, \Widget\Options::alloc()->siteUrl);
            } catch (\Throwable $e) {
                $link = '#';
            }
            $link .= '#comment-' . (int) $row['coid'];

            $name = (string) $row['commentAuthor'];
            $mail = trim((string) $row['commentMail']);

            // گراواتار با d=404؛ اگر حساب نباشد مرورگر به حرف آغازین برمی‌گردد
            $gravatar = '';
            if (filter_var($mail, FILTER_VALIDATE_EMAIL)) {
                try {
                    $gravatar = (string) \Typecho\Common::gravatarUrl($mail, 72, $rating, '404', true);
                } catch (\Throwable $e) {
                    $gravatar = '';
                }
            }

            if ($gravatar !== '') {
                $initial = mb_substr(trim($name) !== '' ? $name : '؟', 0, 1, 'UTF-8');
                $hue = abs(crc32($name)) % 360;
                $avatarHtml = '<span class="avatar widget-comment-avatar" style="--avatar-size:36px"'
                    . ' data-avatar-initial="' . htmlspecialchars($initial, ENT_QUOTES, 'UTF-8') . '"'
                    . ' data-avatar-hue="' . $hue . '">'
                    . '<img src="' . htmlspecialchars($gravatar, ENT_QUOTES, 'UTF-8') . '" alt="' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '" loading="lazy" referrerpolicy="no-referrer" />'
                    . '</span>';
            } else {
                $avatarHtml = ziba_avatar_html($name, null, 36, 'widget-comment-avatar');
            }

            $items[] = [
                'coid'    => (int) $row['coid'],
                'author'  => $name,
                'text'    => trim(strip_tags((string) $row['commentText'])),
                'created' => (int) $row['commentCreated'],
                'title'   => (string) $row['title'],
                'link'    => $link,
                'avatar'  => $avatarHtml,
            ];
        }
    } catch (\Throwable $e) {
        // بی‌خطر
    }

    return $items;
}

/* ================================================================
 *  سایدبار — نمایش در کدام صفحه‌ها؟
 * ================================================================ */

/**
 * آیا ستون کناری در این صفحه نمایش داده شود؟
 */
function ziba_show_sidebar($archive): bool
{
    if ($archive->is('index')) {
        return ziba_on('sidebarIndex', '1');
    }

    if ($archive->is('single')) {
        return ziba_on('sidebarPost', '1');
    }

    // دسته، برچسب، جستجو، نویسنده و آرشیو
    return ziba_on('sidebarArchive', '0');
}

/**
 * انتخاب ویجت‌های فعال از تنظیمات (چک‌باکس)
 */
function ziba_widgets(string $key): array
{
    $selected = \Widget\Options::alloc()->{$key} ?? null;

    if (!is_array($selected)) {
        // پیش‌فرض: همه فعال
        return ['recent', 'popular', 'comments', 'tags'];
    }

    $valid = [];
    foreach (['recent', 'popular', 'comments', 'tags'] as $widget) {
        if (in_array($widget, $selected, true)) {
            $valid[] = $widget;
        }
    }

    return $valid;
}

/**
 * آمارهای انتخاب‌شده برای نمایش در هیرو (نوشته/بازدید/دیدگاه)
 */
function ziba_hero_stats(): array
{
    $selected = \Widget\Options::alloc()->heroStats ?? null;

    if (!is_array($selected)) {
        // پیش‌فرض: هر سه آمار
        return ['posts', 'views', 'comments'];
    }

    $valid = [];
    foreach (['posts', 'views', 'comments'] as $stat) {
        if (in_array($stat, $selected, true)) {
            $valid[] = $stat;
        }
    }

    return $valid;
}

/**
 * پترن پس‌زمینهٔ هیرو برای حالت بدون تصویر
 * فقط وقتی به کار می‌آید که «تصویر هیرو» خالی باشد.
 */
function ziba_hero_pattern(): string
{
    $pattern = (string) ziba_opt('heroPattern', 'arabesque');

    if (!in_array($pattern, ['arabesque', 'dots', 'grid', 'waves', 'hex', 'diagonal', 'none'], true)) {
        $pattern = 'arabesque';
    }

    return $pattern;
}

/* ================================================================
 *  مهارت‌ها و علاقه‌مندی‌های صفحهٔ «درباره من»
 * ================================================================ */

/**
 * تبدیل ارقام فارسی/عربی به لاتین
 */
function ziba_en_digits(?string $text): string
{
    return strtr((string) $text, [
        '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
        '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
        '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
        '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
    ]);
}

/**
 * مقدار پیش‌فرض مهارت‌ها (نمونه) — هر خط: «نام | سطح ۰ تا ۱۰۰»
 */
function ziba_about_skills_default(): string
{
    return "برنامه‌نویسی PHP | 90\nتوسعهٔ وب (HTML/CSS/JS) | 85\nمدیریت سیستم‌های محتوا | 80\nنویسندگی و تولید محتوا | 75\nعکاسی و طراحی گرافیک | 65";
}

/**
 * خواندن مهارت‌های صفحهٔ درباره من
 *
 * @return array<int, array{name:string, level:?int}>
 */
function ziba_about_skills(): array
{
    $raw = (string) ziba_opt('aboutSkills', ziba_about_skills_default());
    $out = [];

    foreach (preg_split('/\r\n|\r|\n/', $raw) ?: [] as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }

        $parts = array_map('trim', explode('|', $line, 2));
        $name = $parts[0];
        if ($name === '') {
            continue;
        }

        $level = null;
        if (isset($parts[1]) && $parts[1] !== '') {
            $num = ziba_en_digits($parts[1]);
            if ($num !== '' && preg_match('/^\d{1,3}$/', $num)) {
                $level = max(5, min(100, (int) $num));
            }
        }

        $out[] = ['name' => $name, 'level' => $level];
    }

    return $out;
}

/**
 * خواندن علاقه‌مندی‌های صفحهٔ درباره من (جدا با کاما)
 *
 * @return array<int, string>
 */
function ziba_about_interests(): array
{
    $raw = (string) ziba_opt('aboutInterests', 'عکاسی, کتاب, موسیقی, کوه‌نوردی, تکنولوژی');
    $out = [];

    foreach (explode(',', $raw) as $tag) {
        $tag = trim($tag);
        if ($tag !== '') {
            $out[] = $tag;
        }
    }

    return array_slice($out, 0, 12);
}

/* ================================================================
 *  آیکون‌های خطی
 * ================================================================ */

function ziba_icon(string $name, int $size = 18): string
{
    $paths = [
        'heart'     => '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>',
        'comment'   => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>',
        'eye'       => '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle>',
        'share'     => '<circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>',
        'search'    => '<circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line>',
        'moon'      => '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>',
        'sun'       => '<circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>',
        'home'      => '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline>',
        'arrow-up'  => '<line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline>',
        'arrow-left' => '<line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline>',
        'arrow-right' => '<line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline>',
        'chevron-left' => '<polyline points="15 18 9 12 15 6"></polyline>',
        'chevron-right' => '<polyline points="9 18 15 12 9 6"></polyline>',
        'tag'       => '<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line>',
        'clock'     => '<circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline>',
        'user'      => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle>',
        'folder'    => '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>',
        'flame'     => '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"></path>',
        'calendar'  => '<rect x="3" y="4" width="18" height="18" rx="2.5"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line>',
        'sparkle'   => '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"></path><path d="M19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9z"></path>',
        'mail'      => '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline>',
        'feed'      => '<path d="M4 11a9 9 0 0 1 9 9"></path><path d="M4 4a16 16 0 0 1 16 16"></path><circle cx="5" cy="19" r="1"></circle>',
        'link'      => '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>',
        'close'     => '<line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>',
        'menu'      => '<line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line>',
        'camera'    => '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle>',
        'telegram'  => '<path d="M21.9 4.6l-3.1 14.7c-.2 1-.8 1.3-1.7.8l-4.7-3.5-2.3 2.2c-.25.25-.47.47-.94.47l.33-4.8L18.2 6.6c.37-.33-.08-.52-.58-.19L6.9 13.7l-4.6-1.44c-1-.31-1-1 .21-1.48L20.6 3.1c.83-.3 1.56.2 1.3 1.5z" fill="currentColor" stroke="none"></path>',
        'github'    => '<path d="M12 .5A11.5 11.5 0 0 0 .5 12a11.5 11.5 0 0 0 7.86 10.91c.58.11.79-.25.79-.56v-2.17c-3.2.7-3.87-1.36-3.87-1.36-.53-1.34-1.28-1.7-1.28-1.7-1.05-.72.08-.7.08-.7 1.16.08 1.77 1.19 1.77 1.19 1.03 1.77 2.7 1.26 3.36.96.1-.75.4-1.26.73-1.55-2.55-.29-5.23-1.28-5.23-5.68 0-1.26.45-2.28 1.19-3.09-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.17 1.18a11 11 0 0 1 5.77 0c2.2-1.49 3.16-1.18 3.16-1.18.63 1.59.24 2.76.12 3.05.74.81 1.18 1.83 1.18 3.09 0 4.41-2.68 5.38-5.24 5.67.41.35.78 1.05.78 2.11v3.13c0 .31.2.68.8.56A11.5 11.5 0 0 0 23.5 12 11.5 11.5 0 0 0 12 .5z" fill="currentColor" stroke="none"></path>',
        'instagram' => '<rect x="2.5" y="2.5" width="19" height="19" rx="5"></rect><circle cx="12" cy="12" r="4.5"></circle><circle cx="17.8" cy="6.2" r="1.1" fill="currentColor" stroke="none"></circle>',
        'linkedin'  => '<path d="M4.98 3.5C4.98 4.88 3.87 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1s2.48 1.12 2.48 2.5zM.22 8.1h4.56V23H.22V8.1zM8.34 8.1h4.37v2.03h.06c.61-1.15 2.1-2.37 4.32-2.37 4.62 0 5.47 3.04 5.47 7v8.24h-4.55v-7.3c0-1.74-.03-3.98-2.43-3.98-2.43 0-2.8 1.9-2.8 3.85V23H8.34V8.1z" fill="currentColor" stroke="none"></path>',
        'rss'       => '<path d="M6.18 15.64a2.18 2.18 0 1 1 0 4.36 2.18 2.18 0 0 1 0-4.36zM4 4.44v2.83c7.03 0 12.73 5.7 12.73 12.73h2.83c0-8.59-6.97-15.56-15.56-15.56zm0 5.66v2.83c3.9 0 7.07 3.17 7.07 7.07h2.83c0-5.47-4.43-9.9-9.9-9.9z" fill="currentColor" stroke="none"></path>',
    ];

    $path = $paths[$name] ?? $paths['sparkle'];

    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
}

/* ================================================================
 *  آواتار — تصویر یا حرف آغازین روی گرادیان رزگلد
 * ================================================================ */

function ziba_avatar_html(string $name, ?string $url = null, int $size = 44, string $extra = ''): string
{
    $url = trim((string) $url);
    $cls = 'avatar' . ($extra !== '' ? ' ' . $extra : '');

    if ($url !== '' && preg_match('#^(https?://|/)#i', $url)) {
        return '<span class="' . $cls . '" style="--avatar-size:' . $size . 'px">'
            . '<img src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" alt="' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '" loading="lazy" />'
            . '</span>';
    }

    $initial = mb_substr(trim($name) !== '' ? $name : '؟', 0, 1, 'UTF-8');
    $hue = abs(crc32($name)) % 360;

    return '<span class="' . $cls . ' avatar-fallback" style="--avatar-size:' . $size . 'px;--avatar-hue:' . $hue . '" aria-hidden="true">'
        . '<span>' . htmlspecialchars($initial, ENT_QUOTES, 'UTF-8') . '</span>'
        . '</span>';
}

/**
 * آواتار نویسنده: تنظیم پوسته ← گراواتار ← حرف آغازین
 */
function ziba_author_avatar($archive, int $size = 44): string
{
    $name = (string) $archive->author->screenName;

    $custom = trim((string) ziba_opt('authorAvatar'));
    if (ziba_image_ok($custom)) {
        return ziba_avatar_html($name, ziba_resolve($custom), $size);
    }

    $mail = trim((string) ($archive->author->mail ?? ''));
    if (filter_var($mail, FILTER_VALIDATE_EMAIL)) {
        // گراواتار با d=404 تا نبودِ حساب به حرف آغازین بیفتد (در مرورگر)
        $rating = (string) (\Widget\Options::alloc()->commentsAvatarRating ?? 'g');
        $url = \Typecho\Common::gravatarUrl($mail, $size * 2, $rating, '404', true);
        $initial = mb_substr(trim($name) !== '' ? $name : '؟', 0, 1, 'UTF-8');
        $hue = abs(crc32($name)) % 360;

        return '<span class="avatar" style="--avatar-size:' . $size . 'px"'
            . ' data-avatar-initial="' . htmlspecialchars($initial, ENT_QUOTES, 'UTF-8') . '"'
            . ' data-avatar-hue="' . $hue . '">'
            . '<img src="' . $url . '" alt="' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '" loading="lazy" referrerpolicy="no-referrer" />'
            . '</span>';
    }

    return ziba_avatar_html($name, null, $size);
}

/* ================================================================
 *  تنظیمات پوسته (پیشخوان ← ظاهر ← تنظیمات پوسته)
 * ================================================================ */

function themeConfig($form)
{
    $yes = _t('نمایش');
    $no = _t('پنهان');

    /* ---------- هویت و ظاهر ---------- */

    $logoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'logoUrl',
        null,
        null,
        _t('نشانی لوگوی سایت'),
        _t('در صورت خالی‌بودن، نام سایت با فونت وزیرمتن و نشان زیبا نمایش داده می‌شود.')
    );
    $form->addInput($logoUrl->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $colorSchema = new \Typecho\Widget\Helper\Form\Element\Select(
        'colorSchema',
        [
            'light' => _t('روشن (پیشنهادی)'),
            'dark'  => _t('تیره'),
            'auto'  => _t('خودکار (پیروی از سیستم کاربر)'),
        ],
        'light',
        _t('حالت رنگی پیش‌فرض'),
        _t('بازدیدکننده می‌تواند با دکمهٔ ماه/خورشید در سربرگ، حالت را عوض کند.')
    );
    $form->addInput($colorSchema);

    /* ---------- هیرو صفحهٔ اصلی ---------- */

    $heroShow = new \Typecho\Widget\Helper\Form\Element\Radio(
        'heroShow',
        ['1' => $yes, '0' => $no],
        '1',
        _t('بخش هیرو صفحهٔ اصلی'),
        _t('نمایش سرصفحهٔ بزرگ تصویری در بالای صفحهٔ نخست.')
    );
    $form->addInput($heroShow);

    $heroTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'heroTitle',
        null,
        null,
        _t('عنوان هیرو'),
        _t('در صورت خالی‌بودن، عنوان سایت نمایش داده می‌شود.')
    );
    $form->addInput($heroTitle);

    $heroSubtitle = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'heroSubtitle',
        null,
        null,
        _t('زیرعنوان هیرو'),
        _t('یک جملهٔ خوشامد یا معرفی وبلاگ؛ در صورت خالی‌بودن، توضیحات سایت نمایش داده می‌شود.')
    );
    $form->addInput($heroSubtitle);

    $heroImage = new \Typecho\Widget\Helper\Form\Element\Text(
        'heroImage',
        null,
        null,
        _t('تصویر هیرو'),
        _t('نشانی تصویر پس‌زمینهٔ هیرو (عرض پیشنهادی: ۱۶۰۰ پیکسل). اگر خالی بماند، گرادیان رزگلد-سرمه‌ای نمایش داده می‌شود.')
    );
    $form->addInput($heroImage->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $heroPattern = new \Typecho\Widget\Helper\Form\Element\Select(
        'heroPattern',
        [
            'arabesque' => _t('گره‌چینی ایرانی (پیشنهادی)'),
            'dots'      => _t('نقطه‌چین'),
            'grid'      => _t('شبکه‌ای'),
            'waves'     => _t('موجی'),
            'hex'       => _t('لانه‌زنبوری'),
            'diagonal'  => _t('خطوط مورب'),
            'none'      => _t('بدون پترن (فقط گرادیان)'),
        ],
        'arabesque',
        _t('پترن پس‌زمینهٔ هیرو بدون تصویر'),
        _t('وقتی «تصویر هیرو» خالی باشد، این پترن به‌صورت لطیف روی گرادیان سرمه‌ای نقش می‌بندد تا هیرو خالی و بی‌روح نباشد و متن سفید هم خوانا بماند. در حالت تصویر‌دار هیچ اثری ندارد.')
    );
    $form->addInput($heroPattern);

    $heroHeight = new \Typecho\Widget\Helper\Form\Element\Select(
        'heroHeight',
        [
            'short'  => _t('کوتاه'),
            'medium' => _t('متوسط (پیشنهادی)'),
            'tall'   => _t('بلند'),
        ],
        'medium',
        _t('ارتفاع هیرو'),
        _t('بلندی بخش هیرو در بالای صفحهٔ نخست.')
    );
    $form->addInput($heroHeight);

    $heroStats = new \Typecho\Widget\Helper\Form\Element\Checkbox(
        'heroStats',
        [
            'posts'    => _t('شمار نوشته‌ها'),
            'views'    => _t('شمار بازدید'),
            'comments' => _t('شمار دیدگاه‌ها'),
        ],
        ['posts', 'views', 'comments'],
        _t('آمار در هیرو'),
        _t('هر آمار را که انتخاب کنید در بخش هیرو صفحهٔ نخست نمایش داده می‌شود. همین آمار در پانوشت هم موجود است؛ اگر پانوشت کافی است، تیک‌ها را بردارید تا هیرو ساده‌تر شود.')
    );
    $form->addInput($heroStats);

    /* ---------- چیدمان فهرست نوشته‌ها ---------- */

    $postCardStyle = new \Typecho\Widget\Helper\Form\Element\Select(
        'postCardStyle',
        [
            'grid' => _t('کارت شبکه‌ای (تصویر بالای متن)'),
            'list' => _t('ردیفی (تصویر کنار متن)'),
        ],
        'grid',
        _t('چیدمان کارت‌های صفحهٔ نخست'),
        _t('در نمایشگرهای کوچک هر دو حالت تک‌ستونی می‌شوند. صفحات جستجو، دسته، برچسب و آرشیو به‌صورت خودکار فهرست مینیمال‌تری دارند.')
    );
    $form->addInput($postCardStyle);

    $defaultCover = new \Typecho\Widget\Helper\Form\Element\Text(
        'defaultCover',
        null,
        null,
        _t('تصویر پیش‌فرض کارت‌ها'),
        _t('برای نوشته‌های بدون تصویر شاخص و بدون تصویر در متن؛ اگر خالی بماند، قاب گرادیانی تزئینی نمایش داده می‌شود.')
    );
    $form->addInput($defaultCover->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    /* ---------- ستون کناری ---------- */

    $sidebarIndex = new \Typecho\Widget\Helper\Form\Element\Radio(
        'sidebarIndex',
        ['1' => $yes, '0' => $no],
        '1',
        _t('ستون کناری در صفحهٔ نخست'),
        _t('نمایش ستون کناری در صفحهٔ اصلی (ایندکس).')
    );
    $form->addInput($sidebarIndex);

    $sidebarArchive = new \Typecho\Widget\Helper\Form\Element\Radio(
        'sidebarArchive',
        ['1' => $yes, '0' => $no],
        '0',
        _t('ستون کناری در دسته/برچسب/جستجو/آرشیو'),
        _t('نمایش ستون کناری در صفحات فهرستی دیگر.')
    );
    $form->addInput($sidebarArchive);

    $sidebarPost = new \Typecho\Widget\Helper\Form\Element\Radio(
        'sidebarPost',
        ['1' => $yes, '0' => $no],
        '1',
        _t('ستون کناری در صفحهٔ نوشته و برگه'),
        _t('نمایش ستون کناری در صفحات تکی.')
    );
    $form->addInput($sidebarPost);

    $sidebarWidgets = new \Typecho\Widget\Helper\Form\Element\Checkbox(
        'sidebarWidgets',
        [
            'recent'   => _t('جدیدترین پست‌ها'),
            'popular'  => _t('محبوب‌ترین پست‌ها'),
            'comments' => _t('آخرین دیدگاه‌ها'),
            'tags'     => _t('ابر برچسب‌ها'),
        ],
        ['recent', 'popular', 'comments', 'tags'],
        _t('ویجت‌های ستون کناری'),
        _t('هر ویجت را که انتخاب کنید در ستون کناری نمایش داده می‌شود؛ برداشتن تیک، آن را پنهان می‌کند.')
    );
    $form->addInput($sidebarWidgets);

    /* ---------- بازدید و پسند ---------- */

    $showViews = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showViews',
        ['1' => $yes, '0' => $no],
        '1',
        _t('شمارندهٔ بازدید'),
        _t('نمایش تعداد بازدید نوشته‌ها در کارت‌ها و صفحهٔ نوشته؛ آمار در دیتابیس ذخیره می‌شود.')
    );
    $form->addInput($showViews);

    $showLikes = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showLikes',
        ['1' => $yes, '0' => $no],
        '1',
        _t('دکمهٔ پسندیدن (لایک)'),
        _t('نمایش دکمهٔ قلب با افکت انفجار ذرات هنگام پسندیدن؛ دو ضربه روی تصویر نوشته هم آن را می‌پسندد.')
    );
    $form->addInput($showLikes);

    $countLoggedInViews = new \Typecho\Widget\Helper\Form\Element\Radio(
        'countLoggedInViews',
        ['0' => _t('شمرده نشود (پیشنهادی)'), '1' => _t('شمرده شود')],
        '0',
        _t('بازدید کاربران واردشده'),
        _t('آمار بازدید مدیر و اعضای واردشده ثبت شود یا نه.')
    );
    $form->addInput($countLoggedInViews);

    $viewsInterval = new \Typecho\Widget\Helper\Form\Element\Select(
        'viewsInterval',
        [
            '3600'   => _t('۱ ساعت (پیشنهادی)'),
            '21600'  => _t('۶ ساعت'),
            '86400'  => _t('۲۴ ساعت'),
            '0'      => _t('بدون فاصله؛ هر بازدید شمرده شود'),
        ],
        '3600',
        _t('فاصلهٔ شمارش بازدید مکرر'),
        _t('بازدید تکراری یک نوشته در این بازه فقط یک بار شمرده می‌شود.')
    );
    $form->addInput($viewsInterval);

    /* ---------- صفحهٔ نوشته ---------- */

    $showReadingTime = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showReadingTime',
        ['1' => $yes, '0' => $no],
        '1',
        _t('زمان مطالعه و نوار پیشرفت'),
        _t('نمایش برآورد دقیقهٔ مطالعه در کارت‌ها و نوار پیشرفت خواندن در بالای صفحهٔ نوشته.')
    );
    $form->addInput($showReadingTime);

    $showRelated = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showRelated',
        ['1' => $yes, '0' => $no],
        '1',
        _t('مطالب مرتبط'),
        _t('در پایان هر نوشته، سه نوشتهٔ مرتبط بر پایهٔ برچسب‌ها نمایش داده می‌شود.')
    );
    $form->addInput($showRelated);

    $enableLightbox = new \Typecho\Widget\Helper\Form\Element\Radio(
        'enableLightbox',
        ['1' => $yes, '0' => $no],
        '1',
        _t('لایت‌باکس تصاویر'),
        _t('با کلیک روی تصاویر داخل متن نوشته، تصویر در حالت تمام‌صفحه بزرگ‌نمایی می‌شود.')
    );
    $form->addInput($enableLightbox);

    $showAuthorBox = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showAuthorBox',
        ['1' => $yes, '0' => $no],
        '1',
        _t('باکس نویسنده'),
        _t('نمایش کارت نویسنده با توضیحات در پایین هر نوشته.')
    );
    $form->addInput($showAuthorBox);

    $authorAvatar = new \Typecho\Widget\Helper\Form\Element\Text(
        'authorAvatar',
        null,
        null,
        _t('آواتار نویسنده'),
        _t('نشانی تصویر نویسنده برای باکس نویسنده؛ خالی بماند تا گراواتار یا حرف آغازین نام نمایش داده شود.')
    );
    $form->addInput($authorAvatar->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $authorBio = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'authorBio',
        null,
        null,
        _t('توضیحات نویسنده'),
        _t('چند جمله دربارهٔ نویسنده برای باکس پایین نوشته‌ها؛ خالی بماند تا توضیحات سایت نمایش داده شود.')
    );
    $form->addInput($authorBio);

    /* ---------- صفحهٔ «درباره من» ---------- */

    $aboutImage = new \Typecho\Widget\Helper\Form\Element\Text(
        'aboutImage',
        null,
        null,
        _t('تصویر بزرگ صفحهٔ «درباره من»'),
        _t('نشانی تصویر بزرگ صفحهٔ اختصاصی درباره من (پوستهٔ صفحهٔ «درباره من» را هنگام ساخت برگه انتخاب کنید).')
    );
    $form->addInput($aboutImage->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $aboutRole = new \Typecho\Widget\Helper\Form\Element\Text(
        'aboutRole',
        null,
        null,
        _t('عنوان شغلی صفحهٔ درباره من'),
        _t('مثلاً: نویسنده، عکاس، توسعه‌دهنده…')
    );
    $form->addInput($aboutRole);

    $aboutSkills = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'aboutSkills',
        null,
        ziba_about_skills_default(),
        _t('مهارت‌های صفحهٔ درباره من'),
        _t('هر خط یک مهارت؛ نام و سطح را با «|» جدا کنید (سطح از ۰ تا ۱۰۰). مثال: برنامه‌نویسی PHP | 90 — اگر سطح ننویسید، فقط نام نمایش داده می‌شود.')
    );
    $form->addInput($aboutSkills);

    $aboutInterests = new \Typecho\Widget\Helper\Form\Element\Text(
        'aboutInterests',
        null,
        'عکاسی, کتاب, موسیقی, کوه‌نوردی, تکنولوژی',
        _t('علاقه‌مندی‌های صفحهٔ درباره من'),
        _t('چند مورد را با کاما جدا کنید؛ به‌صورت برچسب نمایش داده می‌شود. مثال: عکاسی, کتاب, موسیقی')
    );
    $form->addInput($aboutInterests);

    /* ---------- شبکه‌های اجتماعی ---------- */

    $socialTelegram = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialTelegram', null, null, _t('نشانی تلگرام'), _t('مثال: https://t.me/example')
    );
    $form->addInput($socialTelegram->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $socialGithub = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialGithub', null, null, _t('نشانی گیت‌هاب'), _t('مثال: https://github.com/example')
    );
    $form->addInput($socialGithub->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $socialInstagram = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialInstagram', null, null, _t('نشانی اینستاگرام'), _t('مثال: https://instagram.com/example')
    );
    $form->addInput($socialInstagram->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $socialLinkedin = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialLinkedin', null, null, _t('نشانی لینکدین'), _t('مثال: https://linkedin.com/in/example')
    );
    $form->addInput($socialLinkedin->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    /* ---------- فوتر ---------- */

    $footerText = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'footerText',
        null,
        null,
        _t('متن دلخواه فوتر'),
        _t('در صورت خالی‌بودن، توضیحات سایت نمایش داده می‌شود.')
    );
    $form->addInput($footerText);
}

/* ================================================================
 *  فیلد اختصاصی «تصویر شاخص» در ویرایشگر
 * ================================================================ */

function themeFields($layout)
{
    $thumb = new \Typecho\Widget\Helper\Form\Element\Text(
        'thumb',
        null,
        null,
        _t('تصویر شاخص'),
        _t('نشانی تصویر شاخص این نوشته. در صفحهٔ نوشته بالای عنوان می‌نشیند و در کارت‌های فهرست به‌عنوان کاور به کار می‌رود؛ اگر خالی بماند، نخستین تصویر متن برای کارت استفاده می‌شود و جای تصویر در صفحهٔ نوشته خالی می‌ماند.')
    );
    $layout->addItem($thumb);
}

/* ================================================================
 *  ساختار دیدگاه‌ها
 * ================================================================ */

function threadedComments($comments, $options)
{
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
    ?>
    <li id="li-<?php $comments->theId(); ?>" class="comment-item<?php
        if ($comments->levels > 0) {
            echo ' comment-child';
            $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
        } else {
            echo ' comment-parent';
        }
        $comments->alt(' comment-odd', ' comment-even');
        echo $commentClass;
    ?>">
        <div id="<?php $comments->theId(); ?>" class="comment-inner">
            <div class="comment-avatar-wrap">
                <?php $comments->gravatar('48', 'mp', true); ?>
            </div>
            <div class="comment-main">
                <div class="comment-meta">
                    <cite class="comment-author" itemprop="creator" itemscope itemtype="http://schema.org/Person">
                        <?php $comments->author(); ?>
                        <?php if ($comments->authorId && $comments->authorId == $comments->ownerId): ?>
                            <span class="comment-badge-owner"><?php _e('نویسنده'); ?></span>
                        <?php endif; ?>
                    </cite>
                    <span class="comment-time">
                        <a href="<?php $comments->permalink(); ?>" itemprop="url">
                            <time datetime="<?php echo date('c', (int) $comments->created); ?>" itemprop="commentTime"><?php echo ziba_date((int) $comments->created); ?></time>
                        </a>
                    </span>
                    <?php if ($comments->status == 'waiting'): ?>
                        <span class="comment-badge-waiting"><?php _e('در انتظار تأیید'); ?></span>
                    <?php endif; ?>
                    <span class="comment-reply">
                        <?php $comments->reply(_t('پاسخ')); ?>
                    </span>
                </div>
                <div class="comment-content" itemprop="commentText">
                    <?php $comments->content(); ?>
                </div>
            </div>
        </div>
        <?php if ($comments->children) { ?>
            <div class="comment-children">
                <?php $comments->threadedComments($options); ?>
            </div>
        <?php } ?>
    </li>
    <?php
}
