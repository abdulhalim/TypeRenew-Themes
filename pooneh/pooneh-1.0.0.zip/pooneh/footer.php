<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
</main>

<footer class="site-footer" role="contentinfo">
    <div class="container">

        <?php $footerBio = trim((string) poonehOpt('authorBio')); ?>
        <?php $siteAuthor = poonehSiteAuthorInfo(); ?>
        <section class="footer-about">
            <div class="footer-about-avatar" aria-hidden="true"><?php echo poonehSiteAuthorAvatar(72); ?></div>
            <div class="footer-about-main">
                <p class="footer-about-role"><?php _e('دربارهٔ من'); ?></p>
                <h2 class="footer-about-name"><?php echo htmlspecialchars($siteAuthor['name'] !== '' ? $siteAuthor['name'] : (string) $this->options->title, ENT_QUOTES, 'UTF-8'); ?></h2>
                <?php if ($footerBio !== ''): ?>
                    <p class="footer-about-bio"><?php echo htmlspecialchars($footerBio, ENT_QUOTES, 'UTF-8'); ?></p>
                <?php else: ?>
                    <p class="footer-about-bio"><?php _e('به وبلاگم خوش اومدی؛ این‌جا مکانه برای نوشتن خاطره‌ها و چیزهایی که دوست دارم.'); ?></p>
                <?php endif; ?>
            </div>
        </section>

        <div class="footer-inner">
            <div class="footer-brand">
                <a class="footer-title" href="<?php $this->options->siteUrl(); ?>">
                    <span class="footer-title-mark" aria-hidden="true"><?php echo poonehSprigSvg(16); ?></span>
                    <span><?php $this->options->title(); ?></span>
                </a>
                <p class="footer-desc"><?php echo htmlspecialchars((string) $this->options->description, ENT_QUOTES, 'UTF-8'); ?></p>
                <?php $footerText = trim((string) poonehOpt('footerText')); ?>
                <?php if ($footerText !== ''): ?>
                    <p class="footer-custom-text"><?php echo htmlspecialchars($footerText, ENT_QUOTES, 'UTF-8'); ?></p>
                <?php endif; ?>
            </div>

            <?php
                $socials = [
                    'telegram'  => [(string) poonehOpt('socialTelegram'), _t('تلگرام')],
                    'instagram' => [(string) poonehOpt('socialInstagram'), _t('اینستاگرام')],
                    'youtube'   => [(string) poonehOpt('socialYoutube'), _t('یوتیوب')],
                    'github'    => [(string) poonehOpt('socialGithub'), _t('گیت‌هاب')],
                ];
                $hasSocial = false;
                foreach ($socials as $item) {
                    if ($item[0] !== '') { $hasSocial = true; break; }
                }
            ?>
            <?php if ($hasSocial): ?>
            <nav class="footer-social" aria-label="<?php _e('شبکه‌های اجتماعی'); ?>">
                <?php if ($socials['telegram'][0] !== ''): ?>
                    <a class="social-btn" href="<?php echo htmlspecialchars($socials['telegram'][0], ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" title="<?php echo _t('تلگرام'); ?>">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.9 4.6l-3.1 14.7c-.2 1-.8 1.3-1.7.8l-4.7-3.5-2.3 2.2c-.25.25-.47.47-.94.47l.33-4.8L18.2 6.6c.37-.33-.08-.52-.58-.19L6.9 13.7l-4.6-1.44c-1-.31-1-1 .21-1.48L20.6 3.1c.83-.3 1.56.2 1.3 1.5z"/></svg>
                    </a>
                <?php endif; ?>
                <?php if ($socials['instagram'][0] !== ''): ?>
                    <a class="social-btn" href="<?php echo htmlspecialchars($socials['instagram'][0], ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" title="<?php echo _t('اینستاگرام'); ?>">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
                    </a>
                <?php endif; ?>
                <?php if ($socials['youtube'][0] !== ''): ?>
                    <a class="social-btn" href="<?php echo htmlspecialchars($socials['youtube'][0], ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" title="<?php echo _t('یوتیوب'); ?>">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.5 12 3.5 12 3.5s-7.5 0-9.4.6A3 3 0 0 0 .5 6.2 31.3 31.3 0 0 0 0 12a31.3 31.3 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.1c1.9.6 9.4.6 9.4.6s7.5 0 9.4-.6a3 3 0 0 0 2.1-2.1A31.3 31.3 0 0 0 24 12a31.3 31.3 0 0 0-.5-5.8zM9.6 15.6V8.4L15.8 12z"/></svg>
                    </a>
                <?php endif; ?>
                <?php if ($socials['github'][0] !== ''): ?>
                    <a class="social-btn" href="<?php echo htmlspecialchars($socials['github'][0], ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener" title="<?php echo _t('گیت‌هاب'); ?>">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.11.79-.25.79-.55 0-.27-.01-1.17-.02-2.12-3.2.7-3.88-1.36-3.88-1.36-.52-1.33-1.28-1.68-1.28-1.68-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.18 1.76 1.18 1.03 1.76 2.69 1.25 3.35.96.1-.75.4-1.25.72-1.54-2.55-.29-5.24-1.28-5.24-5.68 0-1.26.45-2.28 1.18-3.09-.12-.29-.51-1.46.11-3.05 0 0 .96-.31 3.15 1.18a10.9 10.9 0 0 1 5.74 0c2.19-1.49 3.15-1.18 3.15-1.18.62 1.59.23 2.76.11 3.05.73.81 1.18 1.83 1.18 3.09 0 4.41-2.69 5.38-5.25 5.67.41.35.77 1.05.77 2.12 0 1.53-.01 2.76-.01 3.14 0 .3.2.67.8.55A11.52 11.52 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5z"/></svg>
                    </a>
                <?php endif; ?>
            </nav>
            <?php endif; ?>

            <div class="footer-meta">
                <p>&copy; <?php echo poonehFa(date('Y')); ?> <a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title(); ?></a> · <?php _e('ساخته‌شده با'); ?> <span class="footer-heart" aria-hidden="true"><?php echo poonehIcon('heart', 12); ?></span></p>
                <p><?php _e('قدرت‌گرفته از'); ?> <a href="https://www.typerenew.ir" rel="nofollow">TypeRenew</a> · <?php _e('پوستهٔ پونه'); ?></p>
            </div>
        </div>

        <div class="footer-wave" aria-hidden="true">
            <svg viewBox="0 0 1200 44" preserveAspectRatio="none">
                <path d="M0 22 C 100 -6, 200 44, 300 22 S 500 -6, 600 22 S 800 44, 900 22 S 1100 -6, 1200 22 L 1200 44 L 0 44 Z"></path>
            </svg>
        </div>
    </div>
</footer>

<button type="button" id="back-to-top" class="back-to-top" aria-label="<?php _e('برگشت به بالای صفحه'); ?>" title="<?php _e('برو بالا'); ?>">
    <?php echo poonehIcon('up', 18); ?>
</button>

<div class="toast" id="toast" role="status" aria-live="polite"></div>

<?php $this->footer(); ?>

<?php
    // پیکربندی جاوااسکریپت پوسته
    $poonehBubbles = (string) poonehOpt('bubbleStyle', 'minimal');
    if ($poonehBubbles === 'soft') {
        $poonehBubbles = 'minimal';
    }
    if (!in_array($poonehBubbles, ['minimal', 'bubbles', 'none'], true)) {
        $poonehBubbles = 'minimal';
    }

    $poonehJsConfig = [
        'bubbles' => $poonehBubbles,
        'likes'   => ((string) poonehOpt('enableLikes', '1')) === '1',
        'strings' => [
            'copyOk'      => _t('لینک نوشته کپی شد!'),
            'copyFail'    => _t('کپی لینک ممکن نشد.'),
            'likeOk'      => _t('پسندت ثبت شد؛ مرسی که اینجا بودی!'),
            'likeAlready' => _t('این نوشته رو قبلاً پسندیدی!'),
            'likeFail'    => _t('ثبت پسند ممکن نشد؛ دوباره امتحان کن.'),
        ],
    ];
    echo '<script>window.POONEH = ' . json_encode($poonehJsConfig, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) . ';</script>' . "\n";
?>
<script src="<?php $this->options->themeUrl('assets/js/main.js'); ?>" defer></script>

</body>
</html>
