<?php
/**
 * پونه — پوستهٔ دخترانهٔ مینیمال و شاد
 *
 * @package پونه
 * @author پوردریایی
 * @version 1.0.0
 * @link https://pourdaryaei.ir
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$isHome = $this->is('index');
$heroCardEnabled = $isHome && $this->currentPage <= 1;
?>

<?php if (!$isHome): ?>
    <div class="archive-banner reveal">
        <div class="archive-banner-inner">
            <span class="archive-banner-icon" aria-hidden="true">
                <?php if ($this->is('search')): ?>
                    <?php echo poonehIcon('search', 24); ?>
                <?php elseif ($this->is('category')): ?>
                    <?php echo poonehIcon('folder', 24); ?>
                <?php elseif ($this->is('tag')): ?>
                    <?php echo poonehIcon('tag', 24); ?>
                <?php else: ?>
                    <?php echo poonehIcon('user', 24); ?>
                <?php endif; ?>
            </span>
            <h1 class="archive-banner-title">
                <?php $this->archiveTitle([
                    'category' => _t('%s'),
                    'search'   => _t('%s'),
                    'tag'      => _t('%s'),
                    'author'   => _t('%s')
                ], '', ''); ?>
            </h1>
            <?php if ($this->getDescription()): ?>
                <p class="archive-banner-desc"><?php $this->getDescription(); ?></p>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<div class="layout layout-single">

    <div class="layout-primary">

        <?php if ($this->have()): ?>

            <?php if ($heroCardEnabled): ?>
                <?php poonehRenderHeroCard($this); ?>
                <?php if ($this->length > 1): ?>
                    <div class="posts-heading reveal">
                        <h2 class="posts-heading-title"><?php _e('نوشته‌های بعدی'); ?></h2>
                        <span class="posts-heading-dots" aria-hidden="true">
                            <span></span><span></span><span></span>
                        </span>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <div class="posts-grid">
                <?php
                    $postIndex = 0;
                    while ($this->next()):
                        // نخستین نوشته در صفحهٔ نخست، خودش کارت بزرگ است
                        if ($heroCardEnabled && $postIndex === 0):
                            $postIndex++;
                            continue;
                        endif;
                        $postIndex++;
                        poonehRenderCard($this);
                    endwhile;
                ?>
            </div>

            <nav class="pagination-area" aria-label="<?php _e('صفحه‌بندی'); ?>">
                <?php
                    ob_start();
                    $this->pageNav(
                        poonehIcon('chevron-right', 16),
                        poonehIcon('chevron-left', 16),
                        2,
                        '…'
                    );
                    echo poonehNavDigits((string) ob_get_clean());
                ?>
            </nav>

            <?php if ($isHome && $this->currentPage <= 1): ?>
                <?php poonehRenderPopularSection(); ?>
            <?php endif; ?>

        <?php else: ?>

            <div class="empty-state reveal">
                <div class="empty-state-ornament" aria-hidden="true">
                    <?php echo poonehSprigSvg(64); ?>
                </div>
                <h2 class="empty-state-title"><?php _e('اینجا هنوز خالیه!'); ?></h2>
                <p class="empty-state-text">
                    <?php $this->archiveTitle([
                        'category' => _t('هنوز در دستهٔ «%s» نوشته‌ای منتشر نشده.'),
                        'search'   => _t('چیزی برای «%s» پیدا نشد؛ یه عبارت دیگه امتحان کن.'),
                        'tag'      => _t('هنوز نوشته‌ای با برچسب «%s» منتشر نشده.'),
                        'author'   => _t('هنوز %s نوشته‌ای منتشر نکرده.')
                    ], '', ''); ?>
                </p>
                <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="empty-search-form">
                    <input type="search" name="s" placeholder="<?php _e('مثلاً: دستور پخت کیک'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" required />
                    <button type="submit"><?php _e('جستجو'); ?></button>
                </form>
                <a class="btn-primary" href="<?php $this->options->siteUrl(); ?>">
                    <span><?php _e('برگرد خونه'); ?></span>
                    <?php echo poonehIcon('arrow-left', 16); ?>
                </a>
            </div>

        <?php endif; ?>

    </div>

</div>

<?php $this->need('footer.php'); ?>
