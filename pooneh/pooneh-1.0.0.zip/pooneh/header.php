<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php $this->archiveTitle([
            'category' => _t('نوشته‌های دستهٔ «%s»'),
            'search'   => _t('نتایج جستجو برای «%s»'),
            'tag'      => _t('نوشته‌های برچسب «%s»'),
            'author'   => _t('نوشته‌های %s')
        ], '', ' — '); ?><?php $this->options->title(); ?></title>

    <?php
        // حالت رنگی پیش‌فرض — پیشگیری از پرش رنگ هنگام بارگذاری (anti-FOUC)
        $defaultSchema = (string) ($this->options->colorSchema ?? 'auto');
        $defaultSchemaJson = \Typecho\Common::jsonEncode(
            $defaultSchema,
            JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP,
            '"auto"'
        );

        // پالت رنگی
        $palettePreset = (string) ($this->options->palettePreset ?? 'candy');
        if (!in_array($palettePreset, ['candy', 'bubblegum', 'lavender'], true)) {
            $palettePreset = 'candy';
        }

        // سبک پس‌زمینه — پیش‌فرض: نقطه‌های ریز مینیمال (مقدار قدیمی soft هم به مینیمال تبدیل می‌شود)
        $bubbleStyle = (string) ($this->options->bubbleStyle ?? 'minimal');
        if ($bubbleStyle === 'soft') {
            $bubbleStyle = 'minimal';
        }
        if (!in_array($bubbleStyle, ['minimal', 'bubbles', 'none'], true)) {
            $bubbleStyle = 'minimal';
        }
        echo "<script>
            (function() {
                var stored = null;
                try {
                    stored = localStorage.getItem('pooneh-theme');
                } catch (e) {
                    stored = null;
                }
                var def = {$defaultSchemaJson};
                var isDark = false;
                if (stored === 'dark' || stored === 'light') {
                    isDark = (stored === 'dark');
                } else if (def === 'dark') {
                    isDark = true;
                } else if (def === 'auto' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                    isDark = true;
                }
                if (isDark) {
                    document.documentElement.setAttribute('data-theme', 'dark');
                }
            })();
        </script>";
    ?>

    <link rel="icon" type="image/svg+xml" href="<?php $this->options->themeUrl('assets/img/favicon.svg'); ?>">
    <link rel="stylesheet" href="<?php $this->options->themeUrl('style.css'); ?>">
    <?php $this->header(); ?>
</head>
<body class="palette-<?php echo htmlspecialchars($palettePreset, ENT_QUOTES, 'UTF-8'); ?> bubbles-<?php echo htmlspecialchars($bubbleStyle, ENT_QUOTES, 'UTF-8'); ?>">

<div class="reading-progress" aria-hidden="true"><span class="reading-progress-bar"></span></div>

<!-- لایهٔ حباب‌های شناور پس‌زمینه -->
<div class="bubbles-layer" id="bubbles-layer" aria-hidden="true"></div>

<header class="site-header" id="site-header">
    <div class="container header-inner">
        <div class="site-branding">
            <?php if ($this->options->logoUrl): ?>
                <a class="site-logo" href="<?php $this->options->siteUrl(); ?>">
                    <img src="<?php $this->options->logoUrl() ?>" alt="<?php $this->options->title() ?>"/>
                </a>
            <?php else: ?>
                <a class="site-title" href="<?php $this->options->siteUrl(); ?>">
                    <span class="site-title-mark" aria-hidden="true"><?php echo poonehSprigSvg(22); ?></span>
                    <span><?php $this->options->title() ?></span>
                </a>
            <?php endif; ?>
        </div>

        <nav class="site-nav" aria-label="<?php _e('ناوبری اصلی'); ?>">
            <input type="checkbox" id="nav-toggle" class="nav-toggle-input" aria-label="<?php _e('گشودن ناوبری'); ?>">
            <label for="nav-toggle" class="nav-toggle-label" aria-hidden="true">
                <span class="nav-toggle-bar"></span>
                <span class="nav-toggle-bar"></span>
                <span class="nav-toggle-bar"></span>
            </label>
            <ul class="nav-menu" role="menubar">
                <li role="none"><a role="menuitem" <?php if ($this->is('index')): ?> class="active"<?php endif; ?> href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a></li>
                <?php
                    // دسته‌های انتخاب‌شده برای نمایش در فهرست اصلی (تنظیمات پوسته)
                    // — بعد از «خانه» و قبل از صفحات ثابت
                    $menuCatIds = [];
                    if (is_array($this->options->menuCategories ?? null)) {
                        foreach ((array) $this->options->menuCategories as $menuCatId) {
                            $menuCatIds[] = (string) $menuCatId;
                        }
                    }
                ?>
                <?php if (!empty($menuCatIds)): ?>
                    <?php \Widget\Metas\Category\Rows::alloc()->to($menuCategories); ?>
                    <?php while ($menuCategories->next()): ?>
                        <?php if (in_array((string) $menuCategories->mid, $menuCatIds, true)): ?>
                            <li role="none"><a role="menuitem" <?php if ($this->is('category', $menuCategories->slug)): ?> class="active"<?php endif; ?> href="<?php $menuCategories->permalink(); ?>"><?php $menuCategories->name(); ?></a></li>
                        <?php endif; ?>
                    <?php endwhile; ?>
                <?php endif; ?>
                <?php \Widget\Contents\Page\Rows::alloc()->to($pages); ?>
                <?php while ($pages->next()): ?>
                    <li role="none"><a role="menuitem" <?php if ($this->is('page', $pages->slug)): ?> class="active"<?php endif; ?> href="<?php $pages->permalink(); ?>"><?php $pages->title(); ?></a></li>
                <?php endwhile; ?>
            </ul>
        </nav>

        <div class="header-actions">
            <button type="button" id="search-toggle" class="header-icon-btn" aria-label="<?php _e('جستجو'); ?>" title="<?php _e('جستجو'); ?>">
                <?php echo poonehIcon('search', 18); ?>
            </button>
            <button type="button" id="theme-switch" class="header-icon-btn" aria-label="<?php _e('تغییر حالت روشن و تیره'); ?>" title="<?php _e('تغییر حالت روشن و تیره'); ?>">
                <span class="theme-icon theme-icon-moon" aria-hidden="true"><?php echo poonehIcon('moon', 18); ?></span>
                <span class="theme-icon theme-icon-sun" aria-hidden="true"><?php echo poonehIcon('sun', 18); ?></span>
            </button>
            <label for="nav-toggle" class="header-icon-btn nav-burger" aria-hidden="true">
                <?php echo poonehIcon('menu', 18); ?>
            </label>
        </div>
    </div>
</header>

<!-- پوشش جستجوی تمام‌صفحه -->
<div class="search-overlay" id="search-overlay" aria-hidden="true">
    <div class="search-overlay-backdrop" data-search-close></div>
    <div class="search-overlay-panel" role="dialog" aria-modal="true" aria-label="<?php _e('جستجو در سایت'); ?>">
        <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="search-overlay-form">
            <?php echo poonehIcon('search', 22); ?>
            <input type="search" id="search-overlay-input" name="s" class="search-overlay-input" placeholder="<?php _e('دنبال چی می‌گردی؟…'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" autocomplete="off" required />
            <button type="submit" class="search-overlay-submit"><?php _e('جستجو'); ?></button>
            <button type="button" class="search-overlay-close" data-search-close aria-label="<?php _e('بستن جستجو'); ?>"><?php echo poonehIcon('close', 20); ?></button>
        </form>
        <p class="search-overlay-hint"><?php _e('با فشردن کلید Esc جستجو بسته می‌شود'); ?></p>
    </div>
</div>

<?php if ($this->is('index') && ((string) poonehOpt('showHero', '1')) === '1' && $this->currentPage <= 1): ?>
    <?php
        $heroTagline = trim((string) poonehOpt('heroTagline'));
        if ($heroTagline === '') {
            $heroTagline = (string) $this->options->description;
        }

        // آمار هرو از تنظیمات (چک‌باکس)
        $heroStatsSelected = [];
        if (is_array($this->options->heroStats ?? null)) {
            foreach (['posts', 'comments', 'views', 'likes'] as $key) {
                if (in_array($key, (array) $this->options->heroStats, true)) {
                    $heroStatsSelected[] = $key;
                }
            }
        } else {
            $heroStatsSelected = ['posts', 'comments', 'views', 'likes'];
        }

        $heroStats = !empty($heroStatsSelected) ? poonehStats() : null;

        $heroStatItems = [];
        if (is_array($heroStats)) {
            if (in_array('posts', $heroStatsSelected, true)) {
                $heroStatItems[] = [poonehFormatCount($heroStats['posts']), _t('نوشته')];
            }
            if (in_array('comments', $heroStatsSelected, true)) {
                $heroStatItems[] = [poonehFormatCount($heroStats['comments']), _t('دیدگاه')];
            }
            if (in_array('views', $heroStatsSelected, true)) {
                $heroStatItems[] = [poonehFormatCount($heroStats['views']), _t('بازدید')];
            }
            if (in_array('likes', $heroStatsSelected, true)) {
                $heroStatItems[] = [poonehFormatCount($heroStats['likes']), _t('پسند')];
            }
            if (empty($heroStatItems)) {
                $heroStats = null;
            }
        }

        // ترتیب رنگ‌های آمار هرو
        $heroStatColors = ['pink', 'lilac', 'peach', 'mint', 'sky'];
    ?>
    <section class="hero">
        <div class="container hero-inner">
            <div class="hero-badge">
                <span class="hero-badge-icon" aria-hidden="true"><?php echo poonehSprigSvg(16); ?></span>
                <span><?php _e('وبلاگ شخصی من'); ?></span>
            </div>
            <h1 class="hero-title">
                <?php if ($this->options->logoUrl): ?>
                    <img class="hero-logo" src="<?php $this->options->logoUrl() ?>" alt="<?php $this->options->title() ?>"/>
                <?php endif; ?>
                <span><?php $this->options->title() ?></span>
            </h1>
            <?php if ($heroTagline !== ''): ?>
                <p class="hero-tagline"><?php echo htmlspecialchars($heroTagline, ENT_QUOTES, 'UTF-8'); ?></p>
            <?php endif; ?>
            <?php if (is_array($heroStats) && !empty($heroStatItems)): ?>
                <div class="hero-stats">
                    <?php foreach ($heroStatItems as $heroStatIndex => [$heroStatValue, $heroStatLabel]): ?>
                        <div class="hero-stat hero-stat-<?php echo htmlspecialchars($heroStatColors[$heroStatIndex % 5], ENT_QUOTES, 'UTF-8'); ?>">
                            <strong><?php echo $heroStatValue; ?></strong>
                            <span><?php echo $heroStatLabel; ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <a class="hero-scroll-hint" href="#content" aria-label="<?php _e('رفتن به نوشته‌ها'); ?>">
                <span><?php _e('بریم پایین‌تر'); ?></span>
                <?php echo poonehIcon('arrow-left', 15); ?>
            </a>
        </div>
    </section>
<?php endif; ?>

<main id="content" class="site-main container">
