<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/* ============================================================
 * ۱) ابزارهای عمومی
 * ============================================================ */

/**
 * خواندن تنظیم پوسته همراه با مقدار پیش‌فرض
 */
function poonehOpt(string $name, ?string $default = null): ?string
{
    $value = \Widget\Options::alloc()->{$name};
    return ($value === null || $value === '') ? $default : $value;
}

/**
 * تبدیل ارقام لاتین به فارسی
 */
function poonehFa(?string $text): string
{
    return strtr((string) $text, [
        '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
        '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
    ]);
}

/**
 * تبدیل ارقام لاتین متن خروجی صفحه‌بندی به فارسی؛
 * فقط متنِ میان تگ‌ها تبدیل می‌شود تا نشانی لینک‌ها دست‌نخورده بماند.
 */
function poonehNavDigits(string $html): string
{
    return (string) preg_replace_callback(
        '/>([^<>]+)</u',
        function (array $matches): string {
            return '>' . poonehFa($matches[1]) . '<';
        },
        $html
    );
}

/**
 * قالب‌بندی خلاصهٔ اعداد با ارقام فارسی:
 * ۹۹۹ → ۹۹۹ / ۱۰۰۰ → ۱ هزار / ۱۵۰۰ → ۱٫۵ هزار / ۱۰۰۰۰ → ۱۰ هزار
 */
function poonehFormatCount(int $num): string
{
    if ($num >= 1000000) {
        return poonehCompactNumber(round($num / 1000000, 1)) . ' ' . _t('میلیون');
    }
    if ($num >= 1000) {
        return poonehCompactNumber(round($num / 1000, 1)) . ' ' . _t('هزار');
    }
    return poonehFa((string) $num);
}

/**
 * عدد کوتاه با یک رقم اعشار و ممیز فارسی (۱٫۵)
 */
function poonehCompactNumber(float $value): string
{
    $text = number_format($value, 1);
    if (mb_substr($text, -2) === '.0') {
        $text = mb_substr($text, 0, -2);
    }
    return poonehFa(str_replace('.', '٫', $text));
}

/**
 * متن فارسی تعداد دیدگاه
 */
function poonehCommentsText(int $num): string
{
    if ($num < 1) {
        return _t('هنوز دیدگاهی نیست');
    }
    if ($num == 1) {
        return _t('یک دیدگاه');
    }
    return sprintf('%s %s', poonehFa((string) $num), _t('دیدگاه'));
}

/**
 * نرمال‌سازی آدرس تصویر (نسبی → مطلق)
 */
function poonehResolveUrl(string $url): string
{
    $url = trim($url);
    if ($url === '') {
        return '';
    }

    if (preg_match('#^(data:|https?://|//)#i', $url)) {
        return $url;
    }

    $base = rtrim((string) \Widget\Options::alloc()->siteUrl, '/');
    return $base . '/' . ltrim($url, '/');
}

/**
 * پیدا کردن تصویر شاخص نوشته
 *
 * اولویت: ۱) فیلد اختصاصی thumb
 *          ۲) نخستین تصویر داخل متن نوشته
 *          ۳) تصویر شاخص پیش‌فرض تنظیمات پوسته
 */
function poonehThumbnail(\Widget\Base\Contents $content): string
{
    $thumb = trim((string) ($content->fields->thumb ?? ''));
    if ($thumb !== '') {
        return poonehResolveUrl($thumb);
    }

    $text = (string) $content->text;
    if ($text !== '') {
        if (preg_match('#<img[^>]*\bsrc=["\']([^"\']+)["\']#iu', $text, $matches)) {
            return poonehResolveUrl($matches[1]);
        }
        if (preg_match('#!\[[^\]]*\]\(\s*<?([^)\s>]+)[^)]*\)#iu', $text, $matches)) {
            return poonehResolveUrl($matches[1]);
        }
    }

    $default = trim((string) poonehOpt('defaultCover'));
    if ($default !== '') {
        return poonehResolveUrl($default);
    }

    return '';
}

/**
 * برآورد زمان مطالعه (دقیقه) بر اساس تعداد واژه‌ها
 */
function poonehReadingTime(\Widget\Base\Contents $content): int
{
    $text = (string) $content->text;

    $text = preg_replace('#```.*?```#s', ' ', $text) ?? $text;
    $text = preg_replace('#`[^`]*`#', ' ', $text) ?? $text;
    $text = preg_replace('#!\[[^\]]*\]\([^)]*\)#', ' ', $text) ?? $text;
    $text = preg_replace('#<[^>]+>#', ' ', $text) ?? $text;

    $words = preg_split('/\s+/u', trim($text), -1, PREG_SPLIT_NO_EMPTY);
    $count = is_array($words) ? count($words) : 0;

    if ($count === 0) {
        return 1;
    }

    // سرعت خواندن فارسی: حدود ۲۲۰ واژه در دقیقه
    return max(1, (int) ceil($count / 220));
}

/**
 * چکیدهٔ تمیز برای کارت‌های فهرست
 */
function poonehExcerpt(\Widget\Base\Contents $content, int $words = 26): string
{
    $text = trim((string) $content->excerpt);

    if ($text === '') {
        $text = trim((string) $content->plainExcerpt);
    }

    $text = trim(preg_replace('/\s+/u', ' ', strip_tags($text)) ?? '');
    $parts = preg_split('/\s+/u', $text, $words + 1, PREG_SPLIT_NO_EMPTY);

    if (is_array($parts) && count($parts) > $words) {
        array_pop($parts);
        return implode(' ', $parts) . '…';
    }

    return $text;
}

/**
 * ترجمهٔ نام ماه‌ها و روزهای هفتهٔ میلادی به فارسی.
 * پلاگین تاریخ شمسی (مثل JalaliDate) خودش نام‌های فارسی برمی‌گرداند و
 * این نگاشت روی آن اثری ندارد.
 */
function poonehFaCalendar(string $text): string
{
    static $map = null;

    if ($map === null) {
        $map = [
            'January'  => 'ژانویه', 'February' => 'فوریه', 'March'     => 'مارس',
            'April'    => 'آوریل',  'May'      => 'مه',     'June'      => 'ژوئن',
            'July'     => 'ژوئیه', 'August'   => 'اوت',    'September' => 'سپتامبر',
            'October'  => 'اکتبر', 'November' => 'نوامبر', 'December'  => 'دسامبر',
            'Jan' => 'ژانویه', 'Feb' => 'فوریه', 'Mar' => 'مارس',  'Apr' => 'آوریل',
            'Jun' => 'ژوئن',   'Jul' => 'ژوئیه', 'Aug' => 'اوت',   'Sep' => 'سپتامبر',
            'Oct' => 'اکتبر', 'Nov' => 'نوامبر', 'Dec' => 'دسامبر',
            'Monday'    => 'دوشنبه',   'Tuesday'  => 'سه‌شنبه', 'Wednesday' => 'چهارشنبه',
            'Thursday'  => 'پنجشنبه', 'Friday'   => 'جمعه',    'Saturday'  => 'شنبه',
            'Sunday'    => 'یکشنبه',
            'Mon' => 'دوشنبه', 'Tue' => 'سه‌شنبه', 'Wed' => 'چهارشنبه', 'Thu' => 'پنجشنبه',
            'Fri' => 'جمعه',   'Sat' => 'شنبه',    'Sun' => 'یکشنبه',
        ];
    }

    return strtr($text, $map);
}

/**
 * تاریخ نوشته با ارقام فارسی — سازگار با پلاگین تاریخ شمسی (JalaliDate)
 */
function poonehDate(\Widget\Base\Contents $content, string $format = 'j F Y'): string
{
    try {
        return poonehFa(poonehFaCalendar($content->date->format($format)));
    } catch (\Throwable $e) {
        return poonehFa(poonehFaCalendar(date($format, (int) $content->created)));
    }
}

/**
 * تاریخ دیدگاه با ارقام فارسی (سازگار با پلاگین شمسی)
 */
function poonehCommentDate($comments, string $format = 'j F Y، ساعت H:i'): string
{
    try {
        return poonehFa(poonehFaCalendar($comments->date->format($format)));
    } catch (\Throwable $e) {
        return poonehFa(poonehFaCalendar(date($format, (int) $comments->created)));
    }
}

/* ============================================================
 * ۲) آواتار — گراواتار با پیش‌فرض محلی پوسته
 * ============================================================ */

/**
 * نشانی آواتار پیش‌فرض پوسته (فرمت WebP)
 * اگر در تنظیمات نشانی دلخواه وارد شده باشد، همان برمی‌گردد.
 */
function poonehDefaultAvatarUrl(): string
{
    $custom = trim((string) poonehOpt('avatarUrl'));
    if ($custom !== '') {
        return $custom;
    }

    $themeUrl = rtrim((string) \Widget\Options::alloc()->themeUrl, '/');
    return $themeUrl . '/assets/img/avatar.webp';
}

/**
 * نشانی آواتار: اگر کاربر گراواتار داشته باشد از گراواتار،
 * وگرنه آواتار پیش‌فرض محلی پوسته.
 */
function poonehAvatarUrl(?string $mail, int $size = 48): string
{
    $mode = (string) poonehOpt('avatarMode', 'gravatar');
    $default = poonehDefaultAvatarUrl();

    if ($mode === 'local' || $mail === null || trim($mail) === '') {
        return $default;
    }

    try {
        $secure = \Typecho\Request::getInstance()->isSecure();
        return \Typecho\Common::gravatarUrl($mail, $size, 'g', $default, $secure);
    } catch (\Throwable $e) {
        return $default;
    }
}

/**
 * تصویر آواتار کامل برای نویسندهٔ نوشته
 */
function poonehAuthorAvatar($archive, int $size = 56): string
{
    $mail = '';
    try {
        $mail = (string) $archive->author->mail;
    } catch (\Throwable $e) {
        $mail = '';
    }

    $name = '';
    try {
        $name = (string) $archive->author->screenName;
    } catch (\Throwable $e) {
        $name = '';
    }

    $url = poonehAvatarUrl($mail, $size);

    return '<img class="avatar" src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '"'
        . ' alt="' . htmlspecialchars($name !== '' ? $name : _t('نویسنده'), ENT_QUOTES, 'UTF-8') . '"'
        . ' width="' . $size . '" height="' . $size . '" loading="lazy" decoding="async" />';
}

/**
 * اطلاعات نویسندهٔ اصلی سایت (نخستین کاربر)
 */
function poonehSiteAuthorInfo(): array
{
    static $info = null;

    if ($info !== null) {
        return $info;
    }

    $info = ['name' => '', 'mail' => ''];

    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.users.screenName', 'table.users.mail')
                ->from('table.users')
                ->order('table.users.uid', \Typecho\Db::SORT_ASC)
                ->limit(1)
        );

        if ($row) {
            $info['name'] = (string) ($row['screenName'] ?? '');
            $info['mail'] = (string) ($row['mail'] ?? '');
        }
    } catch (\Throwable $e) {
        // بی‌خیال؛ آواتار پیش‌فرض محلی استفاده می‌شود
    }

    return $info;
}

/**
 * آواتار نویسندهٔ اصلی سایت (برای کارت «درباره» در پانوشت)
 */
function poonehSiteAuthorAvatar(int $size = 72): string
{
    $info = poonehSiteAuthorInfo();
    $url = poonehAvatarUrl($info['mail'] !== '' ? $info['mail'] : null, $size);

    return '<img class="avatar" src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '"'
        . ' alt="' . htmlspecialchars($info['name'] !== '' ? $info['name'] : _t('نویسنده'), ENT_QUOTES, 'UTF-8') . '"'
        . ' width="' . $size . '" height="' . $size . '" loading="lazy" decoding="async" />';
}

/**
 * تصویر آواتار کامل برای کاربر واردشده فعلی
 */
function poonehUserAvatar(int $size = 36): string
{
    $user = \Widget\User::alloc();
    $mail = '';
    $name = '';

    try {
        if ($user->hasLogin()) {
            $mail = (string) $user->mail;
            $name = (string) $user->screenName;
        }
    } catch (\Throwable $e) {
        $mail = '';
    }

    $url = poonehAvatarUrl($mail, $size);

    return '<img class="avatar" src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '"'
        . ' alt="' . htmlspecialchars($name !== '' ? $name : _t('کاربر'), ENT_QUOTES, 'UTF-8') . '"'
        . ' width="' . $size . '" height="' . $size . '" loading="lazy" decoding="async" />';
}

/**
 * تصویر آواتار کامل برای دیدگاه
 */
function poonehCommentAvatar($comments, int $size = 48): string
{
    $mail = '';
    try {
        $mail = (string) $comments->mail;
    } catch (\Throwable $e) {
        $mail = '';
    }

    $name = '';
    try {
        $name = (string) $comments->author;
    } catch (\Throwable $e) {
        $name = '';
    }

    $url = poonehAvatarUrl($mail, $size);

    return '<img class="avatar" src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '"'
        . ' alt="' . htmlspecialchars($name !== '' ? $name : _t('کاربر'), ENT_QUOTES, 'UTF-8') . '"'
        . ' width="' . $size . '" height="' . $size . '" loading="lazy" decoding="async" />';
}

/* ============================================================
 * ۳) سیستم آمار بازدید — ستون views (الگوی ViewsCounter)
 * ============================================================ */

/**
 * تعداد بازدید نوشته از ستون views جدول محتوا
 */
function poonehGetViews($archive): int
{
    try {
        return max(0, (int) $archive->views);
    } catch (\Throwable $e) {
        return 0;
    }
}

/**
 * اطمینان از وجود ستون views در جدول محتوا — یکپارچه‌سازی خودکار.
 */
function poonehViewsSchemaReady(): bool
{
    static $ready = null;

    if ($ready !== null) {
        return $ready;
    }

    $ready = false;

    try {
        $db = \Typecho\Db::get();

        try {
            $db->fetchRow($db->select('table.contents.views')->from('table.contents')->limit(1));
            $columnExists = true;
        } catch (\Throwable $e) {
            $columnExists = false;
        }

        if (!$columnExists) {
            $prefix = $db->getPrefix();
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT DEFAULT 0');

            // انتقال آمار بازدید نسخه‌های پیشین
            try {
                $db->query(
                    'UPDATE `' . $prefix . 'contents` SET views = COALESCE((SELECT SUM(f.int_value)'
                    . ' FROM `' . $prefix . 'fields` f WHERE f.cid = `' . $prefix
                    . 'contents`.cid AND f.name = \'views\' AND f.type = \'int\'), 0)'
                );
                $db->query('DELETE FROM `' . $prefix . 'fields` WHERE name = \'views\' AND type = \'int\'');
            } catch (\Throwable $e) {
                // انتقال آمار اختیاری است
            }
        }

        $ready = true;
    } catch (\Throwable $e) {
        $ready = false;
    }

    return $ready;
}

/**
 * شمارش بازدید صفحات تکی — یکپارچه با پلاگین ViewsCounter
 */
function poonehCountView($archive): void
{
    // اگر پلاگین مستقل ViewsCounter فعال باشد، خودش شمارش می‌کند
    $activatedPlugins = \Widget\Options::alloc()->plugins;
    if (is_array($activatedPlugins) && isset($activatedPlugins['activated']['ViewsCounter'])) {
        return;
    }

    $countLoggedIn = ((string) poonehOpt('countLoggedInViews', '0')) === '1';
    if (\Widget\User::alloc()->hasLogin() && !$countLoggedIn) {
        return;
    }

    if (!$archive instanceof \Widget\Archive || !$archive->is('single')) {
        return;
    }

    $cid = intval($archive->cid);

    if ($cid < 1) {
        return;
    }

    $interval = (int) poonehOpt('viewsInterval', '3600');

    if ($interval > 0) {
        $viewed = (string) \Typecho\Cookie::get('poonehViews', '');
        $viewedIds = $viewed === '' ? [] : explode(',', $viewed);

        if (in_array((string) $cid, $viewedIds, true)) {
            return;
        }

        $viewedIds[] = (string) $cid;

        if (count($viewedIds) > 100) {
            $viewedIds = array_slice($viewedIds, -100);
        }

        \Typecho\Cookie::set('poonehViews', implode(',', $viewedIds), time() + $interval);
    }

    if (!poonehViewsSchemaReady()) {
        return;
    }

    try {
        $db = \Typecho\Db::get();
        $db->query(
            $db->update('table.contents')
                ->expression('views', 'views + 1')
                ->where('cid = ?', $cid)
        );
    } catch (\Throwable $e) {
        // خطا در شمارش بازدید نباید نمایش صفحه را متوقف کند
    }
}

/* ============================================================
 * ۴) سیستم لایک نوشته‌ها — AJAX + ستون likes
 * ============================================================ */

/**
 * اطمینان از وجود ستون likes در جدول محتوا — یکپارچه‌سازی خودکار.
 */
function poonehLikesSchemaReady(): bool
{
    static $ready = null;

    if ($ready !== null) {
        return $ready;
    }

    $ready = false;

    try {
        $db = \Typecho\Db::get();

        try {
            $db->fetchRow($db->select('table.contents.likes')->from('table.contents')->limit(1));
            $columnExists = true;
        } catch (\Throwable $e) {
            $columnExists = false;
        }

        if (!$columnExists) {
            $prefix = $db->getPrefix();
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `likes` INT DEFAULT 0');

            try {
                $db->query(
                    'UPDATE `' . $prefix . 'contents` SET likes = COALESCE((SELECT SUM(f.int_value)'
                    . ' FROM `' . $prefix . 'fields` f WHERE f.cid = `' . $prefix
                    . 'contents`.cid AND f.name = \'likes\' AND f.type = \'int\'), 0)'
                );
                $db->query('DELETE FROM `' . $prefix . 'fields` WHERE name = \'likes\' AND type = \'int\'');
            } catch (\Throwable $e) {
                // انتقال آمار اختیاری است
            }
        }

        $ready = true;
    } catch (\Throwable $e) {
        $ready = false;
    }

    return $ready;
}

/**
 * تعداد لایک نوشته از ستون likes جدول محتوا
 */
function poonehGetLikes($archive): int
{
    try {
        return max(0, (int) $archive->likes);
    } catch (\Throwable $e) {
        return 0;
    }
}

/**
 * توکن امنیتی دکمهٔ لایک (HMAC سایت)
 */
function poonehLikeToken(int $cid): string
{
    try {
        return (string) \Widget\Security::alloc()->getToken('pooneh-like-' . $cid);
    } catch (\Throwable $e) {
        return '';
    }
}

/**
 * خواندن تعداد فعلی لایک یک نوشته از دیتابیس
 */
function poonehFetchLikes(int $cid): int
{
    try {
        $db = \Typecho\Db::get();
        return max(0, (int) $db->fetchObject(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        )->likes);
    } catch (\Throwable $e) {
        return 0;
    }
}

/**
 * پاسخ JSON و پایان اجرا — پیش از هر خروجی صفحه
 */
function poonehJsonResponse(array $payload): void
{
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * رسیدگی به درخواست AJAX دکمهٔ لایک
 */
function poonehHandleLikeRequest(\Widget\Archive $archive): void
{
    $cid = (int) $archive->request->filter('int')->get('cid', 0);
    $token = (string) $archive->request->get('_', '');

    $payload = ['ok' => false, 'status' => 'error', 'likes' => 0, 'message' => ''];

    do {
        if ($cid < 1) {
            $payload['message'] = _t('نوشتهٔ درخواستی نامعتبر است.');
            break;
        }

        if ($token === '' || !hash_equals(poonehLikeToken($cid), $token)) {
            $payload['message'] = _t('درخواست نامعتبر است؛ صفحه را دوباره بارگذاری کنید.');
            break;
        }

        try {
            $db = \Typecho\Db::get();
            $row = $db->fetchRow(
                $db->select('table.contents.cid', 'table.contents.type', 'table.contents.status')
                    ->from('table.contents')
                    ->where('table.contents.cid = ?', $cid)
            );
        } catch (\Throwable $e) {
            $row = null;
        }

        if (!$row || ($row['status'] ?? '') !== 'publish' || !in_array($row['type'] ?? '', ['post', 'page'], true)) {
            $payload['message'] = _t('نوشتهٔ درخواستی یافت نشد.');
            break;
        }

        if (!poonehLikesSchemaReady()) {
            $payload['message'] = _t('خطا در دسترسی به پایگاه داده.');
            break;
        }

        $liked = array_values(array_filter(explode(',', (string) \Typecho\Cookie::get('poonehLikes', ''))));

        if (in_array((string) $cid, $liked, true)) {
            $payload = [
                'ok'      => true,
                'status'  => 'already',
                'likes'   => poonehFetchLikes($cid),
                'message' => _t('این نوشته رو قبلاً پسندیدی!'),
            ];
            break;
        }

        try {
            $db = \Typecho\Db::get();
            $db->query(
                $db->update('table.contents')
                    ->expression('likes', 'likes + 1')
                    ->where('cid = ?', $cid)
            );

            $liked[] = (string) $cid;

            if (count($liked) > 200) {
                $liked = array_slice($liked, -200);
            }

            \Typecho\Cookie::set('poonehLikes', implode(',', $liked), time() + 31536000);

            $payload = [
                'ok'      => true,
                'status'  => 'liked',
                'likes'   => poonehFetchLikes($cid),
                'message' => _t('پسندت ثبت شد؛ مرسی که اینجا بودی!'),
            ];
        } catch (\Throwable $e) {
            $payload['message'] = _t('ثبت پسند ممکن نشد؛ کمی بعد دوباره امتحان کن.');
        }
    } while (false);

    poonehJsonResponse($payload);
}

/* ============================================================
 * ۵) راه‌انداز پوسته
 * ============================================================ */

function themeInit(\Widget\Archive $archive)
{
    // درخواست AJAX دکمهٔ لایک — پیش از هر خروجی پاسخ داده می‌شود
    if ($archive->request->isPost() && $archive->request->isAjax() && $archive->request->is('poonehLike=1')) {
        poonehHandleLikeRequest($archive);
    }

    // شمارندهٔ بازدید یکپارچه در همه قالب‌های نشانی
    \Typecho\Plugin::factory('Widget\Archive')->beforeRender = 'poonehCountView';
}

/* ============================================================
 * ۶) آمار کلی سایت برای بخش هرو
 * ============================================================ */

function poonehStats(): array
{
    $posts = 0;
    $comments = 0;
    $views = 0;
    $likes = 0;

    try {
        $db = \Typecho\Db::get();
        $posts = (int) $db->fetchObject(
            $db->select(['COUNT(table.contents.cid)' => 'num'])
                ->from('table.contents')
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.status = ?', 'publish')
        )->num;
        $comments = (int) $db->fetchObject(
            $db->select(['COUNT(table.comments.coid)' => 'num'])
                ->from('table.comments')
                ->where('table.comments.type = ?', 'comment')
                ->where('table.comments.status = ?', 'approved')
        )->num;

        if (poonehViewsSchemaReady()) {
            $views = (int) $db->fetchObject(
                $db->select(['COALESCE(SUM(table.contents.views), 0)' => 'total'])
                    ->from('table.contents')
                    ->where('table.contents.status = ?', 'publish')
            )->total;
        }

        if (poonehLikesSchemaReady()) {
            $likes = (int) $db->fetchObject(
                $db->select(['COALESCE(SUM(table.contents.likes), 0)' => 'total'])
                    ->from('table.contents')
                    ->where('table.contents.status = ?', 'publish')
            )->total;
        }
    } catch (\Throwable $e) {
        // خطای پایگاه داده نباید نمایش سایت را متوقف کند
    }

    return ['posts' => $posts, 'comments' => $comments, 'views' => $views, 'likes' => $likes];
}

/* ============================================================
 * ۶.۵) داده‌های صفحهٔ «درباره من» — علاقه‌ها و اسکیل‌ها
 * ============================================================ */

/**
 * تجزیهٔ متن تنظیم «چیزهایی که دوست دارم»
 * هر خط: آیکون|متن — خروجی: فهرست [آیکون, متن]
 */
function poonehAboutLikes(): array
{
    $allowed = ['music', 'book', 'cat', 'camera', 'coffee', 'moon', 'star', 'heart', 'smile', 'palette'];
    $raw = (string) poonehOpt('aboutLikes', "music|موسیقی\nbook|کتاب و رمان\ncat|گربه‌ها\ncamera|عکاسی\ncoffee|کافه و قهوه\nmoon|شب‌های پرستاره");

    $likes = [];
    foreach (preg_split('/\r\n|\r|\n/', $raw) ?: [] as $line) {
        $line = trim($line);
        if ($line === '' || strpos($line, '|') === false) {
            continue;
        }

        [$icon, $label] = array_map('trim', explode('|', $line, 2));
        if ($label === '') {
            continue;
        }

        if (!in_array($icon, $allowed, true)) {
            $icon = 'heart';
        }

        $likes[] = [$icon, $label];
        if (count($likes) >= 12) {
            break;
        }
    }

    return $likes;
}

/**
 * تجزیهٔ متن تنظیم «اسکیل‌های من»
 * هر خط: نام|درصد — خروجی: فهرست [نام, درصد]
 */
function poonehAboutSkills(): array
{
    $raw = (string) poonehOpt('aboutSkills', "نوشتن|90\nعکاسی|75\nنقاشی دیجیتال|65\nآشپزی و شیرینی‌پزی|80\nیادگیری زبان|70");

    $skills = [];
    foreach (preg_split('/\r\n|\r|\n/', $raw) ?: [] as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }

        $name = $line;
        $level = null;

        if (strpos($line, '|') !== false) {
            [$name, $levelPart] = array_map('trim', explode('|', $line, 2));
            $levelPart = str_replace('٪', '', $levelPart);
            $levelPart = str_replace('%', '', $levelPart);
            // ارقام فارسی به لاتین تبدیل می‌شوند تا درصد به‌درستی خوانده شود
            $levelPart = strtr($levelPart, [
                '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
                '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            ]);
            if ($name !== '' && $levelPart !== '' && is_numeric($levelPart)) {
                $level = max(0, min(100, intval($levelPart)));
            }
        }

        if ($name === '') {
            continue;
        }

        $skills[] = [$name, $level];
        if (count($skills) >= 12) {
            break;
        }
    }

    return $skills;
}

/* ============================================================
 * ۷) تنظیمات پوسته در پیشخوان
 * ============================================================ */

function themeConfig($form)
{
    $yes = _t('نمایش');
    $no = _t('پنهان');

    /* --- هویت سایت --- */

    $logoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'logoUrl',
        null,
        null,
        _t('نشانی لوگو'),
        _t('نشانی یک تصویر را وارد کنید تا در کنار عنوان سایت نمایش داده شود؛ اگر خالی بماند، عنوان سایت با نشان پونه (شاخهٔ گل پونه) نمایش داده می‌شود.')
    );
    $form->addInput($logoUrl->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    /* --- ظاهر --- */

    $colorSchema = new \Typecho\Widget\Helper\Form\Element\Select(
        'colorSchema',
        [
            'auto'  => _t('خودکار (پیروی از تنظیمات سیستم کاربر)'),
            'light' => _t('روشنِ شاد'),
            'dark'  => _t('شب یاسی'),
        ],
        'auto',
        _t('حالت رنگی پیش‌فرض'),
        _t('بازدیدکننده می‌تواند با دکمهٔ ماه/خورشید در سربرگ، حالت را عوض کند.')
    );
    $form->addInput($colorSchema);

    $palettePreset = new \Typecho\Widget\Helper\Form\Element\Select(
        'palettePreset',
        [
            'candy'     => _t('پاستل آب‌نباتی (پیشنهادی)'),
            'bubblegum' => _t('آدامسی و هلویی'),
            'lavender'  => _t('یاسی و صورتی'),
        ],
        'candy',
        _t('پالت رنگی'),
        _t('پالت «آب‌نباتی» پنج رنگ صورتی، یاسی، هلویی، نعنایی و آسمانی را چرخشی روی کارت‌ها می‌گذارد؛ دو پالت دیگر ترکیب‌های ملایم‌تری دارند.')
    );
    $form->addInput($palettePreset);

    $bubbleStyle = new \Typecho\Widget\Helper\Form\Element\Select(
        'bubbleStyle',
        [
            'minimal' => _t('نقطه‌های ریز پاستلی (پیشنهادی)'),
            'bubbles' => _t('حباب‌های پاستلی متوسط'),
            'none'    => _t('بدون هیچ چیز — کاملاً ساده'),
        ],
        'minimal',
        _t('پس‌زمینهٔ سایت'),
        _t('پس‌زمینهٔ پیش‌فرض تمیز و مینیمال است؛ «نقطه‌های ریز» فقط چند دایرهٔ خیلی کوچک و کم‌رنگِ شناور اضافه می‌کند و «حباب‌های پاستلی» دایره‌های متوسطِ محو و آرام نمایش می‌دهد. هیچ‌کدام پترن بزرگ و رنگی نمی‌سازند.')
    );
    $form->addInput($bubbleStyle);

    /* --- فهرست اصلی --- */

    $menuCategoryOptions = [];
    try {
        $menuDb = \Typecho\Db::get();
        $menuCategoryRows = $menuDb->fetchAll(
            $menuDb->select('mid', 'name')
                ->from('table.metas')
                ->where('type = ?', 'category')
                ->order('table.metas.order', \Typecho\Db::SORT_ASC)
        );
        foreach ($menuCategoryRows as $menuCategoryRow) {
            $menuCategoryOptions[(string) $menuCategoryRow['mid']] = $menuCategoryRow['name'];
        }
    } catch (\Throwable $e) {
        $menuCategoryOptions = [];
    }

    if (!empty($menuCategoryOptions)) {
        $menuCategories = new \Typecho\Widget\Helper\Form\Element\Checkbox(
            'menuCategories',
            $menuCategoryOptions,
            [],
            _t('دسته‌ها در فهرست اصلی'),
            _t('هر دسته‌ای را که دوست داشتی تیک بزن تا به‌صورت گزینهٔ جدا در فهرست بالای سایت، بعد از «خانه» و قبل از صفحات ثابت نمایش داده شود. اگر هیچ‌کدام را انتخاب نکنی، فهرست دست‌نخورده می‌ماند.')
        );
        $form->addInput($menuCategories);
    }

    /* --- هرو صفحه اصلی --- */

    $showHero = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showHero',
        ['1' => $yes, '0' => $no],
        '1',
        _t('هرو صفحه اصلی'),
        _t('نمایش بخش معرفی در بالای صفحه اصلی؛ شامل عنوان سایت، شعار و آمار.')
    );
    $form->addInput($showHero);

    $heroTagline = new \Typecho\Widget\Helper\Form\Element\Text(
        'heroTagline',
        null,
        null,
        _t('شعار هرو'),
        _t('متنی کوتاه و صمیمی برای هرو؛ اگر خالی بماند، توضیحات سایت از تنظیمات عمومی نمایش داده می‌شود.')
    );
    $form->addInput($heroTagline);

    $heroStats = new \Typecho\Widget\Helper\Form\Element\Checkbox(
        'heroStats',
        [
            'posts'    => _t('تعداد نوشته‌ها'),
            'comments' => _t('تعداد دیدگاه‌ها'),
            'views'    => _t('مجموع بازدیدها'),
            'likes'    => _t('مجموع پسندها'),
        ],
        ['posts', 'comments', 'views', 'likes'],
        _t('آمار هرو'),
        _t('انتخاب کن کدام آمار در هرو صفحه اصلی نمایش داده شود؛ اگر هیچ‌کدام انتخاب نشود، بخش آمار به‌طور کامل حذف می‌شود. اعداد به‌صورت خلاصه و با ارقام فارسی نمایش داده می‌شوند.')
    );
    $form->addInput($heroStats);

    /* --- آواتار --- */

    $avatarMode = new \Typecho\Widget\Helper\Form\Element\Select(
        'avatarMode',
        [
            'gravatar' => _t('گراواتار + پیش‌فرض محلی (پیشنهادی)'),
            'local'    => _t('همیشه آواتار محلی پوسته'),
        ],
        'gravatar',
        _t('حالت آواتار'),
        _t('در حالت اول، اگر کاربر گراواتار داشته باشد نمایش داده می‌شود و در غیر این صورت آواتار پیش‌فرض پوسته استفاده می‌شود؛ حالت دوم هیچ درخواستی به بیرون از سایت نمی‌فرستد.')
    );
    $form->addInput($avatarMode);

    $avatarUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'avatarUrl',
        null,
        null,
        _t('آواتار پیش‌فرض دلخواه'),
        _t('نشانی تصویر آواتار پیش‌فرض خودت را وارد کن (فرمت WebP پیشنهاد می‌شود)؛ اگر خالی بماند، آواتار WebP خودِ پوسته نمایش داده می‌شود.')
    );
    $form->addInput($avatarUrl->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    /* --- تصویر شاخص --- */

    $defaultCover = new \Typecho\Widget\Helper\Form\Element\Text(
        'defaultCover',
        null,
        null,
        _t('تصویر شاخص پیش‌فرض'),
        _t('اگر نوشته‌ای نه فیلد تصویر شاخص داشت و نه تصویری در متنش بود، این تصویر نمایش داده می‌شود. خالی بماند تا به‌جای آن طرح تزئینی پونه نمایش داده شود.')
    );
    $form->addInput($defaultCover->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    /* --- امکانات نوشته --- */

    $enableLikes = new \Typecho\Widget\Helper\Form\Element\Radio(
        'enableLikes',
        ['1' => $yes, '0' => $no],
        '1',
        _t('دکمهٔ پسند (لایک)'),
        _t('نمایش دکمهٔ قلب در پایان هر نوشته؛ هر بازدیدکننده یک بار می‌تواند نوشته را بپسندد.')
    );
    $form->addInput($enableLikes);

    $showReadingTime = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showReadingTime',
        ['1' => $yes, '0' => $no],
        '1',
        _t('زمان مطالعه'),
        _t('نمایش برآورد زمان مطالعه در کارت‌ها و صفحهٔ نوشته.')
    );
    $form->addInput($showReadingTime);

    $showRelated = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showRelated',
        ['1' => $yes, '0' => $no],
        '1',
        _t('مطالب مرتبط'),
        _t('در پایان هر نوشته، نوشته‌های مرتبط (بر پایهٔ برچسب‌ها) نمایش داده می‌شود.')
    );
    $form->addInput($showRelated);

    $postSidebar = new \Typecho\Widget\Helper\Form\Element\Radio(
        'postSidebar',
        ['1' => $yes, '0' => $no],
        '1',
        _t('ستون کناری صفحهٔ نوشته'),
        _t('در صفحهٔ نوشته‌های تکی (نه صفحات ثابت) ستونی کناری معمولی نمایش داده می‌شود که مثل وبلاگ‌های کلاسیک، همراه با متن نوشته بالا و پایین می‌رود؛ ویجت‌های آن را از تنظیم پایین انتخاب کن. اگر پنهان کنی، عرض متن نوشته باریک‌تر و برای مطالعهٔ راحت‌تر تنظیم می‌شود.')
    );
    $form->addInput($postSidebar);

    $sidebarWidgets = new \Typecho\Widget\Helper\Form\Element\Checkbox(
        'sidebarWidgets',
        [
            'about'      => _t('کارت «دربارهٔ من»'),
            'recent'     => _t('تازه‌ترین نوشته‌ها'),
            'comments'   => _t('آخرین دیدگاه‌ها'),
            'popular'    => _t('محبوب‌ترین نوشته‌ها'),
            'categories' => _t('دسته‌ها'),
        ],
        ['about', 'recent', 'comments'],
        _t('ویجت‌های ستون کناری نوشته'),
        _t('هر ویجتی را که دوست داشتی تیک بزن تا در ستون کناری صفحهٔ نوشته‌ها نمایش داده شود. چون ستون همراه صفحه اسکرول می‌شود، هر تعداد ویجت که خواستی می‌توانی فعال کنی!')
    );
    $form->addInput($sidebarWidgets);

    $sidebarRecentCount = new \Typecho\Widget\Helper\Form\Element\Select(
        'sidebarRecentCount',
        ['2' => '۲', '3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶'],
        '4',
        _t('تعداد «تازه‌ترین نوشته‌ها»'),
        _t('چند نوشته در ویجت «تازه‌ترین‌ها»ی ستون کناری صفحهٔ نوشته نمایش داده شود.')
    );
    $form->addInput($sidebarRecentCount);

    $sidebarCommentsCount = new \Typecho\Widget\Helper\Form\Element\Select(
        'sidebarCommentsCount',
        ['2' => '۲', '3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶'],
        '3',
        _t('تعداد «آخرین دیدگاه‌ها»'),
        _t('چند دیدگاه در ویجت «آخرین دیدگاه‌ها»ی ستون کناری صفحهٔ نوشته نمایش داده شود.')
    );
    $form->addInput($sidebarCommentsCount);

    $sidebarPopularCount = new \Typecho\Widget\Helper\Form\Element\Select(
        'sidebarPopularCount',
        ['2' => '۲', '3' => '۳', '4' => '۴'],
        '3',
        _t('تعداد «محبوب‌ترین‌ها» در سایدبار'),
        _t('چند نوشته در ویجت «محبوب‌ترین‌ها»ی ستون کناری صفحهٔ نوشته نمایش داده شود (جدا از تعداد بخش محبوب‌ها در صفحهٔ اصلی).')
    );
    $form->addInput($sidebarPopularCount);

    /* --- آمار بازدید --- */

    $countLoggedInViews = new \Typecho\Widget\Helper\Form\Element\Radio(
        'countLoggedInViews',
        ['0' => _t('شمرده نشود (پیشنهادی)'), '1' => _t('شمرده شود')],
        '0',
        _t('بازدید کاربران واردشده'),
        _t('اگر «شمرده نشود» باشد، بازدید مدیر و کاربران واردشده از صفحات تکی در آمار ثبت نمی‌شود.')
    );
    $form->addInput($countLoggedInViews);

    $viewsInterval = new \Typecho\Widget\Helper\Form\Element\Select(
        'viewsInterval',
        [
            '3600'   => _t('۱ ساعت (پیشنهادی)'),
            '21600'  => _t('۶ ساعت'),
            '86400'  => _t('۲۴ ساعت'),
            '0'      => _t('بدون فاصله؛ هر بازدید شمرده شود'),
        ],
        '3600',
        _t('فاصله شمارش بازدید مکرر'),
        _t('بازدید تکراری یک نوشته در این بازه فقط یک بار شمرده می‌شود.')
    );
    $form->addInput($viewsInterval);

    /* --- محبوب‌ترین‌ها --- */

    $popularCount = new \Typecho\Widget\Helper\Form\Element\Select(
        'popularCount',
        ['0' => _t('مخفی'), '3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶'],
        '4',
        _t('تعداد نوشته‌های محبوب'),
        _t('نوشته‌های محبوب برای نمایش در بخش «محبوب‌ترین‌ها» در پایان صفحهٔ اصلی.')
    );
    $form->addInput($popularCount);

    $popularBasis = new \Typecho\Widget\Helper\Form\Element\Select(
        'popularBasis',
        [
            'views'    => _t('بیشترین بازدید (پیشنهادی)'),
            'likes'    => _t('بیشترین پسند'),
            'comments' => _t('بیشترین دیدگاه'),
        ],
        'views',
        _t('پایه محبوبیت نوشته‌ها'),
        _t('محبوب‌ترین نوشته‌ها بر پایهٔ آمار انتخابی فهرست می‌شوند.')
    );
    $form->addInput($popularBasis);

    /* --- درباره و شبکه‌های اجتماعی --- */

    $authorBio = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'authorBio',
        null,
        null,
        _t('دربارهٔ من'),
        _t('متنی کوتاه و صمیمی دربارهٔ خودت برای کارت «درباره» در پانوشت سایت.')
    );
    $form->addInput($authorBio);

    /* --- صفحهٔ «درباره من» --- */

    $aboutImage = new \Typecho\Widget\Helper\Form\Element\Text(
        'aboutImage',
        null,
        null,
        _t('تصویر بزرگ صفحهٔ درباره من'),
        _t('نشانی تصویر بزرگ نویسنده برای صفحهٔ «درباره من»؛ اگر خالی بماند، تصویر شاخص برگه و در غیر این صورت تصویر WebP خودِ پوسته نمایش داده می‌شود.')
    );
    $form->addInput($aboutImage->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $aboutRole = new \Typecho\Widget\Helper\Form\Element\Text(
        'aboutRole',
        null,
        _t('بلاگر و راوی لحظه‌های کوچیک'),
        _t('عنوان کوتاه زیر نامت در صفحهٔ درباره من'),
        _t('مثال: دانش‌آموز، عکاس تازه‌کار و دوست‌دار گربه‌ها.')
    );
    $form->addInput($aboutRole);

    $aboutLikes = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'aboutLikes',
        null,
        "music|موسیقی\nbook|کتاب و رمان\ncat|گربه‌ها\ncamera|عکاسی\ncoffee|کافه و قهوه\nmoon|شب‌های پرستاره",
        _t('چیزهایی که دوست دارم'),
        _t('هر خط یک مورد، به شکل «آیکون|متن»؛ مثال: music|موسیقی. آیکون‌های موجود: music، book، cat، camera، coffee، moon، star، heart، smile، palette')
    );
    $form->addInput($aboutLikes);

    $aboutSkills = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'aboutSkills',
        null,
        "نوشتن|90\nعکاسی|75\nنقاشی دیجیتال|65\nآشپزی و شیرینی‌پزی|80\nیادگیری زبان|70",
        _t('اسکیل‌های من'),
        _t('هر خط یک مهارت، به شکل «نام|درصد»؛ مثال: نوشتن|90. درصد عددی بین ۰ تا ۱۰۰ است.')
    );
    $form->addInput($aboutSkills);

    $socialTelegram = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialTelegram',
        null,
        null,
        _t('نشانی تلگرام'),
        _t('مثال: https://t.me/example')
    );
    $form->addInput($socialTelegram->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $socialInstagram = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialInstagram',
        null,
        null,
        _t('نشانی اینستاگرام'),
        _t('مثال: https://instagram.com/example')
    );
    $form->addInput($socialInstagram->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $socialYoutube = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialYoutube',
        null,
        null,
        _t('نشانی یوتیوب'),
        _t('مثال: https://youtube.com/@example')
    );
    $form->addInput($socialYoutube->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    $socialGithub = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialGithub',
        null,
        null,
        _t('نشانی گیت‌هاب'),
        _t('مثال: https://github.com/example')
    );
    $form->addInput($socialGithub->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

    /* --- پانوشت --- */

    $footerText = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'footerText',
        null,
        null,
        _t('متن دلخواه پانوشت'),
        _t('در صورت خالی‌بودن، فقط نام سایت و سال نمایش داده می‌شود.')
    );
    $form->addInput($footerText);
}

/* ============================================================
 * ۸) فیلد اختصاصی «تصویر شاخص» در ویرایشگر نوشته
 * ============================================================ */

function themeFields($layout)
{
    $thumb = new \Typecho\Widget\Helper\Form\Element\Text(
        'thumb',
        null,
        null,
        _t('تصویر شاخص'),
        _t('نشانی کامل تصویر شاخص این نوشته (در کارت‌های فهرست و ابتدای صفحهٔ نوشته نمایش داده می‌شود). اگر خالی بماند، نخستین تصویر متن به‌طور خودکار استفاده می‌شود.')
    );
    $layout->addItem($thumb);
}

/* ============================================================
 * ۹) ویجت نوشته‌های محبوب
 * ============================================================ */

if (!class_exists('PoonehPopularPosts')) {
    class PoonehPopularPosts extends \Widget\Base\Contents
    {
        public function execute()
        {
            $this->parameter->setDefault(['pageSize' => 5]);
            $limit = max(1, intval($this->parameter->pageSize));

            $basis = (string) ($this->options->popularBasis ?? 'views');
            if (!in_array($basis, ['views', 'likes', 'comments'], true)) {
                $basis = 'views';
            }

            $viewsReady = poonehViewsSchemaReady();
            $likesReady = poonehLikesSchemaReady();

            if ($basis === 'views' && $viewsReady) {
                $total = (int) $this->db->fetchObject(
                    $this->db->select(['COALESCE(SUM(table.contents.views), 0)' => 'total'])
                        ->from('table.contents')
                        ->where('table.contents.type = ?', 'post')
                        ->where('table.contents.status = ?', 'publish')
                )->total;

                if ($total < 1) {
                    $basis = ($likesReady && $this->poonehTotalLikes() > 0) ? 'likes' : 'comments';
                }
            } elseif ($basis === 'likes') {
                $basis = ($likesReady && $this->poonehTotalLikes() > 0) ? 'likes' : 'comments';
            }

            $orderColumn = 'table.contents.commentsNum';
            if ($basis === 'views' && $viewsReady) {
                $orderColumn = 'table.contents.views';
            } elseif ($basis === 'likes' && $likesReady) {
                $orderColumn = 'table.contents.likes';
            }

            $select = $this->select('table.contents.*')
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', $this->options->time)
                ->where('table.contents.type = ?', 'post')
                ->where("table.contents.password IS NULL OR table.contents.password = ''")
                ->order($orderColumn, \Typecho\Db::SORT_DESC)
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit($limit);

            $this->db->fetchAll($select, [$this, 'push']);
        }

        private function poonehTotalLikes(): int
        {
            try {
                return (int) $this->db->fetchObject(
                    $this->db->select(['COALESCE(SUM(table.contents.likes), 0)' => 'total'])
                        ->from('table.contents')
                        ->where('table.contents.type = ?', 'post')
                        ->where('table.contents.status = ?', 'publish')
                )->total;
            } catch (\Throwable $e) {
                return 0;
            }
        }
    }
}

if (!class_exists('PoonehSidebarRecent')) {
    /**
     * ویجت تازه‌ترین نوشته‌ها برای ستون کناری صفحهٔ نوشته
     * (نوشتهٔ در حال مطالعه با پارامتر ignoreCid از فهرست حذف می‌شود)
     */
    class PoonehSidebarRecent extends \Widget\Base\Contents
    {
        public function execute()
        {
            $this->parameter->setDefault(['pageSize' => 4, 'ignoreCid' => 0]);
            $limit = max(1, intval($this->parameter->pageSize));
            $ignoreCid = intval($this->parameter->ignoreCid);

            $select = $this->select('table.contents.*')
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', $this->options->time)
                ->where('table.contents.type = ?', 'post')
                ->where("table.contents.password IS NULL OR table.contents.password = ''")
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit($limit);

            if ($ignoreCid > 0) {
                $select->where('table.contents.cid <> ?', $ignoreCid);
            }

            $this->db->fetchAll($select, [$this, 'push']);
        }
    }
}

/* ============================================================
 * ۱۰) رندر اجزای مشترک
 * ============================================================ */

/**
 * نشان پونه (SVG) — شاخهٔ کوچک پونه با دو برگ و یک غنچه
 * رنگ برگ‌ها با currentColor از والد می‌گیرد.
 */
function poonehSprigSvg(int $size = 20): string
{
    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 64 64" fill="none"'
        . ' aria-hidden="true" focusable="false">'
        . '<path d="M32 58 C32 44 32 36 32 30" stroke="currentColor" stroke-width="3" stroke-linecap="round"></path>'
        . '<path d="M32 40 C22 40 14 34 12 24 C22 22 30 26 32 34" fill="currentColor" opacity="0.85"></path>'
        . '<path d="M32 40 C42 40 50 34 52 24 C42 22 34 26 32 34" fill="currentColor" opacity="0.6"></path>'
        . '<path d="M32 28 C25 28 20 24 18 17 C25 15 31 19 32 25" fill="currentColor" opacity="0.75"></path>'
        . '<path d="M32 28 C39 28 44 24 46 17 C39 15 33 19 32 25" fill="currentColor" opacity="0.5"></path>'
        . '<circle cx="32" cy="22" r="5" fill="currentColor"></circle>'
        . '</svg>';
}

/**
 * آیکن‌های خطی پرکاربرد (Feather-style)
 */
function poonehIcon(string $name, int $size = 14): string
{
    $paths = [
        'user'    => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle>',
        'calendar'=> '<rect x="3" y="4" width="18" height="18" rx="2.5"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line>',
        'clock'   => '<circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15.5 14"></polyline>',
        'chat'    => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>',
        'eye'     => '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle>',
        'heart'   => '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>',
        'folder'  => '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>',
        'tag'     => '<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line>',
        'search'  => '<circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line>',
        'arrow-left'  => '<line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline>',
        'arrow-right' => '<line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline>',
        'chevron-left'  => '<polyline points="15 18 9 12 15 6"></polyline>',
        'chevron-right' => '<polyline points="9 18 15 12 9 6"></polyline>',
        'close'   => '<line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>',
        'menu'    => '<line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="18" x2="21" y2="18"></line>',
        'sun'     => '<circle cx="12" cy="12" r="4"></circle><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M5.64 17.66l-1.41 1.41M18.36 5.64l1.41-1.41"></path>',
        'moon'    => '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>',
        'up'      => '<line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline>',
        'link'    => '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>',
        'send'    => '<line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>',
        'rss'     => '<path d="M4 11a9 9 0 0 1 9 9"></path><path d="M4 4a16 16 0 0 1 16 16"></path><circle cx="5" cy="19" r="1"></circle>',
        'star'    => '<path d="M12 17.75L6.16 21l1.12-6.5L2 9.24l6.54-.95L12 2l3.46 6.29 6.54.95-5.28 5.25L17.84 21z"></path>',
        'sparkle' => '<path d="M12 2l2.2 6.3L21 10.5l-6.8 2.2L12 19l-2.2-6.3L3 10.5l6.8-2.2z"></path><path d="M19 15l.9 2.6L22.5 18l-2.6.9L19 21.5l-.9-2.6L15.5 18l2.6-.9z"></path>',
        'flame'   => '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"></path>',
        'smile'   => '<circle cx="12" cy="12" r="9"></circle><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" y1="9" x2="9.01" y2="9"></line><line x1="15" y1="9" x2="15.01" y2="9"></line>',
        'music'   => '<path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle>',
        'book'    => '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>',
        'camera'  => '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle>',
        'cat'     => '<path d="M4 4l4 4h8l4-4v8c0 4.4-3.6 8-8 8s-8-3.6-8-8z"></path><circle cx="9.5" cy="13" r="0.5"></circle><circle cx="14.5" cy="13" r="0.5"></circle><path d="M12 15.5v1.5"></path><path d="M10 18.4c.6.5 1.3.7 2 .7s1.4-.2 2-.7"></path>',
        'coffee'  => '<path d="M18 8h1a4 4 0 0 1 0 8h-1"></path><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path><line x1="6" y1="1" x2="6" y2="4"></line><line x1="10" y1="1" x2="10" y2="4"></line><line x1="14" y1="1" x2="14" y2="4"></line>',
        'mail'    => '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline>',
        'palette' => '<circle cx="13.5" cy="6.5" r="1.2"></circle><circle cx="17.5" cy="10.5" r="1.2"></circle><circle cx="8.5" cy="7.5" r="1.2"></circle><circle cx="6.5" cy="12.5" r="1.2"></circle><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c1.9 0 2.7-1.2 2.7-2.4 0-.6-.2-1.1-.6-1.6-.4-.4-.6-.9-.6-1.5 0-1.2 1-2.2 2.2-2.2H19c1.7 0 3-1.3 3-3-.2-5.3-4.6-9.3-10-9.3z"></path>',
    ];

    $path = $paths[$name] ?? $paths['star'];

    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor"'
        . ' stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
}

/**
 * آیکن‌های شبکه‌های اجتماعی (تلگرام، اینستاگرام، یوتیوب، گیت‌هاب)
 */
function poonehSocialIcon(string $key, int $size = 18): string
{
    $svgs = [
        'telegram' => '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.9 4.6l-3.1 14.7c-.2 1-.8 1.3-1.7.8l-4.7-3.5-2.3 2.2c-.25.25-.47.47-.94.47l.33-4.8L18.2 6.6c.37-.33-.08-.52-.58-.19L6.9 13.7l-4.6-1.44c-1-.31-1-1 .21-1.48L20.6 3.1c.83-.3 1.56.2 1.3 1.5z"/></svg>',
        'instagram' => '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>',
        'youtube' => '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.5 12 3.5 12 3.5s-7.5 0-9.4.6A3 3 0 0 0 .5 6.2 31.3 31.3 0 0 0 0 12a31.3 31.3 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.1c1.9.6 9.4.6 9.4.6s7.5 0 9.4-.6a3 3 0 0 0 2.1-2.1A31.3 31.3 0 0 0 24 12a31.3 31.3 0 0 0-.5-5.8zM9.6 15.6V8.4L15.8 12z"/></svg>',
        'github' => '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.11.79-.25.79-.55 0-.27-.01-1.17-.02-2.12-3.2.7-3.88-1.36-3.88-1.36-.52-1.33-1.28-1.68-1.28-1.68-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.18 1.76 1.18 1.03 1.76 2.69 1.25 3.35.96.1-.75.4-1.25.72-1.54-2.55-.29-5.24-1.28-5.24-5.68 0-1.26.45-2.28 1.18-3.09-.12-.29-.51-1.46.11-3.05 0 0 .96-.31 3.15 1.18a10.9 10.9 0 0 1 5.74 0c2.19-1.49 3.15-1.18 3.15-1.18.62 1.59.23 2.76.11 3.05.73.81 1.18 1.83 1.18 3.09 0 4.41-2.69 5.38-5.25 5.67.41.35.77 1.05.77 2.12 0 1.53-.01 2.76-.01 3.14 0 .3.2.67.8.55A11.52 11.52 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5z"/></svg>',
    ];

    return $svgs[$key] ?? '';
}

/**
 * رندر ردیف اطلاعات نوشته: نویسنده، تاریخ، زمان مطالعه، بازدید و دیدگاه
 */
function poonehMetaRow($archive, string $context = 'card'): void
{
    $showReadingTime = ((string) poonehOpt('showReadingTime', '1')) === '1';
    $views = poonehGetViews($archive);
    $commentsNum = (int) $archive->commentsNum;
    ?>
    <div class="meta-row">
        <span class="meta-item meta-author">
            <span class="meta-avatar"><?php echo poonehAuthorAvatar($archive, 24); ?></span>
            <a href="<?php $archive->author->permalink(); ?>" rel="author" itemprop="author"><?php $archive->author(); ?></a>
        </span>
        <span class="meta-item">
            <?php echo poonehIcon('calendar'); ?>
            <time datetime="<?php echo date('c', (int) $archive->created); ?>" itemprop="datePublished"><?php echo poonehDate($archive); ?></time>
        </span>
        <?php if ($showReadingTime): ?>
            <span class="meta-item">
                <?php echo poonehIcon('clock'); ?>
                <?php echo poonehFa((string) poonehReadingTime($archive)); ?> <?php _e('دقیقه'); ?>
            </span>
        <?php endif; ?>
        <?php if ($views > 0): ?>
            <span class="meta-item meta-views">
                <?php echo poonehIcon('eye'); ?>
                <?php echo poonehFa((string) $views); ?>
            </span>
        <?php endif; ?>
        <?php if ($context === 'card' || $context === 'hero'): ?>
            <span class="meta-item">
                <?php echo poonehIcon('chat'); ?>
                <a href="<?php $archive->permalink(); ?>#comments" itemprop="discussionUrl"><?php echo poonehCommentsText($commentsNum); ?></a>
            </span>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * قاب تصویر شاخص (تصویر واقعی یا طرح تزئینی پونه)
 */
function poonehCoverHtml(string $cover, string $title, string $loading = 'lazy'): string
{
    if ($cover !== '') {
        return '<img src="' . htmlspecialchars($cover, ENT_QUOTES, 'UTF-8') . '"'
            . ' alt="' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '"'
            . ' loading="' . $loading . '" decoding="async" itemprop="image" />';
    }

    return '<span class="card-cover-pattern" aria-hidden="true">' . poonehSprigSvg(56) . '</span>';
}

/* ============================================================
 * ۱۱) کارت‌های نوشته در فهرست
 * ============================================================ */

/**
 * کارت بزرگ تازه‌ترین نوشته (صفحهٔ نخست خانه)
 */
function poonehRenderHeroCard(\Widget\Archive $archive): void
{
    $cover = poonehThumbnail($archive);
    ?>
    <article class="hero-card reveal" itemscope itemtype="http://schema.org/BlogPosting">
        <a class="hero-card-cover" href="<?php $archive->permalink(); ?>" aria-hidden="true" tabindex="-1">
            <?php echo poonehCoverHtml($cover, (string) $archive->title, 'eager'); ?>
        </a>
        <div class="hero-card-body">
            <div class="card-kicker">
                <span class="chip chip-accent"><?php echo poonehIcon('sparkle', 13); ?> <?php _e('تازه‌ترین نوشته'); ?></span>
                <?php if ($archive->categories): ?>
                    <a class="chip chip-category" href="<?php echo htmlspecialchars($archive->categories[0]['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($archive->categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                <?php endif; ?>
            </div>
            <h2 class="hero-card-title" itemprop="name headline">
                <a href="<?php $archive->permalink(); ?>" itemprop="url"><?php $archive->title(); ?></a>
            </h2>
            <?php $excerpt = poonehExcerpt($archive, 34); ?>
            <?php if ($excerpt !== ''): ?>
                <p class="hero-card-excerpt"><?php echo htmlspecialchars($excerpt, ENT_QUOTES, 'UTF-8'); ?></p>
            <?php endif; ?>
            <?php poonehMetaRow($archive, 'hero'); ?>
            <a class="read-more" href="<?php $archive->permalink(); ?>">
                <span><?php _e('بذار بخونمش'); ?></span>
                <?php echo poonehIcon('arrow-left', 16); ?>
            </a>
        </div>
    </article>
    <?php
}

/**
 * کارت شیشه‌ای نوشته برای گرید دونستونه
 */
function poonehRenderCard(\Widget\Archive $archive): void
{
    $cover = poonehThumbnail($archive);
    ?>
    <article class="post-card reveal" itemscope itemtype="http://schema.org/BlogPosting">
        <a class="post-card-cover" href="<?php $archive->permalink(); ?>" aria-hidden="true" tabindex="-1">
            <?php echo poonehCoverHtml($cover, (string) $archive->title); ?>
        </a>
        <div class="post-card-body">
            <div class="card-kicker">
                <?php if ($archive->categories): ?>
                    <a class="chip chip-category" href="<?php echo htmlspecialchars($archive->categories[0]['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($archive->categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                <?php else: ?>
                    <span class="chip chip-category"><?php _e('یادداشت'); ?></span>
                <?php endif; ?>
            </div>
            <h2 class="post-card-title" itemprop="name headline">
                <a href="<?php $archive->permalink(); ?>" itemprop="url"><?php $archive->title(); ?></a>
            </h2>
            <?php $excerpt = poonehExcerpt($archive, 20); ?>
            <?php if ($excerpt !== ''): ?>
                <p class="post-card-excerpt"><?php echo htmlspecialchars($excerpt, ENT_QUOTES, 'UTF-8'); ?></p>
            <?php endif; ?>
            <?php poonehMetaRow($archive, 'card'); ?>
        </div>
        <a class="post-card-link" href="<?php $archive->permalink(); ?>" aria-hidden="true" tabindex="-1"></a>
    </article>
    <?php
}

/**
 * کارت کوچک نوشتهٔ محبوب (بخش محبوب‌ترین‌ها)
 */
function poonehRenderPopularItem($popular, int $rank): void
{
    $views = 0;
    try {
        $views = max(0, (int) $popular->views);
    } catch (\Throwable $e) {
        $views = 0;
    }

    $likes = 0;
    try {
        $likes = max(0, (int) $popular->likes);
    } catch (\Throwable $e) {
        $likes = 0;
    }

    $basis = (string) poonehOpt('popularBasis', 'views');
    ?>
    <li class="popular-item">
        <span class="popular-rank" aria-hidden="true"><?php echo poonehFa((string) $rank); ?></span>
        <div class="popular-item-main">
            <a class="popular-item-title" href="<?php $popular->permalink(); ?>"><?php $popular->title(); ?></a>
            <span class="popular-item-meta">
                <?php if ($basis === 'likes' && $likes > 0): ?>
                    <?php echo poonehIcon('heart', 13); ?>
                    <?php echo poonehFa((string) $likes); ?> <?php _e('پسند'); ?>
                    <span class="popular-meta-sep" aria-hidden="true">·</span>
                <?php elseif ($views > 0): ?>
                    <?php echo poonehIcon('eye', 13); ?>
                    <?php echo poonehFa((string) $views); ?>
                    <span class="popular-meta-sep" aria-hidden="true">·</span>
                <?php endif; ?>
                <?php echo poonehCommentsText((int) $popular->commentsNum); ?>
            </span>
        </div>
    </li>
    <?php
}

/**
 * بخش «محبوب‌ترین نوشته‌ها» در پایان صفحهٔ اصلی
 */
function poonehRenderPopularSection(): void
{
    $popularCount = intval((string) poonehOpt('popularCount', '4'));
    if ($popularCount < 1) {
        return;
    }

    PoonehPopularPosts::alloc('pageSize=' . $popularCount)->to($popular);
    if (!$popular->have()) {
        return;
    }
    ?>
    <section class="popular-section reveal" aria-label="<?php _e('محبوب‌ترین نوشته‌ها'); ?>">
        <h2 class="section-title">
            <span class="section-title-icon" aria-hidden="true"><?php echo poonehIcon('heart', 18); ?></span>
            <?php _e('محبوب‌ترین‌های وبلاگ'); ?>
        </h2>
        <ol class="popular-list">
            <?php $rank = 0; while ($popular->next()): $rank++; ?>
                <?php poonehRenderPopularItem($popular, $rank); ?>
            <?php endwhile; ?>
        </ol>
    </section>
    <?php
}

/* ============================================================
 * ۱۲) دیدگاه‌های درختی
 * ============================================================ */

function threadedComments($comments, $options)
{
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
    ?>
    <li id="li-<?php $comments->theId(); ?>" class="comment-item<?php
        if ($comments->levels > 0) {
            echo ' comment-child';
            $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
        } else {
            echo ' comment-parent';
        }
        $comments->alt(' comment-odd', ' comment-even');
        echo $commentClass;
    ?>">
        <div id="<?php $comments->theId(); ?>" class="comment-inner">
            <div class="comment-avatar" aria-hidden="true">
                <?php echo poonehCommentAvatar($comments, 48); ?>
            </div>
            <div class="comment-main">
                <div class="comment-meta">
                    <cite class="comment-author" itemprop="creator" itemscope itemtype="http://schema.org/Person">
                        <?php $comments->author(); ?>
                        <?php if ($comments->authorId && $comments->authorId == $comments->ownerId): ?>
                            <span class="comment-badge comment-badge-owner"><?php _e('نویسنده'); ?></span>
                        <?php endif; ?>
                    </cite>
                    <span class="comment-time">
                        <a href="<?php $comments->permalink(); ?>" itemprop="url">
                            <time datetime="<?php echo date('c', (int) $comments->created); ?>" itemprop="commentTime"><?php echo poonehCommentDate($comments); ?></time>
                        </a>
                    </span>
                    <?php if ($comments->status == 'waiting'): ?>
                        <span class="comment-badge comment-badge-waiting"><?php _e('در انتظار تأیید'); ?></span>
                    <?php endif; ?>
                    <span class="comment-reply">
                        <?php $comments->reply(_t('پاسخ')); ?>
                    </span>
                </div>
                <div class="comment-content" itemprop="commentText">
                    <?php $comments->content(); ?>
                </div>
            </div>
        </div>
        <?php if ($comments->children) { ?>
            <div class="comment-children">
                <?php $comments->threadedComments($options); ?>
            </div>
        <?php } ?>
    </li>
    <?php
}
