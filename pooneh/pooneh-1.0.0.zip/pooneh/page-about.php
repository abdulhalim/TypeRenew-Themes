<?php
/**
 * درباره من — صفحهٔ نویسنده
 *
 * @package custom
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

/* ---------- تصویر بزرگ نویسنده ----------
 * اولویت: تنظیم پوسته ← تصویر شاخص برگه ← تصویر WebP خود پوسته */
$aboutImage = trim((string) poonehOpt('aboutImage'));
if ($aboutImage === '') {
    $aboutImage = poonehThumbnail($this);
}
if ($aboutImage === '') {
    $themeUrl = rtrim((string) \Widget\Options::alloc()->themeUrl, '/');
    $aboutImage = $themeUrl . '/assets/img/about-author.webp';
}

/* ---------- نام و معرفی نویسنده ---------- */
$aboutAuthor = poonehSiteAuthorInfo();
$aboutName = $aboutAuthor['name'] !== '' ? $aboutAuthor['name'] : (string) $this->title();
$aboutRole = trim((string) poonehOpt('aboutRole'));
if ($aboutRole === '') {
    $aboutRole = _t('بلاگر و راوی لحظه‌های کوچیک');
}
$aboutBio = trim((string) poonehOpt('authorBio'));
if ($aboutBio === '') {
    $aboutBio = _t('به وبلاگم خوش اومدی؛ این‌جا جای خاطره‌ها، چیزهایی که دوست دارم و لحظه‌های کوچیکِ قشنگ زندگیمه.');
}

/* ---------- آمار سایت ---------- */
$aboutStats = poonehStats();
$aboutStatItems = [];
if ($aboutStats['posts'] > 0) {
    $aboutStatItems[] = [poonehFormatCount($aboutStats['posts']), _t('نوشته')];
}
if ($aboutStats['comments'] > 0) {
    $aboutStatItems[] = [poonehFormatCount($aboutStats['comments']), _t('دیدگاه')];
}
if ($aboutStats['views'] > 0) {
    $aboutStatItems[] = [poonehFormatCount($aboutStats['views']), _t('بازدید')];
}
if ($aboutStats['likes'] > 0) {
    $aboutStatItems[] = [poonehFormatCount($aboutStats['likes']), _t('پسند')];
}

/* ---------- علاقه‌ها و مهارت‌ها ---------- */
$aboutLikes = poonehAboutLikes();
$aboutSkills = poonehAboutSkills();

/* ---------- متن برگه ---------- */
ob_start();
$this->content();
$aboutContent = trim((string) ob_get_clean());

/* ---------- شبکه‌های اجتماعی ---------- */
$aboutSocials = [
    'telegram'  => [(string) poonehOpt('socialTelegram'), _t('تلگرام')],
    'instagram' => [(string) poonehOpt('socialInstagram'), _t('اینستاگرام')],
    'youtube'   => [(string) poonehOpt('socialYoutube'), _t('یوتیوب')],
    'github'    => [(string) poonehOpt('socialGithub'), _t('گیت‌هاب')],
];
$aboutHasSocial = false;
foreach ($aboutSocials as $aboutSocial) {
    if ($aboutSocial[0] !== '') {
        $aboutHasSocial = true;
        break;
    }
}
?>

<div class="layout layout-single">

    <div class="layout-primary">

        <nav class="breadcrumb" aria-label="<?php _e('مسیر صفحه'); ?>">
            <a href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a>
            <span class="breadcrumb-sep" aria-hidden="true">/</span>
            <span class="breadcrumb-current" aria-current="page"><?php $this->title(); ?></span>
        </nav>

        <section class="about-hero reveal">

            <figure class="about-hero-media">
                <img src="<?php echo htmlspecialchars($aboutImage, ENT_QUOTES, 'UTF-8'); ?>"
                    alt="<?php echo htmlspecialchars(_t('تصویر نویسندهٔ بلاگ') . '، ' . $aboutName, ENT_QUOTES, 'UTF-8'); ?>"
                    loading="eager" decoding="async">
                <span class="about-hero-frame" aria-hidden="true"></span>
            </figure>

            <div class="about-hero-info">
                <p class="about-kicker">
                    <span aria-hidden="true"><?php echo poonehSprigSvg(15); ?></span>
                    <span><?php _e('درباره من'); ?></span>
                </p>
                <h1 class="about-name"><?php echo htmlspecialchars($aboutName, ENT_QUOTES, 'UTF-8'); ?></h1>
                <p class="about-role"><?php echo htmlspecialchars($aboutRole, ENT_QUOTES, 'UTF-8'); ?></p>
                <p class="about-bio"><?php echo htmlspecialchars($aboutBio, ENT_QUOTES, 'UTF-8'); ?></p>

                <?php if (!empty($aboutStatItems)): ?>
                    <div class="about-hero-stats">
                        <?php foreach ($aboutStatItems as $aboutStatItem): ?>
                            <span class="about-stat">
                                <strong><?php echo $aboutStatItem[0]; ?></strong>
                                <span><?php echo $aboutStatItem[1]; ?></span>
                            </span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($aboutHasSocial): ?>
                    <div class="about-social">
                        <?php foreach ($aboutSocials as $aboutKey => [$aboutUrl, $aboutLabel]): ?>
                            <?php if ($aboutUrl !== ''): ?>
                                <a href="<?php echo htmlspecialchars($aboutUrl, ENT_QUOTES, 'UTF-8'); ?>"
                                    target="_blank" rel="noopener"
                                    aria-label="<?php echo $aboutLabel; ?>" title="<?php echo $aboutLabel; ?>">
                                    <?php echo poonehSocialIcon($aboutKey, 19); ?>
                                </a>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

        </section>

        <?php if ($aboutContent !== ''): ?>
            <div class="post-content about-content reveal" id="post-content">
                <?php echo $aboutContent; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($aboutLikes)): ?>
            <section class="about-likes reveal" aria-label="<?php _e('چیزهایی که دوست دارم'); ?>">
                <h2 class="section-title">
                    <span class="section-title-icon" aria-hidden="true"><?php echo poonehIcon('heart', 17); ?></span>
                    <?php _e('چیزایی که دوست دارم'); ?>
                </h2>
                <div class="about-likes-grid">
                    <?php foreach ($aboutLikes as $aboutLike): ?>
                        <div class="about-like">
                            <span class="about-like-icon" aria-hidden="true"><?php echo poonehIcon($aboutLike[0], 19); ?></span>
                            <span class="about-like-label"><?php echo htmlspecialchars($aboutLike[1], ENT_QUOTES, 'UTF-8'); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if (!empty($aboutSkills)): ?>
            <section class="about-skills reveal" aria-label="<?php _e('مهارت‌های من'); ?>">
                <h2 class="section-title">
                    <span class="section-title-icon" aria-hidden="true"><?php echo poonehIcon('star', 17); ?></span>
                    <?php _e('اسکیل‌هام'); ?>
                </h2>
                <div class="about-skills-grid">
                    <?php foreach ($aboutSkills as $aboutSkillIndex => $aboutSkill): ?>
                        <?php [$aboutSkillName, $aboutSkillLevel] = $aboutSkill; ?>
                        <div class="about-skill">
                            <div class="about-skill-head">
                                <span class="about-skill-name"><?php echo htmlspecialchars($aboutSkillName, ENT_QUOTES, 'UTF-8'); ?></span>
                                <?php if ($aboutSkillLevel !== null): ?>
                                    <span class="about-skill-level"><?php echo poonehFa((string) $aboutSkillLevel); ?>٪</span>
                                <?php endif; ?>
                            </div>
                            <?php if ($aboutSkillLevel !== null): ?>
                                <div class="about-skill-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100"
                                    aria-valuenow="<?php echo $aboutSkillLevel; ?>"
                                    aria-label="<?php echo htmlspecialchars($aboutSkillName, ENT_QUOTES, 'UTF-8'); ?>">
                                    <span class="about-skill-fill"
                                        style="--skill:<?php echo $aboutSkillLevel; ?>%;--skill-delay:<?php echo $aboutSkillIndex * 110; ?>ms"></span>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <section class="about-cta reveal">
            <div class="about-cta-text">
                <h2 class="about-cta-title"><?php _e('دلت خواست، بمان و بیشتر باهم دوست بشیم'); ?></h2>
                <p class="about-cta-desc"><?php _e('از نوشته‌های تازه غافل نشو؛ هر چند روز یه چیزای جدید همین‌جا پیدا می‌شه.'); ?></p>
            </div>
            <a class="about-cta-btn" href="<?php $this->options->siteUrl(); ?>">
                <?php _e('بزن بریم خوندن'); ?>
                <?php echo poonehIcon('arrow-left', 16); ?>
            </a>
        </section>

    </div>

</div>

<?php $this->need('footer.php'); ?>
