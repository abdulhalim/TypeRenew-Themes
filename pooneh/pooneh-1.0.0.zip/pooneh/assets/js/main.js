(function () {
    'use strict';

    var doc = document;
    var win = window;

    var config = win.POONEH || {};
    var strings = config.strings || {};
    var likesEnabled = config.likes !== false;
    var bubbleStyle = config.bubbles || 'minimal';

    function s(key, fallback) {
        return strings[key] || fallback;
    }

    /* --------------------------------------------------------------
     *  ابزارها
     * -------------------------------------------------------------- */

    /** تبدیل ارقام لاتین به فارسی */
    function faDigits(value) {
        var fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return String(value).replace(/[0-9]/g, function (d) {
            return fa[+d];
        });
    }

    var toastTimer = null;
    function toast(message) {
        var el = doc.getElementById('toast');
        if (!el || !message) return;
        el.textContent = message;
        el.classList.add('is-visible');
        if (toastTimer) clearTimeout(toastTimer);
        toastTimer = setTimeout(function () {
            el.classList.remove('is-visible');
        }, 2600);
    }

    var prefersReducedMotion = win.matchMedia
        && win.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* --------------------------------------------------------------
     *  تعویض حالت روشن و شب یاسی
     * -------------------------------------------------------------- */

    function initThemeSwitch() {
        var btn = doc.getElementById('theme-switch');
        var html = doc.documentElement;
        var transitionTimeout = null;

        function applyTransition() {
            doc.body.classList.add('theme-transition');
            if (transitionTimeout) clearTimeout(transitionTimeout);
            transitionTimeout = setTimeout(function () {
                doc.body.classList.remove('theme-transition');
            }, 420);
        }

        if (btn) {
            btn.addEventListener('click', function () {
                var currentDark = html.getAttribute('data-theme') === 'dark';
                var newTheme = currentDark ? 'light' : 'dark';

                applyTransition();
                html.setAttribute('data-theme', newTheme);
                try {
                    localStorage.setItem('pooneh-theme', newTheme);
                } catch (e) { /* حافظهٔ محلی در دسترس نیست */ }
            });
        }

        var prefersDark = win.matchMedia('(prefers-color-scheme: dark)');
        if (prefersDark.addEventListener) {
            prefersDark.addEventListener('change', function (e) {
                var stored = null;
                try {
                    stored = localStorage.getItem('pooneh-theme');
                } catch (err) { stored = null; }

                if (!stored) {
                    applyTransition();
                    if (e.matches) {
                        html.setAttribute('data-theme', 'dark');
                    } else {
                        html.removeAttribute('data-theme');
                    }
                }
            });
        }
    }

    /* --------------------------------------------------------------
     *  پوشش جستجو
     * -------------------------------------------------------------- */

    function initSearchOverlay() {
        var overlay = doc.getElementById('search-overlay');
        var toggle = doc.getElementById('search-toggle');
        var input = doc.getElementById('search-overlay-input');

        if (!overlay || !toggle) return;

        function open() {
            overlay.classList.add('is-open');
            overlay.setAttribute('aria-hidden', 'false');
            doc.body.style.overflow = 'hidden';
            if (input) {
                setTimeout(function () { input.focus(); }, 60);
            }
        }

        function close() {
            overlay.classList.remove('is-open');
            overlay.setAttribute('aria-hidden', 'true');
            doc.body.style.overflow = '';
        }

        toggle.addEventListener('click', open);

        var closers = overlay.querySelectorAll('[data-search-close]');
        Array.prototype.forEach.call(closers, function (el) {
            el.addEventListener('click', close);
        });

        doc.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' || e.keyCode === 27) {
                if (overlay.classList.contains('is-open')) {
                    close();
                }
            }
        });
    }

    /* --------------------------------------------------------------
     *  نوار پیشرفت مطالعه، سربرگ و بازگشت به بالا
     * -------------------------------------------------------------- */

    function initScrollFeatures() {
        var progressWrap = doc.querySelector('.reading-progress');
        var progressBar = progressWrap ? progressWrap.querySelector('.reading-progress-bar') : null;
        var header = doc.getElementById('site-header');
        var backBtn = doc.getElementById('back-to-top');
        var ticking = false;

        function update() {
            var scrollTop = win.pageYOffset || doc.documentElement.scrollTop;
            var height = doc.documentElement.scrollHeight - win.innerHeight;

            if (progressBar) {
                var ratio = height > 0 ? Math.min(1, Math.max(0, scrollTop / height)) : 0;
                progressBar.style.width = (ratio * 100).toFixed(2) + '%';
            }

            if (header) {
                if (scrollTop > 12) {
                    header.classList.add('is-scrolled');
                } else {
                    header.classList.remove('is-scrolled');
                }
            }

            if (backBtn) {
                if (scrollTop > 480) {
                    backBtn.classList.add('is-visible');
                } else {
                    backBtn.classList.remove('is-visible');
                }
            }

            ticking = false;
        }

        win.addEventListener('scroll', function () {
            if (!ticking) {
                win.requestAnimationFrame(update);
                ticking = true;
            }
        }, { passive: true });

        update();

        if (backBtn) {
            backBtn.addEventListener('click', function () {
                win.scrollTo({
                    top: 0,
                    behavior: prefersReducedMotion ? 'auto' : 'smooth'
                });
            });
        }
    }

    /* --------------------------------------------------------------
     *  انیمیشن ظهور هنگام پیمایش
     * -------------------------------------------------------------- */

    function initReveal() {
        var items = doc.querySelectorAll('.reveal');

        if (!items.length) return;

        if (!('IntersectionObserver' in win)) {
            Array.prototype.forEach.call(items, function (el) {
                el.classList.add('is-visible');
            });
            return;
        }

        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.08, rootMargin: '0px 0px -36px 0px' });

        Array.prototype.forEach.call(items, function (el) {
            observer.observe(el);
        });
    }

    /* --------------------------------------------------------------
     *  پس‌زمینهٔ مینیمال — نقطه‌های ریز پاستلی (یا حباب‌های متوسط)
     * -------------------------------------------------------------- */

    function initBubbles() {
        var layer = doc.getElementById('bubbles-layer');
        if (!layer) return;
        if (bubbleStyle === 'none' || prefersReducedMotion) return;

        var colorful = bubbleStyle === 'bubbles';

        // رنگ‌های پاستلی با شفافیت کم — بدون پترن‌های بزرگ
        var palette = colorful ? [
            'rgba(255, 111, 165, 0.30)',   // صورتی
            'rgba(157, 123, 234, 0.28)',   // یاسی
            'rgba(255, 145, 96, 0.24)',    // هلویی
            'rgba(46, 197, 163, 0.24)',    // نعنایی
            'rgba(85, 172, 255, 0.26)'     // آسمانی
        ] : [
            'rgba(255, 111, 165, 0.15)',   // صورتی
            'rgba(157, 123, 234, 0.13)',   // یاسی
            'rgba(255, 145, 96, 0.13)',    // هلویی
            'rgba(46, 197, 163, 0.12)',    // نعنایی
            'rgba(85, 172, 255, 0.13)'     // آسمانی
        ];

        var count = win.innerWidth < 768 ? (colorful ? 4 : 6) : (colorful ? 6 : 11);

        // نقطه‌های ریز: ۱۰ تا ۳۲ پیکسل · حباب‌ها: ۴۶ تا ۹۶ پیکسل
        var sizeMin = colorful ? 46 : 10;
        var sizeRange = colorful ? 50 : 22;

        // نقطه‌ها آرام‌تر و دیرتر حرکت می‌کنند
        var durMin = colorful ? 18 : 34;
        var durRange = colorful ? 18 : 30;

        var fragment = doc.createDocumentFragment();

        for (var i = 0; i < count; i++) {
            var bubble = doc.createElement('span');
            bubble.className = 'pooneh-bubble';

            var size = sizeMin + Math.round(Math.random() * sizeRange);
            var colorIndex = i % palette.length;

            bubble.style.width = size + 'px';
            bubble.style.height = size + 'px';
            bubble.style.background = palette[colorIndex];
            bubble.style.right = (Math.random() * 96) + '%';
            bubble.style.top = (Math.random() * 92 + 3) + '%';
            bubble.style.setProperty('--dur', (durMin + Math.random() * durRange).toFixed(1) + 's');
            bubble.style.animationDelay = (-Math.random() * 30).toFixed(1) + 's';

            fragment.appendChild(bubble);
        }

        layer.appendChild(fragment);
    }

    /* --------------------------------------------------------------
     *  دکمهٔ پسند (لایک) — AJAX
     * -------------------------------------------------------------- */

    function initLikeButton() {
        var btn = doc.getElementById('like-button');

        if (!btn || !likesEnabled) return;

        var alreadyLiked = false;

        try {
            var liked = (win.localStorage.getItem('pooneh-liked') || '').split(',');
            alreadyLiked = liked.indexOf(String(btn.dataset.cid)) !== -1;
        } catch (e) {
            try {
                var cookie = doc.cookie.match(/poonehLikes=([^;]+)/);
                alreadyLiked = cookie
                    ? decodeURIComponent(cookie[1]).split(',').indexOf(String(btn.dataset.cid)) !== -1
                    : false;
            } catch (err) {
                alreadyLiked = false;
            }
        }

        function markLiked(withPop) {
            btn.classList.add('is-liked');
            btn.setAttribute('aria-pressed', 'true');
            if (withPop) {
                var label = btn.querySelector('.like-label');
                if (label) {
                    label.textContent = 'پسندیدی!';
                }
            }
        }

        if (alreadyLiked) {
            markLiked(false);
        }

        btn.addEventListener('click', function () {
            if (btn.classList.contains('is-liked') || btn.classList.contains('is-busy')) {
                if (alreadyLiked) toast(s('likeAlready', 'این نوشته رو قبلاً پسندیدی!'));
                return;
            }

            btn.classList.add('is-busy');

            var fd = new FormData();
            fd.append('poonehLike', '1');
            fd.append('cid', btn.dataset.cid);
            fd.append('_', btn.dataset.token);

            fetch(win.location.href, {
                method: 'POST',
                body: fd,
                credentials: 'same-origin',
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (data.ok) {
                        alreadyLiked = true;
                        var countEl = btn.querySelector('.like-count');
                        if (countEl && typeof data.likes !== 'undefined') {
                            countEl.textContent = faDigits(data.likes);
                        }
                        markLiked(true);
                        try {
                            var prev = (win.localStorage.getItem('pooneh-liked') || '').split(',').filter(Boolean);
                            prev.push(String(btn.dataset.cid));
                            win.localStorage.setItem('pooneh-liked', prev.join(','));
                        } catch (e) { /* مهم نیست */ }
                        toast(data.message || s('likeOk', 'پسندت ثبت شد!'));
                    } else {
                        toast(data.message || s('likeFail', 'ثبت پسند ممکن نشد.'));
                    }
                })
                .catch(function () {
                    toast(s('likeFail', 'ثبت پسند ممکن نشد؛ دوباره امتحان کن.'));
                })
                .finally(function () {
                    btn.classList.remove('is-busy');
                });
        });
    }

    /* --------------------------------------------------------------
     *  کپی لینک نوشته
     * -------------------------------------------------------------- */

    function initCopyLink() {
        var btn = doc.querySelector('.js-copy-link');
        if (!btn) return;

        btn.addEventListener('click', function () {
            var url = win.location.href;

            function done(ok) {
                toast(ok ? s('copyOk', 'لینک نوشته کپی شد!') : s('copyFail', 'کپی لینک ممکن نشد.'));
            }

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(url).then(function () { done(true); }, function () { done(false); });
            } else {
                try {
                    var input = doc.createElement('textarea');
                    input.value = url;
                    input.setAttribute('readonly', '');
                    input.style.position = 'absolute';
                    input.style.left = '-9999px';
                    doc.body.appendChild(input);
                    input.select();
                    var ok = doc.execCommand('copy');
                    doc.body.removeChild(input);
                    done(ok);
                } catch (e) {
                    done(false);
                }
            }
        });
    }

    /* --------------------------------------------------------------
     *  راه‌اندازی
     * -------------------------------------------------------------- */

    function init() {
        initThemeSwitch();
        initSearchOverlay();
        initScrollFeatures();
        initReveal();
        initBubbles();
        initLikeButton();
        initCopyLink();
    }

    if (doc.readyState === 'loading') {
        doc.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
