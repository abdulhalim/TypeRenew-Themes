<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="error-page">
    <div class="error-inner">
        <div class="error-ornament" aria-hidden="true"><?php echo poonehSprigSvg(44); ?></div>
        <div class="error-code" aria-hidden="true">۴۰۴</div>
        <h1 class="error-title"><?php _e('ای وای! این صفحه پیدا نشد'); ?></h1>
        <p class="error-text">
            <?php _e('انگار این صفحه جایی گم شده؛ شاید آدرس عوض شده یا اصلاً وجود نداشته. نگران نباش، راه برگشت بازه!'); ?>
        </p>
        <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="empty-search-form">
            <input type="search" name="s" placeholder="<?php _e('تو وبلاگ دنبال چی بگردم؟…'); ?>" aria-label="<?php _e('عبارت جستجو'); ?>" required />
            <button type="submit"><?php _e('جستجو'); ?></button>
        </form>
        <a class="btn-primary" href="<?php $this->options->siteUrl(); ?>">
            <span><?php _e('برگرد خونه'); ?></span>
            <?php echo poonehIcon('arrow-left', 16); ?>
        </a>
    </div>
</div>

<?php $this->need('footer.php'); ?>
