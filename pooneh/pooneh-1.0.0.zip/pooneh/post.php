<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<?php
    $postCover = poonehThumbnail($this);
    $postLikes = poonehGetLikes($this);
    $postViews = poonehGetViews($this);
    $enableLikes = ((string) poonehOpt('enableLikes', '1')) === '1';
    $showReadingTime = ((string) poonehOpt('showReadingTime', '1')) === '1';
    $categories = $this->categories;

    // ستون کناری صفحهٔ نوشته — فقط برای نوشته‌ها (نه صفحات ثابت)
    $postSidebarOn = ((string) poonehOpt('postSidebar', '1')) === '1';

    // ویجت‌های ستون کناری — بر اساس سلیقهٔ کاربر از تنظیمات پوسته
    $sidebarWidgets = [];
    if (is_array($this->options->sidebarWidgets ?? null)) {
        foreach (['about', 'recent', 'comments', 'popular', 'categories'] as $sidebarWidgetKey) {
            if (in_array($sidebarWidgetKey, (array) $this->options->sidebarWidgets, true)) {
                $sidebarWidgets[] = $sidebarWidgetKey;
            }
        }
    } else {
        $sidebarWidgets = ['about', 'recent', 'comments'];
    }
    $postSidebarOn = $postSidebarOn && !empty($sidebarWidgets);
?>

<div class="layout <?php echo $postSidebarOn ? 'layout-post' : 'layout-narrow'; ?>">

    <div class="layout-primary">

        <article class="single-post reveal" itemscope itemtype="http://schema.org/BlogPosting">

            <nav class="breadcrumb" aria-label="<?php _e('مسیر صفحه'); ?>">
                <a href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a>
                <?php if (!empty($categories)): ?>
                    <span class="breadcrumb-sep" aria-hidden="true">/</span>
                    <a href="<?php echo htmlspecialchars($categories[0]['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($categories[0]['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                <?php endif; ?>
                <span class="breadcrumb-sep" aria-hidden="true">/</span>
                <span class="breadcrumb-current" aria-current="page"><?php $this->title(); ?></span>
            </nav>

            <header class="post-header">
                <h1 class="post-title" itemprop="name headline"><?php $this->title(); ?></h1>

                <div class="meta-row post-meta-main">
                    <span class="meta-item meta-author">
                        <span class="meta-avatar"><?php echo poonehAuthorAvatar($this, 44); ?></span>
                        <a href="<?php $this->author->permalink(); ?>" rel="author" itemprop="author"><?php $this->author(); ?></a>
                    </span>
                    <span class="meta-item">
                        <?php echo poonehIcon('calendar'); ?>
                        <time datetime="<?php echo date('c', (int) $this->created); ?>" itemprop="datePublished"><?php echo poonehDate($this); ?></time>
                    </span>
                    <?php if ($showReadingTime): ?>
                        <span class="meta-item">
                            <?php echo poonehIcon('clock'); ?>
                            <?php echo poonehFa((string) poonehReadingTime($this)); ?> <?php _e('دقیقه مطالعه'); ?>
                        </span>
                    <?php endif; ?>
                    <?php if ($postViews > 0): ?>
                        <span class="meta-item meta-views">
                            <?php echo poonehIcon('eye'); ?>
                            <?php echo poonehFa((string) $postViews); ?> <?php _e('بازدید'); ?>
                        </span>
                    <?php endif; ?>
                    <?php if ($postLikes > 0): ?>
                        <span class="meta-item meta-likes">
                            <?php echo poonehIcon('heart'); ?>
                            <?php echo poonehFa((string) $postLikes); ?> <?php _e('پسند'); ?>
                        </span>
                    <?php endif; ?>
                    <span class="meta-item">
                        <?php echo poonehIcon('chat'); ?>
                        <a href="<?php $this->permalink(); ?>#comments" itemprop="discussionUrl"><?php echo poonehCommentsText((int) $this->commentsNum); ?></a>
                    </span>
                </div>
            </header>

            <?php if ($postCover !== ''): ?>
                <figure class="post-hero" itemprop="image">
                    <img src="<?php echo htmlspecialchars($postCover, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php $this->title(); ?>" loading="eager" decoding="async">
                </figure>
            <?php endif; ?>

            <div class="post-content" itemprop="articleBody" id="post-content">
                <?php $this->content(); ?>
            </div>

            <?php if ($this->tags): ?>
                <div class="post-tags" itemprop="keywords">
                    <span class="post-tags-label">
                        <?php echo poonehIcon('tag', 15); ?>
                        <?php _e('برچسب‌ها'); ?>:
                    </span>
                    <?php foreach ($this->tags as $tag): ?>
                        <a class="tag-pill" href="<?php echo htmlspecialchars($tag['permalink'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($tag['name'], ENT_QUOTES, 'UTF-8'); ?></a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($enableLikes): ?>
                <div class="post-likes">
                    <button type="button" class="like-button" id="like-button"
                        data-cid="<?php echo intval($this->cid); ?>"
                        data-token="<?php echo htmlspecialchars(poonehLikeToken(intval($this->cid)), ENT_QUOTES, 'UTF-8'); ?>"
                        data-likes="<?php echo $postLikes; ?>"
                        aria-pressed="false">
                        <span class="like-icon" aria-hidden="true"><?php echo poonehIcon('heart', 16); ?></span>
                        <span class="like-text">
                            <strong class="like-count"><?php echo poonehFa((string) $postLikes); ?></strong>
                            <span class="like-label"><?php _e('پسندیدیش؟'); ?></span>
                        </span>
                    </button>
                </div>
            <?php endif; ?>

            <div class="post-share">
                <span class="post-share-label"><?php _e('به اشتراک بذار'); ?>:</span>
                <button type="button" class="share-btn js-copy-link" title="<?php _e('کپی لینک نوشته'); ?>">
                    <?php echo poonehIcon('link', 16); ?>
                    <?php _e('کپی لینک'); ?>
                </button>
                <a class="share-btn" href="https://t.me/share/url?url=<?php echo urlencode((string) $this->permalink); ?>&amp;text=<?php echo urlencode((string) $this->title); ?>" target="_blank" rel="noopener" title="<?php _e('اشتراک‌گذاری در تلگرام'); ?>">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.9 4.6l-3.1 14.7c-.2 1-.8 1.3-1.7.8l-4.7-3.5-2.3 2.2c-.25.25-.47.47-.94.47l.33-4.8L18.2 6.6c.37-.33-.08-.52-.58-.19L6.9 13.7l-4.6-1.44c-1-.31-1-1 .21-1.48L20.6 3.1c.83-.3 1.56.2 1.3 1.5z"/></svg>
                    <?php _e('تلگرام'); ?>
                </a>
            </div>

        </article>

        <?php $authorBio = trim((string) poonehOpt('authorBio')); ?>
        <div class="author-box reveal">
            <div class="author-box-avatar">
                <?php echo poonehAuthorAvatar($this, 72); ?>
            </div>
            <div class="author-box-info">
                <p class="author-box-role"><?php _e('نویسنده'); ?></p>
                <h3 class="author-box-name">
                    <a href="<?php $this->author->permalink(); ?>" rel="author"><?php $this->author(); ?></a>
                </h3>
                <?php if ($authorBio !== ''): ?>
                    <p class="author-box-bio"><?php echo htmlspecialchars($authorBio, ENT_QUOTES, 'UTF-8'); ?></p>
                <?php endif; ?>
                <a class="author-box-link" href="<?php $this->author->permalink(); ?>">
                    <?php _e('نوشته‌های این نویسنده'); ?>
                    <?php echo poonehIcon('arrow-left', 14); ?>
                </a>
            </div>
        </div>

        <nav class="post-nav reveal" aria-label="<?php _e('ناوبری نوشته‌ها'); ?>">
            <div class="post-nav-item post-nav-prev">
                <span class="post-nav-label"><?php _e('نوشتهٔ قدیمی‌تر'); ?></span>
                <div class="post-nav-link"><?php $this->thePrev('%s', _t('نوشتهٔ قدیمی‌تری نیست')); ?></div>
            </div>
            <div class="post-nav-item post-nav-next">
                <span class="post-nav-label"><?php _e('نوشتهٔ تازه‌تر'); ?></span>
                <div class="post-nav-link"><?php $this->theNext('%s', _t('نوشتهٔ تازه‌تری نیست')); ?></div>
            </div>
        </nav>

        <?php if (((string) poonehOpt('showRelated', '1')) === '1'): ?>
            <?php $this->related(3)->to($relatedPosts); ?>
            <?php if ($relatedPosts->have()): ?>
                <section class="related-posts reveal" aria-label="<?php _e('مطالب مرتبط'); ?>">
                    <h2 class="section-title">
                        <span class="section-title-icon" aria-hidden="true"><?php echo poonehIcon('sparkle', 18); ?></span>
                        <?php _e('شاید این‌ها هم خوشت بیاد'); ?>
                    </h2>
                    <div class="related-grid">
                        <?php while ($relatedPosts->next()): ?>
                            <?php $relatedCover = poonehThumbnail($relatedPosts); ?>
                            <article class="related-card">
                                <a class="related-cover" href="<?php $relatedPosts->permalink(); ?>" aria-hidden="true" tabindex="-1">
                                    <?php echo poonehCoverHtml($relatedCover, (string) $relatedPosts->title); ?>
                                </a>
                                <h3 class="related-title">
                                    <a href="<?php $relatedPosts->permalink(); ?>"><?php $relatedPosts->title(); ?></a>
                                </h3>
                                <time class="related-date" datetime="<?php echo date('c', (int) $relatedPosts->created); ?>"><?php echo poonehDate($relatedPosts); ?></time>
                            </article>
                        <?php endwhile; ?>
                    </div>
                </section>
            <?php endif; ?>
        <?php endif; ?>

        <?php $this->need('comments.php'); ?>

    </div>

    <?php if ($postSidebarOn): ?>
        <?php
            $sidebarBio = trim((string) poonehOpt('authorBio'));
            $sidebarAuthor = poonehSiteAuthorInfo();
            $sidebarRecentCount = intval((string) poonehOpt('sidebarRecentCount', '4'));
            $sidebarCommentsCount = intval((string) poonehOpt('sidebarCommentsCount', '3'));
            $sidebarPopularCount = intval((string) poonehOpt('sidebarPopularCount', '3'));
        ?>
        <aside class="post-sidebar" aria-label="<?php _e('ستون کناری نوشته'); ?>">

            <?php if (in_array('about', $sidebarWidgets, true)): ?>
                <section class="sidebar-card sidebar-about reveal">
                    <div class="sidebar-about-avatar" aria-hidden="true"><?php echo poonehSiteAuthorAvatar(60); ?></div>
                    <div class="sidebar-about-main">
                        <p class="sidebar-about-name"><?php echo htmlspecialchars($sidebarAuthor['name'] !== '' ? $sidebarAuthor['name'] : (string) $this->options->title, ENT_QUOTES, 'UTF-8'); ?></p>
                        <?php if ($sidebarBio !== ''): ?>
                            <p class="sidebar-about-bio"><?php echo htmlspecialchars($sidebarBio, ENT_QUOTES, 'UTF-8'); ?></p>
                        <?php else: ?>
                            <p class="sidebar-about-bio"><?php _e('به وبلاگم خوش اومدی؛ این‌جا جای خاطره‌ها و چیزهایی است که دوست دارم.'); ?></p>
                        <?php endif; ?>
                    </div>
                </section>
            <?php endif; ?>

            <?php if ($sidebarRecentCount > 0 && in_array('recent', $sidebarWidgets, true)): ?>
                <?php PoonehSidebarRecent::alloc('pageSize=' . $sidebarRecentCount . '&ignoreCid=' . intval($this->cid))->to($sidebarRecent); ?>
                <?php if ($sidebarRecent->have()): ?>
                    <section class="sidebar-card reveal">
                        <h3 class="sidebar-title">
                            <span class="sidebar-title-icon sidebar-title-icon-pink" aria-hidden="true"><?php echo poonehIcon('sparkle', 14); ?></span>
                            <?php _e('تازه‌ترین‌ها'); ?>
                        </h3>
                        <ul class="sidebar-recent">
                            <?php while ($sidebarRecent->next()): ?>
                                <li class="sidebar-recent-item">
                                    <span class="sidebar-recent-dot" aria-hidden="true"></span>
                                    <a class="sidebar-recent-title" href="<?php $sidebarRecent->permalink(); ?>"><?php $sidebarRecent->title(); ?></a>
                                    <time class="sidebar-recent-date" datetime="<?php echo date('c', (int) $sidebarRecent->created); ?>"><?php echo poonehDate($sidebarRecent); ?></time>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    </section>
                <?php endif; ?>
            <?php endif; ?>

            <?php if ($sidebarCommentsCount > 0 && in_array('comments', $sidebarWidgets, true)): ?>
                <?php
                    $sidebarComments = null;
                    try {
                        \Widget\Comments\Recent::allocWithAlias(
                            'pooneh-sidebar-comments',
                            'pageSize=' . $sidebarCommentsCount . '&ignoreAuthor=0'
                        )->to($sidebarComments);
                    } catch (\Throwable $sidebarCommentsError) {
                        $sidebarComments = null;
                    }
                ?>
                <?php if ($sidebarComments && $sidebarComments->have()): ?>
                    <section class="sidebar-card reveal">
                        <h3 class="sidebar-title">
                            <span class="sidebar-title-icon sidebar-title-icon-mint" aria-hidden="true"><?php echo poonehIcon('chat', 14); ?></span>
                            <?php _e('آخرین دیدگاه‌ها'); ?>
                        </h3>
                        <ul class="sidebar-comments">
                            <?php while ($sidebarComments->next()): ?>
                                <?php
                                    $sidebarCommentLink = '#';
                                    try {
                                        $sidebarCommentLink = (string) $sidebarComments->permalink;
                                    } catch (\Throwable $sidebarCommentLinkError) {
                                        $sidebarCommentLink = '#';
                                    }

                                    $sidebarCommentPost = '';
                                    try {
                                        $sidebarCommentPost = (string) $sidebarComments->title;
                                    } catch (\Throwable $sidebarCommentPostError) {
                                        $sidebarCommentPost = '';
                                    }
                                ?>
                                <li class="sidebar-comment">
                                    <a class="sidebar-comment-link" href="<?php echo htmlspecialchars($sidebarCommentLink, ENT_QUOTES, 'UTF-8'); ?>">
                                        <span class="sidebar-comment-avatar" aria-hidden="true"><?php echo poonehCommentAvatar($sidebarComments, 40); ?></span>
                                        <span class="sidebar-comment-main">
                                            <span class="sidebar-comment-head">
                                                <strong class="sidebar-comment-author"><?php echo htmlspecialchars((string) $sidebarComments->author, ENT_QUOTES, 'UTF-8'); ?></strong>
                                                <?php if ($sidebarCommentPost !== ''): ?>
                                                    <span class="sidebar-comment-on"><?php _e('روی'); ?> «<?php echo htmlspecialchars($sidebarCommentPost, ENT_QUOTES, 'UTF-8'); ?>»</span>
                                                <?php endif; ?>
                                            </span>
                                            <span class="sidebar-comment-text"><?php $sidebarComments->excerpt(48, '…'); ?></span>
                                        </span>
                                    </a>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    </section>
                <?php endif; ?>
            <?php endif; ?>

            <?php if ($sidebarPopularCount > 0 && in_array('popular', $sidebarWidgets, true)): ?>
                <?php PoonehPopularPosts::alloc('pageSize=' . $sidebarPopularCount)->to($sidebarPopular); ?>
                <?php if ($sidebarPopular->have()): ?>
                    <section class="sidebar-card reveal">
                        <h3 class="sidebar-title">
                            <span class="sidebar-title-icon sidebar-title-icon-peach" aria-hidden="true"><?php echo poonehIcon('heart', 14); ?></span>
                            <?php _e('محبوب‌ترین‌ها'); ?>
                        </h3>
                        <ol class="popular-list sidebar-popular">
                            <?php $sidebarRank = 0; while ($sidebarPopular->next()): $sidebarRank++; ?>
                                <?php poonehRenderPopularItem($sidebarPopular, $sidebarRank); ?>
                            <?php endwhile; ?>
                        </ol>
                    </section>
                <?php endif; ?>
            <?php endif; ?>

            <?php if (in_array('categories', $sidebarWidgets, true)): ?>
                <?php \Widget\Metas\Category\Rows::allocWithAlias('pooneh-post-sidebar')->to($sidebarCategories); ?>
                <?php if ($sidebarCategories->have()): ?>
                    <section class="sidebar-card reveal">
                        <h3 class="sidebar-title">
                            <span class="sidebar-title-icon sidebar-title-icon-lilac" aria-hidden="true"><?php echo poonehIcon('folder', 14); ?></span>
                            <?php _e('دسته‌ها'); ?>
                        </h3>
                        <ul class="sidebar-categories">
                            <?php while ($sidebarCategories->next()): ?>
                                <li class="sidebar-cat">
                                    <a class="sidebar-cat-link" href="<?php $sidebarCategories->permalink(); ?>">
                                        <span class="sidebar-cat-dot" aria-hidden="true"></span>
                                        <span class="sidebar-cat-name"><?php $sidebarCategories->name(); ?></span>
                                        <span class="sidebar-cat-count"><?php echo poonehFa((string) $sidebarCategories->count); ?></span>
                                    </a>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    </section>
                <?php endif; ?>
            <?php endif; ?>

        </aside>
    <?php endif; ?>

</div>

<?php $this->need('footer.php'); ?>
