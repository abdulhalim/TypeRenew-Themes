<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$themeMode = (string) mijam_opt('themeMode', 'auto');
if (! in_array($themeMode, ['auto', 'light', 'dark'], true)) {
    $themeMode = 'auto';
}

$faviconUrl  = (string) mijam_opt('faviconUrl', mijam_theme_url('images/favicon.png'));

/* لوگوی هدر: سفارشی (img) یا پیش‌فرض تطبیقی (SVG اینلاین با currentColor) */
$headerLogo      = trim((string) mijam_opt('headerLogoUrl', ''));
$headerLogoDark  = trim((string) mijam_opt('headerLogoDarkUrl', ''));
$defaultLogoPath = mijam_theme_url('images/logo.png');
if ($headerLogo === $defaultLogoPath) {
    /* مقدار پیش‌فرض قدیمی ذخیره‌شده → SVG پیش‌فرض تطبیقی */
    $headerLogo = '';
}

$menuCatIds  = getSelectedCategories();
$showMenuAll = empty($menuCatIds);
$siteTitle   = '';
try {
    $siteTitle = (string) $this->options->title;
} catch (Throwable $e) {
    $siteTitle = '';
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="theme-color" content="#f6f7fb" media="(prefers-color-scheme: light)">
    <meta name="theme-color" content="#14161d" media="(prefers-color-scheme: dark)">

    <link rel="icon" href="<?php echo mijam_e($faviconUrl); ?>">

    <title>
        <?php if ($this->is('index')): ?>
            <?php $this->options->title(); ?>
        <?php else: ?>
            <?php $this->archiveTitle([], '', ''); ?> — <?php $this->options->title(); ?>
        <?php endif; ?>
    </title>

    <?php $this->header(); ?>

    <link rel="stylesheet" href="<?php echo mijam_theme_url('style.css'); ?>?v=<?php echo MIJAM_VERSION; ?>">

    <script>
    // اعمال سریع تم (روز/شب) قبل از رندر — برای جلوگیری از فلش روشن/تیره
    (function () {
        try {
            var mode = <?php echo json_encode($themeMode); ?>;
            var saved = null;
            try { saved = localStorage.getItem('mijam-theme'); } catch (e) {}
            var theme;
            if (saved === 'light' || saved === 'dark') {
                theme = saved;
            } else if (mode === 'light' || mode === 'dark') {
                theme = mode;
            } else {
                theme = window.matchMedia
                    && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
            }
            document.documentElement.setAttribute('data-theme', theme);
            document.documentElement.style.colorScheme = theme;
        } catch (e) {}
    })();
    </script>
</head>

<body>
<div class="site-wrapper farsi-digits" id="siteWrapper">

    <a class="skip-link" href="#main">پرش به محتوای اصلی</a>

    <?php if (mijam_opt('showReadingProgress', '1') == '1'): ?>
    <div class="reading-progress" aria-hidden="true">
        <div class="reading-progress__bar" id="readingProgressBar"></div>
    </div>
    <?php endif; ?>

    <header class="site-header">
        <div class="container header-container">

            <div class="site-logo">
                <a href="<?php $this->options->siteUrl(); ?>" aria-label="<?php $this->options->title(); ?>">
                    <?php if ($headerLogo !== ''): ?>
                        <img src="<?php echo mijam_e($headerLogo); ?>" alt="<?php $this->options->title(); ?>"
                             data-logo-light="<?php echo mijam_e($headerLogo); ?>"
                             <?php if ($headerLogoDark !== ''): ?>data-logo-dark="<?php echo mijam_e($headerLogoDark); ?>"<?php endif; ?>>
                    <?php else: ?>
                        <?php echo mijam_default_logo_svg($siteTitle); ?>
                    <?php endif; ?>
                </a>
            </div>

            <nav class="main-menu" id="mainMenu" aria-label="منوی اصلی">
                <div class="main-menu__search">
                    <form class="menu-search-form" method="get" action="<?php $this->options->siteUrl(); ?>" role="search">
                        <?php echo mijam_icon('search', 16); ?>
                        <input type="search" name="s" placeholder="جستجو…" aria-label="جستجو" autocomplete="off">
                    </form>
                </div>
                <ul class="main-menu__list">
                    <li><a href="<?php $this->options->siteUrl(); ?>"><?php echo mijam_icon('home', 14); ?><span>خانه</span></a></li>
                    <?php
                    try {
                        $this->widget('Widget_Metas_Category_List@menu', 'current=')->to($menuCategories);
                        while ($menuCategories->next()):
                            $menuMid   = (int) $menuCategories->mid;
                            $menuCount = (int) $menuCategories->count;
                            // نمایش همه دسته‌های پُر؛ یا فقط دسته‌های انتخابی صریح (حتی خالی)
                            if ($showMenuAll && $menuCount < 1) {
                                continue;
                            }
                            if (! $showMenuAll && ! in_array($menuMid, $menuCatIds, true)) {
                                continue;
                            }
                    ?>
                        <li><a href="<?php $menuCategories->permalink(); ?>"><?php $menuCategories->name(); ?></a></li>
                    <?php
                        endwhile;
                    } catch (Throwable $e) {
                        // منوی دسته در دسترس نیست
                    }

                    try {
                        $this->widget('Widget_Contents_Page_List@menu')->to($menuPages);
                        while ($menuPages->next()):
                    ?>
                        <li><a href="<?php $menuPages->permalink(); ?>"><?php $menuPages->title(); ?></a></li>
                    <?php
                        endwhile;
                    } catch (Throwable $e) {
                        // فهرست برگه‌ها در دسترس نیست
                    }
                    ?>
                </ul>
            </nav>

            <div class="header-actions">
                <button type="button" class="icon-btn" id="searchToggle" aria-label="جستجو (Ctrl+K)" title="جستجو (Ctrl+K)">
                    <?php echo mijam_icon('search', 18); ?>
                </button>
                <button type="button" class="icon-btn theme-toggle" id="themeToggle"
                        aria-label="تغییر حالت روز/شب" title="تغییر حالت روز/شب"
                        aria-pressed="false">
                    <span class="theme-toggle__icon theme-toggle__icon--sun"><?php echo mijam_icon('sun', 18); ?></span>
                    <span class="theme-toggle__icon theme-toggle__icon--moon"><?php echo mijam_icon('moon', 18); ?></span>
                </button>
                <button type="button" class="icon-btn hamburger" id="hamburgerBtn" aria-label="باز و بسته کردن منو"
                        aria-expanded="false" aria-controls="mainMenu">
                    <span class="hamburger__bar"></span>
                    <span class="hamburger__bar"></span>
                    <span class="hamburger__bar"></span>
                </button>
            </div>

        </div>
    </header>

    <div class="search-palette" id="searchPalette" hidden>
        <div class="search-palette__backdrop" data-close-search></div>
        <div class="search-palette__dialog" role="dialog" aria-modal="true" aria-label="جستجو در سایت">
            <form class="search-palette__form" method="get" action="<?php $this->options->siteUrl(); ?>" role="search">
                <?php echo mijam_icon('search', 20); ?>
                <input type="search" name="s" id="searchPaletteInput"
                       placeholder="چه چیزی را جستجو می‌کنید؟" autocomplete="off"
                       aria-label="عبارت جستجو">
                <button type="button" class="icon-btn search-palette__close" data-close-search aria-label="بستن جستجو">
                    <?php echo mijam_icon('x', 18); ?>
                </button>
            </form>
            <p class="search-palette__hint">
                <kbd>Enter</kbd> برای جستجو · <kbd>Esc</kbd> برای بستن
            </p>
        </div>
    </div>

    <div class="menu-overlay" id="menuOverlay"></div>
