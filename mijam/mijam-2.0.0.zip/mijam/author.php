<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');

/* سایدبار در صفحه نویسنده همیشه فعال است */
$authorName  = (string) $this->author->screenName;
if ($authorName === '') {
    $authorName = (string) $this->author->name;
}
$authorUid = (int) $this->author->uid;
$lastLogin = (int) $this->author->logged;
?>
<main id="main" class="container site-main site-main--with-sidebar">

    <div class="content-area">

        <header class="author-header">
            <div class="author-header__avatar">
                <?php echo mijam_letter_avatar($authorName, 96); ?>
            </div>

            <h1 class="author-header__name"><?php echo mijam_e($authorName); ?></h1>

            <div class="author-header__stats">
                <span class="author-stat">
                    <span class="dot dot--posts"></span>
                    <?php echo number_format(getAuthorPostsCount($authorUid)); ?> نوشته
                </span>
                <span class="author-stat">
                    <span class="dot dot--comments"></span>
                    <?php echo number_format(getAuthorCommentsCount($authorUid)); ?> دیدگاه
                </span>
                <span class="author-stat">
                    <span class="dot dot--join"></span>
                    عضو از: <?php echo jalali_date('Y/m/d', (int) $this->author->created); ?>
                </span>
                <span class="author-stat">
                    <span class="dot dot--login"></span>
                    آخرین بازدید:
                    <?php echo ($lastLogin > 0) ? jalali_date('Y/m/d — H:i', $lastLogin) : '—'; ?>
                </span>
            </div>
        </header>

        <section class="posts-section">
            <header class="posts-section__head">
                <h2 class="posts-section__title">
                    <?php echo mijam_icon('file-text', 18); ?>
                    مطالب <?php echo mijam_e($authorName); ?>
                </h2>
            </header>

            <?php if ($this->have()): ?>
            <div class="post-grid post-grid--fluid">
                <?php while ($this->next()): ?>
                    <?php mijam_post_card($this, ['excerpt_len' => 110]); ?>
                <?php endwhile; ?>
            </div>

            <nav class="clean-pagination" aria-label="ناوبری صفحات">
                <?php $this->pageNav(
                    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>',
                    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>',
                    3,
                    '…',
                    [
                        'wrapTag'   => 'ul',
                        'wrapClass' => 'page-numbers',
                        'itemTag'   => 'li',
                        'textTag'   => 'span',
                    ]
                ); ?>
            </nav>

            <?php else: ?>
            <div class="empty-state">
                <?php echo mijam_icon('user', 48); ?>
                <h2>مطلبی یافت نشد</h2>
                <p>تاکنون هیچ مطلبی از این نویسنده در سایت منتشر نشده است.</p>
            </div>
            <?php endif; ?>
        </section>

    </div>

    <aside class="sidebar" aria-label="نوار کناری">
        <?php $this->need('sidebar.php'); ?>
    </aside>

</main>

<?php $this->need('footer.php'); ?>
