(function () {
    'use strict';

    var SELECTOR = '.single-post__body img, .comment-item__content img';

    /* ---------- آیکون‌های Lucide (اینلاین) ---------- */
    var ICONS = {
        close: '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>',
        zoomIn: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><line x1="21" x2="16.65" y1="21" y2="16.65"/><line x1="11" x2="11" y1="8" y2="14"/><line x1="8" x2="14" y1="11" y2="11"/></svg>',
        zoomOut: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><line x1="21" x2="16.65" y1="21" y2="16.65"/><line x1="8" x2="14" y1="11" y2="11"/></svg>',
        next: '<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>',
        prev: '<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>'
    };

    function el(tag, className, html) {
        var node = document.createElement(tag);
        if (className) { node.className = className; }
        if (html !== undefined) { node.innerHTML = html; }
        return node;
    }

    function clamp(value, min, max) {
        return Math.min(max, Math.max(min, value));
    }

    /* ==================================================================
       کلاس اصلی
       ================================================================== */
    function MijamLightbox() {
        this.groups = new Map(); // Map<groupName, Array<img>>
        this.activeGroup = null;
        this.activeIndex = -1;
        this.isZoomed = false;
        this.zoomScale = 1;
        this.panX = 0;
        this.panY = 0;
        this.lastFocused = null;

        this.collectImages();
        if (this.groups.size === 0) { return; }
        this.buildDom();
        this.bindEvents();
    }

    /* ---------- جمع‌آوری تصاویر و گروه‌بندی ---------- */
    MijamLightbox.prototype.collectImages = function () {
        var self = this;
        var images = document.querySelectorAll(SELECTOR);
        if (!images.length) { return; }

        Array.prototype.forEach.call(images, function (img) {
            var src = img.getAttribute('src');
            if (!src || src.charAt(0) === 'data:') { return; }

            // اگر تصویر داخل لینکی به مقصد دیگری است، مالکیت لینک را نمی‌گیریم
            var link = img.closest('a');
            if (link) {
                var href = link.getAttribute('href') || '';
                if (href !== src) { return; }
            }

            // نام گروه: data-mijam-lightbox یا نام مطلب والد
            var manualGroup = img.getAttribute('data-mijam-lightbox');
            var container = img.closest('.single-post__body, .comment-item__content');
            var group = manualGroup
                || (container ? 'body-' + (container.id || Array.prototype.indexOf.call(document.querySelectorAll('.single-post__body, .comment-item__content'), container)) : 'default');

            if (!self.groups.has(group)) {
                self.groups.set(group, []);
            }
            self.groups.get(group).push(img);
        });

        // نشانه‌گذاری تصاویر — کلیک‌ها با delegation مدیریت می‌شوند
        this.groups.forEach(function (imgs) {
            imgs.forEach(function (img) {
                img.classList.add('mijam-lb-item');
            });
        });
    };

    /* ---------- ساخت DOM ---------- */
    MijamLightbox.prototype.buildDom = function () {
        this.root = el('div', 'lightbox');
        this.root.setAttribute('role', 'dialog');
        this.root.setAttribute('aria-modal', 'true');
        this.root.setAttribute('aria-label', 'نمایش تصویر');
        this.root.hidden = true;

        // نوار ابزار
        this.toolbar = el('div', 'lightbox__toolbar');
        var toolsStart = el('div', 'lightbox__toolbar-group');
        this.btnZoom = el('button', 'lightbox__btn', ICONS.zoomIn);
        this.btnZoom.type = 'button';
        this.btnZoom.setAttribute('aria-label', 'بزرگ‌نمایی');
        this.btnClose = el('button', 'lightbox__btn', ICONS.close);
        this.btnClose.type = 'button';
        this.btnClose.setAttribute('aria-label', 'بستن');
        toolsStart.appendChild(this.btnZoom);
        toolsStart.appendChild(this.btnClose);

        this.counter = el('span', 'lightbox__counter-bar');
        this.counter.textContent = '— / —';

        this.toolbar.appendChild(toolsStart);
        this.toolbar.appendChild(this.counter);

        // شکل اصلی
        this.figure = el('figure', 'lightbox__figure');
        this.imgWrap = el('div', 'lightbox__img-wrap');

        this.spinner = el('div', 'lightbox__spinner');
        this.spinner.hidden = true;

        this.img = el('img', 'lightbox__img');
        this.img.alt = '';

        this.imgWrap.appendChild(this.spinner);
        this.imgWrap.appendChild(this.img);

        this.caption = el('figcaption', 'lightbox__caption');

        this.figure.appendChild(this.imgWrap);
        this.figure.appendChild(this.caption);

        // فلش‌ها
        this.btnPrev = el('button', 'lightbox__arrow lightbox__arrow--prev', ICONS.prev);
        this.btnPrev.type = 'button';
        this.btnPrev.setAttribute('aria-label', 'تصویر قبلی');
        this.btnNext = el('button', 'lightbox__arrow', ICONS.next);
        this.btnNext.type = 'button';
        this.btnNext.setAttribute('aria-label', 'تصویر بعدی');

        this.root.appendChild(this.toolbar);
        this.root.appendChild(this.figure);
        this.root.appendChild(this.btnPrev);
        this.root.appendChild(this.btnNext);

        document.body.appendChild(this.root);
    };

    /* ---------- رویدادها ---------- */
    MijamLightbox.prototype.bindEvents = function () {
        var self = this;

        // باز کردن با کلیک روی تصویر (delegation)
        document.addEventListener('click', function (event) {
            var target = event.target;
            if (!target || !target.classList || !target.classList.contains('mijam-lb-item')) { return; }
            event.preventDefault();
            self.openFor(target);
        });

        this.btnClose.addEventListener('click', function () { self.close(); });
        this.btnPrev.addEventListener('click', function (e) { e.stopPropagation(); self.navigate(-1); });
        this.btnNext.addEventListener('click', function (e) { e.stopPropagation(); self.navigate(1); });
        this.btnZoom.addEventListener('click', function () { self.toggleZoom(); });

        // کلیک روی پس‌زمینه = بستن (کلیک روی تصویر خودش زوم است)
        this.root.addEventListener('click', function (event) {
            if (event.target === self.root) { self.close(); }
        });

        // کیبورد
        document.addEventListener('keydown', function (event) {
            if (self.root.hidden) { return; }

            var isRtl = getComputedStyle(document.documentElement).direction === 'rtl';

            switch (event.key) {
                case 'Escape':
                    self.close();
                    break;
                case 'ArrowLeft':
                    self.navigate(isRtl ? 1 : -1);
                    break;
                case 'ArrowRight':
                    self.navigate(isRtl ? -1 : 1);
                    break;
                case 'Home':
                    self.show(0);
                    break;
                case 'End':
                    self.show(self.currentList().length - 1);
                    break;
                case '+':
                case '=':
                    self.setZoom(self.zoomScale + 0.5);
                    break;
                case '-':
                    self.setZoom(self.zoomScale - 0.5);
                    break;
            }
        });

        // زوم با اسکرول
        this.imgWrap.addEventListener('wheel', function (event) {
            if (self.root.hidden) { return; }
            event.preventDefault();
            var factor = event.deltaY < 0 ? 0.25 : -0.25;
            self.setZoom(self.zoomScale + factor);
        }, { passive: false });

        // کلیک روی تصویر = تغییر زوم
        this.img.addEventListener('click', function (event) {
            event.stopPropagation();
            self.toggleZoom();
        });

        // درگ برای جابه‌جایی در حالت زوم
        this.bindPan();

        // سوایپ لمسی (آگاه از RTL)
        this.bindSwipe();
    };

    /* ---------- درگ ---------- */
    MijamLightbox.prototype.bindPan = function () {
        var self = this;
        var dragging = false;
        var startX = 0;
        var startY = 0;

        this.img.addEventListener('mousedown', function (event) {
            if (!self.isZoomed) { return; }
            dragging = true;
            startX = event.pageX - self.panX;
            startY = event.pageY - self.panY;
            event.preventDefault();
        });

        document.addEventListener('mousemove', function (event) {
            if (!dragging) { return; }
            self.panX = event.pageX - startX;
            self.panY = event.pageY - startY;
            self.applyTransform();
        });

        document.addEventListener('mouseup', function () { dragging = false; });
    };

    /* ---------- سوایپ ---------- */
    MijamLightbox.prototype.bindSwipe = function () {
        var self = this;
        var startX = 0;
        var startY = 0;
        var tracking = false;

        this.root.addEventListener('touchstart', function (event) {
            if (event.touches.length !== 1) { tracking = false; return; }
            tracking = true;
            startX = event.touches[0].clientX;
            startY = event.touches[0].clientY;
        }, { passive: true });

        this.root.addEventListener('touchend', function (event) {
            if (!tracking || self.isZoomed) { tracking = false; return; }
            tracking = false;

            var touch = event.changedTouches[0];
            var dx = touch.clientX - startX;
            var dy = touch.clientY - startY;

            if (Math.abs(dx) < 48 || Math.abs(dy) > Math.abs(dx)) { return; }

            // در RTL حرکت به چپ (dx منفی) یعنی رفتن به تصویر بعدی
            var isRtl = getComputedStyle(document.documentElement).direction === 'rtl';
            if (isRtl) {
                self.navigate(dx < 0 ? 1 : -1);
            } else {
                self.navigate(dx > 0 ? -1 : 1);
            }
        }, { passive: true });
    };

    /* ---------- کنترل ---------- */
    MijamLightbox.prototype.currentList = function () {
        return this.activeGroup ? this.groups.get(this.activeGroup) : [];
    };

    MijamLightbox.prototype.openFor = function (img) {
        var self = this;
        this.groups.forEach(function (imgs, name) {
            if (imgs.indexOf(img) !== -1) { self.activeGroup = name; }
        });
        this.lastFocused = document.activeElement;
        this.show(this.currentList().indexOf(img));
    };

    MijamLightbox.prototype.show = function (index) {
        var list = this.currentList();
        if (!list.length) { return; }

        this.activeIndex = clamp(index, 0, list.length - 1);
        var source = list[this.activeIndex];

        this.resetZoom();

        // نمایش اسپینر تا بارگذاری کامل
        this.spinner.hidden = false;
        this.img.classList.remove('is-loaded');
        this.img.src = source.getAttribute('src');
        this.img.alt = source.alt || 'تصویر';

        var self = this;
        this.img.onload = function () {
            self.spinner.hidden = true;
            self.img.classList.add('is-loaded');
        };
        this.img.onerror = function () {
            self.spinner.hidden = true;
        };

        this.caption.textContent = source.alt || '';
        this.caption.style.display = source.alt ? '' : 'none';

        this.counter.textContent = (this.activeIndex + 1) + ' / ' + list.length;
        this.btnPrev.style.display = list.length > 1 ? '' : 'none';
        this.btnNext.style.display = list.length > 1 ? '' : 'none';

        // نمایش روت با کلاس
        this.root.hidden = false;
        requestAnimationFrame(function () {
            self.root.classList.add('is-open');
        });

        document.body.classList.add('no-scroll');
        this.btnClose.focus();

        // پیش‌بارگذاری تصاویر همسایه
        this.preload(this.activeIndex + 1);
        this.preload(this.activeIndex - 1);
    };

    MijamLightbox.prototype.preload = function (index) {
        var list = this.currentList();
        if (index < 0 || index >= list.length) { return; }
        var src = list[index].getAttribute('src');
        if (!src) { return; }
        var loader = new Image();
        loader.src = src;
    };

    MijamLightbox.prototype.navigate = function (step) {
        var list = this.currentList();
        if (list.length < 2) { return; }
        var next = (this.activeIndex + step + list.length) % list.length;
        this.show(next);
    };

    MijamLightbox.prototype.close = function () {
        var self = this;
        this.root.classList.remove('is-open');
        document.body.classList.remove('no-scroll');
        this.resetZoom();

        // کمی تأخیر تا انیمیشن بسته شدن دیده شود
        setTimeout(function () {
            self.root.hidden = true;
        }, 260);

        if (this.lastFocused && typeof this.lastFocused.focus === 'function') {
            this.lastFocused.focus();
        }
    };

    /* ---------- زوم ---------- */
    MijamLightbox.prototype.setZoom = function (scale) {
        this.zoomScale = clamp(scale, 1, 4);
        this.isZoomed = this.zoomScale > 1;
        this.imgWrap.classList.toggle('is-zoomed', this.isZoomed);
        this.btnZoom.innerHTML = this.isZoomed ? ICONS.zoomOut : ICONS.zoomIn;
        this.btnZoom.setAttribute('aria-label', this.isZoomed ? 'کوچک‌نمایی' : 'بزرگ‌نمایی');
        if (!this.isZoomed) {
            this.panX = 0;
            this.panY = 0;
        }
        this.applyTransform();
    };

    MijamLightbox.prototype.toggleZoom = function () {
        this.setZoom(this.isZoomed ? 1 : 2);
    };

    MijamLightbox.prototype.resetZoom = function () {
        this.zoomScale = 1;
        this.isZoomed = false;
        this.panX = 0;
        this.panY = 0;
        this.imgWrap.classList.remove('is-zoomed');
        this.btnZoom.innerHTML = ICONS.zoomIn;
        this.applyTransform();
    };

    MijamLightbox.prototype.applyTransform = function () {
        var value = 'scale(' + this.zoomScale + ') translate(' + this.panX + 'px, ' + this.panY + 'px)';
        this.img.style.transform = this.isZoomed ? value : '';
        this.img.style.transformOrigin = 'center center';
    };

    /* ---------- راه‌اندازی ---------- */
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            window.MijamLightbox = new MijamLightbox();
        });
    } else {
        window.MijamLightbox = new MijamLightbox();
    }
})();
