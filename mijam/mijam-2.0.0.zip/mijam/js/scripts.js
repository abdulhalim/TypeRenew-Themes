(function () {
    'use strict';

    var prefersReducedMotion = window.matchMedia
        && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* ================================================================
       ۰) اعلان کوتاه (Toast)
       ================================================================ */
    var toastTimer = null;

    function showToast(message) {
        var toast = document.getElementById('mijamToast');
        if (!toast) { return; }
        toast.textContent = message;
        toast.classList.add('is-visible');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function () {
            toast.classList.remove('is-visible');
        }, 2400);
    }

    window.mijamToast = showToast;

    /* ================================================================
       ۱) حالت روز/شب
       ================================================================ */
    function applyTheme(theme, announce) {
        document.documentElement.setAttribute('data-theme', theme);
        document.documentElement.style.colorScheme = theme;
        try {
            localStorage.setItem('mijam-theme', theme);
        } catch (e) { /* حالت خصوصی مرورگر */ }

        // هماهنگ‌سازی رنگ نوار مرورگر
        var metas = document.querySelectorAll('meta[name="theme-color"]');
        var color = theme === 'dark' ? '#14161d' : '#f6f7fb';
        Array.prototype.forEach.call(metas, function (meta) {
            meta.setAttribute('content', color);
            meta.removeAttribute('media');
        });

        var toggle = document.getElementById('themeToggle');
        if (toggle) {
            toggle.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false');
        }

        // تعویض لوگوی سفارشی روشن/تیره (لوگوی پیش‌فرض SVG خودش تطبیقی است)
        var themedLogos = document.querySelectorAll('img[data-logo-dark]');
        Array.prototype.forEach.call(themedLogos, function (img) {
            var darkSrc = img.getAttribute('data-logo-dark');
            var lightSrc = img.getAttribute('data-logo-light') || img.src;
            if (darkSrc && lightSrc) {
                img.src = theme === 'dark' ? darkSrc : lightSrc;
            }
        });

        if (announce) {
            showToast(theme === 'dark' ? 'حالت تیره فعال شد' : 'حالت روشن فعال شد');
        }
    }

    function initThemeToggle() {
        var toggle = document.getElementById('themeToggle');
        if (!toggle) { return; }

        toggle.addEventListener('click', function () {
            var current = document.documentElement.getAttribute('data-theme');
            applyTheme(current === 'dark' ? 'light' : 'dark', true);
        });

        // همگام‌سازی با تغییر سیستم فقط وقتی کاربر انتخابی ثبت نکرده است
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function (event) {
            var saved = null;
            try { saved = localStorage.getItem('mijam-theme'); } catch (e) { /* noop */ }
            if (saved !== 'light' && saved !== 'dark') {
                applyTheme(event.matches ? 'dark' : 'light', false);
            }
        });
    }

    /* ================================================================
       ۲) منوی موبایل
       ================================================================ */
    function initMobileMenu() {
        var hamburger = document.getElementById('hamburgerBtn');
        var menu = document.getElementById('mainMenu');
        if (!hamburger || !menu) { return; }

        function setMenu(open) {
            hamburger.setAttribute('aria-expanded', open ? 'true' : 'false');
            document.body.classList.toggle('menu-open', open);
            document.body.classList.toggle('no-scroll', open);
        }

        hamburger.addEventListener('click', function () {
            setMenu(hamburger.getAttribute('aria-expanded') !== 'true');
        });

        // بستن با کلیک روی پس‌زمینه
        var overlay = document.getElementById('menuOverlay');
        if (overlay) {
            overlay.addEventListener('click', function () { setMenu(false); });
        }

        // بستن بعد از انتخاب هر آیتم (تجربه موبایل بهتر)
        menu.addEventListener('click', function (event) {
            if (event.target.closest('a')) { setMenu(false); }
        });

        // بستن با Esc
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && document.body.classList.contains('menu-open')) {
                setMenu(false);
                hamburger.focus();
            }
        });
    }

    /* ================================================================
       ۳) پوشش جستجو (Ctrl+K)
       ================================================================ */
    function initSearchPalette() {
        var palette = document.getElementById('searchPalette');
        var input = document.getElementById('searchPaletteInput');
        if (!palette || !input) { return; }

        function open() {
            palette.hidden = false;
            document.body.classList.add('no-scroll');
            requestAnimationFrame(function () { input.focus(); });
        }

        function close() {
            palette.hidden = true;
            document.body.classList.remove('no-scroll');
        }

        var toggle = document.getElementById('searchToggle');
        if (toggle) {
            toggle.addEventListener('click', open);
        }

        // دکمه جستجو در صفحه ۴۰۴
        var errorBtn = document.getElementById('errorSearchBtn');
        if (errorBtn) {
            errorBtn.addEventListener('click', open);
        }

        palette.addEventListener('click', function (event) {
            if (event.target.hasAttribute('data-close-search')) { close(); }
        });

        document.addEventListener('keydown', function (event) {
            // Ctrl+K یا Cmd+K
            if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
                event.preventDefault();
                palette.hidden ? open() : close();
                return;
            }
            if (event.key === 'Escape' && !palette.hidden) {
                close();
            }
        });
    }

    /* ================================================================
       ۴) فهرست مطالب (TOC) + scrollspy
       ================================================================ */
    function initToc() {
        var container = document.getElementById('tocContainer');
        var nav = document.getElementById('tocNav');
        var toggle = document.getElementById('tocToggle');
        var body = document.getElementById('postBody');
        if (!container || !nav || !toggle || !body) { return; }

        var headings = body.querySelectorAll('h2, h3');
        if (!headings.length) { return; }

        var links = [];

        Array.prototype.forEach.call(headings, function (heading, index) {
            if (!heading.id) {
                heading.id = 'mijam-heading-' + (index + 1);
            }

            var link = document.createElement('a');
            link.href = '#' + heading.id;
            link.textContent = heading.textContent;
            link.className = 'toc-link toc-level-' + heading.tagName.toLowerCase();
            link.addEventListener('click', function (event) {
                event.preventDefault();
                var top = heading.getBoundingClientRect().top + window.pageYOffset - 84;
                window.scrollTo({ top: top, behavior: prefersReducedMotion ? 'auto' : 'smooth' });
                // با تاریخچه تمیز: بدون تغییر hash
            });
            nav.appendChild(link);
            links.push({ link: link, heading: heading });
        });

        container.hidden = false;
        toggle.setAttribute('aria-expanded', 'true');

        toggle.addEventListener('click', function () {
            var expanded = toggle.getAttribute('aria-expanded') === 'true';
            toggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
            nav.hidden = expanded;
        });

        /* --- scrollspy --- */
        var ticking = false;

        function updateActiveLink() {
            var scrollPos = window.pageYOffset + 120;
            var current = -1;

            for (var i = 0; i < links.length; i++) {
                if (links[i].heading.offsetTop <= scrollPos) { current = i; }
            }

            for (var j = 0; j < links.length; j++) {
                links[j].link.classList.toggle('is-active', j === current);
            }
            ticking = false;
        }

        window.addEventListener('scroll', function () {
            if (!ticking) {
                ticking = true;
                requestAnimationFrame(updateActiveLink);
            }
        }, { passive: true });

        updateActiveLink();
    }

    /* ================================================================
       ۵) نوار پیشرفت مطالعه
       ================================================================ */
    function initReadingProgress() {
        var bar = document.getElementById('readingProgressBar');
        var body = document.getElementById('postBody');
        if (!bar || !body) { return; }

        var ticking = false;

        function update() {
            var rect = body.getBoundingClientRect();
            var total = rect.height - window.innerHeight + 80;
            var done = Math.min(Math.max(-rect.top + 60, 0), Math.max(total, 1));
            bar.style.width = Math.round((done / Math.max(total, 1)) * 100) + '%';
            ticking = false;
        }

        window.addEventListener('scroll', function () {
            if (!ticking) {
                ticking = true;
                requestAnimationFrame(update);
            }
        }, { passive: true });

        window.addEventListener('resize', update);
        update();
    }

    /* ================================================================
       ۶) بازگشت به بالا
       ================================================================ */
    function initBackToTop() {
        var btn = document.getElementById('backToTopBtn');
        if (!btn) { return; }

        var ticking = false;

        function update() {
            btn.classList.toggle('is-visible', window.pageYOffset > 320);
            ticking = false;
        }

        window.addEventListener('scroll', function () {
            if (!ticking) {
                ticking = true;
                requestAnimationFrame(update);
            }
        }, { passive: true });

        btn.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: prefersReducedMotion ? 'auto' : 'smooth' });
        });

        update();
    }

    /* ================================================================
       ۷) کپی بلوک‌های کد
       ================================================================ */
    function copyText(text) {
        if (navigator.clipboard && window.isSecureContext) {
            return navigator.clipboard.writeText(text);
        }

        // پشتیبان برای HTTP (بدون API کلیپ‌بورد امن)
        return new Promise(function (resolve, reject) {
            var textarea = document.createElement('textarea');
            textarea.value = text;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            try {
                document.execCommand('copy') ? resolve() : reject();
            } catch (e) {
                reject(e);
            } finally {
                document.body.removeChild(textarea);
            }
        });
    }

    function initCodeCopy() {
        var blocks = document.querySelectorAll('.single-post__body pre');
        if (!blocks.length) { return; }

        Array.prototype.forEach.call(blocks, function (pre) {
            var code = pre.querySelector('code');
            if (!code) { return; }

            var button = document.createElement('button');
            button.type = 'button';
            button.className = 'copy-button';
            button.setAttribute('aria-label', 'کپی کد');
            button.innerHTML =
                '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>'
                + '<span>کپی</span>';
            pre.appendChild(button);

            button.addEventListener('click', function () {
                copyText(code.innerText).then(function () {
                    button.classList.add('is-copied');
                    button.querySelector('span').textContent = 'کپی شد!';
                    showToast('کد در کلیپ‌بورد کپی شد');
                    setTimeout(function () {
                        button.classList.remove('is-copied');
                        button.querySelector('span').textContent = 'کپی';
                    }, 1600);
                }).catch(function () {
                    showToast('کپی انجام نشد — لطفا دستی انتخاب و کپی کنید');
                });
            });
        });
    }

    /* ================================================================
       ۸) کپی لینک نوشته (دکمه اشتراک)
       ================================================================ */
    function initShareCopy() {
        var buttons = document.querySelectorAll('.js-copy-link');
        if (!buttons.length) { return; }

        Array.prototype.forEach.call(buttons, function (button) {
            button.addEventListener('click', function () {
                var link = button.getAttribute('data-link') || window.location.href;
                copyText(link).then(function () {
                    showToast('لینک نوشته کپی شد');
                }).catch(function () {
                    showToast('کپی انجام نشد');
                });
            });
        });
    }

    /* ================================================================
       ۹) هایلایت کد
       ================================================================ */
    function initHighlight() {
        if (typeof hljs === 'undefined') { return; }
        var blocks = document.querySelectorAll('pre code');
        Array.prototype.forEach.call(blocks, function (block) {
            try {
                hljs.highlightElement(block);
            } catch (e) { /* کد ناشناس — بدون هایلایت */ }
        });
    }

    /* ================================================================
       راه‌اندازی
       ================================================================ */
    function init() {
        initThemeToggle();
        initMobileMenu();
        initSearchPalette();
        initToc();
        initReadingProgress();
        initBackToTop();
        initCodeCopy();
        initShareCopy();
        initHighlight();

        // اعمال لوگوی درست در نخستین بارگذاری (اگر تم ذخیره‌شده تیره باشد)
        applyTheme(document.documentElement.getAttribute('data-theme') || 'light', false);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
