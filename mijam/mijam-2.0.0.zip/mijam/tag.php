<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');

/* سایدبار در صفحات برچسب همیشه فعال است */
$tagMid      = getArchiveTagId($this);
$tagColor    = getTagColor($tagMid);
?>
<main id="main" class="container site-main site-main--with-sidebar">

    <div class="content-area">

        <header class="archive-header">
            <h1 class="archive-header__title">
                <span class="dot" style="background-color: <?php echo $tagColor; ?>"></span>
                برچسب: <?php $this->archiveTitle([], '', ''); ?>
            </h1>
            <div class="archive-header__count">
                <?php echo number_format((int) $this->getTotal()); ?> مطلب
            </div>
        </header>

        <?php if ($this->have()): ?>
        <section class="posts-section">
            <div class="post-grid post-grid--fluid">
                <?php while ($this->next()): ?>
                    <?php mijam_post_card($this, ['excerpt_len' => 110]); ?>
                <?php endwhile; ?>
            </div>
        </section>

        <nav class="clean-pagination" aria-label="ناوبری صفحات">
            <?php $this->pageNav(
                '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>',
                '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>',
                3,
                '…',
                [
                    'wrapTag'   => 'ul',
                    'wrapClass' => 'page-numbers',
                    'itemTag'   => 'li',
                    'textTag'   => 'span',
                ]
            ); ?>
        </nav>

        <?php else: ?>
        <div class="empty-state">
            <?php echo mijam_icon('tag', 48); ?>
            <h2>نتیجه‌ای برای این برچسب پیدا نشد</h2>
            <p>مطلبی با این برچسب در سایت منتشر نشده است.</p>
        </div>
        <?php endif; ?>

    </div>

    <aside class="sidebar" aria-label="نوار کناری">
        <?php $this->need('sidebar.php'); ?>
    </aside>

</main>

<?php $this->need('footer.php'); ?>
