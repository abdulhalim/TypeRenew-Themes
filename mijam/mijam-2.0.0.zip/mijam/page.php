<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');

/* سایدبار در برگه‌ها همیشه فعال است */
?>
<main id="main" class="container site-main site-main--with-sidebar">

    <div class="content-area">
        <article class="single-post single-post--page">

            <div class="single-post__content">
                <h1 class="single-post__title"><?php $this->title(); ?></h1>

                <div class="single-post__meta">
                    <div class="single-post__meta-info">
                        <span class="meta-chip">
                            <?php echo mijam_icon('calendar', 14); ?>
                            <time datetime="<?php echo date('c', (int) $this->created); ?>">
                                <?php echo jalali_date('Y/m/d', (int) $this->created); ?>
                            </time>
                        </span>
                    </div>
                </div>

                <div class="single-post__body" id="postBody">
                    <?php $this->content(); ?>
                </div>
            </div>

        </article>

        <?php $this->need('comments.php'); ?>
    </div>

    <aside class="sidebar" aria-label="نوار کناری">
        <?php $this->need('sidebar.php'); ?>
    </aside>

</main>

<?php $this->need('footer.php'); ?>
