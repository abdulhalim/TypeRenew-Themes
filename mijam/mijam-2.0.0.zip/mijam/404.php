<?php
if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');
?>
<main id="main" class="container site-main">

    <div class="content-area">
        <div class="error-page">
            <div class="error-page__code" aria-hidden="true">۴۰۴</div>

            <div class="error-page__icon">
                <?php echo mijam_icon('alert-circle', 56); ?>
            </div>

            <h1 class="error-page__title">صفحه مورد نظر پیدا نشد!</h1>

            <p class="error-page__message">
                آدرسی که دنبالش بودید حذف شده، جابه‌جا شده یا اصلاً وجود نداشته است.
                می‌توانید به صفحه اصلی برگردید یا دنبال مطلب مورد نظرتان بگردید.
            </p>

            <div class="error-page__actions">
                <a href="<?php $this->options->siteUrl(); ?>" class="btn btn--primary">
                    <?php echo mijam_icon('home', 16); ?>
                    بازگشت به صفحه اصلی
                </a>
                <button type="button" class="btn btn--ghost" id="errorSearchBtn">
                    <?php echo mijam_icon('search', 16); ?>
                    جستجو در سایت
                </button>
            </div>
        </div>
    </div>

</main>

<?php $this->need('footer.php'); ?>
