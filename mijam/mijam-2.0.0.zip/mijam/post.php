<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');

$showCover   = (mijam_opt('showPostCover', '1') == '1');
$showToc     = (mijam_opt('showToc', '1') == '1');
$showShare   = (mijam_opt('showShareButtons', '1') == '1');
$showRelated = (mijam_opt('showRelatedPosts', '1') == '1');
/* سایدبار در نوشته‌ها همیشه فعال است — تنظیم فقط مخصوص صفحه اصلی است */

$coverUrl = '';
if ($showCover) {
    $coverUrl = mijam_post_thumbnail($this);
}

/* بازدید نوشته — از ستون views (سیستم آمار قالب) */
$postViews = mijam_get_views($this);

/* مطالب مرتبط: ۳ یا ۴ کارت — همه در یک ردیف (گرید داینامیک) */
$relatedCount = (int) mijam_opt('relatedPostsCount', 3);
if ($relatedCount < 1) {
    $relatedCount = 1;
}
if ($relatedCount > 12) {
    $relatedCount = 12;
}

$canEdit = false;
try {
    if ($this->user->hasLogin()) {
        $canEdit = $this->user->groupCheck('administrator')
            || ((int) $this->author->uid === (int) $this->user->uid);
    }
} catch (Throwable $e) {
    $canEdit = false;
}

$authorName = (string) $this->author->screenName;
if ($authorName === '') {
    $authorName = (string) $this->author->name;
}

$shareUrl = '';
try {
    $shareUrl = (string) $this->permalink;
} catch (Throwable $e) {
    $shareUrl = '';
}
$shareText = (string) $this->title;
?>
<main id="main" class="container site-main site-main--with-sidebar">

    <div class="content-area">
        <article class="single-post">

            <?php if ($showCover && $coverUrl !== ''): ?>
            <div class="single-post__cover">
                <img src="<?php echo mijam_e($coverUrl); ?>" alt="<?php $this->title(); ?>">
            </div>
            <?php endif; ?>

            <div class="single-post__content">

                <?php if ($canEdit): ?>
                <div class="single-post__admin-bar">
                    <a class="btn btn--ghost btn--sm" href="<?php $this->options->adminUrl('write-post.php?cid=' . (int) $this->cid); ?>">
                        <?php echo mijam_icon('pencil', 14); ?>
                        ویرایش نوشته
                    </a>
                </div>
                <?php endif; ?>

                <h1 class="single-post__title"><?php $this->title(); ?></h1>

                <div class="single-post__meta">
                    <a href="<?php $this->author->permalink(); ?>" class="post-card__author post-card__author--lg">
                        <?php echo mijam_letter_avatar($authorName, 36); ?>
                        <span><?php echo mijam_e($authorName); ?></span>
                    </a>

                    <div class="single-post__meta-info">
                        <span class="meta-chip">
                            <?php echo mijam_icon('calendar', 14); ?>
                            <time datetime="<?php echo date('c', (int) $this->created); ?>">
                                <?php echo jalali_date('Y/m/d', (int) $this->created); ?>
                            </time>
                        </span>
                        <span class="meta-chip">
                            <?php echo mijam_icon('clock', 14); ?>
                            <span><?php echo mijam_reading_time($this); ?> دقیقه مطالعه</span>
                        </span>
                        <?php if ($this->category): ?>
                        <span class="meta-chip meta-chip--category">
                            <?php echo mijam_icon('folder', 14); ?>
                            <?php $this->category('، '); ?>
                        </span>
                        <?php endif; ?>
                        <?php if ($postViews > 0): ?>
                        <span class="meta-chip meta-chip--views">
                            <?php echo mijam_icon('eye', 14); ?>
                            <span><?php echo number_format($postViews); ?> بازدید</span>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($showToc): ?>
                <div class="toc-container" id="tocContainer" hidden>
                    <button type="button" class="toc-toggle" id="tocToggle" aria-expanded="false" aria-controls="tocNav">
                        <?php echo mijam_icon('list-tree', 16); ?>
                        <span>فهرست مطالب</span>
                        <?php echo mijam_icon('chevron-left', 14, 'toc-toggle__chevron'); ?>
                    </button>
                    <nav class="toc-nav" id="tocNav" aria-label="فهرست مطالب نوشته"></nav>
                </div>
                <?php endif; ?>

                <div class="single-post__body" id="postBody">
                    <?php $this->content(); ?>
                </div>

                <?php mijam_post_tags_html($this); ?>

                <?php if ($showShare && $shareUrl !== ''): ?>
                <div class="post-share-box">
                    <span class="post-share-box__title">
                        <?php echo mijam_icon('share-2', 16); ?>
                        اشتراک‌گذاری:
                    </span>
                    <div class="post-share-box__buttons">
                        <a href="https://t.me/share/url?url=<?php echo urlencode($shareUrl); ?>&text=<?php echo urlencode($shareText); ?>"
                           target="_blank" rel="noopener" class="share-btn share-btn--telegram"
                           title="اشتراک در تلگرام" aria-label="اشتراک در تلگرام">
                            <?php echo mijam_icon('send', 18); ?>
                        </a>
                        <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode($shareUrl); ?>&text=<?php echo urlencode($shareText); ?>"
                           target="_blank" rel="noopener" class="share-btn share-btn--twitter"
                           title="اشتراک در توییتر" aria-label="اشتراک در توییتر">
                            <?php echo mijam_icon('twitter', 18); ?>
                        </a>
                        <a href="https://api.whatsapp.com/send?text=<?php echo urlencode($shareText . ' ' . $shareUrl); ?>"
                           target="_blank" rel="noopener" class="share-btn share-btn--whatsapp"
                           title="ارسال به واتس‌اپ" aria-label="ارسال به واتس‌اپ">
                            <?php echo mijam_icon('message-circle', 18); ?>
                        </a>
                        <button type="button" class="share-btn share-btn--copy js-copy-link"
                                data-link="<?php echo mijam_e($shareUrl); ?>"
                                title="کپی لینک نوشته" aria-label="کپی لینک نوشته">
                            <?php echo mijam_icon('link', 18); ?>
                        </button>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </article>

        <nav class="post-navigation" aria-label="ناوبری مطالب">
            <div class="post-navigation__item post-navigation__prev">
                <?php echo mijam_icon('arrow-right', 16); ?>
                <?php $this->thePrev('%s', '<span class="post-navigation__empty">مطلب قبلی وجود ندارد</span>'); ?>
            </div>
            <div class="post-navigation__item post-navigation__next">
                <?php $this->theNext('%s', '<span class="post-navigation__empty">مطلب بعدی وجود ندارد</span>'); ?>
                <?php echo mijam_icon('arrow-left', 16); ?>
            </div>
        </nav>

        <?php
        if ($showRelated):
            $relatedPosts = null;
            try {
                $this->related($relatedCount)->to($relatedPosts);
            } catch (Throwable $e) {
                $relatedPosts = null;
            }

            /* رندر کارت‌ها + شمارش واقعی → همه در یک ردیف هم‌اندازه */
            $relatedCards = '';
            $relatedShown = 0;
            $relatedTitle = 'مطالب مرتبط';

            if ($relatedPosts && $relatedPosts->have()) {
                ob_start();
                while ($relatedPosts->next()) {
                    mijam_post_card($relatedPosts, ['show_excerpt' => false]);
                    $relatedShown++;
                }
                $relatedCards = (string) ob_get_clean();
            } else {
                $fallbackPosts = null;
                try {
                    $this->widget('Widget_Contents_Post_Recent@related-fallback', 'pageSize=' . $relatedCount)->to($fallbackPosts);
                } catch (Throwable $e) {
                    $fallbackPosts = null;
                }
                if ($fallbackPosts && $fallbackPosts->have()) {
                    $relatedTitle = 'مطالب پیشنهادی';
                    ob_start();
                    while ($fallbackPosts->next()) {
                        mijam_post_card($fallbackPosts, ['show_excerpt' => false]);
                        $relatedShown++;
                    }
                    $relatedCards = (string) ob_get_clean();
                }
            }

            /* ستون‌ها = تعداد کارت‌ها (تا سقف ۴) — ۵ کارت یا بیشتر: ۳ ستون چند‌ردیفی متوازن */
            $relatedColumns = ($relatedShown > 4) ? 3 : max(1, $relatedShown);
        ?>
            <?php if ($relatedCards !== ''): ?>
            <section class="related-posts" aria-label="<?php echo $relatedTitle === 'مطالب مرتبط' ? 'مطالب مرتبط' : 'مطالب پیشنهادی'; ?>">
                <h2 class="related-posts__title">
                    <?php echo mijam_icon('book-open', 18); ?>
                    <?php echo $relatedTitle; ?>
                </h2>
                <div class="post-grid post-grid--related" style="--related-count: <?php echo (int) $relatedColumns; ?>">
                    <?php echo $relatedCards; ?>
                </div>
            </section>
            <?php endif; ?>
        <?php endif; ?>

        <?php $this->need('comments.php'); ?>
    </div>

    <aside class="sidebar" aria-label="نوار کناری">
        <?php $this->need('sidebar.php'); ?>
    </aside>

</main>

<?php $this->need('footer.php'); ?>
