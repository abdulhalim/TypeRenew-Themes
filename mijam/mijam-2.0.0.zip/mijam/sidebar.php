<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
?>
<section class="widget widget--search" aria-label="جستجو در سایت">
    <form method="get" action="<?php $this->options->siteUrl(); ?>" role="search" class="widget-search">
        <?php echo mijam_icon('search', 16); ?>
        <input type="search" name="s" class="widget-search__input" placeholder="جستجو…" aria-label="جستجو" autocomplete="off">
    </form>
</section>

<section class="widget" aria-label="آخرین نوشته‌ها">
    <h3 class="widget-title"><?php echo mijam_icon('file-text', 16); ?> آخرین نوشته‌ها</h3>
    <ul class="recent-posts-list">
        <?php
        $recentPosts = null;
        try {
            $this->widget('Widget_Contents_Post_Recent@sidebar', 'pageSize=4')->to($recentPosts);
        } catch (Throwable $e) {
            $recentPosts = null;
        }
        ?>
        <?php if ($recentPosts): while ($recentPosts->next()): ?>
        <li class="recent-post-item">
            <a href="<?php $recentPosts->permalink(); ?>" class="recent-post-item__link">
                <img src="<?php echo mijam_e(mijam_post_thumbnail($recentPosts)); ?>"
                     alt="<?php $recentPosts->title(); ?>" class="recent-post-item__thumb" loading="lazy" decoding="async">
                <div class="recent-post-item__info">
                    <span class="recent-post-item__title"><?php $recentPosts->title(); ?></span>
                    <time class="recent-post-item__date">
                        <?php echo jalali_date('Y/m/d', (int) $recentPosts->created); ?>
                    </time>
                </div>
            </a>
        </li>
        <?php endwhile; endif; ?>
    </ul>
</section>

<?php
/* مطالب محبوب — پر بازدیدترین نوشته‌ها (الگوی نیلوفر) */
$showPopular  = (mijam_opt('showPopularPosts', '1') == '1');
$popularCount = (int) mijam_opt('popularPostsCount', 4);
if ($popularCount < 3) {
    $popularCount = 3;
}
if ($popularCount > 6) {
    $popularCount = 6;
}

$popularPosts = null;
if ($showPopular && $popularCount > 0 && class_exists('MijamPopularPosts')) {
    try {
        $this->widget('MijamPopularPosts@sidebar', 'pageSize=' . $popularCount)->to($popularPosts);
    } catch (Throwable $e) {
        $popularPosts = null;
    }
}
?>
<?php if ($popularPosts && $popularPosts->have()): ?>
<section class="widget widget--popular" aria-label="مطالب محبوب">
    <h3 class="widget-title"><?php echo mijam_icon('flame', 16); ?> مطالب محبوب</h3>
    <ol class="popular-list">
        <?php $rank = 0; while ($popularPosts->next()): $rank++; ?>
        <li class="popular-item">
            <a href="<?php $popularPosts->permalink(); ?>" class="popular-item__link">
                <span class="popular-item__rank" aria-hidden="true"><?php echo (int) $rank; ?></span>
                <img src="<?php echo mijam_e(mijam_post_thumbnail($popularPosts)); ?>"
                     alt="<?php $popularPosts->title(); ?>" class="popular-item__thumb" loading="lazy" decoding="async">
                <span class="popular-item__info">
                    <span class="popular-item__title"><?php $popularPosts->title(); ?></span>
                    <span class="popular-item__views">
                        <?php echo mijam_icon('eye', 12); ?>
                        <span><?php echo number_format(mijam_get_views($popularPosts)); ?> بازدید</span>
                    </span>
                </span>
            </a>
        </li>
        <?php endwhile; ?>
    </ol>
</section>
<?php endif; ?>

<section class="widget" aria-label="ابر برچسب‌ها">
    <h3 class="widget-title"><?php echo mijam_icon('tag', 16); ?> برچسب‌ها</h3>
    <div class="tag-cloud">
        <?php
        $sidebarTags = [];
        try {
            $this->widget('Widget_Metas_Tag_Cloud@sidebar')->to($tagCloud);
            while ($tagCloud->next()) {
                $sidebarTags[] = [
                    'name'      => (string) $tagCloud->name,
                    'permalink' => (string) $tagCloud->permalink,
                    'mid'       => (int) $tagCloud->mid,
                ];
            }
        } catch (Throwable $e) {
            $sidebarTags = [];
        }
        shuffle($sidebarTags);
        $sidebarTags = array_slice($sidebarTags, 0, 12);
        foreach ($sidebarTags as $sidebarTag) {
            mijam_tag_chip($sidebarTag);
        }
        ?>
    </div>
</section>

<section class="widget" aria-label="آخرین دیدگاه‌ها">
    <h3 class="widget-title"><?php echo mijam_icon('message-circle', 16); ?> آخرین دیدگاه‌ها</h3>
    <ul class="recent-comments-list">
        <?php
        $recentComments = null;
        try {
            $this->widget('Widget_Comments_Recent@sidebar', 'pageSize=4')->to($recentComments);
        } catch (Throwable $e) {
            $recentComments = null;
        }
        ?>
        <?php if ($recentComments): while ($recentComments->next()): ?>
        <li class="recent-comment-item">
            <!-- permalink() در Typecho خودش لنگر #comment-{coid} را شامل می‌شود -->
            <a href="<?php $recentComments->permalink(); ?>"
               class="recent-comment-item__link">
                <?php echo mijam_letter_avatar((string) $recentComments->author, 38); ?>
                <span class="recent-comment-item__body">
                    <span class="recent-comment-item__author"><?php echo mijam_e((string) $recentComments->author); ?></span>
                    <span class="recent-comment-item__text">
                        <?php echo mijam_e(mijam_excerpt_text((string) $recentComments->text, 48)); ?>
                    </span>
                    <time class="recent-comment-item__date">
                        <?php echo jalali_date('Y/m/d', (int) $recentComments->created); ?>
                    </time>
                </span>
            </a>
        </li>
        <?php endwhile; endif; ?>
    </ul>
</section>
