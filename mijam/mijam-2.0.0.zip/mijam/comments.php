<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
?>
<div class="comments-section" id="comments">
    <?php $this->comments()->to($comments); ?>

    <h2 class="comments-section__title">
        <?php echo mijam_icon('message-square', 20); ?>
        <?php $this->commentsNum('هنوز دیدگاهی ثبت نشده', 'یک دیدگاه', '%d دیدگاه'); ?>
    </h2>

    <?php if ($comments->have()): ?>
    <div class="comments-list-wrapper">
        <?php $comments->listComments([
            'before'          => '<ol class="comment-list">',
            'after'           => '</ol>',
            'replyWord'       => 'پاسخ',
            'commentStatus'   => 'این دیدگاه در انتظار تایید است.',
        ]); ?>

        <?php $comments->pageNav(
            /* در RTL: «قبلی» سمت راست است و فلش آن به راست اشاره می‌کند */
            '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>',
            '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>'
        ); ?>
    </div>
    <?php endif; ?>

    <?php if ($this->allow('comment')): ?>
    <div id="<?php $this->respondId(); ?>" class="comment-form-block">
        <div class="cancel-comment-reply">
            <?php $comments->cancelReply(); ?>
        </div>

        <h3 class="comment-form-block__title">
            <?php echo mijam_icon('message-circle', 18); ?>
            ارسال دیدگاه
        </h3>

        <form method="post" action="<?php $this->commentUrl(); ?>" id="comment-form" class="comment-form" role="form">
            <?php if ($this->user->hasLogin()): ?>
                <p class="comment-form__notice">
                    شما با نام کاربری «<?php $this->user->screenName(); ?>» وارد شده‌اید.
                    <a href="<?php $this->options->logoutUrl(); ?>" rel="nofollow">خروج از حساب؟</a>
                </p>
            <?php else: ?>
                <div class="comment-form__fields">
                    <div class="comment-form__field">
                        <label for="author">نام <span class="required">*</span></label>
                        <input type="text" name="author" id="author" placeholder="نام شما…"
                               value="<?php $this->remember('author'); ?>" required>
                    </div>
                    <div class="comment-form__field">
                        <label for="mail">ایمیل <span class="required">*</span></label>
                        <input type="email" name="mail" id="mail" placeholder="name@example.com"
                               value="<?php $this->remember('mail'); ?>" required>
                    </div>
                    <div class="comment-form__field">
                        <label for="url">آدرس وب (اختیاری)</label>
                        <input type="url" name="url" id="url" placeholder="https://…"
                               value="<?php $this->remember('url'); ?>">
                    </div>
                </div>
            <?php endif; ?>

            <div class="comment-form__field comment-form__field--full">
                <label for="textarea">متن دیدگاه <span class="required">*</span></label>
                <textarea rows="6" name="text" id="textarea" placeholder="نظر شما درباره این مطلب چیست؟"
                          required><?php $this->remember('text'); ?></textarea>
            </div>

            <button type="submit" class="btn btn--primary">
                <?php echo mijam_icon('send', 16); ?>
                ارسال دیدگاه
            </button>
        </form>
    </div>

    <?php else: ?>
    <p class="comments-closed">
        <?php echo mijam_icon('message-square', 18); ?>
        ارسال دیدگاه برای این نوشته بسته شده است.
    </p>
    <?php endif; ?>
</div>
