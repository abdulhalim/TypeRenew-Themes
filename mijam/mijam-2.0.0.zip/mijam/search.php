<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');

/* سایدبار در نتایج جستجو همیشه فعال است */
$host        = isset($_SERVER['HTTP_HOST']) ? preg_replace('/[^a-zA-Z0-9.\-:]/', '', $_SERVER['HTTP_HOST']) : '';
?>
<main id="main" class="container site-main site-main--with-sidebar">

    <div class="content-area">

        <header class="archive-header">
            <h1 class="archive-header__title">
                <span class="dot dot--search"></span>
                نتیجه جستجو برای: «<?php $this->archiveTitle([], '', ''); ?>»
            </h1>
            <div class="archive-header__count">
                <?php echo number_format((int) $this->getTotal()); ?> نتیجه
            </div>
        </header>

        <?php if ($this->have()): ?>
        <section class="posts-section">
            <div class="post-grid post-grid--fluid">
                <?php while ($this->next()): ?>
                    <?php mijam_post_card($this, ['excerpt_len' => 130]); ?>
                <?php endwhile; ?>
            </div>
        </section>

        <nav class="clean-pagination" aria-label="ناوبری صفحات">
            <?php $this->pageNav(
                '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>',
                '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>',
                3,
                '…',
                [
                    'wrapTag'   => 'ul',
                    'wrapClass' => 'page-numbers',
                    'itemTag'   => 'li',
                    'textTag'   => 'span',
                ]
            ); ?>
        </nav>

        <?php else: ?>

        <div class="empty-state">
            <?php echo mijam_icon('search', 48); ?>
            <h2>چیزی پیدا نشد!</h2>
            <p>با عرض پوزش، جستجوی شما نتیجه‌ای در بر نداشت.</p>
        </div>

        <?php if ($host !== ''): ?>
        <div class="google-search-box">
            <div class="google-search-card">
                <p>شاید در <strong>گوگل</strong> راحت‌تر جوابت را بگیری!</p>
                <form id="google-search" action="https://www.google.com/search" method="get" target="_blank" rel="noopener">
                    <input type="text" name="q"
                           value="site:<?php echo mijam_e($host); ?> <?php $this->archiveTitle([], '', ''); ?>"
                           placeholder="جستجوی گوگل…" required>
                    <button type="submit" class="btn btn--primary">
                        <?php echo mijam_icon('external-link', 16); ?>
                        جستجو در گوگل
                    </button>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <?php endif; ?>

    </div>

    <aside class="sidebar" aria-label="نوار کناری">
        <?php $this->need('sidebar.php'); ?>
    </aside>

</main>

<?php $this->need('footer.php'); ?>
