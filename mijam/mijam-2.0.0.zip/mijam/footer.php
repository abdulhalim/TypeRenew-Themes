<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/* لوگوی فوتر: سفارشی (img) یا نشان پیش‌فرض SVG اینلاین */
$footerLogo      = trim((string) mijam_opt('footerLogoUrl', ''));
$footerLogoDark  = trim((string) mijam_opt('footerLogoDarkUrl', ''));
$defaultFooterLogo = mijam_theme_url('images/footer-logo.png');
if ($footerLogo === $defaultFooterLogo) {
    $footerLogo = '';
}
$footerSiteTitle = '';
try {
    $footerSiteTitle = (string) $this->options->title;
} catch (Throwable $e) {
    $footerSiteTitle = '';
}
?>
    <footer class="site-footer">
        <div class="container footer-container">
            <div class="footer-logo">
                <a href="<?php $this->options->siteUrl(); ?>">
                    <?php if ($footerLogo !== ''): ?>
                        <img src="<?php echo mijam_e($footerLogo); ?>" alt="<?php $this->options->title(); ?>" loading="lazy"
                             data-logo-light="<?php echo mijam_e($footerLogo); ?>"
                             <?php if ($footerLogoDark !== ''): ?>data-logo-dark="<?php echo mijam_e($footerLogoDark); ?>"<?php endif; ?>>
                    <?php else: ?>
                        <?php echo mijam_footer_dots_svg($footerSiteTitle); ?>
                    <?php endif; ?>
                </a>
            </div>

            <p class="footer-text">
                با عشق و چای ☕                
            </p>

            <p class="footer-copy">
                &copy; <?php echo jalali_date('Y'); ?> —
                <?php $this->options->title(); ?>
                · تمام حقوق محفوظ است.
            </p>

            <p class="footer-meta">Mijam <?php echo MIJAM_VERSION; ?></p>
        </div>
    </footer>
</div>

<button type="button" class="back-to-top" id="backToTopBtn" aria-label="بازگشت به بالای صفحه" title="بازگشت به بالا">
    <?php echo mijam_icon('arrow-up', 20); ?>
</button>

<div class="toast" id="mijamToast" role="status" aria-live="polite"></div>

<?php $this->footer(); ?>

<!-- همه اسکریپت‌ها محلی هستند — هیچ وابستگی به CDN وجود ندارد -->
<script src="<?php echo mijam_theme_url('js/highlight.min.js'); ?>" defer></script>
<script src="<?php echo mijam_theme_url('js/lightbox.js'); ?>" defer></script>
<script src="<?php echo mijam_theme_url('js/scripts.js'); ?>?v=<?php echo MIJAM_VERSION; ?>" defer></script>

</body>
</html>
