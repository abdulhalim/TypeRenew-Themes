<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

if (! defined('MIJAM_VERSION')) {
    define('MIJAM_VERSION', '2.0.0');
}

/** منطقه زمانی پیش‌فرض قالب (یک‌بار در کل درخواست) */
if (! date_default_timezone_set('Asia/Tehran')) {
    date_default_timezone_set('UTC');
}

/* ============================================================
 * ۱) موتور تاریخ شمسی (جلالی)
 * الگوریتم استاندارد jdf — دقت تضمین‌شده برای سال‌های ۱۱۷۸ تا ۱۶۳۳ شمسی
 * تبدیل میلادی→جلالی و جلالی→میلادی + تشخیص سال کبیسه
 * ============================================================ */

if (! function_exists('mijam_gregorian_to_jalali')) {
    /**
     * تبدیل تاریخ میلادی به جلالی
     *
     * @param int $gy سال میلادی
     * @param int $gm ماه میلادی (۱-۱۲)
     * @param int $gd روز میلادی (۱-۳۱)
     * @return array [سال، ماه، روز] جلالی
     */
    function mijam_gregorian_to_jalali($gy, $gm, $gd)
    {
        $gDaysInMonth = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

        $gy = (int) $gy;
        $gm = (int) $gm;
        $gd = (int) $gd;

        if ($gm < 1 || $gm > 12) {
            $gm = 1;
        }
        if ($gd < 1 || $gd > 31) {
            $gd = 1;
        }
        if ($gy < 1700 || $gy > 2400) {
            $gy = 2000;
        }

        $gy2 = ($gm > 2) ? ($gy + 1) : $gy;

        $days = 355666 + (365 * $gy)
            + intdiv($gy2 + 3, 4)
            - intdiv($gy2 + 99, 100)
            + intdiv($gy2 + 399, 400)
            + $gd
            + $gDaysInMonth[$gm - 1];

        $jy = -1595 + (33 * intdiv($days, 12053));
        $days %= 12053;

        $jy += 4 * intdiv($days, 1461);
        $days %= 1461;

        if ($days > 365) {
            $jy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }

        if ($days < 186) {
            $jm = 1 + intdiv($days, 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + intdiv($days - 186, 30);
            $jd = 1 + (($days - 186) % 30);
        }

        return [$jy, $jm, $jd];
    }
}

if (! function_exists('mijam_jalali_to_gregorian')) {
    /**
     * تبدیل تاریخ جلالی به میلادی (معکوس)
     *
     * @param int $jy سال شمسی
     * @param int $jm ماه شمسی (۱-۱۲)
     * @param int $jd روز شمسی (۱-۳۱)
     * @return array [سال، ماه، روز] میلادی
     */
    function mijam_jalali_to_gregorian($jy, $jm, $jd)
    {
        $jy = (int) $jy;
        $jm = (int) $jm;
        $jd = (int) $jd;

        if ($jm < 1 || $jm > 12) {
            $jm = 1;
        }
        if ($jd < 1 || $jd > 31) {
            $jd = 1;
        }
        if ($jy < 1178 || $jy > 1633) {
            $jy = 1400;
        }

        $jy += 1595;

        $days = -355668 + (365 * $jy)
            + (intdiv($jy, 33) * 8)
            + intdiv(($jy % 33) + 3, 4)
            + $jd
            + (($jm < 7) ? (($jm - 1) * 31) : ((($jm - 7) * 30) + 186));

        $gy = 400 * intdiv($days, 146097);
        $days %= 146097;

        if ($days > 36524) {
            --$days;
            $gy += 100 * intdiv($days, 36524);
            $days %= 36524;
            if ($days >= 365) {
                ++$days;
            }
        }

        $gy += 4 * intdiv($days, 1461);
        $days %= 1461;

        if ($days > 365) {
            $gy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }

        $gd = $days + 1;

        $gregorianLeap = (($gy % 4 === 0 && $gy % 100 !== 0) || ($gy % 400 === 0));
        $gMonthLen = [31, $gregorianLeap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

        $gm = 0;
        while ($gm < 12 && $gd > $gMonthLen[$gm]) {
            $gd -= $gMonthLen[$gm];
            ++$gm;
        }
        ++$gm;

        return [$gy, $gm, $gd];
    }
}

if (! function_exists('mijam_is_jalali_leap')) {
    /**
     * آیا سال شمسی کبیسه است؟ (اسفند ۳۰ روزه)
     * با محاسبه فاصله نوروز دو سال متوالی — سازگار با خود الگوریتم تبدیل
     *
     * @param int $jy سال شمسی
     * @return bool
     */
    function mijam_is_jalali_leap($jy)
    {
        static $cache = [];

        $jy = (int) $jy;
        if ($jy < 1178 || $jy > 1633) {
            return false;
        }
        if (isset($cache[$jy])) {
            return $cache[$jy];
        }

        $a = mijam_jalali_to_gregorian($jy, 1, 1);
        $b = mijam_jalali_to_gregorian($jy + 1, 1, 1);

        $t1 = mktime(12, 0, 0, $a[1], $a[2], $a[0]);
        $t2 = mktime(12, 0, 0, $b[1], $b[2], $b[0]);

        $cache[$jy] = (($t2 - $t1) === 366 * 86400);

        return $cache[$jy];
    }
}

if (! function_exists('mijam_jalali_month_name')) {
    /**
     * نام ماه شمسی
     *
     * @param int $jm شماره ماه (۱-۱۲)
     * @return string
     */
    function mijam_jalali_month_name($jm)
    {
        $months = [
            1  => 'فروردین',
            2  => 'اردیبهشت',
            3  => 'خرداد',
            4  => 'تیر',
            5  => 'مرداد',
            6  => 'شهریور',
            7  => 'مهر',
            8  => 'آبان',
            9  => 'آذر',
            10 => 'دی',
            11 => 'بهمن',
            12 => 'اسفند',
        ];

        return isset($months[(int) $jm]) ? $months[(int) $jm] : '';
    }
}

if (! function_exists('mijam_jalali_weekday_name')) {
    /**
     * نام روز هفته — بر اساس روز هفته میلادی همان لحظه
     *
     * @param int $w شماره روز هفته به سبک PHP (۰ = یکشنبه)
     * @param bool $short خروجی کوتاه
     * @return string
     */
    function mijam_jalali_weekday_name($w, $short = false)
    {
        $full = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
        $abbr = ['ی', 'د', 'س', 'چ', 'پ', 'ج', 'ش'];

        $w = (int) $w;
        if ($w < 0 || $w > 6) {
            $w = 0;
        }

        return $short ? $abbr[$w] : $full[$w];
    }
}

if (! function_exists('jalali_date')) {
    /**
     * معادل date() برای تقویم شمسی (جلالی)
     *
     * حروف پشتیبانی‌شده:
     *  Y y m n d j t F l D N w H G i s a A L U
     *  بقیه کاراکترها به‌صورت literal عبور می‌کنند (مثل / و - و فاصله)
     *  با بک‌اسلش می‌توان هر کاراکتری را literal کرد
     *
     * @param string $format فرمت
     * @param int|null $timestamp مهر زمانی (پیش‌فرض: الان)
     * @return string
     */
    function jalali_date($format, $timestamp = null)
    {
        if ($timestamp === null || $timestamp === '') {
            $timestamp = time();
        }
        $timestamp = (int) $timestamp;

        $parts = getdate($timestamp);
        [$jy, $jm, $jd] = mijam_gregorian_to_jalali($parts['year'], $parts['mon'], $parts['mday']);

        $out    = '';
        $len    = strlen($format);
        $escape = false;

        for ($i = 0; $i < $len; $i++) {
            $ch = $format[$i];

            if ($escape) {
                $out .= $ch;
                $escape = false;
                continue;
            }

            if ($ch === '\\') {
                $escape = true;
                continue;
            }

            switch ($ch) {
                case 'Y':
                    $out .= sprintf('%04d', $jy);
                    break;
                case 'y':
                    $out .= sprintf('%02d', $jy % 100);
                    break;
                case 'm':
                    $out .= sprintf('%02d', $jm);
                    break;
                case 'n':
                    $out .= (string) $jm;
                    break;
                case 'd':
                    $out .= sprintf('%02d', $jd);
                    break;
                case 'j':
                    $out .= (string) $jd;
                    break;
                case 't':
                    $out .= (string) ($jm < 7 ? 31 : ($jm < 12 ? 30 : (mijam_is_jalali_leap($jy) ? 30 : 29)));
                    break;
                case 'F':
                    $out .= mijam_jalali_month_name($jm);
                    break;
                case 'M':
                    $out .= mb_substr(mijam_jalali_month_name($jm), 0, 3, 'UTF-8');
                    break;
                case 'l':
                    $out .= mijam_jalali_weekday_name($parts['wday']);
                    break;
                case 'D':
                    $out .= mijam_jalali_weekday_name($parts['wday'], true);
                    break;
                case 'N':
                    // شنبه = ۷ ... جمعه = ۵؟ نه — ISO8601: دوشنبه=۱..یکشنبه=۷
                    $iso = ($parts['wday'] == 0) ? 7 : $parts['wday'];
                    $out .= (string) $iso;
                    break;
                case 'w':
                    $out .= (string) $parts['wday'];
                    break;
                case 'H':
                    $out .= sprintf('%02d', $parts['hours']);
                    break;
                case 'G':
                    $out .= (string) $parts['hours'];
                    break;
                case 'i':
                    $out .= sprintf('%02d', $parts['minutes']);
                    break;
                case 's':
                    $out .= sprintf('%02d', $parts['seconds']);
                    break;
                case 'a':
                    $out .= ($parts['hours'] < 12) ? 'ق.ظ' : 'ب.ظ';
                    break;
                case 'A':
                    $out .= ($parts['hours'] < 12) ? 'قبل‌ازظهر' : 'بعدازظهر';
                    break;
                case 'L':
                    $out .= mijam_is_jalali_leap($jy) ? '1' : '0';
                    break;
                case 'U':
                    $out .= (string) $timestamp;
                    break;
                default:
                    $out .= $ch;
                    break;
            }
        }

        return $out;
    }
}

/* ============================================================
 * ۲) آیکون‌های Lucide (SVG اینلاین — بدون هیچ فایل خارجی)
 *   lucide.dev — ISC License
 * ============================================================ */

if (! function_exists('mijam_icon')) {
    /**
     * خروجی SVG آیکون Lucide به‌صورت اینلاین
     *
     * @param string $name نام آیکون
     * @param int $size اندازه (پیکسل)
     * @param string $class کلاس اضافه
     * @return string
     */
    function mijam_icon($name, $size = 18, $class = '')
    {
        static $icons = null;
        if ($icons === null) {
            $icons = [
                'search'         => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
                'x'              => '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
                'sun'            => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',
                'moon'           => '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
                'menu'           => '<line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="18" y2="18"/>',
                'calendar'       => '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/>',
                'folder'         => '<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>',
                'tag'            => '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"/>',
                'arrow-up'       => '<path d="m5 12 7-7 7 7"/><path d="M12 19V5"/>',
                'arrow-left'     => '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
                'arrow-right'    => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
                'chevron-left'   => '<path d="m15 18-6-6 6-6"/>',
                'chevron-right'  => '<path d="m9 18 6-6-6-6"/>',
                'copy'           => '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
                'check'          => '<path d="M20 6 9 17l-5-5"/>',
                'share-2'        => '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/>',
                'link'           => '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
                'send'           => '<path d="M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z"/><path d="m21.854 2.147-10.94 10.939"/>',
                'twitter'        => '<path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/>',
                'message-circle' => '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>',
                'message-square' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
                'user'           => '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
                'clock'          => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
                'pencil'         => '<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/>',
                'file-text'      => '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
                'zoom-in'        => '<circle cx="11" cy="11" r="8"/><line x1="21" x2="16.65" y1="21" y2="16.65"/><line x1="11" x2="11" y1="8" y2="14"/><line x1="8" x2="14" y1="11" y2="11"/>',
                'zoom-out'       => '<circle cx="11" cy="11" r="8"/><line x1="21" x2="16.65" y1="21" y2="16.65"/><line x1="8" x2="14" y1="11" y2="11"/>',
                'home'           => '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
                'external-link'  => '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
                'list'           => '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>',
                'list-tree'      => '<path d="M21 12H8"/><path d="M21 6H8"/><path d="M21 18H8"/><path d="M3 18v-6a3 3 0 0 1 3-3h5"/>',
                'book-open'      => '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
                'image'          => '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
                'loader'         => '<path d="M12 2v4"/><path d="m16.2 7.8 2.9-2.9"/><path d="M18 12h4"/><path d="m16.2 16.2 2.9 2.9"/><path d="M12 18v4"/><path d="m4.9 19.1 2.9-2.9"/><path d="M2 12h2"/><path d="m4.9 4.9 2.9 2.9"/>',
                'alert-circle'   => '<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/>',
                'corner-up-left' => '<polyline points="9 14 4 9 9 4"/><path d="M20 20v-7a4 4 0 0 0-4-4H4"/>',
                'rss'            => '<path d="M4 11a9 9 0 0 1 9 9"/><path d="M4 4a16 16 0 0 1 16 16"/><circle cx="5" cy="19" r="1"/>',
                'eye'            => '<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>',
                'flame'          => '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>',
            ];
        }

        $name = (string) $name;
        if (! isset($icons[$name])) {
            return '';
        }

        $classAttr = 'mijam-icon icon-' . $name . ($class !== '' ? ' ' . htmlspecialchars($class, ENT_QUOTES) : '');

        return '<svg class="' . $classAttr . '" xmlns="http://www.w3.org/2000/svg" width="' . (int) $size
            . '" height="' . (int) $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
            . 'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'
            . $icons[$name] . '</svg>';
    }
}

/* ============================================================
 * ۳) خواندن امن تنظیمات + ابزارهای عمومی
 * ============================================================ */

if (! function_exists('mijam_opt')) {
    /**
     * خواندن امن یک گزینه از تنظیمات قالب/سایت (بدون echo جانبی)
     *
     * @param string $name نام گزینه
     * @param mixed $default مقدار پیش‌فرض
     * @return mixed
     */
    function mijam_opt($name, $default = null)
    {
        try {
            $options = Helper::options();
            $value   = $options->{$name};

            if ($value === null || $value === '') {
                return $default;
            }

            return $value;
        } catch (Throwable $e) {
            return $default;
        }
    }
}

if (! function_exists('mijam_theme_url')) {
    /**
     * آدرس کامل یک فایل داخل قالب — همیشه بدون echo جانبی
     *
     * @param string $path مسیر نسبی مثل images/logo.png
     * @return string
     */
    function mijam_theme_url($path = '')
    {
        try {
            $base = rtrim(Helper::options()->themeUrl, '/');

            return $path === '' ? $base : ($base . '/' . ltrim($path, '/'));
        } catch (Throwable $e) {
            return '';
        }
    }
}

if (! function_exists('mijam_letter_avatar')) {
    /**
     * آواتار محلی با حرف اول نام (بدون هیچ وابستگی خارجی مثل gravatar)
     * رنگ به‌صورت قطعی از روی نام تولید می‌شود
     *
     * @param string $name نام نویسنده/کاربر
     * @param int $size اندازه در پیکسل
     * @return string HTML
     */
    function mijam_letter_avatar($name, $size = 40)
    {
        $name   = trim((string) $name);
        $letter = ($name === '') ? '؟' : mb_substr($name, 0, 1, 'UTF-8');

        $palette = [
            '#e74c3c', '#3498db', '#2ecc71', '#9b59b6',
            '#f39c12', '#16a085', '#e67e22', '#2980b9',
            '#c0392b', '#8e44ad', '#27ae60', '#d35400',
        ];

        $idx    = abs(crc32(mb_strtolower($name, 'UTF-8'))) % count($palette);
        $bg     = $palette[$idx];
        $letter = htmlspecialchars($letter, ENT_QUOTES, 'UTF-8');

        return '<span class="letter-avatar" style="--avatar-bg:' . $bg . ';--avatar-size:' . (int) $size . 'px" '
            . 'aria-hidden="true">' . $letter . '</span>';
    }
}

if (! function_exists('mijam_e')) {
    /**
     * escape کوتاه
     *
     * @param string $text متن
     * @return string
     */
    function mijam_e($text)
    {
        return htmlspecialchars((string) $text, ENT_QUOTES, 'UTF-8');
    }
}

if (! function_exists('mijam_excerpt_text')) {
    /**
     * خلاصه متنی امن (برای متن خام بدون HTML)
     *
     * @param string $text متن
     * @param int $length طول
     * @return string
     */
    function mijam_excerpt_text($text, $length = 60)
    {
        $text = trim(strip_tags((string) $text));
        $text = preg_replace('/\s+/u', ' ', $text);

        if (mb_strlen($text, 'UTF-8') > $length) {
            return mb_substr($text, 0, $length, 'UTF-8') . '…';
        }

        return $text;
    }
}

/* ============================================================
 * ۴) فیلدهای سفارشی پست
 * ============================================================ */

if (! function_exists('themeFields')) {
    /**
     * فیلدهای سفارشی نوشته‌ها
     *
     * نام فیلد تصویر شاخص «thumb» است تا با پوسته‌های دیگر
     * (مثل نیلوفر) یکپارچه باشد — همان مقدار در هر دو پوسته خوانده می‌شود.
     *
     * @param Typecho_Widget_Helper_Layout $layout
     */
    function themeFields($layout)
    {
        if (! class_exists('Typecho_Widget_Helper_Form_Element_Text')) {
            return;
        }

        $thumb = new Typecho_Widget_Helper_Form_Element_Text(
            'thumb',
            null,
            null,
            'تصویر شاخص',
            'نشانی کامل یا نسبت به سایت. اگر خالی بماند، نخستین تصویر مطلب و سپس تصویر پیش‌فرض قالب استفاده می‌شود.'
        );
        $layout->addItem($thumb);
    }
}

/* ============================================================
 * ۵) تنظیمات قالب (themeConfig)
 * ============================================================ */

if (! function_exists('themeConfig')) {
    /**
     * فرم تنظیمات قالب در پیشخوان
     *
     * @param Typecho_Widget_Helper_Form $form
     */
    function themeConfig($form)
    {
        if (! class_exists('Typecho_Widget_Helper_Form_Element_Text')) {
            return;
        }

        /* --- ظاهر و هویت --- */

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text(
            'headerLogoUrl',
            null,
            mijam_theme_url('images/logo.png'),
            'آدرس لوگوی هدر',
            'در صورت خالی گذاشتن، لوگوی پیش‌فرض قالب (SVG تطبیقی با حالت روز/شب) استفاده می‌شود.'
        ));

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text(
            'headerLogoDarkUrl',
            null,
            '',
            'آدرس لوگوی هدر در حالت تیره (اختیاری)',
            'اگر لوگوی سفارشی دارید و نسخه روشن آن برای حالت تیره مناسب نیست، آدرس نسخه تیره را اینجا بگذارید؛ با تغییر حالت روز/شب خودکار جایگزین می‌شود. لوگوی پیش‌فرض قالب به این گزینه نیاز ندارد.'
        ));

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text(
            'footerLogoUrl',
            null,
            mijam_theme_url('images/footer-logo.png'),
            'آدرس لوگوی فوتر',
            'در صورت خالی گذاشتن، نشان پیش‌فرض قالب (SVG) استفاده می‌شود.'
        ));

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text(
            'footerLogoDarkUrl',
            null,
            '',
            'آدرس لوگوی فوتر در حالت تیره (اختیاری)',
            'مانند لوگوی هدر — فقط برای لوگوی سفارشی فوتر؛ در حالت تیره جایگزین می‌شود.'
        ));

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text(
            'faviconUrl',
            null,
            mijam_theme_url('images/favicon.png'),
            'آدرس فاوآیکون',
            'در صورت خالی گذاشتن، فاوآیکون پیش‌فرض (images/favicon.png) استفاده می‌شود.'
        ));

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text(
            'defaultThumbnail',
            null,
            mijam_theme_url('images/default-thumb.jpg'),
            'آدرس تصویر پیش‌فرض مطالب',
            'وقتی مطلب تصویری ندارد این تصویر نمایش داده می‌شود.'
        ));

        /* --- صفحه اصلی --- */

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Radio(
            'indexViewMode',
            [
                'card' => 'آخرین مطالب — کارتی',
                'list' => 'آخرین مطالب — لیستی (ردیفی)',
            ],
            'card',
            'طرح‌بندی صفحه اصلی'
        ));

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Radio(
            'showSidebar',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'نمایش نوار کناری (سایدبار) در صفحه اصلی',
            'این گزینه فقط صفحه اصلی را کنترل می‌کند؛ نوشته‌ها، دسته‌ها، جستجو و بقیه صفحات همیشه سایدبار دارند.'
        ));

        /* --- منو --- */

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text(
            'showCategoryIds',
            null,
            '',
            'شناسه دسته‌های منوی بالای سایت',
            'با کاما جدا کنید؛ مثال: 1,3,5 — اگر خالی باشد همه دسته‌ها نمایش داده می‌شوند.'
        ));

        /* --- نوشته‌ها --- */

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Radio(
            'showPostCover',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'نمایش تصویر شاخص بزرگ در بالای نوشته'
        ));

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Radio(
            'showToc',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'فهرست مطالب خودکار (TOC) در نوشته‌ها'
        ));

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Radio(
            'showShareButtons',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'دکمه‌های اشتراک‌گذاری در نوشته‌ها'
        ));

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Radio(
            'showRelatedPosts',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'نمایش مطالب مرتبط'
        ));

        if (class_exists('Typecho_Widget_Helper_Form_Element_Select')) {
            $form->addInput(new Typecho_Widget_Helper_Form_Element_Select(
                'relatedPostsCount',
                ['3' => '۳ کارت — در یک ردیف', '4' => '۴ کارت — در یک ردیف'],
                '3',
                'تعداد مطالب مرتبط',
                'کارت‌ها به‌صورت خودکار هم‌اندازه می‌شوند تا هر سه یا هر چهار کارت در یک ردیف جای بگیرند.'
            ));
        } else {
            $form->addInput(new Typecho_Widget_Helper_Form_Element_Text(
                'relatedPostsCount',
                null,
                '3',
                'تعداد مطالب مرتبط',
                '۳ یا ۴ (پیش‌فرض ۳ کارت) — همه کارت‌ها در یک ردیف جای می‌گیرند.'
            ));
        }

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Radio(
            'showReadingProgress',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'نوار پیشرفت مطالعه در نوشته‌ها'
        ));

        /* --- مطالب محبوب (سایدبار) --- */

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Radio(
            'showPopularPosts',
            ['1' => 'فعال', '0' => 'غیرفعال'],
            '1',
            'نمایش ویجت «مطالب محبوب» در سایدبار',
            'پر بازدیدترین نوشته‌ها بر پایه آمار بازدید قالب؛ تا زمانی که بازدیدی ثبت نشده باشد، بر پایه تعداد دیدگاه مرتب می‌شود.'
        ));

        if (class_exists('Typecho_Widget_Helper_Form_Element_Select')) {
            $form->addInput(new Typecho_Widget_Helper_Form_Element_Select(
                'popularPostsCount',
                ['3' => '۳ مطلب', '4' => '۴ مطلب', '5' => '۵ مطلب', '6' => '۶ مطلب'],
                '4',
                'تعداد مطالب محبوب'
            ));
        }

        /* --- آمار بازدید --- */

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Radio(
            'countLoggedInViews',
            ['0' => 'شمرده نشود', '1' => 'شمرده شود'],
            '0',
            'شمارش بازدید کاربران واردشده',
            'اگر «شمرده نشود» باشد، بازدید مدیر و نویسندگان واردشده از صفحات پست در آمار ثبت نمی‌شود.'
        ));

        if (class_exists('Typecho_Widget_Helper_Form_Element_Select')) {
            $form->addInput(new Typecho_Widget_Helper_Form_Element_Select(
                'viewsInterval',
                [
                    '0'     => 'بدون فاصله — هر بازدید شمرده شود',
                    '1800'  => '۳۰ دقیقه',
                    '3600'  => '۱ ساعت',
                    '21600' => '۶ ساعت',
                    '86400' => '۲۴ ساعت',
                ],
                '3600',
                'فاصله شمارش بازدید مکرر',
                'بازدید تکراری یک پست در این بازه فقط یک بار شمرده می‌شود (کوکی مرورگر بازدیدکننده).'
            ));
        }

        /* --- رنگ و حالت --- */

        $form->addInput(new Typecho_Widget_Helper_Form_Element_Radio(
            'themeMode',
            ['auto' => 'خودکار (پیش‌فرض سیستم)', 'light' => 'همیشه روشن', 'dark' => 'همیشه تیره'],
            'auto',
            'حالت نمایش پیش‌فرض',
            'بازدیدکننده می‌تواند با دکمه روز/شب تغییرش دهد؛ انتخاب او در مرورگرش ذخیره می‌شود.'
        ));
    }
}

/* ============================================================
 * ۶) توابع کمکی محتوا
 * ============================================================ */

if (! function_exists('mijam_resolve_url')) {
    /**
     * تبدیل نشانی نسبی به نشانی کامل سایت
     * (نشانی‌های data-uri، مطلق و پروتکل‌نسبی دست‌نخورده می‌مانند)
     *
     * @param string $url نشانی ورودی
     * @return string
     */
    function mijam_resolve_url($url)
    {
        $url = trim((string) $url);
        if ($url === '' || preg_match('#^(data:|https?://|//)#i', $url)) {
            return $url;
        }

        try {
            $base = rtrim((string) Helper::options()->siteUrl, '/');

            return $base . '/' . ltrim($url, '/');
        } catch (Throwable $e) {
            return $url;
        }
    }
}

if (! function_exists('mijam_post_thumbnail')) {
    /**
     * تصویر شاخص مطلب:
     * ۱) فیلد اختصاصی «thumb» (یکپارچه با پوسته نیلوفر و پوسته‌های دیگر)
     * ۲) فیلد قدیمی «thumbnail» (سازگاری با نسخه‌های پیشین Mijam)
     * ۳) نخستین تصویر داخل مطلب
     * ۴) تصویر پیش‌فرض تنظیمات قالب
     *
     * @param mixed $widget ویجت محتوا
     * @return string آدرس تصویر
     */
    function mijam_post_thumbnail($widget)
    {
        try {
            $fields = $widget->fields;
            if (is_object($fields)) {
                foreach (['thumb', 'thumbnail'] as $fieldName) {
                    if (isset($fields->{$fieldName})) {
                        $url = trim((string) $fields->{$fieldName});
                        if ($url !== '') {
                            return mijam_resolve_url($url);
                        }
                    }
                }
            }
        } catch (Throwable $e) {
            // نادیده بگیر — به مسیر بعدی می‌رویم
        }

        try {
            $content = (string) $widget->content;
            if ($content !== '' && preg_match('/<img[^>]*\bsrc=[\'"]([^\'"]+)[\'"]/i', $content, $m)) {
                return $m[1];
            }
        } catch (Throwable $e) {
            // نادیده بگیر
        }

        return mijam_resolve_url(mijam_opt('defaultThumbnail', mijam_theme_url('images/default-thumb.jpg')));
    }
}

if (! function_exists('getFirstImage')) {
    /**
     * سازگاری با نسخه قبل — تصویر اول مطلب
     *
     * @param mixed $widget ویجت
     * @return string
     */
    function getFirstImage($widget)
    {
        return mijam_post_thumbnail($widget);
    }
}

if (! function_exists('mijam_reading_time')) {
    /**
     * زمان مطالعه تقریبی به دقیقه (حدود ۲۰۰ کلمه در دقیقه)
     *
     * @param mixed $widget ویجت محتوا
     * @return int دقیقه (حداقل ۱)
     */
    function mijam_reading_time($widget)
    {
        try {
            $text   = trim(strip_tags((string) $widget->content));
            $words  = preg_split('/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY);
            $minute = (int) ceil(count($words) / 200);

            return max(1, $minute);
        } catch (Throwable $e) {
            return 1;
        }
    }
}

if (! function_exists('mijam_post_card')) {
    /**
     * رندر مشترک کارت مطلب — تنها منبع تولید مارک‌آپ کارت در کل قالب
     * (رفع قطعی باگ کلاس‌های خراب و فاصله‌های اضافی)
     *
     * @param mixed $widget ویجت محتوا
     * @param array $args گزینه‌ها: image_first, show_excerpt, class
     */
    function mijam_post_card($widget, $args = [])
    {
        $imageFirst   = isset($args['image_first']) ? (bool) $args['image_first'] : true;
        $showExcerpt  = isset($args['show_excerpt']) ? (bool) $args['show_excerpt'] : true;
        $extraClass   = isset($args['class']) ? ' ' . $args['class'] : '';
        $excerptLen   = isset($args['excerpt_len']) ? (int) $args['excerpt_len'] : 110;

        $thumb  = mijam_post_thumbnail($widget);
        $title  = $widget->title;
        $author = $widget->author->screenName ? $widget->author->screenName : $widget->author->name;
        ?>
<article class="post-card<?php echo $extraClass; ?>">
    <div class="post-card__thumb">
        <a href="<?php $widget->permalink(); ?>" tabindex="-1" aria-hidden="true">
            <img src="<?php echo mijam_e($thumb); ?>" alt="<?php echo mijam_e($title); ?>" loading="lazy" decoding="async">
        </a>
    </div>
    <div class="post-card__body">
        <h3 class="post-card__title">
            <a href="<?php $widget->permalink(); ?>"><?php echo mijam_e($title); ?></a>
        </h3>
        <?php if ($showExcerpt): ?>
        <div class="post-card__excerpt">
            <?php $widget->excerpt($excerptLen, '…'); ?>
        </div>
        <?php endif; ?>
        <footer class="post-card__meta">
            <a href="<?php $widget->author->permalink(); ?>" class="post-card__author">
                <?php echo mijam_letter_avatar((string) $author, 28); ?>
                <span><?php echo mijam_e($author); ?></span>
            </a>
            <time class="post-card__date" datetime="<?php echo date('c', (int) $widget->created); ?>">
                <?php echo mijam_icon('calendar', 14); ?>
                <?php echo jalali_date('Y/m/d', (int) $widget->created); ?>
            </time>
        </footer>
    </div>
</article>
        <?php
    }
}

if (! function_exists('mijam_tag_chip')) {
    /**
     * چیپ برچسب رنگی
     *
     * @param array $tag آرایه برچسب (name, permalink, mid)
     */
    function mijam_tag_chip($tag)
    {
        $name = is_array($tag) ? $tag['name'] : (string) $tag;
        $href = is_array($tag) ? $tag['permalink'] : '#';
        $mid  = is_array($tag) ? (int) $tag['mid'] : 0;
        ?>
<a class="tag-chip" href="<?php echo mijam_e($href); ?>">
    <span class="tag-chip__dot" style="background-color: <?php echo getTagColor($mid); ?>"></span>
    <?php echo mijam_e($name); ?>
</a>
        <?php
    }
}

if (! function_exists('mijam_post_tags_html')) {
    /**
     * خروجی تگ‌های مطلب جاری
     *
     * @param mixed $widget ویجت
     */
    function mijam_post_tags_html($widget)
    {
        try {
            $tags = $widget->tags;
            if (empty($tags) || ! is_array($tags)) {
                return;
            }
        } catch (Throwable $e) {
            return;
        }
        ?>
<div class="post-tags">
    <?php foreach ($tags as $tag): ?>
        <?php mijam_tag_chip($tag); ?>
    <?php endforeach; ?>
</div>
        <?php
    }
}

/* ============================================================
 * ۷) رنگ دسته/برچسب و دسته‌های انتخابی
 * ============================================================ */

if (! function_exists('getCategoryColor')) {
    /**
     * رنگ قطعی دسته بر اساس شناسه
     *
     * @param int $cid شناسه دسته
     * @return string
     */
    function getCategoryColor($cid)
    {
        $hue = ((int) $cid * 47) % 360;

        return "hsl($hue, 70%, 55%)";
    }
}

if (! function_exists('getTagColor')) {
    /**
     * رنگ قطعی برچسب بر اساس شناسه
     *
     * @param int $mid شناسه برچسب
     * @return string
     */
    function getTagColor($mid)
    {
        $hue = ((int) $mid * 37) % 360;

        return "hsl($hue, 75%, 50%)";
    }
}

if (! function_exists('getSelectedCategories')) {
    /**
     * شناسه دسته‌های انتخاب‌شده برای منو
     *
     * @return array
     */
    function getSelectedCategories()
    {
        $idsStr = (string) mijam_opt('showCategoryIds', '');
        if ($idsStr === '') {
            return [];
        }

        return array_values(array_filter(array_map('intval', explode(',', $idsStr))));
    }
}

/* ============================================================
 * ۷) سیستم آمار بازدید نوشته‌ها (الگوی پوسته نیلوفر — ستون views)
 * ============================================================ */

if (! function_exists('mijam_get_views')) {
    /**
     * تعداد بازدید نوشته از ستون views جدول محتوا
     *
     * @param mixed $widget ویجت محتوا
     * @return int
     */
    function mijam_get_views($widget)
    {
        try {
            return max(0, (int) $widget->views);
        } catch (Throwable $e) {
            return 0;
        }
    }
}

if (! function_exists('mijam_views_schema_ready')) {
    /**
     * اطمینان از وجود ستون views در جدول محتوا — یکپارچه‌سازی خودکار.
     * آمار احتمالی پوسته‌های دیگر (فیلد views در جدول fields) در نخستین
     * اجرا به ستون جدید منتقل می‌شود؛ همیشه یک‌بار در هر درخواست کش می‌شود.
     *
     * @return bool
     */
    function mijam_views_schema_ready()
    {
        static $ready = null;

        if ($ready !== null) {
            return $ready;
        }

        $ready = false;

        try {
            $db = Typecho_Db::get();

            $columnExists = false;
            try {
                $db->fetchRow($db->select('table.contents.views')->from('table.contents')->limit(1));
                $columnExists = true;
            } catch (Throwable $e) {
                $columnExists = false;
            }

            if (! $columnExists) {
                $prefix = $db->getPrefix();
                $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT DEFAULT 0');

                /* انتقال آمار احتمالی پوسته‌های دیگر (اختیاری — نباید سایت را متوقف کند) */
                try {
                    $db->query(
                        'UPDATE `' . $prefix . 'contents` SET views = COALESCE((SELECT SUM(f.int_value)'
                        . ' FROM `' . $prefix . 'fields` f WHERE f.cid = `' . $prefix
                        . 'contents`.cid AND f.name = \'views\' AND f.type = \'int\'), 0)'
                    );
                    $db->query('DELETE FROM `' . $prefix . 'fields` WHERE name = \'views\' AND type = \'int\'');
                } catch (Throwable $e) {
                    // انتقال آمار اختیاری است
                }
            }

            $ready = true;
        } catch (Throwable $e) {
            // نبود دسترسی کافی به دیتابیس نباید سایت را از کار بیندازد
            $ready = false;
        }

        return $ready;
    }
}

if (! function_exists('mijam_count_view')) {
    /**
     * شمارش بازدید صفحات تکی — با هوک beforeRender فراخوانی می‌شود
     * (اگر پلاگین مستقل ViewsCounter فعال باشد، خودش شمارش می‌کند و
     * شمارش مضاعف نمی‌شود)
     *
     * @param mixed $archive ویجت آرشیو
     * @return void
     */
    function mijam_count_view($archive)
    {
        /* اگر پلاگین مستقل ViewsCounter فعال باشد، خودش شمارش می‌کند */
        try {
            $options         = Helper::options();
            $activatedPlugins = $options->plugins;
            if (is_array($activatedPlugins) && isset($activatedPlugins['activated']['ViewsCounter'])) {
                return;
            }
        } catch (Throwable $e) {
            // نادیده بگیر
        }

        /* بازدید کاربران واردشده طبق تنظیم پوسته شمرده می‌شود یا نه */
        $countLoggedIn = (mijam_opt('countLoggedInViews', '0') == '1');
        if (! $countLoggedIn) {
            try {
                if (class_exists('Widget_User')) {
                    $user = Typecho_Widget::widget('Widget_User');
                    if (method_exists($user, 'hasLogin') && $user->hasLogin()) {
                        return;
                    }
                }
            } catch (Throwable $e) {
                // نادیده بگیر
            }
        }

        /* شمارش فقط برای صفحات تکی (نوشته/برگه) انجام می‌شود */
        try {
            if (! method_exists($archive, 'is') || ! $archive->is('single')) {
                return;
            }
        } catch (Throwable $e) {
            return;
        }

        $cid = 0;
        try {
            $cid = (int) $archive->cid;
        } catch (Throwable $e) {
            $cid = 0;
        }

        if ($cid < 1) {
            return;
        }

        /* فاصله زمانی جلوگیری از شمارش بازدیدهای مکرر (کوکی مرورگر) */
        $interval = (int) mijam_opt('viewsInterval', '3600');

        if ($interval > 0 && class_exists('Typecho_Cookie')) {
            try {
                $viewed    = (string) Typecho_Cookie::get('mijamViews', '');
                $viewedIds = ($viewed === '') ? [] : explode(',', $viewed);

                if (in_array((string) $cid, $viewedIds, true)) {
                    return;
                }

                $viewedIds[] = (string) $cid;

                /* جلوگیری از بزرگ‌شدن بی‌رویه کوکی */
                if (count($viewedIds) > 100) {
                    $viewedIds = array_slice($viewedIds, -100);
                }

                Typecho_Cookie::set('mijamViews', implode(',', $viewedIds), time() + $interval);
            } catch (Throwable $e) {
                // نادیده بگیر
            }
        }

        if (! mijam_views_schema_ready()) {
            return;
        }

        try {
            $db = Typecho_Db::get();
            $db->query(
                $db->update('table.contents')
                    ->expression('views', 'views + 1')
                    ->where('cid = ?', $cid)
            );
        } catch (Throwable $e) {
            // خطا در شمارش بازدید نباید نمایش صفحه را متوقف کند
        }
    }
}

if (! class_exists('MijamPopularPosts')) {
    /**
     * ویجت مطالب محبوب — پر بازدیدترین نوشته‌ها (الگوی پوسته نیلوفر)
     *
     * ترتیب: بیشترین بازدید (ستون views)؛ تا زمانی که هیچ بازدیدی ثبت
     * نشده باشد، بر پایه تعداد دیدگاه مرتب می‌شود.
     * فقط وقتی تعریف می‌شود که کلاس پایه Typecho/TypeRenew در دسترس باشد.
     */
    if (class_exists('\\Widget\\Base\\Contents')) {
        class MijamPopularPosts extends \Widget\Base\Contents
        {
            public function execute()
            {
                $this->parameter->setDefault(['pageSize' => 4]);
                $limit = max(1, (int) $this->parameter->pageSize);

                /* ستون مرتب‌سازی: بازدید — یا دیدگاه اگر هنوز آماری ثبت نشده */
                $orderColumn = 'table.contents.commentsNum';
                if (mijam_views_schema_ready()) {
                    try {
                        $totalViews = (int) $this->db->fetchObject(
                            $this->db->select(['COALESCE(SUM(table.contents.views), 0)' => 'total'])
                                ->from('table.contents')
                                ->where('table.contents.type = ?', 'post')
                                ->where('table.contents.status = ?', 'publish')
                        )->total;

                        if ($totalViews > 0) {
                            $orderColumn = 'table.contents.views';
                        }
                    } catch (Throwable $e) {
                        // نادیده — با پایه دیدگاه ادامه می‌دهیم
                    }
                }

                $select = $this->select('table.contents.*')
                    ->where('table.contents.status = ?', 'publish')
                    ->where('table.contents.created < ?', $this->options->time)
                    ->where('table.contents.type = ?', 'post')
                    ->where("table.contents.password IS NULL OR table.contents.password = ''")
                    ->order($orderColumn, \Typecho\Db::SORT_DESC)
                    ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                    ->limit($limit);

                $this->db->fetchAll($select, [$this, 'push']);
            }
        }
    }
}

/* ============================================================
 * ۷-ب) لوگوی پیش‌فرض SVG — تطبیقی با حالت روز/شب
 * ============================================================ */

if (! function_exists('mijam_default_logo_svg')) {
    /**
     * لوگوی پیش‌فرض هدر (اینلاین):
     * سه دایره برند (آبی/قرمز/سبز) + واژه MIJAM.
     * متن با currentColor رسم می‌شود تا در دارک‌مود خودکار روشن شود.
     *
     * @param string $alt متن جایگزین
     * @return string
     */
    function mijam_default_logo_svg($alt = '')
    {
        $altAttr = $alt !== '' ? ' role="img" aria-label="' . htmlspecialchars($alt, ENT_QUOTES) . '"' : ' aria-hidden="true"';

        return '<svg class="site-logo__svg" xmlns="http://www.w3.org/2000/svg"'
            . ' viewBox="0 0 500 170"' . $altAttr . ' focusable="false">'
            /* نشان برند — سه دایره */
            . '<circle cx="63" cy="61" r="17.5" fill="#1e90ff"/>'
            . '<circle cx="29" cy="108" r="17.5" fill="#ff6347"/>'
            . '<circle cx="101" cy="108" r="17.5" fill="#32cd32"/>'
            /* واژه MIJAM — با رنگ متن صفحه (currentColor) */
            . '<g fill="none" stroke="currentColor" stroke-width="22"'
            . ' stroke-linecap="round" stroke-linejoin="round">'
            . '<path d="M152 114 V54 L183 83 L214 54 V114"/>' /* M */
            . '<path d="M245 54 V114"/>' /* I */
            . '<path d="M290.5 54 V88 C290.5 112 282 116 276 107"/>' /* J */
            . '<path d="M322 113 L352.5 54 L383 113"/>' /* A — دو پایه */
            . '<path d="M328 114 H377"/>' /* A — میله پایین */
            . '<path d="M414 114 V54 L445 83 L474 54 V114"/>' /* M */
            . '</g></svg>';
    }
}

if (! function_exists('mijam_footer_dots_svg')) {
    /**
     * نشان پیش‌فرض فوتر (اینلاین) — سه دایره برند
     *
     * @param string $alt متن جایگزین
     * @return string
     */
    function mijam_footer_dots_svg($alt = '')
    {
        $altAttr = $alt !== '' ? ' role="img" aria-label="' . htmlspecialchars($alt, ENT_QUOTES) . '"' : ' aria-hidden="true"';

        return '<svg class="footer-logo__svg" xmlns="http://www.w3.org/2000/svg"'
            . ' viewBox="0 0 200 200"' . $altAttr . ' focusable="false">'
            . '<circle cx="21" cy="99" r="18.5" fill="#1e90ff"/>'
            . '<circle cx="99" cy="99" r="18.5" fill="#ff6347"/>'
            . '<circle cx="177" cy="99" r="18.5" fill="#32cd32"/>'
            . '</svg>';
    }
}

if (! function_exists('themeInit')) {
    /**
     * راه‌انداز قالب — توسط Typecho/TypeRenew قبل از رندر فراخوانی می‌شود
     *
     * @param mixed $archive ویجت آرشیو
     * @return void
     */
    function themeInit($archive)
    {
        /* ثبت شمارنده بازدید صفحات تکی (هوک beforeRender) */
        try {
            if (class_exists('\\Typecho\\Plugin')) {
                \Typecho\Plugin::factory('Widget\Archive')->beforeRender = 'mijam_count_view';
            } elseif (class_exists('Typecho_Plugin')) {
                Typecho_Plugin::factory('Widget_Archive')->beforeRender = 'mijam_count_view';
            }
        } catch (Throwable $e) {
            // ثبت هوک نباید سایت را از کار بیندازد
        }
    }
}

/* ============================================================
 * ۸) آمار نویسنده (با گارد کامل)
 * ============================================================ */

if (! function_exists('getAuthorPostsCount')) {
    /**
     * تعداد نوشته‌های منتشرشده یک نویسنده
     *
     * @param int $uid شناسه کاربری
     * @return int
     */
    function getAuthorPostsCount($uid)
    {
        try {
            $db    = Typecho_Db::get();
            $posts = $db->fetchObject(
                $db->select(['COUNT(*)' => 'num'])
                    ->from('table.contents')
                    ->where('authorId = ?', (int) $uid)
                    ->where('type = ?', 'post')
                    ->where('status = ?', 'publish')
            );

            return (int) ($posts->num ?? 0);
        } catch (Throwable $e) {
            return 0;
        }
    }
}

if (! function_exists('getAuthorCommentsCount')) {
    /**
     * تعداد دیدگاه‌های تاییدشده یک کاربر
     *
     * @param int $uid شناسه کاربری
     * @return int
     */
    function getAuthorCommentsCount($uid)
    {
        try {
            $db       = Typecho_Db::get();
            $comments = $db->fetchObject(
                $db->select(['COUNT(*)' => 'num'])
                    ->from('table.comments')
                    ->where('authorId = ?', (int) $uid)
                    ->where('status = ?', 'approved')
            );

            return (int) ($comments->num ?? 0);
        } catch (Throwable $e) {
            return 0;
        }
    }
}

if (! function_exists('getArchiveTagId')) {
    /**
     * شناسه برچسب آرشیو جاری
     *
     * @param mixed $archive ویجت آرشیو
     * @return int
     */
    function getArchiveTagId($archive)
    {
        try {
            if (! $archive->is('tag')) {
                return 0;
            }
            $slug = method_exists($archive, 'getArchiveSlug') ? $archive->getArchiveSlug() : null;
            if (! $slug) {
                return 0;
            }
            $db  = Typecho_Db::get();
            $tag = $db->fetchRow(
                $db->select('mid')
                    ->from('table.metas')
                    ->where('slug = ?', $slug)
                    ->limit(1)
            );

            return $tag ? (int) $tag['mid'] : 0;
        } catch (Throwable $e) {
            return 0;
        }
    }
}

/* ============================================================
 * ۹) callback دیدگاه‌های تو‌در‌تو (با آواتار حرف اول)
 * ============================================================ */

if (! function_exists('threadedComments')) {
    /**
     * قالب نمایش تک‌دیدگاه — توسط listComments فراخوانی می‌شود
     *
     * @param mixed $comments ویجت دیدگاه
     * @param mixed $options تنظیمات نمایش
     */
    function threadedComments($comments, $options)
    {
        $author = (string) $comments->author;
        $level  = (int) $comments->levels;
        ?>
<li id="<?php $comments->theId(); ?>" class="comment-item comment-level-<?php echo min($level, 3); ?>">
    <div class="comment-item__card">
        <div class="comment-item__avatar">
            <?php echo mijam_letter_avatar($author, 44); ?>
        </div>
        <div class="comment-item__main">
            <header class="comment-item__head">
                <span class="comment-item__author"><?php echo mijam_e($author); ?></span>
                <time class="comment-item__date" datetime="<?php echo date('c', (int) $comments->created); ?>">
                    <?php echo jalali_date('Y/m/d — H:i', (int) $comments->created); ?>
                </time>
            </header>
            <div class="comment-item__content">
                <?php $comments->content(); ?>
            </div>
            <footer class="comment-item__actions">
                <?php $comments->reply('پاسخ'); ?>
            </footer>
        </div>
    </div>
    <?php if ($comments->children): ?>
    <div class="comment-children">
        <?php $comments->threadedComments($options); ?>
    </div>
    <?php endif; ?>
</li>
        <?php
    }
}
