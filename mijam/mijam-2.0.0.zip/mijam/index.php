<?php
/**
 * مریم — قالب وبلاگی فارسی با دو طرح کارتی/ردیفی
 *
 * @package مریم
 * @author پوردریایی
 * @version 2.0.0
 * @link https://pourdaryaei.ir
 */

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');

/* طرح‌بندی صفحه اصلی: کارتی یا ردیفی (لیستی) */
$indexMode = (string) mijam_opt('indexViewMode', 'card');
if (! in_array($indexMode, ['card', 'list'], true)) {
    $indexMode = 'card';
}

/* سایدبار: فقط در صفحه اصلی قابل فعال/غیرفعال شدن است */
$showSidebar = (mijam_opt('showSidebar', '1') == '1');

$isFirstPage = true;
try {
    $isFirstPage = ((int) $this->getCurrentPage() <= 1);
} catch (Throwable $e) {
    $isFirstPage = true;
}
?>
<main id="main" class="container site-main<?php echo $showSidebar ? ' site-main--with-sidebar' : ''; ?>">

    <div class="content-area">

        <?php if ($this->have()): ?>

            <section class="posts-section" aria-label="<?php echo $isFirstPage ? 'آخرین مطالب' : 'مطالب'; ?>">
                <?php if ($isFirstPage): ?>
                <header class="posts-section__head">
                    <h2 class="posts-section__title">
                        <?php echo mijam_icon('book-open', 18); ?>
                        آخرین مطالب
                    </h2>
                </header>
                <?php endif; ?>

                <?php if ($indexMode === 'list'): ?>
                <div class="post-list">
                    <?php while ($this->next()): ?>
                    <article class="post-row">
                        <div class="post-row__thumb">
                            <a href="<?php $this->permalink(); ?>" tabindex="-1" aria-hidden="true">
                                <img src="<?php echo mijam_e(mijam_post_thumbnail($this)); ?>"
                                     alt="<?php $this->title(); ?>" loading="lazy" decoding="async">
                            </a>
                        </div>
                        <div class="post-row__body">
                            <h2 class="post-row__title">
                                <a href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a>
                            </h2>
                            <p class="post-row__excerpt">
                                <?php $this->excerpt(140, '…'); ?>
                            </p>
                            <footer class="post-card__meta">
                                <a href="<?php $this->author->permalink(); ?>" class="post-card__author">
                                    <?php echo mijam_letter_avatar((string) $this->author->screenName, 28); ?>
                                    <span><?php $this->author(); ?></span>
                                </a>
                                <time class="post-card__date" datetime="<?php echo date('c', (int) $this->created); ?>">
                                    <?php echo mijam_icon('calendar', 14); ?>
                                    <?php echo jalali_date('Y/m/d', (int) $this->created); ?>
                                </time>
                                <?php echo mijam_icon('clock', 14); ?>
                                <span><?php echo mijam_reading_time($this); ?> دقیقه</span>
                            </footer>
                        </div>
                    </article>
                    <?php endwhile; ?>
                </div>

                <?php else: ?>
                <div class="post-grid<?php echo $showSidebar ? ' post-grid--2col' : ' post-grid--3col'; ?>">
                    <?php while ($this->next()): ?>
                        <?php mijam_post_card($this, ['excerpt_len' => 110]); ?>
                    <?php endwhile; ?>
                </div>
                <?php endif; ?>
            </section>

            <nav class="clean-pagination" aria-label="ناوبری صفحات">
                <?php $this->pageNav(
                    /* در RTL: «قبلی» سمت راست است و فلش آن باید به راست اشاره کند */
                    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>',
                    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>',
                    3,
                    '…',
                    [
                        'wrapTag'   => 'ul',
                        'wrapClass' => 'page-numbers',
                        'itemTag'   => 'li',
                        'textTag'   => 'span',
                    ]
                ); ?>
            </nav>

        <?php else: ?>

            <div class="empty-state">
                <?php echo mijam_icon('file-text', 56); ?>
                <h2>هنوز مطلبی منتشر نشده است!</h2>
                <p>این بخش منتظر اولین نوشته شماست. به محض انتشار مطلب، همین‌جا نمایش داده می‌شود.</p>
                <?php if ($this->user->hasLogin()): ?>
                    <a href="<?php $this->options->adminUrl('write-post.php'); ?>" class="btn btn--primary">
                        <?php echo mijam_icon('pencil', 16); ?>
                        نوشتن مطلب جدید
                    </a>
                <?php else: ?>
                    <a href="<?php $this->options->adminUrl('login.php'); ?>" class="btn btn--primary">
                        <?php echo mijam_icon('user', 16); ?>
                        ورود به پیشخوان
                    </a>
                <?php endif; ?>
            </div>

        <?php endif; ?>

    </div>

    <?php if ($showSidebar): ?>
    <aside class="sidebar" aria-label="نوار کناری">
        <?php $this->need('sidebar.php'); ?>
    </aside>
    <?php endif; ?>

</main>

<?php $this->need('footer.php'); ?>
