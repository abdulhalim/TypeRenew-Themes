<?php
/**
 * سپیده — پوسته کلینیک زیبایی و اسپا
 *
 * @package سپیده
 * @author پوردریایی
 * @link https://pourdaryaei.ir
 * @version 1.0.1
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');


if (sepideh_is_front()):

    /* ================================================================
     *  صفحهٔ اصلی — لندینگ کلینیک زیبایی
     * ================================================================ */

    // ---------- داده‌های هیرو ----------
    $sepidehHeroBadge    = sepideh_opt('sepidehHeroBadge', 'کلینیک زیبایی تخصصی بانوان');
    $sepidehHeroTitle    = sepideh_opt('sepidehHeroTitle', 'درخشش واقعی پوست شما با هنر ما');
    $sepidehHeroSubtitle = trim((string)sepideh_opt_raw('sepidehHeroSubtitle'));
    $sepidehHeroSubtitle = ($sepidehHeroSubtitle === '') ? "در کلینیک سپیده، تیم متخصص ما با دستگاه‌های روز دنیا و روش‌های کاملاً ایمن، زیبایی و شادابی پوست شما را دوباره زنده می‌کند." : $sepidehHeroSubtitle;
    $sepidehHeroImageRaw = trim((string)sepideh_opt_raw('sepidehHeroImage'));
    $sepidehHeroImage    = ($sepidehHeroImageRaw !== '') ? sepideh_resolve_url($sepidehHeroImageRaw) : sepideh_asset('img/hero.jpg');
    $sepidehHeroBtn1Text = sepideh_opt('sepidehHeroBtn1Text', 'دریافت نوبت');
    $sepidehHeroBtn1Url  = sepideh_opt('sepidehHeroBtn1Url', '#contact');
    $sepidehHeroBtn2Text = sepideh_opt_raw('sepidehHeroBtn2Text');
    $sepidehHeroBtn2Url  = sepideh_opt_raw('sepidehHeroBtn2Url');
    $sepidehHeroStats    = sepideh_parse_stats(sepideh_opt_raw('sepidehHeroStats'));

    // ---------- داده‌های بخش‌ها ----------
    $sepidehServicesTitle = trim((string)sepideh_opt_raw('sepidehServicesTitle'));
    $sepidehServices      = sepideh_parse_services(sepideh_opt_raw('sepidehServices'));
    if (empty($sepidehServices) && $sepidehServicesTitle !== '') {
        $sepidehServices = sepideh_parse_services("sparkles | مزوتراپی و ژرفیلر | تزریق ژل و ویتامین‌های پوست\ndroplet | لیزر موهای زائد | لیزر دیود فریزر\nsun | پاکسازی و هیدرودرم | پاکسازی عمیق پوست\nzap | الکترولیفت | سفت‌کردن پوست بدون جراحی");
    }
    $sepidehServicesSubtitle = sepideh_opt('sepidehServicesSubtitle', 'هر آنچه برای زیبایی و سلامت پوست شما نیاز دارید، زیر یک سقف');

    $sepidehAboutTitle = trim((string)sepideh_opt_raw('sepidehAboutTitle'));
    $sepidehAboutText  = (string)sepideh_opt('sepidehAboutText', '');
    $sepidehAboutImageRaw = trim((string)sepideh_opt_raw('sepidehAboutImage'));
    $sepidehAboutImage = ($sepidehAboutImageRaw !== '') ? sepideh_resolve_url($sepidehAboutImageRaw) : sepideh_asset('img/about.jpg');
    $sepidehAboutFeatures = sepideh_parse_features(sepideh_opt_raw('sepidehAboutFeatures'));
    $sepidehAboutBtnText = trim((string)sepideh_opt_raw('sepidehAboutBtnText'));
    $sepidehAboutBtnUrl  = trim((string)sepideh_opt_raw('sepidehAboutBtnUrl'));
    if ($sepidehAboutBtnUrl === '') { $sepidehAboutBtnUrl = '#contact'; }

    $sepidehGalleryTitle    = trim((string)sepideh_opt_raw('sepidehGalleryTitle'));
    $sepidehGallerySubtitle = sepideh_opt('sepidehGallerySubtitle', 'گوشه‌ای از خدمات و فضای دنج کلینیک ما');
    $sepidehGalleryImages   = sepideh_parse_gallery(sepideh_opt_raw('sepidehGalleryImages'));
    if (empty($sepidehGalleryImages)) {
        $sepidehGalleryImages = [sepideh_asset('img/gallery-1.jpg'), sepideh_asset('img/gallery-2.jpg'), sepideh_asset('img/gallery-3.jpg'), sepideh_asset('img/gallery-4.jpg')];
    }

    $sepidehTeamTitle    = trim((string)sepideh_opt_raw('sepidehTeamTitle'));
    $sepidehTeamSubtitle = sepideh_opt('sepidehTeamSubtitle', 'متخصصانی که زیبایی شما را به آنها بسپارید');
    $sepidehTeam         = sepideh_parse_team(sepideh_opt_raw('sepidehTeam'));
    $sepidehTeamDefaultImg = [sepideh_asset('img/team-1.jpg'), sepideh_asset('img/team-2.jpg'), sepideh_asset('img/team-3.jpg'), sepideh_asset('img/team-4.jpg')];

    $sepidehTestTitle    = trim((string)sepideh_opt_raw('sepidehTestimonialsTitle'));
    $sepidehTestSubtitle = sepideh_opt('sepidehTestimonialsSubtitle', 'اعتماد شما، بزرگ‌ترین سرمایهٔ ماست');
    $sepidehTestimonials = sepideh_parse_testimonials(sepideh_opt_raw('sepidehTestimonials'));

    $sepidehBlogShow = sepideh_opt('sepidehBlogShow', '1') === '1';
    $sepidehBlogTitle = sepideh_opt('sepidehBlogTitle', 'آخرین مقالات');
    $sepidehBlogSubtitle = sepideh_opt('sepidehBlogSubtitle', 'راهنمایی و نکات مراقبت از پوست و زیبایی');
    $sepidehBlogCount = max(1, min(12, (int)sepideh_opt('sepidehBlogCount', '3')));

    $sepidehContactTitle    = trim((string)sepideh_opt_raw('sepidehContactTitle'));
    $sepidehContactSubtitle = sepideh_opt('sepidehContactSubtitle', 'همین حالا نوبت خود را رزرو کنید؛ مشاورهٔ اولیه رایگان است');
    $sepidehContactPhone  = sepideh_opt_raw('sepidehContactPhone');
    $sepidehContactPhone2 = sepideh_opt_raw('sepidehContactPhone2');
    $sepidehContactEmail  = sepideh_opt_raw('sepidehContactEmail');
    $sepidehContactAddr   = sepideh_opt_raw('sepidehContactAddress');
    $sepidehContactHours  = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string)sepideh_opt_raw('sepidehContactHours'))));
    $sepidehMapEmbed = trim((string)sepideh_opt_raw('sepidehMapEmbed'));
?>

    <!-- ==================== هیرو ==================== -->
    <section class="hero" id="home">
        <div class="hero-decor hero-decor-1" aria-hidden="true"></div>
        <div class="hero-decor hero-decor-2" aria-hidden="true"></div>
        <div class="container hero-inner">
            <div class="hero-content">
                <?php if ($sepidehHeroBadge !== ''): ?>
                <span class="hero-badge">
                    <?php echo sepideh_icon('sparkles', 15); ?>
                    <?php echo htmlspecialchars($sepidehHeroBadge, ENT_QUOTES); ?>
                </span>
                <?php endif; ?>
                <h1 class="hero-title"><?php echo htmlspecialchars($sepidehHeroTitle, ENT_QUOTES); ?></h1>
                <div class="hero-subtitle">
                    <?php foreach (array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $sepidehHeroSubtitle))) as $sepidehHeroP): ?>
                    <p><?php echo htmlspecialchars($sepidehHeroP, ENT_QUOTES); ?></p>
                    <?php endforeach; ?>
                </div>
                <div class="hero-actions">
                    <?php if (trim($sepidehHeroBtn1Text) !== ''): ?>
                    <a href="<?php echo htmlspecialchars(sepideh_link_url($sepidehHeroBtn1Url), ENT_QUOTES); ?>" class="btn btn-primary btn-lg">
                        <?php echo sepideh_icon('calendar-check', 18); ?>
                        <?php echo htmlspecialchars($sepidehHeroBtn1Text, ENT_QUOTES); ?>
                    </a>
                    <?php endif; ?>
                    <?php if ($sepidehHeroBtn2Text !== null && trim($sepidehHeroBtn2Text) !== ''): ?>
                    <a href="<?php echo htmlspecialchars(sepideh_link_url((string)$sepidehHeroBtn2Url), ENT_QUOTES); ?>" class="btn btn-ghost btn-lg">
                        <?php echo sepideh_icon('sparkles', 17); ?>
                        <?php echo htmlspecialchars($sepidehHeroBtn2Text, ENT_QUOTES); ?>
                    </a>
                    <?php endif; ?>
                </div>
                <?php if (!empty($sepidehHeroStats)): ?>
                <div class="hero-stats">
                    <?php foreach ($sepidehHeroStats as $sepidehStat): ?>
                    <div class="hero-stat">
                        <span class="hero-stat-num"><?php echo toPersianNumbers(htmlspecialchars($sepidehStat['num'], ENT_QUOTES)); ?></span>
                        <span class="hero-stat-label"><?php echo htmlspecialchars($sepidehStat['label'], ENT_QUOTES); ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="hero-visual">
                <div class="hero-img-frame">
                    <img src="<?php echo htmlspecialchars($sepidehHeroImage, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($sepidehHeroTitle, ENT_QUOTES); ?>" class="hero-img" fetchpriority="high">
                </div>
                <div class="hero-card hero-card-1">
                    <?php echo sepideh_icon('shield-check', 20); ?>
                    <div>
                        <strong>مواد اورجینال</strong>
                        <span>دارای مجوز رسمی</span>
                    </div>
                </div>
                <div class="hero-card hero-card-2">
                    <?php echo sepideh_icon('heart', 18); ?>
                    <div>
                        <strong>۸۵۰۰+ مراجع راضی</strong>
                        <span>۱۵ سال تجربه</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php if (!empty($sepidehServices) && $sepidehServicesTitle !== ''): ?>
    <!-- ==================== خدمات ==================== -->
    <section class="section services-section" id="services">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo sepideh_icon('sparkles', 14); ?> خدمات ما</span>
                <h2 class="section-title"><?php echo htmlspecialchars($sepidehServicesTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($sepidehServicesSubtitle, ENT_QUOTES); ?></p>
            </div>
            <div class="services-grid">
                <?php foreach ($sepidehServices as $sepidehService): ?>
                <div class="service-card">
                    <div class="service-icon"><?php echo sepideh_icon($sepidehService['icon'], 26); ?></div>
                    <h3 class="service-title"><?php echo htmlspecialchars($sepidehService['title'], ENT_QUOTES); ?></h3>
                    <?php if ($sepidehService['desc'] !== ''): ?>
                    <p class="service-desc"><?php echo htmlspecialchars($sepidehService['desc'], ENT_QUOTES); ?></p>
                    <?php endif; ?>
                    <?php if ($sepidehService['url'] !== '' && $sepidehService['url'] !== '#'): ?>
                    <a href="<?php echo htmlspecialchars(sepideh_link_url($sepidehService['url']), ENT_QUOTES); ?>" class="service-link">
                        جزئیات بیشتر <?php echo sepideh_icon('arrow-left', 15); ?>
                    </a>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($sepidehAboutTitle !== ''): ?>
    <!-- ==================== درباره کلینیک ==================== -->
    <section class="section about-section" id="about">
        <div class="container about-inner">
            <div class="about-visual">
                <div class="about-img-frame">
                    <img src="<?php echo htmlspecialchars($sepidehAboutImage, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($sepidehAboutTitle, ENT_QUOTES); ?>" class="about-img" loading="lazy">
                </div>
                <div class="about-badge">
                    <span class="about-badge-num"><?php echo toPersianNumbers('15'); ?>+</span>
                    <span class="about-badge-label">سال تجربه</span>
                </div>
            </div>
            <div class="about-content">
                <span class="section-tag"><?php echo sepideh_icon('users', 14); ?> درباره ما</span>
                <h2 class="section-title"><?php echo htmlspecialchars($sepidehAboutTitle, ENT_QUOTES); ?></h2>
                <div class="about-text">
                    <?php foreach (array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $sepidehAboutText))) as $sepidehAboutP): ?>
                    <p><?php echo htmlspecialchars($sepidehAboutP, ENT_QUOTES); ?></p>
                    <?php endforeach; ?>
                </div>
                <?php if (!empty($sepidehAboutFeatures)): ?>
                <div class="about-features">
                    <?php foreach ($sepidehAboutFeatures as $sepidehFeature): ?>
                    <div class="about-feature">
                        <span class="about-feature-icon"><?php echo sepideh_icon($sepidehFeature['icon'], 20); ?></span>
                        <div class="about-feature-text">
                            <strong><?php echo htmlspecialchars($sepidehFeature['title'], ENT_QUOTES); ?></strong>
                            <?php if ($sepidehFeature['desc'] !== ''): ?>
                            <span><?php echo htmlspecialchars($sepidehFeature['desc'], ENT_QUOTES); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                <?php if ($sepidehAboutBtnText !== ''): ?>
                <a href="<?php echo htmlspecialchars(sepideh_link_url($sepidehAboutBtnUrl), ENT_QUOTES); ?>" class="btn btn-primary">
                    <?php echo sepideh_icon('calendar-check', 17); ?>
                    <?php echo htmlspecialchars($sepidehAboutBtnText, ENT_QUOTES); ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($sepidehGalleryImages) && $sepidehGalleryTitle !== ''): ?>
    <!-- ==================== گالری ==================== -->
    <section class="section gallery-section" id="gallery">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo sepideh_icon('gem', 14); ?> گالری</span>
                <h2 class="section-title"><?php echo htmlspecialchars($sepidehGalleryTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($sepidehGallerySubtitle, ENT_QUOTES); ?></p>
            </div>
            <div class="gallery-grid" id="galleryGrid">
                <?php foreach ($sepidehGalleryImages as $sepidehImg): ?>
                <button type="button" class="gallery-item" data-src="<?php echo htmlspecialchars($sepidehImg, ENT_QUOTES); ?>">
                    <img src="<?php echo htmlspecialchars($sepidehImg, ENT_QUOTES); ?>" alt="نمونه‌کار کلینیک" loading="lazy">
                </button>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($sepidehTeam) && $sepidehTeamTitle !== ''): ?>
    <!-- ==================== تیم متخصصان ==================== -->
    <section class="section team-section" id="team">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo sepideh_icon('users', 14); ?> تیم ما</span>
                <h2 class="section-title"><?php echo htmlspecialchars($sepidehTeamTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($sepidehTeamSubtitle, ENT_QUOTES); ?></p>
            </div>
            <div class="team-grid">
                <?php foreach ($sepidehTeam as $sepidehIdx => $sepidehMember):
                    $sepidehPhoto = $sepidehMember['photo'] !== '' ? $sepidehMember['photo'] : ($sepidehTeamDefaultImg[$sepidehIdx % 4] ?? sepideh_asset('img/team-1.jpg'));
                ?>
                <div class="team-card">
                    <div class="team-photo-frame">
                        <img src="<?php echo htmlspecialchars($sepidehPhoto, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($sepidehMember['name'], ENT_QUOTES); ?>" class="team-photo" loading="lazy">
                    </div>
                    <div class="team-info">
                        <h3 class="team-name"><?php echo htmlspecialchars($sepidehMember['name'], ENT_QUOTES); ?></h3>
                        <span class="team-role"><?php echo htmlspecialchars($sepidehMember['role'], ENT_QUOTES); ?></span>
                        <?php if ($sepidehMember['desc'] !== ''): ?>
                        <p class="team-desc"><?php echo htmlspecialchars($sepidehMember['desc'], ENT_QUOTES); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($sepidehTestimonials) && $sepidehTestTitle !== ''): ?>
    <!-- ==================== نظرات مشتریان ==================== -->
    <section class="section testimonials-section" id="testimonials">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo sepideh_icon('message-circle', 14); ?> نظرات</span>
                <h2 class="section-title"><?php echo htmlspecialchars($sepidehTestTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($sepidehTestSubtitle, ENT_QUOTES); ?></p>
            </div>
            <div class="testimonials-grid">
                <?php foreach ($sepidehTestimonials as $sepidehTestimonial): ?>
                <figure class="testimonial-card">
                    <span class="testimonial-quote" aria-hidden="true"><?php echo sepideh_icon('quote', 30); ?></span>
                    <blockquote class="testimonial-text"><?php echo htmlspecialchars($sepidehTestimonial['text'], ENT_QUOTES); ?></blockquote>
                    <figcaption class="testimonial-author">
                        <span class="testimonial-avatar" aria-hidden="true"><?php echo htmlspecialchars(sepideh_initial($sepidehTestimonial['name']), ENT_QUOTES); ?></span>
                        <div class="testimonial-author-text">
                            <strong><?php echo htmlspecialchars($sepidehTestimonial['name'], ENT_QUOTES); ?></strong>
                            <span><?php echo htmlspecialchars($sepidehTestimonial['role'], ENT_QUOTES); ?></span>
                        </div>
                        <span class="testimonial-stars" aria-label="پنج ستاره">
                            <?php for ($sepidehStar = 0; $sepidehStar < 5; $sepidehStar++): ?><?php echo sepideh_icon('star', 13); ?><?php endfor; ?>
                        </span>
                    </figcaption>
                </figure>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($sepidehBlogShow): ?>
    <!-- ==================== وبلاگ (کوچک) ==================== -->
    <section class="section blog-section" id="blog">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo sepideh_icon('file-text', 14); ?> وبلاگ</span>
                <h2 class="section-title"><?php echo htmlspecialchars($sepidehBlogTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($sepidehBlogSubtitle, ENT_QUOTES); ?></p>
            </div>
            <?php
            // ---------- آخرین نوشته‌های وبلاگ ----------
            try {
                $sepidehRecent = \Widget\Contents\Post\Recent::allocWithAlias('sepideh-home', ['pageSize' => $sepidehBlogCount]);
            } catch (\Throwable $e) {
                $sepidehRecent = null;
            }
            if ($sepidehRecent && $sepidehRecent->have()):
            ?>
            <div class="blog-grid">
                <?php while ($sepidehRecent->next()): ?>
                <article class="blog-card">
                    <a href="<?php $sepidehRecent->permalink(); ?>" class="blog-card-link">
                        <div class="blog-card-thumb">
                            <img src="<?php echo htmlspecialchars(sepideh_thumbnail($sepidehRecent), ENT_QUOTES); ?>" alt="<?php echo sepideh_fa_title($sepidehRecent); ?>" loading="lazy">
                        </div>
                        <div class="blog-card-body">
                            <div class="blog-card-meta">
                                <span><?php echo sepideh_icon('calendar', 13); ?> <?php echo sepideh_post_date($sepidehRecent, 'j F Y'); ?></span>
                                <?php if (sepideh_opt('sepidehShowViews', '1') === '1'): ?>
                                <span><?php echo sepideh_icon('eye', 13); ?> <?php echo sepideh_num(sepideh_views($sepidehRecent)); ?></span>
                                <?php endif; ?>
                            </div>
                            <h3 class="blog-card-title"><?php echo sepideh_fa_title($sepidehRecent); ?></h3>
                            <p class="blog-card-excerpt"><?php echo toPersianNumbers(mb_substr(trim(strip_tags((string)$sepidehRecent->excerpt)), 0, 90, 'UTF-8') . '...'); ?></p>
                            <span class="blog-card-more">ادامه مطلب <?php echo sepideh_icon('arrow-left', 14); ?></span>
                        </div>
                    </a>
                </article>
                <?php endwhile; ?>
            </div>
            <div class="blog-more-row">
                <a href="<?php echo htmlspecialchars(sepideh_blog_url(), ENT_QUOTES); ?>" class="btn btn-ghost"><?php echo sepideh_icon('file-text', 16); ?> همهٔ مقالات</a>
            </div>
            <?php else: ?>
            <p class="blog-empty">هنوز مقاله‌ای منتشر نشده است.</p>
            <?php endif; ?>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($sepidehContactTitle !== ''): ?>
    <!-- ==================== تماس و نوبت‌گیری ==================== -->
    <section class="section contact-section" id="contact">
        <div class="container">
            <div class="contact-banner">
                <div class="contact-banner-decor" aria-hidden="true"><?php echo sepideh_icon('sparkles', 120); ?></div>
                <div class="contact-banner-content">
                    <h2 class="contact-title"><?php echo htmlspecialchars($sepidehContactTitle, ENT_QUOTES); ?></h2>
                    <p class="contact-subtitle"><?php echo htmlspecialchars($sepidehContactSubtitle, ENT_QUOTES); ?></p>
                    <?php
                    // دکمهٔ «رزرو نوبت» — فقط وقتی افزونهٔ Booking فعال باشد نمایش داده می‌شود
                    $sepidehBookingUrl = sepideh_booking_url();
                    if ($sepidehBookingUrl !== null):
                    ?>
                    <div class="contact-banner-actions">
                        <a href="<?php echo htmlspecialchars($sepidehBookingUrl, ENT_QUOTES); ?>" class="btn btn-light btn-lg">
                            <?php echo sepideh_icon('calendar-check', 18); ?>
                            رزرو نوبت
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="contact-grid">
                <div class="contact-info">
                    <h3 class="contact-info-title"><?php echo sepideh_icon('info', 17); ?> اطلاعات تماس</h3>
                    <ul class="contact-list">
                        <?php if ($sepidehContactAddr !== null && trim($sepidehContactAddr) !== ''): ?>
                        <li class="contact-item">
                            <span class="contact-item-icon"><?php echo sepideh_icon('map-pin', 20); ?></span>
                            <div class="contact-item-text">
                                <strong>نشانی کلینیک</strong>
                                <span><?php echo htmlspecialchars($sepidehContactAddr, ENT_QUOTES); ?></span>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php if ($sepidehContactPhone !== null && trim($sepidehContactPhone) !== ''): ?>
                        <li class="contact-item">
                            <span class="contact-item-icon"><?php echo sepideh_icon('phone-call', 20); ?></span>
                            <div class="contact-item-text">
                                <strong>تلفن ثابت</strong>
                                <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $sepidehContactPhone), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($sepidehContactPhone), ENT_QUOTES); ?></a>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php if ($sepidehContactPhone2 !== null && trim($sepidehContactPhone2) !== ''): ?>
                        <li class="contact-item">
                            <span class="contact-item-icon"><?php echo sepideh_icon('message-circle', 20); ?></span>
                            <div class="contact-item-text">
                                <strong>موبایل / واتس‌اپ</strong>
                                <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $sepidehContactPhone2), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($sepidehContactPhone2), ENT_QUOTES); ?></a>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php if ($sepidehContactEmail !== null && trim($sepidehContactEmail) !== ''): ?>
                        <li class="contact-item">
                            <span class="contact-item-icon"><?php echo sepideh_icon('mail', 20); ?></span>
                            <div class="contact-item-text">
                                <strong>ایمیل</strong>
                                <a href="mailto:<?php echo htmlspecialchars($sepidehContactEmail, ENT_QUOTES); ?>"><?php echo htmlspecialchars($sepidehContactEmail, ENT_QUOTES); ?></a>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php foreach ($sepidehContactHours as $sepidehHour): ?>
                        <li class="contact-item">
                            <span class="contact-item-icon"><?php echo sepideh_icon('clock', 20); ?></span>
                            <div class="contact-item-text">
                                <strong>ساعت کاری</strong>
                                <span><?php echo htmlspecialchars($sepidehHour, ENT_QUOTES); ?></span>
                            </div>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php if ($sepidehMapEmbed !== ''): ?>
                <div class="contact-map">
                    <?php echo $sepidehMapEmbed; /* کد iframe نقشه — از تنظیمات */ ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

<?php
else:

    /* ================================================================
     *  فهرست وبلاگ — مسیر آرشیو (/blog/) و صفحه‌بندی آن (/page/2/ …)
     * ================================================================ */
?>
    <div class="container archive-wrap">
        <header class="archive-head">
            <span class="section-tag"><?php echo sepideh_icon('file-text', 14); ?> وبلاگ</span>
            <h1 class="archive-title">
                <?php if ($this->is('archive')): ?>
                    <?php $this->archiveTitle(['category' => _t('دستهٔ %s'), 'search' => _t('جستجو: %s'), 'tag' => _t('برچسب %s'), 'author' => _t('نوشته‌های %s'), 'date' => _t('آرشیو %s')], '', ''); ?>
                <?php else: ?>
                    <?php echo htmlspecialchars(sepideh_opt('sepidehBlogTitle', 'آخرین مقالات') === 'آخرین مقالات' ? 'همهٔ مقالات' : sepideh_opt('sepidehBlogTitle', 'آخرین مقالات'), ENT_QUOTES); ?>
                <?php endif; ?>
            </h1>
            <p class="section-subtitle"><?php echo htmlspecialchars(sepideh_opt('sepidehBlogSubtitle', 'راهنمایی و نکات مراقبت از پوست و زیبایی'), ENT_QUOTES); ?></p>
        </header>

        <?php if ($this->have()): ?>
        <div class="archive-grid">
            <?php while ($this->next()): ?>
            <article class="blog-card">
                <a href="<?php $this->permalink(); ?>" class="blog-card-link">
                    <div class="blog-card-thumb">
                        <img src="<?php echo htmlspecialchars(sepideh_thumbnail($this), ENT_QUOTES); ?>" alt="<?php $this->title(); ?>" loading="lazy">
                    </div>
                    <div class="blog-card-body">
                        <div class="blog-card-meta">
                            <span><?php echo sepideh_icon('calendar', 13); ?> <?php echo sepideh_post_date($this, 'j F Y'); ?></span>
                            <?php if (sepideh_opt('sepidehShowViews', '1') === '1'): ?>
                            <span><?php echo sepideh_icon('eye', 13); ?> <?php echo sepideh_num(sepideh_views($this)); ?></span>
                            <?php endif; ?>
                        </div>
                        <h2 class="blog-card-title"><?php $this->title(); ?></h2>
                        <p class="blog-card-excerpt"><?php echo mb_substr(trim(strip_tags((string)$this->excerpt)), 0, 90, 'UTF-8') . '...'; ?></p>
                        <span class="blog-card-more">ادامه مطلب <?php echo sepideh_icon('arrow-left', 14); ?></span>
                    </div>
                </a>
            </article>
            <?php endwhile; ?>
        </div>
        <?php else: ?>
        <div class="archive-empty">
            <?php echo sepideh_icon('search', 44); ?>
            <p>هنوز مقاله‌ای منتشر نشده است.</p>
            <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-ghost">بازگشت به خانه</a>
        </div>
        <?php endif; ?>

        <?php
        // ---------- صفحه‌بندی (روی مسیر /page/2/ … همان فهرست ادامه می‌یابد) ----------
        // فراخوانی از طریق هلپر: ترتیب آرگومان‌های pageNav هسته باید
        // (قبلی، بعدی، int تعداد، جداکننده، قالب) باشد — رفع TypeError نسخه‌های قبل.
        sepideh_page_nav($this);
        ?>
    </div>
<?php endif; ?>

<?php $this->need('footer.php'); ?>
