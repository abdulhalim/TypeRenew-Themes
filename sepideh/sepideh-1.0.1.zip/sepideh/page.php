<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$GLOBALS['sepidehPostJs'] = true;

$this->need('header.php');
?>

<article class="page-wrap container">
    <header class="page-head">
        <nav class="post-breadcrumb" aria-label="مسیر">
            <a href="<?php $this->options->siteUrl(); ?>">خانه</a>
            <span class="crumb-sep">/</span>
            <span aria-current="page"><?php echo sepideh_fa_title($this); ?></span>
        </nav>
        <h1 class="page-title"><?php echo sepideh_fa_title($this); ?></h1>
        <div class="post-meta">
            <span class="post-meta-item">
                <?php echo sepideh_icon('calendar', 15); ?>
                <time datetime="<?php $this->date('c'); ?>"><?php echo sepideh_post_date($this, 'j F Y'); ?></time>
            </span>
            <?php if (sepideh_opt('sepidehShowViews', '1') === '1'): ?>
            <span class="post-meta-item">
                <?php echo sepideh_icon('eye', 15); ?>
                <?php echo sepideh_num(sepideh_views($this)); ?> بازدید
            </span>
            <?php endif; ?>
        </div>
    </header>

    <?php $sepidehPageCover = sepideh_thumbnail($this, false); if ($sepidehPageCover !== ''): ?>
    <figure class="post-cover">
        <img src="<?php echo htmlspecialchars($sepidehPageCover, ENT_QUOTES); ?>" alt="<?php echo sepideh_fa_title($this); ?>">
    </figure>
    <?php endif; ?>

    <div class="post-content page-content">
        <?php $this->content(); ?>
    </div>

    <?php $this->need('comments.php'); ?>
</article>

<?php $this->need('footer.php'); ?>
