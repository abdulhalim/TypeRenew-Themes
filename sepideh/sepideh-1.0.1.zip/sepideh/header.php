<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="<?php $this->options->charset(); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php if ($this->options->favicon): ?>
    <link rel="icon" href="<?php $this->options->favicon(); ?>">
<?php endif; ?>
<title><?php $this->archiveTitle([
            'category' => _t('دستهٔ %s'),
            'search'   => _t('نتایج جستجوی %s'),
            'tag'      => _t('برچسب %s'),
            'author'   => _t('نوشته‌های %s')
        ], '', ' - '); ?><?php $this->options->title(); ?></title>
<?php
// ---------- توضیحات متا (فقط صفحهٔ اول؛ صفحات تکی خود TypeRenew متا تولید می‌کند) ----------
$sepidehMetaDesc = '';
try {
    if (sepideh_is_front()) {
        $sepidehMetaDesc = trim((string)sepideh_opt_raw('sepidehHeroSubtitle'));
        $sepidehMetaDesc = $sepidehMetaDesc !== '' ? trim(preg_replace('/\s+/', ' ', strip_tags(str_replace("\n", ' ', $sepidehMetaDesc)))) : '';
        if (mb_strlen($sepidehMetaDesc) > 160) {
            $sepidehMetaDesc = mb_substr($sepidehMetaDesc, 0, 157, 'UTF-8') . '...';
        }
    }
} catch (\Throwable $e) {
}
if ($sepidehMetaDesc !== ''):
?>
<meta name="description" content="<?php echo htmlspecialchars($sepidehMetaDesc, ENT_QUOTES); ?>">
<?php endif; ?>
<?php $this->header(); ?>

<?php
// ---------- رنگ‌های داینامیک ----------
$sepidehPrimary   = sepideh_opt('sepidehPrimaryColor', '#d94670');
$sepidehSecondary = sepideh_opt('sepidehSecondaryColor', '#6d2949');
if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $sepidehPrimary)) { $sepidehPrimary = '#d94670'; }
if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $sepidehSecondary)) { $sepidehSecondary = '#6d2949'; }
?>

<style>:root{--primary:<?php echo $sepidehPrimary; ?>;--secondary:<?php echo $sepidehSecondary; ?>;}</style>

<!-- ---------- استایل‌های اصلی (با نسخه برای جلوگیری از کش) ---------- -->
<link rel="stylesheet" href="<?php $this->options->themeUrl('css/style.css'); ?>?v=1.4">
<link rel="stylesheet" href="<?php $this->options->themeUrl('css/fonts.css'); ?>?v=1.4">
</head>
<body class="sepideh-body farsi-digits">
<a href="#main" class="skip-link">رفتن به محتوای اصلی</a>

<?php
// ---------- داده‌های مشترک ----------
$sepidehClinicName = sepideh_opt('sepidehClinicName', (string)$this->options->title);
$sepidehTagline    = sepideh_opt('sepidehTagline', 'زیبایی شما، هنر ماست');
$sepidehLogoUrl    = sepideh_logo_url();
$sepidehPhone      = sepideh_opt_raw('sepidehContactPhone');
$sepidehShowTopbar = sepideh_opt('sepidehShowTopbar', '1') === '1';
// آیا همین صفحه، صفحهٔ اول (لندینگ) است؟ لینک‌های #hash فقط در این صفحه اسکرول درون‌صفحه‌اند؛
// در صفحات دیگر به «آدرس سایت + #hash» تبدیل می‌شوند تا منو در همهٔ صفحات کامل بماند.
// (بر مبنای مسیر جاری، نه is() — بعد از تبدیل مسیر آرشیو به فهرست وبلاگ، is('index') آنجا هم true است)
$sepidehOnHome     = sepideh_is_front();
// آدرس فهرست وبلاگ: مسیر آرشیو تایپ‌رینیو (پیش‌فرض /blog/) یا آدرس سفارشی مدیر
$sepidehBlogUrl    = sepideh_blog_url();
// آیا همین صفحه، صفحهٔ فهرست وبلاگ (مسیر آرشیو) است؟ — برای حالت فعال منوی «وبلاگ»
$sepidehIsBlogPage = in_array(sepideh_route(), ['archive', 'archive_page'], true);
$sepidehSocial = [
    'instagram' => sepideh_opt_raw('sepidehSocialInstagram'),
    'telegram'  => sepideh_opt_raw('sepidehSocialTelegram'),
    'whatsapp'  => sepideh_opt_raw('sepidehSocialWhatsapp'),
    'youtube'   => sepideh_opt_raw('sepidehSocialYoutube'),
];
?>

<!-- ---------- نوار بالای هدر ---------- -->
<?php if ($sepidehShowTopbar): ?>
<div class="topbar">
    <div class="container topbar-inner">
        <div class="topbar-item topbar-phone">
            <?php echo sepideh_icon('phone', 15); ?>
            <?php if ($sepidehPhone !== null && trim($sepidehPhone) !== ''): ?>
                <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $sepidehPhone), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($sepidehPhone), ENT_QUOTES); ?></a>
            <?php endif; ?>
        </div>
        <div class="topbar-item topbar-hours">
            <?php echo sepideh_icon('clock', 15); ?>
            <span>شنبه تا چهارشنبه ۹ تا ۲۰</span>
        </div>
        <div class="topbar-social">
            <?php foreach ($sepidehSocial as $sepidehNet => $sepidehUrl): if (trim((string)$sepidehUrl) !== ''): ?>
                <a href="<?php echo htmlspecialchars($sepidehUrl, ENT_QUOTES); ?>" target="_blank" rel="noopener" aria-label="<?php echo ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام', 'whatsapp' => 'واتس‌اپ', 'youtube' => 'یوتیوب'][$sepidehNet]; ?>">
                    <?php echo sepideh_icon($sepidehNet === 'telegram' ? 'send' : ($sepidehNet === 'whatsapp' ? 'message-circle' : $sepidehNet), 15); ?>
                </a>
            <?php endif; endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ---------- هدر اصلی ---------- -->
<header class="site-header<?php echo $sepidehShowTopbar ? '' : ' no-topbar'; ?>" id="siteHeader">
    <div class="container nav-container">

        <!-- بخش راست: لوگو -->
        <div class="nav-logo">
            <a href="<?php $this->options->siteUrl(); ?>" class="logo-link">
                <?php if ($sepidehLogoUrl !== ''): ?>
                    <img src="<?php echo htmlspecialchars($sepidehLogoUrl, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($sepidehClinicName, ENT_QUOTES); ?>" class="logo-img">
                <?php else: ?>
                    <span class="logo-mark" aria-hidden="true"><?php echo sepideh_icon('sparkles', 22); ?></span>
                <?php endif; ?>
                <span class="logo-text">
                    <span class="logo-main"><?php echo htmlspecialchars($sepidehClinicName, ENT_QUOTES); ?></span>
                    <span class="logo-sub"><?php echo htmlspecialchars($sepidehTagline, ENT_QUOTES); ?></span>
                </span>
            </a>
        </div>

        <!-- بخش وسط: منوی اصلی — در همهٔ صفحات کامل نمایش داده می‌شود؛
             لینک‌های بخش‌ها (#hash) در صفحات غیر از صفحهٔ اول به «آدرس سایت + #hash» تبدیل می‌شوند -->
        <nav class="main-nav" aria-label="منوی اصلی">
            <ul class="nav-links">
                <li><a href="<?php $this->options->siteUrl(); ?>" <?php if ($sepidehOnHome): ?>class="active" aria-current="page"<?php endif; ?>><?php echo sepideh_icon('home', 15); ?> خانه</a></li>
                <li><a href="<?php echo htmlspecialchars(sepideh_link_url('#services', $sepidehOnHome), ENT_QUOTES); ?>"><?php echo sepideh_icon('sparkles', 15); ?> خدمات</a></li>
                <li><a href="<?php echo htmlspecialchars(sepideh_link_url('#about', $sepidehOnHome), ENT_QUOTES); ?>"><?php echo sepideh_icon('users', 15); ?> درباره ما</a></li>
                <li><a href="<?php echo htmlspecialchars(sepideh_link_url('#team', $sepidehOnHome), ENT_QUOTES); ?>"><?php echo sepideh_icon('user', 15); ?> تیم</a></li>
                <li><a href="<?php echo htmlspecialchars($sepidehOnHome ? '#blog' : $sepidehBlogUrl, ENT_QUOTES); ?>" <?php if (!$sepidehOnHome && ($sepidehIsBlogPage || $this->is('archive') || $this->is('post'))): ?>class="active" aria-current="page"<?php endif; ?>><?php echo sepideh_icon('file-text', 15); ?> وبلاگ</a></li>
                <?php
                // ---------- برگه‌های انتخاب‌شده در منو ----------
                $sepidehNavPages = \Widget\Contents\Page\Rows::alloc();
                while ($sepidehNavPages->next()):
                ?>
                    <li><a href="<?php $sepidehNavPages->permalink(); ?>" <?php if ($this->is('page', $sepidehNavPages->slug)): ?>class="active" aria-current="page"<?php endif; ?>><?php echo sepideh_icon('file-text', 15); ?> <?php echo sepideh_fa_title($sepidehNavPages); ?></a></li>
                <?php endwhile; ?>
                <li><a href="<?php echo htmlspecialchars(sepideh_link_url('#contact', $sepidehOnHome), ENT_QUOTES); ?>" class="nav-contact-link"><?php echo sepideh_icon('phone', 15); ?> تماس</a></li>
            </ul>
        </nav>

        <!-- بخش چپ: دکمهٔ نوبت -->
        <div class="nav-actions">
            <?php
            $sepidehCtaText = sepideh_opt('sepidehHeroBtn1Text', 'دریافت نوبت');
            $sepidehCtaUrl  = sepideh_opt('sepidehHeroBtn1Url', '#contact');
            if (trim($sepidehCtaText) !== '' && trim($sepidehCtaUrl) !== ''):
            ?>
            <a href="<?php echo htmlspecialchars(sepideh_link_url($sepidehCtaUrl, $sepidehOnHome), ENT_QUOTES); ?>" class="nav-cta">
                <?php echo sepideh_icon('calendar-check', 16); ?>
                <span><?php echo htmlspecialchars($sepidehCtaText, ENT_QUOTES); ?></span>
            </a>
            <?php endif; ?>
            <button type="button" class="menu-toggle" id="menuToggle" aria-label="باز کردن منو" aria-expanded="false" aria-controls="mobileMenu">
                <?php echo sepideh_icon('menu', 22); ?>
            </button>
        </div>
    </div>
</header>

<!-- ---------- منوی موبایل ---------- -->
<div class="mobile-menu" id="mobileMenu" aria-hidden="true">
    <div class="mobile-menu-head">
        <span class="logo-mark" aria-hidden="true"><?php echo sepideh_icon('sparkles', 20); ?></span>
        <span class="mobile-menu-title"><?php echo htmlspecialchars($sepidehClinicName, ENT_QUOTES); ?></span>
        <button type="button" class="mobile-menu-close" id="menuClose" aria-label="بستن منو">
            <?php echo sepideh_icon('x', 20); ?>
        </button>
    </div>
    <nav class="mobile-nav" aria-label="منوی موبایل">
        <a href="<?php $this->options->siteUrl(); ?>" <?php if ($sepidehOnHome): ?>class="active" aria-current="page"<?php endif; ?>><?php echo sepideh_icon('home', 18); ?> خانه</a>
        <a href="<?php echo htmlspecialchars(sepideh_link_url('#services', $sepidehOnHome), ENT_QUOTES); ?>" data-close><?php echo sepideh_icon('sparkles', 18); ?> خدمات</a>
        <a href="<?php echo htmlspecialchars(sepideh_link_url('#about', $sepidehOnHome), ENT_QUOTES); ?>" data-close><?php echo sepideh_icon('users', 18); ?> درباره ما</a>
        <a href="<?php echo htmlspecialchars(sepideh_link_url('#team', $sepidehOnHome), ENT_QUOTES); ?>" data-close><?php echo sepideh_icon('user', 18); ?> تیم</a>
        <a href="<?php echo htmlspecialchars($sepidehOnHome ? '#blog' : $sepidehBlogUrl, ENT_QUOTES); ?>" data-close <?php if (!$sepidehOnHome && ($sepidehIsBlogPage || $this->is('archive') || $this->is('post'))): ?>class="active" aria-current="page"<?php endif; ?>><?php echo sepideh_icon('file-text', 18); ?> وبلاگ</a>
        <?php
        // ---------- برگه‌های انتخاب‌شده در منو ----------
        $sepidehNavPagesM = \Widget\Contents\Page\Rows::allocWithAlias('sepidehMobile');
        while ($sepidehNavPagesM->next()):
        ?>
            <a href="<?php $sepidehNavPagesM->permalink(); ?>"><?php echo sepideh_icon('file-text', 18); ?> <?php echo sepideh_fa_title($sepidehNavPagesM); ?></a>
        <?php endwhile; ?>
        <a href="<?php echo htmlspecialchars(sepideh_link_url('#contact', $sepidehOnHome), ENT_QUOTES); ?>" data-close class="nav-contact-link"><?php echo sepideh_icon('phone', 18); ?> تماس و نوبت</a>
    </nav>
    <?php if (trim((string)$sepidehCtaUrl) !== '' && trim($sepidehCtaText) !== ''): ?>
    <a href="<?php echo htmlspecialchars(sepideh_link_url($sepidehCtaUrl, $sepidehOnHome), ENT_QUOTES); ?>" class="mobile-cta">
        <?php echo sepideh_icon('calendar-check', 18); ?>
        <?php echo htmlspecialchars($sepidehCtaText, ENT_QUOTES); ?>
    </a>
    <?php endif; ?>
    <?php if ($sepidehPhone !== null && trim($sepidehPhone) !== ''): ?>
    <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $sepidehPhone), ENT_QUOTES); ?>" class="mobile-cta mobile-cta-phone">
        <?php echo sepideh_icon('phone-call', 18); ?>
        <?php echo htmlspecialchars(toPersianNumbers($sepidehPhone), ENT_QUOTES); ?>
    </a>
    <?php endif; ?>
</div>
<div class="menu-overlay" id="menuOverlay" aria-hidden="true"></div>

<main id="main" class="site-main">
