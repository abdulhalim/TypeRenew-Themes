<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');
?>

<div class="container error-wrap">
    <div class="error-card">
        <span class="error-code"><?php echo toPersianNumbers('404'); ?></span>
        <span class="error-icon" aria-hidden="true"><?php echo sepideh_icon('search', 52); ?></span>
        <h1 class="error-title">صفحه پیدا نشد!</h1>
        <p class="error-text">
            متأسفیم؛ صفحه‌ای که دنبالش بودید وجود ندارد، جابه‌جا شده یا آدرس آن اشتباه وارد شده است.
        </p>
        <div class="error-actions">
            <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-primary">
                <?php echo sepideh_icon('home', 16); ?>
                بازگشت به خانه
            </a>
            <a href="<?php echo htmlspecialchars(sepideh_link_url('#contact', false), ENT_QUOTES); ?>" class="btn btn-ghost">
                <?php echo sepideh_icon('phone', 16); ?>
                تماس با کلینیک
            </a>
        </div>
    </div>
</div>

<?php $this->need('footer.php'); ?>
