<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
</main>

<!-- ---------- فوتر سایت ---------- -->
<footer class="site-footer">
    <?php
    // ---------- داده‌های فوتر ----------
    $sepidehClinicName = sepideh_opt('sepidehClinicName', (string)$this->options->title);
    $sepidehTagline    = sepideh_opt('sepidehTagline', 'زیبایی شما، هنر ماست');
    $sepidehLogoUrl    = sepideh_logo_url();
    $sepidehFooterText = sepideh_opt('sepidehFooterText', 'کلینیک زیبایی سپیده — ترکیبی از علم روز و هنر ظریف ایرانی برای زیبایی ماندگار شما.');
    $sepidehPhone      = sepideh_opt_raw('sepidehContactPhone');
    $sepidehPhone2     = sepideh_opt_raw('sepidehContactPhone2');
    $sepidehEmail      = sepideh_opt_raw('sepidehContactEmail');
    $sepidehAddress    = sepideh_opt_raw('sepidehContactAddress');
    $sepidehHours      = (string)sepideh_opt_raw('sepidehContactHours');
    $sepidehSocial = [
        'instagram' => sepideh_opt_raw('sepidehSocialInstagram'),
        'telegram'  => sepideh_opt_raw('sepidehSocialTelegram'),
        'whatsapp'  => sepideh_opt_raw('sepidehSocialWhatsapp'),
        'youtube'   => sepideh_opt_raw('sepidehSocialYoutube'),
    ];
    $sepidehSocialNames = ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام', 'whatsapp' => 'واتس‌اپ', 'youtube' => 'یوتیوب'];
    ?>

    <!-- بخش اصلی فوتر -->
    <div class="container">
        <div class="footer-grid">

            <!-- ستون ۱: لوگو و معرفی -->
            <div class="footer-col footer-about">
                <div class="footer-logo">
                    <a href="<?php $this->options->siteUrl(); ?>" class="footer-logo-link">
                        <?php if ($sepidehLogoUrl !== ''): ?>
                            <img src="<?php echo htmlspecialchars($sepidehLogoUrl, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($sepidehClinicName, ENT_QUOTES); ?>" class="footer-logo-img">
                        <?php else: ?>
                            <span class="footer-logo-mark" aria-hidden="true"><?php echo sepideh_icon('sparkles', 20); ?></span>
                        <?php endif; ?>
                        <span class="footer-logo-text"><?php echo htmlspecialchars($sepidehClinicName, ENT_QUOTES); ?></span>
                    </a>
                </div>
                <p class="footer-desc"><?php echo htmlspecialchars($sepidehFooterText, ENT_QUOTES); ?></p>
                <div class="footer-social">
                    <?php foreach ($sepidehSocial as $sepidehNet => $sepidehUrl): if (trim((string)$sepidehUrl) !== ''): ?>
                        <a href="<?php echo htmlspecialchars($sepidehUrl, ENT_QUOTES); ?>" target="_blank" rel="noopener" aria-label="<?php echo $sepidehSocialNames[$sepidehNet]; ?>">
                            <?php echo sepideh_icon($sepidehNet === 'telegram' ? 'send' : ($sepidehNet === 'whatsapp' ? 'message-circle' : $sepidehNet), 17); ?>
                        </a>
                    <?php endif; endforeach; ?>
                </div>
            </div>

            <!-- ستون ۲: لینک‌های برگه‌ها -->
            <div class="footer-col">
                <h3 class="footer-title"><?php echo sepideh_icon('file-text', 17); ?> دسترسی سریع</h3>
                <ul class="footer-links">
                    <li><a href="<?php $this->options->siteUrl(); ?>">خانه</a></li>
                    <?php
                    $sepidehFooterPages = \Widget\Contents\Page\Rows::allocWithAlias('sepidehFooter');
                    while ($sepidehFooterPages->next()):
                    ?>
                        <li><a href="<?php $sepidehFooterPages->permalink(); ?>"><?php echo sepideh_fa_title($sepidehFooterPages); ?></a></li>
                    <?php endwhile; ?>
                </ul>
            </div>

            <!-- ستون ۳: اطلاعات تماس -->
            <div class="footer-col footer-contact-col">
                <h3 class="footer-title"><?php echo sepideh_icon('phone-call', 17); ?> تماس با ما</h3>
                <ul class="footer-contact">
                    <?php if ($sepidehAddress !== null && trim($sepidehAddress) !== ''): ?>
                    <li>
                        <?php echo sepideh_icon('map-pin', 16); ?>
                        <span><?php echo htmlspecialchars($sepidehAddress, ENT_QUOTES); ?></span>
                    </li>
                    <?php endif; ?>
                    <?php if ($sepidehPhone !== null && trim($sepidehPhone) !== ''): ?>
                    <li>
                        <?php echo sepideh_icon('phone', 16); ?>
                        <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $sepidehPhone), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($sepidehPhone), ENT_QUOTES); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if ($sepidehPhone2 !== null && trim($sepidehPhone2) !== ''): ?>
                    <li>
                        <?php echo sepideh_icon('message-circle', 16); ?>
                        <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $sepidehPhone2), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($sepidehPhone2), ENT_QUOTES); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if ($sepidehEmail !== null && trim($sepidehEmail) !== ''): ?>
                    <li>
                        <?php echo sepideh_icon('mail', 16); ?>
                        <a href="mailto:<?php echo htmlspecialchars($sepidehEmail, ENT_QUOTES); ?>"><?php echo htmlspecialchars($sepidehEmail, ENT_QUOTES); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php foreach (array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $sepidehHours))) as $sepidehHour): ?>
                    <li>
                        <?php echo sepideh_icon('clock', 16); ?>
                        <span><?php echo htmlspecialchars($sepidehHour, ENT_QUOTES); ?></span>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <!-- خط جداکننده و کپی‌رایت -->
    <div class="footer-bottom">
        <div class="container footer-bottom-inner">
            <div class="copyright">
                <span>© <?php echo sepideh_jalali_year(); ?> <?php echo htmlspecialchars($sepidehClinicName, ENT_QUOTES); ?> — تمامی حقوق محفوظ است.</span>
            </div>
            <div class="footer-powered">
                <span>قدرت گرفته از <a href="https://typerenew.com" target="_blank" rel="noopener">تایپ‌رینیو</a></span>
            </div>
        </div>
    </div>
</footer>

<!-- ---------- دکمهٔ بازگشت به بالا ---------- -->
<button type="button" class="back-to-top" id="backToTop" aria-label="بازگشت به بالا" title="بازگشت به بالا">
    <?php echo sepideh_icon('arrow-up', 19); ?>
</button>

<!-- ---------- مودال گالری (لایت‌باکس) ---------- -->
<div class="lightbox" id="lightbox" aria-hidden="true" role="dialog" aria-label="نمایش بزرگ تصویر">
    <button type="button" class="lightbox-close" id="lightboxClose" aria-label="بستن"><?php echo sepideh_icon('x', 24); ?></button>
    <button type="button" class="lightbox-nav lightbox-prev" id="lightboxPrev" aria-label="تصویر قبلی"><?php echo sepideh_icon('chevron-left', 26); ?></button>
    <img class="lightbox-img" id="lightboxImg" src="" alt="نمایش بزرگ تصویر">
    <button type="button" class="lightbox-nav lightbox-next" id="lightboxNext" aria-label="تصویر بعدی"><?php echo sepideh_icon('chevron-left', 26); ?></button>
</div>

<!-- ---------- اسکریپت‌ها ---------- -->
<script src="<?php $this->options->themeUrl('js/main.js'); ?>?v=1.4"></script>
<?php if (isset($GLOBALS['sepidehPostJs']) && $GLOBALS['sepidehPostJs']): ?>
<!-- لایک و کپی کد — فقط صفحات نوشته -->
<script src="<?php $this->options->themeUrl('js/likes.js'); ?>?v=1.4"></script>
<?php endif; ?>

<?php $this->footer(); ?>
</body>
</html>
