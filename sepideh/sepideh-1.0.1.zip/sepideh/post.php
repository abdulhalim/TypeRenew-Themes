<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$GLOBALS['sepidehPostJs'] = true;

$this->need('header.php');

$sepidehShowViews = sepideh_opt('sepidehShowViews', '1') === '1';
$sepidehShowLikes = sepideh_opt('sepidehShowLikes', '1') === '1';
$sepidehShowRelated = sepideh_opt('sepidehShowRelated', '1') === '1';
$sepidehShowAuthorBox = sepideh_opt('sepidehShowAuthorBox', '1') === '1';
$sepidehClinicName = sepideh_opt('sepidehClinicName', (string)$this->options->title);
?>

<article class="post-wrap container" itemscope itemtype="https://schema.org/BlogPosting">

    <!-- ---------- سربرگ نوشته ---------- -->
    <header class="post-head">
        <nav class="post-breadcrumb" aria-label="مسیر">
            <a href="<?php $this->options->siteUrl(); ?>">خانه</a>
            <span class="crumb-sep">/</span>
            <a href="<?php echo htmlspecialchars(sepideh_blog_url(), ENT_QUOTES); ?>">وبلاگ</a>
            <span class="crumb-sep">/</span>
            <span aria-current="page"><?php echo sepideh_fa_title($this); ?></span>
        </nav>

        <h1 class="post-title" itemprop="name headline"><?php echo sepideh_fa_title($this); ?></h1>

        <div class="post-meta">
            <span class="post-meta-item" itemprop="author" itemscope itemtype="https://schema.org/Person">
                <?php echo sepideh_icon('user', 15); ?>
                <span itemprop="name"><?php $this->author(); ?></span>
            </span>
            <span class="post-meta-item">
                <?php echo sepideh_icon('calendar', 15); ?>
                <time datetime="<?php $this->date('c'); ?>" itemprop="datePublished"><?php echo sepideh_post_date($this, 'j F Y'); ?></time>
            </span>
            <span class="post-meta-item">
                <?php echo sepideh_icon('folder', 15); ?>
                <?php $this->category(','); ?>
            </span>
            <?php if ($sepidehShowViews): ?>
            <span class="post-meta-item post-views" id="postViews">
                <?php echo sepideh_icon('eye', 15); ?>
                <?php echo sepideh_num(sepideh_views($this)); ?> بازدید
            </span>
            <?php endif; ?>
            <span class="post-meta-item">
                <?php echo sepideh_icon('message-square', 15); ?>
                <a href="#comments"><?php ob_start(); $this->commentsNum('بدون دیدگاه', '۱ دیدگاه', '%d دیدگاه'); echo toPersianNumbers(ob_get_clean()); ?></a>
            </span>
        </div>
    </header>

    <!-- ---------- تصویر شاخص ---------- -->
    <?php $sepidehCover = sepideh_thumbnail($this, false); if ($sepidehCover !== ''): ?>
    <figure class="post-cover">
        <img src="<?php echo htmlspecialchars($sepidehCover, ENT_QUOTES); ?>" alt="<?php echo sepideh_fa_title($this); ?>" itemprop="image">
    </figure>
    <?php endif; ?>

    <!-- ---------- محتوای نوشته ---------- -->
    <div class="post-content" itemprop="articleBody">
        <?php $this->content(); ?>
    </div>

    <!-- ---------- تگ‌ها ---------- -->
    <?php if ($this->tags): ?>
    <div class="post-tags">
        <?php echo sepideh_icon('tag', 15); ?>
        <?php $this->tags(' ', true, ''); ?>
    </div>
    <?php endif; ?>

    <!-- ---------- لایک ---------- -->
    <?php if ($sepidehShowLikes): ?>
    <?php
    $sepidehLikes = sepideh_likes($this);
    $sepidehLiked = sepideh_is_liked((int)$this->cid) ? '1' : '0';
    ?>
    <div class="post-like-row" id="sepidehLikeFloat">
        <button type="button" class="like-btn<?php echo $sepidehLiked === '1' ? ' is-liked' : ''; ?>" id="sepidehLikeBtn"
                data-cid="<?php echo (int)$this->cid; ?>" data-likes="<?php echo $sepidehLikes; ?>" data-liked="<?php echo $sepidehLiked; ?>"
                aria-pressed="<?php echo $sepidehLiked === '1' ? 'true' : 'false'; ?>">
            <?php echo sepideh_icon('heart', 18); ?>
            <span class="like-label"><?php echo $sepidehLiked === '1' ? 'پسندیدید' : 'این مطلب را پسندیدید؟'; ?></span>
            <span class="like-count"><?php echo sepideh_num($sepidehLikes); ?></span>
        </button>
    </div>
    <?php endif; ?>

    <!-- ---------- نویسنده ---------- -->
    <?php if ($sepidehShowAuthorBox): ?>
    <aside class="author-box">
        <span class="author-avatar">
            <?php $this->author->gravatar(96); ?>
            <span class="author-avatar-fallback" aria-hidden="true"><?php echo htmlspecialchars(sepideh_initial((string)$this->author->screenName), ENT_QUOTES); ?></span>
        </span>
        <div class="author-info">
            <strong class="author-name"><a href="<?php $this->author->permalink(); ?>" rel="author"><?php $this->author(); ?></a></strong>
            <span class="author-role">نویسنده در <?php echo htmlspecialchars($sepidehClinicName, ENT_QUOTES); ?></span>
            <?php if (trim((string)$this->author->description) !== ''): ?>
            <p class="author-desc"><?php $this->author->description(); ?></p>
            <?php endif; ?>
        </div>
    </aside>
    <?php endif; ?>

    <!-- ---------- نوشته‌های مرتبط ---------- -->
    <?php
    $sepidehRelated = $sepidehShowRelated ? sepideh_related_posts($this, 3) : [];
    if (!empty($sepidehRelated)):
    ?>
    <section class="related-posts">
        <h2 class="related-title"><?php echo sepideh_icon('file-text', 18); ?> نوشته‌های مرتبط</h2>
        <div class="related-grid">
            <?php foreach ($sepidehRelated as $sepidehRelatedPost): ?>
            <a href="<?php echo htmlspecialchars($sepidehRelatedPost['url'], ENT_QUOTES); ?>" class="related-card">
                <span class="related-card-title"><?php echo toPersianNumbers(htmlspecialchars($sepidehRelatedPost['title'], ENT_QUOTES)); ?></span>
                <span class="related-card-date"><?php echo sepideh_post_date($sepidehRelatedPost['created'], 'j F Y'); ?></span>
                <span class="related-card-more">خواندن <?php echo sepideh_icon('arrow-left', 14); ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- ---------- نظرات ---------- -->
    <?php $this->need('comments.php'); ?>

</article>

<?php $this->need('footer.php'); ?>
