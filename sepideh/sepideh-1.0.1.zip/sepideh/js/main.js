(function () {
    'use strict';

    /* ---------- تبدیل ارقام به فارسی (برای محتوای داینامیک) ---------- */
    function faNum(str) {
        var map = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return String(str).replace(/[0-9]/g, function (d) { return map[+d]; });
    }

    /* ---------- منوی موبایل ---------- */
    var menu = document.getElementById('mobileMenu');
    var overlay = document.getElementById('menuOverlay');
    var toggle = document.getElementById('menuToggle');
    var closeBtn = document.getElementById('menuClose');

    function openMenu() {
        if (!menu) { return; }
        menu.classList.add('open');
        if (overlay) { overlay.classList.add('show'); }
        menu.setAttribute('aria-hidden', 'false');
        if (toggle) { toggle.setAttribute('aria-expanded', 'true'); }
        document.body.style.overflow = 'hidden';
    }

    function closeMenu() {
        if (!menu) { return; }
        menu.classList.remove('open');
        if (overlay) { overlay.classList.remove('show'); }
        menu.setAttribute('aria-hidden', 'true');
        if (toggle) { toggle.setAttribute('aria-expanded', 'false'); }
        document.body.style.overflow = '';
    }

    if (toggle) { toggle.addEventListener('click', openMenu); }
    if (closeBtn) { closeBtn.addEventListener('click', closeMenu); }
    if (overlay) { overlay.addEventListener('click', closeMenu); }

    // لینک‌های داخل منو که data-close دارند → بستن منو
    document.querySelectorAll('.mobile-nav a[data-close]').forEach(function (link) {
        link.addEventListener('click', closeMenu);
    });

    // ESC → بستن منو/لایت‌باکس
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closeMenu();
            closeLightbox();
        }
    });

    /* ---------- سایهٔ هدر بعد از اسکرول + دکمهٔ بالا ---------- */
    var header = document.getElementById('siteHeader');
    var backToTop = document.getElementById('backToTop');

    function onScroll() {
        var y = window.scrollY || window.pageYOffset;
        if (header) {
            if (y > 10) { header.classList.add('scrolled'); }
            else { header.classList.remove('scrolled'); }
        }
        if (backToTop) {
            if (y > 460) { backToTop.classList.add('show'); }
            else { backToTop.classList.remove('show'); }
        }
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    if (backToTop) {
        backToTop.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    /* ---------- لایت‌باکس گالری ---------- */
    var lightbox = document.getElementById('lightbox');
    var lightboxImg = document.getElementById('lightboxImg');
    var lbClose = document.getElementById('lightboxClose');
    var lbPrev = document.getElementById('lightboxPrev');
    var lbNext = document.getElementById('lightboxNext');
    var galleryItems = Array.prototype.slice.call(document.querySelectorAll('.gallery-item[data-src]'));
    var lbIndex = -1;

    function showLightbox(index) {
        if (!lightbox || galleryItems.length === 0) { return; }
        lbIndex = (index + galleryItems.length) % galleryItems.length;
        var src = galleryItems[lbIndex].getAttribute('data-src');
        lightboxImg.src = src;
        lightbox.classList.add('show');
        lightbox.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
    }

    function closeLightbox() {
        if (!lightbox || !lightbox.classList.contains('show')) { return; }
        lightbox.classList.remove('show');
        lightbox.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
        setTimeout(function () { lightboxImg.src = ''; }, 250);
    }

    galleryItems.forEach(function (item, i) {
        item.addEventListener('click', function () { showLightbox(i); });
    });
    if (lbClose) { lbClose.addEventListener('click', closeLightbox); }
    if (lbPrev) { lbPrev.addEventListener('click', function (e) { e.stopPropagation(); showLightbox(lbIndex - 1); }); }
    if (lbNext) { lbNext.addEventListener('click', function (e) { e.stopPropagation(); showLightbox(lbIndex + 1); }); }
    if (lightbox) { lightbox.addEventListener('click', function (e) { if (e.target === lightbox) { closeLightbox(); } }); }

    /* ---------- دکمهٔ کپی کد (پیش‌نمایش کد در نوشته‌ها) ---------- */
    document.querySelectorAll('.post-content pre').forEach(function (pre) {
        // اگر خودش دکمه نداشت، بساز
        var btn = pre.querySelector('.copy-code-btn');
        if (!btn) {
            btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'copy-code-btn';
            btn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg> کپی';
            pre.appendChild(btn);
        }
        btn.addEventListener('click', function () {
            var text = pre.querySelector('code') ? pre.querySelector('code').innerText : pre.innerText;
            var done = function () {
                btn.classList.add('copied');
                var old = btn.innerHTML;
                btn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 7 17l-5-5"/><path d="m22 10-7.5 7.5L13 16"/></svg> کپی شد';
                setTimeout(function () { btn.classList.remove('copied'); btn.innerHTML = old; }, 1600);
            };
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(done).catch(function () {});
            } else {
                var ta = document.createElement('textarea');
                ta.value = text;
                document.body.appendChild(ta);
                ta.select();
                try { document.execCommand('copy'); done(); } catch (e) { }
                document.body.removeChild(ta);
            }
        });
    });

    /* ---------- اسکرول نرم برای لینک‌های # با فاصلهٔ هدر چسبان ---------- */
    document.querySelectorAll('a[href^="#"]').forEach(function (link) {
        link.addEventListener('click', function (e) {
            var id = link.getAttribute('href');
            if (!id || id === '#' || id.length < 2) { return; }
            var target = document.querySelector(id);
            if (!target) { return; }
            e.preventDefault();
            closeMenu();
            var headerH = header ? header.offsetHeight : 0;
            var top = target.getBoundingClientRect().top + window.pageYOffset - headerH - 14;
            window.scrollTo({ top: top, behavior: 'smooth' });
        });
    });

    /* ---------- ورود با #hash از صفحهٔ دیگر (مثلاً نوشته → خانه#services) ----------
       مرورگر مستقیم روی بخش می‌پرد؛ ارتفاع هدر چسبان را اصلاح می‌کنیم تا عنوان زیر هدر نماند */
    if (window.location.hash && window.location.hash.length > 1) {
        try {
            var hashTarget = document.querySelector(window.location.hash);
            if (hashTarget) {
                setTimeout(function () {
                    var headerH = header ? header.offsetHeight : 0;
                    var top = hashTarget.getBoundingClientRect().top + window.pageYOffset - headerH - 14;
                    window.scrollTo({ top: top, behavior: 'smooth' });
                }, 80);
            }
        } catch (e) { /* هش نامعتبر — بی‌خیال */ }
    }

    /* ---------- باز شدن تصاویر نوشته در لایت‌باکس ---------- */
    document.querySelectorAll('.post-content img').forEach(function (img) {
        if (img.closest('.gallery-item')) { return; }
        img.style.cursor = 'zoom-in';
        img.addEventListener('click', function () {
            if (!lightbox || !lightboxImg) { return; }
            lightboxImg.src = img.currentSrc || img.src;
            lightbox.classList.add('show');
            lightbox.setAttribute('aria-hidden', 'false');
            document.body.style.overflow = 'hidden';
            lbIndex = -1; // حالت تک‌تصویر
        });
    });
})();
