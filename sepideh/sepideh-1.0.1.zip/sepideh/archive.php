<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');
?>

<div class="container archive-wrap">
    <header class="archive-head">
        <span class="section-tag"><?php echo sepideh_icon('file-text', 14); ?> وبلاگ</span>
        <h1 class="archive-title">
            <?php $this->archiveTitle([
                'category' => _t('دستهٔ %s'),
                'search'   => _t('نتایج جستجوی %s'),
                'tag'      => _t('برچسب %s'),
                'author'   => _t('نوشته‌های %s'),
                'date'     => _t('آرشیو %s'),
            ], '', ''); ?>
        </h1>
    </header>

    <?php if ($this->have()): ?>
    <div class="archive-grid">
        <?php while ($this->next()): ?>
        <article class="blog-card">
            <a href="<?php $this->permalink(); ?>" class="blog-card-link">
                <div class="blog-card-thumb">
                    <img src="<?php echo htmlspecialchars(sepideh_thumbnail($this), ENT_QUOTES); ?>" alt="<?php echo sepideh_fa_title($this); ?>" loading="lazy">
                </div>
                <div class="blog-card-body">
                    <div class="blog-card-meta">
                        <span><?php echo sepideh_icon('calendar', 13); ?> <?php echo sepideh_post_date($this, 'j F Y'); ?></span>
                        <?php if (sepideh_opt('sepidehShowViews', '1') === '1'): ?>
                        <span><?php echo sepideh_icon('eye', 13); ?> <?php echo sepideh_num(sepideh_views($this)); ?></span>
                        <?php endif; ?>
                    </div>
                    <h2 class="blog-card-title"><?php echo sepideh_fa_title($this); ?></h2>
                    <p class="blog-card-excerpt"><?php echo toPersianNumbers(mb_substr(trim(strip_tags((string)$this->excerpt)), 0, 100, 'UTF-8') . '...'); ?></p>
                    <span class="blog-card-more">ادامه مطلب <?php echo sepideh_icon('arrow-left', 14); ?></span>
                </div>
            </a>
        </article>
        <?php endwhile; ?>
    </div>

    <?php
    // ---------- صفحه‌بندی (هلپر پوسته — ترتیب آرگومان‌های صحیح pageNav) ----------
    sepideh_page_nav($this);
    ?>
    <?php else: ?>
    <div class="archive-empty">
        <?php echo sepideh_icon('search', 44); ?>
        <p>چیزی برای نمایش پیدا نشد.</p>
        <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-ghost">بازگشت به خانه</a>
    </div>
    <?php endif; ?>
</div>

<?php $this->need('footer.php'); ?>
