<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="container">
    <div class="error-page">
        <div class="error-glare" aria-hidden="true">
            <?php echo negarinIcon('camera', 88); ?>
            <span class="error-code"><?php echo negarinToPersianDigits('404'); ?></span>
        </div>
        <h1 class="error-title"><?php _e('این قاب هرگز ثبت نشد'); ?></h1>
        <p class="error-text">
            <?php _e('صفحه‌ای که دنبالش بودید این‌جا نیست؛ شاید نشانی اشتباه است یا نوشته جابه‌جا شده. از صفحهٔ اصلی ادامه بدهید.'); ?>
        </p>
        <div class="error-actions">
            <a class="btn btn-gradient" href="<?php $this->options->siteUrl(); ?>">
                <?php echo negarinIcon('home', 17); ?>
                <span><?php _e('بازگشت به خانه'); ?></span>
            </a>
            <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="error-search">
                <?php echo negarinIcon('search', 16); ?>
                <input type="search" name="s" class="search-input" placeholder="<?php _e('دنبال چه چیزی بودید؟'); ?>" aria-label="<?php _e('جستجو'); ?>" />
            </form>
        </div>
    </div>
</div>

<?php $this->need('footer.php'); ?>
