<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="container">
    <div class="layout">
        <div class="layout-primary layout-single">

            <?php renderSingle($this, 'page'); ?>

            <?php $this->need('comments.php'); ?>

        </div>
    </div>
</div>

<?php $this->need('footer.php'); ?>
