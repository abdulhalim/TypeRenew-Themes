<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<div class="container">
    <div class="layout">
        <div class="layout-primary layout-single">

            <a class="back-link" href="<?php $this->options->siteUrl(); ?>">
                <?php echo negarinIcon('arrow-right', 16); ?>
                <span><?php _e('بازگشت به خانه'); ?></span>
            </a>

            <?php renderSingle($this, 'post'); ?>

            <nav class="post-near" aria-label="<?php _e('ناوبری نوشته‌ها'); ?>">
                <?php $this->thePrev(
                    '<div class="post-near-item"><span class="post-near-label">' . _t('نوشتهٔ قدیمی‌تر') . '</span><span class="post-near-link">%s</span></div>',
                    '<div class="post-near-item post-near-empty"></div>',
                    ['tagClass' => 'post-near-anchor']
                ); ?>
                <?php $this->theNext(
                    '<div class="post-near-item post-near-next"><span class="post-near-label">' . _t('نوشتهٔ تازه‌تر') . '</span><span class="post-near-link">%s</span></div>',
                    '<div class="post-near-item post-near-empty"></div>',
                    ['tagClass' => 'post-near-anchor']
                ); ?>
            </nav>

            <?php $this->need('comments.php'); ?>

        </div>
    </div>
</div>

<?php $this->need('footer.php'); ?>
