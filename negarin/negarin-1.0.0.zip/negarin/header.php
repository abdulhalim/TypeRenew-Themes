<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php if ($this->is('archive', '404')): ?><?php _e('صفحه پیدا نشد'); ?> — <?php $this->options->title(); ?><?php else: ?><?php $this->archiveTitle([
            'category' => _t('نوشته‌های دسته «%s»'),
            'search'   => _t('نتایج جستجو برای «%s»'),
            'tag'      => _t('نوشته‌های برچسب «%s»'),
            'author'   => _t('نوشته‌های %s')
        ], '', ' — '); ?><?php $this->options->title(); ?><?php endif; ?></title>

    <?php
        $defaultSchema = (string) ($this->options->colorSchema ?? 'dark');
        if (!in_array($defaultSchema, ['auto', 'light', 'dark'], true)) {
            $defaultSchema = 'dark';
        }
        $defaultSchemaJson = \Typecho\Common::jsonEncode(
            $defaultSchema,
            JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP,
            '"dark"'
        );
        $accentPreset = (string) ($this->options->accentPreset ?? 'sunset');
        if (!in_array($accentPreset, ['sunset', 'violet', 'ocean'], true)) {
            $accentPreset = 'sunset';
        }
        echo "<script>
            (function() {
                var stored = null;
                try {
                    stored = localStorage.getItem('negarin-theme');
                } catch (e) {
                    stored = null;
                }
                var def = {$defaultSchemaJson};
                var isDark = true;
                if (stored === 'dark' || stored === 'light') {
                    isDark = (stored === 'dark');
                } else if (def === 'light') {
                    isDark = false;
                } else if (def === 'auto' && window.matchMedia && !window.matchMedia('(prefers-color-scheme: dark)').matches) {
                    isDark = false;
                }
                document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
            })();
        </script>";
    ?>

    <link rel="stylesheet" href="<?php $this->options->themeUrl('style.css'); ?>">
    <?php $this->header(); ?>
</head>
<body class="ng-<?php echo htmlspecialchars($accentPreset, ENT_QUOTES, 'UTF-8'); ?>">
<a class="skip-link" href="#content"><?php _e('رفتن به محتوا'); ?></a>

<header class="topbar">
    <div class="topbar-inner">
        <a class="brand" href="<?php $this->options->siteUrl(); ?>">
            <span class="brand-mark" aria-hidden="true"><?php echo negarinIcon('camera', 20); ?></span>
            <span class="brand-name"><?php $this->options->title(); ?></span>
        </a>

        <nav class="topbar-nav" aria-label="<?php _e('ناوبری اصلی'); ?>">
            <a <?php if ($this->is('index')): ?> class="active"<?php endif; ?> href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a>
            <?php \Widget\Contents\Page\Rows::alloc()->to($pages); ?>
            <?php while ($pages->next()): ?>
                <a <?php if ($this->is('page', $pages->slug)): ?> class="active"<?php endif; ?> href="<?php $pages->permalink(); ?>"><?php $pages->title(); ?></a>
            <?php endwhile; ?>
        </nav>

        <div class="topbar-actions">
            <form id="search" method="post" action="<?php $this->options->siteUrl(); ?>" role="search" class="search-form">
                <?php echo negarinIcon('search', 16); ?>
                <?php $searchQuery = htmlspecialchars((string) ($this->request->keywords ?? $this->request->s ?? ''), ENT_QUOTES, 'UTF-8'); ?>
                <input type="search" id="s" name="s" class="search-input" placeholder="<?php _e('جستجو…'); ?>" aria-label="<?php _e('جستجو'); ?>" value="<?php echo $searchQuery; ?>" required />
            </form>
            <button type="button" id="theme-switch" class="topbar-icon theme-switch" aria-label="<?php _e('تغییر حالت روشن و تیره'); ?>" title="<?php _e('تغییر حالت روشن و تیره'); ?>">
                <span class="theme-icon" aria-hidden="true"></span>
            </button>
        </div>
    </div>
</header>

<?php
    $negarinScopeAll = ((string) ($this->options->profileScope ?? 'index')) === 'all';
    if (($negarinScopeAll || $this->is('index')) && ($this->options->showProfile ?? '1') === '1'):
?>
    <?php
        $profileBio = trim((string) ($this->options->profileBio ?? ''));
        if ($profileBio === '') {
            $profileBio = (string) $this->options->description;
        }
        $contactUrl = trim((string) ($this->options->contactUrl ?? ''));
        $profileAvatar = trim((string) ($this->options->profileAvatar ?? ''));

        $statsSelected = negarinProfileStatsSelection($this->options);
        $stats = !empty($statsSelected) ? negarinStats() : null;

        $statItems = [];
        if (is_array($stats)) {
            if (in_array('posts', $statsSelected, true)) {
                $statItems[] = [negarinFormatCount($stats['posts']), _t('نوشته')];
            }
            if (in_array('comments', $statsSelected, true)) {
                $statItems[] = [negarinFormatCount($stats['comments']), _t('دیدگاه')];
            }
            if (in_array('views', $statsSelected, true)) {
                $statItems[] = [negarinFormatCount($stats['views']), _t('بازدید')];
            }
            if (empty($statItems)) {
                $stats = null;
            }
        }
    ?>
    <section class="profile">
        <div class="profile-glow" aria-hidden="true"></div>
        <div class="container profile-inner">
            <div class="profile-avatar-ring">
                <?php echo negarinAvatarHtml((string) $this->options->title, $profileAvatar, 104, 'profile-avatar'); ?>
            </div>
            <div class="profile-main">
                <h1 class="profile-name"><?php $this->options->title(); ?></h1>
                <?php if ($profileBio !== ''): ?>
                    <p class="profile-bio"><?php echo htmlspecialchars($profileBio, ENT_QUOTES, 'UTF-8'); ?></p>
                <?php endif; ?>
                <?php if ($contactUrl !== '' && preg_match('#^(https?://|mailto:|/)#i', $contactUrl)): ?>
                    <div class="profile-actions">
                        <a class="btn btn-ghost" href="<?php echo htmlspecialchars($contactUrl, ENT_QUOTES, 'UTF-8'); ?>">
                            <?php echo negarinIcon('mail', 17); ?>
                            <span><?php _e('تماس'); ?></span>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
            <?php if (is_array($stats) && !empty($statItems)): ?>
                <div class="profile-stats">
                    <?php foreach ($statItems as $i => [$statValue, $statLabel]): ?>
                        <?php if ($i > 0): ?><span class="profile-stat-sep" aria-hidden="true"></span><?php endif; ?>
                        <div class="profile-stat">
                            <strong><?php echo $statValue; ?></strong>
                            <span><?php echo $statLabel; ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php endif; ?>

<?php
    $isFirstPageIndex = false;
    if ($this->is('index')) {
        $isFirstPageIndex = intval($this->request->get('page', 1)) < 2;
    }
    if (($isFirstPageIndex || $negarinScopeAll) && ($this->options->showStories ?? '1') === '1'):
        $storiesCount = max(4, intval($this->options->storiesCount ?? '8'));
        NegarinPopularPosts::alloc('pageSize=' . $storiesCount)->to($stories);
        if ($stories->have()):
?>
    <section class="stories" aria-label="<?php _e('محبوب‌ترین نوشته‌ها'); ?>">
        <div class="container stories-inner">
            <div class="stories-scroll" id="stories-scroll">
                <?php while ($stories->next()): ?>
                    <?php
                        $storyImage = negarinPostImage($stories);
                        $storyTitle = (string) $stories->title;
                    ?>
                    <a class="story" href="<?php $stories->permalink(); ?>" title="<?php echo htmlspecialchars($storyTitle . ' — ' . _t('محبوب'), ENT_QUOTES, 'UTF-8'); ?>">
                        <span class="story-ring">
                            <span class="story-thumb">
                                <?php if ($storyImage !== ''): ?>
                                    <img src="<?php echo htmlspecialchars($storyImage, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($storyTitle, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy" />
                                <?php else: ?>
                                    <?php echo negarinAvatarHtml($storyTitle, null, 56); ?>
                                <?php endif; ?>
                            </span>
                            <span class="story-badge" aria-hidden="true"><?php echo negarinIcon('flame', 11); ?></span>
                        </span>
                        <span class="story-title"><?php $stories->title(); ?></span>
                    </a>
                <?php endwhile; ?>
            </div>
            <button type="button" class="stories-nav stories-prev" aria-label="<?php _e('قبلی'); ?>"><?php echo negarinIcon('arrow-right', 18); ?></button>
            <button type="button" class="stories-nav stories-next" aria-label="<?php _e('بعدی'); ?>"><?php echo negarinIcon('arrow-left', 18); ?></button>
        </div>
    </section>
<?php endif; endif; ?>

<main id="content" class="site-main">
