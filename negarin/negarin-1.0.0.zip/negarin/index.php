<?php
/**
 * نگارین — پوسته‌ای اجتماعی برای عکاسان و دوست‌داران شبکه‌های اجتماعی
 *
 * @package نگارین
 * @author پوردریایی
 * @version 1.0.0
 * @link https://pourdaryaei.ir
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');

$isIndex = $this->is('index');
?>

<div class="container">
    <div class="layout">
        <div class="layout-primary">

            <?php if (!$isIndex): ?>
                <div class="archive-header">
                    <span class="archive-chip" aria-hidden="true">
                        <?php
                            if ($this->is('category')) {
                                echo negarinIcon('folder', 20);
                            } elseif ($this->is('search')) {
                                echo negarinIcon('search', 20);
                            } elseif ($this->is('tag')) {
                                echo negarinIcon('tag', 20);
                            } else {
                                echo negarinIcon('user', 20);
                            }
                        ?>
                    </span>
                    <?php $this->archiveTitle([
                        'category' => _t('%s'),
                        'search'   => _t('%s'),
                        'tag'      => _t('%s'),
                        'author'   => _t('%s')
                    ], '<h2 class="archive-title">', '</h2>'); ?>
                    <?php if ($this->is('search') || $this->is('category') || $this->is('tag')): ?>
                        <p class="archive-subtitle"><?php _e('همهٔ نوشته‌های این بخش، از تازه‌ترین آغاز می‌شوند'); ?></p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if ($this->have()): ?>
                <div class="posts-grid">
                    <?php while ($this->next()): ?>
                        <?php negarinTileHtml($this, 'grid'); ?>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-state-icon" aria-hidden="true">
                        <?php echo negarinIcon('camera', 52); ?>
                    </div>
                    <h2 class="empty-state-title"><?php _e('این‌جا هنوز قابی خالی است'); ?></h2>
                    <p class="empty-state-text">
                        <?php $this->archiveTitle([
                            'category' => _t('هنوز در دسته «%s» نوشته‌ای منتشر نشده است.'),
                            'search'   => _t('برای «%s» نتیجه‌ای پیدا نشد؛ عبارت دیگری را بیازمایید.'),
                            'tag'      => _t('هنوز نوشته‌ای با برچسب «%s» منتشر نشده است.'),
                            'author'   => _t('هنوز %s نوشته‌ای منتشر نکرده است.')
                        ], '', ''); ?>
                    </p>
                    <a class="btn btn-gradient" href="<?php $this->options->siteUrl(); ?>">
                        <span><?php _e('بازگشت به خانه'); ?></span>
                    </a>
                </div>
            <?php endif; ?>

            <nav class="pagination-area" aria-label="<?php _e('صفحه‌بندی'); ?>">
                <?php
                    ob_start();
                    $this->pageNav(
                        '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18l6-6-6-6"></path></svg>',
                        '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"></path></svg>',
                        3,
                        '…'
                    );
                    echo negarinConvertNavDigits((string) ob_get_clean());
                ?>
            </nav>
        </div>
    </div>
</div>

<?php
    $showExploreOnPage = false;
    if ($isIndex && intval($this->request->get('page', 1)) < 2 && ($this->options->showExplore ?? '1') === '1') {
        $showExploreOnPage = true;
    }

    if ($showExploreOnPage):
        $exploreCount = max(6, intval($this->options->exploreCount ?? '9'));
        $exploreColumns = max(2, intval($this->options->exploreColumns ?? '4'));
        NegarinRandomPosts::alloc('limit=' . $exploreCount)->to($explore);
        if ($explore->have()):
?>
<section class="explore" aria-label="<?php _e('گالری کاوش'); ?>">
    <div class="container">
        <div class="explore-head">
            <div class="explore-title-wrap">
                <span class="explore-icon" aria-hidden="true"><?php echo negarinIcon('shuffle', 20); ?></span>
                <div>
                    <h2 class="explore-title"><?php _e('کاوش'); ?></h2>
                    <p class="explore-sub"><?php _e('هر بار که برگردید، قاب‌های تازه‌ای برای کشف هست'); ?></p>
                </div>
            </div>
        </div>
        <div class="explore-grid" style="--explore-cols: <?php echo $exploreColumns; ?>">
            <?php while ($explore->next()): ?>
                <?php negarinTileHtml($explore, 'explore'); ?>
            <?php endwhile; ?>
        </div>
    </div>
</section>
<?php endif; endif; ?>

<?php $this->need('footer.php'); ?>
