<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * تبدیل ارقام لاتین به فارسی
 */
function negarinToPersianDigits(?string $text): string
{
    return str_replace(
        ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
        ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'],
        (string) $text
    );
}

/**
 * قالب‌بندی خلاصهٔ اعداد به سبک شبکه‌های اجتماعی با ارقام فارسی:
 * ۹۹۹ → ۹۹۹ / ۱۰۰۰ → ۱ هزار / ۱۵۰۰ → ۱٫۵ هزار / ۱۰۰۰۰ → ۱۰ هزار / ۱۲۰۰۰۰۰ → ۱٫۲ میلیون
 */
function negarinFormatCount(int $num): string
{
    if ($num >= 1000000) {
        return negarinCompactNumber(round($num / 1000000, 1)) . ' ' . _t('میلیون');
    }

    if ($num >= 1000) {
        $thousands = round($num / 1000, 1);

        // گردشدن به ۱۰۰۰ هزار (مثل ۹۹۹۹۹۹) باید «۱ میلیون» نمایش دهد
        if ($thousands >= 1000) {
            return negarinCompactNumber(round($thousands / 1000, 1)) . ' ' . _t('میلیون');
        }

        return negarinCompactNumber($thousands) . ' ' . _t('هزار');
    }

    return negarinToPersianDigits($num);
}

/**
 * عدد اعشاری خلاصه با ارقام فارسی؛ رقم اعشار تنها در صورت نیاز (۱٫۵ و نه ۱٫۰)
 */
function negarinCompactNumber(float $value): string
{
    $text = number_format($value, 1, '.', '');

    if (substr($text, -2) === '.0') {
        $text = substr($text, 0, -2);
    }

    return negarinToPersianDigits(str_replace('.', '٫', $text));
}

/**
 * متن فارسی تعداد دیدگاه با ارقام فارسی
 */
function negarinCommentsCountText(int $num): string
{
    if ($num <= 0) {
        return _t('بدون دیدگاه');
    }

    if ($num === 1) {
        return _t('۱ دیدگاه');
    }

    return negarinToPersianDigits($num) . ' ' . _t('دیدگاه');
}

/**
 * تبدیل ارقام لاتین متن خروجی صفحه‌بندی به فارسی؛
 * فقط متنِ میان تگ‌ها تبدیل می‌شود تا نشانی لینک‌ها دست‌نخورده بماند.
 */
function negarinConvertNavDigits(string $html): string
{
    return (string) preg_replace_callback(
        '/>([^<>]+)</u',
        function (array $matches): string {
            return '>' . negarinToPersianDigits($matches[1]) . '<';
        },
        $html
    );
}

/**
 * تعداد بازدید نوشته از ستون views جدول محتوا
 */
function negarinGetViews($archive): int
{
    try {
        return max(0, (int) $archive->views);
    } catch (\Throwable $e) {
        return 0;
    }
}

/**
 * اطمینان از وجود ستون views در جدول محتوا — شمارندهٔ بازدید داخلی
 * (الگوی پلاگین ViewsCounter) بدون نیاز به نصب پلاگین مجزا.
 */
function negarinViewsSchemaReady(): bool
{
    static $ready = null;

    if ($ready !== null) {
        return $ready;
    }

    $ready = false;

    try {
        $db = \Typecho\Db::get();

        try {
            $db->fetchRow($db->select('table.contents.views')->from('table.contents')->limit(1));
            $columnExists = true;
        } catch (\Throwable $e) {
            $columnExists = false;
        }

        if (!$columnExists) {
            $prefix = $db->getPrefix();
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT DEFAULT 0');

            // انتقال آمار بازدید احتیاطی از فیلدهای قدیمی (در صورت وجود)
            try {
                $db->query(
                    'UPDATE `' . $prefix . 'contents` SET views = COALESCE((SELECT SUM(f.int_value)'
                    . ' FROM `' . $prefix . 'fields` f WHERE f.cid = `' . $prefix
                    . 'contents`.cid AND f.name = \'views\' AND f.type = \'int\'), 0)'
                );
                $db->query('DELETE FROM `' . $prefix . 'fields` WHERE name = \'views\' AND type = \'int\'');
            } catch (\Throwable $e) {
                // انتقال آمار اختیاری است و نباید نمایش صفحه را متوقف کند
            }
        }

        $ready = true;
    } catch (\Throwable $e) {
        // نبود دسترسی کافی به دیتابیس نباید سایت را از کار بیندازد
        $ready = false;
    }

    return $ready;
}

/**
 * شمارش بازدید صفحات تکی — یکپارچه با پلاگین ViewsCounter؛
 * اگر پلاگین فعال باشد پوسته کنار می‌کشد تا شمارش مضاعف انجام نشود.
 * آمار در ستون views جدول محتوا ذخیره می‌شود که مستقل از پوسته است و
 * با غیرفعال‌کردن یا تعویض پوسته هرگز حذف نمی‌شود.
 */
function negarinCountView($archive): void
{
    $activatedPlugins = \Widget\Options::alloc()->plugins;
    if (is_array($activatedPlugins) && isset($activatedPlugins['activated']['ViewsCounter'])) {
        return;
    }

    // بازدید کاربران واردشده (مدیر و اعضا) طبق تنظیم پوسته شمرده می‌شود یا نه
    $countLoggedIn = ((string) (\Widget\Options::alloc()->countLoggedInViews ?? '0')) === '1';
    if (\Widget\User::alloc()->hasLogin() && !$countLoggedIn) {
        return;
    }

    if (!$archive instanceof \Widget\Archive || !$archive->is('single')) {
        return;
    }

    $cid = intval($archive->cid);

    if ($cid < 1) {
        return;
    }

    // فاصله زمانی جلوگیری از شمارش بازدیدهای مکرر
    $interval = (int) (\Widget\Options::alloc()->viewsInterval ?? 3600);

    if ($interval > 0) {
        $viewed = (string) \Typecho\Cookie::get('negarinViews', '');
        $viewedIds = $viewed === '' ? [] : explode(',', $viewed);

        if (in_array((string) $cid, $viewedIds, true)) {
            return;
        }

        $viewedIds[] = (string) $cid;

        // جلوگیری از بزرگ‌شدن بی‌رویه کوکی
        if (count($viewedIds) > 100) {
            $viewedIds = array_slice($viewedIds, -100);
        }

        \Typecho\Cookie::set('negarinViews', implode(',', $viewedIds), time() + $interval);
    }

    if (!negarinViewsSchemaReady()) {
        return;
    }

    try {
        $db = \Typecho\Db::get();
        $db->query(
            $db->update('table.contents')
                ->expression('views', 'views + 1')
                ->where('cid = ?', $cid)
        );
    } catch (\Throwable $e) {
        // خطا در شمارش بازدید نباید نمایش صفحه را متوقف کند
    }
}

/**
 * راه‌انداز پوسته — ثبت قلاب شمارنده بازدید یکپارچه + نقطهٔ پایانی AJAX پسند
 */
function themeInit(\Widget\Archive $archive)
{
    \Typecho\Plugin::factory('Widget\Archive')->beforeRender = 'negarinCountView';

    // نقطهٔ پایانی پسند: POST با پارامتر negarinLike=<cid> به هر نشانی سایت
    if ($archive->request->isPost() && $archive->request->is('negarinLike')) {
        negarinHandleLikeRequest($archive->request);
    }
}

/**
 * اطمینان از وجود ستون likes در جدول محتوا — پسندهای واقعی،
 * همانند بازدیدها در دیتابیس ذخیره می‌شوند و با تعویض پوسته حذف نمی‌شوند.
 */
function negarinLikesSchemaReady(): bool
{
    static $likesReady = null;

    if ($likesReady !== null) {
        return $likesReady;
    }

    $likesReady = false;

    try {
        $db = \Typecho\Db::get();

        try {
            $db->fetchRow($db->select('table.contents.likes')->from('table.contents')->limit(1));
            $columnExists = true;
        } catch (\Throwable $e) {
            $columnExists = false;
        }

        if (!$columnExists) {
            $prefix = $db->getPrefix();
            $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `likes` INT DEFAULT 0');
        }

        $likesReady = true;
    } catch (\Throwable $e) {
        $likesReady = false;
    }

    return $likesReady;
}

/**
 * تعداد پسند نوشته از ستون likes جدول محتوا
 */
function negarinGetLikes($archive): int
{
    if (!negarinLikesSchemaReady()) {
        return 0;
    }

    try {
        return max(0, (int) $archive->likes);
    } catch (\Throwable $e) {
        return 0;
    }
}

/**
 * فهرست شناسه‌های پسندیده‌شده توسط این بازدیدکننده (کوکی negarinLikes)
 */
function negarinUserLikes(): array
{
    $raw = (string) \Typecho\Cookie::get('negarinLikes', '');

    if ($raw === '') {
        return [];
    }

    $ids = [];
    foreach (explode(',', $raw) as $id) {
        $id = trim($id);
        if ($id !== '' && ctype_digit($id) && !in_array($id, $ids, true)) {
            $ids[] = $id;
        }
    }

    return $ids;
}

/**
 * آیا این بازدیدکننده این نوشته را پسندیده است؟
 */
function negarinIsLikedByUser(int $cid): bool
{
    return $cid > 0 && in_array((string) $cid, negarinUserLikes(), true);
}

/**
 * خروجی JSON و پایان درخواست
 */
function negarinSendJson(array $payload, int $status = 200): void
{
    $response = \Typecho\Response::getInstance();
    $response->setStatus($status);
    $response->setContentType('application/json');
    $response->addResponder(function () use ($payload): void {
        echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    });
    $response->respond();
}

/**
 * پردازش درخواست پسند — فعال/غیرفعال‌کردن پسند نوشته برای این بازدیدکننده.
 * پاسخ: {"ok":true,"likes":N,"liked":bool}
 */
function negarinHandleLikeRequest($request): void
{
    $cid = intval((string) $request->get('negarinLike'));

    if ($cid < 1) {
        negarinSendJson(['ok' => false, 'error' => 'bad-request'], 400);
        return;
    }

    // جلوگیری ساده از درخواست متقاطع (CSRF)
    $siteHost = (string) parse_url((string) \Widget\Options::alloc()->siteUrl, PHP_URL_HOST);
    $referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');
    if ($referer !== '' && $siteHost !== '' && stripos($referer, $siteHost) === false) {
        negarinSendJson(['ok' => false, 'error' => 'cross-origin'], 403);
        return;
    }

    if (!negarinLikesSchemaReady()) {
        negarinSendJson(['ok' => false, 'error' => 'db-error'], 500);
        return;
    }

    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.type', 'table.contents.status', 'table.contents.password', 'table.contents.created')
                ->from('table.contents')
                ->where('table.contents.cid = ?', $cid)
        );

        $valid = is_array($row)
            && $row['status'] === 'publish'
            && in_array($row['type'], ['post', 'page'], true)
            && empty($row['password'])
            && (int) $row['created'] <= \Widget\Options::alloc()->time;

        if (!$valid) {
            negarinSendJson(['ok' => false, 'error' => 'not-found'], 404);
            return;
        }

        $likedIds = negarinUserLikes();
        $wasLiked = in_array((string) $cid, $likedIds, true);

        if ($wasLiked) {
            $likedIds = array_values(array_filter(
                $likedIds,
                function (string $id) use ($cid): bool {
                    return $id !== (string) $cid;
                }
            ));
            $delta = -1;
        } else {
            $likedIds[] = (string) $cid;
            $delta = 1;
        }

        // جلوگیری از بزرگ‌شدن بی‌رویهٔ کوکی (یک سال اعتبار)
        if (count($likedIds) > 200) {
            $likedIds = array_slice($likedIds, -200);
        }
        \Typecho\Cookie::set('negarinLikes', implode(',', $likedIds), time() + 31536000);

        $current = (int) $db->fetchObject(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        )->likes;

        if ($delta > 0 || $current > 0) {
            $db->query(
                $db->update('table.contents')
                    ->expression('likes', $delta > 0 ? 'likes + 1' : 'likes - 1')
                    ->where('table.contents.cid = ?', $cid)
            );
        }

        $newLikes = (int) $db->fetchObject(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        )->likes;

        negarinSendJson([
            'ok'    => true,
            'likes' => $newLikes,
            'liked' => !$wasLiked,
        ]);
    } catch (\Throwable $e) {
        negarinSendJson(['ok' => false, 'error' => 'server-error'], 500);
    }
}

/**
 * آمار کلی سایت — نوشته، دیدگاه و مجموع بازدیدها (برای پروفایل و پانوشت).
 */
function negarinStats(): array
{
    $posts = 0;
    $comments = 0;
    $views = 0;

    try {
        $db = \Typecho\Db::get();
        $posts = (int) $db->fetchObject(
            $db->select(['COUNT(table.contents.cid)' => 'num'])
                ->from('table.contents')
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.status = ?', 'publish')
        )->num;
        $comments = (int) $db->fetchObject(
            $db->select(['COUNT(table.comments.coid)' => 'num'])
                ->from('table.comments')
                ->where('table.comments.type = ?', 'comment')
                ->where('table.comments.status = ?', 'approved')
        )->num;

        if (negarinViewsSchemaReady()) {
            $views = (int) $db->fetchObject(
                $db->select(['COALESCE(SUM(table.contents.views), 0)' => 'total'])
                    ->from('table.contents')
                    ->where('table.contents.status = ?', 'publish')
            )->total;
        }
    } catch (\Exception $e) {
        // خطای دیتابیس نباید نمایش سایت را از کار بیندازد
    }

    return ['posts' => $posts, 'comments' => $comments, 'views' => $views];
}

/**
 * انتخاب کاربر برای آمار پروفایل (چک‌باکس)؛
 * اگر هنوز ذخیره نشده باشد هر سه آمار نمایش داده می‌شود.
 */
function negarinProfileStatsSelection($options): array
{
    $selected = $options->heroStats ?? null;

    if (!is_array($selected)) {
        return ['posts', 'comments', 'views'];
    }

    $valid = [];
    foreach (['posts', 'comments', 'views'] as $key) {
        if (in_array($key, $selected, true)) {
            $valid[] = $key;
        }
    }

    return $valid;
}

/**
 * بررسی اعتبار نشانی تصویر — مطلق (http/https)، ریشه‌ای (/...) یا data:image
 */
function negarinImageUrlOk(string $url): bool
{
    $url = trim($url);

    if ($url === '' || strlen($url) > 2048) {
        return false;
    }

    return (bool) preg_match('#^(https?://|/|data:image/)#i', $url);
}

/**
 * جدا کردن نشانی از آرگومان تصویر مارک‌داون — <url>، عنوان اختیاری و فاصله‌ها را کنار می‌گذارد
 */
function negarinMarkdownUrl(string $raw): string
{
    $raw = trim($raw);

    if ($raw === '') {
        return '';
    }

    if ($raw[0] === '<') {
        $end = strpos($raw, '>');

        return trim($end === false ? substr($raw, 1) : substr($raw, 1, $end - 1));
    }

    return rtrim(substr($raw, 0, strcspn($raw, " \t")));
}

/**
 * استخراج نخستین تصویر از متن نوشته — به ترتیبِ ظاهر شدن در متن:
 * تگ img در HTML، تصویر مارک‌داون درون‌خطی ![alt](url)،
 * تصویر ارجاعی ![alt][n] همراه با تعریف [n]: url (سبکی که ویرایشگر مارک‌داون
 * پیشخوان هنگام درج پیوست تصویر می‌سازد) و میان‌بر ![alt].
 */
function negarinImageFromText(?string $text): string
{
    $text = str_replace("\r\n", "\n", (string) $text);

    if ($text === '') {
        return '';
    }

    $candidates = [];

    // ۱) تگ img در HTML — src واقعی، نه data-src و مانند آن
    if (preg_match_all('#<img\b[^>]*?(?<![\w-])src=["\']([^"\']+)["\']#i', $text, $m, PREG_OFFSET_CAPTURE)) {
        foreach ($m[1] as $hit) {
            $candidates[] = [$hit[1], $hit[0]];
        }
    }

    // ۲) تصویر مارک‌داون درون‌خطی ![alt](url) یا ![alt](<url> "عنوان")
    if (preg_match_all('#!\[[^\]\n]*\]\(\s*([^)\n]+)#', $text, $m, PREG_OFFSET_CAPTURE)) {
        foreach ($m[1] as $hit) {
            $candidates[] = [$hit[1], negarinMarkdownUrl($hit[0])];
        }
    }

    // ۳) تصویر ارجاعی ![alt][label] و میان‌بر ![alt] — با تعریف [label]: url در ادامهٔ متن
    if (preg_match_all('#!\[([^\]\n]*)\](?:\[([^\]\n]*)\])?(?!\()#', $text, $m, PREG_OFFSET_CAPTURE)) {
        $defs = [];

        if (preg_match_all('#^[ \t]{0,3}\[([^\]\n]+)\]:[ \t]*(<?[^\s>]+>?)#m', $text, $d)) {
            foreach ($d[1] as $i => $label) {
                $defs[strtolower(trim((string) $label))] = negarinMarkdownUrl((string) $d[2][$i]);
            }
        }

        foreach ($m[0] as $i => $hit) {
            $label = trim((string) $m[2][$i][0]) !== '' ? (string) $m[2][$i][0] : (string) $m[1][$i][0];
            $label = strtolower(trim($label));

            if ($label !== '' && isset($defs[$label])) {
                $candidates[] = [$hit[1], $defs[$label]];
            }
        }
    }

    if ($candidates === []) {
        return '';
    }

    usort($candidates, static function (array $a, array $b): int {
        return $a[0] <=> $b[0];
    });

    foreach ($candidates as $candidate) {
        $url = html_entity_decode(trim((string) $candidate[1]), ENT_QUOTES, 'UTF-8');

        if (negarinImageUrlOk($url)) {
            return $url;
        }
    }

    return '';
}

/**
 * تصویر شاخص نوشته — فقط فیلد سفارشی thumb؛
 * بدون تصویر شاخص رشتهٔ خالی برمی‌گردد (هرو صفحهٔ نوشته خالی می‌ماند).
 */
function negarinThumbnail($archive): string
{
    if (isset($archive->fields) && $archive->fields instanceof \Typecho\Config) {
        $thumb = trim((string) ($archive->fields->thumb ?? ''));

        if (negarinImageUrlOk($thumb)) {
            return $thumb;
        }
    }

    return '';
}

/**
 * تصویر نوشته برای کاور کارت‌های ایندکس و استوری‌ها: فیلد سفارشی thumb و سپس
 * نخستین تصویر متن؛ بدون نتیجه رشتهٔ خالی برمی‌گردد.
 */
function negarinPostImage($archive): string
{
    $thumb = negarinThumbnail($archive);

    if ($thumb !== '') {
        return $thumb;
    }

    return negarinImageFromText((string) $archive->text);
}

/**
 * تصویر پیش‌فرض SVG با گرادیان یکتا بر پایهٔ عنوان نوشته (به‌صورت data-URI)
 */
function negarinDefaultImageSvg(string $title): string
{
    $hue = abs(crc32($title)) % 360;
    $hue2 = ($hue + 40) % 360;

    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1080" viewBox="0 0 1080 1080">'
        . '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">'
        . '<stop offset="0" stop-color="hsl(' . $hue . ' 55% 26%)"/>'
        . '<stop offset="1" stop-color="hsl(' . $hue2 . ' 60% 14%)"/>'
        . '</linearGradient></defs>'
        . '<rect width="1080" height="1080" fill="url(#g)"/>'
        . '<g fill="none" stroke="rgba(255,255,255,0.14)" stroke-width="6">'
        . '<circle cx="540" cy="540" r="168"/>'
        . '<circle cx="540" cy="540" r="228" stroke-dasharray="10 20"/>'
        . '</g>'
        . '<g transform="translate(468 468) scale(6)" fill="none" stroke="rgba(255,255,255,0.38)"'
        . ' stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
        . '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>'
        . '<circle cx="12" cy="13" r="4"/>'
        . '</g>'
        . '</svg>';

    return 'data:image/svg+xml;charset=utf-8,' . rawurlencode($svg);
}

/**
 * تصویر کاشی‌های شبکه و کاوش: تصویر شاخص ← نخستین تصویر متن ← تصویر پیش‌فرض.
 * همیشه یک تصویر برمی‌گرداند تا هیچ کاشی خالی نماند.
 */
function negarinTileImage($archive): string
{
    $image = negarinPostImage($archive);

    if ($image !== '') {
        return $image;
    }

    $custom = trim((string) (\Widget\Options::alloc()->defaultPostImage ?? ''));
    if ($custom !== '' && preg_match('#^(https?://|/|data:)#i', $custom)) {
        return $custom;
    }

    return negarinDefaultImageSvg((string) $archive->title);
}

/**
 * زمان نسبی به سبک شبکه‌های اجتماعی — «۳ روز پیش»
 */
function negarinTimeAgo(int $timestamp): string
{
    $diff = time() - $timestamp;

    if ($diff < 60) {
        return _t('همین حالا');
    }

    if ($diff < 3600) {
        return negarinToPersianDigits((int) floor($diff / 60)) . ' ' . _t('دقیقه پیش');
    }

    if ($diff < 86400) {
        return negarinToPersianDigits((int) floor($diff / 3600)) . ' ' . _t('ساعت پیش');
    }

    if ($diff < 604800) {
        return negarinToPersianDigits((int) floor($diff / 86400)) . ' ' . _t('روز پیش');
    }

    if ($diff < 2592000) {
        return negarinToPersianDigits((int) floor($diff / 604800)) . ' ' . _t('هفته پیش');
    }

    if ($diff < 31536000) {
        return negarinToPersianDigits((int) floor($diff / 2592000)) . ' ' . _t('ماه پیش');
    }

    return negarinToPersianDigits(date('Y/m/d', $timestamp));
}

/**
 * آواتار اجتماعی — تصویر دلخواه یا حرف آغازین نام روی گرادیان یکتا
 */
function negarinAvatarHtml(string $name, ?string $url = null, int $size = 44, string $extraClass = ''): string
{
    $url = trim((string) $url);

    if ($url !== '' && preg_match('#^(https?://|/)#i', $url)) {
        return '<span class="avatar' . ($extraClass !== '' ? ' ' . $extraClass : '') . '" style="--avatar-size:' . $size . 'px">'
            . '<img src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" alt="' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '" loading="lazy" />'
            . '</span>';
    }

    $initial = mb_substr(trim($name) !== '' ? $name : '?', 0, 1, 'UTF-8');
    $hue = abs(crc32($name)) % 360;

    return '<span class="avatar avatar-fallback' . ($extraClass !== '' ? ' ' . $extraClass : '') . '" style="--avatar-size:' . $size . 'px;--avatar-hue:' . $hue . '" aria-hidden="true">'
        . '<span>' . htmlspecialchars($initial, ENT_QUOTES, 'UTF-8') . '</span>'
        . '</span>';
}

/**
 * آواتار نویسندهٔ نوشته — سه مرحله:
 * ۱) تصویر پروفایل تنظیم‌شده در پوسته (profileAvatar)
 * ۲) گراواتار نویسنده بر پایهٔ رایانامه (اگر تصویری نداشته باشد، در مرورگر
 *    به حرف آغازین برمی‌گردد)
 * ۳) حرف آغازین نام روی گرادیان یکتا
 */
function negarinAuthorAvatarHtml($archive, int $size = 46): string
{
    $name = (string) $archive->author->screenName;

    // ۱) تصویر پروفایل پوسته
    $profileAvatar = trim((string) (\Widget\Options::alloc()->profileAvatar ?? ''));

    if (negarinImageUrlOk($profileAvatar)) {
        return negarinAvatarHtml($name, $profileAvatar, $size);
    }

    // ۲) گراواتار نویسنده — d=404 تا نبودِ حساب گراواتار به حرف آغازین بیفتد
    $mail = trim((string) ($archive->author->mail ?? ''));

    if (filter_var($mail, FILTER_VALIDATE_EMAIL)) {
        $rating = (string) (\Widget\Options::alloc()->commentsAvatarRating ?? 'g');
        $url = \Typecho\Common::gravatarUrl($mail, $size * 2, $rating, '404', true);
        $safeName = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
        $initial = mb_substr(trim($name) !== '' ? $name : '?', 0, 1, 'UTF-8');
        $hue = abs(crc32($name)) % 360;

        return '<span class="avatar" style="--avatar-size:' . $size . 'px"'
            . ' data-avatar-initial="' . htmlspecialchars($initial, ENT_QUOTES, 'UTF-8') . '"'
            . ' data-avatar-hue="' . $hue . '">'
            . '<img src="' . $url . '" alt="' . $safeName . '" loading="lazy" referrerpolicy="no-referrer" />'
            . '</span>';
    }

    // ۳) حرف آغازین
    return negarinAvatarHtml($name, null, $size);
}

/**
 * برچسب‌های نوشته به شکل چیپ هشتگ — آرایه‌ای از [نشانی, نام]
 */
function negarinTagChips($archive): array
{
    ob_start();
    $archive->tags(',,', true, 'none');
    $buffer = (string) ob_get_clean();

    if ($buffer === '' || !preg_match_all('#<a[^>]*href=["\']([^"\']+)["\'][^>]*>([^<]+)</a>#u', $buffer, $matches)) {
        return [];
    }

    $chips = [];
    foreach ($matches[1] as $i => $url) {
        $chips[] = [$url, $matches[2][$i]];
    }

    return $chips;
}

/**
 * تنظیمات پوسته در پیشخوان
 */
function themeConfig($form)
{
    /* ---------- ظاهر پروفایل ---------- */

    $profileAvatar = new \Typecho\Widget\Helper\Form\Element\Text(
        'profileAvatar',
        null,
        null,
        _t('آواتار پروفایل'),
        _t('نشانی تصویر پروفایل (مربعی) برای هدر صفحه اصلی؛ اگر خالی بماند، حرف آغازین عنوان سایت روی گرادیان نمایش داده می‌شود')
    );
    $form->addInput($profileAvatar);

    $profileBio = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'profileBio',
        null,
        null,
        _t('بیوگرافی پروفایل'),
        _t('متنی کوتاه دربارهٔ خودتان زیر عنوان صفحه اصلی؛ اگر خالی بماند، توضیحات سایت نمایش داده می‌شود')
    );
    $form->addInput($profileBio);

    $contactUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'contactUrl',
        null,
        null,
        _t('پیوند دکمهٔ تماس'),
        _t('نشانی صفحهٔ تماس یا ایمیل (مثل mailto:you@example.com) برای دکمهٔ «تماس» در هدر پروفایل؛ خالی باشد دکمه نمایش داده نمی‌شود')
    );
    $form->addInput($contactUrl);

    /* ---------- رنگ و حالت ---------- */

    $profileScope = new \Typecho\Widget\Helper\Form\Element\Radio(
        'profileScope',
        [
            'index' => _t('فقط صفحهٔ اصلی (پیشنهادی)'),
            'all'   => _t('تمام صفحات'),
        ],
        'index',
        _t('محل نمایش پروفایل و استوری'),
        _t('هدر پروفایل و ردیف استوری‌ها فقط در بالای صفحهٔ اصلی نمایش داده شوند یا در تمام صفحه‌ها (نوشته، برگه، دسته، برچسب، جستجو، نویسنده و ۴۰۴). کلیدهای «نمایش/مخفی» هر بخش همچنان رعایت می‌شوند')
    );
    $form->addInput($profileScope);

    $showProfile = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showProfile',
        ['1' => _t('نمایش (پیشنهادی)'), '0' => _t('مخفی')],
        '1',
        _t('هدر پروفایل'),
        _t('نمایش هدر پروفایل — آواتار، بیوگرافی، آمار و دکمه‌ها — در محل تعیین‌شده در «محل نمایش پروفایل و استوری»')
    );
    $form->addInput($showProfile);

    $colorSchema = new \Typecho\Widget\Helper\Form\Element\Select(
        'colorSchema',
        [
            'dark'  => _t('تیره (پیشنهادی — مناسب نمایش عکس)'),
            'light' => _t('روشن'),
            'auto'  => _t('خودکار (پیروی از سیستم کاربر)'),
        ],
        'dark',
        _t('حالت رنگی پیش‌فرض'),
        _t('بازدیدکننده می‌تواند از دکمهٔ ماه/خورشید حالت را عوض کند')
    );
    $form->addInput($colorSchema);

    $accentPreset = new \Typecho\Widget\Helper\Form\Element\Select(
        'accentPreset',
        [
            'sunset' => _t('غروب — صورتی به نارنجی (پیشنهادی)'),
            'violet' => _t('بنفش — بنفش به سرخابی'),
            'ocean'  => _t('اقیانوس — آبی به فیروزه‌ای'),
        ],
        'sunset',
        _t('پالت گرادیان'),
        _t('رنگ حلقهٔ استوری‌ها، دکمه‌ها و برچسب‌های پسند')
    );
    $form->addInput($accentPreset);

    /* ---------- آمار و بازدید ---------- */

    $heroStats = new \Typecho\Widget\Helper\Form\Element\Checkbox(
        'heroStats',
        [
            'posts'    => _t('تعداد نوشته‌ها'),
            'comments' => _t('تعداد دیدگاه‌ها'),
            'views'    => _t('مجموع بازدیدها'),
        ],
        ['posts', 'comments', 'views'],
        _t('آمار پروفایل'),
        _t('انتخاب کنید کدام آمار در هدر پروفایل نمایش داده شود؛ اگر هیچ‌کدام انتخاب نشود، ردیف آمار به‌طور کامل حذف می‌شود. مجموع بازدیدها مثل شبکه‌های اجتماعی خلاصه نمایش داده می‌شود (۱ هزار / ۱۰ هزار / ۱٫۲ میلیون)')
    );
    $form->addInput($heroStats);

    $countLoggedInViews = new \Typecho\Widget\Helper\Form\Element\Radio(
        'countLoggedInViews',
        ['0' => _t('شمرده نشود (پیشنهادی)'), '1' => _t('شمرده شود')],
        '0',
        _t('بازدید کاربران واردشده'),
        _t('اگر «شمرده نشود» باشد، بازدید مدیر و کاربران واردشده از صفحات تکی در آمار ثبت نمی‌شود (هم‌راستا با پلاگین ViewsCounter)')
    );
    $form->addInput($countLoggedInViews);

    $viewsInterval = new \Typecho\Widget\Helper\Form\Element\Select(
        'viewsInterval',
        [
            '3600'   => _t('۱ ساعت (پیشنهادی)'),
            '21600'  => _t('۶ ساعت'),
            '86400'  => _t('۲۴ ساعت'),
            '0'      => _t('بدون فاصله؛ هر بازدید شمرده شود'),
        ],
        '3600',
        _t('فاصله شمارش بازدید مکرر'),
        _t('بازدید تکراری یک نوشته در این بازه فقط یک بار شمرده می‌شود')
    );
    $form->addInput($viewsInterval);

    $showLikes = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showLikes',
        ['1' => _t('نمایش (پیشنهادی)'), '0' => _t('مخفی')],
        '1',
        _t('دکمهٔ پسندیدن'),
        _t('نمایش دکمهٔ قلب و شمارندهٔ پسند روی نوشته‌ها؛ پسندها در دیتابیس ذخیره می‌شوند و شمارنده در همهٔ صفحه‌ها یکسان است')
    );
    $form->addInput($showLikes);

    $defaultPostImage = new \Typecho\Widget\Helper\Form\Element\Text(
        'defaultPostImage',
        null,
        null,
        _t('تصویر پیش‌فرض نوشته‌ها'),
        _t('نشانی تصویری که برای نوشته‌های بدون تصویر شاخص و بدون عکس در متن به کار می‌رود (کاشی‌های صفحهٔ اصلی و کاوش)؛ اگر خالی بماند، قاب گرادیانی خودکار با آیکون دوربین ساخته می‌شود')
    );
    $form->addInput($defaultPostImage);

    /* ---------- بخش‌های صفحهٔ اصلی ---------- */

    $showStories = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showStories',
        ['1' => _t('نمایش (پیشنهادی)'), '0' => _t('مخفی')],
        '1',
        _t('ردیف محبوب‌ها (استوری)'),
        _t('ردیف دایره‌های رنگی محبوب‌ترین نوشته‌ها زیر هدر پروفایل — مثل استوری‌های اینستاگرام؛ در محل تعیین‌شده در «محل نمایش پروفایل و استوری»')
    );
    $form->addInput($showStories);

    $storiesCount = new \Typecho\Widget\Helper\Form\Element\Select(
        'storiesCount',
        ['4' => '۴', '6' => '۶', '8' => '۸', '10' => '۱۰'],
        '8',
        _t('تعداد استوری‌ها'),
        _t('چند نوشتهٔ محبوب در ردیف استوری نمایش داده شود')
    );
    $form->addInput($storiesCount);

    $showExplore = new \Typecho\Widget\Helper\Form\Element\Radio(
        'showExplore',
        ['1' => _t('نمایش (پیشنهادی)'), '0' => _t('مخفی')],
        '1',
        _t('گالری کاوش'),
        _t('شبکهٔ تصویری نوشته‌های تصادفی در پایین صفحهٔ اصلی — هر بار بازدید، قاب‌های تازه‌ای برای کشف')
    );
    $form->addInput($showExplore);

    $exploreCount = new \Typecho\Widget\Helper\Form\Element\Select(
        'exploreCount',
        ['6' => '۶', '9' => '۹', '12' => '۱۲'],
        '9',
        _t('تعداد کاشی‌های کاوش'),
        _t('چند تصویر از نوشته‌های تصادفی در گالری کاوش نمایش داده شود')
    );
    $form->addInput($exploreCount);

    $exploreColumns = new \Typecho\Widget\Helper\Form\Element\Select(
        'exploreColumns',
        ['3' => '۳ ستون', '4' => '۴ ستون', '5' => '۵ ستون'],
        '4',
        _t('ستون‌های گالری کاوش'),
        _t('تعداد ستون‌های شبکهٔ تصویری در نمایشگرهای بزرگ')
    );
    $form->addInput($exploreColumns);

    $popularBasis = new \Typecho\Widget\Helper\Form\Element\Select(
        'popularBasis',
        [
            'views'    => _t('بیشترین بازدید (پیشنهادی)'),
            'comments' => _t('بیشترین دیدگاه'),
        ],
        'views',
        _t('پایهٔ محبوبیت'),
        _t('استوری‌های محبوب بر پایهٔ بازدید شمرده‌شده فهرست می‌شوند؛ تا وقتی آماری ثبت نشده باشد، خودکار بر پایهٔ دیدگاه مرتب می‌شود')
    );
    $form->addInput($popularBasis);
}

/**
 * کادر سفارشی «تصویر شاخص» در پیشخوان نوشته و برگه
 */
function themeFields($layout)
{
    $thumb = new \Typecho\Widget\Helper\Form\Element\Text(
        'thumb',
        null,
        null,
        _t('تصویر شاخص'),
        _t('نشانی تصویر شاخص این نوشته؛ اگر خالی بماند، نخستین تصویر داخل متن به‌طور خودکار به کارت می‌آید و اگر آن هم نبود، تصویر پیش‌فرض (قاب گرادیانی خودکار یا تصویر تنظیم‌شده در تنظیمات پوسته) نمایش داده می‌شود')
    );
    $layout->addItem($thumb);
}

/**
 * ویجت نوشته‌های پرطرفدار — بر پایهٔ بیشترین بازدید (ستون views)،
 * با جایگزینی خودکار بر پایهٔ بیشترین دیدگاه هنگام نبود آمار بازدید
 */
if (!class_exists('NegarinPopularPosts')) {
    class NegarinPopularPosts extends \Widget\Base\Contents
    {
        public function execute()
        {
            $this->parameter->setDefault(['pageSize' => 5]);
            $limit = max(1, intval($this->parameter->pageSize));

            $basis = (string) ($this->options->popularBasis ?? 'views');
            if (!in_array($basis, ['views', 'comments'], true)) {
                $basis = 'views';
            }

            $schemaReady = negarinViewsSchemaReady();

            if ($basis === 'views' && $schemaReady) {
                try {
                    $totalViews = (int) $this->db->fetchObject(
                        $this->db->select(['COALESCE(SUM(table.contents.views), 0)' => 'total'])
                            ->from('table.contents')
                            ->where('table.contents.type = ?', 'post')
                            ->where('table.contents.status = ?', 'publish')
                    )->total;
                } catch (\Throwable $e) {
                    $totalViews = 0;
                }

                if ($totalViews < 1) {
                    $basis = 'comments';
                }
            } elseif ($basis === 'views') {
                $basis = 'comments';
            }

            $select = $this->select('table.contents.*')
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', $this->options->time)
                ->where('table.contents.type = ?', 'post')
                ->where("table.contents.password IS NULL OR table.contents.password = ''")
                ->order(
                    $basis === 'views' ? 'table.contents.views' : 'table.contents.commentsNum',
                    \Typecho\Db::SORT_DESC
                )
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit($limit);

            $this->db->fetchAll($select, [$this, 'push']);
        }
    }
}

/**
 * ویجت نوشته‌های تصادفی — برای گالری کاوش؛
 * همهٔ نوشته‌های منتشرشده شرکت می‌کنند (کاشی‌های بدون عکس تصویر پیش‌فرض می‌گیرند)
 * تا بخش کاوش همیشه پُر باشد. ترتیب با بُر زدن PHP انجام می‌شود تا مستقل از نوع دیتابیس باشد.
 */
if (!class_exists('NegarinRandomPosts')) {
    class NegarinRandomPosts extends \Widget\Base\Contents
    {
        public function execute()
        {
            $this->parameter->setDefault(['limit' => 9]);
            $limit = max(1, intval($this->parameter->limit));

            $select = $this->select('table.contents.*')
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', $this->options->time)
                ->where('table.contents.type = ?', 'post')
                ->where("table.contents.password IS NULL OR table.contents.password = ''")
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit(200);

            $rows = $this->db->fetchAll($select);

            shuffle($rows);

            foreach (array_slice($rows, 0, $limit) as $row) {
                $this->push($row);
            }
        }
    }
}

/**
 * آیکون‌های خطی سبک شبکه‌های اجتماعی
 */
function negarinIcon(string $name, int $size = 20): string
{
    $paths = [
        'heart'   => '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>',
        'comment' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>',
        'share'   => '<line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>',
        'eye'     => '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle>',
        'camera'  => '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle>',
        'search'  => '<circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line>',
        'moon'    => '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>',
        'sun'     => '<circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>',
        'home'    => '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline>',
        'arrow-up' => '<line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline>',
        'arrow-right' => '<line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline>',
        'arrow-left' => '<line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline>',
        'tag'     => '<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line>',
        'clock'   => '<circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline>',
        'feed'    => '<path d="M4 11a9 9 0 0 1 9 9"></path><path d="M4 4a16 16 0 0 1 16 16"></path><circle cx="5" cy="19" r="1"></circle>',
        'mail'    => '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline>',
        'trend'   => '<polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline>',
        'user'    => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle>',
        'folder'  => '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>',
        'link'    => '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>',
        'message' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>',
        'flame'   => '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"></path>',
        'shuffle' => '<polyline points="16 3 21 3 21 8"></polyline><line x1="4" y1="20" x2="21" y2="3"></line><polyline points="21 16 21 21 16 21"></polyline><line x1="15" y1="15" x2="21" y2="21"></line><line x1="4" y1="4" x2="9" y2="9"></line>',
    ];

    $path = $paths[$name] ?? $paths['camera'];

    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
}

/**
 * نوار کنش‌های اجتماعی کارت — پسند، دیدگاه، هم‌رسانی و بازدید
 */
function negarinActionBar($archive, string $context = 'card'): void
{
    $showLikes = (($archive->options->showLikes ?? '1') === '1');
    $views = negarinGetViews($archive);
    $cid = (int) $archive->cid;
    $likes = negarinGetLikes($archive);
    $liked = negarinIsLikedByUser($cid);
    ?>
    <div class="card-actions<?php echo $context === 'single' ? ' card-actions-single' : ''; ?>">
        <?php if ($showLikes): ?>
            <button type="button" class="act-btn like-btn<?php echo $liked ? ' is-liked' : ''; ?>" data-cid="<?php echo $cid; ?>" data-likes="<?php echo $likes; ?>"<?php echo $liked ? ' data-liked="1"' : ''; ?> aria-pressed="<?php echo $liked ? 'true' : 'false'; ?>" aria-label="<?php _e('پسندیدن'); ?>">
                <?php echo negarinIcon('heart', 20); ?>
                <span class="like-count"><?php echo negarinFormatCount($likes); ?></span>
            </button>
        <?php endif; ?>
        <a class="act-btn" href="<?php $archive->permalink(); ?>#comments" aria-label="<?php _e('دیدگاه‌ها'); ?>">
            <?php echo negarinIcon('comment', 20); ?>
            <span><?php echo negarinFormatCount((int) $archive->commentsNum); ?></span>
        </a>
        <button type="button" class="act-btn share-btn" data-url="<?php $archive->permalink(); ?>" aria-label="<?php _e('هم‌رسانی'); ?>">
            <?php echo negarinIcon('share', 20); ?>
        </button>
        <span class="views-chip" title="<?php echo negarinToPersianDigits($views); ?> <?php _e('بازدید'); ?>">
            <?php echo negarinIcon('eye', 18); ?>
            <span><?php echo negarinFormatCount($views); ?></span>
        </span>
    </div>
    <?php
}

/**
 * کاشی شبکه‌ای نوشته به سبک اینستاگرام — برای شبکهٔ سه‌ستونی صفحهٔ اصلی و گالری کاوش؛
 * همیشه تصویر دارد (شاخص ← نخستین عکس متن ← پیش‌فرض)؛
 * $variant = 'grid' (شبکهٔ اصلی: پسند + دیدگاه + بازدید) یا 'explore' (کاوش: پسند + بازدید)
 */
function negarinTileHtml($archive, string $variant = 'grid'): void
{
    $image = negarinTileImage($archive);
    $title = (string) $archive->title;
    $safeTitle = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
    $views = negarinGetViews($archive);
    $likes = negarinGetLikes($archive);
    $comments = (int) $archive->commentsNum;
    ?>
    <a class="tile" href="<?php $archive->permalink(); ?>" aria-label="<?php echo $safeTitle; ?>">
        <img src="<?php echo htmlspecialchars($image, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo $safeTitle; ?>" loading="lazy" />
        <span class="tile-overlay">
            <span class="tile-title"><?php echo $safeTitle; ?></span>
            <span class="tile-meta">
                <span class="tile-meta-item"><?php echo negarinIcon('heart', 14); ?> <?php echo negarinFormatCount($likes); ?></span>
                <?php if ($variant === 'grid'): ?>
                    <span class="tile-meta-item"><?php echo negarinIcon('comment', 14); ?> <?php echo negarinFormatCount($comments); ?></span>
                <?php endif; ?>
                <span class="tile-meta-item"><?php echo negarinIcon('eye', 14); ?> <?php echo negarinFormatCount($views); ?></span>
            </span>
        </span>
    </a>
    <?php
}

/**
 * رندر نوشته یا برگهٔ کامل
 */
function renderSingle(\Widget\Archive $archive, string $type = 'post'): void
{
    // هرو صفحهٔ نوشته فقط با تصویر شاخص — بدون آن خالی می‌ماند
    // (نخستین عکس متن فقط برای کاور کارت‌های ایندکس به کار می‌رود)
    $image = negarinThumbnail($archive);
    $views = negarinGetViews($archive);
    ?>
    <article class="card card-full" data-cid="<?php echo (int) $archive->cid; ?>" itemscope itemtype="http://schema.org/BlogPosting">
        <header class="card-head">
            <a class="card-author" href="<?php $archive->author->permalink(); ?>">
                <?php echo negarinAuthorAvatarHtml($archive, 46); ?>
                <span class="card-author-main">
                    <span class="card-author-name"><?php $archive->author(); ?></span>
                    <span class="card-author-meta">
                        <time datetime="<?php $archive->date('c'); ?>" itemprop="datePublished"><?php echo negarinToPersianDigits($archive->date->format('Y/m/d')); ?></time>
                        <?php if ($views > 0): ?>
                            <span class="dot-sep" aria-hidden="true">·</span>
                            <span class="card-views-inline"><?php echo negarinIcon('eye', 14); ?> <?php echo negarinToPersianDigits($views); ?> <?php _e('بازدید'); ?></span>
                        <?php endif; ?>
                    </span>
                </span>
            </a>
        </header>

        <div class="card-body card-body-full">
            <h1 class="card-title card-title-full" itemprop="name headline"><?php $archive->title(); ?></h1>

            <?php if ($image !== ''): ?>
                <figure class="card-hero" itemprop="image" itemscope itemtype="http://schema.org/ImageObject">
                    <img src="<?php echo htmlspecialchars($image, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars((string) $archive->title, ENT_QUOTES, 'UTF-8'); ?>" itemprop="url" />
                    <span class="card-media-heart" aria-hidden="true"><?php echo negarinIcon('heart', 64); ?></span>
                </figure>
            <?php endif; ?>

            <div class="post-content" itemprop="articleBody">
                <?php $archive->content(); ?>
            </div>

            <?php
                $chips = negarinTagChips($archive);
                if ($type === 'post' && !empty($chips)):
            ?>
                <div class="card-tags card-tags-full">
                    <?php foreach ($chips as [$chipUrl, $chipName]): ?>
                        <a class="tag-chip" href="<?php echo htmlspecialchars($chipUrl, ENT_QUOTES, 'UTF-8'); ?>">#<?php echo htmlspecialchars($chipName, ENT_QUOTES, 'UTF-8'); ?></a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($type === 'post'): ?>
                <?php negarinActionBar($archive, 'single'); ?>
            <?php endif; ?>
        </div>
    </article>
    <?php
}

/**
 * دیدگاه‌های درختی به سبک شبکه‌های اجتماعی
 */
function threadedComments($comments, $options)
{
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
    $authorName = (string) $comments->author;
?>
    <li id="li-<?php $comments->theId(); ?>" class="comment-body<?php
    if ($comments->levels > 0) {
        echo ' comment-child';
        $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
    } else {
        echo ' comment-parent';
    }
    $comments->alt(' comment-odd', ' comment-even');
    echo $commentClass;
    ?>">
        <div id="<?php $comments->theId(); ?>" class="comment-inner">
            <div class="comment-avatar-wrap">
                <?php $comments->gravatar('44', 'identicon'); ?>
            </div>
            <div class="comment-main">
                <div class="comment-meta">
                    <cite class="comment-author" itemprop="creator" itemscope itemtype="http://schema.org/Person">
                        <?php $comments->author(); ?>
                    </cite>
                    <span class="comment-time">
                        <a href="<?php $comments->permalink(); ?>" itemprop="url">
                            <time datetime="<?php $comments->date('c'); ?>" itemprop="commentTime"><?php echo negarinTimeAgo((int) $comments->created); ?></time>
                        </a>
                    </span>
                    <span class="comment-reply">
                        <?php $comments->reply(_t('پاسخ')); ?>
                    </span>
                </div>
                <div class="comment-content" itemprop="commentText">
                    <?php $comments->content(); ?>
                </div>
            </div>
        </div>
        <?php if ($comments->children) { ?>
            <div class="comment-children">
                <?php $comments->threadedComments($options); ?>
            </div>
        <?php } ?>
    </li>
<?php
}
