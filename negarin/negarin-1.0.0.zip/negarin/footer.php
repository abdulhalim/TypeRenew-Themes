<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
</main>

<footer class="site-footer" role="contentinfo">
    <div class="container">
        <div class="footer-inner">
            <a class="footer-brand" href="<?php $this->options->siteUrl(); ?>">
                <span class="footer-mark" aria-hidden="true"><?php echo negarinIcon('camera', 18); ?></span>
                <span class="footer-name"><?php $this->options->title(); ?></span>
            </a>
            <p class="footer-desc"><?php echo htmlspecialchars((string) $this->options->description, ENT_QUOTES, 'UTF-8'); ?></p>
            <?php $footerStats = negarinStats(); ?>
            <p class="footer-views">
                <?php echo negarinIcon('eye', 15); ?>
                <span><?php _e('تا اینجا'); ?> <?php echo negarinFormatCount($footerStats['views']); ?> <?php _e('بازدید ثبت شده است'); ?></span>
            </p>
            <p class="footer-meta">
                &copy; <?php echo negarinToPersianDigits(date('Y')); ?> <?php $this->options->title(); ?> ·
                <?php _e('قدرت‌گرفته از'); ?> <a href="https://www.typerenew.ir" rel="nofollow">TypeRenew</a> · <?php _e('پوستهٔ'); ?> <a href="https://pourdaryaei.ir" rel="noopener">نگارین</a> </p>
            </p>
        </div>
    </div>
</footer>

<nav class="mobile-nav" aria-label="<?php _e('ناوبری سریع'); ?>">
    <a class="mobile-nav-btn<?php echo $this->is('index') ? ' is-active' : ''; ?>" href="<?php $this->options->siteUrl(); ?>"><?php echo negarinIcon('home', 22); ?></a>
    <button type="button" class="mobile-nav-btn mobile-search-btn" aria-label="<?php _e('جستجو'); ?>"><?php echo negarinIcon('search', 22); ?></button>
    <button type="button" class="mobile-nav-btn mobile-theme-btn" aria-label="<?php _e('تغییر حالت روشن و تیره'); ?>"><span class="theme-icon" aria-hidden="true"></span></button>
    <button type="button" class="mobile-nav-btn mobile-top-btn" aria-label="<?php _e('بازگشت به بالا'); ?>"><?php echo negarinIcon('arrow-up', 22); ?></button>
</nav>

<button type="button" id="back-to-top" class="back-to-top" aria-label="<?php _e('بازگشت به بالای صفحه'); ?>" title="<?php _e('بازگشت به بالا'); ?>">
    <?php echo negarinIcon('arrow-up', 18); ?>
</button>

<div class="toast" id="toast" role="status" aria-live="polite"></div>

<?php $this->footer(); ?>

<script>
(function() {
    'use strict';

    var html = document.documentElement;
    var SUN_SVG = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>';
    var MOON_SVG = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>';

    function isDark() { return html.getAttribute('data-theme') === 'dark'; }

    function updateThemeIcons() {
        var icons = document.querySelectorAll('.theme-icon');
        for (var i = 0; i < icons.length; i++) {
            icons[i].innerHTML = isDark() ? SUN_SVG : MOON_SVG;
        }
    }

    function toggleTheme() {
        var next = isDark() ? 'light' : 'dark';
        html.classList.add('theme-transition');
        html.setAttribute('data-theme', next);
        try { localStorage.setItem('negarin-theme', next); } catch (e) {}
        updateThemeIcons();
        setTimeout(function() { html.classList.remove('theme-transition'); }, 400);
    }

    var switchBtn = document.getElementById('theme-switch');
    if (switchBtn) switchBtn.addEventListener('click', toggleTheme);
    var mobileThemeBtn = document.querySelector('.mobile-theme-btn');
    if (mobileThemeBtn) mobileThemeBtn.addEventListener('click', toggleTheme);

    var prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
    if (prefersDark.addEventListener) {
        prefersDark.addEventListener('change', function(e) {
            var stored = null;
            try { stored = localStorage.getItem('negarin-theme'); } catch (err) {}
            if (!stored) {
                html.setAttribute('data-theme', e.matches ? 'dark' : 'light');
                updateThemeIcons();
            }
        });
    }

    updateThemeIcons();

    /* ---------- اعلان کوچک ---------- */
    var toast = document.getElementById('toast');
    var toastTimer = null;
    function showToast(message) {
        if (!toast) return;
        toast.textContent = message;
        toast.classList.add('is-visible');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function() { toast.classList.remove('is-visible'); }, 2600);
    }

    /* ---------- پسندیدن (ذخیره در دیتابیس) ---------- */
    var LIKE_URL = <?php echo json_encode((string) $this->options->siteUrl, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP); ?>;
    var PERSIAN_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    function toFa(num) {
        num = String(num);
        var out = '';
        for (var i = 0; i < num.length; i++) {
            out += PERSIAN_DIGITS[+num.charAt(i)] || num.charAt(i);
        }
        return out;
    }

    /* قالب‌بندی خلاصهٔ اجتماعی — هماهنگ با negarinFormatCount در PHP */
    function compactFa(value) {
        var text = (Math.round(value * 10) / 10).toFixed(1);
        if (text.slice(-2) === '.0') {
            text = text.slice(0, -2);
        }
        return toFa(text.replace('.', '٫'));
    }
    function formatCount(num) {
        num = parseInt(num, 10) || 0;
        if (num >= 1000000) {
            return compactFa(num / 1000000) + ' میلیون';
        }
        if (num >= 1000) {
            var thousands = num / 1000;
            if (thousands >= 1000) {
                return compactFa(thousands / 1000) + ' میلیون';
            }
            return compactFa(thousands) + ' هزار';
        }
        return toFa(num);
    }

    function paintLikeButton(btn) {
        var countEl = btn.querySelector('.like-count');
        if (countEl) {
            countEl.textContent = formatCount(btn.getAttribute('data-likes'));
        }
        var liked = btn.getAttribute('data-liked') === '1';
        btn.classList.toggle('is-liked', liked);
        btn.setAttribute('aria-pressed', liked ? 'true' : 'false');
    }

    function animateLike(btn) {
        btn.classList.remove('is-animating');
        void btn.offsetWidth;
        btn.classList.add('is-animating');
        var card = btn.closest('.card');
        var heart = card ? card.querySelector('.card-media-heart') : null;
        if (heart) {
            heart.classList.remove('is-popped');
            void heart.offsetWidth;
            heart.classList.add('is-popped');
        }
    }

    var likeBusy = {};

    function sendLike(cid, btn) {
        if (likeBusy[cid]) return;
        likeBusy[cid] = true;

        var before = {
            likes: btn.getAttribute('data-likes'),
            liked: btn.getAttribute('data-liked')
        };
        var optimistic = btn.getAttribute('data-liked') === '1' ? -1 : 1;

        /* به‌روزرسانی خوش‌بینانهٔ همهٔ دکمه‌های همین نوشته */
        var all = document.querySelectorAll('.like-btn[data-cid="' + cid + '"]');
        for (var i = 0; i < all.length; i++) {
            all[i].setAttribute('data-likes', String((parseInt(all[i].getAttribute('data-likes'), 10) || 0) + optimistic));
            all[i].setAttribute('data-liked', optimistic > 0 ? '1' : '0');
            paintLikeButton(all[i]);
        }

        var body = new URLSearchParams();
        body.append('negarinLike', cid);

        fetch(LIKE_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' },
            body: body.toString(),
            credentials: 'same-origin'
        })
        .then(function(res) { return res.json(); })
        .then(function(data) {
            delete likeBusy[cid];
            if (!data || !data.ok) {
                for (var j = 0; j < all.length; j++) {
                    all[j].setAttribute('data-likes', before.likes);
                    all[j].setAttribute('data-liked', before.liked);
                    paintLikeButton(all[j]);
                }
                showToast('ذخیرهٔ پسند ممکن نشد؛ دوباره تلاش کنید');
                return;
            }
            /* همگام‌سازی با مقدار قطعی سرور */
            for (var k = 0; k < all.length; k++) {
                all[k].setAttribute('data-likes', String(data.likes));
                all[k].setAttribute('data-liked', data.liked ? '1' : '0');
                paintLikeButton(all[k]);
            }
        })
        .catch(function() {
            delete likeBusy[cid];
            for (var m = 0; m < all.length; m++) {
                all[m].setAttribute('data-likes', before.likes);
                all[m].setAttribute('data-liked', before.liked);
                paintLikeButton(all[m]);
            }
            showToast('ذخیرهٔ پسند ممکن نشد؛ اتصال اینترنت را بررسی کنید');
        });
    }

    var likeButtons = document.querySelectorAll('.like-btn');
    for (var bi = 0; bi < likeButtons.length; bi++) {
        paintLikeButton(likeButtons[bi]);
        (function(btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                var cid = String(btn.getAttribute('data-cid'));
                var nowLiked = btn.getAttribute('data-liked') !== '1';
                sendLike(cid, btn);
                if (nowLiked) {
                    animateLike(btn);
                }
            });
        })(likeButtons[bi]);
    }

    /* ---------- دو ضربه روی عکس نوشتهٔ کامل = پسند ----------
       (فقط صفحهٔ تک‌نوشته؛ در فید، عکس لینک نوشته است و تک‌کلیک آن را می‌گشاید) */
    var mediaEls = document.querySelectorAll('.card-hero');
    for (var mi = 0; mi < mediaEls.length; mi++) {
        (function(media) {
            var lastTap = 0;
            function handleTap(e) {
                if (e.target.closest('.card-media-heart')) return;
                var now = Date.now();
                if (now - lastTap < 350) {
                    e.preventDefault();
                    var card = media.closest('.card');
                    var btn = card ? card.querySelector('.like-btn') : null;
                    var cid = card ? card.getAttribute('data-cid') : null;
                    if (!cid) return;
                    if (btn && btn.hasAttribute('data-cid')) {
                        /* دو ضربه فقط پسند می‌افزاید؛ لغو پسند با خودِ دکمهٔ قلب */
                        if (btn.getAttribute('data-liked') !== '1') {
                            sendLike(cid, btn);
                            animateLike(btn);
                        } else {
                            var heartOnly = media.querySelector('.card-media-heart');
                            if (heartOnly) {
                                heartOnly.classList.remove('is-popped');
                                void heartOnly.offsetWidth;
                                heartOnly.classList.add('is-popped');
                            }
                        }
                    } else {
                        /* دکمهٔ پسند مخفی است؛ فقط قلب بزرگ نمایش داده می‌شود */
                        var heartHidden = media.querySelector('.card-media-heart');
                        if (heartHidden) {
                            heartHidden.classList.remove('is-popped');
                            void heartHidden.offsetWidth;
                            heartHidden.classList.add('is-popped');
                        }
                    }
                    lastTap = 0;
                } else {
                    lastTap = now;
                }
            }
            media.addEventListener('click', handleTap);
        })(mediaEls[mi]);
    }

    /* ---------- هم‌رسانی ---------- */
    var shareButtons = document.querySelectorAll('.share-btn');
    for (var si = 0; si < shareButtons.length; si++) {
        (function(btn) {
            btn.addEventListener('click', function() {
                var url = btn.getAttribute('data-url') || window.location.href;
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(url).then(function() {
                        showToast('پیوند نوشته هم‌رسانی شد');
                    }, function() { fallbackCopy(url); });
                } else {
                    fallbackCopy(url);
                }
            });
        })(shareButtons[si]);
    }
    function fallbackCopy(url) {
        var input = document.createElement('textarea');
        input.value = url;
        input.style.position = 'fixed';
        input.style.opacity = '0';
        document.body.appendChild(input);
        input.select();
        try { document.execCommand('copy'); showToast('پیوند نوشته هم‌رسانی شد'); }
        catch (err) { showToast(url); }
        document.body.removeChild(input);
    }

    /* ---------- ردیف استوری ---------- */
    var storiesScroll = document.getElementById('stories-scroll');
    if (storiesScroll) {
        var storiesWrap = storiesScroll.closest('.stories-inner');
        var prevBtn = document.querySelector('.stories-prev');
        var nextBtn = document.querySelector('.stories-next');

        function step() {
            return Math.max(200, storiesScroll.clientWidth * 0.8);
        }
        if (prevBtn) prevBtn.addEventListener('click', function() {
            storiesScroll.scrollBy({ left: step(), behavior: 'smooth' });
        });
        if (nextBtn) nextBtn.addEventListener('click', function() {
            storiesScroll.scrollBy({ left: -step(), behavior: 'smooth' });
        });

        function updateStoriesNav() {
            var max = storiesScroll.scrollWidth - storiesScroll.clientWidth - 2;
            var pos = Math.abs(storiesScroll.scrollLeft);
            if (prevBtn) prevBtn.style.visibility = pos < 4 ? 'hidden' : 'visible';
            if (nextBtn) nextBtn.style.visibility = pos > max ? 'hidden' : 'visible';
            if (storiesWrap) {
                if (pos > 4) {
                    storiesWrap.classList.add('has-start');
                } else {
                    storiesWrap.classList.remove('has-start');
                }
                if (pos < max) {
                    storiesWrap.classList.add('has-end');
                } else {
                    storiesWrap.classList.remove('has-end');
                }
            }
        }
        storiesScroll.addEventListener('scroll', updateStoriesNav, { passive: true });
        window.addEventListener('resize', updateStoriesNav);
        updateStoriesNav();
    }

    /* ---------- بازگشت به بالا ---------- */
    var backBtn = document.getElementById('back-to-top');
    function updateBackToTop() {
        if (!backBtn) return;
        if (window.pageYOffset > 480) {
            backBtn.classList.add('is-visible');
        } else {
            backBtn.classList.remove('is-visible');
        }
    }
    if (backBtn) {
        backBtn.addEventListener('click', function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
    var topBtn = document.querySelector('.mobile-top-btn');
    if (topBtn) topBtn.addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    /* ---------- جستجوی موبایل ---------- */
    var mobileSearch = document.querySelector('.mobile-search-btn');
    if (mobileSearch) {
        mobileSearch.addEventListener('click', function() {
            var input = document.querySelector('.search-input');
            if (input) {
                input.scrollIntoView({ behavior: 'smooth', block: 'center' });
                setTimeout(function() { input.focus(); }, 350);
            }
        });
    }

    /* ---------- آواتار شکسته: گراواتارِ نبودنی → حرف آغازین ---------- */
    window.addEventListener('error', function(e) {
        var img = e.target;
        if (!img || img.tagName !== 'IMG') return;

        /* آواتار نویسندهٔ نوشته (گراواتار با d=404) */
        var avatarSpan = img.closest ? img.closest('.avatar[data-avatar-initial]') : null;
        if (avatarSpan) {
            var span = document.createElement('span');
            span.className = 'avatar avatar-fallback';
            var size = avatarSpan.style.getPropertyValue('--avatar-size') || '46px';
            span.style.setProperty('--avatar-size', size);
            span.style.setProperty('--avatar-hue', avatarSpan.getAttribute('data-avatar-hue') || '0');
            span.setAttribute('aria-hidden', 'true');
            span.innerHTML = '<span>' + avatarSpan.getAttribute('data-avatar-initial') + '</span>';
            if (avatarSpan.parentNode) {
                avatarSpan.parentNode.replaceChild(span, avatarSpan);
            }
            return;
        }

        /* آواتار دیدگاه‌ها */
        var wrap = img.closest ? img.closest('.comment-avatar-wrap') : null;
        if (!wrap) return;
        var name = (img.getAttribute('alt') || '').trim() || '؟';
        var hue = 0;
        for (var ci = 0; ci < name.length; ci++) {
            hue = (hue * 31 + name.charCodeAt(ci)) % 360;
        }
        var cspan = document.createElement('span');
        cspan.className = 'avatar avatar-fallback';
        cspan.style.setProperty('--avatar-size', '44px');
        cspan.style.setProperty('--avatar-hue', String(hue));
        cspan.innerHTML = '<span>' + name.charAt(0) + '</span>';
        wrap.innerHTML = '';
        wrap.appendChild(cspan);
    }, true);

    var ticking = false;
    window.addEventListener('scroll', function() {
        if (!ticking) {
            window.requestAnimationFrame(function() {
                updateBackToTop();
                ticking = false;
            });
            ticking = true;
        }
    }, { passive: true });

    updateBackToTop();
})();
</script>

</body>
</html>
