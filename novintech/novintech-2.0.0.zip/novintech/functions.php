<?php
/**
 * Theme Functions
 *
 * @package NovinTech Theme
 * @author پوردریایی
 * @link https://pourdaryaei.ir
 * @version 1.2.1
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/* ============================================================
   هلپرهای عمومی
   ============================================================ */

/** خواندن امن مقدار تنظیم پوسته با مقدار پیش‌فرض */
function novintech_opt(string $key, string $default = ''): string
{
    try {
        $options = \Widget\Options::alloc();
        $value = $options->{$key};
        return (is_string($value) && trim($value) !== '') ? $value : $default;
    } catch (\Throwable $e) {
        return $default;
    }
}

/**
 * اطلاعات تماس با مقدار دمو: اگر مدیر در تنظیمات پوسته چیزی وارد نکرده باشد،
 * اطلاعات نمونه نمایش داده می‌شود تا بخش تماس/فوتر خالی نماند.
 * با پرکردن همان فیلد در تنظیمات پوسته، مقدار واقعی جای دمو را می‌گیرد.
 */
function novintech_contact(string $key, string $demo): string
{
    return novintech_opt($key, $demo);
}

/** مقدارهای دموی اطلاعات تماس (قابل بازنویسی از تنظیمات پوسته) */
function novintech_contact_demo(string $key): string
{
    static $demos = [
        'contact_phone'    => '021-91008877',
        'contact_email'    => 'info@novintech.example',
        'contact_address'  => 'تهران، خیابان ولیعصر، بالاتر از پارک ساعی، برج نوین، طبقهٔ ۱۲',
        'social_instagram' => 'https://instagram.comnovintech_demo',
        'social_telegram'  => 'https://t.menovintech_demo',
        'social_twitter'   => 'https://x.comnovintech_demo',
        'social_linkedin'  => 'https://linkedin.com/companynovintech_demo',
    ];
    return $demos[$key] ?? '';
}

/** شمارهٔ تماس نهایی (تنظیم مدیر یا دمو) — شمارهٔ خام برای لینک tel: */
function novintech_contact_phone(): string
{
    return novintech_contact('contact_phone', novintech_contact_demo('contact_phone'));
}

/** نام مسیر (route) جاری — مثل index / archive / post / page */
function novintech_route(): string
{
    try {
        if (class_exists('\Typecho\Router') && property_exists('\Typecho\Router', 'current')) {
            $current = \Typecho\Router::$current;
            if (is_string($current) && $current !== '') {
                return $current;
            }
        }
    } catch (\Throwable $e) {
    }
    return '';
}

/** آیا همین صفحه «صفحهٔ اول» سایت است؟ (فقط مسیر index — نه صفحه‌بندی آن) */
function novintech_is_front(): bool
{
    return novintech_route() === 'index';
}

/** تبدیل ارقام لاتین به فارسی */
function novintech_fa_digits(string $text): string
{
    return str_replace(
        array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9'),
        array('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'),
        $text
    );
}

/**
 * آدرس فهرست مقالات (وبلاگ) — الگوی پوسته الناز
 * ۱) نشانی سفارشی از تنظیمات پوسته
 * ۲) مسیر آرشیو واقعی از جدول مسیریابی هسته (Router::url('archive'))
 * ۳) در نبود آن‌ها، آدرس سایت
 */
function novintech_blog_url(): string
{
    $custom = trim(novintech_opt('novintechBlogUrl'));
    if ($custom !== '') {
        return $custom;
    }
    try {
        if (class_exists('\Typecho\Router')) {
            $url = \Typecho\Router::url('archive', [], (string)\Widget\Options::alloc()->index);
            if (is_string($url) && $url !== '' && $url !== '#') {
                return $url;
            }
        }
    } catch (\Throwable $e) {
    }
    try {
        return rtrim((string)\Widget\Options::alloc()->siteUrl, '/') . '/';
    } catch (\Throwable $e) {
        return '#';
    }
}

/** آیا صفحهٔ جاری یکی از صفحات مرتبط با وبلاگ است؟ (برای حالت فعال منو) */
function novintech_is_blog_context(): bool
{
    $route = novintech_route();
    return in_array($route, array('archive', 'archive_page', 'index_page', 'search', 'search_page', 'post', 'category', 'category_page', 'tag', 'tag_page'), true);
}

/* ============================================================
   صفحه‌بندی فارسی — الگوی پوستهٔ الناز
   itemTag خالی → کلاس‌ها مستقیم روی <a> می‌نشینند (رفتار Box.php).
   ارقام فقط داخل متن تگ‌ها فارسی می‌شوند، نه در href.
   ============================================================ */

function novintech_page_nav($archive): void
{
    if ($archive === null || !method_exists($archive, 'pageNav')) {
        return;
    }
    ob_start();
    $archive->pageNav(
        'قبلی',
        'بعدی',
        2,
        '...',
        array(
            'wrapTag'      => 'nav',
            'wrapClass'    => 'pagination-nav pagination',
            'itemTag'      => '',
            'textTag'      => '',
            'currentClass' => 'current',
            'prevClass'    => 'prev',
            'nextClass'    => 'next',
        )
    );
    $html = (string)ob_get_clean();
    if (trim($html) === '') {
        return;
    }
    echo preg_replace_callback(
        '/>([^<>]*)</',
        function ($m) {
            return '>' . novintech_fa_digits($m[1]) . '<';
        },
        $html
    );
}

/** تجزیهٔ بلوک‌های متنی خطی با جداکنندهٔ | — مثل «عنوان | توضیح | آیکون» */
function novintech_parse_lines(string $raw, int $minParts = 1): array
{
    $out = array();
    foreach (preg_split('/\r\n|\r|\n/', trim($raw)) as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        $parts = array_map('trim', explode('|', $line));
        if (count($parts) >= $minParts) {
            $out[] = $parts;
        }
    }
    return $out;
}

/**
 * آیکون‌های Lucide — lucide.dev (پروانهٔ ISC)
 * تمام آیکون‌های پوسته از این تابع رندر می‌شوند (SVG درون‌خطی، رنگ از currentColor).
 */
function novintech_icon(string $key, int $size = 24, string $class = ''): string
{
    $icons = array(
        /* خدمات و ویژگی‌ها */
        'code'        => '<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>',
        'mobile'      => '<rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><path d="M12 18h.01"/>',
        'pen'         => '<path d="m12 19 7-7 3 3-7 7-3-3z"/><path d="m18 13-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/><path d="m2 2 7.586 7.586"/><circle cx="11" cy="11" r="2"/>',
        'chart'       => '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
        'cloud'       => '<path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/>',
        'shield'      => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>',
        'shield-check' => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
        'users'       => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'user'        => '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'award'       => '<circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>',
        'briefcase'   => '<path d="M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/><rect width="20" height="14" x="2" y="6" rx="2"/>',
        'clock'       => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
        'check'       => '<path d="M20 6 9 17l-5-5"/>',
        'check-circle' => '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
        'spark'       => '<path d="m12 3-1.9 5.8a2 2 0 0 1-1.287 1.288L3 12l5.8 1.9a2 2 0 0 1 1.288 1.287L12 21l1.9-5.8a2 2 0 0 1 1.287-1.288L21 12l-5.8-1.9a2 2 0 0 1-1.288-1.287Z"/>',
        'zap'         => '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
        'rocket'      => '<path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>',
        'arrow'       => '<path d="M19 12H5"/><path d="m12 19-7-7 7-7"/>',
        'arrow-right' => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
        'arrow-up'    => '<path d="m5 12 7-7 7 7"/><path d="M12 19V5"/>',
        'doc'         => '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
        /* مخاطبین، بوکینگ و عمومی */
        'phone'       => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
        'mail'        => '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
        'map-pin'     => '<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',
        'calendar'    => '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/>',
        'calendar-check' => '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="m9 16 2 2 4-4"/>',
        'send'        => '<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
        'x'           => '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
        'lock'        => '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
        'inbox'       => '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
        'message-square' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
        'trash'       => '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
        'target'      => '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
        'star'        => '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
        'search'      => '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
        'chevron-left'  => '<path d="m15 18-6-6 6-6"/>',
        'chevron-right' => '<path d="m9 18 6-6-6-6"/>',
        'chevron-down'  => '<path d="m6 9 6 6 6-6"/>',
        'home'        => '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
        'link'        => '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
        'copy'        => '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
        'tag'         => '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"/>',
        'reply'       => '<polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 0 0-4-4H4"/>',
        'building'    => '<rect width="16" height="20" x="4" y="2" rx="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01"/><path d="M16 6h.01"/><path d="M12 6h.01"/><path d="M12 10h.01"/><path d="M12 14h.01"/><path d="M16 10h.01"/><path d="M16 14h.01"/><path d="M8 10h.01"/><path d="M8 14h.01"/>',
        'server'      => '<rect width="20" height="8" x="2" y="2" rx="2" ry="2"/><rect width="20" height="8" x="2" y="14" rx="2" ry="2"/><line x1="6" x2="6.01" y1="6" y2="6"/><line x1="6" x2="6.01" y1="18" y2="18"/>',
        'monitor'     => '<rect width="20" height="14" x="2" y="3" rx="2"/><line x1="8" x2="16" y1="21" y2="21"/><line x1="12" x2="12" y1="17" y2="21"/>',
        'database'    => '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5V19A9 3 0 0 0 21 19V5"/><path d="M3 12A9 3 0 0 0 21 12"/>',
        /* شبکه‌های اجتماعی */
        'instagram'   => '<rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>',
        'telegram'    => '<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
        'twitter'     => '<path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/>',
        'linkedin'    => '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect width="4" height="12" x="2" y="9"/><circle cx="4" cy="4" r="2"/>',
    );
    $body = isset($icons[$key]) ? $icons[$key] : $icons['zap'];
    $classAttr = ($class !== '') ? ' class="' . htmlspecialchars($class, ENT_QUOTES) . '"' : '';
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="' . $size . '" height="' . $size . '"' . $classAttr
        . ' fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $body . '</svg>';
}

/**
 * تصویر شاخص مطلب — فیلد جدید thumb و سپس فیلد قدیمی thumbnail
 * (سازگاری کامل با مطالب قبلی پوسته)
 */
function novintech_thumb($widget): string
{
    $url = '';
    if (is_object($widget)) {
        foreach (array('thumb', 'thumbnail') as $nvtFieldName) {
            try {
                if (isset($widget->fields->{$nvtFieldName})) {
                    $candidate = trim((string)$widget->fields->{$nvtFieldName});
                    if ($candidate !== '') {
                        $url = $candidate;
                        break;
                    }
                }
            } catch (\Throwable $e) {
            }
        }
    }
    return $url;
}

/** تصویر شاخص از روی cid — thumb سپس thumbnail (برای کارت‌های قبلی/بعدی) */
function novintech_fields_thumb(int $cid): string
{
    if ($cid < 1) {
        return '';
    }
    try {
        $db = Typecho_Db::get();
        $rows = $db->fetchAll(
            $db->select('name', 'str_value')->from('table.fields')
                ->where('cid = ?', $cid)
                ->where('name IN ?', array('thumb', 'thumbnail'))
        );
        $map = array();
        foreach ($rows as $row) {
            $map[(string)$row['name']] = trim((string)$row['str_value']);
        }
        if (isset($map['thumb']) && $map['thumb'] !== '') {
            return $map['thumb'];
        }
        if (isset($map['thumbnail']) && $map['thumbnail'] !== '') {
            return $map['thumbnail'];
        }
    } catch (\Throwable $e) {
    }
    return '';
}

/* ============================================================
   پنل تنظیمات پوسته
   ============================================================ */

/**
 * Theme Configuration Panel
 */
function themeConfig($form)
{
    // ---------- صفحهٔ اول ----------
    $frontStyle = new Typecho_Widget_Helper_Form_Element_Radio(
        'novintechFrontStyle',
        array(
            'classic' => _t('کلاسیک (فعلی)'),
            'modern'  => _t('مدرن (شیشه‌ای + گرادیان)'),
        ),
        'classic',
        _t('قالب صفحهٔ اول'),
        _t('طرح صفحهٔ نخست سایت را انتخاب کنید؛ طرح «مدرن» لندینگ شیشه‌ای جدید پوسته است.')
    );
    $form->addInput($frontStyle);

    $blogUrl = new Typecho_Widget_Helper_Form_Element_Text('novintechBlogUrl', NULL, NULL, _t('نشانی صفحهٔ مقالات'), _t('در حالت پیش‌فرض مسیر آرشیو هسته (مثل /blog/) استفاده می‌شود؛ اگر صفحهٔ دلخواهی دارید نشانی کامل آن را وارد کنید.'));
    $form->addInput($blogUrl);

    // Site Logo
    $logo = new Typecho_Widget_Helper_Form_Element_Text('logo', NULL, NULL, _t('آدرس لوگو'), _t('آدرس کامل تصویر لوگو سایت (PNG/JPG)'));
    $form->addInput($logo);

    $favicon = new Typecho_Widget_Helper_Form_Element_Text('favicon', NULL, NULL, _t('آدرس Favicon'), _t('آدرس کامل آیکون سایت (ICO/PNG)'));
    $form->addInput($favicon);

    // Contact Information
    $contactPhone = new Typecho_Widget_Helper_Form_Element_Text('contact_phone', NULL, NULL, _t('شماره تلفن'), _t('شماره تلفن تماس — در حالت خالی، شمارهٔ دموی ۰۲۱-۹۱۰۰۸۸۷۷ نمایش داده می‌شود'));
    $form->addInput($contactPhone);

    $contactEmail = new Typecho_Widget_Helper_Form_Element_Text('contact_email', NULL, NULL, _t('ایمیل'), _t('آدرس ایمیل تماس — در حالت خالی، ایمیل دموی info@novintech.example نمایش داده می‌شود'));
    $form->addInput($contactEmail);

    $contactAddress = new Typecho_Widget_Helper_Form_Element_Textarea('contact_address', NULL, NULL, _t('آدرس'), _t('آدرس شرکت — در حالت خالی، آدرس دمو نمایش داده می‌شود'));
    $form->addInput($contactAddress);

    // Google Maps Coordinates (Single Field)
    $mapCoordinates = new Typecho_Widget_Helper_Form_Element_Text('map_coordinates', NULL, NULL, _t('مختصات نقشه گوگل'), _t('فرمت: 27.16562176463718, 56.246837684355505'));
    $form->addInput($mapCoordinates);

    /* ---------- محتوای لندینگ مدرن ---------- */

    $heroBadge = new Typecho_Widget_Helper_Form_Element_Text('novintechHeroBadge', NULL, _t('راهکارهای دیجیتال پیشرفته'), _t('برچسب بالای عنوان هیرو (مدرن)'), _t('متن کوچک روی گلولهٔ هیرو'));
    $form->addInput($heroBadge);

    $heroTitle = new Typecho_Widget_Helper_Form_Element_Text('novintechHeroTitle', NULL, _t('آینده کسب‌وکار شما در دستان ماست'), _t('عنوان هیرو (مدرن)'), _t('برای رنگی کردن بخشی از عنوان، آن را داخل *ستاره* قرار دهید'));
    $form->addInput($heroTitle);

    $heroSubtitle = new Typecho_Widget_Helper_Form_Element_Textarea('novintechHeroSubtitle', NULL, _t('با بهره‌گیری از جدیدترین تکنولوژی‌ها و تیم مجرب، کسب‌وکار شما را به سطح بالاتری می‌بریم. از طراحی وب تا هوش مصنوعی، همراه شما هستیم.'), _t('زیرمتن هیرو (مدرن)'), _t('توضیح کوتاه زیر عنوان'));
    $form->addInput($heroSubtitle);

    $heroPrimary = new Typecho_Widget_Helper_Form_Element_Text('novintechHeroPrimary', NULL, _t('شروع همکاری'), _t('دکمهٔ اصلی هیرو (مدرن)'), _t('متن دکمهٔ پررنگ؛ نشانی آن به بخش تماس اشاره می‌کند'));
    $form->addInput($heroPrimary);

    $heroSecondary = new Typecho_Widget_Helper_Form_Element_Text('novintechHeroSecondary', NULL, _t('مشاهده خدمات'), _t('دکمهٔ دوم هیرو (مدرن)'), _t('متن دکمهٔ حاشیه‌دار؛ به بخش خدمات اشاره می‌کند'));
    $form->addInput($heroSecondary);

    $servicesRaw = new Typecho_Widget_Helper_Form_Element_Textarea(
        'novintechServices',
        NULL,
        _t("توسعه وب | طراحی و توسعه وب‌سایت‌های مدرن، سریع و امن با جدیدترین تکنولوژی‌ها | code\nاپلیکیشن موبایل | ساخت اپلیکیشن‌های موبایل چندپلتفرمی و بومی برای iOS و Android | mobile\nطراحی UI/UX | طراحی رابط کاربری زیبا و تجربهٔ کاربری عالی برای محصولات دیجیتال | pen\nدیجیتال مارکتینگ | استراتژی‌های بازاریابی دیجیتال برای افزایش فروش و رشد کسب‌وکار | chart\nخدمات ابری | راه‌اندازی و مدیریت زیرساخت‌های ابری مقیاس‌پذیر و امن | cloud\nامنیت سایبری | محافظت از کسب‌وکار شما در برابر تهدیدات و حملات سایبری | shield"),
        _t('خدمات لندینگ مدرن'),
        _t('هر خط: عنوان | توضیح | کلید آیکون (code، mobile، pen، chart، cloud، shield، users، award، briefcase، clock، rocket، doc)')
    );
    $form->addInput($servicesRaw);

    $statsRaw = new Typecho_Widget_Helper_Form_Element_Textarea(
        'novintechStats',
        NULL,
        _t("+۲۵۰ | پروژهٔ موفق\n+۱۸۰ | مشتری راضی\n+۱۲ | سال تجربه\n۹۸٪ | رضایت مشتری"),
        _t('نوار آمار لندینگ مدرن'),
        _t('هر خط: عدد | برچسب')
    );
    $form->addInput($statsRaw);

    $aboutTitle = new Typecho_Widget_Helper_Form_Element_Text('novintechAboutTitle', NULL, _t('چرا نوین‌تک را انتخاب کنید؟'), _t('عنوان دربارهٔ ما (مدرن)'), _t('عنوان بخش «دربارهٔ ما» در لندینگ مدرن'));
    $form->addInput($aboutTitle);

    $aboutText = new Typecho_Widget_Helper_Form_Element_Textarea(
        'novintechAboutText',
        NULL,
        _t('شرکت نوین‌تک با بیش از یک دهه تجربه در حوزهٔ فناوری اطلاعات، همواره در خط مقدم نوآوری و تحول دیجیتال قرار داشته است. ما با تیمی متشکل از بهترین متخصصان، راهکارهای هوشمند و کارآمد برای کسب‌وکارها ارائه می‌دهیم و تعهد ما به کیفیت، نوآوری و رضایت مشتری است.'),
        _t('متن دربارهٔ ما (مدرن)'),
        _t('متن توضیحی بخش «دربارهٔ ما» در لندینگ مدرن')
    );
    $form->addInput($aboutText);

    $aboutPoints = new Typecho_Widget_Helper_Form_Element_Textarea(
        'novintechAboutPoints',
        NULL,
        _t("تیم متخصص و با تجربه\nپشتیبانی ۲۴/۷ و پاسخ‌گویی سریع\nتحویل به‌موقع و شفافیت کامل قرارداد\nتضمین امنیت و مقیاس‌پذیری راهکارها"),
        _t('مزیت‌های دربارهٔ ما (مدرن)'),
        _t('هر خط یک مزیت با علامت تیک')
    );
    $form->addInput($aboutPoints);

    $ctaTitle = new Typecho_Widget_Helper_Form_Element_Text('novintechCtaTitle', NULL, _t('آمادهٔ شروع تحول دیجیتال هستید؟'), _t('عنوان دعوت پایانی (مدرن)'), _t('عنوان بخش دعوت پایانی (CTA) در لندینگ مدرن'));
    $form->addInput($ctaTitle);

    $ctaText = new Typecho_Widget_Helper_Form_Element_Textarea('novintechCtaText', NULL, _t('تیم ما آماده است تا ایدهٔ شما را به محصولی دیجیتال، سریع و امن تبدیل کند. همین امروز مشاورهٔ رایگان بگیرید.'), _t('متن دعوت پایانی (مدرن)'), _t('متن بخش دعوت پایانی (CTA) در لندینگ مدرن'));
    $form->addInput($ctaText);

    $ctaButton = new Typecho_Widget_Helper_Form_Element_Text('novintechCtaButton', NULL, _t('درخواست مشاورهٔ رایگان'), _t('دکمهٔ دعوت پایانی (مدرن)'), _t('با کلیک روی این دکمه، فرم درخواست مشاورهٔ رایگان فعال می‌شود'));
    $form->addInput($ctaButton);

    /* ---------- درخواست مشاورهٔ رایگان (بوکینگ) ---------- */

    $bookingTitle = new Typecho_Widget_Helper_Form_Element_Text('novintechBookingTitle', NULL, _t('درخواست مشاورهٔ رایگان'), _t('عنوان بخش مشاوره'), _t('عنوان بخش فرم درخواست مشاورهٔ رایگان در صفحهٔ اول'));
    $form->addInput($bookingTitle);

    $bookingSubtitle = new Typecho_Widget_Helper_Form_Element_Text('novintechBookingSubtitle', NULL, _t('فرم را پر کنید؛ کارشناسان ما در اولین فرصت برای هماهنگی جلسهٔ مشاورهٔ رایگان با شما تماس می‌گیرند.'), _t('زیرمتن بخش مشاوره'), _t('متن توضیحی زیر عنوان بخش مشاوره'));
    $form->addInput($bookingSubtitle);

    $bookingServices = new Typecho_Widget_Helper_Form_Element_Text('novintechBookingServices', NULL, _t('توسعه وب, اپلیکیشن موبایل, طراحی UI/UX, دیجیتال مارکتینگ, خدمات ابری, امنیت سایبری, مشاورهٔ عمومی'), _t('گزینه‌های فرم مشاوره'), _t('گزینه‌های منوی «خدمت موردنیاز» فرم مشاوره — با کاما جدا کنید'));
    $form->addInput($bookingServices);

    $bookingCid = new Typecho_Widget_Helper_Form_Element_Text('novintechBookingCid', NULL, NULL, _t('شناسهٔ برگهٔ دفتر درخواست‌ها (پیشرفته)'), _t('در حالت پیش‌فرض برگهٔ سیستمی «دفتر درخواست‌های مشاوره» خودکار ساخته می‌شود؛ اگر می‌خواهید درخواست‌ها روی برگهٔ دلخواه ذخیره شوند شناسهٔ آن را وارد کنید. مدیریت درخواست‌ها از برگهٔ «مدیریت درخواست‌ها» یا مدیریت ← دیدگاه‌ها انجام می‌شود.'));
    $form->addInput($bookingCid);

    /* ---------- فوتر ---------- */

    $footerText = new Typecho_Widget_Helper_Form_Element_Textarea('novintechFooterText', NULL, _t('نوین‌تک — همراه شما در مسیر تحول دیجیتال؛ از طراحی وب و موبایل تا راهکارهای ابری و امنیت.'), _t('متن معرفی فوتر'), _t('متن کوتاه معرفی شرکت که در ستون اول فوتر نمایش داده می‌شود'));
    $form->addInput($footerText);

    // Social Media
    $socialInstagram = new Typecho_Widget_Helper_Form_Element_Text('social_instagram', NULL, NULL, _t('اینستاگرام'), _t('لینک صفحه اینستاگرام — در حالت خالی، لینک دمو نمایش داده می‌شود'));
    $form->addInput($socialInstagram);

    $socialTelegram = new Typecho_Widget_Helper_Form_Element_Text('social_telegram', NULL, NULL, _t('تلگرام'), _t('لینک کانال یا گروه تلگرام — در حالت خالی، لینک دمو نمایش داده می‌شود'));
    $form->addInput($socialTelegram);

    $socialTwitter = new Typecho_Widget_Helper_Form_Element_Text('social_twitter', NULL, NULL, _t('توییتر'), _t('لینک صفحه توییتر — در حالت خالی، لینک دمو نمایش داده می‌شود'));
    $form->addInput($socialTwitter);

    $socialLinkedin = new Typecho_Widget_Helper_Form_Element_Text('social_linkedin', NULL, NULL, _t('لینکدین'), _t('لینک صفحه لینکدین — در حالت خالی، لینک دمو نمایش داده می‌شود'));
    $form->addInput($socialLinkedin);

    // Footer Pages - Multi-select
    $footerPages = new Typecho_Widget_Helper_Form_Element_Checkbox(
        'footerPages',
        getPagesList(),
        NULL,
        _t('صفحات فوتر'),
        _t('صفحاتی که در فوتر نمایش داده شوند؛ اگر خالی بمانند همهٔ صفحات نمایش داده می‌شوند')
    );
    $form->addInput($footerPages);

    // Custom Code
    $headerCode = new Typecho_Widget_Helper_Form_Element_Textarea('header_code', NULL, NULL, _t('کد هدر'), _t('کدهای JavaScript یا CSS که در هدر قرار می‌گیرند'));
    $form->addInput($headerCode);

    $footerCode = new Typecho_Widget_Helper_Form_Element_Textarea('footer_code', NULL, NULL, _t('کد فوتر'), _t('کدهای JavaScript یا CSS که در فوتر قرار می‌گیرند'));
    $form->addInput($footerCode);
}

/**
 * Get Pages List for Selection
 */
function getPagesList()
{
    try {
        $db = Typecho_Db::get();
        $pages = $db->fetchAll(
            $db->select('slug', 'title')->from('table.contents')
                ->where('type = ?', 'page')
                ->where('status = ?', 'publish')
                ->order('table.contents.order', Typecho_Db::SORT_ASC)
        );
    } catch (\Throwable $e) {
        return array();
    }

    $result = array();
    foreach ($pages as $page) {
        $result[$page['slug']] = $page['title'];
    }
    return $result;
}

/**
 * Theme Fields for Posts/Pages
 */
function themeFields($layout)
{
    $thumb = new Typecho_Widget_Helper_Form_Element_Text('thumb', NULL, NULL, _t('تصویر شاخص (thumb)'), _t('آدرس تصویر شاخص این مطلب — در کارت‌های مقالات و تصویر اصلی پست استفاده می‌شود'));
    $layout->addItem($thumb);

    $thumbnail = new Typecho_Widget_Helper_Form_Element_Text('thumbnail', NULL, NULL, _t('تصویر شاخص قدیمی (thumbnail)'), _t('فیلد قدیمی پوسته — برای سازگاری با مطالب قبلی نگه داشته شده؛ اگر فیلد thumb خالی باشد از آن استفاده می‌شود'));
    $layout->addItem($thumbnail);

    $subtitle = new Typecho_Widget_Helper_Form_Element_Text('subtitle', NULL, NULL, _t('زیرعنوان'), _t('زیرعنوان برای صفحات'));
    $layout->addItem($subtitle);
}

/* ============================================================
   سیستم درخواست مشاورهٔ رایگان (بوکینگ ساده)
   الگوی اثبات‌شدهٔ پوسته‌های نهال و الناز
   ------------------------------------------------------------
   معماری:
   ۱) فرم به نقطهٔ پایانی اختصاصی /novintech-booking POST می‌شود؛ مسیر
      یک‌بار در جدول مسیریابی ثبت می‌شود (idempotent) و همیشه توسط هسته
      به Widget\Archive سپرده می‌شود → themeInit حتماً اجرا می‌شود و
      پاسخ JSON خالص است؛ مستقل از نوع صفحه و قالب.
   ۲) درخواست‌ها مانند نهال/الناز به‌صورت دیدگاه «در انتظار تأیید» روی یک
      برگهٔ پشتیبان مخفی ذخیره می‌شوند (وضعیت waiting → عمومی نیست؛
      شمارهٔ تلفن در فیلد url ذخیره می‌شود).
   ۳) امنیت: توکن CSRF هسته + تلهٔ هرزنامه + فاصلهٔ ارسال
      (commentsPostInterval) + اعتبارسنجی شمارهٔ ایرانی.
   ۴) مدیریت: برگهٔ مخفی «مدیریت درخواست‌ها» با قالب booking-manage.php
      برای مدیر/سردبیر (تأیید/رد/حذف با AJAX) + همان موارد در پنل
      «دیدگاه‌های در انتظار» مدیریت.
   ============================================================ */

/** خروجی JSON خالص و پایان درخواست (الگو از نهال/الناز) */
function novintech_json(array $payload, int $status = 200): void
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('X-Content-Type-Options: nosniff');
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** نام مسیر نقطهٔ پایانی درخواست مشاوره */
function novintech_booking_route_name(): string
{
    return 'novintech-booking';
}

/** ثبت مسیر /novintech-booking در جدول مسیریابی (یک‌بار — idempotent) */
function novintech_register_booking_route(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    try {
        $options = \Widget\Options::alloc();
        $routingTable = $options->routingTable;

        if (!is_array($routingTable) || !isset($routingTable[novintech_booking_route_name()])) {
            \Utils\Helper::addRoute(
                novintech_booking_route_name(),
                '/' . novintech_booking_route_name(),
                '\Widget\Archive',
                'render'
            );

            // همگام‌سازی جدول مسیرِ درون‌حافظه‌ای (مثل Widget\Init)
            \Typecho\Router::setRoutes($options->routingTable);
        }
    } catch (\Throwable $e) {
        // ثبت نشد؟ فرم به آدرس صفحهٔ جاری POST می‌شود و همان مسیر کار می‌کند
    }
}

/** نشانی نقطهٔ پایانی ثبت درخواست (با جایگزین خانه در نبود مسیر) */
function novintech_booking_endpoint(): string
{
    try {
        $url = \Typecho\Router::url(novintech_booking_route_name(), [], \Widget\Options::alloc()->index);
        if (is_string($url) && $url !== '#' && $url !== '') {
            return $url;
        }
    } catch (\Throwable $e) {
    }
    try {
        return (string)\Widget\Options::alloc()->siteUrl;
    } catch (\Throwable $e) {
        return '/';
    }
}

/** اسلاگ برگهٔ دفتر درخواست‌ها (برگهٔ سیستمی مخفی پوسته) */
function novintech_reserve_slug(): string
{
    return 'novintech-reserve';
}

/** اسلاگ برگهٔ «مدیریت درخواست‌ها» (برگهٔ سیستمی با قالب booking-manage) */
function novintech_manage_slug(): string
{
    return 'novintech-bookings';
}

/** اسلاگ‌های قابل قبول برای برگهٔ دفتر درخواست‌ها (اسلاگ‌های عمومی رایج) */
function novintech_reserve_slug_list(): array
{
    return [novintech_reserve_slug(), 'booking', 'rezerv', 'reserve', 'nobat', 'appointment', 'consult'];
}

/**
 * یافتن شناسهٔ برگهٔ دفتر درخواست‌ها:
 *  ۱) تنظیم سفارشی مدیر (novintechBookingCid)؛
 *  ۲) جست‌وجوی برگه‌هایی با اسلاگ رایج رزرو؛
 *  ۳) ساخت خودکار برگهٔ سیستمی «مخفی» در نخستین نیاز (مثل نهال/الناز).
 */
function novintech_reserve_cid(): int
{
    static $cid = null;
    if ($cid !== null) {
        return $cid;
    }

    try {
        $db = \Typecho\Db::get();

        // ۱) تنظیم سفارشی
        $custom = (int)novintech_opt('novintechBookingCid', '0');
        if ($custom > 0) {
            $row = $db->fetchRow(
                $db->select('cid')->from('table.contents')->where('cid = ?', $custom)->limit(1)
            );
            if ($row) {
                $cid = (int)$row['cid'];
                return $cid;
            }
        }

        // ۲) جست‌وجوی اسلاگ‌های رایج (شامل نسخه‌های قبلی پوسته)
        $row = $db->fetchRow(
            $db->select('cid')->from('table.contents')
                ->where('type = ?', 'page')
                ->where('slug IN ?', novintech_reserve_slug_list())
                ->limit(1)
        );
        if ($row) {
            $cid = (int)$row['cid'];
            return $cid;
        }

        // ۳) ساخت خودکار برگهٔ سیستمی «دفتر درخواست‌ها» — مخفی
        $now = time();
        $adminUid = 1;
        try {
            $user = \Widget\User::alloc();
            if ($user->hasLogin()) {
                $adminUid = (int)$user->uid;
            }
        } catch (\Throwable $e) {
        }

        $text = "<!-- نوین‌تک --> برگهٔ سیستمی پوستهٔ نوین‌تک؛ درخواست‌های «مشاورهٔ رایگان» فرم سایت به‌صورت دیدگاه «در انتظار تأیید» روی همین برگه ذخیره می‌شوند. مشاهده و مدیریت از برگهٔ «مدیریت درخواست‌ها» یا مدیریت ← دیدگاه‌ها. لطفاً این برگه را حذف نکنید.";
        // Db::query برای INSERT شناسهٔ درج‌شده را برمی‌گرداند (متد Db::lastInsertId وجود ندارد)
        $cid = (int)$db->query(
            $db->insert('table.contents')->rows([
                'title'        => 'دفتر درخواست‌های مشاوره',
                'slug'         => novintech_reserve_slug(),
                'created'      => $now,
                'modified'     => $now,
                'text'         => $text,
                'order'        => 9999,
                'authorId'     => $adminUid,
                'template'     => '',
                'type'         => 'page',
                'status'       => 'hidden',
                'password'     => '',
                'commentsNum'  => 0,
                'allowComment' => 1,
                'allowPing'    => 0,
                'allowFeed'    => 0,
                'parent'       => 0,
            ])
        );
        return $cid;
    } catch (\Throwable $e) {
        $cid = 0;
    }
    return 0;
}

/**
 * شناسهٔ برگهٔ «مدیریت درخواست‌ها» — در نبودش خودکار ساخته می‌شود (مخفی).
 * قالب برگه: booking-manage.php (فایل پوسته).
 */
function novintech_manage_cid(): int
{
    static $cid = null;
    if ($cid !== null) {
        return $cid;
    }

    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('cid')->from('table.contents')
                ->where('type = ?', 'page')
                ->where('slug = ?', novintech_manage_slug())
                ->limit(1)
        );
        if ($row) {
            $cid = (int)$row['cid'];
            return $cid;
        }

        $now = time();
        $adminUid = 1;
        try {
            $user = \Widget\User::alloc();
            if ($user->hasLogin()) {
                $adminUid = (int)$user->uid;
            }
        } catch (\Throwable $e) {
        }

        // Db::query برای INSERT شناسهٔ درج‌شده را برمی‌گرداند
        $cid = (int)$db->query(
            $db->insert('table.contents')->rows([
                'title'        => 'مدیریت درخواست‌ها',
                'slug'         => novintech_manage_slug(),
                'created'      => $now,
                'modified'     => $now,
                'text'         => "<!-- نوین‌تک --> برگهٔ سیستمی پوستهٔ نوین‌تک برای مشاهده و مدیریت درخواست‌های «مشاورهٔ رایگان». فقط برای اعضای واردشده (مدیر/سردبیر) قابل استفاده است.",
                'order'        => 9999,
                'authorId'     => $adminUid,
                'template'     => 'booking-manage.php',
                'type'         => 'page',
                'status'       => 'hidden',
                'password'     => '',
                'commentsNum'  => 0,
                'allowComment' => 0,
                'allowPing'    => 0,
                'allowFeed'    => 0,
                'parent'       => 0,
            ])
        );
        return $cid;
    } catch (\Throwable $e) {
        $cid = 0;
    }
    return 0;
}

/** نشانی برگهٔ مدیریت درخواست‌ها (یا '') */
function novintech_manage_url(): string
{
    try {
        $cid = novintech_manage_cid();
        if ($cid < 1) {
            return '';
        }
        $url = \Typecho\Router::url('page', ['slug' => novintech_manage_slug()], \Widget\Options::alloc()->index);
        return ($url === '#') ? '' : (string)$url;
    } catch (\Throwable $e) {
        return '';
    }
}

/** آیا این cid، برگهٔ سیستمی درخواست است؟ (برای حذف از منوها) */
function novintech_is_reserve_cid(int $pageCid): bool
{
    if ($pageCid < 1) {
        return false;
    }
    $custom = (int)novintech_opt('novintechBookingCid', '0');
    if ($custom === $pageCid) {
        return true;
    }
    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('slug')->from('table.contents')->where('cid = ?', $pageCid)->limit(1)
        );
        if ($row && (in_array((string)$row['slug'], novintech_reserve_slug_list(), true)
            || (string)$row['slug'] === novintech_manage_slug())) {
            return true;
        }
    } catch (\Throwable $e) {
    }
    return false;
}

/** آیا کاربر فعلی اجازهٔ مدیریت درخواست‌ها را دارد؟ (مدیر/سردبیر) */
function novintech_can_manage_bookings(): bool
{
    try {
        $user = \Widget\User::alloc();
        return $user->hasLogin() && $user->pass('editor', true);
    } catch (\Throwable $e) {
        return false;
    }
}

/** تعداد درخواست‌های در انتظار بررسی */
function novintech_pending_bookings_count(): int
{
    try {
        $cid = novintech_reserve_cid();
        if ($cid < 1) {
            return 0;
        }
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select(['COUNT(coid)' => 'n'])->from('table.comments')
                ->where('cid = ? AND parent = 0 AND type = ? AND status = ?', $cid, 'comment', 'waiting')
        );
        return (int)($row['n'] ?? 0);
    } catch (\Throwable $e) {
        return 0;
    }
}

/** تبدیل ارقام فارسی/عربی به انگلیسی */
function novintech_to_english_digits(string $s): string
{
    return strtr($s, [
        '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
        '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
        '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
        '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
    ]);
}

/** اعتبارسنجی شمارهٔ تلفن ایرانی: 09xxxxxxxxx / +98… / 0xxxxxxxxx */
function novintech_valid_phone(string $phone): bool
{
    $phone = novintech_to_english_digits(trim($phone));
    $phone = str_replace([' ', '-', '(', ')', "\t"], '', $phone);
    return (bool)preg_match('/^(\+98|98|0098|0)?9\d{9}$/', $phone)
        || (bool)preg_match('/^0\d{9,10}$/', $phone);
}

/**
 * اعتبارسنجی توکن امنیتی CSRF — همان منطق Widget\Security::protect با
 * دو پذیرش جانبی: ارجاع هم‌مبدأ و (در نبود هر دو) ارجاع خالی، تا فرم
 * هرگز برای کاربر واقعی نشکند (الگوی نهال/الناز).
 */
function novintech_booking_token_ok($request): bool
{
    try {
        $security = \Widget\Security::alloc();
        $token = (string)$request->get('_', '');
        $referer = (string)$request->getReferer();

        if ($token !== '') {
            if (hash_equals($security->getToken($referer), $token)) {
                return true;
            }
            if (hash_equals($security->getToken((string)$request->getRequestUrl()), $token)) {
                return true;
            }
        }

        // پذیرش جانبی ۱: ارجاع هم‌مبدأ
        if ($referer !== '') {
            $siteHost = (string)parse_url((string)\Widget\Options::alloc()->siteUrl, PHP_URL_HOST);
            $refHost = (string)parse_url($referer, PHP_URL_HOST);
            if ($siteHost !== '' && strcasecmp($siteHost, $refHost) === 0) {
                return true;
            }
            return false; // ارجاع بیگانه → رد
        }

        // پذیرش جانبی ۲: بدون ارجاع → قبول؛ تله و محدودیت ارسال محافظت می‌کنند
        return true;
    } catch (\Throwable $e) {
        return true;
    }
}

/**
 * پردازش درخواست مشاوره — POST به نقطهٔ پایانی /novintech-booking (یا هر صفحهٔ پوسته).
 *  - پیش‌فرض  : ثبت درخواست جدید (فرم عمومی؛ پارامتر novintechBooking=1)
 *  - mode=approve | reject | delete : مدیریت درخواست (فقط اعضای مجاز)
 */
function novintech_handle_booking($request): void
{
    // ---------- حالت‌های مدیریتی (تأیید/رد/حذف) ----------
    $mode = trim((string)$request->get('mode', ''));
    if (in_array($mode, ['approve', 'reject', 'delete'], true)) {
        novintech_handle_booking_manage($request, $mode);
        return;
    }

    // ---------- توکن امنیتی (CSRF) ----------
    if (!novintech_booking_token_ok($request)) {
        novintech_json(['ok' => false, 'error' => 'درخواست از منبع نامعتبر است؛ صفحه را رفرش کنید و دوباره تلاش کنید.'], 403);
    }

    // ---------- تلهٔ هرزنامه (honeypot باید خالی باشد) ----------
    $hp = trim((string)$request->get('novintechHp', ''));
    if ($hp !== '') {
        novintech_json(['ok' => true, 'stored' => true]); // پاسخ مثبت کاذب برای ربات‌ها
    }

    // ---------- داده‌های فرم (ارقام فارسی → انگلیسی) ----------
    $name    = trim((string)$request->get('novintechName', ''));
    $phone   = novintech_to_english_digits(trim((string)$request->get('novintechPhone', '')));
    $phone   = str_replace([' ', '-', '(', ')', "\t"], '', $phone);
    $mail    = trim((string)$request->get('novintechMail', ''));
    $service = trim((string)$request->get('novintechService', ''));
    $note    = trim((string)$request->get('novintechNote', ''));

    // ---------- اعتبارسنجی ----------
    if (mb_strlen($name) < 2) {
        novintech_json(['ok' => false, 'error' => 'نام را کامل وارد کنید.'], 422);
    }
    if (!novintech_valid_phone($phone)) {
        novintech_json(['ok' => false, 'error' => 'شمارهٔ تلفن معتبر نیست (مثال: ۰۹۱۲۳۴۵۶۷۸۹).'], 422);
    }
    if ($mail !== '' && !filter_var($mail, FILTER_VALIDATE_EMAIL)) {
        novintech_json(['ok' => false, 'error' => 'ایمیل واردشده معتبر نیست.'], 422);
    }

    // برش طولانی‌ها
    $name    = mb_substr($name, 0, 150);
    $mail    = mb_substr($mail, 0, 150);
    $service = mb_substr($service, 0, 150);
    $note    = mb_substr($note, 0, 2000);

    // ---------- ذخیره به‌صورت دیدگاه مخفی روی برگهٔ دفتر درخواست‌ها ----------
    $cid = novintech_reserve_cid();
    if ($cid < 1) {
        novintech_json(['ok' => false, 'error' => 'خطای سرور در ساخت دفتر درخواست‌ها؛ لطفاً چند لحظه بعد دوباره تلاش کنید.'], 500);
    }

    try {
        $options = \Widget\Options::alloc();
        $db = \Typecho\Db::get();

        $ownerRow = $db->fetchRow(
            $db->select('authorId')->from('table.contents')->where('cid = ?', $cid)->limit(1)
        );
        $ownerId = (int)($ownerRow['authorId'] ?? 1);

        /*
         * محدودیت فاصلهٔ ارسال (مثل Widget\Feedback):
         * اگر گزینهٔ commentsPostIntervalEnable فعال باشد و آخرین ارسالِ همین IP
         * روی این برگه کمتر از commentsPostInterval ثانیه پیش بوده باشد، رد می‌شود.
         */
        $intervalBlocked = false;
        try {
            if (!\Widget\User::alloc()->pass('editor', true) && $options->commentsPostIntervalEnable) {
                $latest = $db->fetchRow(
                    $db->select('created')->from('table.comments')
                        ->where('cid = ? AND ip = ?', $cid, $request->getIp())
                        ->order('created', \Typecho\Db::SORT_DESC)
                        ->limit(1)
                );
                if ($latest && (int)$options->time - (int)$latest['created'] >= 0
                    && (int)$options->time - (int)$latest['created'] < (int)$options->commentsPostInterval) {
                    $intervalBlocked = true;
                }
            }
        } catch (\Throwable $e) {
        }
        if ($intervalBlocked) {
            novintech_json(['ok' => false, 'error' => 'ارسال‌ها بیش از حد نزدیک است؛ چند دقیقه بعد دوباره تلاش کنید.'], 429);
        }

        // متن خوانا برای پنل مدیریت (نمایش عمومی ندارد)
        $lines = ['[درخواست مشاورهٔ رایگان]'];
        $lines[] = 'نام: ' . $name;
        $lines[] = 'تلفن: ' . $phone;
        if ($mail !== '') {
            $lines[] = 'ایمیل: ' . $mail;
        }
        if ($service !== '') {
            $lines[] = 'نوع خدمت: ' . $service;
        }
        if ($note !== '') {
            $lines[] = 'توضیحات: ' . $note;
        }

        // ثبت (شمارهٔ تلفن در فیلد url — الگوی نهال/الناز)
        $coid = (int)$db->query(
            $db->insert('table.comments')->rows([
                'cid'      => $cid,
                'created'  => (int)$options->time,
                'author'   => $name,
                'authorId' => 0,
                'ownerId'  => $ownerId,
                'mail'     => $mail,
                'url'      => $phone,
                'ip'       => substr((string)$request->getIp(), 0, 64),
                'agent'    => substr((string)$request->getAgent(), 0, 511),
                'text'     => implode("\n", $lines),
                'type'     => 'comment',
                'status'   => 'waiting', // هرگز عمومی نمی‌شود؛ فقط پنل مدیریت و برگهٔ مدیریت درخواست‌ها
                'parent'   => 0,
            ])
        );

        // شمارندهٔ دیدگاه‌های برگه (برای پنل مدیریت درست باشد)
        try {
            $db->query(
                $db->update('table.contents')
                    ->expression('commentsNum', 'commentsNum + 1')
                    ->where('cid = ?', $cid)
            );
        } catch (\Throwable $e) {
        }

        // اطلاع‌رسانی ایمیلی مدیر (در صورت پیکربندی ایمیل در تایپ‌رینیو)
        try {
            $nvtAdminMail = trim((string)($options->mailFrom ?? $options->mailSmtpUser ?? ''));
            if ($nvtAdminMail === '') {
                $nvtAdminMail = trim((string)($options->adminMail ?? ''));
            }
            if ($nvtAdminMail !== '' && filter_var($nvtAdminMail, FILTER_VALIDATE_EMAIL)
                && class_exists('\Typecho\Mail\Message') && class_exists('\Typecho\Mail\Queue')) {
                $manageUrl = novintech_manage_url();
                $nvtMailText = implode("\n", $lines)
                    . ($manageUrl !== '' ? "\n\nمشاهده و مدیریت:\n" . $manageUrl : '');
                $nvtMailHtml = '<div style="font-family:Tahoma,Arial,sans-serif;direction:rtl;text-align:right;line-height:2">'
                    . nl2br(htmlspecialchars($nvtMailText, ENT_QUOTES, 'UTF-8')) . '</div>';
                $nvtMessage = new \Typecho\Mail\Message(
                    $nvtAdminMail,
                    'درخواست مشاورهٔ رایگان جدید — ' . $name,
                    $nvtMailHtml,
                    $nvtAdminMail,
                    (string)($options->mailFromName ?? $options->title ?? 'نوین‌تک'),
                    'مدیر سایت',
                    $nvtMailText
                );
                \Typecho\Mail\Queue::enqueue('booking', $nvtMessage, $db, $options);
            }
        } catch (\Throwable $e) {
            // ایمیل اختیاری است؛ نبود آن خطا محسوب نمی‌شود
        }

        novintech_json([
            'ok'     => true,
            'stored' => true,
            'coid'   => $coid,
        ]);
    } catch (\Throwable $e) {
        try {
            error_log('[novintech] booking save failed: ' . $e->getMessage()
                . ' @ ' . $e->getFile() . ':' . $e->getLine());
        } catch (\Throwable $e2) {
        }
        novintech_json(['ok' => false, 'error' => 'خطای سرور در ذخیرهٔ درخواست؛ لطفاً دوباره تلاش کنید.'], 500);
    }
}

/**
 * حالت‌های مدیریتی درخواست (تأیید/رد/حذف) — فقط اعضای مجاز (مدیر/سردبیر).
 * coid باید متعلق به برگهٔ دفتر درخواست‌ها باشد.
 */
function novintech_handle_booking_manage($request, string $mode): void
{
    if (!novintech_can_manage_bookings()) {
        novintech_json(['ok' => false, 'error' => 'برای مدیریت درخواست‌ها باید با حساب مدیر وارد شوید.'], 403);
    }

    // توکن امنیتی
    if (!novintech_booking_token_ok($request)) {
        novintech_json(['ok' => false, 'error' => 'توکن امنیتی نامعتبر است؛ صفحه را رفرش کنید.'], 403);
    }

    $coid = (int)(string)$request->get('coid', '0');
    if ($coid < 1) {
        novintech_json(['ok' => false, 'error' => 'شناسهٔ درخواست نامعتبر است.'], 400);
    }

    try {
        $cid = novintech_reserve_cid();
        if ($cid < 1) {
            novintech_json(['ok' => false, 'error' => 'دفتر درخواست‌ها یافت نشد.'], 500);
        }
        $db = \Typecho\Db::get();

        // فقط درخواست‌های همین دفتر
        $row = $db->fetchRow(
            $db->select('coid, status')->from('table.comments')
                ->where('coid = ? AND cid = ? AND parent = 0 AND type = ?', $coid, $cid, 'comment')
                ->limit(1)
        );
        if (!$row) {
            novintech_json(['ok' => false, 'error' => 'درخواستی با این شناسه یافت نشد.'], 404);
        }

        if ($mode === 'delete') {
            $db->query(
                $db->delete('table.comments')->where('coid = ? AND cid = ?', $coid, $cid)
            );
            try {
                $db->query(
                    $db->update('table.contents')
                        ->expression('commentsNum', 'GREATEST(commentsNum - 1, 0)')
                        ->where('cid = ?', $cid)
                );
            } catch (\Throwable $e) {
            }
        } else {
            $status = ($mode === 'approve') ? 'approved' : 'spam';
            $db->query(
                $db->update('table.comments')
                    ->rows(['status' => $status])
                    ->where('coid = ? AND cid = ?', $coid, $cid)
            );
        }

        novintech_json([
            'ok'         => true,
            'mode'       => $mode,
            'coid'       => $coid,
            'status'     => ($mode === 'delete') ? 'deleted' : (($mode === 'approve') ? 'approved' : 'spam'),
            'pending'    => novintech_pending_bookings_count(),
        ]);
    } catch (\Throwable $e) {
        novintech_json(['ok' => false, 'error' => 'خطای سرور در به‌روزرسانی درخواست.'], 500);
    }
}

/**
 * فهرست درخواست‌ها برای برگهٔ «مدیریت درخواست‌ها».
 * ترتیب: در انتظار اول، سپس تأییدشده‌ها و ردشده‌ها (جدید به قدیم).
 */
function novintech_bookings_list(int $limit = 200): array
{
    try {
        $cid = novintech_reserve_cid();
        if ($cid < 1) {
            return [];
        }
        $db = \Typecho\Db::get();
        $rows = $db->fetchAll(
            $db->select('coid', 'created', 'author', 'mail', 'url', 'ip', 'text', 'status')
                ->from('table.comments')
                ->where('cid = ? AND parent = 0 AND type = ?', $cid, 'comment')
                ->order('created', \Typecho\Db::SORT_DESC)
                ->limit($limit)
        );

        // waiting اول، سپس approved، سپس spam — هر کدام جدید به قدیم
        $order = ['waiting' => 0, 'approved' => 1, 'spam' => 2];
        usort($rows, function ($a, $b) use ($order) {
            $ka = $order[$a['status']] ?? 3;
            $kb = $order[$b['status']] ?? 3;
            if ($ka !== $kb) {
                return $ka <=> $kb;
            }
            return (int)$b['created'] <=> (int)$a['created'];
        });

        foreach ($rows as &$r) {
            $r = array_merge($r, novintech_parse_booking_text((string)$r['text']));
        }
        unset($r);

        return $rows;
    } catch (\Throwable $e) {
        return [];
    }
}

/**
 * پارس متن خوانای درخواست به فیلدهای ساختاریافته برای برگهٔ مدیریت.
 * (قالب متن را خودمان در novintech_handle_booking می‌نویسیم؛ پس پارس قطعی است.)
 */
function novintech_parse_booking_text(string $text): array
{
    $out = [
        'phone'   => '',
        'mail'    => '',
        'service' => '',
        'note'    => '',
    ];

    foreach (preg_split('/\r\n|\r|\n/', $text) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '[') {
            continue;
        }
        $pos = strpos($line, ':');
        if ($pos === false) {
            continue;
        }
        $key = trim(substr($line, 0, $pos));
        $val = trim(substr($line, $pos + 1));
        switch ($key) {
            case 'تلفن':
                $out['phone'] = $val;
                break;
            case 'ایمیل':
                $out['mail'] = $val;
                break;
            case 'نوع خدمت':
                $out['service'] = $val;
                break;
            case 'توضیحات':
                $out['note'] = $val;
                break;
        }
    }
    return $out;
}

// ثبت مسیر اختصاصی درخواست‌ها (یک‌بار؛ idempotent) — باید پیش از رندر فرم اجرا شود
novintech_register_booking_route();

/**
 * Theme Init
 *
 * ۱) نقطهٔ پایانی AJAX درخواست مشاوره (/novintech-booking و پشتیبانِ
 *    POST روی هر صفحهٔ پوسته) — الگوی نهال/الناز.
 * ۲) فهرست وبلاگ روی مسیر آرشیو (پیش‌فرض /blog/): هستهٔ تایپ‌رینیو وقتی
 *    «صفحهٔ نخست» روی نوشته‌های اخیر باشد (حالت پیش‌فرض)، مسیر archive را
 *    با ۴۰۴ می‌بندد (archiveEmptyHandle). نوع درخواست را به index تبدیل
 *    می‌کنیم تا فهرست مقالات همیشه در /blog/ رندر شود.
 */
function themeInit($archive)
{
    try {
        \Closure::bind(function () {
            /** @var \Widget\Archive $this */

            // نقطهٔ پایانی AJAX درخواست مشاورهٔ رایگان
            if ($this->request->isPost() && (string)$this->request->get('novintechBooking', '') !== '') {
                novintech_handle_booking($this->request);
            }

            // درخواست غیر-POST روی نقطهٔ پایانی اختصاصی → 405 (فقط برای POST است)
            if ((string)$this->request->getPathInfo() === '/' . novintech_booking_route_name()) {
                if (!$this->request->isPost()) {
                    novintech_json(['ok' => false, 'error' => 'این نقطهٔ پایانی فقط برای ثبت درخواست مشاوره است.'], 405);
                }
            }

            $nvtRouteType = (string)$this->parameter->type;
            if ($nvtRouteType === 'archive' || $nvtRouteType === 'archive_page') {
                $nvtFrontPage = 'recent';
                $nvtFrontArchive = 0;
                try {
                    $nvtFrontPage = (string)\Widget\Options::alloc()->frontPage;
                    $nvtFrontArchive = (int)\Widget\Options::alloc()->frontArchive;
                } catch (\Throwable $e) {
                }
                if ($nvtFrontPage === 'recent' || $nvtFrontArchive !== 1) {
                    $this->parameter->type = ($nvtRouteType === 'archive_page') ? 'index_page' : 'index';
                }
            }
        }, $archive, \Typecho\Widget::class)();
    } catch (\Throwable $e) {
    }
}

/**
 * Get Gravatar URL with Image Tag
 */
function getAvatar($email, $size = 40)
{
    $hash = md5(strtolower(trim($email)));
    $url = "https://www.gravatar.com/avatar/{$hash}?s={$size}&d=mp&r=g";
    return '<img src="' . $url . '" alt="Avatar" width="' . $size . '" height="' . $size . '" style="border-radius: 50%;">';
}

/* ============================================================
   شمارش بازدید — سازگار با MySQL و SQLite و PgSQL
   ============================================================ */

/**
 * Get Post Views Count (MySQL / SQLite / PgSQL Compatible)
 */
function PostViews($archive)
{
    $cid = $archive->cid;
    if (empty($cid)) {
        return '۰';
    }

    try {
        $db = Typecho_Db::get();
        $prefix = $db->getPrefix();
        $tableName = $prefix . 'post_views';

        $views = null;

        // ابتدا سعی در خواندن؛ اگر جدول وجود نداشت می‌سازیم (پرتاب استثنا = نبود جدول)
        try {
            $row = $db->fetchRow($db->select('views')->from('table.post_views')->where('cid = ?', $cid));
            $views = empty($row) ? 0 : (int)$row['views'];
        } catch (\Throwable $e) {
            // ساخت جدول بر اساس نوع پیوند پایگاه داده
            $adapterName = '';
            try {
                $adapterName = strtolower((string)$db->getAdapterName());
            } catch (\Throwable $ignore) {
            }

            if (false !== strpos($adapterName, 'sqlite')) {
                $db->query("CREATE TABLE IF NOT EXISTS {$tableName} (cid INTEGER PRIMARY KEY, views INTEGER DEFAULT 0)");
            } elseif (false !== strpos($adapterName, 'pgsql') || false !== strpos($adapterName, 'postgres')) {
                $db->query("CREATE TABLE IF NOT EXISTS {$tableName} (cid INTEGER PRIMARY KEY, views INTEGER DEFAULT 0)");
            } else {
                $db->query("CREATE TABLE IF NOT EXISTS {$tableName} (cid INT UNSIGNED NOT NULL PRIMARY KEY, views INT UNSIGNED NOT NULL DEFAULT 0)");
            }
            $views = 0;
        }

        if ($views === 0) {
            try {
                $db->query($db->insert('table.post_views')->rows(array('cid' => $cid, 'views' => 0)));
            } catch (\Throwable $e) {
                // ردیف قبلاً وجود دارد
            }
        }

        if ($archive->is('single')) {
            $views++;
            $db->query($db->update('table.post_views')->rows(array('views' => $views))->where('cid = ?', $cid));
        }

        return novintech_fa_digits(number_format($views));
    } catch (\Throwable $e) {
        return '۰';
    }
}

/**
 * Get Related Posts
 */
function getRelatedPosts($archive, $limit = 3)
{
    try {
        $cid = $archive->cid;
        $tags = $archive->tags;

        if (empty($tags) || !is_array($tags)) {
            return array();
        }

        $tagIds = array();
        foreach ($tags as $tag) {
            if (isset($tag['mid'])) {
                $tagIds[] = $tag['mid'];
            }
        }

        if (empty($tagIds)) {
            return array();
        }

        $db = Typecho_Db::get();
        $prefix = $db->getPrefix();

        $relatedPosts = $db->fetchAll(
            $db->select()->from('table.contents')
                ->join($prefix . 'relationships', $prefix . 'contents.cid = ' . $prefix . 'relationships.cid')
                ->where($prefix . 'relationships.mid IN ?', $tagIds)
                ->where('table.contents.cid <> ?', $cid)
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.type = ?', 'post')
                ->order('table.contents.created', Typecho_Db::SORT_DESC)
                ->limit($limit)
        );

        return $relatedPosts;
    } catch (\Throwable $e) {
        return array();
    }
}

/**
 * Parse Map Coordinates
 */
function parseMapCoordinates($coordinates)
{
    if (empty($coordinates)) {
        return null;
    }

    $parts = array_map('trim', explode(',', $coordinates));
    if (count($parts) == 2) {
        return array(
            'lat' => floatval($parts[0]),
            'lng' => floatval($parts[1])
        );
    }
    return null;
}

/**
 * Jalali Date Function
 */
function jdate($format, $timestamp = null)
{
    if ($timestamp === null) {
        $timestamp = time();
    }

    $g_d = date('d', $timestamp);
    $g_m = date('m', $timestamp);
    $g_y = date('Y', $timestamp);

    $g_days_in_month = array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
    $j_days_in_month = array(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29);

    $gy = $g_y - 1600;
    $gm = $g_m - 1;
    $gd = $g_d - 1;

    $g_day_no = 365 * $gy + floor(($gy + 3) / 4) - floor(($gy + 99) / 100) + floor(($gy + 399) / 400);

    for ($i = 0; $i < $gm; ++$i)
        $g_day_no += $g_days_in_month[$i];
    if ($gm > 1 && (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0)))
        ++$g_day_no;
    $g_day_no += $gd;

    $j_day_no = $g_day_no - 79;

    $j_np = floor($j_day_no / 12053);
    $j_day_no %= 12053;

    $jy = 979 + 33 * $j_np + 4 * floor($j_day_no / 1461);
    $j_day_no %= 1461;

    if ($j_day_no >= 366) {
        $jy += floor(($j_day_no - 1) / 365);
        $j_day_no = ($j_day_no - 1) % 365;
    }

    for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i)
        $j_day_no -= $j_days_in_month[$i];
    $jm = $i + 1;
    $jd = $j_day_no + 1;

    $j_months = array(
        'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
    );

    $j_days = array(
        'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'
    );

    $output = $format;
    $output = str_replace('Y', $jy, $output);
    $output = str_replace('y', substr((string)$jy, 2), $output);
    $output = str_replace('F', $j_months[$jm - 1], $output);
    $output = str_replace('m', str_pad((string)$jm, 2, '0', STR_PAD_LEFT), $output);
    $output = str_replace('n', $jm, $output);
    $output = str_replace('d', str_pad((string)$jd, 2, '0', STR_PAD_LEFT), $output);
    $output = str_replace('j', $jd, $output);
    $output = str_replace('l', $j_days[date('w', $timestamp)], $output);
    $output = str_replace('H', date('H', $timestamp), $output);
    $output = str_replace('i', date('i', $timestamp), $output);

    return novintech_fa_digits($output);
}
