<?php
/**
 * Page Template - Single Page
 *
 * @package NovinTech Theme
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');
?>

<article class="single-page">
    <!-- Page Header -->
    <header class="post-header">
        <div class="container">
            <div class="post-header-inner">
                <div class="post-meta-top">
                    <span class="post-category">صفحه</span>
                </div>
                <h1 class="post-title"><?php $this->title(); ?></h1>
                <?php if($this->fields->subtitle): ?>
                <p class="archive-description"><?php echo $this->fields->subtitle; ?></p>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <!-- Page Thumbnail — فیلد thumb (جدید) یا thumbnail (قدیمی) -->
    <?php $nvtPageThumb = novintech_thumb($this); ?>
    <?php if($nvtPageThumb !== ''): ?>
    <div class="post-thumbnail">
        <div class="container">
            <img src="<?php echo htmlspecialchars($nvtPageThumb, ENT_QUOTES); ?>" alt="<?php $this->title(); ?>">
        </div>
    </div>
    <?php endif; ?>

    <!-- Page Content -->
    <div class="post-content">
        <div class="container">
            <div class="post-body page-body">
                <?php $this->content(); ?>
            </div>
        </div>
    </div>

    <!-- Comments -->
    <?php if($this->allow('comment')): ?>
    <div class="page-comments">
        <div class="container">
            <?php $this->need('comments.php'); ?>
        </div>
    </div>
    <?php endif; ?>
</article>

<?php $this->need('footer.php'); ?>
