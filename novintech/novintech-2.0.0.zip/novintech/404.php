<?php
/**
 * 404 Page Template
 *
 * @package NovinTech Theme
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$nvtHome = rtrim((string)$this->options->siteUrl, '/') . '/';
$nvtBlog = novintech_blog_url();
$this->need('header.php');
?>

<section class="error-section">
    <div class="container">
        <div class="error-content">
            <div class="error-illustration">
                <svg viewBox="0 0 400 300" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <!-- Background shapes -->
                    <circle cx="200" cy="150" r="120" fill="#EFF6FF" opacity="0.5"/>
                    <circle cx="200" cy="150" r="80" fill="#DBEAFE"/>

                    <!-- 404 Text -->
                    <text x="200" y="170" text-anchor="middle" font-size="72" font-weight="bold" fill="#2563EB">404</text>

                    <!-- Decorative elements -->
                    <circle cx="80" cy="80" r="20" fill="#93C5FD"/>
                    <circle cx="320" cy="220" r="15" fill="#93C5FD"/>
                    <circle cx="340" cy="100" r="10" fill="#BFDBFE"/>
                    <circle cx="60" cy="200" r="12" fill="#BFDBFE"/>

                    <!-- Sad face -->
                    <circle cx="175" cy="210" r="8" fill="#3B82F6"/>
                    <circle cx="225" cy="210" r="8" fill="#3B82F6"/>
                    <path d="M170 250 Q200 230 230 250" stroke="#3B82F6" stroke-width="4" fill="none" stroke-linecap="round"/>
                </svg>
            </div>

            <h1 class="error-title">صفحه مورد نظر یافت نشد!</h1>
            <p class="error-description">
                متأسفانه صفحه‌ای که به دنبال آن هستید وجود ندارد یا حذف شده است.
                <br>
                می‌توانید به صفحه اصلی برگردید یا از منوی سایت استفاده کنید.
            </p>

            <div class="error-actions">
                <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-primary btn-lg">
                    <?php echo novintech_icon('home', 17); ?>
                    بازگشت به صفحه اصلی
                </a>
                <a href="<?php echo htmlspecialchars($nvtHome . '#contact', ENT_QUOTES); ?>" class="btn btn-outline btn-lg">
                    <?php echo novintech_icon('mail', 17); ?>
                    تماس با ما
                </a>
            </div>

            <div class="error-suggestions">
                <h3>شاید به دنبال این‌ها باشید:</h3>
                <ul>
                    <li>
                        <a href="<?php $this->options->siteUrl(); ?>">
                            <?php echo novintech_icon('chevron-left', 16); ?>
                            صفحه اصلی
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo htmlspecialchars($nvtBlog, ENT_QUOTES); ?>">
                            <?php echo novintech_icon('chevron-left', 16); ?>
                            وبلاگ
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo htmlspecialchars($nvtHome . '#services', ENT_QUOTES); ?>">
                            <?php echo novintech_icon('chevron-left', 16); ?>
                            خدمات
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo htmlspecialchars($nvtHome . '#about', ENT_QUOTES); ?>">
                            <?php echo novintech_icon('chevron-left', 16); ?>
                            درباره ما
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>

<style>
.error-section {
    min-height: 80vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 80px 0;
}

.error-content {
    text-align: center;
    max-width: 600px;
    margin: 0 auto;
}

.error-illustration {
    max-width: 400px;
    margin: 0 auto 40px;
}

.error-title {
    font-size: 2rem;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 16px;
}

.error-description {
    font-size: 1.125rem;
    color: var(--text-secondary);
    line-height: 1.8;
    margin-bottom: 32px;
}

.error-actions {
    display: flex;
    gap: 16px;
    justify-content: center;
    flex-wrap: wrap;
    margin-bottom: 48px;
}

.error-suggestions {
    background: var(--bg-secondary);
    border-radius: 12px;
    padding: 24px;
}

.error-suggestions h3 {
    font-size: 1rem;
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 16px;
}

.error-suggestions ul {
    list-style: none;
    padding: 0;
    margin: 0;
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 8px;
}

.error-suggestions a {
    display: flex;
    align-items: center;
    gap: 8px;
    color: var(--primary);
    text-decoration: none;
    padding: 8px 12px;
    border-radius: 6px;
    transition: background 0.2s;
}

.error-suggestions a:hover {
    background: var(--bg-primary);
}

.error-suggestions svg {
    width: 16px;
    height: 16px;
}
</style>

<?php $this->need('footer.php'); ?>
