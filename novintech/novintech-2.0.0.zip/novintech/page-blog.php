<?php
/**
 * آرشیو وبلاگ به‌عنوان قالب اختصاصی صفحه — نسخهٔ بازنویسی‌شده و پایدار
 * جستجو به مسیر استاندارد جستجوی هسته هدایت می‌شود و صفحه‌بندی با
 * پارامترهای واقعی Widget_Archive کار می‌کند (بدون متدهای ناموجود).
 *
 * @package custom
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/* ---------- هدایت جستجو به مسیر استاندارد هسته ---------- */
$nvtSearchKey = trim((string)$this->request->get('s', ''));
if ($nvtSearchKey !== '') {
    try {
        $this->response->redirect(
            \Typecho\Router::url('search', array('keywords' => urlencode($nvtSearchKey)), $this->options->index)
        );
    } catch (\Throwable $e) {
        // در نبود مسیریاب، ادامهٔ رندر با نتایج خالی
    }
    return;
}

$this->need('header.php');

/* ---------- ساخت ویجت آرشیو با پارامترهای صحیح ---------- */
$nvtPageSize = max(1, (int)$this->options->pageSize);
$nvtFrontPage = (string)$this->options->frontPage;

// اگر صفحهٔ نخست سایت «مطالب اخیر» است type=index درست است؛
// در غیر این صورت مسیر آرشیو هسته را شبیه‌سازی می‌کنیم (type=archive)
$nvtBlogType = ('recent' === $nvtFrontPage || 0 === strpos($nvtFrontPage, 'file:')) ? 'index' : 'archive';

$nvtBlog = null;
try {
    $nvtBlog = $this->widget('Widget_Archive@novintechblog', 'type=' . $nvtBlogType . '&pageSize=' . $nvtPageSize);
} catch (\Throwable $e) {
    $nvtBlog = null;
}

$nvtHave = false;
$nvtTotal = 0;
$nvtCurrentPage = 1;
if ($nvtBlog !== null) {
    try {
        $nvtHave = $nvtBlog->have();
        $nvtTotal = (int)$nvtBlog->getTotal();
        $nvtCurrentPage = max(1, (int)$nvtBlog->getCurrentPage());
    } catch (\Throwable $e) {
        $nvtHave = false;
        $nvtTotal = 0;
    }
}
?>

<header class="post-header">
    <div class="container">
        <div class="post-header-inner">
            <div class="post-meta-top">
                <span class="post-category">وبلاگ</span>
            </div>
            <h1 class="post-title">آرشیو وبلاگ</h1>
            <p class="archive-description">همه نوشته‌ها و مقالات</p>
        </div>
    </div>
</header>

<section class="archive-section">
    <div class="container">

        <!-- فرم جستجو (به مسیر جستجوی استاندارد هدایت می‌شود) -->
        <div class="archive-search-box">
            <form method="get" action="<?php $this->options->siteUrl(); ?>" class="archive-search-form">
                <input type="text" name="s" placeholder="جستجو در مطالب..." class="archive-search-input">
                <button type="submit" class="archive-search-btn">
                    <?php echo novintech_icon('search', 16); ?>
                    <span>جستجو</span>
                </button>
            </form>
        </div>

        <?php if ($nvtHave): ?>
        <div class="blog-grid">
            <?php while ($nvtBlog->next()): ?>
            <article class="blog-card">
                <div class="blog-image">
                    <?php $nvtThumb = novintech_thumb($nvtBlog); ?>
                    <?php if ($nvtThumb !== ''): ?>
                        <img src="<?php echo htmlspecialchars($nvtThumb, ENT_QUOTES); ?>" alt="<?php $nvtBlog->title(); ?>">
                    <?php else: ?>
                        <div class="blog-image-placeholder">
                            <?php echo novintech_icon('doc', 30); ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="blog-content">
                    <div class="blog-meta">
                        <span class="blog-category"><?php $nvtBlog->category(',', false); ?></span>
                        <span class="blog-date">
                            <?php echo novintech_icon('calendar', 14); ?>
                            <?php echo jdate('j F Y', $nvtBlog->created); ?>
                        </span>
                    </div>
                    <h3 class="blog-title">
                        <a href="<?php $nvtBlog->permalink(); ?>"><?php $nvtBlog->title(); ?></a>
                    </h3>
                    <p class="blog-excerpt"><?php $nvtBlog->excerpt(100, '...'); ?></p>
                    <a href="<?php $nvtBlog->permalink(); ?>" class="blog-link">
                        ادامه مطلب
                        <?php echo novintech_icon('arrow', 15); ?>
                    </a>
                </div>
            </article>
            <?php endwhile; ?>
        </div>

        <!-- صفحه‌بندی فارسی (الگوی الناز) -->
        <?php novintech_page_nav($nvtBlog); ?>

        <?php else: ?>
        <div class="no-results">
            <div class="no-results-icon">
                <?php echo novintech_icon('search', 34); ?>
            </div>
            <h2 class="no-results-title">مطلبی یافت نشد</h2>
            <p class="no-results-text">هنوز مطلبی در وبلاگ ثبت نشده است.</p>
            <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-primary">بازگشت به صفحه اصلی</a>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php $this->need('footer.php'); ?>
