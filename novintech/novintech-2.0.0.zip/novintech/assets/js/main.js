/**
 * NovinTech Theme - Main JavaScript
 *
 * @package NovinTech Theme
 * @version 1.0.0
 */

(function() {
    'use strict';

    // ========================================
    // DOM Elements
    // ========================================
    const header = document.getElementById('site-header');
    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
    const mobileNav = document.getElementById('mobile-nav');
    const mobileNavClose = document.getElementById('mobile-nav-close');
    const backToTop = document.getElementById('back-to-top');
    const mobileNavLinks = document.querySelectorAll('.mobile-nav-menu a');

    // ========================================
    // Header Scroll Effect
    // ========================================
    function handleHeaderScroll() {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    }

    window.addEventListener('scroll', handleHeaderScroll);
    handleHeaderScroll(); // Initial check

    // ========================================
    // Mobile Menu
    // ========================================
    if (mobileMenuToggle && mobileNav) {
        // Open menu
        mobileMenuToggle.addEventListener('click', function() {
            mobileNav.classList.add('open');
            document.body.style.overflow = 'hidden';
        });

        // Close menu
        if (mobileNavClose) {
            mobileNavClose.addEventListener('click', function() {
                mobileNav.classList.remove('open');
                document.body.style.overflow = '';
            });
        }

        // Close menu when clicking a link
        mobileNavLinks.forEach(function(link) {
            link.addEventListener('click', function() {
                mobileNav.classList.remove('open');
                document.body.style.overflow = '';
            });
        });

        // Close menu when clicking outside
        document.addEventListener('click', function(e) {
            if (mobileNav.classList.contains('open') &&
                !mobileNav.contains(e.target) &&
                !mobileMenuToggle.contains(e.target)) {
                mobileNav.classList.remove('open');
                document.body.style.overflow = '';
            }
        });
    }

    // ========================================
    // Back to Top Button
    // ========================================
    if (backToTop) {
        function handleBackToTopVisibility() {
            if (window.scrollY > 300) {
                backToTop.classList.add('visible');
            } else {
                backToTop.classList.remove('visible');
            }
        }

        window.addEventListener('scroll', handleBackToTopVisibility);
        handleBackToTopVisibility();

        backToTop.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // ========================================
    // Smooth Scroll for Anchor Links
    // ========================================
    document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');

            if (href === '#') return;

            const target = document.querySelector(href);

            if (target) {
                e.preventDefault();

                const headerHeight = header ? header.offsetHeight : 0;
                const targetPosition = target.getBoundingClientRect().top + window.scrollY - headerHeight;

                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // ========================================
    // Scroll Reveal Animation
    // ========================================
    function revealOnScroll() {
        const reveals = document.querySelectorAll('.reveal');
        const windowHeight = window.innerHeight;

        reveals.forEach(function(element) {
            const elementTop = element.getBoundingClientRect().top;
            const revealPoint = 150;

            if (elementTop < windowHeight - revealPoint) {
                element.classList.add('active');
            }
        });
    }

    window.addEventListener('scroll', revealOnScroll);
    revealOnScroll(); // Initial check

    // ========================================
    // Copy Link Function
    // ========================================
    window.copyToClipboard = function(text) {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(function() {
                showNotification('لینک کپی شد!');
            }).catch(function(err) {
                fallbackCopy(text);
            });
        } else {
            fallbackCopy(text);
        }
    };

    function fallbackCopy(text) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();

        try {
            document.execCommand('copy');
            showNotification('لینک کپی شد!');
        } catch (err) {
            showNotification('خطا در کپی کردن', 'error');
        }

        document.body.removeChild(textArea);
    }

    // ========================================
    // Notification System
    // ========================================
    function showNotification(message, type = 'success') {
        // Remove existing notification
        const existingNotification = document.querySelector('.notification');
        if (existingNotification) {
            existingNotification.remove();
        }

        // Create notification
        const notification = document.createElement('div');
        notification.className = 'notification notification-' + type;
        notification.innerHTML = '<span>' + message + '</span>';

        // Style the notification
        notification.style.cssText = [
            'position: fixed',
            'bottom: 20px',
            'right: 20px',
            'padding: 12px 24px',
            'background: ' + (type === 'error' ? '#ef4444' : '#22c55e'),
            'color: white',
            'border-radius: 8px',
            'box-shadow: 0 4px 12px rgba(0,0,0,0.15)',
            'z-index: 9999',
            'animation: slideIn 0.3s ease'
        ].join(';');

        document.body.appendChild(notification);

        // Remove after 3 seconds
        setTimeout(function() {
            notification.style.animation = 'slideOut 0.3s ease forwards';
            setTimeout(function() {
                notification.remove();
            }, 300);
        }, 3000);
    }

    // Add notification animations
    const style = document.createElement('style');
    style.textContent = [
        '@keyframes slideIn {',
        '  from { transform: translateX(100%); opacity: 0; }',
        '  to { transform: translateX(0); opacity: 1; }',
        '}',
        '@keyframes slideOut {',
        '  from { transform: translateX(0); opacity: 1; }',
        '  to { transform: translateX(100%); opacity: 0; }',
        '}'
    ].join('\n');
    document.head.appendChild(style);

    // ========================================
    // Image Lazy Loading
    // ========================================
    if ('IntersectionObserver' in window) {
        const lazyImages = document.querySelectorAll('img[data-src]');

        const imageObserver = new IntersectionObserver(function(entries, observer) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                    observer.unobserve(img);
                }
            });
        }, {
            rootMargin: '50px 0px'
        });

        lazyImages.forEach(function(img) {
            imageObserver.observe(img);
        });
    }

    // ========================================
    // Booking Form — درخواست مشاورهٔ رایگان
    // AJAX به نقطهٔ پایانی اختصاصی /novintech-booking
    // (الگوی نهال/الناز؛ توکن _ و تلهٔ هرزنامه همراه فرم ارسال می‌شود)
    // ========================================
    function enNum(s) {
        return String(s)
            .replace(/[۰-۹]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); })
            .replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); });
    }

    function initBooking() {
        var form = document.getElementById('bookingForm');
        if (!form) { return; }

        var submitBtn = document.getElementById('bookingSubmitBtn');
        var successEl = document.getElementById('bookingSuccess');
        var errorEl = document.getElementById('bookingError');
        var errorText = document.getElementById('bookingErrorText');

        function showMsg(el, textEl, msg) {
            if (el) { el.hidden = false; }
            if (textEl && typeof msg === 'string' && msg !== '') { textEl.textContent = msg; }
            if (el) {
                try { el.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) { }
            }
        }

        form.addEventListener('submit', function (e) {
            e.preventDefault();

            // مخفی‌کردن پیام‌های قبلی
            if (successEl) { successEl.hidden = true; }
            if (errorEl) { errorEl.hidden = true; }

            // اعتبارسنجی سمت کلاینت
            var name = (form.querySelector('#novintechName') || {}).value || '';
            var phone = enNum(String((form.querySelector('#novintechPhone') || {}).value || ''))
                .replace(/[\s\-()]/g, '');

            if (name.trim().length < 2) {
                showMsg(errorEl, errorText, 'لطفاً نام خود را کامل وارد کنید.');
                return;
            }
            if (!/^(\+98|98|0098|0)?9\d{9}$/.test(phone) && !/^0\d{9,10}$/.test(phone)) {
                showMsg(errorEl, errorText, 'شمارهٔ تلفن معتبر نیست (مثال: ۰۹۱۲۳۴۵۶۷۸۹).');
                return;
            }

            // حالت بارگذاری
            if (submitBtn) {
                submitBtn.setAttribute('disabled', 'disabled');
            }

            // گردآوری همهٔ فیلدهای فرم (شامل توکن _ و تلهٔ هرزنامه)
            var body = new URLSearchParams();
            Array.prototype.forEach.call(form.elements, function (el) {
                if (!el.name || el.disabled) { return; }
                var tag = (el.tagName || '').toLowerCase();
                if (tag === 'select') {
                    body.append(el.name, el.value || '');
                } else if (el.type === 'checkbox' || el.type === 'radio') {
                    if (el.checked) { body.append(el.name, el.value || ''); }
                } else if (el.type !== 'file' && el.type !== 'button' && el.type !== 'submit') {
                    body.append(el.name, el.value || '');
                }
            });
            body.set('novintechBooking', '1');
            // شمارهٔ نرمال‌شده
            body.set('novintechPhone', phone);

            // نقطهٔ پایانی اختصاصی؛ در نبودش آدرس صفحهٔ جاری
            var endpoint = form.getAttribute('action') || window.location.href;
            if (!endpoint || endpoint === '#' || endpoint.charAt(0) === '#') {
                endpoint = window.location.href;
            }

            fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: body.toString(),
                credentials: 'same-origin',
                redirect: 'follow'
            })
                .then(function (res) {
                    var contentType = (res.headers.get('content-type') || '');
                    if (contentType.indexOf('application/json') !== -1) {
                        return res.json().then(function (data) { return data; });
                    }
                    return res.text().then(function () {
                        return { ok: false, error: 'پاسخ سرور قابل پردازش نبود؛ صفحه را رفرش کنید و دوباره تلاش کنید. (HTTP ' + res.status + ')' };
                    });
                })
                .then(function (data) {
                    if (data && data.ok) {
                        try { form.reset(); } catch (e) { }
                        if (successEl) { successEl.hidden = false; }
                        if (successEl) {
                            try { successEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) { }
                        }
                    } else {
                        var msg = (data && data.error && typeof data.error === 'string')
                            ? data.error
                            : 'ارسال درخواست ناموفق بود؛ لطفاً دوباره تلاش کنید.';
                        showMsg(errorEl, errorText, msg);
                    }
                })
                .catch(function () {
                    showMsg(errorEl, errorText, 'خطای ارتباط با سرور؛ اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.');
                })
                .finally(function () {
                    if (submitBtn) {
                        submitBtn.removeAttribute('disabled');
                    }
                });
        });
    }
    initBooking();

    // ========================================
    // Form Validation
    // ========================================
    const contactForm = document.querySelector('.contact-form');

    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            const inputs = this.querySelectorAll('input[required], textarea[required]');
            let isValid = true;

            inputs.forEach(function(input) {
                if (!input.value.trim()) {
                    isValid = false;
                    input.classList.add('error');
                } else {
                    input.classList.remove('error');
                }

                // Email validation
                if (input.type === 'email' && input.value) {
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailRegex.test(input.value)) {
                        isValid = false;
                        input.classList.add('error');
                    }
                }
            });

            if (!isValid) {
                e.preventDefault();
                showNotification('لطفاً فیلدهای مورد نیاز را پر کنید', 'error');
            }
        });

        // Remove error class on input
        contactForm.querySelectorAll('input, textarea').forEach(function(input) {
            input.addEventListener('input', function() {
                this.classList.remove('error');
            });
        });
    }

    // Add error style
    const errorStyle = document.createElement('style');
    errorStyle.textContent = [
        '.form-group input.error,',
        '.form-group textarea.error {',
        '  border-color: #ef4444;',
        '  box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);',
        '}'
    ].join('\n');
    document.head.appendChild(errorStyle);

    // ========================================
    // Reading Progress Bar
    // ========================================
    const progressBar = document.createElement('div');
    progressBar.className = 'reading-progress';
    progressBar.style.cssText = [
        'position: fixed',
        'top: 0',
        'left: 0',
        'width: 0%',
        'height: 3px',
        'background: linear-gradient(90deg, #2563eb, #3b82f6)',
        'z-index: 9999',
        'transition: width 0.1s ease'
    ].join(';');

    // Only show on single posts
    if (document.body.classList.contains('single')) {
        document.body.appendChild(progressBar);

        window.addEventListener('scroll', function() {
            const scrollTop = window.scrollY;
            const docHeight = document.documentElement.scrollHeight - window.innerHeight;
            const progress = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
            progressBar.style.width = progress + '%';
        }, { passive: true });
    }

    // ========================================
    // Keyboard Navigation
    // ========================================
    document.addEventListener('keydown', function(e) {
        // Close mobile menu with Escape
        if (e.key === 'Escape') {
            if (mobileNav && mobileNav.classList.contains('open')) {
                mobileNav.classList.remove('open');
                document.body.style.overflow = '';
            }
        }
    });

    // ========================================
    // Print Button
    // ========================================
    const printBtn = document.querySelector('.print-btn');
    if (printBtn) {
        printBtn.addEventListener('click', function() {
            window.print();
        });
    }

})();
