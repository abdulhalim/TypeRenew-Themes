<?php
/**
 * Footer Template — بازطراحی نسخهٔ ۱٫۲٫۰
 * فوتر سرمه‌ای تیره با هالهٔ آبی، چهار ستون (برند، دسترسی سریع، صفحات، تماس)
 * و کنتراست کامل برای خوانایی متن‌ها.
 *
 * @package NovinTech Theme
 * @author پوردریایی
 * @link https://pourdaryaei.ir
 * @version 1.2.1
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$options = $this->options;
$nvtHome = rtrim((string)$options->siteUrl, '/') . '/';

/* اطلاعات تماس فوتر: اول تنظیمات مدیر، بعد مقدار دمو (۱٫۲٫۱) */
$nvtFooterPhone    = novintech_contact('contact_phone', novintech_contact_demo('contact_phone'));
$nvtFooterMail     = novintech_contact('contact_email', novintech_contact_demo('contact_email'));
$nvtFooterAddress  = novintech_contact('contact_address', novintech_contact_demo('contact_address'));
$nvtFooterInstagram = novintech_contact('social_instagram', novintech_contact_demo('social_instagram'));
$nvtFooterTelegram  = novintech_contact('social_telegram', novintech_contact_demo('social_telegram'));
$nvtFooterTwitter   = novintech_contact('social_twitter', novintech_contact_demo('social_twitter'));
$nvtFooterLinkedin  = novintech_contact('social_linkedin', novintech_contact_demo('social_linkedin'));
?>
    </main><!-- End .site-main -->

    <!-- Footer -->
    <footer class="site-footer">
        <!-- خط گرادیانی بالای فوتر -->
        <div class="footer-gradient-line" aria-hidden="true"></div>
        <div class="container">

            <!-- ستون‌های اصلی فوتر -->
            <div class="footer-main">

                <!-- ستون برند -->
                <div class="footer-brand">
                    <div class="footer-logo">
                        <a href="<?php $options->siteUrl(); ?>">
                            <?php if($options->logo): ?>
                            <img src="<?php echo $options->logo; ?>" alt="<?php $options->title(); ?>" class="footer-logo-image">
                            <?php else: ?>
                            <span class="footer-logo-badge">ن</span>
                            <?php endif; ?>
                            <span class="footer-logo-text"><?php $options->title(); ?></span>
                        </a>
                    </div>
                    <p class="footer-desc">
                        <?php echo novintech_fa_digits(nl2br(htmlspecialchars((string)novintech_opt('novintechFooterText', 'نوین‌تک — همراه شما در مسیر تحول دیجیتال؛ از طراحی وب و موبایل تا راهکارهای ابری و امنیت.'), ENT_QUOTES))); ?>
                    </p>
                    <div class="footer-social">
                        <a href="<?php echo htmlspecialchars($nvtFooterInstagram, ENT_QUOTES); ?>" class="social-link" title="اینستاگرام" target="_blank" rel="noopener">
                            <?php echo novintech_icon('instagram', 18); ?>
                        </a>
                        <a href="<?php echo htmlspecialchars($nvtFooterTelegram, ENT_QUOTES); ?>" class="social-link" title="تلگرام" target="_blank" rel="noopener">
                            <?php echo novintech_icon('telegram', 18); ?>
                        </a>
                        <a href="<?php echo htmlspecialchars($nvtFooterTwitter, ENT_QUOTES); ?>" class="social-link" title="توییتر" target="_blank" rel="noopener">
                            <?php echo novintech_icon('twitter', 18); ?>
                        </a>
                        <a href="<?php echo htmlspecialchars($nvtFooterLinkedin, ENT_QUOTES); ?>" class="social-link" title="لینکدین" target="_blank" rel="noopener">
                            <?php echo novintech_icon('linkedin', 18); ?>
                        </a>
                    </div>
                </div>

                <!-- ستون دسترسی سریع -->
                <nav class="footer-col" aria-label="دسترسی سریع">
                    <h4 class="footer-col-title"><?php echo novintech_icon('zap', 15); ?> دسترسی سریع</h4>
                    <ul class="footer-links">
                        <li><a href="<?php $options->siteUrl(); ?>"><?php echo novintech_icon('chevron-left', 13); ?> خانه</a></li>
                        <li><a href="<?php echo htmlspecialchars($nvtHome . 'services', ENT_QUOTES); ?>"><?php echo novintech_icon('chevron-left', 13); ?> خدمات</a></li>
                        <li><a href="<?php echo htmlspecialchars($nvtHome . 'about', ENT_QUOTES); ?>"><?php echo novintech_icon('chevron-left', 13); ?> درباره ما</a></li>
                        <li><a href="<?php echo htmlspecialchars(novintech_blog_url(), ENT_QUOTES); ?>"><?php echo novintech_icon('chevron-left', 13); ?> وبلاگ</a></li>
                        <li><a href="<?php echo htmlspecialchars($nvtHome . 'contact', ENT_QUOTES); ?>"><?php echo novintech_icon('chevron-left', 13); ?> تماس با ما</a></li>
                    </ul>
                </nav>

                <!-- ستون صفحات (با اعمال انتخاب «صفحات فوتر» از تنظیمات) -->
                <div class="footer-col">
                    <h4 class="footer-col-title"><?php echo novintech_icon('doc', 15); ?> صفحات</h4>
                    <ul class="footer-links footer-pages-links">
                        <?php
                        $nvtFooterSlugs = array();
                        try {
                            $nvtFooterSlugs = (array)$options->footerPages;
                        } catch (\Throwable $e) {
                            $nvtFooterSlugs = array();
                        }
                        $nvtFooterCount = 0;
                        $pages = $this->widget('Widget_Contents_Page_List');
                        if($pages->have()):
                            while($pages->next()):
                                // برگه‌های سیستمی پوسته (دفتر درخواست‌ها و مدیریت) هرگز نمایش داده نمی‌شوند
                                if (novintech_is_reserve_cid((int)$pages->cid)) {
                                    continue;
                                }
                                if (!empty($nvtFooterSlugs) && !in_array($pages->slug, $nvtFooterSlugs, true)) {
                                    continue;
                                }
                                $nvtFooterCount++;
                        ?>
                        <li><a href="<?php $pages->permalink(); ?>"><?php echo novintech_icon('chevron-left', 13); ?> <?php $pages->title(); ?></a></li>
                        <?php
                            endwhile;
                        endif;
                        if ($nvtFooterCount === 0):
                        ?>
                        <li><span class="footer-no-pages">صفحه‌ای وجود ندارد</span></li>
                        <?php endif; ?>
                    </ul>
                </div>

                <!-- ستون راه‌های ارتباطی -->
                <div class="footer-col footer-contact-col">
                    <h4 class="footer-col-title"><?php echo novintech_icon('phone', 15); ?> راه‌های ارتباطی</h4>
                    <ul class="footer-contact-list">
                        <li>
                            <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $nvtFooterPhone), ENT_QUOTES); ?>" class="footer-contact-item">
                                <span class="footer-contact-ic"><?php echo novintech_icon('phone', 16); ?></span>
                                <span class="footer-contact-body">
                                    <span class="footer-contact-label">تلفن</span>
                                    <span class="footer-contact-value" dir="ltr"><?php echo novintech_fa_digits($nvtFooterPhone); ?></span>
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="mailto:<?php echo htmlspecialchars($nvtFooterMail, ENT_QUOTES); ?>" class="footer-contact-item">
                                <span class="footer-contact-ic"><?php echo novintech_icon('mail', 16); ?></span>
                                <span class="footer-contact-body">
                                    <span class="footer-contact-label">ایمیل</span>
                                    <span class="footer-contact-value" dir="ltr"><?php echo htmlspecialchars($nvtFooterMail, ENT_QUOTES); ?></span>
                                </span>
                            </a>
                        </li>
                        <li>
                            <span class="footer-contact-item">
                                <span class="footer-contact-ic"><?php echo novintech_icon('map-pin', 16); ?></span>
                                <span class="footer-contact-body">
                                    <span class="footer-contact-label">آدرس</span>
                                    <span class="footer-contact-value"><?php echo htmlspecialchars($nvtFooterAddress, ENT_QUOTES); ?></span>
                                </span>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- ردیف پایین: حق نشر -->
            <div class="footer-bottom-row">
                <p class="copyright">
                    © <?php echo jdate('Y'); ?> <?php $options->title(); ?>. تمامی حقوق محفوظ است.
                </p>
                <p class="footer-manage">
                    <?php if (novintech_can_manage_bookings()): ?>
                    <a href="<?php echo htmlspecialchars(novintech_manage_url(), ENT_QUOTES); ?>"><?php echo novintech_icon('inbox', 14); ?> مدیریت درخواست‌ها<?php $nvtPendingCount = novintech_pending_bookings_count(); if ($nvtPendingCount > 0): ?> <span class="footer-manage-badge"><?php echo novintech_fa_digits((string)$nvtPendingCount); ?></span><?php endif; ?></a>
                    <?php endif; ?>
                </p>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <button class="back-to-top" id="back-to-top" aria-label="بازگشت به بالا">
        <?php echo novintech_icon('arrow-up', 20); ?>
    </button>

    <!-- JavaScript -->
    <script src="<?php $options->themeUrl('assets/js/main.js'); ?>?v=1.2.1"></script>
    <script>
        window.respondId = '<?php $this->respondId(); ?>';
    </script>
    <script src="<?php $options->themeUrl('assets/js/comments.js'); ?>?v=1.2.1"></script>

    <!-- Custom Footer Code -->
    <?php if($options->footer_code): ?>
    <?php echo $options->footer_code; ?>
    <?php endif; ?>

    <!-- Typecho Footer Hook -->
    <?php $this->footer(); ?>
</body>
</html>
