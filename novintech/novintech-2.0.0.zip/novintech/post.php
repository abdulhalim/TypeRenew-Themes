<?php
/**
 * Post Template - Single Post Page
 *
 * @package NovinTech Theme
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');
?>

<article class="single-post">
    <!-- Post Header -->
    <header class="post-header">
        <div class="container">
            <div class="post-header-inner">
                <div class="post-meta-top">
                    <span class="post-category">
                        <?php $this->category(','); ?>
                    </span>
                    <span class="post-date">
                        <?php echo novintech_icon('calendar', 15); ?>
                        <?php echo jdate('j F Y', $this->created); ?>
                    </span>
                </div>

                <h1 class="post-title"><?php $this->title(); ?></h1>

                <div class="post-meta-bottom">
                    <div class="post-author">
                        <div class="author-avatar">
                            <?php
                            $authorEmail = '';
                            if (isset($this->author) && isset($this->author->mail)) {
                                $authorEmail = $this->author->mail;
                            }
                            echo getAvatar($authorEmail, 48);
                            ?>
                        </div>
                        <div class="author-info">
                            <span class="author-name"><?php $this->author(); ?></span>
                            <span class="author-role">نویسنده</span>
                        </div>
                    </div>

                    <div class="post-share">
                        <span class="share-label">اشتراک‌گذاری:</span>
                        <div class="share-buttons">
                            <a href="https://t.me/share/url?url=<?php $this->permalink(); ?>&text=<?php echo urlencode($this->title); ?>" target="_blank" class="share-btn telegram" title="تلگرام">
                                <?php echo novintech_icon('telegram', 17); ?>
                            </a>
                            <a href="https://twitter.com/intent/tweet?url=<?php $this->permalink(); ?>&text=<?php echo urlencode($this->title); ?>" target="_blank" class="share-btn twitter" title="توییتر">
                                <?php echo novintech_icon('twitter', 17); ?>
                            </a>
                            <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php $this->permalink(); ?>&title=<?php echo urlencode($this->title); ?>" target="_blank" class="share-btn linkedin" title="لینکدین">
                                <?php echo novintech_icon('linkedin', 17); ?>
                            </a>
                            <button type="button" class="share-btn copy-link" onclick="copyToClipboard('<?php $this->permalink(); ?>')" title="کپی لینک">
                                <?php echo novintech_icon('copy', 17); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Post Content Box - Contains Thumbnail and Content -->
    <div class="post-content-wrapper">
        <div class="container">
            <div class="post-content-box">
                <!-- Post Thumbnail — فیلد thumb (جدید) یا thumbnail (قدیمی) -->
                <?php $nvtMainThumb = novintech_thumb($this); ?>
                <?php if($nvtMainThumb !== ''): ?>
                <div class="post-thumbnail-wrapper">
                    <img src="<?php echo htmlspecialchars($nvtMainThumb, ENT_QUOTES); ?>" alt="<?php $this->title(); ?>" class="post-thumbnail-img">
                </div>
                <?php endif; ?>

                <!-- Post Body -->
                <div class="post-body">
                    <?php $this->content(); ?>
                </div>

                <!-- Post Tags -->
                <?php if($this->tags): ?>
                <div class="post-tags">
                    <span class="tags-label">
                        <?php echo novintech_icon('tag', 15); ?>
                        برچسب‌ها:
                    </span>
                    <div class="tags-list">
                        <?php $this->tags('', true, ''); ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

   <!-- Post Navigation (پست قبلی / بعدی) -->
<?php
/*
 * رفع ۴۰۴ ناوبری قبلی/بعدی:
 * نشانی‌ها دقیقاً از همان مسیر هسته ساخته می‌شوند که thePrev/theNext
 * (Widget\Archive) استفاده می‌کنند — Widget\Contents\From با همان کوئری
 * هسته + permalink واقعی محتوا؛ مستقل از طرح پیوند یکتا (post/archive/
 * category) و بدون URL ناقص.
 */
$nvtPrevPost = null;
$nvtNextPost = null;
try {
    $nvtPrevPost = \Widget\Contents\From::allocWithAlias(
        'novintech:prev:' . (int)$this->cid,
        array('query' => $this->select()
            ->where('table.contents.created < ?', $this->created)
            ->where('table.contents.status = ?', 'publish')
            ->where('table.contents.type = ?', 'post')
            ->where("table.contents.password IS NULL OR table.contents.password = ''")
            ->order('table.contents.created', Typecho_Db::SORT_DESC)
            ->limit(1))
    );
    $nvtNextPost = \Widget\Contents\From::allocWithAlias(
        'novintech:next:' . (int)$this->cid,
        array('query' => $this->select()
            ->where('table.contents.created > ?', $this->created)
            ->where('table.contents.status = ?', 'publish')
            ->where('table.contents.type = ?', 'post')
            ->where("table.contents.password IS NULL OR table.contents.password = ''")
            ->order('table.contents.created', Typecho_Db::SORT_ASC)
            ->limit(1))
    );
} catch (\Throwable $e) {
    $nvtPrevPost = null;
    $nvtNextPost = null;
}

$nvtHasPrev = ($nvtPrevPost !== null && $nvtPrevPost->have());
$nvtHasNext = ($nvtNextPost !== null && $nvtNextPost->have());

if ($nvtHasPrev || $nvtHasNext):
?>
    <nav class="post-navigation" aria-label="ناوبری مطالب">
        <div class="container">
            <div class="post-nav-grid">
                <?php if ($nvtHasPrev): ?>
                <a href="<?php echo htmlspecialchars((string)$nvtPrevPost->permalink, ENT_QUOTES); ?>" class="post-nav-card" title="<?php echo htmlspecialchars((string)$nvtPrevPost->title, ENT_QUOTES); ?>">
                    <span class="post-nav-label">
                        <?php echo novintech_icon('chevron-right', 16); ?>
                        مطلب قبلی
                    </span>
                    <?php $nvtPrevThumb = novintech_fields_thumb((int)$nvtPrevPost->cid); ?>
                    <?php if ($nvtPrevThumb !== ''): ?>
                    <span class="post-nav-thumb"><img src="<?php echo htmlspecialchars($nvtPrevThumb, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars((string)$nvtPrevPost->title, ENT_QUOTES); ?>" loading="lazy"></span>
                    <?php endif; ?>
                    <span class="post-nav-title"><?php echo htmlspecialchars((string)$nvtPrevPost->title, ENT_QUOTES); ?></span>
                </a>
                <?php else: ?>
                <span class="post-nav-card post-nav-empty"></span>
                <?php endif; ?>

                <?php if ($nvtHasNext): ?>
                <a href="<?php echo htmlspecialchars((string)$nvtNextPost->permalink, ENT_QUOTES); ?>" class="post-nav-card post-nav-next" title="<?php echo htmlspecialchars((string)$nvtNextPost->title, ENT_QUOTES); ?>">
                    <span class="post-nav-label">
                        مطلب بعدی
                        <?php echo novintech_icon('chevron-left', 16); ?>
                    </span>
                    <?php $nvtNextThumb = novintech_fields_thumb((int)$nvtNextPost->cid); ?>
                    <?php if ($nvtNextThumb !== ''): ?>
                    <span class="post-nav-thumb"><img src="<?php echo htmlspecialchars($nvtNextThumb, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars((string)$nvtNextPost->title, ENT_QUOTES); ?>" loading="lazy"></span>
                    <?php endif; ?>
                    <span class="post-nav-title"><?php echo htmlspecialchars((string)$nvtNextPost->title, ENT_QUOTES); ?></span>
                </a>
                <?php else: ?>
                <span class="post-nav-card post-nav-empty"></span>
                <?php endif; ?>
            </div>
        </div>
    </nav>
<?php endif; ?>
    <!-- Comments -->
    <div class="post-comments">
        <div class="container">
            <?php $this->need('comments.php'); ?>
        </div>
    </div>
</article>

<script>
function copyToClipboard(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(function() {
            // Show toast notification
            showToast('لینک کپی شد!');
        });
    } else {
        var textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showToast('لینک کپی شد!');
    }
}

function showToast(message) {
    // Remove existing toast
    var existingToast = document.querySelector('.toast-notification');
    if (existingToast) {
        existingToast.remove();
    }
    
    // Create new toast
    var toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.innerHTML = '<?php echo novintech_icon('check-circle', 18); ?><span>' + message + '</span>';
    document.body.appendChild(toast);
    
    // Show toast
    setTimeout(function() {
        toast.classList.add('show');
    }, 10);
    
    // Hide and remove toast
    setTimeout(function() {
        toast.classList.remove('show');
        setTimeout(function() {
            toast.remove();
        }, 300);
    }, 3000);
}
</script>

<?php $this->need('footer.php'); ?>
