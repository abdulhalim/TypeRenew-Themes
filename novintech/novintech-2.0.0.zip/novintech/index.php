<?php
/**
 * نوین تکنولوژی - یک پوسته شرکتی برای تایپ‌چو
 *
 * @package نوین‌تک
 * @author پوردریایی
 * @version 2.0.0
 * @link https://pourdaryaei.ir
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/* ================================================================
 * فهرست وبلاگ — مسیر آرشیو (/blog/) و صفحه‌بندی آن — الگوی پوستهٔ الناز
 * وقتی مسیر جاری صفحهٔ اول سایت نباشد (مثل /blog/ یا /page/2/)،
 * به‌جای لندینگ، فهرست مقالات با صفحه‌بندی رندر می‌شود.
 * ================================================================ */
if (!novintech_is_front()) {
    $this->need('header.php');
    ?>

    <header class="post-header">
        <div class="container">
            <div class="post-header-inner">
                <div class="post-meta-top">
                    <span class="post-category">وبلاگ</span>
                </div>
                <h1 class="post-title">آرشیو وبلاگ</h1>
                <p class="archive-description">همهٔ مقالات و نوشته‌های نوین‌تک</p>
            </div>
        </div>
    </header>

    <section class="archive-section">
        <div class="container">

            <!-- فرم جستجو (به مسیر جستجوی استاندارد هسته هدایت می‌شود) -->
            <div class="archive-search-box">
                <form method="get" action="<?php $this->options->siteUrl(); ?>" class="archive-search-form">
                    <input type="text" name="s" placeholder="جستجو در مطالب..." class="archive-search-input">
                    <button type="submit" class="archive-search-btn">
                        <?php echo novintech_icon('search', 16); ?>
                        <span>جستجو</span>
                    </button>
                </form>
            </div>

            <?php if ($this->have()): ?>
            <div class="blog-grid">
                <?php while ($this->next()): ?>
                <article class="blog-card">
                    <div class="blog-image">
                        <?php $nvtThumb = novintech_thumb($this); ?>
                        <?php if ($nvtThumb !== ''): ?>
                            <img src="<?php echo htmlspecialchars($nvtThumb, ENT_QUOTES); ?>" alt="<?php $this->title(); ?>" loading="lazy">
                        <?php else: ?>
                            <div class="blog-image-placeholder">
                                <?php echo novintech_icon('doc', 30); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta">
                            <span class="blog-category"><?php $this->category(',', false); ?></span>
                            <span class="blog-date">
                                <?php echo novintech_icon('calendar', 14); ?>
                                <?php echo jdate('j F Y', $this->created); ?>
                            </span>
                        </div>
                        <h3 class="blog-title">
                            <a href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a>
                        </h3>
                        <p class="blog-excerpt"><?php $this->excerpt(100, '...'); ?></p>
                        <a href="<?php $this->permalink(); ?>" class="blog-link">
                            ادامه مطلب
                            <?php echo novintech_icon('arrow', 15); ?>
                        </a>
                    </div>
                </article>
                <?php endwhile; ?>
            </div>

            <!-- صفحه‌بندی فارسی (الگوی الناز) -->
            <?php novintech_page_nav($this); ?>

            <?php else: ?>
            <div class="no-results">
                <div class="no-results-icon">
                    <?php echo novintech_icon('search', 34); ?>
                </div>
                <h2 class="no-results-title">مطلبی یافت نشد</h2>
                <p class="no-results-text">هنوز مطلبی در وبلاگ ثبت نشده است.</p>
                <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-primary">بازگشت به صفحه اصلی</a>
            </div>
            <?php endif; ?>
        </div>
    </section>

    <?php
    $this->need('footer.php');
    return;
}

// انتخاب طرح صفحهٔ اول از تنظیمات پوسته (کلاسیک / مدرن)
$nvtFrontStyle = novintech_opt('novintechFrontStyle', 'classic');
if ($nvtFrontStyle === 'modern') {
    $this->need('index-modern.php');
    return;
}

$this->need('header.php');
$options = $this->options;
$nvtBlogUrl = novintech_blog_url();
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="hero-bg"></div>
    <div class="hero-shapes">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
    </div>

    <div class="container">
        <div class="hero-content">
            <span class="hero-badge"><?php echo novintech_icon('rocket', 15); ?> راهکارهای دیجیتال پیشرفته</span>
            <h1 class="hero-title">
                <span class="text-primary">آینده</span> کسب‌وکار شما
                <br>در دستان ماست
            </h1>
            <p class="hero-description">
                با بهره‌گیری از جدیدترین تکنولوژی‌ها و تیم مجرب، کسب‌وکار شما را به سطح بالاتری می‌بریم.
                از طراحی وب تا هوش مصنوعی، همراه شما هستیم.
            </p>
            <div class="hero-buttons">
                <a href="#booking" class="btn btn-primary btn-lg">
                    درخواست مشاوره رایگان
                    <?php echo novintech_icon('arrow', 17); ?>
                </a>
                <a href="#services" class="btn btn-outline btn-lg">مشاهده خدمات</a>
            </div>
        </div>

        <div class="hero-illustration">
            <div class="hero-card">
                <div class="hero-card-content">
                    <?php echo novintech_icon('code', 34, 'hero-icon'); ?>
                    <p class="hero-card-title">تکنولوژی</p>
                    <p class="hero-card-subtitle">نوین و خلاق</p>
                </div>
            </div>
            <div class="floating-icon icon-1">
                <?php echo novintech_icon('mobile', 26); ?>
            </div>
            <div class="floating-icon icon-2">
                <?php echo novintech_icon('users', 26); ?>
            </div>
            <div class="floating-icon icon-3">
                <?php echo novintech_icon('chart', 26); ?>
            </div>
        </div>
    </div>

<div class="scroll-indicator">
    <a href="#services" class="scroll-link">
        <div class="scroll-mouse">
            <div class="scroll-wheel"></div>
        </div>
    </a>
</div>
</section>

<!-- Services Section -->
<section id="services" class="services-section">
    <div class="container">
        <div class="section-header">
            <span class="section-badge">خدمات ما</span>
            <h2 class="section-title">چه خدماتی ارائه می‌دهیم؟</h2>
            <p class="section-description">
                ما با ارائه طیف گسترده‌ای از خدمات دیجیتال، تمام نیازهای کسب‌وکار شما را پوشش می‌دهیم
            </p>
        </div>

        <div class="services-grid">
            <div class="service-card">
                <div class="service-icon">
                    <?php echo novintech_icon('code', 26); ?>
                </div>
                <h3 class="service-title">توسعه وب</h3>
                <p class="service-description">طراحی و توسعه وب‌سایت‌های مدرن، سریع و امن با استفاده از جدیدترین تکنولوژی‌ها</p>
            </div>

            <div class="service-card">
                <div class="service-icon">
                    <?php echo novintech_icon('mobile', 26); ?>
                </div>
                <h3 class="service-title">اپلیکیشن موبایل</h3>
                <p class="service-description">ساخت اپلیکیشن‌های موبایل چندپلتفرمی و بومی برای iOS و Android</p>
            </div>

            <div class="service-card">
                <div class="service-icon">
                    <?php echo novintech_icon('pen', 26); ?>
                </div>
                <h3 class="service-title">طراحی UI/UX</h3>
                <p class="service-description">طراحی رابط کاربری زیبا و تجربه کاربری عالی برای محصولات دیجیتال</p>
            </div>

            <div class="service-card">
                <div class="service-icon">
                    <?php echo novintech_icon('chart', 26); ?>
                </div>
                <h3 class="service-title">دیجیتال مارکتینگ</h3>
                <p class="service-description">استراتژی‌های بازاریابی دیجیتال برای افزایش فروش و رشد کسب‌وکار</p>
            </div>

            <div class="service-card">
                <div class="service-icon">
                    <?php echo novintech_icon('cloud', 26); ?>
                </div>
                <h3 class="service-title">خدمات ابری</h3>
                <p class="service-description">راه‌اندازی و مدیریت زیرساخت‌های ابری مقیاس‌پذیر و امن</p>
            </div>

            <div class="service-card">
                <div class="service-icon">
                    <?php echo novintech_icon('shield', 26); ?>
                </div>
                <h3 class="service-title">امنیت سایبری</h3>
                <p class="service-description">محافظت از کسب‌وکار شما در برابر تهدیدات و حملات سایبری</p>
            </div>
        </div>
    </div>
</section>

<!-- About Section -->
<section id="about" class="about-section">
    <div class="container">
        <div class="about-grid">
            <div class="about-illustration">
                <div class="about-card">
                    <div class="about-card-inner">
                        <div class="about-avatar">
                            <?php echo novintech_icon('users', 28); ?>
                        </div>
                        <h4 class="about-card-title">تیم حرفه‌ای</h4>
                        <p class="about-card-text">بیش از ۵۰ متخصص در کنار شما</p>
                    </div>
                </div>
                <div class="about-stat floating">
                    <div class="stat-icon">
                        <?php echo novintech_icon('award', 24); ?>
                    </div>
                    <div class="stat-info">
                        <span class="stat-label">رضایت مشتری</span>
                        <span class="stat-value">۹۸٪</span>
                    </div>
                </div>
            </div>

            <div class="about-content">
                <span class="section-badge">درباره ما</span>
                <h2 class="section-title">چرا نوین فناوری را انتخاب کنید؟</h2>
                <p class="about-text">
                    شرکت نوین فناوری با بیش از یک دهه تجربه در حوزه فناوری اطلاعات، همواره در خط مقدم نوآوری و تحول دیجیتال قرار داشته است.
                    ما با تیمی متشکل از بهترین متخصصان، راهکارهای هوشمند و کارآمد برای کسب‌وکارها ارائه می‌دهیم.
                </p>
                <p class="about-text">
                    تعهد ما به کیفیت، نوآوری و رضایت مشتری، ما را به یکی از پیشروترین شرکت‌های فناوری در کشور تبدیل کرده است.
                </p>

                <div class="about-stats">
                    <div class="stat-item">
                        <?php echo novintech_icon('briefcase', 22); ?>
                        <span class="stat-number">+۲۵۰</span>
                        <span class="stat-text">پروژه موفق</span>
                    </div>
                    <div class="stat-item">
                        <?php echo novintech_icon('users', 22); ?>
                        <span class="stat-number">+۱۸۰</span>
                        <span class="stat-text">مشتری راضی</span>
                    </div>
                    <div class="stat-item">
                        <?php echo novintech_icon('award', 22); ?>
                        <span class="stat-number">+۱۲</span>
                        <span class="stat-text">سال تجربه</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Blog Section -->
<section id="blog" class="blog-section">
    <div class="container">
        <div class="section-header">
            <span class="section-badge">وبلاگ</span>
            <h2 class="section-title">آخرین مطالب وبلاگ</h2>
            <p class="section-description">
                جدیدترین مقالات و اخبار دنیای فناوری را در وبلاگ ما بخوانید
            </p>
        </div>

        <div class="blog-grid">
            <?php
            $recentPosts = $this->widget('Widget_Contents_Post_Recent', 'pageSize=3');
            if ($recentPosts->have()):
                while($recentPosts->next()):
            ?>
            <article class="blog-card">
                <div class="blog-image">
                    <?php $nvtRecentThumb = novintech_thumb($recentPosts); ?>
                    <?php if($nvtRecentThumb !== ''): ?>
                        <img src="<?php echo htmlspecialchars($nvtRecentThumb, ENT_QUOTES); ?>" alt="<?php $recentPosts->title(); ?>">
                    <?php else: ?>
                        <div class="blog-image-placeholder">
                            <?php echo novintech_icon('doc', 30); ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="blog-content">
                    <div class="blog-meta">
                        <span class="blog-category"><?php $recentPosts->category(','); ?></span>
                        <span class="blog-date">
                            <?php echo novintech_icon('calendar', 14); ?>
                            <?php echo jdate('j F Y', $recentPosts->created); ?>
                        </span>
                    </div>
                    <h3 class="blog-title">
                        <a href="<?php $recentPosts->permalink(); ?>"><?php $recentPosts->title(); ?></a>
                    </h3>
                    <p class="blog-excerpt"><?php $recentPosts->excerpt(100, '...'); ?></p>
                    <a href="<?php $recentPosts->permalink(); ?>" class="blog-link">
                        ادامه مطلب
                        <?php echo novintech_icon('arrow', 15); ?>
                    </a>
                </div>
            </article>
            <?php
                endwhile;
            endif;
            ?>
        </div>

        <div class="blog-archive-btn">
            <a href="<?php echo htmlspecialchars($nvtBlogUrl, ENT_QUOTES); ?>" class="btn btn-outline btn-lg">
                آرشیو وبلاگ
                <?php echo novintech_icon('arrow-right', 17); ?>
            </a>
        </div>
    </div>
</section>

<!-- Booking Section — درخواست مشاورهٔ رایگان (الگوی نهال/الناز) -->
<?php
$nvtBookingTitle    = novintech_opt('novintechBookingTitle', 'درخواست مشاورهٔ رایگان');
$nvtBookingSubtitle = novintech_opt('novintechBookingSubtitle', 'فرم را پر کنید؛ کارشناسان ما در اولین فرصت برای هماهنگی جلسهٔ مشاورهٔ رایگان با شما تماس می‌گیرند.');
$nvtBookingServices = array_filter(array_map('trim', explode(',', (string)novintech_opt('novintechBookingServices', 'توسعه وب, اپلیکیشن موبایل, طراحی UI/UX, دیجیتال مارکتینگ, خدمات ابری, امنیت سایبری, مشاورهٔ عمومی'))));
$nvtBookingAction = novintech_booking_endpoint();
$nvtBookingToken = '';
try {
    $nvtBookingToken = htmlspecialchars(\Widget\Security::alloc()->getToken($this->request->getRequestUrl()), ENT_QUOTES, 'UTF-8');
} catch (\Throwable $e) {
    $nvtBookingToken = '';
}
?>
<section id="booking" class="booking-section">
    <div class="container">
        <div class="section-header">
            <span class="section-badge"><?php echo novintech_icon('calendar-check', 14); ?> شروع رایگان</span>
            <h2 class="section-title"><?php echo htmlspecialchars($nvtBookingTitle, ENT_QUOTES); ?></h2>
            <p class="section-description"><?php echo htmlspecialchars($nvtBookingSubtitle, ENT_QUOTES); ?></p>
        </div>

        <div class="bk-split">
            <div class="bk-panel">
                <div class="bk-panel-head">
                    <span class="bk-panel-ic"><?php echo novintech_icon('calendar-check', 48); ?></span>
                    <div>
                        <strong>فرم درخواست مشاوره</strong>
                        <span>کمتر از یک دقیقه طول می‌کشد</span>
                    </div>
                </div>
                <form class="bk-form" id="bookingForm" method="post" action="<?php echo htmlspecialchars($nvtBookingAction, ENT_QUOTES); ?>" novalidate>
                    <input type="hidden" name="novintechBooking" value="1">
                    <?php if ($nvtBookingToken !== ''): ?>
                    <input type="hidden" name="_" value="<?php echo $nvtBookingToken; ?>">
                    <?php endif; ?>

                    <!-- تلهٔ هرزنامه — باید خالی بماند -->
                    <input type="text" name="novintechHp" class="hp-field" tabindex="-1" autocomplete="off" aria-hidden="true">

                    <div class="bk-form-row">
                        <div class="bk-field">
                            <label for="novintechName">نام و نام خانوادگی <span class="req">*</span></label>
                            <input type="text" id="novintechName" name="novintechName" class="bk-input" placeholder="مثلاً: آرش رضایی" required>
                        </div>
                        <div class="bk-field">
                            <label for="novintechPhone">شمارهٔ تلفن همراه <span class="req">*</span></label>
                            <input type="tel" id="novintechPhone" name="novintechPhone" class="bk-input" placeholder="۰۹۱۲۳۴۵۶۷۸۹" required>
                        </div>
                    </div>

                    <div class="bk-form-row">
                        <div class="bk-field">
                            <label for="novintechMail">ایمیل (اختیاری)</label>
                            <input type="email" id="novintechMail" name="novintechMail" class="bk-input" placeholder="you@example.com" dir="ltr">
                        </div>
                        <?php if (!empty($nvtBookingServices)): ?>
                        <div class="bk-field">
                            <label for="novintechService">خدمت موردنیاز</label>
                            <select id="novintechService" name="novintechService" class="bk-input bk-select">
                                <option value="">انتخاب کنید…</option>
                                <?php foreach ($nvtBookingServices as $nvtBookingService): ?>
                                <option value="<?php echo htmlspecialchars($nvtBookingService, ENT_QUOTES); ?>"><?php echo htmlspecialchars($nvtBookingService, ENT_QUOTES); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="bk-field">
                        <label for="novintechNote">توضیحات پروژه (اختیاری)</label>
                        <textarea id="novintechNote" name="novintechNote" class="bk-input" rows="3" placeholder="کسب‌وکار شما، ایده، یا هر نکته‌ای که لازم است بدانیم…"></textarea>
                    </div>

                    <button type="submit" class="bk-submit" id="bookingSubmitBtn">
                        <?php echo novintech_icon('send', 17); ?>
                        <span>ثبت درخواست مشاورهٔ رایگان</span>
                    </button>

                    <p class="bk-note">
                        <?php echo novintech_icon('shield-check', 13); ?>
                        اطلاعات شما محفوظ است و فقط برای هماهنگی جلسهٔ مشاوره استفاده می‌شود.
                    </p>

                    <div class="bk-alert bk-alert-success" id="bookingSuccess" hidden>
                        <?php echo novintech_icon('check-circle', 20); ?>
                        <div>
                            <strong>درخواست شما ثبت شد!</strong>
                            <span>کارشناسان ما در اولین فرصت با شما تماس می‌گیرند.</span>
                        </div>
                    </div>
                    <div class="bk-alert bk-alert-error" id="bookingError" hidden>
                        <?php echo novintech_icon('x', 20); ?>
                        <div>
                            <strong>خطا در ثبت درخواست!</strong>
                            <span id="bookingErrorText">لطفاً دوباره تلاش کنید.</span>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Contact Section -->
<?php
/* اطلاعات تماس کلاسیک: اول تنظیمات مدیر، بعد مقدار دمو (۱٫۲٫۱) */
$nvtContactPhone    = novintech_contact('contact_phone', novintech_contact_demo('contact_phone'));
$nvtContactMail     = novintech_contact('contact_email', novintech_contact_demo('contact_email'));
$nvtContactAddress  = novintech_contact('contact_address', novintech_contact_demo('contact_address'));
$nvtSocialInstagram = novintech_contact('social_instagram', novintech_contact_demo('social_instagram'));
$nvtSocialTelegram  = novintech_contact('social_telegram', novintech_contact_demo('social_telegram'));
$nvtSocialTwitter   = novintech_contact('social_twitter', novintech_contact_demo('social_twitter'));
$nvtSocialLinkedin  = novintech_contact('social_linkedin', novintech_contact_demo('social_linkedin'));
?>
<section id="contact" class="contact-section">
    <div class="container">
        <div class="section-header">
            <span class="section-badge">تماس با ما</span>
            <h2 class="section-title">ارتباط با ما</h2>
            <p class="section-description">
                برای کسب اطلاعات بیشتر یا شروع همکاری، از طریق راه‌های زیر با ما در تماس باشید.
            </p>
        </div>

        <div class="contact-content-grid">
            <div class="contact-main-row">
                <div class="contact-info-side">
                    <div class="contact-info-list">
                        <div class="contact-info-item">
                            <div class="contact-info-icon">
                                <?php echo novintech_icon('phone', 22); ?>
                            </div>
                            <div class="contact-info-content">
                                <span class="contact-info-label">تلفن</span>
                                <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $nvtContactPhone), ENT_QUOTES); ?>" class="contact-info-value" dir="ltr"><?php echo novintech_fa_digits($nvtContactPhone); ?></a>
                            </div>
                        </div>

                        <div class="contact-info-item">
                            <div class="contact-info-icon">
                                <?php echo novintech_icon('mail', 22); ?>
                            </div>
                            <div class="contact-info-content">
                                <span class="contact-info-label">ایمیل</span>
                                <a href="mailto:<?php echo htmlspecialchars($nvtContactMail, ENT_QUOTES); ?>" class="contact-info-value" dir="ltr"><?php echo htmlspecialchars($nvtContactMail, ENT_QUOTES); ?></a>
                            </div>
                        </div>

                        <div class="contact-info-item">
                            <div class="contact-info-icon">
                                <?php echo novintech_icon('map-pin', 22); ?>
                            </div>
                            <div class="contact-info-content">
                                <span class="contact-info-label">آدرس</span>
                                <span class="contact-info-value"><?php echo htmlspecialchars($nvtContactAddress, ENT_QUOTES); ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="social-links">
                        <span class="social-label">ما را در شبکه‌های اجتماعی دنبال کنید</span>
                        <div class="social-icons">
                            <a href="<?php echo htmlspecialchars($nvtSocialInstagram, ENT_QUOTES); ?>" class="social-icon" title="اینستاگرام" target="_blank" rel="noopener">
                                <?php echo novintech_icon('instagram', 18); ?>
                            </a>
                            <a href="<?php echo htmlspecialchars($nvtSocialTelegram, ENT_QUOTES); ?>" class="social-icon" title="تلگرام" target="_blank" rel="noopener">
                                <?php echo novintech_icon('telegram', 18); ?>
                            </a>
                            <a href="<?php echo htmlspecialchars($nvtSocialTwitter, ENT_QUOTES); ?>" class="social-icon" title="توییتر" target="_blank" rel="noopener">
                                <?php echo novintech_icon('twitter', 18); ?>
                            </a>
                            <a href="<?php echo htmlspecialchars($nvtSocialLinkedin, ENT_QUOTES); ?>" class="social-icon" title="لینکدین" target="_blank" rel="noopener">
                                <?php echo novintech_icon('linkedin', 18); ?>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="contact-map-side">
                    <?php 
                    $mapCoords = parseMapCoordinates($options->map_coordinates);
                    if($mapCoords): 
                    ?>
                    <div class="contact-map">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3000!2d<?php echo $mapCoords['lng']; ?>!3d<?php echo $mapCoords['lat']; ?>!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjfCsDA5JzU2LjAiTiA1NsKwMTQnNDguNiJF!5e0!3m2!1sen!2s!4v1!5m2!1sen!2s"
                            width="100%"
                            height="300"
                            style="border:0; border-radius: 16px;"
                            allowfullscreen=""
                            loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade">
                        </iframe>
                    </div>
                    <?php else: ?>
                    <div class="contact-map-placeholder">
                        <?php echo novintech_icon('map-pin', 34); ?>
                        <span>مختصات نقشه را در تنظیمات پوسته وارد کنید</span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $this->need('footer.php'); ?>
