<?php
/**
 * مدیریت درخواست‌های مشاورهٔ نوین‌تک — قالب سفارشی برگه
 *
 * نمایش و مدیریت درخواست‌های «مشاورهٔ رایگان» (فقط برای اعضای واردشده با
 * دسترسی مدیر/سردبیر). درخواست‌ها روی برگهٔ «دفتر درخواست‌ها» به‌صورت دیدگاه
 * ذخیره شده‌اند؛ این قالب آن‌ها را ساختاریافته نمایش می‌دهد و دکمه‌های
 * تأیید/رد/حذف دارد که با AJAX به نقطهٔ پایانی /novintech-booking
 * ارسال می‌شوند (الگوی نهال/الناز).
 *
 * @package custom
 * @author پوردریایی
 * @link https://pourdaryaei.ir
 * @version 1.2.1
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$nvtManageOk = novintech_can_manage_bookings();
$nvtBookings = $nvtManageOk ? novintech_bookings_list() : [];
$nvtStats = ['total' => 0, 'waiting' => 0, 'approved' => 0, 'spam' => 0];
foreach ($nvtBookings as $nvtB) {
    $nvtStats['total']++;
    if (isset($nvtStats[$nvtB['status']])) {
        $nvtStats[$nvtB['status']]++;
    }
}

$nvtStatusLabels = [
    'waiting'  => 'در انتظار بررسی',
    'approved' => 'تأیید شده',
    'spam'     => 'رد شده',
];
$nvtStatusClasses = [
    'waiting'  => 'bkst-waiting',
    'approved' => 'bkst-approved',
    'spam'     => 'bkst-rejected',
];

$nvtManageToken = '';
try {
    $nvtManageToken = htmlspecialchars(
        \Widget\Security::alloc()->getToken($this->request->getRequestUrl()),
        ENT_QUOTES,
        'UTF-8'
    );
} catch (\Throwable $e) {
}

$nvtManageEndpoint = novintech_booking_endpoint();
?>

<article class="page-wrap container bk-manage">

    <header class="page-head">
        <nav class="post-breadcrumb" aria-label="مسیر">
            <a href="<?php $this->options->siteUrl(); ?>">خانه</a>
            <span class="crumb-sep">/</span>
            <span aria-current="page">مدیریت درخواست‌ها</span>
        </nav>
        <h1 class="page-title">
            <?php echo novintech_icon('calendar-check', 22); ?>
            مدیریت درخواست‌های مشاوره
        </h1>
        <p class="bk-manage-sub">درخواست‌های «مشاورهٔ رایگان» ثبت‌شده از فرم سایت — جدیدترین در ابتدا؛ درخواست‌های در انتظار بررسی اولویت دارند.</p>
    </header>

    <?php if (!$nvtManageOk): ?>
    <div class="bk-manage-notice" role="alert">
        <?php echo novintech_icon('lock', 22); ?>
        <div>
            <strong>ورود لازم است</strong>
            <span>برای مشاهده و مدیریت درخواست‌ها باید با حساب مدیر یا سردبیر وارد سایت شوید.</span>
            <a class="btn btn-primary btn-sm" href="<?php echo htmlspecialchars((string)$this->options->loginUrl, ENT_QUOTES); ?>">ورود به حساب</a>
        </div>
    </div>
    <?php else: ?>

    <div class="bk-manage-stats">
        <div class="bk-stat">
            <span class="bk-stat-num"><?php echo novintech_fa_digits((string)$nvtStats['waiting']); ?></span>
            <span class="bk-stat-label">در انتظار بررسی</span>
        </div>
        <div class="bk-stat bk-stat-approved">
            <span class="bk-stat-num"><?php echo novintech_fa_digits((string)$nvtStats['approved']); ?></span>
            <span class="bk-stat-label">تأیید شده</span>
        </div>
        <div class="bk-stat bk-stat-rejected">
            <span class="bk-stat-num"><?php echo novintech_fa_digits((string)$nvtStats['spam']); ?></span>
            <span class="bk-stat-label">رد شده</span>
        </div>
        <div class="bk-stat bk-stat-total">
            <span class="bk-stat-num"><?php echo novintech_fa_digits((string)$nvtStats['total']); ?></span>
            <span class="bk-stat-label">مجموع</span>
        </div>
    </div>

    <div class="bk-manage-list" id="bkManageList">
        <?php if (empty($nvtBookings)): ?>
        <div class="bk-manage-empty">
            <?php echo novintech_icon('inbox', 40); ?>
            <p>هنوز درخواستی ثبت نشده است.</p>
            <p class="bk-manage-empty-sub">به‌محض ثبت اولین درخواست مشاورهٔ رایگان، اینجا نمایش داده می‌شود.</p>
        </div>
        <?php else: ?>
        <?php foreach ($nvtBookings as $nvtB): ?>
        <?php
        $nvtBPhone = trim((string)($nvtB['phone'] !== '' ? $nvtB['phone'] : $nvtB['url']));
        $nvtBTel = preg_replace('/[^0-9+]/', '', $nvtBPhone);
        ?>
        <div class="bk-card" data-coid="<?php echo (int)$nvtB['coid']; ?>">
            <div class="bk-card-head">
                <span class="bk-status <?php echo $nvtStatusClasses[$nvtB['status']] ?? 'bkst-other'; ?>">
                    <?php echo htmlspecialchars($nvtStatusLabels[$nvtB['status']] ?? $nvtB['status'], ENT_QUOTES); ?>
                </span>
                <span class="bk-card-date">
                    <?php echo novintech_icon('clock', 13); ?>
                    <?php echo jdate('j F Y — H:i', (int)$nvtB['created']); ?>
                </span>
            </div>

            <div class="bk-card-body">
                <div class="bk-card-main">
                    <div class="bk-card-name">
                        <?php echo novintech_icon('user', 16); ?>
                        <strong><?php echo htmlspecialchars((string)$nvtB['author'], ENT_QUOTES); ?></strong>
                    </div>
                    <?php if ($nvtBPhone !== ''): ?>
                    <div class="bk-card-field">
                        <?php echo novintech_icon('phone', 15); ?>
                        <a href="tel:<?php echo htmlspecialchars($nvtBTel, ENT_QUOTES); ?>" dir="ltr"><?php echo htmlspecialchars(novintech_fa_digits($nvtBPhone), ENT_QUOTES); ?></a>
                    </div>
                    <?php endif; ?>
                    <?php if ($nvtB['mail'] !== ''): ?>
                    <div class="bk-card-field">
                        <?php echo novintech_icon('mail', 15); ?>
                        <a href="mailto:<?php echo htmlspecialchars($nvtB['mail'], ENT_QUOTES); ?>" dir="ltr"><?php echo htmlspecialchars($nvtB['mail'], ENT_QUOTES); ?></a>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="bk-card-side">
                    <?php if ($nvtB['service'] !== ''): ?>
                    <div class="bk-tag"><?php echo novintech_icon('briefcase', 13); ?> <?php echo htmlspecialchars($nvtB['service'], ENT_QUOTES); ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($nvtB['note'] !== ''): ?>
            <div class="bk-card-note">
                <?php echo novintech_icon('message-square', 14); ?>
                <p><?php echo htmlspecialchars($nvtB['note'], ENT_QUOTES); ?></p>
            </div>
            <?php endif; ?>

            <div class="bk-card-actions">
                <?php if ($nvtB['status'] !== 'approved'): ?>
                <button type="button" class="bk-btn bk-btn-approve" data-mode="approve" data-coid="<?php echo (int)$nvtB['coid']; ?>">
                    <?php echo novintech_icon('check', 14); ?> تأیید
                </button>
                <?php endif; ?>
                <?php if ($nvtB['status'] !== 'spam'): ?>
                <button type="button" class="bk-btn bk-btn-reject" data-mode="reject" data-coid="<?php echo (int)$nvtB['coid']; ?>">
                    <?php echo novintech_icon('x', 14); ?> رد
                </button>
                <?php endif; ?>
                <button type="button" class="bk-btn bk-btn-delete" data-mode="delete" data-coid="<?php echo (int)$nvtB['coid']; ?>">
                    <?php echo novintech_icon('trash', 14); ?> حذف
                </button>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script>
    (function () {
        'use strict';
        var list = document.getElementById('bkManageList');
        if (!list) { return; }
        var endpoint = <?php echo json_encode($nvtManageEndpoint, JSON_UNESCAPED_SLASHES); ?>;
        var token = <?php echo json_encode($nvtManageToken); ?>;

        function setBusy(card, busy) {
            Array.prototype.forEach.call(card.querySelectorAll('.bk-btn'), function (b) {
                b.disabled = !!busy;
            });
        }

        list.addEventListener('click', function (e) {
            var btn = e.target.closest ? e.target.closest('.bk-btn') : null;
            if (!btn || btn.disabled) { return; }
            var card = btn.closest('.bk-card');
            if (!card) { return; }
            var coid = parseInt(btn.getAttribute('data-coid'), 10);
            var mode = btn.getAttribute('data-mode');
            if (!coid || !mode) { return; }

            if (mode === 'delete' && !window.confirm('این درخواست برای همیشه حذف شود؟')) { return; }

            setBusy(card, true);

            var body = new URLSearchParams();
            body.append('novintechBooking', '1');
            body.append('mode', mode);
            body.append('coid', String(coid));
            if (token) { body.append('_', token); }

            fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' },
                body: body.toString(),
                credentials: 'same-origin'
            })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (data && data.ok) {
                        // ساده و مطمئن: بارگذاری مجدد صفحه
                        window.location.reload();
                    } else {
                        alert((data && data.error) ? data.error : 'خطا در به‌روزرسانی درخواست.');
                        setBusy(card, false);
                    }
                })
                .catch(function () {
                    alert('خطای ارتباط با سرور؛ دوباره تلاش کنید.');
                    setBusy(card, false);
                });
        });
    })();
    </script>
    <?php endif; ?>

</article>

<?php $this->need('footer.php'); ?>
