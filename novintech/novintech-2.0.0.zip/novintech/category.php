<?php
/**
 * Category Template - Same style as Archive
 *
 * @package NovinTech Theme
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');
?>

<!-- Post Header (همانند archive.php) -->
<header class="post-header">
    <div class="container">
        <div class="post-header-inner">
            <div class="post-meta-top">
                <span class="post-category">دسته‌بندی</span>
            </div>
            <h1 class="post-title">
                <?php $this->archiveTitle('', '', ''); ?>
            </h1>
            <p class="archive-description">
                <?php if($this->getDescription()): ?>
                    <?php echo $this->getDescription(); ?>
                <?php else: ?>
                    تمام مطالب منتشر شده در این دسته‌بندی
                <?php endif; ?>
            </p>
        </div>
    </div>
</header>

<!-- Main Content -->
<section class="archive-section">
    <div class="container">
        
        <!-- Search Box -->
        <div class="archive-search-box">
            <form method="post" action="<?php $this->options->siteUrl(); ?>" class="archive-search-form">
                <input type="text" name="s" placeholder="جستجو در مطالب..." class="archive-search-input" value="">
                <button type="submit" class="archive-search-btn">
                    <?php echo novintech_icon('search', 16); ?>
                    <span>جستجو</span>
                </button>
            </form>
        </div>

        <!-- Archive Grid -->
        <?php if($this->have()): ?>
        <div class="blog-grid">
            <?php while($this->next()): ?>
            <article class="blog-card">
                <div class="blog-image">
                    <?php $nvtCatThumb = novintech_thumb($this); ?>
                    <?php if($nvtCatThumb !== ''): ?>
                        <img src="<?php echo htmlspecialchars($nvtCatThumb, ENT_QUOTES); ?>" alt="<?php $this->title(); ?>">
                    <?php else: ?>
                        <div class="blog-image-placeholder">
                            <?php echo novintech_icon('doc', 30); ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="blog-content">
                    <div class="blog-meta">
                        <span class="blog-category"><?php $this->category(',', false); ?></span>
                        <span class="blog-date">
                            <?php echo novintech_icon('calendar', 14); ?>
                            <?php echo jdate('j F Y', $this->created); ?>
                        </span>
                    </div>
                    <h3 class="blog-title">
                        <a href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a>
                    </h3>
                    <p class="blog-excerpt"><?php $this->excerpt(100, '...'); ?></p>
                    <a href="<?php $this->permalink(); ?>" class="blog-link">
                        ادامه مطلب
                        <?php echo novintech_icon('arrow', 15); ?>
                    </a>
                </div>
            </article>
            <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <div class="pagination">
            <?php
            $this->pageNav(
                novintech_icon('chevron-right', 14) . ' قبلی',
                'بعدی ' . novintech_icon('chevron-left', 14),
                1,
                '...',
                array(
                    'wrapTag' => 'nav',
                    'wrapClass' => 'pagination-nav',
                    'itemTag' => 'span',
                    'textTag' => 'span',
                    'currentClass' => 'current',
                    'prevClass' => 'prev',
                    'nextClass' => 'next'
                )
            ); ?>
        </div>

        <!-- نمایش اطلاعات صفحه‌بندی -->
        <?php if($this->getTotal() > $this->options->pageSize): ?>
        <div class="pagination-info">
            <?php 
            $total = $this->getTotal();
            $pageSize = $this->options->pageSize;
            $currentPage = $this->_currentPage;
            $from = ($currentPage - 1) * $pageSize + 1;
            $to = min($currentPage * $pageSize, $total);
            ?>
            <p>نمایش <?php echo $from; ?> - <?php echo $to; ?> از <?php echo $total; ?> مطلب</p>
        </div>
        <?php endif; ?>

        <?php else: ?>
        <div class="no-results">
            <div class="no-results-icon">
                <?php echo novintech_icon('search', 34); ?>
            </div>
            <h2 class="no-results-title">مطلبی یافت نشد</h2>
            <p class="no-results-text">متأسفانه مطلبی در این دسته‌بندی پیدا نشد.</p>
            <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-primary">بازگشت به صفحه اصلی</a>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php $this->need('footer.php'); ?>
