<?php
/**
 * Header Template
 *
 * @package NovinTech Theme
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$options = $this->options;
$nvtOnHome    = novintech_is_front();
$nvtBlogUrl   = novintech_blog_url();
$nvtBlogNav   = $nvtOnHome ? '#blog' : $nvtBlogUrl;
$nvtVersion   = '1.2.1';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="<?php $options->charset(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- SEO Meta Tags -->
    <title><?php $this->archiveTitle(array(
        'category'  =>  _t('دسته‌بندی %s'),
        'search'    =>  _t('نتایج جستجو برای %s'),
        'tag'       =>  _t('برچسب %s'),
        'author'    =>  _t('نویسنده %s'),
        'date'      =>  _t('آرشیو %s'),
    ), '', ' - '); ?><?php $options->title(); ?></title>

    <meta name="description" content="<?php $options->description(); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($options->keywords ?? ''); ?>">
    <meta name="author" content="<?php $options->title(); ?>">

    <!-- Open Graph -->
    <meta property="og:title" content="<?php 
    if ($this->is('search') && !$this->have()) {
        echo 'نتیجه جستجو: ' . htmlspecialchars($this->request->get('s', ''));
    } else {
        $this->title();
    }
    ?>">
    <meta property="og:description" content="<?php 
    if ($this->is('search') && !$this->have()) {
        echo 'جستجوی ' . htmlspecialchars($this->request->get('s', '')) . ' نتیجه‌ای نداشت';
    } else {
        echo htmlspecialchars($this->excerpt(100, ''));
    }
    ?>">

    <!-- Favicon -->
    <?php if($options->favicon): ?>
    <link rel="icon" href="<?php echo htmlspecialchars($options->favicon, ENT_QUOTES); ?>" type="image/x-icon">
    <link rel="apple-touch-icon" href="<?php echo htmlspecialchars($options->favicon, ENT_QUOTES); ?>">
    <?php else: ?>
    <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%232563eb'/%3E%3Ctext x='32' y='44' font-size='36' font-weight='bold' text-anchor='middle' fill='white' font-family='sans-serif'%3E%D9%86%3C/text%3E%3C/svg%3E" type="image/svg+xml">
    <?php endif; ?>

    <!-- Fonts -->
    <!-- ---------- فونت وزیرمتن (آفلاین) ---------- -->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/fonts.css'); ?>?v=<?php echo $nvtVersion; ?>">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="<?php $options->themeUrl('style.css'); ?>?v=<?php echo $nvtVersion; ?>">

    <!-- RSS Feed -->
    <link rel="alternate" type="application/rss+xml" title="<?php $options->title(); ?>" href="<?php $options->feedUrl(); ?>">

    <!-- Custom Header Code -->
    <?php if($options->header_code): ?>
    <?php echo $options->header_code; ?>
    <?php endif; ?>

    <!-- Typecho Header Hook -->
    <?php $this->header(); ?>
</head>
<body class="farsi-digits <?php if($this->is('index')): ?>home<?php elseif($this->is('post')): ?>single<?php elseif($this->is('page')): ?>page<?php elseif($this->is('archive')): ?>archive<?php endif; ?>">

    <!-- Header -->
    <header class="site-header" id="site-header">
        <div class="container">
            <!-- Logo -->
            <div class="site-logo">
                <a href="<?php $options->siteUrl(); ?>">
                    <?php if($options->logo): ?>
                    <img src="<?php echo $options->logo; ?>" alt="<?php $options->title(); ?>" class="logo-image">
                    <?php else: ?>
                    <div class="logo-icon">
                        <span>ن</span>
                    </div>
                    <?php endif; ?>
                    <span class="logo-text"><?php $options->title(); ?></span>
                </a>
            </div>

            <!-- Desktop Navigation -->
            <nav class="main-nav" id="main-nav">
                <ul class="nav-menu">
                    <li class="nav-item <?php if($this->is('index')): ?>active<?php endif; ?>">
                        <a href="<?php $options->siteUrl(); ?>">خانه</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php $options->siteUrl(); ?>#services">خدمات</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php $options->siteUrl(); ?>#about">درباره ما</a>
                    </li>
                    <li class="nav-item <?php if(novintech_is_blog_context() && !$nvtOnHome): ?>active<?php endif; ?>">
                        <a href="<?php echo htmlspecialchars($nvtBlogNav, ENT_QUOTES); ?>">وبلاگ</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php $options->siteUrl(); ?>#contact">تماس با ما</a>
                    </li>
                </ul>
            </nav>

            <!-- Header CTA -->
            <div class="header-cta">
                <a href="<?php $options->siteUrl(); ?>#booking" class="btn btn-primary btn-sm">
                    شروع پروژه
                    <?php echo novintech_icon('arrow', 15); ?>
                </a>
            </div>

            <!-- Mobile Menu Toggle -->
            <button class="mobile-menu-toggle" id="mobile-menu-toggle" aria-label="منو">
                <span class="hamburger-line"></span>
                <span class="hamburger-line"></span>
                <span class="hamburger-line"></span>
            </button>
        </div>

        <!-- Mobile Navigation -->
        <div class="mobile-nav" id="mobile-nav">
            <div class="mobile-nav-inner">
                <div class="mobile-nav-header">
                    <div class="site-logo">
                        <?php if($options->logo): ?>
                        <img src="<?php echo $options->logo; ?>" alt="<?php $options->title(); ?>" class="logo-image" style="height: 40px; width: auto;">
                        <?php else: ?>
                        <div class="logo-icon">
                            <span>ن</span>
                        </div>
                        <?php endif; ?>
                        <span class="logo-text"><?php $options->title(); ?></span>
                    </div>
                    <button class="mobile-nav-close" id="mobile-nav-close" aria-label="بستن">
                        <?php echo novintech_icon('x', 22); ?>
                    </button>
                </div>
                <ul class="mobile-nav-menu">
                    <li>
                        <a href="<?php $options->siteUrl(); ?>">
                            <?php echo novintech_icon('chevron-left', 16); ?>
                            خانه
                        </a>
                    </li>
                    <li>
                        <a href="<?php $options->siteUrl(); ?>#services">
                            <?php echo novintech_icon('chevron-left', 16); ?>
                            خدمات
                        </a>
                    </li>
                    <li>
                        <a href="<?php $options->siteUrl(); ?>#about">
                            <?php echo novintech_icon('chevron-left', 16); ?>
                            درباره ما
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo htmlspecialchars($nvtBlogNav, ENT_QUOTES); ?>">
                            <?php echo novintech_icon('chevron-left', 16); ?>
                            وبلاگ
                        </a>
                    </li>
                    <li>
                        <a href="<?php $options->siteUrl(); ?>#contact">
                            <?php echo novintech_icon('chevron-left', 16); ?>
                            تماس با ما
                        </a>
                    </li>
                </ul>
                <div class="mobile-nav-cta">
                    <a href="<?php $options->siteUrl(); ?>#booking" class="btn btn-primary btn-block">
                        شروع پروژه
                        <?php echo novintech_icon('arrow', 15); ?>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="site-main" id="site-main">
