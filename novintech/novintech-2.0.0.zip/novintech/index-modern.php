<?php
/**
 * لندینگ مدرن نوین‌تک — طرح شیشه‌ای + گرادیان
 * این فایل از تنظیمات پوسته قابل انتخاب است (قالب صفحهٔ اول → مدرن)
 *
 * @package نوین‌تک
 * @author پوردریایی
 * @version 1.2.1
 * @link https://pourdaryaei.ir
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$options  = $this->options;
$nvtHome  = rtrim((string)$options->siteUrl, '/') . '/';
$nvtBlog  = novintech_blog_url();

/* ---------- محتوای قابل ویرایش ---------- */
$nvtBadge    = novintech_opt('novintechHeroBadge', 'راهکارهای دیجیتال پیشرفته');
$nvtTitle    = novintech_opt('novintechHeroTitle', 'آینده کسب‌وکار شما در دستان ماست');
$nvtSubtitle = novintech_opt('novintechHeroSubtitle', 'با بهره‌گیری از جدیدترین تکنولوژی‌ها و تیم مجرب، کسب‌وکار شما را به سطح بالاتری می‌بریم. از طراحی وب تا هوش مصنوعی، همراه شما هستیم.');
$nvtPrimary   = novintech_opt('novintechHeroPrimary', 'شروع همکاری');
$nvtSecondary = novintech_opt('novintechHeroSecondary', 'مشاهده خدمات');

$nvtServices = novintech_parse_lines(novintech_opt('novintechServices'), 3);
if (empty($nvtServices)) {
    $nvtServices = array(
        array('توسعه وب', 'طراحی و توسعه وب‌سایت‌های مدرن، سریع و امن', 'code'),
        array('اپلیکیشن موبایل', 'ساخت اپلیکیشن‌های چندپلتفرمی و بومی', 'mobile'),
        array('طراحی UI/UX', 'رابط کاربری زیبا و تجربهٔ کاربری عالی', 'pen'),
    );
}

$nvtStats = novintech_parse_lines(novintech_opt('novintechStats'), 2);
if (empty($nvtStats)) {
    $nvtStats = array(
        array('+۲۵۰', 'پروژهٔ موفق'),
        array('+۱۸۰', 'مشتری راضی'),
        array('+۱۲', 'سال تجربه'),
        array('۹۸٪', 'رضایت مشتری'),
    );
}

$nvtAboutTitle  = novintech_opt('novintechAboutTitle', 'چرا نوین‌تک را انتخاب کنید؟');
$nvtAboutText   = novintech_opt('novintechAboutText', '');
$nvtAboutPoints = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', novintech_opt('novintechAboutPoints'))));

$nvtCtaTitle  = novintech_opt('novintechCtaTitle', 'آمادهٔ شروع تحول دیجیتال هستید؟');
$nvtCtaText   = novintech_opt('novintechCtaText', '');
$nvtCtaButton = novintech_opt('novintechCtaButton', 'درخواست مشاورهٔ رایگان');

/* عنوان هیرو: بخش *ستاره‌دار* با گرادیان رنگی می‌شود */
$nvtTitleHtml = htmlspecialchars($nvtTitle, ENT_QUOTES);
if (preg_match('/\*([^*]+)\*/', $nvtTitle, $nvtM)) {
    $nvtTitleHtml = str_replace(
        array('*' . $nvtM[1] . '*', $nvtM[1]),
        '<span class="nvt-grad">' . htmlspecialchars($nvtM[1], ENT_QUOTES) . '</span>',
        htmlspecialchars($nvtTitle, ENT_QUOTES)
    );
}
?>

<div class="nvt-modern" id="nvt-top">

    <!-- ================= هیرو شیشه‌ای ================= -->
    <section class="nvt-hero">
        <div class="nvt-hero-bg" aria-hidden="true">
            <div class="nvt-blob nvt-blob-1"></div>
            <div class="nvt-blob nvt-blob-2"></div>
            <div class="nvt-blob nvt-blob-3"></div>
            <div class="nvt-grid-lines"></div>
        </div>

        <div class="nvt-container nvt-hero-grid">
            <div class="nvt-hero-text">
                <span class="nvt-chip">
                    <?php echo novintech_icon('rocket', 15); ?>
                    <?php echo htmlspecialchars($nvtBadge, ENT_QUOTES); ?>
                </span>

                <h1 class="nvt-hero-title"><?php echo $nvtTitleHtml; ?></h1>

                <p class="nvt-hero-sub"><?php echo htmlspecialchars($nvtSubtitle, ENT_QUOTES); ?></p>

                <div class="nvt-hero-actions">
                    <a href="#booking" class="nvt-btn nvt-btn-primary">
                        <?php echo htmlspecialchars($nvtPrimary, ENT_QUOTES); ?>
                        <?php echo novintech_icon('arrow', 17); ?>
                    </a>
                    <a href="#services" class="nvt-btn nvt-btn-glass">
                        <?php echo htmlspecialchars($nvtSecondary, ENT_QUOTES); ?>
                    </a>
                </div>

                <div class="nvt-hero-trust">
                    <span class="nvt-trust-stars" aria-hidden="true">
                        <?php echo novintech_icon('star', 15, 'nvt-star'); ?>
                        <?php echo novintech_icon('star', 15, 'nvt-star'); ?>
                        <?php echo novintech_icon('star', 15, 'nvt-star'); ?>
                        <?php echo novintech_icon('star', 15, 'nvt-star'); ?>
                        <?php echo novintech_icon('star', 15, 'nvt-star'); ?>
                    </span>
                    <div class="nvt-trust-text">
                        <strong>«۳۰۰+ متخصص و کارفرما»</strong>
                        <span>به راهکارهای ما اعتماد کرده‌اند</span>
                    </div>
                </div>
            </div>

            <div class="nvt-hero-visual" aria-hidden="true">
                <!-- صحنهٔ پویا: شاتل نوین‌تک در حال حرکت (نسخهٔ ۱٫۲٫۱) -->
                <div class="nvt-shuttle-scene">
                    <svg class="nvt-ss-svg" viewBox="0 0 360 400" xmlns="http://www.w3.org/2000/svg" focusable="false">
                        <defs>
                            <linearGradient id="nvtSSBody" x1="0" y1="0" x2="1" y2="0">
                                <stop offset="0" stop-color="#dbe7fd"/>
                                <stop offset=".5" stop-color="#ffffff"/>
                                <stop offset="1" stop-color="#c3d9fb"/>
                            </linearGradient>
                            <linearGradient id="nvtSSNose" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0" stop-color="#60a5fa"/>
                                <stop offset="1" stop-color="#2563eb"/>
                            </linearGradient>
                            <linearGradient id="nvtSSFin" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0" stop-color="#3b82f6"/>
                                <stop offset="1" stop-color="#1e40af"/>
                            </linearGradient>
                            <linearGradient id="nvtSSFlame" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0" stop-color="#fbbf24"/>
                                <stop offset=".55" stop-color="#f97316"/>
                                <stop offset="1" stop-color="#f97316" stop-opacity="0"/>
                            </linearGradient>
                            <linearGradient id="nvtSSFlameCore" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0" stop-color="#fef9c3"/>
                                <stop offset="1" stop-color="#fbbf24" stop-opacity="0"/>
                            </linearGradient>
                            <radialGradient id="nvtSSGlow" cx=".5" cy=".5" r=".5">
                                <stop offset="0" stop-color="#60a5fa" stop-opacity=".30"/>
                                <stop offset="1" stop-color="#60a5fa" stop-opacity="0"/>
                            </radialGradient>
                            <linearGradient id="nvtSSPlanet" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0" stop-color="#3b82f6"/>
                                <stop offset="1" stop-color="#1e3a8a"/>
                            </linearGradient>
                            <radialGradient id="nvtSSAtmo" cx=".5" cy=".25" r=".6">
                                <stop offset="0" stop-color="#93c5fd" stop-opacity=".55"/>
                                <stop offset="1" stop-color="#93c5fd" stop-opacity="0"/>
                            </radialGradient>
                        </defs>

                        <!-- هالهٔ نور پشت شاتل -->
                        <circle class="nvt-ss-glow" cx="180" cy="140" r="105" fill="url(#nvtSSGlow)"/>

                        <!-- میدان ستاره‌ها -->
                        <g class="nvt-ss-stars">
                            <circle cx="42" cy="58" r="2" fill="#93c5fd"/>
                            <circle cx="305" cy="84" r="1.6" fill="#bfdbfe"/>
                            <circle cx="66" cy="252" r="1.7" fill="#93c5fd"/>
                            <circle cx="312" cy="212" r="2.2" fill="#60a5fa"/>
                            <circle cx="252" cy="36" r="1.4" fill="#bfdbfe"/>
                            <circle cx="28" cy="168" r="1.3" fill="#bfdbfe"/>
                            <circle cx="332" cy="302" r="1.5" fill="#93c5fd"/>
                            <circle cx="96" cy="112" r="1.2" fill="#bfdbfe"/>
                            <path class="nvt-ss-spark" transform="translate(296 132)" d="M0,-7 L1.8,-1.8 L7,0 L1.8,1.8 L0,7 L-1.8,1.8 L-7,0 L-1.8,-1.8 Z" fill="#60a5fa"/>
                            <path class="nvt-ss-spark" transform="translate(56 108)" d="M0,-6 L1.6,-1.6 L6,0 L1.6,1.6 L0,6 L-1.6,1.6 L-6,0 L-1.6,-1.6 Z" fill="#93c5fd"/>
                        </g>

                        <!-- مدار گردش و ماهواره -->
                        <g transform="rotate(-12 180 195)">
                            <circle class="nvt-ss-orbit-ring" cx="180" cy="195" r="128" fill="none" stroke="rgba(37,99,235,.30)" stroke-width="1.5" stroke-dasharray="5 9"/>
                            <g class="nvt-ss-orbit-spin">
                                <g transform="translate(308 195)">
                                    <rect x="-15" y="-6" width="9" height="12" rx="1.5" fill="#3b82f6"/>
                                    <rect x="6" y="-6" width="9" height="12" rx="1.5" fill="#3b82f6"/>
                                    <circle r="6" fill="#1d4ed8"/>
                                    <circle r="6" fill="none" stroke="#93c5fd" stroke-width="1" opacity=".8"/>
                                </g>
                            </g>
                        </g>

                        <!-- خطوط سرعت -->
                        <g class="nvt-ss-speed" stroke="#93c5fd" stroke-width="2.5" stroke-linecap="round" fill="none" opacity=".55">
                            <path class="nvt-ss-speed-line" d="M112,66 L112,116"/>
                            <path class="nvt-ss-speed-line" d="M250,80 L250,118"/>
                            <path class="nvt-ss-speed-line" d="M84,180 L84,214"/>
                            <path class="nvt-ss-speed-line" d="M278,170 L278,208"/>
                        </g>

                        <!-- سیاره در پایین صحنه -->
                        <g class="nvt-ss-planet">
                            <circle cx="180" cy="600" r="215" fill="url(#nvtSSAtmo)"/>
                            <circle cx="180" cy="600" r="200" fill="url(#nvtSSPlanet)"/>
                            <path d="M20,412 C70,438 290,438 340,412" stroke="rgba(191,219,254,.5)" stroke-width="3" fill="none" stroke-linecap="round"/>
                        </g>

                        <!-- شاتل در حال حرکت -->
                        <g transform="translate(180 168) rotate(-8)">
                            <g class="nvt-ss-bob">
                                <rect x="-31" y="6" width="11" height="46" rx="5" fill="url(#nvtSSNose)" opacity=".9"/>
                                <rect x="20" y="6" width="11" height="46" rx="5" fill="url(#nvtSSNose)" opacity=".9"/>
                                <path d="M-18,26 L-36,64 L-18,56 Z" fill="url(#nvtSSFin)"/>
                                <path d="M18,26 L36,64 L18,56 Z" fill="url(#nvtSSFin)"/>
                                <rect x="-18" y="-44" width="36" height="106" rx="10" fill="url(#nvtSSBody)"/>
                                <path d="M0,-100 C13,-80 18,-60 18,-42 L-18,-42 C-18,-60 -13,-80 0,-100 Z" fill="url(#nvtSSNose)"/>
                                <circle cx="0" cy="-14" r="12.5" fill="#dbeafe" stroke="#93c5fd" stroke-width="3"/>
                                <circle cx="0" cy="-14" r="7" fill="url(#nvtSSNose)"/>
                                <rect x="-18" y="8" width="36" height="5" fill="#2563eb" opacity=".85"/>
                                <text class="nvt-ss-name" x="0" y="27" text-anchor="middle">نوین‌تک ۱</text>
                                <path d="M-11,62 L11,62 L8,74 L-8,74 Z" fill="#334155"/>
                                <g class="nvt-ss-flame">
                                    <path d="M-9,74 C-13,94 -6,110 0,126 C6,110 13,94 9,74 Z" fill="url(#nvtSSFlame)"/>
                                    <path d="M-4,74 C-6,86 -3,96 0,104 C3,96 6,86 4,74 Z" fill="url(#nvtSSFlameCore)"/>
                                </g>
                                <g class="nvt-ss-smoke" fill="#cbd5e1">
                                    <circle cx="-4" cy="132" r="4" opacity=".5"/>
                                    <circle cx="5" cy="146" r="5.5" opacity=".35"/>
                                    <circle cx="-2" cy="162" r="7" opacity=".2"/>
                                </g>
                            </g>
                        </g>
                    </svg>
                </div>

                <div class="nvt-glass nvt-float nvt-float-1">
                    <?php echo novintech_icon('chart', 20); ?>
                    <div>
                        <strong>رشد ۳۸٪</strong>
                        <span>میانگین مشتریان</span>
                    </div>
                </div>

                <div class="nvt-glass nvt-float nvt-float-2">
                    <?php echo novintech_icon('shield', 20); ?>
                    <div>
                        <strong>امنیت</strong>
                        <span>استاندارد بین‌المللی</span>
                    </div>
                </div>

                <div class="nvt-glass nvt-float nvt-float-3">
                    <?php echo novintech_icon('clock', 20); ?>
                    <div>
                        <strong>پشتیبانی ۲۴/۷</strong>
                        <span>همیشه در دسترس</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="nvt-hero-wave" aria-hidden="true">
            <svg viewBox="0 0 1440 70" preserveAspectRatio="none"><path d="M0,35 C240,70 480,0 720,30 C960,60 1200,10 1440,40 L1440,70 L0,70 Z" fill="currentColor"/></svg>
        </div>
    </section>

    <!-- ================= نوار آمار ================= -->
    <section class="nvt-stats-band">
        <div class="nvt-container nvt-stats-grid">
            <?php foreach ($nvtStats as $nvtStat): ?>
            <div class="nvt-stat">
                <span class="nvt-stat-num"><?php echo htmlspecialchars($nvtStat[0], ENT_QUOTES); ?></span>
                <span class="nvt-stat-label"><?php echo htmlspecialchars($nvtStat[1], ENT_QUOTES); ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- ================= خدمات ================= -->
    <section id="services" class="nvt-section">
        <div class="nvt-container">
            <div class="nvt-sec-head">
                <span class="nvt-sec-badge"><?php echo novintech_icon('spark', 14); ?> خدمات ما</span>
                <h2 class="nvt-sec-title">چه خدماتی ارائه می‌دهیم؟</h2>
                <p class="nvt-sec-desc">طیف گسترده‌ای از خدمات دیجیتال برای پوشش کامل نیازهای کسب‌وکار شما</p>
            </div>

            <div class="nvt-services">
                <?php foreach ($nvtServices as $nvtSvc): ?>
                <div class="nvt-service nvt-glass">
                    <div class="nvt-service-icon"><?php echo novintech_icon($nvtSvc[2], 24); ?></div>
                    <h3 class="nvt-service-title"><?php echo htmlspecialchars($nvtSvc[0], ENT_QUOTES); ?></h3>
                    <p class="nvt-service-desc"><?php echo htmlspecialchars($nvtSvc[1], ENT_QUOTES); ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- ================= دربارهٔ ما ================= -->
    <section id="about" class="nvt-section nvt-about-section">
        <div class="nvt-container nvt-about-grid">
            <div class="nvt-about-visual">
                <div class="nvt-glass nvt-about-panel">
                    <div class="nvt-about-ring">
                        <span class="nvt-ring-num">+۱۲</span>
                        <span class="nvt-ring-label">سال تجربه</span>
                    </div>
                    <ul class="nvt-about-ticks">
                        <li><?php echo novintech_icon('check', 15); ?> تیم متخصص</li>
                        <li><?php echo novintech_icon('check', 15); ?> تحویل به‌موقع</li>
                        <li><?php echo novintech_icon('check', 15); ?> پشتیبانی ۲۴/۷</li>
                    </ul>
                </div>
                <div class="nvt-glass nvt-float nvt-about-float">
                    <?php echo novintech_icon('award', 22); ?>
                    <div>
                        <strong>۹۸٪</strong>
                        <span>رضایت مشتری</span>
                    </div>
                </div>
            </div>

            <div class="nvt-about-text">
                <span class="nvt-sec-badge"><?php echo novintech_icon('users', 14); ?> دربارهٔ ما</span>
                <h2 class="nvt-sec-title"><?php echo htmlspecialchars($nvtAboutTitle, ENT_QUOTES); ?></h2>
                <p class="nvt-about-p"><?php echo htmlspecialchars($nvtAboutText, ENT_QUOTES); ?></p>
                <?php if (!empty($nvtAboutPoints)): ?>
                <ul class="nvt-points">
                    <?php foreach ($nvtAboutPoints as $nvtPoint): ?>
                    <li><?php echo novintech_icon('check', 16); ?> <?php echo htmlspecialchars($nvtPoint, ENT_QUOTES); ?></li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- ================= وبلاگ ================= -->
    <section id="blog" class="nvt-section">
        <div class="nvt-container">
            <div class="nvt-sec-head">
                <span class="nvt-sec-badge"><?php echo novintech_icon('doc', 14); ?> وبلاگ</span>
                <h2 class="nvt-sec-title">آخرین مطالب وبلاگ</h2>
                <p class="nvt-sec-desc">جدیدترین مقالات و اخبار دنیای فناوری را در وبلاگ ما بخوانید</p>
            </div>

            <div class="nvt-posts">
                <?php
                $nvtRecent = $this->widget('Widget_Contents_Post_Recent', 'pageSize=3');
                if ($nvtRecent->have()):
                    while ($nvtRecent->next()):
                        $nvtThumb = novintech_thumb($nvtRecent);
                ?>
                <article class="nvt-post nvt-glass">
                    <a href="<?php $nvtRecent->permalink(); ?>" class="nvt-post-link">
                        <div class="nvt-post-thumb<?php if ($nvtThumb === ''): ?> nvt-post-thumb-empty<?php endif; ?>">
                            <?php if ($nvtThumb !== ''): ?>
                            <img src="<?php echo htmlspecialchars($nvtThumb, ENT_QUOTES); ?>" alt="<?php $nvtRecent->title(); ?>" loading="lazy">
                            <?php else: ?>
                            <?php echo novintech_icon('doc', 30); ?>
                            <?php endif; ?>
                        </div>
                        <div class="nvt-post-body">
                            <div class="nvt-post-meta">
                                <span class="nvt-post-cat"><?php $nvtRecent->category(',', false); ?></span>
                                <span class="nvt-post-date"><?php echo jdate('j F Y', $nvtRecent->created); ?></span>
                            </div>
                            <h3 class="nvt-post-title"><?php $nvtRecent->title(); ?></h3>
                            <p class="nvt-post-excerpt"><?php $nvtRecent->excerpt(90, '…'); ?></p>
                            <span class="nvt-post-more">ادامهٔ مطلب <?php echo novintech_icon('arrow', 15); ?></span>
                        </div>
                    </a>
                </article>
                <?php
                    endwhile;
                else:
                ?>
                <p class="nvt-empty">هنوز مطلبی منتشر نشده است.</p>
                <?php endif; ?>
            </div>

            <div class="nvt-posts-all">
                <a href="<?php echo htmlspecialchars($nvtBlog, ENT_QUOTES); ?>" class="nvt-btn nvt-btn-primary">
                    مشاهدهٔ همهٔ مقالات
                    <?php echo novintech_icon('arrow', 17); ?>
                </a>
            </div>
        </div>
    </section>

    <!-- ================= دعوت پایانی ================= -->
    <section class="nvt-cta">
        <div class="nvt-container">
            <div class="nvt-cta-card">
                <h2 class="nvt-cta-title"><?php echo htmlspecialchars($nvtCtaTitle, ENT_QUOTES); ?></h2>
                <p class="nvt-cta-text"><?php echo htmlspecialchars($nvtCtaText, ENT_QUOTES); ?></p>
                <a href="#booking" class="nvt-btn nvt-btn-white">
                    <?php echo htmlspecialchars($nvtCtaButton, ENT_QUOTES); ?>
                    <?php echo novintech_icon('arrow', 17); ?>
                </a>
            </div>
        </div>
    </section>

    <!-- ================= درخواست مشاورهٔ رایگان (بوکینگ — الگوی نهال/الناز) ================= -->
    <?php
    $nvtBookingTitle    = novintech_opt('novintechBookingTitle', 'درخواست مشاورهٔ رایگان');
    $nvtBookingSubtitle = novintech_opt('novintechBookingSubtitle', 'فرم را پر کنید؛ کارشناسان ما در اولین فرصت برای هماهنگی جلسهٔ مشاورهٔ رایگان با شما تماس می‌گیرند.');
    $nvtBookingServices = array_filter(array_map('trim', explode(',', (string)novintech_opt('novintechBookingServices', 'توسعه وب, اپلیکیشن موبایل, طراحی UI/UX, دیجیتال مارکتینگ, خدمات ابری, امنیت سایبری, مشاورهٔ عمومی'))));
    $nvtBookingAction = novintech_booking_endpoint();
    $nvtBookingToken = '';
    try {
        $nvtBookingToken = htmlspecialchars(\Widget\Security::alloc()->getToken($this->request->getRequestUrl()), ENT_QUOTES, 'UTF-8');
    } catch (\Throwable $e) {
        $nvtBookingToken = '';
    }
    ?>
    <section id="booking" class="nvt-section nvt-booking">
        <div class="nvt-container">
            <div class="nvt-sec-head">
                <span class="nvt-sec-badge"><?php echo novintech_icon('calendar-check', 14); ?> شروع رایگان</span>
                <h2 class="nvt-sec-title"><?php echo htmlspecialchars($nvtBookingTitle, ENT_QUOTES); ?></h2>
                <p class="nvt-sec-desc"><?php echo htmlspecialchars($nvtBookingSubtitle, ENT_QUOTES); ?></p>
            </div>

            <div class="bk-split">
                <div class="bk-panel">
                    <div class="bk-panel-head">
                        <span class="bk-panel-ic"><?php echo novintech_icon('calendar-check', 48); ?></span>
                        <div>
                            <strong>فرم درخواست مشاوره</strong>
                            <span>کمتر از یک دقیقه طول می‌کشد</span>
                        </div>
                    </div>
                    <form class="bk-form" id="bookingForm" method="post" action="<?php echo htmlspecialchars($nvtBookingAction, ENT_QUOTES); ?>" novalidate>
                        <input type="hidden" name="novintechBooking" value="1">
                        <?php if ($nvtBookingToken !== ''): ?>
                        <input type="hidden" name="_" value="<?php echo $nvtBookingToken; ?>">
                        <?php endif; ?>

                        <!-- تلهٔ هرزنامه — باید خالی بماند -->
                        <input type="text" name="novintechHp" class="hp-field" tabindex="-1" autocomplete="off" aria-hidden="true">

                        <div class="bk-form-row">
                            <div class="bk-field">
                                <label for="novintechName">نام و نام خانوادگی <span class="req">*</span></label>
                                <input type="text" id="novintechName" name="novintechName" class="bk-input" placeholder="مثلاً: آرش رضایی" required>
                            </div>
                            <div class="bk-field">
                                <label for="novintechPhone">شمارهٔ تلفن همراه <span class="req">*</span></label>
                                <input type="tel" id="novintechPhone" name="novintechPhone" class="bk-input" placeholder="۰۹۱۲۳۴۵۶۷۸۹" required>
                            </div>
                        </div>

                        <div class="bk-form-row">
                            <div class="bk-field">
                                <label for="novintechMail">ایمیل (اختیاری)</label>
                                <input type="email" id="novintechMail" name="novintechMail" class="bk-input" placeholder="you@example.com" dir="ltr">
                            </div>
                            <?php if (!empty($nvtBookingServices)): ?>
                            <div class="bk-field">
                                <label for="novintechService">خدمت موردنیاز</label>
                                <select id="novintechService" name="novintechService" class="bk-input bk-select">
                                    <option value="">انتخاب کنید…</option>
                                    <?php foreach ($nvtBookingServices as $nvtBookingService): ?>
                                    <option value="<?php echo htmlspecialchars($nvtBookingService, ENT_QUOTES); ?>"><?php echo htmlspecialchars($nvtBookingService, ENT_QUOTES); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="bk-field">
                            <label for="novintechNote">توضیحات پروژه (اختیاری)</label>
                            <textarea id="novintechNote" name="novintechNote" class="bk-input" rows="3" placeholder="کسب‌وکار شما، ایده، یا هر نکته‌ای که لازم است بدانیم…"></textarea>
                        </div>

                        <button type="submit" class="bk-submit" id="bookingSubmitBtn">
                            <?php echo novintech_icon('send', 17); ?>
                            <span>ثبت درخواست مشاورهٔ رایگان</span>
                        </button>

                        <p class="bk-note">
                            <?php echo novintech_icon('shield-check', 13); ?>
                            اطلاعات شما محفوظ است و فقط برای هماهنگی جلسهٔ مشاوره استفاده می‌شود.
                        </p>

                        <div class="bk-alert bk-alert-success" id="bookingSuccess" hidden>
                            <?php echo novintech_icon('check-circle', 20); ?>
                            <div>
                                <strong>درخواست شما ثبت شد!</strong>
                                <span>کارشناسان ما در اولین فرصت با شما تماس می‌گیرند.</span>
                            </div>
                        </div>
                        <div class="bk-alert bk-alert-error" id="bookingError" hidden>
                            <?php echo novintech_icon('x', 20); ?>
                            <div>
                                <strong>خطا در ثبت درخواست!</strong>
                                <span id="bookingErrorText">لطفاً دوباره تلاش کنید.</span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- ================= تماس ================= -->
    <?php
    /* اطلاعات تماس: اول تنظیمات مدیر، بعد مقدار دمو (نسخهٔ ۱٫۲٫۱) */
    $nvtContactPhone    = novintech_contact('contact_phone', novintech_contact_demo('contact_phone'));
    $nvtContactMail     = novintech_contact('contact_email', novintech_contact_demo('contact_email'));
    $nvtContactAddress  = novintech_contact('contact_address', novintech_contact_demo('contact_address'));
    $nvtSocialInstagram = novintech_contact('social_instagram', novintech_contact_demo('social_instagram'));
    $nvtSocialTelegram  = novintech_contact('social_telegram', novintech_contact_demo('social_telegram'));
    $nvtSocialTwitter   = novintech_contact('social_twitter', novintech_contact_demo('social_twitter'));
    $nvtSocialLinkedin  = novintech_contact('social_linkedin', novintech_contact_demo('social_linkedin'));
    ?>
    <section id="contact" class="nvt-section nvt-contact">
        <div class="nvt-container">
            <div class="nvt-sec-head">
                <span class="nvt-sec-badge"><?php echo novintech_icon('users', 14); ?> تماس با ما</span>
                <h2 class="nvt-sec-title">ارتباط با ما</h2>
                <p class="nvt-sec-desc">برای شروع همکاری از راه‌های زیر با ما در تماس باشید</p>
            </div>

            <div class="nvt-contact-grid">
                <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $nvtContactPhone), ENT_QUOTES); ?>" class="nvt-contact-card nvt-glass">
                    <span class="nvt-contact-icon"><?php echo novintech_icon('phone', 22); ?></span>
                    <span class="nvt-contact-label">تلفن</span>
                    <span class="nvt-contact-value" dir="ltr"><?php echo novintech_fa_digits(htmlspecialchars($nvtContactPhone, ENT_QUOTES)); ?></span>
                </a>

                <a href="mailto:<?php echo htmlspecialchars($nvtContactMail, ENT_QUOTES); ?>" class="nvt-contact-card nvt-glass">
                    <span class="nvt-contact-icon"><?php echo novintech_icon('mail', 22); ?></span>
                    <span class="nvt-contact-label">ایمیل</span>
                    <span class="nvt-contact-value" dir="ltr"><?php echo htmlspecialchars($nvtContactMail, ENT_QUOTES); ?></span>
                </a>

                <div class="nvt-contact-card nvt-glass">
                    <span class="nvt-contact-icon"><?php echo novintech_icon('map-pin', 22); ?></span>
                    <span class="nvt-contact-label">آدرس</span>
                    <span class="nvt-contact-value"><?php echo htmlspecialchars($nvtContactAddress, ENT_QUOTES); ?></span>
                </div>
            </div>

            <div class="nvt-social-row">
                <a href="<?php echo htmlspecialchars($nvtSocialInstagram, ENT_QUOTES); ?>" target="_blank" rel="noopener" class="nvt-social">اینستاگرام</a>
                <a href="<?php echo htmlspecialchars($nvtSocialTelegram, ENT_QUOTES); ?>" target="_blank" rel="noopener" class="nvt-social">تلگرام</a>
                <a href="<?php echo htmlspecialchars($nvtSocialTwitter, ENT_QUOTES); ?>" target="_blank" rel="noopener" class="nvt-social">توییتر</a>
                <a href="<?php echo htmlspecialchars($nvtSocialLinkedin, ENT_QUOTES); ?>" target="_blank" rel="noopener" class="nvt-social">لینکدین</a>
            </div>
        </div>
    </section>
</div>

<?php $this->need('footer.php'); ?>
