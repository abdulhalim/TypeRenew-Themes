<?php
/**
 * Comments Template
 *
 * @package NovinTech Theme
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * تابع بازگشتی برای رندر کردن کامنت و تمام فرزندانش
 */
function renderCommentRecursive($c, $options, $adminEmail, $postAuthorId) {
    
    // ---------- محاسبه و نمایش آواتار ----------
    $avatarUrl = '';
    $commenterEmail = '';
    
    if (is_array($c)) {
        $commenterEmail = isset($c['mail']) ? $c['mail'] : 'guest@example.com';
    } else {
        $commenterEmail = $c->mail ?: 'guest@example.com';
    }
    
    $isAuthor = false;
    if (is_array($c)) {
        $isAuthor = isset($c['authorId']) && $c['authorId'] == $postAuthorId;
    } else {
        $isAuthor = $c->authorId == $postAuthorId;
    }

    $avatarUrl = 'https://www.gravatar.com/avatar/' . md5(strtolower($commenterEmail)) . '?s=60&d=mp&r=g';

    // ---------- دریافت اطلاعات کامنت (آرایه یا آبجکت) ----------
    $authorName = is_array($c) ? $c['author'] : $c->author;
    $commentContent = is_array($c) ? $c['text'] : $c->content;
    $commentId = is_array($c) ? $c['coid'] : $c->coid;
    $commentCreated = is_array($c) ? $c['created'] : $c->created;

    // فیلتر متن پاسخ‌ها (سازگار با سیاست هسته — فقط تگ‌های مجاز)
    if (is_string($commentContent)) {
        try {
            $allowed = '<p><br>' . \Widget\Options::alloc()->commentsHTMLTagAllowed;
            $commentContent = \Typecho\Common::stripTags($commentContent, $allowed);
        } catch (\Throwable $e) {
            $commentContent = htmlspecialchars($commentContent, ENT_QUOTES);
        }
    }
    
    // ---------- محاسبه سطح کامنت ----------
    $currentLevel = 0;
    if (is_array($c)) {
        $currentLevel = isset($c['myCustomLevel']) ? $c['myCustomLevel'] : 0;
    } else {
        $currentLevel = $c->levels;
    }

    $is_reply = $currentLevel > 0;
    $reply_class = $is_reply ? ' comment-reply' : '';
    
    $reply_style = '';
    if ($is_reply) {
        $margin = min(($currentLevel * 30), 60); 
        $reply_style = 'margin-right: ' . $margin . 'px;';
    }
    
    ?>
    
    <div id="comment-<?php echo $commentId; ?>" class="comment-item<?php echo $reply_class; ?>" style="<?php echo $reply_style; ?>">
        
        <!-- ---------- آواتار ---------- -->
        <div class="comment-avatar">
            <img src="<?php echo $avatarUrl; ?>" alt="<?php echo htmlspecialchars($authorName); ?>" width="50" height="50">
        </div>
        
        <!-- ---------- بدنه کامنت ---------- -->
        <div class="comment-body">
            <div class="comment-header">
                <div class="comment-author">
                    <span class="author-name"><?php echo htmlspecialchars($authorName ?? ''); ?></span>
                    <?php if ($isAuthor): ?>
                    <span class="author-badge">نویسنده</span>
                    <?php endif; ?>
                </div>
                <div class="comment-meta">
                    <time datetime="<?php echo date('c', $commentCreated); ?>">
                        <?php echo jdate('j F Y', $commentCreated); ?>
                    </time>
                </div>
            </div>
            
            <div class="comment-text">
                <?php echo $commentContent; ?>
            </div>
            
            <!-- ---------- دکمه پاسخ (فقط سطح ۰ و ۱) ---------- -->
            <?php if ($currentLevel < 2): ?>
            <div class="comment-actions">
                <button type="button" class="reply-btn" onclick="return TypechoComment.reply('comment-<?php echo $commentId; ?>', <?php echo $commentId; ?>);">
                    <?php echo novintech_icon('reply', 14); ?>
                    پاسخ
                </button>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php
    // ---------- نمایش فرزندان (بازگشتی) ----------
    if ($currentLevel < 2) {
        $db = Typecho_Db::get();
        
        try {
            $cid = is_array($c) ? $c['cid'] : $c->cid;
            $childQuery = $db->select()->from('table.comments')
                ->where('cid = ?', $cid)
                ->where('parent = ?', $commentId)
                ->where('status = ?', 'approved')
                ->order('coid', Typecho_Db::SORT_ASC);

            $children = $db->fetchAll($childQuery);

            if (!empty($children)) {
                echo '<div class="comment-children">';
                foreach ($children as $childRow) {
                    $childRow['myCustomLevel'] = $currentLevel + 1;
                    renderCommentRecursive($childRow, $options, $adminEmail, $postAuthorId);
                }
                echo '</div>';
            }
        } catch (Exception $e) {
            // خطا نادیده گرفته شود
        }
    }
}

/**
 * تابع برای شمارش تمام نظرات (والد + فرزند + نوه)
 */
function getTotalCommentsCount($cid) {
    $db = Typecho_Db::get();
    
    try {
        // شمارش تمام نظرات تایید شده برای این پست
        $count = $db->fetchObject($db->select('COUNT(*) as total')
            ->from('table.comments')
            ->where('cid = ?', $cid)
            ->where('status = ?', 'approved'));
        
        return $count->total;
    } catch (Exception $e) {
        return 0;
    }
}
?>

<div id="comments" class="comments-area">
    
    <?php $this->comments()->to($comments); ?>
    
    <?php if ($comments->have()): ?>
    
    <!-- Comments Header -->
    <div class="comments-header">
        <h3 class="comments-title">
            <?php echo novintech_icon('message-square', 18); ?>
            نظرات
            <span class="comments-count">(<?php echo getTotalCommentsCount($this->cid); ?>)</span>
        </h3>
    </div>

    <!-- Comments List -->
    <div class="comments-list">
        <?php 
        // ---------- حلقه اصلی (فقط والدین) ----------
        while($comments->next()): 
            if ($comments->levels > 0) {
                continue;
            }
            renderCommentRecursive($comments, $this->options, $this->options->mail, $this->authorId);
        endwhile; 
        ?>
    </div>

    <?php endif; ?>

    <!-- Comment Form -->
    <?php if ($this->allow('comment')): ?>
    <div id="<?php $this->respondId(); ?>" class="comment-respond">
        <h3 class="respond-title" id="response">
            <?php if ($comments->have()): ?>
            ارسال نظر
            <?php else: ?>
            اولین نظر را ثبت کنید
            <?php endif; ?>
        </h3>

        <form method="post" action="<?php $this->commentUrl(); ?>" id="comment-form" class="comment-form">
            
            <!-- دکمه لغو پاسخ -->
            <div class="cancel-reply-wrapper">
                <?php $comments->cancelReply(); ?>
            </div>
            
            <?php if ($this->user->hasLogin()): ?>
            <div class="logged-in-as">
                <span>وارد شده به عنوان <strong><?php $this->user->screenName(); ?></strong></span>
                <a href="<?php $this->options->logoutUrl(); ?>" class="logout-link">خروج</a>
            </div>
            <input type="hidden" name="author" value="<?php $this->user->screenName(); ?>">
            <input type="hidden" name="mail" value="<?php $this->user->mail(); ?>">
            <input type="hidden" name="url" value="<?php $this->user->url(); ?>">
            <?php else: ?>
            <div class="form-row">
                <div class="form-group">
                    <label for="author">نام *</label>
                    <input type="text" id="author" name="author" placeholder="نام شما" value="<?php $this->remember('author'); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">ایمیل *</label>
                    <input type="email" id="email" name="mail" placeholder="ایمیل شما" value="<?php $this->remember('mail'); ?>" required dir="ltr">
                </div>
            </div>
            <div class="form-group">
                <label for="url">وب‌سایت (اختیاری)</label>
                <input type="url" id="url" name="url" placeholder="https://example.com" value="<?php $this->remember('url'); ?>" dir="ltr">
            </div>
            <?php endif; ?>

            <div class="form-group">
                <label for="comment">نظر شما *</label>
                <textarea id="comment" name="text" placeholder="نظر خود را بنویسید..." rows="5" required><?php $this->remember('text'); ?></textarea>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    ارسال نظر
                    <?php echo novintech_icon('send', 16); ?>
                </button>
            </div>
        </form>
    </div>
    <?php else: ?>
    <div class="comments-closed">
        <?php echo novintech_icon('message-square', 22); ?>
        <p>نظرات برای این مطلب بسته شده است.</p>
    </div>
    <?php endif; ?>
</div>
