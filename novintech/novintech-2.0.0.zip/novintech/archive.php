<?php
/**
 * Archive Template - Category, Tag, Author, Date Archives
 *
 * @package NovinTech Theme
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');
?>

<!-- Post Header (تمام عرض مانند post.php) -->
<header class="post-header">
    <div class="container">
        <div class="post-header-inner">
            <div class="post-meta-top">
                <span class="post-category">
                    <?php if($this->is('category')): ?>
                        دسته‌بندی
                    <?php elseif($this->is('tag')): ?>
                        برچسب
                    <?php elseif($this->is('search')): ?>
                        جستجو
                    <?php elseif($this->is('author')): ?>
                        نویسنده
                    <?php elseif($this->is('date')): ?>
                        آرشیو زمانی
                    <?php else: ?>
                        آرشیو
                    <?php endif; ?>
                </span>
            </div>
            <h1 class="post-title">
                <?php $this->archiveTitle(array(
                    'category'  =>  _t('%s'),
                    'search'    =>  _t('نتایج جستجو: %s'),
                    'tag'       =>  _t('%s'),
                    'author'    =>  _t('%s'),
                    'date'      =>  _t('%s'),
                ), '', ''); ?>
            </h1>
            <p class="archive-description">
                <?php if($this->is('category')): ?>
                    <?php echo $this->getDescription(); ?>
                <?php elseif($this->is('search')): ?>
                    تعداد <?php echo $this->getTotal(); ?> نتیجه یافت شد
                <?php elseif($this->is('tag')): ?>
                    تمام مطالب مرتبط با این برچسب
                <?php elseif($this->is('author')): ?>
                    تمام مطالب این نویسنده
                <?php elseif($this->is('date')): ?>
                    تمام مطالب منتشر شده در این بازه زمانی
                <?php else: ?>
                    تمام مطالب منتشر شده در این بخش
                <?php endif; ?>
            </p>
        </div>
    </div>
</header>

<!-- Main Content -->
<section class="archive-section">
    <div class="container">
        
        <!-- Search Box - فقط در صفحه آرشیو عمومی نمایش داده می‌شود -->
        <?php if(!$this->is('search')): ?>
        <div class="archive-search-box">
            <form method="get" action="<?php $this->options->siteUrl(); ?>" class="archive-search-form">
                <input type="text" name="s" placeholder="جستجو در مطالب..." class="archive-search-input" value="<?php echo htmlspecialchars($this->request->s ?? ''); ?>">
                <button type="submit" class="archive-search-btn">
                    <?php echo novintech_icon('search', 16); ?>
                    <span>جستجو</span>
                </button>
            </form>
        </div>
        <?php endif; ?>

        <!-- Archive Grid -->
        <?php if($this->have()): ?>
        <div class="blog-grid">
            <?php while($this->next()): ?>
            <article class="blog-card">
                <div class="blog-image">
                    <?php $nvtArchThumb = novintech_thumb($this); ?>
                    <?php if($nvtArchThumb !== ''): ?>
                        <img src="<?php echo htmlspecialchars($nvtArchThumb, ENT_QUOTES); ?>" alt="<?php $this->title(); ?>" loading="lazy">
                    <?php else: ?>
                        <div class="blog-image-placeholder">
                            <?php echo novintech_icon('doc', 30); ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="blog-content">
                    <div class="blog-meta">
                        <span class="blog-category"><?php $this->category(',', false); ?></span>
                        <span class="blog-date">
                            <?php echo novintech_icon('calendar', 14); ?>
                            <?php echo jdate('j F Y', $this->created); ?>
                        </span>
                    </div>
                    <h3 class="blog-title">
                        <a href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a>
                    </h3>
                    <p class="blog-excerpt"><?php $this->excerpt(100, '...'); ?></p>
                    <a href="<?php $this->permalink(); ?>" class="blog-link">
                        ادامه مطلب
                        <?php echo novintech_icon('arrow', 15); ?>
                    </a>
                </div>
            </article>
            <?php endwhile; ?>
        </div>

        <!-- Pagination - با فلش‌های درست برای راست چین -->
        <div class="pagination">
            <?php
            // صفحه‌بندی با فلش‌های درست برای راست چین
            $this->pageNav(
                novintech_icon('chevron-right', 14) . ' قبلی',
                'بعدی ' . novintech_icon('chevron-left', 14),
                1,
                '...',
                array(
                    'wrapTag' => 'nav',
                    'wrapClass' => 'pagination-nav',
                    'itemTag' => 'span',
                    'textTag' => 'span',
                    'currentClass' => 'current',
                    'prevClass' => 'prev',
                    'nextClass' => 'next'
                )
            ); ?>
        </div>

        <!-- نمایش اطلاعات صفحه‌بندی -->
        <?php if($this->getTotal() > $this->options->pageSize): ?>
        <div class="pagination-info">
            <?php 
            $total = $this->getTotal();
            $pageSize = $this->options->pageSize;
            $currentPage = $this->_currentPage;
            $from = ($currentPage - 1) * $pageSize + 1;
            $to = min($currentPage * $pageSize, $total);
            ?>
            <p>نمایش <?php echo $from; ?> - <?php echo $to; ?> از <?php echo $total; ?> مطلب</p>
        </div>
        <?php endif; ?>

        <?php else: ?>
        <div class="no-results">
            <div class="no-results-icon">
                <?php echo novintech_icon('search', 34); ?>
            </div>
            <h2 class="no-results-title">مطلبی یافت نشد</h2>
            <p class="no-results-text">متأسفانه مطلبی با این مشخصات پیدا نشد. لطفاً جستجوی دیگری انجام دهید.</p>
            <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-primary">بازگشت به صفحه اصلی</a>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php $this->need('footer.php'); ?>