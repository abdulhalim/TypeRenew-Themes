<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
</main>

<!-- ---------- فوتر سایت ---------- -->
<footer class="site-footer">
    <?php
    // ---------- داده‌های فوتر ----------
    $farzanehInstituteName = farzaneh_opt('farzanehInstituteName', (string)$this->options->title);
    $farzanehTagline    = farzaneh_opt('farzanehTagline', 'یادگیری، روشن کردن چراغ دانایی است');
    $farzanehLogoUrl    = farzaneh_logo_url();
    $farzanehFooterText = farzaneh_opt('farzanehFooterText', 'آموزشگاه فرزانه — سال‌هاست کنار خانواده‌های ایرانی ایستاده‌ایم تا مسیر تحصیلی فرزندان شما روشن‌تر و مطمئن‌تر باشد. یادگیریِ عمیق، آینده‌ای روشن می‌سازد.');
    $farzanehPhone      = farzaneh_opt_raw('farzanehContactPhone');
    $farzanehPhone2     = farzaneh_opt_raw('farzanehContactPhone2');
    $farzanehEmail      = farzaneh_opt_raw('farzanehContactEmail');
    $farzanehAddress    = farzaneh_opt_raw('farzanehContactAddress');
    $farzanehHours      = (string)farzaneh_opt_raw('farzanehContactHours');
    $farzanehSocial = [
        'instagram' => farzaneh_opt_raw('farzanehSocialInstagram'),
        'telegram'  => farzaneh_opt_raw('farzanehSocialTelegram'),
        'whatsapp'  => farzaneh_opt_raw('farzanehSocialWhatsapp'),
        'youtube'   => farzaneh_opt_raw('farzanehSocialYoutube'),
    ];
    $farzanehSocialNames = ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام', 'whatsapp' => 'واتس‌اپ', 'youtube' => 'آپارات/یوتیوب'];
    ?>

    <!-- بخش اصلی فوتر -->
    <div class="container">
        <div class="footer-grid">

            <!-- ستون ۱: لوگو و معرفی -->
            <div class="footer-col footer-about">
                <div class="footer-logo">
                    <a href="<?php $this->options->siteUrl(); ?>" class="footer-logo-link">
                        <?php if ($farzanehLogoUrl !== ''): ?>
                            <img src="<?php echo htmlspecialchars($farzanehLogoUrl, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($farzanehInstituteName, ENT_QUOTES); ?>" class="footer-logo-img">
                        <?php else: ?>
                            <span class="footer-logo-mark" aria-hidden="true"><?php echo farzaneh_icon('graduation-cap', 20); ?></span>
                        <?php endif; ?>
                        <span class="footer-logo-text"><?php echo htmlspecialchars($farzanehInstituteName, ENT_QUOTES); ?></span>
                    </a>
                </div>
                <p class="footer-desc"><?php echo htmlspecialchars($farzanehFooterText, ENT_QUOTES); ?></p>
                <div class="footer-social">
                    <?php foreach ($farzanehSocial as $farzanehNet => $farzanehUrl): if (trim((string)$farzanehUrl) !== ''): ?>
                        <a href="<?php echo htmlspecialchars($farzanehUrl, ENT_QUOTES); ?>" target="_blank" rel="noopener" aria-label="<?php echo $farzanehSocialNames[$farzanehNet]; ?>">
                            <?php echo farzaneh_icon($farzanehNet === 'telegram' ? 'send' : ($farzanehNet === 'whatsapp' ? 'message-circle' : $farzanehNet), 17); ?>
                        </a>
                    <?php endif; endforeach; ?>
                </div>
            </div>

            <!-- ستون ۲: لینک‌های سریع -->
            <div class="footer-col">
                <h3 class="footer-title"><?php echo farzaneh_icon('zap', 17); ?> دسترسی سریع</h3>
                <ul class="footer-links">
                    <li><a href="<?php echo htmlspecialchars(farzaneh_link_url('#courses', farzaneh_is_front()), ENT_QUOTES); ?>">دوره‌های آموزشی</a></li>
                    <li><a href="<?php echo htmlspecialchars(farzaneh_link_url('#classes', farzaneh_is_front()), ENT_QUOTES); ?>">برنامهٔ کلاس‌ها</a></li>
                    <li><a href="<?php echo htmlspecialchars(farzaneh_link_url('#team', farzaneh_is_front()), ENT_QUOTES); ?>">اساتید ما</a></li>
                    <li><a href="<?php echo htmlspecialchars(farzaneh_link_url('#enroll', farzaneh_is_front()), ENT_QUOTES); ?>">ثبت‌نام و مشاوره</a></li>
                    <li><a href="<?php echo htmlspecialchars(farzaneh_blog_url(), ENT_QUOTES); ?>">مقالات آموزشی</a></li>
                    <?php
                    $farzanehFooterPages = \Widget\Contents\Page\Rows::allocWithAlias('farzanehFooter');
                    $farzanehFooterPageCount = 0;
                    while ($farzanehFooterPages->next()):
                        if (farzaneh_is_reserve_cid((int)$farzanehFooterPages->cid)) { continue; }
                        $farzanehFooterPageCount++;
                        if ($farzanehFooterPageCount > 4) { break; }
                    ?>
                        <li><a href="<?php $farzanehFooterPages->permalink(); ?>"><?php echo farzaneh_fa_title($farzanehFooterPages); ?></a></li>
                    <?php endwhile; ?>
                </ul>
            </div>

            <!-- ستون ۳: اطلاعات تماس -->
            <div class="footer-col footer-contact-col">
                <h3 class="footer-title"><?php echo farzaneh_icon('phone-call', 17); ?> تماس با ما</h3>
                <ul class="footer-contact">
                    <?php if ($farzanehAddress !== null && trim($farzanehAddress) !== ''): ?>
                    <li>
                        <?php echo farzaneh_icon('map-pin', 16); ?>
                        <span><?php echo htmlspecialchars($farzanehAddress, ENT_QUOTES); ?></span>
                    </li>
                    <?php endif; ?>
                    <?php if ($farzanehPhone !== null && trim($farzanehPhone) !== ''): ?>
                    <li>
                        <?php echo farzaneh_icon('phone', 16); ?>
                        <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $farzanehPhone), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($farzanehPhone), ENT_QUOTES); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if ($farzanehPhone2 !== null && trim($farzanehPhone2) !== ''): ?>
                    <li>
                        <?php echo farzaneh_icon('message-circle', 16); ?>
                        <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $farzanehPhone2), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($farzanehPhone2), ENT_QUOTES); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if ($farzanehEmail !== null && trim($farzanehEmail) !== ''): ?>
                    <li>
                        <?php echo farzaneh_icon('mail', 16); ?>
                        <a href="mailto:<?php echo htmlspecialchars($farzanehEmail, ENT_QUOTES); ?>"><?php echo htmlspecialchars($farzanehEmail, ENT_QUOTES); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php foreach (array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $farzanehHours))) as $farzanehHour): ?>
                    <li>
                        <?php echo farzaneh_icon('clock', 16); ?>
                        <span><?php echo htmlspecialchars(toPersianNumbers($farzanehHour), ENT_QUOTES); ?></span>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <!-- خط جداکننده و کپی‌رایت -->
    <div class="footer-bottom">
        <div class="container footer-bottom-inner">
            <div class="copyright">
                <span>© <?php echo farzaneh_jalali_year(); ?> <?php echo htmlspecialchars($farzanehInstituteName, ENT_QUOTES); ?> — تمامی حقوق محفوظ است.</span>
            </div>
            <div class="footer-powered">
                <span>قدرت گرفته از <a href="https://typerenew.com" target="_blank" rel="noopener">تایپ‌رینیو</a></span>
            </div>
        </div>
    </div>
</footer>

<!-- ---------- دکمهٔ بازگشت به بالا ---------- -->
<button type="button" class="back-to-top" id="backToTop" aria-label="بازگشت به بالا" title="بازگشت به بالا">
    <?php echo farzaneh_icon('arrow-up', 19); ?>
</button>

<!-- ---------- اسکریپت‌ها ---------- -->
<script src="<?php $this->options->themeUrl('js/main.js'); ?>?v=1.0.2"></script>
<?php if (isset($GLOBALS['farzanehPostJs']) && $GLOBALS['farzanehPostJs']): ?>
<!-- لایک — فقط صفحات نوشته -->
<script src="<?php $this->options->themeUrl('js/likes.js'); ?>?v=1.0.0"></script>
<?php endif; ?>

<?php $this->footer(); ?>
</body>
</html>
