(function () {
    'use strict';

    function faNum(str) {
        var map = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return String(str).replace(/[0-9]/g, function (d) { return map[+d]; });
    }

    function enNum(str) {
        return String(str)
            .replace(/[۰-۹]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); })
            .replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); });
    }

    /* ================================================================
     *  منوی موبایل
     * ================================================================ */
    var menu = document.getElementById('mobileMenu');
    var overlay = document.getElementById('menuOverlay');
    var toggle = document.getElementById('menuToggle');
    var closeBtn = document.getElementById('menuClose');

    function openMenu() {
        if (!menu) { return; }
        menu.classList.add('is-open');
        if (overlay) { overlay.classList.add('is-visible'); }
        menu.setAttribute('aria-hidden', 'false');
        if (toggle) { toggle.setAttribute('aria-expanded', 'true'); }
        document.body.style.overflow = 'hidden';
    }

    function closeMenu() {
        if (!menu) { return; }
        menu.classList.remove('is-open');
        if (overlay) { overlay.classList.remove('is-visible'); }
        menu.setAttribute('aria-hidden', 'true');
        if (toggle) { toggle.setAttribute('aria-expanded', 'false'); }
        document.body.style.overflow = '';
    }

    if (toggle) { toggle.addEventListener('click', openMenu); }
    if (closeBtn) { closeBtn.addEventListener('click', closeMenu); }
    if (overlay) { overlay.addEventListener('click', closeMenu); }

    document.querySelectorAll('.mobile-nav a[data-close]').forEach(function (link) {
        link.addEventListener('click', closeMenu);
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') { closeMenu(); }
    });

    /* ================================================================
     *  هدر چسبان و دکمهٔ بازگشت به بالا
     * ================================================================ */
    var header = document.getElementById('siteHeader');
    var backToTop = document.getElementById('backToTop');

    function onScroll() {
        var y = window.pageYOffset || document.documentElement.scrollTop || 0;
        if (header) {
            if (y > 8) { header.classList.add('is-scrolled'); }
            else { header.classList.remove('is-scrolled'); }
        }
        if (backToTop) {
            if (y > 480) { backToTop.classList.add('is-visible'); }
            else { backToTop.classList.remove('is-visible'); }
        }
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    if (backToTop) {
        backToTop.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    /* ================================================================
     *  پرسش‌های متداول — آکاردئون تک‌بازشو
     * ================================================================ */
    (function initFaqAccordion() {
        var items = document.querySelectorAll('.faq-list details');
        if (!items.length) { return; }
        items.forEach(function (item) {
            item.addEventListener('toggle', function () {
                if (item.open) {
                    items.forEach(function (other) {
                        if (other !== item) { other.open = false; }
                    });
                }
            });
        });
    })();

    /* ================================================================
     *  آواتار: یا گراواتار واقعی یا آواتار الفبایی — نه هر دو
     *  (تصاویر گراواتار با d=404 خواسته می‌شوند؛ اگر تصویری وجود
     *   نداشته باشد لود شکست می‌خورد و فقط آواتار الفبایی می‌ماند)
     * ================================================================ */
    (function initAvatars() {
        function sync(box) {
            if (!box) { return; }
            var img = box.querySelector('img');
            if (!img) { return; }
            function showImg() { box.classList.add('has-img'); }
            function hideImg() { img.classList.add('is-hidden'); }
            if (img.complete) {
                // تصویر قبلاً لود شده (کش) یا شکست خورده است
                if (img.naturalWidth > 0) { showImg(); } else { hideImg(); }
                return;
            }
            img.addEventListener('load', showImg);
            img.addEventListener('error', hideImg);
        }
        document.querySelectorAll('.comment-avatar, .author-avatar').forEach(sync);
    })();

    /* ================================================================
     *  شمارندهٔ انیمیشنی آمار آموزشگاه («در یک نگاه»)
     *  data-counter = عدد هدف لاتین — data-suffix = پسوند مثل «٪» یا «+»
     * ================================================================ */
    (function initCounters() {
        var boxes = document.querySelectorAll('.stats-band .stat-num[data-counter]');
        if (!boxes.length) { return; }

        var started = false;

        function animate(el) {
            var target = parseInt(el.getAttribute('data-counter'), 10) || 0;
            if (target <= 0) { return; }
            var suffix = el.getAttribute('data-suffix') || '';
            var duration = 1400;
            var start = null;
            function frame(ts) {
                if (!start) { start = ts; }
                var p = Math.min((ts - start) / duration, 1);
                var eased = 1 - Math.pow(1 - p, 3);
                el.textContent = faNum(Math.round(target * eased).toLocaleString('en-US').replace(/,/g, '٬')) + suffix;
                if (p < 1) { window.requestAnimationFrame(frame); }
            }
            window.requestAnimationFrame(frame);
        }

        function tryStart() {
            if (started) { return; }
            var band = document.querySelector('.stats-band');
            if (!band) { return; }
            var rect = band.getBoundingClientRect();
            if (rect.top < window.innerHeight - 80 && rect.bottom > 0) {
                started = true;
                boxes.forEach(animate);
                window.removeEventListener('scroll', tryStart);
            }
        }

        window.addEventListener('scroll', tryStart, { passive: true });
        tryStart();
    })();

    /* ================================================================
     *  حرکت‌های بخش هیرو (نسخهٔ ۱٫۰٫۲):
     *  ۱) شمارندهٔ «۹۸٪» هم‌گام با پرشدن حلقهٔ SVG؛
     *  ۲) تیلت سه‌بعدی پنل با حرکت ماوس + پارالاکس شناورها و حباب‌ها.
     *  (هر دو با احترام به prefers-reduced-motion غیرفعال می‌شوند)
     * ================================================================ */
    (function initHeroMotion() {
        var wrap = document.querySelector('.hero-visual');
        if (!wrap) { return; }

        var reduced = window.matchMedia
            && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

        /* حل‌کنندهٔ سادهٔ cubic-bezier (تقسیم دوتایی) برای هم‌گامی دقیق با CSS */
        function bezierEasing(x1, y1, x2, y2) {
            return function (t) {
                var lo = 0, hi = 1, mid = .5, v = 0, mt, i;
                for (i = 0; i < 24; i++) {
                    mid = (lo + hi) / 2;
                    mt = 1 - mid;
                    v = 3 * mt * mt * mid * x1 + 3 * mt * mid * mid * x2 + mid * mid * mid;
                    if (Math.abs(v - t) < 1e-5) { break; }
                    if (v < t) { lo = mid; } else { hi = mid; }
                }
                mt = 1 - mid;
                return 3 * mt * mt * mid * y1 + 3 * mt * mid * mid * y2 + mid * mid * mid;
            };
        }

        /* ---------- ۱) شمارندهٔ درصد قبولی، هم‌زمان با حلقه ---------- */
        var ringEl = wrap.querySelector('.hb-ring-text strong[data-ring-counter]');
        if (ringEl && !reduced) {
            var target = parseInt(ringEl.getAttribute('data-ring-counter'), 10);
            if (!isNaN(target) && target > 0) {
                var suffix = ringEl.getAttribute('data-ring-suffix') || '';
                var ease = bezierEasing(.6, .05, .3, 1);   // همان easing انیمیشن hbRing
                var delayMs = 550;   // همان تأخیر hbRing در CSS
                var durMs = 1700;    // همان مدت hbRing در CSS
                var t0 = null;
                ringEl.textContent = faNum(0) + suffix;
                function ringFrame(ts) {
                    if (t0 === null) { t0 = ts; }
                    var t = ts - t0 - delayMs;
                    if (t >= 0) {
                        var p = Math.min(t / durMs, 1);
                        ringEl.textContent = faNum(Math.round(target * ease(p))) + suffix;
                    }
                    if (t < durMs) { window.requestAnimationFrame(ringFrame); }
                }
                window.requestAnimationFrame(ringFrame);
            }
        }

        /* ---------- ۲) تیلت سه‌بعدی پنل + پارالاکس لایه‌ها ---------- */
        var board = wrap.querySelector('.hero-board');
        if (!board || reduced) { return; }
        if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) { return; }

        var floats = Array.prototype.slice.call(wrap.querySelectorAll('.hero-float'));
        var blobs = Array.prototype.slice.call(wrap.querySelectorAll('.hero-blob'));
        var floatDepth = [24, 16, 30];   // عمق پارالاکس هر شناور (پیکسل)

        var tx = 0, ty = 0;   // هدف ماوس
        var cx = 0, cy = 0;   // مقدار جاریِ نرم‌شده
        var raf = null;

        function tick() {
            cx += (tx - cx) * .09;
            cy += (ty - cy) * .09;
            if (Math.abs(tx - cx) < .001) { cx = tx; }
            if (Math.abs(ty - cy) < .001) { cy = ty; }

            var rx = (-cy * 4.5).toFixed(3);
            var ry = (cx * 5.5).toFixed(3);
            board.style.transform = 'perspective(1100px) rotateX(' + rx + 'deg) rotateY(' + ry + 'deg)';

            // پارالاکس روی ویژگی translate تا با انیمیشن‌های transform هم‌نشین باشد
            floats.forEach(function (el, i) {
                var d = floatDepth[i] || 18;
                el.style.translate = (cx * d).toFixed(2) + 'px ' + (cy * d * .7).toFixed(2) + 'px';
            });
            blobs.forEach(function (el, i) {
                var d = (i === 0) ? -13 : -17;
                el.style.translate = (cx * d).toFixed(2) + 'px ' + (cy * d * .6).toFixed(2) + 'px';
            });

            if (cx !== tx || cy !== ty) {
                raf = window.requestAnimationFrame(tick);
            } else {
                raf = null;
            }
        }

        function wake() {
            if (raf === null) { raf = window.requestAnimationFrame(tick); }
        }

        wrap.addEventListener('mousemove', function (e) {
            var r = wrap.getBoundingClientRect();
            if (!r.width || !r.height) { return; }
            tx = Math.max(-1, Math.min(1, ((e.clientX - r.left) / r.width - .5) * 2));
            ty = Math.max(-1, Math.min(1, ((e.clientY - r.top) / r.height - .5) * 2));
            board.classList.add('is-tilting');
            wake();
        });

        wrap.addEventListener('mouseleave', function () {
            tx = 0;
            ty = 0;
            board.classList.remove('is-tilting');
            wake();
        });
    })();

    /* ================================================================
     *  فرم ثبت‌نام — AJAX به نقطهٔ پایانی اختصاصی /farzaneh-register
     *  (الگو از افزونهٔ Booking و بوکینگ نهال؛ توکن _ و تلهٔ هرزنامه همراه فرم ارسال می‌شود)
     * ================================================================ */
    function initEnroll() {
        var form = document.getElementById('enrollForm');
        if (!form) { return; }

        var submitBtn = document.getElementById('enrollSubmitBtn');
        var successEl = document.getElementById('enrollSuccess');
        var errorEl = document.getElementById('enrollError');
        var errorText = document.getElementById('enrollErrorText');

        function showMsg(el, textEl, msg) {
            if (el) { el.hidden = false; }
            if (textEl && typeof msg === 'string' && msg !== '') { textEl.textContent = msg; }
            if (el) {
                try { el.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) { }
            }
        }

        form.addEventListener('submit', function (e) {
            e.preventDefault();

            // مخفی‌کردن پیام‌های قبلی
            if (successEl) { successEl.hidden = true; }
            if (errorEl) { errorEl.hidden = true; }

            // اعتبارسنجی سمت کلاینت
            var name = (form.querySelector('#farzanehName') || {}).value || '';
            var phone = (form.querySelector('#farzanehPhone') || {}).value || '';
            phone = enNum(String(phone)).replace(/[\s\-()]/g, '');

            if (name.trim().length < 2) {
                showMsg(errorEl, errorText, 'لطفاً نام خود را کامل وارد کنید.');
                return;
            }
            if (!/^(\+98|98|0098|0)?9\d{9}$/.test(phone) && !/^0\d{9,10}$/.test(phone)) {
                showMsg(errorEl, errorText, 'شمارهٔ تلفن معتبر نیست (مثال: ۰۹۱۲۳۴۵۶۷۸۹).');
                return;
            }

            // حالت بارگذاری
            if (submitBtn) {
                submitBtn.classList.add('loading');
                submitBtn.setAttribute('disabled', 'disabled');
            }

            // گردآوری همهٔ فیلدهای فرم (شامل توکن _ و تلهٔ هرزنامه)
            var body = new URLSearchParams();
            Array.prototype.forEach.call(form.elements, function (el) {
                if (!el.name || el.disabled) { return; }
                var tag = (el.tagName || '').toLowerCase();
                if (tag === 'select') {
                    body.append(el.name, el.value || '');
                } else if (el.type === 'checkbox' || el.type === 'radio') {
                    if (el.checked) { body.append(el.name, el.value || ''); }
                } else if (el.type !== 'file' && el.type !== 'button' && el.type !== 'submit') {
                    body.append(el.name, el.value || '');
                }
            });
            body.set('farzanehEnroll', '1');
            // شمارهٔ نرمال‌شده
            body.set('farzanehPhone', phone);

            // نقطهٔ پایانی اختصاصی؛ در نبودش آدرس صفحهٔ جاری
            var endpoint = form.getAttribute('action') || window.location.href;
            if (!endpoint || endpoint === '#' || endpoint.charAt(0) === '#') {
                endpoint = window.location.href;
            }

            fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: body.toString(),
                credentials: 'same-origin',
                redirect: 'follow'
            })
                .then(function (res) {
                    // اگر پاسخ JSON نبود (مثلاً HTML)، متن را برای تشخیص خطا بخوان
                    var contentType = (res.headers.get('content-type') || '');
                    if (contentType.indexOf('application/json') !== -1) {
                        return res.json().then(function (data) { return data; });
                    }
                    return res.text().then(function () {
                        return { ok: false, error: 'پاسخ سرور قابل پردازش نبود؛ صفحه را رفرش کنید و دوباره تلاش کنید. (HTTP ' + res.status + ')' };
                    });
                })
                .then(function (data) {
                    if (data && data.ok) {
                        try { form.reset(); } catch (e) { }
                        if (successEl) { successEl.hidden = false; }
                        if (successEl) {
                            successEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                        }
                    } else {
                        var msg = (data && data.error && typeof data.error === 'string')
                            ? data.error
                            : 'ارسال درخواست ناموفق بود؛ لطفاً دوباره تلاش کنید.';
                        showMsg(errorEl, errorText, msg);
                    }
                })
                .catch(function () {
                    showMsg(errorEl, errorText, 'خطای ارتباط با سرور؛ اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.');
                })
                .finally(function () {
                    if (submitBtn) {
                        submitBtn.classList.remove('loading');
                        submitBtn.removeAttribute('disabled');
                    }
                });
        });
    }
    initEnroll();

    /* ================================================================
     *  پیش‌انتخاب دوره — دکمهٔ «ثبت‌نام» کارت دوره، منوی دورهٔ فرم را پر می‌کند
     * ================================================================ */
    (function initCoursePreselect() {
        var courseSelect = document.getElementById('farzanehCourse');
        if (!courseSelect) { return; }
        document.querySelectorAll('.btn-course[data-course]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var title = btn.getAttribute('data-course') || '';
                if (!title) { return; }
                Array.prototype.forEach.call(courseSelect.options, function (opt) {
                    if (opt.value === title) {
                        courseSelect.value = title;
                        try { courseSelect.classList.add('flash'); } catch (e) { }
                        window.setTimeout(function () {
                            try { courseSelect.classList.remove('flash'); } catch (e) { }
                        }, 900);
                    }
                });
            });
        });
    })();

    /* ================================================================
     *  نظرات دانش‌آموزان و والدین — کاروسل خودگردان تک‌کارت
     * ================================================================ */
    (function initTestimonials() {
        var carousel = document.getElementById('testimonialsCarousel');
        if (!carousel) { return; }
        var cards = Array.prototype.slice.call(carousel.querySelectorAll('.testimonial-card'));
        if (cards.length < 2) { return; }

        var dotsWrap = carousel.querySelector('.t-dots');
        var current = 0;
        var timer = null;
        var interval = 6500;
        var dots = [];

        cards.forEach(function (card, i) {
            card.setAttribute('data-index', String(i));
        });

        if (dotsWrap) {
            cards.forEach(function (card, i) {
                var dot = document.createElement('button');
                dot.type = 'button';
                dot.className = 't-dot' + (i === 0 ? ' is-active' : '');
                dot.setAttribute('aria-label', 'نظر ' + (i + 1));
                dot.addEventListener('click', function () {
                    goTo(i);
                    restart();
                });
                dotsWrap.appendChild(dot);
                dots.push(dot);
            });
        }

        function goTo(index) {
            current = (index + cards.length) % cards.length;
            cards.forEach(function (card, i) {
                card.classList.toggle('is-active', i === current);
                card.setAttribute('aria-hidden', i === current ? 'false' : 'true');
            });
            dots.forEach(function (dot, i) {
                dot.classList.toggle('is-active', i === current);
            });
        }

        function next() { goTo(current + 1); }
        function prev() { goTo(current - 1); }
        function start() {
            stop();
            timer = window.setInterval(next, interval);
        }
        function stop() {
            if (timer) {
                window.clearInterval(timer);
                timer = null;
            }
        }
        function restart() {
            stop();
            start();
        }

        var nextBtn = carousel.querySelector('.t-next');
        var prevBtn = carousel.querySelector('.t-prev');
        if (nextBtn) { nextBtn.addEventListener('click', function () { next(); restart(); }); }
        if (prevBtn) { prevBtn.addEventListener('click', function () { prev(); restart(); }); }

        carousel.addEventListener('mouseenter', stop);
        carousel.addEventListener('mouseleave', start);

        // پشتیبانی لمسی ساده
        var touchX = null;
        carousel.addEventListener('touchstart', function (e) {
            touchX = e.touches[0].clientX;
            stop();
        }, { passive: true });
        carousel.addEventListener('touchend', function (e) {
            if (touchX === null) { return; }
            var dx = e.changedTouches[0].clientX - touchX;
            if (Math.abs(dx) > 40) {
                if (dx > 0) { next(); } else { prev(); }
            }
            touchX = null;
            start();
        }, { passive: true });

        start();
    })();
})();
