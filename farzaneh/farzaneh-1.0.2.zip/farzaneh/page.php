<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');
?>

<article class="page-wrap container">
    <header class="page-head">
        <nav class="post-breadcrumb" aria-label="مسیر">
            <a href="<?php $this->options->siteUrl(); ?>">خانه</a>
            <span class="crumb-sep">/</span>
            <span aria-current="page"><?php echo farzaneh_fa_title($this); ?></span>
        </nav>
        <h1 class="page-title"><?php echo farzaneh_fa_title($this); ?></h1>
        <div class="post-meta">
            <span class="post-meta-item">
                <?php echo farzaneh_icon('calendar', 15); ?>
                <time datetime="<?php $this->date('c'); ?>"><?php echo farzaneh_post_date($this, 'j F Y'); ?></time>
            </span>
            <?php if (farzaneh_opt('farzanehShowViews', '1') === '1'): ?>
            <span class="post-meta-item">
                <?php echo farzaneh_icon('eye', 15); ?>
                <?php echo farzaneh_num(farzaneh_views($this)); ?> بازدید
            </span>
            <?php endif; ?>
        </div>
    </header>

    <?php $farzanehPageCover = farzaneh_thumbnail($this, false); if ($farzanehPageCover !== ''): ?>
    <figure class="post-cover">
        <img src="<?php echo htmlspecialchars($farzanehPageCover, ENT_QUOTES); ?>" alt="<?php echo farzaneh_fa_title($this); ?>">
    </figure>
    <?php endif; ?>

    <div class="post-content page-content">
        <?php $this->content(); ?>
    </div>

    <?php
    // برگهٔ دفتر ثبت‌نام — دیدگاه‌های عمومی نشان داده نمی‌شود
    if (!farzaneh_is_reserve_cid((int)$this->cid)):
    ?>
    <?php $this->need('comments.php'); ?>
    <?php endif; ?>
</article>

<?php $this->need('footer.php'); ?>
