<?php
/**
 * فرزانه — پوسته تخصصی آموزشگاه و مدارس
 *
 * @package فرزانه
 * @author پوردریایی
 * @link https://pourdaryaei.ir
 * @version 1.0.2
 * @since 1.6.0
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');


if (farzaneh_is_front()):

    /* ================================================================
     *  صفحهٔ اصلی — لندینگ آموزشگاه
     * ================================================================ */

    // ---------- داده‌های هیرو ----------
    $farzanehHeroBadge    = farzaneh_opt('farzanehHeroBadge', 'آموزشگاه تخصصی دانش‌آموزی و کنکور');
    $farzanehHeroTitle    = farzaneh_opt('farzanehHeroTitle', 'مسیر موفقیت تحصیلی، از همین‌جا آغاز می‌شود');
    $farzanehHeroSubtitle = trim((string)farzaneh_opt_raw('farzanehHeroSubtitle'));
    $farzanehHeroSubtitle = ($farzanehHeroSubtitle === '') ? "در فرزانه، اساتید باتجربه با کلاس‌های کم‌جمعیت، آزمون‌های هدفمند و مشاورهٔ تحصیلی فردی، دانش‌آموزان را به قبولی مطمئن می‌رسانند.\nهمین حالا دورهٔ مناسب خود را انتخاب کنید و اولین جلسهٔ مشاوره را رایگان رزرو کنید." : $farzanehHeroSubtitle;
    $farzanehHeroImageRaw = trim((string)farzaneh_opt_raw('farzanehHeroImage'));
    $farzanehHeroImage    = ($farzanehHeroImageRaw !== '') ? farzaneh_resolve_url($farzanehHeroImageRaw) : farzaneh_asset('img/hero.jpg');
    $farzanehHeroBtn1Text = farzaneh_opt('farzanehHeroBtn1Text', 'ثبت‌نام دوره‌ها');
    $farzanehHeroBtn1Url  = farzaneh_opt('farzanehHeroBtn1Url', '#enroll');
    $farzanehHeroBtn2Text = farzaneh_opt_raw('farzanehHeroBtn2Text');
    $farzanehHeroBtn2Url  = farzaneh_opt_raw('farzanehHeroBtn2Url');
    $farzanehHeroStats    = farzaneh_parse_stats(farzaneh_opt_raw('farzanehHeroStats'));
    $farzanehHeroStats    = array_slice($farzanehHeroStats, 0, 4);

    // ---------- داده‌های دوره‌ها ----------
    $farzanehCoursesTitle = trim((string)farzaneh_opt_raw('farzanehCoursesTitle'));
    $farzanehCoursesSubtitle = farzaneh_opt('farzanehCoursesSubtitle', 'از تقویتی تا کنکور؛ دوره‌ای که لازم دارید، اینجاست');
    $farzanehCourses      = farzaneh_parse_courses(farzaneh_opt_raw('farzanehCourses'));
    if (empty($farzanehCourses) && $farzanehCoursesTitle !== '') {
        $farzanehCourses = farzaneh_parse_courses("ریاضی نهم | تقویتی | سرکار خانم احمدی | مبتدی | ۳۰ ساعت / ۱۶ جلسه | ۱٬۸۰۰٬۰۰۰ | ۲٬۲۰۰٬۰۰۰ | پرفروش | تثبیت مفاهیم پایه، حل تمرین هدفمند و آمادگی امتحانات نهایی\nفیزیک کنکور | کنکور | دکتر رضایی | پیشرفته | ۴۵ ساعت / ۲۴ جلسه | ۳٬۵۰۰٬۰۰۰ | | جدید | مرور جامع کلِ دروس، تست‌زنی حساب‌شده و آزمون‌های شبیه‌ساز\nزبان انگلیسی نوجوانان | مهارتی | سرکار خانم کریمی | همه سطوح | ۲۴ ساعت / ۱۲ جلسه | رایگان جلسهٔ اول | | | مکالمهٔ روزمره، تقویت چهار مهارت با متد بازی‌محور");
    }

    // ---------- داده‌های کلاس‌ها ----------
    $farzanehClassesTitle = trim((string)farzaneh_opt_raw('farzanehClassesTitle'));
    $farzanehClassesSubtitle = farzaneh_opt('farzanehClassesSubtitle', 'برنامهٔ منظم کلاس‌ها با گروه‌های کوچک و پشتیبانی مستقیم استاد');
    $farzanehClasses      = farzaneh_parse_classes(farzaneh_opt_raw('farzanehClasses'));
    if (empty($farzanehClasses) && $farzanehClassesTitle !== '') {
        $farzanehClasses = farzaneh_parse_classes("ریاضی نهم — گروه A | سرکار خانم احمدی | شنبه و دوشنبه | ۱۶:۰۰ تا ۱۷:۳۰ | ۱۲ نفر | ثبت‌نام باز\nفیزیک کنکور — گروه ۱ | دکتر رضایی | یکشنبه و سه‌شنبه | ۱۷:۰۰ تا ۱۹:۰۰ | ۱۵ نفر | تقریباً تکمیل\nزبان انگلیسی نوجوانان | سرکار خانم کریمی | سه‌شنبه | ۱۰:۰۰ تا ۱۱:۳۰ | ۱۰ نفر | ثبت‌نام باز\nشیمی دهم | آقای موسوی | چهارشنبه | ۱۵:۳۰ تا ۱۷:۰۰ | ۱۴ نفر | تکمیل شده");
    }

    // ---------- داده‌های اساتید ----------
    $farzanehTeamTitle = trim((string)farzaneh_opt_raw('farzanehTeamTitle'));
    $farzanehTeamSubtitle = farzaneh_opt('farzanehTeamSubtitle', 'تیمی از بهترین اساتید و مشاوران تحصیلی کشور');
    $farzanehTeam      = farzaneh_parse_team(farzaneh_opt_raw('farzanehTeam'));
    if (empty($farzanehTeam) && $farzanehTeamTitle !== '') {
        $farzanehTeam = farzaneh_parse_team("دکتر امیر رضایی | مدرس فیزیک کنکور — دکترای فیزیک از دانشگاه تهران | | ۱۴ سال سابقهٔ تدریس کنکور و رتبه‌سازی\nسرکار خانم سارا احمدی | مدرس ریاضی متوسطهٔ اول — کارشناسی ارشد آموزش ریاضی | | متد تدریس بازی‌محور و پشتیبانی فردی\nآقای محمد موسوی | مدرس شیمی — رتبهٔ برتر کنکور تجربی | | جزوه‌نویس و مدرس مدارس نمونه\nسرکار خانم نگار کریمی | مدرس زبان انگلیسی — مدرک TESOL | | طراحی دوره‌های مکالمهٔ نوجوانان");
    }

    // ---------- داده‌های چرا فرزانه ----------
    $farzanehAboutTitle = trim((string)farzaneh_opt_raw('farzanehAboutTitle'));
    $farzanehAboutText  = (string)farzaneh_opt('farzanehAboutText', '');
    $farzanehAboutImageRaw = trim((string)farzaneh_opt_raw('farzanehAboutImage'));
    $farzanehAboutImage = ($farzanehAboutImageRaw !== '') ? farzaneh_resolve_url($farzanehAboutImageRaw) : farzaneh_asset('img/about.jpg');
    $farzanehAboutFeatures = farzaneh_parse_features(farzaneh_opt_raw('farzanehAboutFeatures'));
    $farzanehAboutBtnText = trim((string)farzaneh_opt_raw('farzanehAboutBtnText'));
    $farzanehAboutBtnUrl  = trim((string)farzaneh_opt_raw('farzanehAboutBtnUrl'));

    // ---------- داده‌های «فرزانه در یک نگاه» (دستاوردهای آموزشگاه) ----------
    $farzanehStatsShow = farzaneh_opt('farzanehStatsShow', '1') === '1';
    $farzanehStatsTitle = farzaneh_opt('farzanehStatsTitle', 'فرزانه در یک نگاه');
    $farzanehGlance = farzaneh_parse_glance(farzaneh_opt_raw('farzanehGlanceStats'));
    if (empty($farzanehGlance)) {
        $farzanehGlance = farzaneh_parse_glance(
            "درصد قبولی کنکور | ۹۸٪ | trophy\nرتبه‌های زیر ۱۰۰۰ کشوری | ۴۵+ | award\nقبولی در رشته‌های موردعلاقه | ۱۲۰+ | heart\nسال تجربهٔ تدریس | ۱۵ | calendar-check"
        );
    }

    // ---------- داده‌های پنل داشبوردی هیرو ----------
    /* سه کلاس اول برای «برنامهٔ امروز» پنل هیرو؛ در نبود داده، نمونهٔ پیش‌فرض */
    $farzanehHeroSchedule = [];
    foreach (array_slice($farzanehClasses, 0, 3) as $farzanehHeroClass) {
        $farzanehHeroTime = '';
        if (preg_match('#([۰-۹0-9]{1,2}:[۰-۹0-9]{2})#u', (string)$farzanehHeroClass['time'], $m)) {
            $farzanehHeroTime = toPersianNumbers($m[1]);
        }
        $farzanehHeroSchedule[] = [
            'time'    => $farzanehHeroTime !== '' ? $farzanehHeroTime : '۱۶:۰۰',
            'title'   => $farzanehHeroClass['title'],
            'teacher' => $farzanehHeroClass['teacher'],
        ];
    }
    if (empty($farzanehHeroSchedule)) {
        $farzanehHeroSchedule = [
            ['time' => '۱۶:۰۰', 'title' => 'ریاضی نهم', 'teacher' => 'خانم احمدی'],
            ['time' => '۱۷:۳۰', 'title' => 'فیزیک کنکور', 'teacher' => 'دکتر رضایی'],
            ['time' => '۱۹:۰۰', 'title' => 'مکالمهٔ زبان', 'teacher' => 'خانم کریمی'],
        ];
    }
    /* حروف اول اساتید برای پیل استک پنل */
    $farzanehHeroStack = [];
    foreach (array_slice($farzanehTeam, 0, 4) as $farzanehHeroMember) {
        $farzanehHeroStack[] = farzaneh_initial($farzanehHeroMember['name']);
    }
    if (empty($farzanehHeroStack)) {
        $farzanehHeroStack = ['ا', 'س', 'م', 'ن'];
    }
    $farzanehHeroTeacherCount = max(1, count($farzanehTeam));
    $farzanehHeroTeacherText = toPersianNumbers($farzanehHeroTeacherCount) . ' استاد باتجربه';

    // ---------- داده‌های نظرات ----------
    $farzanehTestTitle = trim((string)farzaneh_opt_raw('farzanehTestTitle'));
    $farzanehTestSubtitle = farzaneh_opt('farzanehTestSubtitle', 'تجربهٔ واقعی خانواده‌های فرزانه');
    $farzanehTestimonials = farzaneh_parse_testimonials(farzaneh_opt_raw('farzanehTestimonials'));

    // ---------- داده‌های وبلاگ ----------
    $farzanehBlogShow = farzaneh_opt('farzanehBlogShow', '1') === '1';
    $farzanehBlogTitle = farzaneh_opt('farzanehBlogTitle', 'مقالات آموزشی');
    $farzanehBlogSubtitle = farzaneh_opt('farzanehBlogSubtitle', 'راهنمای درس‌خواندن، تست‌زنی و برنامه‌ریزی تحصیلی');
    $farzanehBlogCount = max(1, min(12, (int)farzaneh_opt('farzanehBlogCount', '3')));

    // ---------- داده‌های پرسش‌ها ----------
    $farzanehFaqShow = farzaneh_opt('farzanehFaqShow', '1') === '1';
    $farzanehFaqTitle = farzaneh_opt('farzanehFaqTitle', 'پرسش‌های متداول والدین و دانش‌آموزان');
    $farzanehFaq      = farzaneh_parse_faq(farzaneh_opt_raw('farzanehFaq'));

    // ---------- داده‌های ثبت‌نام ----------
    $farzanehEnrollTitle = farzaneh_opt('farzanehEnrollTitle', 'ثبت‌نام دوره و دریافت مشاورهٔ رایگان');
    $farzanehEnrollSubtitle = farzaneh_opt('farzanehEnrollSubtitle', 'فرم را پر کنید؛ مشاوران آموزشی فرزانه برای سنجش سطح و تکمیل ثبت‌نام با شما تماس می‌گیرند');
    $farzanehEnrollCourseOptions = farzaneh_enroll_course_options();
    $farzanehEnrollLevels = array_filter(array_map('trim', explode(',', (string)farzaneh_opt('farzanehEnrollLevels', 'نمی‌دانم، مبتدی, متوسط, پیشرفته'))), function ($v) { return $v !== ''; });
    $farzanehEnrollGrades = array_filter(array_map('trim', explode(',', (string)farzaneh_opt('farzanehEnrollGrades', 'هفتم, هشتم, نهم, دهم, یازدهم, دوازدهم, فارغ‌التحصیل'))), function ($v) { return $v !== ''; });
    $farzanehEnrollTimes  = array_filter(array_map('trim', explode(',', (string)farzaneh_opt('farzanehEnrollTimes', 'صبح, ظهر, عصر, شب, فرقی ندارد'))), function ($v) { return $v !== ''; });

    // ---------- داده‌های تماس ----------
    $farzanehContactPhone  = farzaneh_opt_raw('farzanehContactPhone');
    $farzanehContactPhone2 = farzaneh_opt_raw('farzanehContactPhone2');
    $farzanehContactEmail  = farzaneh_opt_raw('farzanehContactEmail');
    $farzanehContactAddr   = farzaneh_opt_raw('farzanehContactAddress');
    $farzanehContactHours  = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string)farzaneh_opt_raw('farzanehContactHours'))));
    $farzanehMapEmbedRaw   = trim((string)farzaneh_opt_raw('farzanehMapEmbed'));
    // فقط src مجاز است (مقدار کامل iframe یا فقط آدرس src)
    $farzanehMapEmbed = '';
    if ($farzanehMapEmbedRaw !== '') {
        if (preg_match('#src=["\']([^"\']+)["\']#i', $farzanehMapEmbedRaw, $m)) {
            $farzanehMapEmbed = htmlspecialchars($m[1], ENT_QUOTES);
        } elseif (preg_match('#^https?://#i', $farzanehMapEmbedRaw)) {
            $farzanehMapEmbed = htmlspecialchars($farzanehMapEmbedRaw, ENT_QUOTES);
        }
    }
?>

    <!-- ==================== هیرو ==================== -->
    <section class="hero">
        <div class="container hero-inner">
            <div class="hero-content">
                <?php if (trim($farzanehHeroBadge) !== ''): ?>
                <span class="hero-badge">
                    <?php echo farzaneh_icon('sparkles', 15); ?>
                    <?php echo htmlspecialchars($farzanehHeroBadge, ENT_QUOTES); ?>
                </span>
                <?php endif; ?>
                <h1 class="hero-title"><?php echo htmlspecialchars($farzanehHeroTitle, ENT_QUOTES); ?></h1>
                <div class="hero-subtitle">
                    <?php foreach (array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $farzanehHeroSubtitle))) as $farzanehHeroP): ?>
                    <p><?php echo htmlspecialchars($farzanehHeroP, ENT_QUOTES); ?></p>
                    <?php endforeach; ?>
                </div>
                <div class="hero-actions">
                    <?php if (trim($farzanehHeroBtn1Text) !== ''): ?>
                    <a href="<?php echo htmlspecialchars(farzaneh_link_url($farzanehHeroBtn1Url), ENT_QUOTES); ?>" class="btn btn-primary btn-lg">
                        <?php echo farzaneh_icon('graduation-cap', 18); ?>
                        <?php echo htmlspecialchars($farzanehHeroBtn1Text, ENT_QUOTES); ?>
                    </a>
                    <?php endif; ?>
                    <?php if ($farzanehHeroBtn2Text !== null && trim($farzanehHeroBtn2Text) !== ''): ?>
                    <a href="<?php echo htmlspecialchars(farzaneh_link_url((string)$farzanehHeroBtn2Url), ENT_QUOTES); ?>" class="btn btn-ghost btn-lg">
                        <?php echo farzaneh_icon('book-open', 17); ?>
                        <?php echo htmlspecialchars($farzanehHeroBtn2Text, ENT_QUOTES); ?>
                    </a>
                    <?php endif; ?>
                </div>
                <?php if (!empty($farzanehHeroStats)): ?>
                <div class="hero-stats">
                    <?php foreach ($farzanehHeroStats as $farzanehStat): ?>
                    <div class="hero-stat">
                        <span class="hero-stat-num"><?php echo toPersianNumbers(htmlspecialchars($farzanehStat['num'], ENT_QUOTES)); ?></span>
                        <span class="hero-stat-label"><?php echo htmlspecialchars($farzanehStat['label'], ENT_QUOTES); ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="hero-visual" aria-hidden="true">
                <!-- حباب‌های نرم پس‌زمینه -->
                <span class="hero-blob hero-blob-1"></span>
                <span class="hero-blob hero-blob-2"></span>

                <!-- پنل داشبوردی «کلاس فرزانه» -->
                <div class="hero-board">
                    <div class="hb-head">
                        <span class="hb-dots"><i></i><i></i><i></i></span>
                        <strong class="hb-title"><?php echo farzaneh_icon('school', 14); ?> کلاس فرزانه</strong>
                        <span class="hb-live"><i></i> سال تحصیلی جاری</span>
                    </div>

                    <div class="hb-body">
                        <div class="hb-photo">
                            <img src="<?php echo htmlspecialchars($farzanehHeroImage, ENT_QUOTES); ?>" alt="" class="hb-img" loading="eager" decoding="async">
                            <span class="hb-photo-tag"><?php echo farzaneh_icon('flask-conical', 12); ?> آزمون شبیه‌ساز</span>
                        </div>
                        <div class="hb-side">
                            <div class="hb-ring">
                                <svg viewBox="0 0 100 100" class="hb-ring-svg" focusable="false">
                                    <circle class="hb-ring-track" cx="50" cy="50" r="43"></circle>
                                    <circle class="hb-ring-value" cx="50" cy="50" r="43"></circle>
                                </svg>
                                <div class="hb-ring-text">
                                    <strong data-ring-counter="98" data-ring-suffix="٪">۹۸٪</strong>
                                    <span>قبولی کنکور</span>
                                </div>
                            </div>
                            <div class="hb-chart">
                                <span class="hb-bars-label"><?php echo farzaneh_icon('trending-up', 12); ?> روند رشد نمرات</span>
                                <div class="hb-bars">
                                    <i style="--hb-h: 30%"></i>
                                    <i style="--hb-h: 46%"></i>
                                    <i style="--hb-h: 40%"></i>
                                    <i style="--hb-h: 62%"></i>
                                    <i style="--hb-h: 55%"></i>
                                    <i style="--hb-h: 84%"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="hb-schedule">
                        <div class="hb-sched-head">
                            <strong><?php echo farzaneh_icon('calendar', 13); ?> برنامهٔ امروز</strong>
                            <span class="hb-sched-note">به وقت تهران</span>
                        </div>
                        <ul class="hb-sched-list">
                            <?php foreach (array_slice($farzanehHeroSchedule, 0, 3) as $farzanehHeroSi => $farzanehHeroS): ?>
                            <li<?php echo $farzanehHeroSi === 0 ? ' class="is-now"' : ''; ?>>
                                <span class="hb-time" dir="ltr"><?php echo htmlspecialchars($farzanehHeroS['time'], ENT_QUOTES); ?></span>
                                <span class="hb-lesson">
                                    <?php echo htmlspecialchars($farzanehHeroS['title'], ENT_QUOTES); ?>
                                    <?php if (trim((string)$farzanehHeroS['teacher']) !== ''): ?>
                                    <em><?php echo htmlspecialchars($farzanehHeroS['teacher'], ENT_QUOTES); ?></em>
                                    <?php endif; ?>
                                </span>
                                <span class="hb-pulse"></span>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>

                    <div class="hb-foot">                        
                        <div class="hb-foot-text">
                            <strong><?php echo htmlspecialchars($farzanehHeroTeacherText, ENT_QUOTES); ?></strong>
                            <span>و مشاور تحصیلی اختصاصی</span>
                        </div>
                        <span class="hb-chip"><?php echo farzaneh_icon('award', 13); ?> رتبه‌آور</span>
                    </div>
                </div>

                <!-- عناصر شناور اطراف پنل -->
                <div class="hero-float hero-float-1"><?php echo farzaneh_icon('graduation-cap', 22); ?></div>
                <div class="hero-float hero-float-2"><?php echo farzaneh_icon('calculator', 19); ?></div>
                <div class="hero-float hero-float-3">
                    <strong><?php echo toPersianNumbers('15'); ?></strong>
                    <span>سال تجربه</span>
                </div>
            </div>
        </div>
    </section>

    <?php if (!empty($farzanehCourses) && $farzanehCoursesTitle !== ''): ?>
    <!-- ==================== دوره‌های آموزشی ==================== -->
    <section class="section courses-section" id="courses">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo farzaneh_icon('book-open', 14); ?> دوره‌های آموزشی</span>
                <h2 class="section-title"><?php echo htmlspecialchars($farzanehCoursesTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($farzanehCoursesSubtitle, ENT_QUOTES); ?></p>
            </div>
            <div class="courses-grid">
                <?php foreach ($farzanehCourses as $farzanehCourse): ?>
                <article class="course-card">
                    <div class="course-media<?php echo trim($farzanehCourse['image']) === '' ? ' course-media-pattern' : ''; ?>">
                        <?php if (trim($farzanehCourse['image']) !== ''): ?>
                        <img src="<?php echo htmlspecialchars($farzanehCourse['image'], ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($farzanehCourse['title'], ENT_QUOTES); ?>" class="course-img" loading="lazy">
                        <?php else: ?>
                        <span class="course-media-icon"><?php echo farzaneh_icon('graduation-cap', 44); ?></span>
                        <?php endif; ?>
                        <?php if (trim($farzanehCourse['badge']) !== ''): ?>
                        <span class="course-badge"><?php echo farzaneh_icon('star', 12); ?> <?php echo htmlspecialchars($farzanehCourse['badge'], ENT_QUOTES); ?></span>
                        <?php endif; ?>
                        <?php if (trim($farzanehCourse['level']) !== ''): ?>
                        <span class="course-level <?php echo farzaneh_level_class($farzanehCourse['level']); ?>"><?php echo htmlspecialchars($farzanehCourse['level'], ENT_QUOTES); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="course-body">
                        <?php if (trim($farzanehCourse['category']) !== ''): ?>
                        <span class="course-cat"><?php echo farzaneh_icon('tag', 13); ?> <?php echo htmlspecialchars($farzanehCourse['category'], ENT_QUOTES); ?></span>
                        <?php endif; ?>
                        <h3 class="course-title"><?php echo htmlspecialchars($farzanehCourse['title'], ENT_QUOTES); ?></h3>
                        <div class="course-meta">
                            <?php if (trim($farzanehCourse['teacher']) !== ''): ?>
                            <span><?php echo farzaneh_icon('user', 14); ?> <?php echo htmlspecialchars($farzanehCourse['teacher'], ENT_QUOTES); ?></span>
                            <?php endif; ?>
                            <?php if (trim($farzanehCourse['duration']) !== ''): ?>
                            <span><?php echo farzaneh_icon('clock', 14); ?> <?php echo toPersianNumbers(htmlspecialchars($farzanehCourse['duration'], ENT_QUOTES)); ?></span>
                            <?php endif; ?>
                        </div>
                        <?php if ($farzanehCourse['desc'] !== ''): ?>
                        <p class="course-desc"><?php echo htmlspecialchars($farzanehCourse['desc'], ENT_QUOTES); ?></p>
                        <?php endif; ?>
                        <div class="course-foot">
                            <div class="course-price">
                                <?php if ($farzanehCourse['price'] !== ''): ?>
                                <span class="course-price-current"><?php echo toPersianNumbers(htmlspecialchars($farzanehCourse['price'], ENT_QUOTES)); ?></span>
                                <?php if ($farzanehCourse['oldPrice'] !== ''): ?>
                                <span class="course-price-old"><?php echo toPersianNumbers(htmlspecialchars($farzanehCourse['oldPrice'], ENT_QUOTES)); ?></span>
                                <?php endif; ?>
                                <?php else: ?>
                                <span class="course-price-current">تماس بگیرید</span>
                                <?php endif; ?>
                            </div>
                            <a href="#enroll" class="btn btn-course" data-course="<?php echo htmlspecialchars($farzanehCourse['title'], ENT_QUOTES); ?>">
                                <?php echo farzaneh_icon('send', 15); ?>
                                ثبت‌نام
                            </a>
                        </div>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($farzanehClasses) && $farzanehClassesTitle !== ''): ?>
    <!-- ==================== کلاس‌ها و برنامهٔ هفتگی ==================== -->
    <section class="section classes-section" id="classes">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo farzaneh_icon('calendar', 14); ?> برنامهٔ هفتگی</span>
                <h2 class="section-title"><?php echo htmlspecialchars($farzanehClassesTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($farzanehClassesSubtitle, ENT_QUOTES); ?></p>
            </div>
            <div class="classes-table">
                <div class="classes-row classes-head-row" role="row">
                    <span class="cl-cell cl-title"><?php echo farzaneh_icon('notebook-pen', 14); ?> کلاس</span>
                    <span class="cl-cell cl-teacher"><?php echo farzaneh_icon('user', 14); ?> استاد</span>
                    <span class="cl-cell cl-days"><?php echo farzaneh_icon('calendar', 14); ?> روزها</span>
                    <span class="cl-cell cl-time"><?php echo farzaneh_icon('clock', 14); ?> ساعت</span>
                    <span class="cl-cell cl-capacity"><?php echo farzaneh_icon('users', 14); ?> ظرفیت</span>
                    <span class="cl-cell cl-status"><?php echo farzaneh_icon('check-circle', 14); ?> وضعیت</span>
                </div>
                <?php foreach ($farzanehClasses as $farzanehClass): ?>
                <div class="classes-row" role="row">
                    <span class="cl-cell cl-title"><strong><?php echo htmlspecialchars($farzanehClass['title'], ENT_QUOTES); ?></strong></span>
                    <span class="cl-cell cl-teacher"><?php echo htmlspecialchars($farzanehClass['teacher'], ENT_QUOTES); ?></span>
                    <span class="cl-cell cl-days"><?php echo toPersianNumbers(htmlspecialchars($farzanehClass['days'], ENT_QUOTES)); ?></span>
                    <span class="cl-cell cl-time"><?php echo toPersianNumbers(htmlspecialchars($farzanehClass['time'], ENT_QUOTES)); ?></span>
                    <span class="cl-cell cl-capacity"><?php echo toPersianNumbers(htmlspecialchars($farzanehClass['capacity'], ENT_QUOTES)); ?></span>
                    <span class="cl-cell cl-status">
                        <span class="cls-status <?php echo farzaneh_class_status_class($farzanehClass['status']); ?>"><?php echo htmlspecialchars($farzanehClass['status'], ENT_QUOTES); ?></span>
                    </span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($farzanehTeam) && $farzanehTeamTitle !== ''): ?>
    <!-- ==================== اساتید ==================== -->
    <section class="section team-section" id="team">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo farzaneh_icon('users', 14); ?> اساتید ما</span>
                <h2 class="section-title"><?php echo htmlspecialchars($farzanehTeamTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($farzanehTeamSubtitle, ENT_QUOTES); ?></p>
            </div>
            <?php
            /* شبکهٔ داینامیک: با هر تعداد استاد، کارت‌ها کش می‌آیند و جای
               کارت حذف‌شده را پر می‌کنند؛ ردیف آخر همیشه وسط‌چین می‌ماند */
            ?>
            <div class="team-grid">
                <?php foreach ($farzanehTeam as $farzanehMember): ?>
                <div class="team-card">
                    <?php if (trim($farzanehMember['photo']) !== ''): ?>
                    <img src="<?php echo htmlspecialchars($farzanehMember['photo'], ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($farzanehMember['name'], ENT_QUOTES); ?>" class="team-photo" loading="lazy">
                    <?php else: ?>
                    <span class="team-avatar"><?php echo htmlspecialchars(farzaneh_initial($farzanehMember['name']), ENT_QUOTES); ?></span>
                    <?php endif; ?>
                    <div class="team-info">
                        <strong class="team-name"><?php echo htmlspecialchars($farzanehMember['name'], ENT_QUOTES); ?></strong>
                        <span class="team-role"><?php echo htmlspecialchars($farzanehMember['role'], ENT_QUOTES); ?></span>
                        <?php if ($farzanehMember['desc'] !== ''): ?>
                        <p class="team-desc"><?php echo htmlspecialchars($farzanehMember['desc'], ENT_QUOTES); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($farzanehAboutTitle !== '' && ($farzanehAboutText !== '' || !empty($farzanehAboutFeatures))): ?>
    <!-- ==================== چرا فرزانه ==================== -->
    <section class="section about-section" id="about">
        <div class="container about-inner">
            <div class="about-visual">
                <div class="about-img-frame">
                    <img src="<?php echo htmlspecialchars($farzanehAboutImage, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($farzanehAboutTitle, ENT_QUOTES); ?>" class="about-img" loading="lazy">
                </div>
                <div class="about-card">
                    <?php echo farzaneh_icon('heart-pulse', 22); ?>
                    <strong>اولین جلسهٔ مشاوره رایگان</strong>
                </div>
            </div>
            <div class="about-content">
                <span class="section-tag"><?php echo farzaneh_icon('school', 14); ?> چرا فرزانه</span>
                <h2 class="section-title about-title"><?php echo htmlspecialchars($farzanehAboutTitle, ENT_QUOTES); ?></h2>
                <?php foreach (array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $farzanehAboutText))) as $farzanehAboutP): ?>
                <p class="about-text"><?php echo htmlspecialchars($farzanehAboutP, ENT_QUOTES); ?></p>
                <?php endforeach; ?>
                <?php if (!empty($farzanehAboutFeatures)): ?>
                <div class="about-features">
                    <?php foreach ($farzanehAboutFeatures as $farzanehFeature): ?>
                    <div class="about-feature">
                        <span class="about-feature-icon"><?php echo farzaneh_icon($farzanehFeature['icon'], 19); ?></span>
                        <div class="about-feature-text">
                            <strong><?php echo htmlspecialchars($farzanehFeature['title'], ENT_QUOTES); ?></strong>
                            <?php if ($farzanehFeature['desc'] !== ''): ?>
                            <span><?php echo htmlspecialchars($farzanehFeature['desc'], ENT_QUOTES); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                <?php if ($farzanehAboutBtnText !== ''): ?>
                <a href="<?php echo htmlspecialchars(farzaneh_link_url($farzanehAboutBtnUrl), ENT_QUOTES); ?>" class="btn btn-primary">
                    <?php echo farzaneh_icon('phone-call', 16); ?>
                    <?php echo htmlspecialchars($farzanehAboutBtnText, ENT_QUOTES); ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($farzanehStatsShow && !empty($farzanehGlance)): ?>
    <!-- ==================== فرزانه در یک نگاه (دستاوردها) ==================== -->
    <section class="section stats-band-section" id="stats">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo farzaneh_icon('trophy', 14); ?> دستاوردهای ما</span>
                <h2 class="section-title"><?php echo htmlspecialchars($farzanehStatsTitle, ENT_QUOTES); ?></h2>
            </div>
            <div class="stats-band">
                <?php foreach ($farzanehGlance as $farzanehG): ?>
                <?php
                /* اگر مقدار با عدد شروع شود: بخش عددی شمارندهٔ انیمیشنی می‌شود و
                   باقی‌مانده (٪ / + / متن) به‌عنوان پسوند حفظ می‌شود */
                $farzanehGValue = trim((string)$farzanehG['value']);
                $farzanehGTarget = '';
                $farzanehGSuffix = '';
                if (preg_match('#^([۰-۹0-9][۰-۹0-9,،٬]*)\s*(.*)$#u', $farzanehGValue, $farzanehGm)) {
                    $farzanehGTarget = farzaneh_to_en_digits(preg_replace('#[,،٬]#u', '', $farzanehGm[1]));
                    $farzanehGSuffix = trim($farzanehGm[2]);
                    if ($farzanehGTarget === '' || !ctype_digit($farzanehGTarget)) {
                        $farzanehGTarget = '';
                    }
                }
                ?>
                <div class="stat-box">
                    <span class="stat-icon"><?php echo farzaneh_icon($farzanehG['icon'], 24); ?></span>
                    <?php if ($farzanehGTarget !== ''): ?>
                    <span class="stat-num" data-counter="<?php echo htmlspecialchars($farzanehGTarget, ENT_QUOTES); ?>"<?php echo $farzanehGSuffix !== '' ? ' data-suffix="' . htmlspecialchars($farzanehGSuffix, ENT_QUOTES) . '"' : ''; ?>><?php echo toPersianNumbers(htmlspecialchars($farzanehGValue, ENT_QUOTES)); ?></span>
                    <?php else: ?>
                    <span class="stat-num"><?php echo toPersianNumbers(htmlspecialchars($farzanehGValue, ENT_QUOTES)); ?></span>
                    <?php endif; ?>
                    <span class="stat-label"><?php echo htmlspecialchars($farzanehG['label'], ENT_QUOTES); ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($farzanehTestimonials) && $farzanehTestTitle !== ''): ?>
    <!-- ==================== نظرات دانش‌آموزان و والدین ==================== -->
    <section class="section testimonials-section" id="testimonials">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo farzaneh_icon('star', 14); ?> نظرات واقعی</span>
                <h2 class="section-title"><?php echo htmlspecialchars($farzanehTestTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($farzanehTestSubtitle, ENT_QUOTES); ?></p>
            </div>
            <?php
            /* کاروسل تک‌کارت — هرچند نظر ثبت شده باشد، یکی نمایش داده
               می‌شود و به‌صورت خودگردان با افکت محو/لغزش تعویض می‌شود */
            $farzanehTestiCount = count($farzanehTestimonials);
            ?>
            <div class="testimonials-carousel<?php echo $farzanehTestiCount < 2 ? ' is-single' : ''; ?>" id="testimonialsCarousel">
                <div class="t-stage">
                    <?php foreach ($farzanehTestimonials as $farzanehTi => $farzanehTestimonial): ?>
                    <figure class="testimonial-card<?php echo $farzanehTi === 0 ? ' is-active' : ''; ?>"
                             data-name="نظر <?php echo htmlspecialchars($farzanehTestimonial['name'], ENT_QUOTES); ?>"
                             aria-hidden="<?php echo $farzanehTi === 0 ? 'false' : 'true'; ?>">
                        <div class="testimonial-meta">
                            <span class="testimonial-role"><?php echo htmlspecialchars($farzanehTestimonial['meta'], ENT_QUOTES); ?></span>
                        </div>
                        <blockquote class="testimonial-text">
                            <?php echo farzaneh_icon('quote', 20); ?>
                            <p><?php echo htmlspecialchars($farzanehTestimonial['text'], ENT_QUOTES); ?></p>
                        </blockquote>
                        <figcaption class="testimonial-author">
                            <?php if (trim($farzanehTestimonial['photo']) !== ''): ?>
                            <img src="<?php echo htmlspecialchars($farzanehTestimonial['photo'], ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($farzanehTestimonial['name'], ENT_QUOTES); ?>" class="testimonial-photo" loading="lazy">
                            <?php else: ?>
                            <span class="testimonial-avatar" aria-hidden="true"><?php echo htmlspecialchars(farzaneh_initial($farzanehTestimonial['name']), ENT_QUOTES); ?></span>
                            <?php endif; ?>
                            <strong><?php echo htmlspecialchars($farzanehTestimonial['name'], ENT_QUOTES); ?></strong>
                        </figcaption>
                    </figure>
                    <?php endforeach; ?>
                </div>
                <?php if ($farzanehTestiCount > 1): ?>
                <div class="t-controls">
                    <button type="button" class="t-arrow t-prev" aria-label="نظر قبلی"><?php echo farzaneh_icon('chevron-right', 18); ?></button>
                    <div class="t-dots" role="tablist" aria-label="انتخاب نظر"></div>
                    <button type="button" class="t-arrow t-next" aria-label="نظر بعدی"><?php echo farzaneh_icon('chevron-left', 18); ?></button>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($farzanehBlogShow): ?>
    <!-- ==================== آخرین مقالات ==================== -->
    <section class="section blog-section" id="blog">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo farzaneh_icon('library', 14); ?> وبلاگ</span>
                <h2 class="section-title"><?php echo htmlspecialchars($farzanehBlogTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($farzanehBlogSubtitle, ENT_QUOTES); ?></p>
            </div>
            <?php
            // آخرین نوشته‌های منتشرشده (کوئری اختصاصی پوسته — شامل چکیده، تصویر و فیلدهای آموزشی)
            $farzanehRecentPosts = farzaneh_recent_posts($farzanehBlogCount);
            ?>
            <?php if (!empty($farzanehRecentPosts)): ?>
            <div class="blog-grid">
                <?php foreach ($farzanehRecentPosts as $farzanehRecentPost): ?>
                <article class="blog-card">
                    <a href="<?php echo htmlspecialchars($farzanehRecentPost['url'], ENT_QUOTES); ?>" class="blog-card-link">
                        <div class="blog-card-thumb">
                            <img src="<?php echo htmlspecialchars($farzanehRecentPost['thumb'], ENT_QUOTES); ?>" alt="<?php echo toPersianNumbers(htmlspecialchars($farzanehRecentPost['title'], ENT_QUOTES)); ?>" loading="lazy">
                            <?php if (is_numeric($farzanehRecentPost['readingTime']) && (int)$farzanehRecentPost['readingTime'] > 0): ?>
                            <span class="blog-card-badge"><?php echo farzaneh_icon('clock', 13); ?> <?php echo toPersianNumbers($farzanehRecentPost['readingTime']); ?> دقیقه مطالعه</span>
                            <?php elseif ($farzanehRecentPost['grade'] !== ''): ?>
                            <span class="blog-card-badge"><?php echo farzaneh_icon('graduation-cap', 13); ?> <?php echo htmlspecialchars($farzanehRecentPost['grade'], ENT_QUOTES); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="blog-card-body">
                            <div class="blog-card-meta">
                                <span><?php echo farzaneh_icon('calendar', 13); ?> <?php echo farzaneh_jalali_date($farzanehRecentPost['created'], 'j F Y'); ?></span>
                                <?php if (farzaneh_opt('farzanehShowViews', '1') === '1' && $farzanehRecentPost['views'] > 0): ?>
                                <span><?php echo farzaneh_icon('eye', 13); ?> <?php echo farzaneh_num($farzanehRecentPost['views']); ?></span>
                                <?php endif; ?>
                            </div>
                            <h3 class="blog-card-title"><?php echo toPersianNumbers(htmlspecialchars($farzanehRecentPost['title'], ENT_QUOTES)); ?></h3>
                            <p class="blog-card-excerpt"><?php echo toPersianNumbers(mb_substr($farzanehRecentPost['excerpt'], 0, 100, 'UTF-8') . '…'); ?></p>
                            <span class="blog-card-more">ادامه مطلب <?php echo farzaneh_icon('arrow-left', 14); ?></span>
                        </div>
                    </a>
                </article>
                <?php endforeach; ?>
            </div>
            <div class="section-more">
                <a href="<?php echo htmlspecialchars(farzaneh_blog_url(), ENT_QUOTES); ?>" class="btn btn-ghost">
                    مشاهدهٔ همهٔ مقالات
                    <?php echo farzaneh_icon('arrow-left', 15); ?>
                </a>
            </div>
            <?php else: ?>
            <div class="archive-empty">
                <?php echo farzaneh_icon('library', 44); ?>
                <p>هنوز مقاله‌ای منتشر نشده است.</p>
            </div>
            <?php endif; ?>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($farzanehFaqShow && !empty($farzanehFaq)): ?>
    <!-- ==================== پرسش‌های متداول ==================== -->
    <section class="section faq-section" id="faq">
        <div class="container faq-inner">
            <div class="faq-head">
                <span class="section-tag"><?php echo farzaneh_icon('lightbulb', 14); ?> پرسش و پاسخ</span>
                <h2 class="section-title"><?php echo htmlspecialchars($farzanehFaqTitle, ENT_QUOTES); ?></h2>
            </div>
            <div class="faq-list" id="faqList">
                <?php foreach ($farzanehFaq as $farzanehFaqItem): ?>
                <details class="faq-item">
                    <summary class="faq-q">
                        <?php echo farzaneh_icon('chevron-down', 17); ?>
                        <span><?php echo htmlspecialchars($farzanehFaqItem['q'], ENT_QUOTES); ?></span>
                    </summary>
                    <div class="faq-a"><?php echo htmlspecialchars($farzanehFaqItem['a'], ENT_QUOTES); ?></div>
                </details>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- ==================== ثبت‌نام و تماس ==================== -->
    <section class="section contact-section" id="enroll">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo farzaneh_icon('graduation-cap', 14); ?> ثبت‌نام و مشاوره</span>
                <h2 class="section-title"><?php echo htmlspecialchars($farzanehEnrollTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($farzanehEnrollSubtitle, ENT_QUOTES); ?></p>
            </div>

            <div class="contact-grid" id="contact">
                <!-- اطلاعات تماس -->
                <div class="contact-info">
                    <h3 class="contact-info-title"><?php echo farzaneh_icon('phone-call', 18); ?> راه‌های ارتباطی</h3>
                    <ul class="contact-list">
                        <?php if ($farzanehContactPhone !== null && trim($farzanehContactPhone) !== ''): ?>
                        <li>
                            <span class="contact-ic"><?php echo farzaneh_icon('phone', 18); ?></span>
                            <div>
                                <strong>تلفن آموزشگاه</strong>
                                <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $farzanehContactPhone), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($farzanehContactPhone), ENT_QUOTES); ?></a>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php if ($farzanehContactPhone2 !== null && trim($farzanehContactPhone2) !== ''): ?>
                        <li>
                            <span class="contact-ic"><?php echo farzaneh_icon('message-circle', 18); ?></span>
                            <div>
                                <strong>همراه ثبت‌نام</strong>
                                <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $farzanehContactPhone2), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($farzanehContactPhone2), ENT_QUOTES); ?></a>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php if ($farzanehContactEmail !== null && trim($farzanehContactEmail) !== ''): ?>
                        <li>
                            <span class="contact-ic"><?php echo farzaneh_icon('mail', 18); ?></span>
                            <div>
                                <strong>ایمیل</strong>
                                <a href="mailto:<?php echo htmlspecialchars($farzanehContactEmail, ENT_QUOTES); ?>"><?php echo htmlspecialchars($farzanehContactEmail, ENT_QUOTES); ?></a>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php if ($farzanehContactAddr !== null && trim($farzanehContactAddr) !== ''): ?>
                        <li>
                            <span class="contact-ic"><?php echo farzaneh_icon('map-pin', 18); ?></span>
                            <div>
                                <strong>آدرس آموزشگاه</strong>
                                <span><?php echo htmlspecialchars(toPersianNumbers($farzanehContactAddr), ENT_QUOTES); ?></span>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php foreach ($farzanehContactHours as $farzanehHour): ?>
                        <li>
                            <span class="contact-ic"><?php echo farzaneh_icon('clock', 18); ?></span>
                            <div>
                                <strong>ساعت کاری</strong>
                                <span><?php echo htmlspecialchars(toPersianNumbers($farzanehHour), ENT_QUOTES); ?></span>
                            </div>
                        </li>
                        <?php endforeach; ?>
                    </ul>

                    <?php
                    $farzanehSocialActive = array_filter($farzanehSocial ?? [], function ($u) { return trim((string)$u) !== ''; });
                    if (!empty($farzanehSocialActive)):
                    ?>
                    <div class="contact-social">
                        <?php foreach ($farzanehSocialActive as $farzanehNet => $farzanehUrl): ?>
                        <a href="<?php echo htmlspecialchars($farzanehUrl, ENT_QUOTES); ?>" target="_blank" rel="noopener" aria-label="<?php echo ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام', 'whatsapp' => 'واتس‌اپ', 'youtube' => 'آپارات/یوتیوب'][$farzanehNet]; ?>">
                            <?php echo farzaneh_icon($farzanehNet === 'telegram' ? 'send' : ($farzanehNet === 'whatsapp' ? 'message-circle' : $farzanehNet), 19); ?>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- فرم ثبت‌نام دوره -->
                <div class="enroll-panel">
                    <?php
                    /*
                     * ارسال به نقطهٔ پایانی اختصاصی /farzaneh-register (الگو از بوکینگ نهال)؛
                     * اگر مسیر هنوز ثبت نشده باشد، آدرس صفحهٔ جاری جایگزین می‌شود.
                     * توکن امنیتی _ مطابق Widget\Security::getToken برای همان صفحه تولید می‌شود
                     * و سمت سرور با getToken(referer) اعتبارسنجی می‌شود.
                     */
                    $farzanehEnrollAction = farzaneh_enroll_endpoint();
                    try {
                        $farzanehEnrollToken = htmlspecialchars(
                            \Widget\Security::alloc()->getToken($this->request->getRequestUrl()),
                            ENT_QUOTES,
                            'UTF-8'
                        );
                    } catch (\Throwable $e) {
                        $farzanehEnrollToken = '';
                    }
                    ?>
                    <form class="enroll-form" id="enrollForm" method="post"
                          action="<?php echo htmlspecialchars($farzanehEnrollAction, ENT_QUOTES); ?>" novalidate>
                        <input type="hidden" name="farzanehEnroll" value="1">
                        <?php if ($farzanehEnrollToken !== ''): ?>
                        <input type="hidden" name="_" value="<?php echo $farzanehEnrollToken; ?>">
                        <?php endif; ?>

                        <!-- تلهٔ هرزنامه — باید خالی بماند -->
                        <input type="text" name="farzanehHp" class="hp-field" tabindex="-1" autocomplete="off" aria-hidden="true">

                        <div class="enroll-form-row">
                            <div class="enroll-field">
                                <label for="farzanehName">نام و نام خانوادگی <span class="req">*</span></label>
                                <input type="text" id="farzanehName" name="farzanehName" class="enroll-input" placeholder="مثلاً: سارا محمدی" required>
                            </div>
                            <div class="enroll-field">
                                <label for="farzanehPhone">شمارهٔ تلفن همراه <span class="req">*</span></label>
                                <input type="tel" id="farzanehPhone" name="farzanehPhone" class="enroll-input" placeholder="۰۹۱۲۳۴۵۶۷۸۹" required>
                            </div>
                        </div>

                        <div class="enroll-form-row">
                            <?php if (!empty($farzanehEnrollCourseOptions)): ?>
                            <div class="enroll-field">
                                <label for="farzanehCourse">انتخاب دوره</label>
                                <select id="farzanehCourse" name="farzanehCourse" class="enroll-input enroll-select">
                                    <option value="">انتخاب کنید…</option>
                                    <?php foreach ($farzanehEnrollCourseOptions as $farzanehEnrollCourse): ?>
                                    <option value="<?php echo htmlspecialchars($farzanehEnrollCourse, ENT_QUOTES); ?>"><?php echo htmlspecialchars($farzanehEnrollCourse, ENT_QUOTES); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($farzanehEnrollGrades)): ?>
                            <div class="enroll-field">
                                <label for="farzanehGrade">پایهٔ تحصیلی</label>
                                <select id="farzanehGrade" name="farzanehGrade" class="enroll-input enroll-select">
                                    <option value="">انتخاب کنید…</option>
                                    <?php foreach ($farzanehEnrollGrades as $farzanehEnrollGrade): ?>
                                    <option value="<?php echo htmlspecialchars($farzanehEnrollGrade, ENT_QUOTES); ?>"><?php echo htmlspecialchars($farzanehEnrollGrade, ENT_QUOTES); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="enroll-form-row">
                            <?php if (!empty($farzanehEnrollLevels)): ?>
                            <div class="enroll-field">
                                <label for="farzanehLevel">سطح آموزشی</label>
                                <select id="farzanehLevel" name="farzanehLevel" class="enroll-input enroll-select">
                                    <option value="">انتخاب کنید…</option>
                                    <?php foreach ($farzanehEnrollLevels as $farzanehEnrollLevel): ?>
                                    <option value="<?php echo htmlspecialchars($farzanehEnrollLevel, ENT_QUOTES); ?>"><?php echo htmlspecialchars($farzanehEnrollLevel, ENT_QUOTES); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($farzanehEnrollTimes)): ?>
                            <div class="enroll-field">
                                <label for="farzanehTime">زمان مناسب کلاس</label>
                                <select id="farzanehTime" name="farzanehTime" class="enroll-input enroll-select">
                                    <option value="">انتخاب کنید…</option>
                                    <?php foreach ($farzanehEnrollTimes as $farzanehEnrollTime): ?>
                                    <option value="<?php echo htmlspecialchars($farzanehEnrollTime, ENT_QUOTES); ?>"><?php echo htmlspecialchars($farzanehEnrollTime, ENT_QUOTES); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="enroll-field">
                            <label for="farzanehNote">توضیحات (اختیاری)</label>
                            <textarea id="farzanehNote" name="farzanehNote" class="enroll-input" rows="3" placeholder="هر نکته‌ای که لازم است بدانیم: درس‌های ضعیف‌تر، زمان‌های مناسب، سابقهٔ کلاس…"></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg btn-block" id="enrollSubmitBtn">
                            <?php echo farzaneh_icon('send', 17); ?>
                            <span>ثبت درخواست و دریافت مشاوره</span>
                        </button>

                        <p class="enroll-form-note">
                            <?php echo farzaneh_icon('shield-check', 13); ?>
                            اطلاعات شما محفوظ است و فقط برای تماس مشاوران آموزشی استفاده می‌شود.
                        </p>

                        <div class="enroll-alert enroll-alert-success" id="enrollSuccess" hidden>
                            <?php echo farzaneh_icon('check-circle', 20); ?>
                            <div>
                                <strong>درخواست شما ثبت شد!</strong>
                                <span>مشاوران آموزشی در اولین فرصت برای سنجش سطح و تکمیل ثبت‌نام با شما تماس می‌گیرند.</span>
                            </div>
                        </div>
                        <div class="enroll-alert enroll-alert-error" id="enrollError" hidden>
                            <?php echo farzaneh_icon('x', 20); ?>
                            <div>
                                <strong>خطا در ثبت درخواست!</strong>
                                <span id="enrollErrorText">لطفاً دوباره تلاش کنید.</span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <?php if ($farzanehMapEmbed !== ''): ?>
            <div class="contact-map">
                <iframe src="<?php echo $farzanehMapEmbed; ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="نقشهٔ آموزشگاه" allowfullscreen></iframe>
            </div>
            <?php endif; ?>
        </div>
    </section>

<?php

else:

    /* ================================================================
     *  فهرست وبلاگ — مسیر آرشیو (/blog/) و صفحه‌بندی آن
     * ================================================================ */
?>
    <div class="container archive-wrap">
        <header class="archive-head">
            <span class="section-tag"><?php echo farzaneh_icon('file-text', 14); ?> وبلاگ</span>
            <h1 class="archive-title">
                <?php if ($this->is('archive')): ?>
                    <?php $this->archiveTitle(['category' => _t('دستهٔ %s'), 'search' => _t('جستجو: %s'), 'tag' => _t('برچسب %s'), 'author' => _t('نوشته‌های %s'), 'date' => _t('آرشیو %s')], '', ''); ?>
                <?php else: ?>
                    <?php echo htmlspecialchars(farzaneh_opt('farzanehBlogTitle', 'مقالات آموزشی') === 'مقالات آموزشی' ? 'همهٔ مقالات' : farzaneh_opt('farzanehBlogTitle', 'مقالات آموزشی'), ENT_QUOTES); ?>
                <?php endif; ?>
            </h1>
            <p class="section-subtitle"><?php echo htmlspecialchars(farzaneh_opt('farzanehBlogSubtitle', 'راهنمای درس‌خواندن، تست‌زنی و برنامه‌ریزی تحصیلی'), ENT_QUOTES); ?></p>
        </header>

        <?php if ($this->have()): ?>
        <div class="archive-grid">
            <?php while ($this->next()): ?>
            <article class="blog-card">
                <a href="<?php $this->permalink(); ?>" class="blog-card-link">
                    <div class="blog-card-thumb">
                        <img src="<?php echo htmlspecialchars(farzaneh_thumbnail($this), ENT_QUOTES); ?>" alt="<?php echo farzaneh_fa_title($this); ?>" loading="lazy">
                        <?php
                        $farzanehListReading = farzaneh_reading_time($this);
                        $farzanehListGrade = farzaneh_grade($this);
                        ?>
                        <?php if ($farzanehListReading !== ''): ?>
                        <span class="blog-card-badge"><?php echo farzaneh_icon('clock', 13); ?> <?php echo $farzanehListReading; ?> دقیقه مطالعه</span>
                        <?php elseif ($farzanehListGrade !== ''): ?>
                        <span class="blog-card-badge"><?php echo farzaneh_icon('graduation-cap', 13); ?> <?php echo htmlspecialchars($farzanehListGrade, ENT_QUOTES); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="blog-card-body">
                        <div class="blog-card-meta">
                            <span><?php echo farzaneh_icon('calendar', 13); ?> <?php echo farzaneh_post_date($this, 'j F Y'); ?></span>
                            <?php if (farzaneh_opt('farzanehShowViews', '1') === '1'): ?>
                            <span><?php echo farzaneh_icon('eye', 13); ?> <?php echo farzaneh_num(farzaneh_views($this)); ?></span>
                            <?php endif; ?>
                        </div>
                        <h2 class="blog-card-title"><?php echo farzaneh_fa_title($this); ?></h2>
                        <p class="blog-card-excerpt"><?php echo toPersianNumbers(mb_substr(trim(strip_tags((string)$this->excerpt)), 0, 100, 'UTF-8') . '...'); ?></p>
                        <span class="blog-card-more">ادامه مطلب <?php echo farzaneh_icon('arrow-left', 14); ?></span>
                    </div>
                </a>
            </article>
            <?php endwhile; ?>
        </div>
        <?php else: ?>
        <div class="archive-empty">
            <?php echo farzaneh_icon('search', 44); ?>
            <p>هنوز مقاله‌ای منتشر نشده است.</p>
            <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-ghost">بازگشت به خانه</a>
        </div>
        <?php endif; ?>

        <?php farzaneh_page_nav($this); ?>
    </div>
<?php endif;

$this->need('footer.php');
