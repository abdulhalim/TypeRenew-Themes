<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$GLOBALS['farzanehPostJs'] = true;

$this->need('header.php');

$farzanehShowViews = farzaneh_opt('farzanehShowViews', '1') === '1';
$farzanehShowLikes = farzaneh_opt('farzanehShowLikes', '1') === '1';
$farzanehShowRelated = farzaneh_opt('farzanehShowRelated', '1') === '1';
$farzanehShowAuthorBox = farzaneh_opt('farzanehShowAuthorBox', '1') === '1';
$farzanehInstituteName = farzaneh_opt('farzanehInstituteName', (string)$this->options->title);
$farzanehPostReading = farzaneh_reading_time($this);
$farzanehPostGrade = farzaneh_grade($this);
?>

<article class="post-wrap container" itemscope itemtype="https://schema.org/BlogPosting">

    <!-- ---------- سربرگ نوشته ---------- -->
    <header class="post-head">
        <nav class="post-breadcrumb" aria-label="مسیر">
            <a href="<?php $this->options->siteUrl(); ?>">خانه</a>
            <span class="crumb-sep">/</span>
            <a href="<?php echo htmlspecialchars(farzaneh_blog_url(), ENT_QUOTES); ?>">مقالات</a>
            <span class="crumb-sep">/</span>
            <span aria-current="page"><?php echo farzaneh_fa_title($this); ?></span>
        </nav>

        <h1 class="post-title" itemprop="name headline"><?php echo farzaneh_fa_title($this); ?></h1>

        <div class="post-meta">
            <span class="post-meta-item" itemprop="author" itemscope itemtype="https://schema.org/Person">
                <?php echo farzaneh_icon('user', 15); ?>
                <span itemprop="name"><?php $this->author(); ?></span>
            </span>
            <span class="post-meta-item">
                <?php echo farzaneh_icon('calendar', 15); ?>
                <time datetime="<?php $this->date('c'); ?>" itemprop="datePublished"><?php echo farzaneh_post_date($this, 'j F Y'); ?></time>
            </span>
            <span class="post-meta-item">
                <?php echo farzaneh_icon('folder', 15); ?>
                <?php $this->category(','); ?>
            </span>
            <?php if ($farzanehPostReading !== ''): ?>
            <span class="post-meta-item post-meta-badge">
                <?php echo farzaneh_icon('clock', 15); ?>
                <?php echo $farzanehPostReading; ?> دقیقه مطالعه
            </span>
            <?php endif; ?>
            <?php if ($farzanehPostGrade !== ''): ?>
            <span class="post-meta-item post-meta-badge">
                <?php echo farzaneh_icon('graduation-cap', 15); ?>
                <?php echo htmlspecialchars($farzanehPostGrade, ENT_QUOTES); ?>
            </span>
            <?php endif; ?>
            <?php if ($farzanehShowViews): ?>
            <span class="post-meta-item post-views" id="postViews">
                <?php echo farzaneh_icon('eye', 15); ?>
                <?php echo farzaneh_num(farzaneh_views($this)); ?> بازدید
            </span>
            <?php endif; ?>
            <span class="post-meta-item">
                <?php echo farzaneh_icon('message-square', 15); ?>
                <a href="#comments"><?php ob_start(); $this->commentsNum('بدون دیدگاه', '۱ دیدگاه', '%d دیدگاه'); echo toPersianNumbers(ob_get_clean()); ?></a>
            </span>
        </div>
    </header>

    <!-- ---------- تصویر شاخص ---------- -->
    <?php $farzanehCover = farzaneh_thumbnail($this, false); if ($farzanehCover !== ''): ?>
    <figure class="post-cover">
        <img src="<?php echo htmlspecialchars($farzanehCover, ENT_QUOTES); ?>" alt="<?php echo farzaneh_fa_title($this); ?>" itemprop="image">
    </figure>
    <?php endif; ?>

    <!-- ---------- محتوای نوشته ---------- -->
    <div class="post-content" itemprop="articleBody">
        <?php $this->content(); ?>
    </div>

    <!-- ---------- تگ‌ها ---------- -->
    <?php if ($this->tags): ?>
    <div class="post-tags">
        <?php echo farzaneh_icon('tag', 15); ?>
        <?php $this->tags(' ', true, ''); ?>
    </div>
    <?php endif; ?>

    <!-- ---------- لایک ---------- -->
    <?php if ($farzanehShowLikes): ?>
    <?php
    $farzanehLikes = farzaneh_likes($this);
    $farzanehLiked = farzaneh_is_liked((int)$this->cid) ? '1' : '0';
    ?>
    <div class="post-like-row" id="farzanehLikeFloat">
        <button type="button" class="like-btn<?php echo $farzanehLiked === '1' ? ' is-liked' : ''; ?>" id="farzanehLikeBtn"
                data-cid="<?php echo (int)$this->cid; ?>" data-likes="<?php echo $farzanehLikes; ?>" data-liked="<?php echo $farzanehLiked; ?>"
                aria-pressed="<?php echo $farzanehLiked === '1' ? 'true' : 'false'; ?>">
            <?php echo farzaneh_icon('heart', 18); ?>
            <span class="like-label"><?php echo $farzanehLiked === '1' ? 'پسندیدید' : 'این مطلب را پسندیدید؟'; ?></span>
            <span class="like-count"><?php echo farzaneh_num($farzanehLikes); ?></span>
        </button>
    </div>
    <?php endif; ?>

    <!-- ---------- نویسنده ---------- -->
    <?php if ($farzanehShowAuthorBox): ?>
    <aside class="author-box">
        <span class="author-avatar">
            <?php /* d=404: اگر گراواتار واقعی نباشد تصویر لود نمی‌شود و فقط آواتار الفبایی می‌ماند */ ?>
            <?php $this->author->gravatar(96, 'X', '404'); ?>
            <span class="author-avatar-fallback" aria-hidden="true"><?php echo htmlspecialchars(farzaneh_initial((string)$this->author->screenName), ENT_QUOTES); ?></span>
        </span>
        <div class="author-info">
            <strong class="author-name"><a href="<?php $this->author->permalink(); ?>" rel="author"><?php $this->author(); ?></a></strong>
            <span class="author-role">نویسنده در <?php echo htmlspecialchars($farzanehInstituteName, ENT_QUOTES); ?></span>
            <?php if (trim((string)$this->author->description) !== ''): ?>
            <p class="author-desc"><?php $this->author->description(); ?></p>
            <?php endif; ?>
        </div>
    </aside>
    <?php endif; ?>

    <!-- ---------- نوشته‌های مرتبط ---------- -->
    <?php
    $farzanehRelated = $farzanehShowRelated ? farzaneh_related_posts($this, 3) : [];
    if (!empty($farzanehRelated)):
    ?>
    <section class="related-posts">
        <h2 class="related-title"><?php echo farzaneh_icon('file-text', 18); ?> نوشته‌های مرتبط</h2>
        <div class="related-grid">
            <?php foreach ($farzanehRelated as $farzanehRelatedPost): ?>
            <a href="<?php echo htmlspecialchars($farzanehRelatedPost['url'], ENT_QUOTES); ?>" class="related-card">
                <span class="related-card-title"><?php echo toPersianNumbers(htmlspecialchars($farzanehRelatedPost['title'], ENT_QUOTES)); ?></span>
                <span class="related-card-date"><?php echo farzaneh_jalali_date($farzanehRelatedPost['created'], 'j F Y'); ?></span>
                <span class="related-card-more">خواندن <?php echo farzaneh_icon('arrow-left', 14); ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- ---------- نظرات ---------- -->
    <?php $this->need('comments.php'); ?>

</article>

<?php $this->need('footer.php'); ?>
