<?php

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/* ================================================================
 *  فرزانه — پوستهٔ آموزشگاه و مدارس برای تایپ‌رینیو
 *  معماری بر اساس پوستهٔ نهال و سازوکار افزونهٔ Booking
 * ================================================================ */

/* ================================================================
 *  ۱) ابزارهای عمومی
 * ================================================================ */

/** خواندن تنظیم پوسته با مقدار پیش‌فرض (مقدار خالی → پیش‌فرض) */
function farzaneh_opt(string $name, ?string $default = null): string
{
    try {
        $value = \Widget\Options::alloc()->{$name};
    } catch (\Throwable $e) {
        $value = null;
    }
    return ($value === null || $value === '') ? (string)$default : (string)$value;
}

/** مانند farzaneh_opt اما «مقدار خالی» را نیز برمی‌گرداند (تمایز تنظیم‌نشده/خالی‌شده) */
function farzaneh_opt_raw(string $name): ?string
{
    try {
        $value = \Widget\Options::alloc()->{$name};
    } catch (\Throwable $e) {
        return null;
    }
    return ($value === null) ? null : (string)$value;
}

/** تبدیل ارقام لاتین به فارسی */
if (!function_exists('toPersianNumbers')) {
    function toPersianNumbers($num)
    {
        $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return str_replace(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], $persian, (string)$num);
    }
}

/** تبدیل ارقام فارسی/عربی به لاتین (برای شمارندهٔ انیمیشنی و محاسبات) */
function farzaneh_to_en_digits(string $text): string
{
    $fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $ar = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    $text = str_replace($fa, array_keys($fa), $text);
    return str_replace($ar, array_keys($ar), $text);
}

/** عدد فارسی با جداکنندهٔ هزارگان: 1234 → ۱٬۲۳۴ */
function farzaneh_num($num): string
{
    return toPersianNumbers(str_replace(',', '٬', number_format(max(0, (float)$num))));
}

/** عنوان محتوا برای نمایش: HTML-escaped + ارقام فارسی */
function farzaneh_fa_title($widget): string
{
    $title = '';
    try {
        $title = (string)$widget->title;
    } catch (\Throwable $e) {
        $title = '';
    }
    return toPersianNumbers(htmlspecialchars($title, ENT_QUOTES, 'UTF-8'));
}

/** نرمال‌سازی آدرس تصویر (نسبی → مطلق) — آدرس‌های دارای scheme دست‌نخورده می‌مانند */
function farzaneh_resolve_url(string $url): string
{
    $url = trim($url);
    if ($url === '' || preg_match('#^(data:|[a-z][a-z0-9+.\-]*:|//)#i', $url)) {
        return $url;
    }
    try {
        $base = rtrim((string)\Widget\Options::alloc()->siteUrl, '/');
    } catch (\Throwable $e) {
        $base = '';
    }
    return $base . '/' . ltrim($url, '/');
}

/**
 * آدرس نهایی دکمه‌ها و لینک‌های منو:
 *  - «#hash» فقط در صفحهٔ اول همان اسکرول درون‌صفحه است؛ در صفحات دیگر به «siteUrl/#hash» تبدیل می‌شود
 *  - آدرس‌های دارای scheme (tel: / mailto: / https: …) و // و data: عیناً حفظ می‌شوند
 */
function farzaneh_link_url(string $url, bool $onHome = true): string
{
    $url = trim($url);
    if ($url === '') {
        return '';
    }
    if (preg_match('#^(data:|[a-z][a-z0-9+.\-]*:|//)#i', $url)) {
        return $url;
    }
    if ($url[0] === '#') {
        if ($onHome) {
            return $url;
        }
        try {
            $base = rtrim((string)\Widget\Options::alloc()->siteUrl, '/');
        } catch (\Throwable $e) {
            $base = '';
        }
        return $base . '/' . $url;
    }
    return farzaneh_resolve_url($url);
}

/** نام مسیر (route) جاری تایپ‌رینیو؛ در نبود روتر خالی برمی‌گردد */
function farzaneh_route(): string
{
    try {
        if (class_exists('\Typecho\Router') && isset(\Typecho\Router::$current)) {
            return (string)\Typecho\Router::$current;
        }
    } catch (\Throwable $e) {
    }
    return '';
}

/** آیا همین صفحه «صفحهٔ اول» سایت است؟ (بر مبنای مسیر جاری) */
function farzaneh_is_front(): bool
{
    return farzaneh_route() === 'index';
}

/** آدرس فهرست مقالات (وبلاگ) */
function farzaneh_blog_url(): string
{
    $custom = trim((string)farzaneh_opt_raw('farzanehBlogUrl'));
    if ($custom !== '') {
        return farzaneh_link_url($custom);
    }
    try {
        if (class_exists('\Typecho\Router')) {
            $url = \Typecho\Router::url('archive', [], (string)\Widget\Options::alloc()->index);
            if (is_string($url) && $url !== '' && $url !== '#') {
                return $url;
            }
        }
    } catch (\Throwable $e) {
    }
    try {
        return rtrim((string)\Widget\Options::alloc()->siteUrl, '/') . '/';
    } catch (\Throwable $e) {
        return '#';
    }
}

/**
 * صفحه‌بندی فهرست مقالات با فراخوانی صحیحِ Widget\Archive::pageNav.
 * امضای هستهٔ تایپ‌رینیو ۱٫۶: pageNav(string $prev, string $next, int $splitPage, string $splitWord, $template)
 * itemTag خالی → کلاس‌ها مستقیم روی <a> می‌نشینند (طرح فعال صفحهٔ جاری در CSS).
 */
function farzaneh_page_nav($archive): void
{
    if ($archive === null || !method_exists($archive, 'pageNav')) {
        return;
    }
    ob_start();
    $archive->pageNav(
        toPersianNumbers('قبلی'),
        toPersianNumbers('بعدی'),
        2,
        '...',
        [
            'wrapTag'      => 'nav',
            'wrapClass'    => 'pagination',
            'itemTag'      => '',
            'textTag'      => '',
            'currentClass' => 'page-current',
            'prevClass'    => 'page-prev',
            'nextClass'    => 'page-next',
        ]
    );
    $html = (string)ob_get_clean();
    if ($html === '') {
        return;
    }
    echo preg_replace_callback(
        '/>([^<>]*)</',
        function ($m) {
            return '>' . toPersianNumbers($m[1]) . '<';
        },
        $html
    );
}

/** آدرس یک فایل داخل پوسته */
function farzaneh_asset(string $path): string
{
    try {
        return rtrim((string)\Widget\Options::alloc()->themeUrl, '/') . '/' . ltrim($path, '/');
    } catch (\Throwable $e) {
        return $path;
    }
}

/* ================================================================
 *  ۲) آیکون‌های Lucide (SVG درون‌خطی — بدون نیاز به اینترنت)
 * ================================================================ */

/** نقشهٔ آیکون‌های Lucide — همه ۲۴×۲۴ با stroke */
function farzaneh_icons(): array
{
    static $icons = null;
    if ($icons !== null) {
        return $icons;
    }

    $icons = [
        // برند و آموزش
        'graduation-cap' => '<path d="M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z"/><path d="M22 10v6"/><path d="M6 12.5V16a6 3 0 0 0 12 0v-3.5"/>',
        'school' => '<path d="m4 6 8-4 8 4"/><path d="m18 10 4 2v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-8l4-2"/><path d="M14 22v-4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v4"/><path d="M18 5v17"/><path d="M6 5v17"/><circle cx="12" cy="9" r="2"/>',
        'book-open' => '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
        'library' => '<path d="m16 6 4 14"/><path d="M12 6v14"/><path d="M8 8v12"/><path d="M4 4v16"/>',
        'notebook-pen' => '<path d="M12 20H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6"/><path d="M16.8 13.5a1.9 1.9 0 0 1 2.7 2.7l-3.1 3.1a2.1 2.1 0 0 1-.9.5l-2 .5.5-2a2.1 2.1 0 0 1 .5-.9z"/>',
        'pencil' => '<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/>',
        'calculator' => '<rect width="16" height="20" x="4" y="2" rx="2"/><line x1="8" x2="16" y1="6" y2="6"/><line x1="16" x2="16" y1="14" y2="18"/><path d="M16 10h.01"/><path d="M12 10h.01"/><path d="M8 10h.01"/><path d="M12 14h.01"/><path d="M8 14h.01"/><path d="M12 18h.01"/><path d="M8 18h.01"/>',
        'atom' => '<circle cx="12" cy="12" r="1"/><path d="M20.2 20.2c2.04-2.03.02-7.36-4.5-11.9-4.54-4.52-9.87-6.54-11.9-4.5-2.04 2.03-.02 7.36 4.5 11.9 4.54 4.52 9.87 6.54 11.9 4.5Z"/><path d="M15.7 15.7c4.52-4.54 6.54-9.87 4.5-11.9-2.03-2.04-7.36-.02-11.9 4.5-4.52 4.54-6.54 9.87-4.5 11.9 2.03 2.04 7.36.02 11.9-4.5Z"/>',
        'flask-conical' => '<path d="M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2"/><path d="M6.453 15h11.094"/><path d="M8.5 2h7"/>',
        'microscope' => '<path d="M6 18h8"/><path d="M3 22h18"/><path d="M14 22a7 7 0 1 0 0-14h-1"/><path d="M9 14h2"/><path d="M9 12a2 2 0 0 1-2-2V6h6v4a2 2 0 0 1-2 2Z"/><path d="M12 6V3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3"/>',
        'languages' => '<path d="m5 8 6 6"/><path d="m4 14 6-6 2-3"/><path d="M2 5h12"/><path d="M7 2h1"/><path d="m22 22-5-10-5 10"/><path d="M14 18h6"/>',
        'globe' => '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
        'laptop' => '<path d="M20 16V7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v9m16 0H4m16 0 1.28 2.55a1 1 0 0 1-.9 1.45H3.62a1 1 0 0 1-.9-1.45L4 16"/>',
        'music' => '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
        'palette' => '<circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/>',
        'presentation' => '<path d="M2 3h20"/><path d="M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"/><path d="m7 21 5-5 5 5"/>',
        'ruler' => '<path d="M21.3 15.3 15.3 21.3a1 1 0 0 1-1.4 0l-1.8-1.8 8.5-8.5 1.8 1.8a1 1 0 0 1 0 1.4Z"/><path d="m15.9 6.1 1.8 1.8"/><path d="m12.2 9.8 1.8 1.8"/><path d="m8.5 13.5 1.8 1.8"/><path d="m4.8 17.2 1.8 1.8"/><path d="M3.9 2.7 2.7 3.9a1 1 0 0 0 0 1.4l2.4 2.4 2.6-.4.4-2.6-2.4-2.4a1 1 0 0 0-1.4 0Z"/>',
        'trophy' => '<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/>',
        'sparkles' => '<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/><path d="M20 3v4"/><path d="M22 5h-4"/><path d="M4 17v2"/><path d="M5 18H3"/>',
        'heart' => '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
        'heart-pulse' => '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/><path d="M3.22 12H9.5l.5-1 2 4.5 2-7 1.5 3.5h5.27"/>',
        'brain' => '<path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/><path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/><path d="M15 13H9"/>',
        'lightbulb' => '<path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/>',
        'moon' => '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
        'sun' => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',

        // وضعیت و هدف
        'trending-up' => '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
        'trending-down' => '<polyline points="22 17 13.5 8.5 8.5 13.5 2 7"/><polyline points="16 17 22 17 22 11"/>',
        'target' => '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
        'zap' => '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',

        // رابط کاربری
        'user' => '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'users' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'clipboard-check' => '<rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/>',
        'clipboard-list' => '<rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/>',
        'calendar' => '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/>',
        'calendar-check' => '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="m9 16 2 2 4-4"/>',
        'phone' => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
        'phone-call' => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/><path d="M14.05 2a9 9 0 0 1 8 7.94"/><path d="M14.05 6A5 5 0 0 1 18 10"/>',
        'mail' => '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
        'map-pin' => '<path d="M20 10c0 4.99-5.54 10.19-7.4 11.79a1 1 0 0 1-1.2 0C9.54 20.19 4 14.99 4 10a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
        'clock' => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
        'message-circle' => '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>',
        'message-square' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
        'send' => '<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
        'check-circle' => '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
        'shield-check' => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1 1 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
        'star' => '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
        'award' => '<circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>',
        'quote' => '<path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"/><path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"/>',
        'file-text' => '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M16 13H8"/><path d="M16 17H8"/><path d="M10 9H8"/>',
        'folder' => '<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>',
        'tag' => '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"/>',
        'eye' => '<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>',
        'arrow-up' => '<path d="m5 12 7-7 7 7"/><path d="M12 19V5"/>',
        'arrow-left' => '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
        'chevron-left' => '<path d="m15 18-6-6 6-6"/>',
        'chevron-right' => '<path d="m9 18 6-6-6-6"/>',
        'chevron-down' => '<path d="m6 9 6 6 6-6"/>',
        'menu' => '<line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="18" y2="18"/>',
        'x' => '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
        'check' => '<path d="M20 6 9 17l-5-5"/>',
        'lock' => '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
        'inbox' => '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
        'trash-2' => '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
        'home' => '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
        'search' => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
        'instagram' => '<rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>',
        'youtube' => '<path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/><path d="m10 15 5-3-5-3z"/>',
    ];
    return $icons;
}

/** رندر آیکون Lucide — خروجی SVG درون‌خطی */
function farzaneh_icon(string $name, int $size = 24, string $class = ''): string
{
    $icons = farzaneh_icons();
    $path = $icons[$name] ?? $icons['graduation-cap'];
    $classAttr = $class !== '' ? ' class="' . htmlspecialchars($class, ENT_QUOTES) . '"' : '';
    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"' . $classAttr . '>' . $path . '</svg>';
}

/** آیا نام آیکون معتبر است؟ (برای اعتبارسنجی ورودی) */
function farzaneh_icon_exists(string $name): bool
{
    return array_key_exists($name, farzaneh_icons());
}

/* ================================================================
 *  ۳) تاریخ شمسی
 * ================================================================ */

/** میلادی → جلالی (الگوریتم استاندارد) */
function farzaneh_to_jalali(int $gy, int $gm, int $gd): array
{
    $g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100))
        + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
    $jy = -1595 + (33 * ((int)($days / 12053)));
    $days %= 12053;
    $jy += 4 * ((int)($days / 1461));
    $days %= 1461;
    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + (int)($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }
    return [$jy, $jm, $jd];
}

/**
 * تاریخ/ساعت شمسی بر اساس وقت تهران — مستقل از تنظیمات سرور.
 *
 * تمام نمایش‌های تاریخ و ساعت پوسته (از جمله ساعت ثبت درخواست‌های ثبت‌نام در
 * برگهٔ مدیریت) با منطقهٔ زمانی Asia/Tehran محاسبه می‌شوند؛ بنابراین حتی اگر
 * سرور روی UTC یا منطقهٔ دیگری باشد، ساعت‌ها همیشه به وقت ایران نمایش داده می‌شوند.
 * (ایران از سال ۱۴۰۱ تغییر ساعت ندارد؛ DateTimeZone قواعد تاریخی DST را هم درست رعایت می‌کند.)
 */
function farzaneh_tehran(int $timestamp): \DateTimeImmutable
{
    static $tz = null;
    try {
        if ($tz === null) {
            $tz = new \DateTimeZone('Asia/Tehran');
        }
        return (new \DateTimeImmutable('@' . $timestamp))->setTimezone($tz);
    } catch (\Throwable $e) {
        return new \DateTimeImmutable('@' . $timestamp);
    }
}

/** تاریخ شمسی از timestamp — همیشه به وقت تهران */
function farzaneh_jalali_date($timestamp = null, string $format = 'Y/m/d'): string
{
    if ($timestamp === null) {
        $timestamp = time();
    }
    $timestamp = (int)$timestamp;
    if ($timestamp <= 0) {
        $timestamp = time();
    }
    return farzaneh_format_jalali($timestamp, $format);
}

/** قالب‌بندی تاریخ شمسی — اجزای میلادی از DateTime منطقهٔ تهران خوانده می‌شوند */
function farzaneh_format_jalali(int $timestamp, string $format): string
{
    $dt = farzaneh_tehran($timestamp);
    $gy = (int)$dt->format('Y');
    $gm = (int)$dt->format('n');
    $gd = (int)$dt->format('j');
    [$jy, $jm, $jd] = farzaneh_to_jalali($gy, $gm, $gd);

    $months = [
        1 => 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
    ];

    $out = $format;
    $out = str_replace('Y', (string)$jy, $out);
    $out = str_replace('y', substr((string)$jy, -2), $out);
    $out = str_replace('m', str_pad((string)$jm, 2, '0', STR_PAD_LEFT), $out);
    $out = str_replace('n', (string)$jm, $out);
    $out = str_replace('d', str_pad((string)$jd, 2, '0', STR_PAD_LEFT), $out);
    $out = str_replace('j', (string)$jd, $out);
    $out = str_replace('F', $months[$jm], $out);
    $out = str_replace('H', $dt->format('H'), $out);
    $out = str_replace('i', $dt->format('i'), $out);
    return toPersianNumbers($out);
}

/** تاریخ ISO 8601 هماهنگ با وقت تهران (برای ویژگی datetime تگ time) */
function farzaneh_iso_date(int $timestamp): string
{
    return farzaneh_tehran($timestamp)->format('c');
}

/** تاریخ انتشار محتوا به شمسی */
function farzaneh_post_date($archive, string $format = 'j F Y'): string
{
    try {
        $timestamp = (int)$archive->created;
    } catch (\Throwable $e) {
        $timestamp = time();
    }
    return farzaneh_jalali_date($timestamp, $format);
}

/** سال شمسی جاری برای کپی‌رایت */
function farzaneh_jalali_year(): string
{
    return farzaneh_jalali_date(time(), 'Y');
}

/* ================================================================
 *  ۴) بازدید و لایک
 * ================================================================ */

/** آیا افزونهٔ ViewsCounter فعال است؟ */
function farzaneh_views_counter_active(): bool
{
    try {
        $plugins = \Widget\Options::alloc()->plugins;
        if (is_array($plugins) && isset($plugins['activated']) && is_array($plugins['activated'])) {
            foreach (array_keys($plugins['activated']) as $key) {
                if (stripos((string)$key, 'views') !== false) {
                    return true;
                }
            }
        }
    } catch (\Throwable $e) {
    }
    return false;
}

/** اطمینان از وجود ستون‌های views و likes (در نبود، ساخته می‌شوند) */
function farzaneh_stats_ready(): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }

    $ready = false;
    try {
        $db = \Typecho\Db::get();
        $prefix = $db->getPrefix();

        $columns = [];
        try {
            // MySQL
            $rows = $db->fetchAll("SHOW COLUMNS FROM `{$prefix}contents`");
            foreach ($rows as $row) {
                $columns[] = is_array($row) ? (string)reset($row) : (string)$row->Field;
            }
        } catch (\Throwable $e) {
            $columns = [];
        }

        if (empty($columns)) {
            foreach (['views', 'likes'] as $col) {
                try {
                    $db->fetchRow($db->select("table.contents.{$col}")->from('table.contents')->limit(1));
                } catch (\Throwable $e) {
                    try {
                        $db->query("ALTER TABLE `{$prefix}contents` ADD `{$col}` INT DEFAULT 0");
                    } catch (\Throwable $e2) {
                    }
                }
            }
        } else {
            foreach (['views', 'likes'] as $col) {
                if (!in_array($col, $columns, true)) {
                    try {
                        $db->query("ALTER TABLE `{$prefix}contents` ADD `{$col}` INT DEFAULT 0");
                    } catch (\Throwable $e) {
                    }
                }
            }
        }

        $ready = true;
    } catch (\Throwable $e) {
        $ready = false;
    }
    return $ready;
}

/** تعداد بازدید نوشته */
function farzaneh_views($archive): int
{
    if (farzaneh_views_counter_active()) {
        try {
            $v = (int)$archive->views;
            if ($v > 0) {
                return $v;
            }
        } catch (\Throwable $e) {
        }
    }
    try {
        $cid = (int)$archive->cid;
        if ($cid < 1 || !farzaneh_stats_ready()) {
            return 0;
        }
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.views')->from('table.contents')->where('table.contents.cid = ?', $cid)
        );
        return (int)($row['views'] ?? 0);
    } catch (\Throwable $e) {
        return 0;
    }
}

/** تعداد لایک نوشته */
function farzaneh_likes($archive): int
{
    try {
        $cid = (int)$archive->cid;
        if ($cid < 1 || !farzaneh_stats_ready()) {
            return 0;
        }
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        );
        return (int)($row['likes'] ?? 0);
    } catch (\Throwable $e) {
        return 0;
    }
}

/** شمارش بازدید صفحات تکی با کوکی ضد تکرار */
function farzaneh_count_view($archive): void
{
    try {
        if (!method_exists($archive, 'is') || !$archive->is('single')) {
            return;
        }
        if (farzaneh_opt('farzanehCountAdminViews', '0') !== '1') {
            try {
                $user = \Widget\User::alloc();
                if ($user->hasLogin() && $user->pass('administrator', true)) {
                    return;
                }
            } catch (\Throwable $e) {
            }
        }
        $cid = (int)$archive->cid;
        if ($cid < 1 || !farzaneh_stats_ready()) {
            return;
        }
        $cookieName = 'farzanehV' . $cid;
        if (isset($_COOKIE[$cookieName])) {
            return;
        }
        $db = \Typecho\Db::get();
        $db->query(
            $db->update('table.contents')
                ->expression('views', 'views + 1')
                ->where('table.contents.cid = ?', $cid)
        );
        \Typecho\Cookie::set($cookieName, '1', time() + 86400);
    } catch (\Throwable $e) {
    }
}

/** شناسه‌های لایک‌شدهٔ این بازدیدکننده (کوکی farzanehLikes) */
function farzaneh_user_likes(): array
{
    $raw = $_COOKIE['farzanehLikes'] ?? '';
    $ids = array_filter(array_map('trim', explode(',', (string)$raw)));
    $out = [];
    foreach ($ids as $id) {
        if (ctype_digit((string)$id)) {
            $out[] = (string)(int)$id;
        }
    }
    return $out;
}

/** آیا این بازدیدکننده این نوشته را لایک کرده؟ */
function farzaneh_is_liked($cid): bool
{
    return in_array((string)(int)$cid, farzaneh_user_likes(), true);
}

/** خروجی JSON و پایان درخواست — سخت‌سازی‌شده (الگو از افزونهٔ Booking) */
function farzaneh_json(array $payload, int $status = 200): void
{
    /*
     * هر بافر خروجی باز (حتی هشدارهای PHP در حالت display_errors) پاک می‌شود تا
     * پاسخ همیشه JSON خالص باشد و سمت کلاینت res.json() هرگز شکست نخورد.
     */
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('X-Content-Type-Options: nosniff');
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** پردازش درخواست لایک — POST با پارامتر farzanehLike=<cid> */
function farzaneh_handle_like($request): void
{
    $cid = (int)(string)$request->get('farzanehLike');
    if ($cid < 1) {
        farzaneh_json(['ok' => false, 'error' => 'bad-request'], 400);
        return;
    }

    // جلوگیری ساده از CSRF
    try {
        $siteHost = (string)parse_url((string)\Widget\Options::alloc()->siteUrl, PHP_URL_HOST);
        $referer = (string)($_SERVER['HTTP_REFERER'] ?? '');
        if ($referer !== '' && $siteHost !== '' && stripos($referer, $siteHost) === false) {
            farzaneh_json(['ok' => false, 'error' => 'cross-origin'], 403);
            return;
        }
    } catch (\Throwable $e) {
    }

    if (!farzaneh_stats_ready()) {
        farzaneh_json(['ok' => false, 'error' => 'db-error'], 500);
        return;
    }

    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        );
        if (!$row) {
            farzaneh_json(['ok' => false, 'error' => 'not-found'], 404);
            return;
        }

        $likes = max(0, (int)$row['likes']);
        $likedIds = farzaneh_user_likes();
        $wasLiked = in_array((string)$cid, $likedIds, true);

        if ($wasLiked) {
            $likes = max(0, $likes - 1);
            $likedIds = array_values(array_diff($likedIds, [(string)$cid]));
        } else {
            $likes = $likes + 1;
            $likedIds[] = (string)$cid;
        }

        try {
            \Typecho\Cookie::set('farzanehLikes', implode(',', $likedIds), time() + 31536000);
        } catch (\Throwable $e) {
        }

        $db->query(
            $db->update('table.contents')
                ->expression('likes', 'likes + ' . ($wasLiked ? -1 : 1))
                ->where('table.contents.cid = ?', $cid)
        );

        farzaneh_json([
            'ok'    => true,
            'cid'   => $cid,
            'likes' => $likes,
            'liked' => !$wasLiked,
        ]);
    } catch (\Throwable $e) {
        farzaneh_json(['ok' => false, 'error' => 'server-error'], 500);
    }
}

/* ================================================================
 *  ۵) سیستم ثبت‌نام دوره — الگوبرداری‌شده از بوکینگ اختصاصی نهال
 * ================================================================
 *
 * معماری (مطابق افزونهٔ Booking و پوستهٔ نهال):
 *   ۱) فرم به یک «نقطهٔ پایانی اختصاصی» POST می‌شود (نه آدرس صفحهٔ جاری):
 *      مسیر /farzaneh-register یک‌بار در جدول مسیریابی ثبت می‌شود و همیشه توسط
 *      هسته به Widget\Archive سپرده می‌شود → themeInit حتماً اجرا می‌شود و
 *      نتیجه JSON خالص است؛ مستقل از نوع صفحه، صفحهٔ نخست یا قالب سفارشی.
 *   ۲) درخواست‌ها مانند افزونه به‌صورت دیدگاه روی یک «برگهٔ پشتیبان مخفی»
 *      ذخیره می‌شوند (وضعیت waiting → عمومی نیست، شماره تلفن در فیلد url).
 *   ۳) امنیت: توکن CSRF هسته (Security::getToken) + تلهٔ هرزنامه +
 *      فاصلهٔ زمانی ارسال (commentsPostInterval) + اعتبارسنجی ایرانی.
 *   ۴) نمایش: برگهٔ «مدیریت ثبت‌نام‌ها» (قالب enroll-manage.php) برای اعضای
 *      مجاز + همان دیدگاه‌ها در پنل مدیریت ← دیدگاه‌های در انتظار.
 */

/** نام مسیر نقطهٔ پایانی ثبت‌نام */
function farzaneh_enroll_route_name(): string
{
    return 'farzaneh-register';
}

/**
 * ثبت مسیر /farzaneh-register در جدول مسیریابی (یک‌بار — idempotent).
 * پس از ثبت، جدول مسیرِ درون‌حافظه‌ای هم همگام می‌شود تا در همان درخواست
 * اول Router::url کار کند. خطاها بی‌صدا بلعیده می‌شوند.
 */
function farzaneh_register_enroll_route(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    try {
        $options = \Widget\Options::alloc();
        $routingTable = $options->routingTable;

        if (!is_array($routingTable) || !isset($routingTable[farzaneh_enroll_route_name()])) {
            \Utils\Helper::addRoute(
                farzaneh_enroll_route_name(),
                '/' . farzaneh_enroll_route_name(),
                '\Widget\Archive',
                'render'
            );

            // همگام‌سازی جدول مسیرِ درون‌حافظه‌ای (مثل Widget\Init)
            \Typecho\Router::setRoutes($options->routingTable);
        }
    } catch (\Throwable $e) {
        // ثبت نشد؟ فرم همچنان به آدرس صفحهٔ جاری POST می‌شود و همان مسیر قدیمی کار می‌کند
    }
}

/** نشانی نقطهٔ پایانی ثبت نام دوره (با جایگزین خانه در نبود مسیر) */
function farzaneh_enroll_endpoint(): string
{
    try {
        $url = \Typecho\Router::url(farzaneh_enroll_route_name(), [], \Widget\Options::alloc()->index);
        if ($url !== '#' && $url !== '') {
            return $url;
        }
    } catch (\Throwable $e) {
    }
    try {
        return (string)\Widget\Options::alloc()->siteUrl;
    } catch (\Throwable $e) {
        return '/';
    }
}

/** اسلاگ برگهٔ ذخیرهٔ ثبت‌نام (برگهٔ سیستمی پوسته) */
function farzaneh_reserve_slug(): string
{
    return 'farzaneh-enroll';
}

/** اسلاگ برگهٔ «مدیریت ثبت‌نام‌ها» (برگهٔ سیستمی پوسته با قالب enroll-manage) */
function farzaneh_manage_slug(): string
{
    return 'farzaneh-enrollments';
}

/** اسلاگ‌های قابل قبول برای برگهٔ دفتر ثبت‌نام */
function farzaneh_reserve_slug_list(): array
{
    return [farzaneh_reserve_slug(), 'enroll', 'enrollment', 'register', 'sabtnam', 'course-register'];
}

/**
 * یافتن شناسهٔ برگهٔ دفتر ثبت‌نام:
 *  ۱) تنظیم سفارشی مدیر؛
 *  ۲) جست‌وجوی برگه‌هایی با اسلاگ رایج ثبت‌نام؛
 *  ۳) ساخت خودکار برگهٔ سیستمی «مخفی» در نخستین نیاز (مثل افزونهٔ Booking).
 */
function farzaneh_reserve_cid(): int
{
    static $cid = null;
    if ($cid !== null) {
        return $cid;
    }

    try {
        $db = \Typecho\Db::get();

        // ۱) تنظیم سفارشی
        $custom = (int)farzaneh_opt('farzanehEnrollCid', '0');
        if ($custom > 0) {
            $row = $db->fetchRow(
                $db->select('cid')->from('table.contents')->where('cid = ?', $custom)->limit(1)
            );
            if ($row) {
                $cid = (int)$row['cid'];
                return $cid;
            }
        }

        // ۲) جست‌وجوی اسلاگ‌های رایج
        $row = $db->fetchRow(
            $db->select('cid')->from('table.contents')
                ->where('type = ?', 'page')
                ->where('slug IN ?', farzaneh_reserve_slug_list())
                ->limit(1)
        );
        if ($row) {
            $cid = (int)$row['cid'];
            return $cid;
        }

        // ۳) ساخت خودکار برگهٔ سیستمی «دفتر ثبت‌نام» — مخفی (مثل افزونهٔ Booking)
        $now = time();
        $adminUid = 1;
        try {
            $user = \Widget\User::alloc();
            if ($user->hasLogin()) {
                $adminUid = (int)$user->uid;
            }
        } catch (\Throwable $e) {
        }

        $text = "<!-- فرزانه --> برگهٔ سیستمی پوستهٔ فرزانه؛ درخواست‌های ثبت‌نام دورهٔ فرم سایت به‌صورت دیدگاه «در انتظار تأیید» روی همین برگه ذخیره می‌شوند. مشاهده و مدیریت از برگهٔ «مدیریت ثبت‌نام‌ها» یا مدیریت ← دیدگاه‌ها. لطفاً این برگه را حذف نکنید.";
        // Db::query برای INSERT شناسهٔ درج‌شده را برمی‌گرداند (متد Db::lastInsertId در هسته وجود ندارد)
        $cid = (int)$db->query(
            $db->insert('table.contents')->rows([
                'title'        => 'دفتر ثبت‌نام دوره‌ها',
                'slug'         => farzaneh_reserve_slug(),
                'created'      => $now,
                'modified'     => $now,
                'text'         => $text,
                'order'        => 9999,
                'authorId'     => $adminUid,
                'template'     => '',
                'type'         => 'page',
                'status'       => 'hidden',
                'password'     => '',
                'commentsNum'  => 0,
                'allowComment' => 1,
                'allowPing'    => 0,
                'allowFeed'    => 0,
                'parent'       => 0,
            ])
        );
        return $cid;
    } catch (\Throwable $e) {
        $cid = 0;
    }
    return 0;
}

/**
 * شناسهٔ برگهٔ «مدیریت ثبت‌نام‌ها» — در نبودش خودکار ساخته می‌شود (مخفی).
 * قالب برگه: enroll-manage.php (فایل پوسته).
 */
function farzaneh_manage_cid(): int
{
    static $cid = null;
    if ($cid !== null) {
        return $cid;
    }

    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('cid')->from('table.contents')
                ->where('type = ?', 'page')
                ->where('slug = ?', farzaneh_manage_slug())
                ->limit(1)
        );
        if ($row) {
            $cid = (int)$row['cid'];
            return $cid;
        }

        $now = time();
        $adminUid = 1;
        try {
            $user = \Widget\User::alloc();
            if ($user->hasLogin()) {
                $adminUid = (int)$user->uid;
            }
        } catch (\Throwable $e) {
        }

        // Db::query برای INSERT شناسهٔ درج‌شده را برمی‌گرداند (متد Db::lastInsertId در هسته وجود ندارد)
        $cid = (int)$db->query(
            $db->insert('table.contents')->rows([
                'title'        => 'مدیریت ثبت‌نام‌ها',
                'slug'         => farzaneh_manage_slug(),
                'created'      => $now,
                'modified'     => $now,
                'text'         => "<!-- فرزانه --> برگهٔ سیستمی پوستهٔ فرزانه برای مشاهده و مدیریت درخواست‌های ثبت‌نام دوره. فقط برای اعضای واردشده (مدیر/سردبیر) قابل استفاده است.",
                'order'        => 9999,
                'authorId'     => $adminUid,
                'template'     => 'enroll-manage.php',
                'type'         => 'page',
                'status'       => 'hidden',
                'password'     => '',
                'commentsNum'  => 0,
                'allowComment' => 0,
                'allowPing'    => 0,
                'allowFeed'    => 0,
                'parent'       => 0,
            ])
        );
        return $cid;
    } catch (\Throwable $e) {
        $cid = 0;
    }
    return 0;
}

/** نشانی برگهٔ مدیریت ثبت‌نام‌ها (یا '') */
function farzaneh_manage_url(): string
{
    try {
        $cid = farzaneh_manage_cid();
        if ($cid < 1) {
            return '';
        }
        $url = \Typecho\Router::url('page', ['slug' => farzaneh_manage_slug()], \Widget\Options::alloc()->index);
        return ($url === '#') ? '' : (string)$url;
    } catch (\Throwable $e) {
        return '';
    }
}

/** آیا این cid، برگهٔ سیستمی ثبت‌نام است؟ (برای حذف از منوها و دیدگاه‌های عمومی) */
function farzaneh_is_reserve_cid(int $pageCid): bool
{
    if ($pageCid < 1) {
        return false;
    }
    $custom = (int)farzaneh_opt('farzanehEnrollCid', '0');
    if ($custom === $pageCid) {
        return true;
    }
    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('slug')->from('table.contents')->where('cid = ?', $pageCid)->limit(1)
        );
        if ($row && (in_array((string)$row['slug'], farzaneh_reserve_slug_list(), true)
            || (string)$row['slug'] === farzaneh_manage_slug())) {
            return true;
        }
    } catch (\Throwable $e) {
    }
    return false;
}

/** آیا کاربر فعلی اجازهٔ مدیریت ثبت‌نام‌ها را دارد؟ (مدیر/سردبیر) */
function farzaneh_can_manage_enrollments(): bool
{
    try {
        $user = \Widget\User::alloc();
        return $user->hasLogin() && $user->pass('editor', true);
    } catch (\Throwable $e) {
        return false;
    }
}

/** تعداد ثبت‌نام‌های در انتظار بررسی */
function farzaneh_pending_enrollments_count(): int
{
    try {
        $cid = farzaneh_reserve_cid();
        if ($cid < 1) {
            return 0;
        }
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select(['COUNT(coid)' => 'n'])->from('table.comments')
                ->where('cid = ? AND parent = 0 AND type = ? AND status = ?', $cid, 'comment', 'waiting')
        );
        return (int)($row['n'] ?? 0);
    } catch (\Throwable $e) {
        return 0;
    }
}

/** تبدیل ارقام فارسی/عربی به انگلیسی (مثل افزونهٔ Booking) */
function farzaneh_to_english_digits(string $s): string
{
    return strtr($s, [
        '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
        '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
        '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
        '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
    ]);
}

/** اعتبارسنجی شمارهٔ تلفن ایرانی: 09xxxxxxxxx / +98… / 0xxxxxxxxx */
function farzaneh_valid_phone(string $phone): bool
{
    $phone = farzaneh_to_english_digits(trim($phone));
    $phone = str_replace([' ', '-', '(', ')', "\t"], '', $phone);
    return (bool)preg_match('/^(\+98|98|0098|0)?9\d{9}$/', $phone)
        || (bool)preg_match('/^0\d{9,10}$/', $phone);
}

/**
 * اعتبارسنجی توکن امنیتی CSRF — همان منطق Widget\Security::protect با
 * دو پذیرش جانبی: ارجاع هم‌مبدأ و (در نبود هر دو) ارجاع خالی، تا فرم
 * هرگز برای کاربر واقعی نشکند (الگوی protect افزونهٔ Booking).
 */
function farzaneh_enroll_token_ok($request): bool
{
    try {
        $security = \Widget\Security::alloc();
        $token = (string)$request->get('_', '');
        $referer = (string)$request->getReferer();

        if ($token !== '') {
            if (hash_equals($security->getToken($referer), $token)) {
                return true;
            }
            if (hash_equals($security->getToken((string)$request->getRequestUrl()), $token)) {
                return true;
            }
        }

        // پذیرش جانبی ۱: ارجاع هم‌مبدأ (رفتار پیش‌فرض مرورگرها برای POST هم‌مبدأ)
        if ($referer !== '') {
            $siteHost = (string)parse_url((string)\Widget\Options::alloc()->siteUrl, PHP_URL_HOST);
            $refHost = (string)parse_url($referer, PHP_URL_HOST);
            if ($siteHost !== '' && strcasecmp($siteHost, $refHost) === 0) {
                return true;
            }
            return false; // ارجاع بیگانه → رد
        }

        // پذیرش جانبی ۲: بدون ارجاع (مرورگرهای حریم‌خصوصی) → قبول؛
        // تلهٔ هرزنامه و محدودیت ارسال همچنان محافظت می‌کنند
        return true;
    } catch (\Throwable $e) {
        return true;
    }
}

/**
 * فهرست گزینه‌های «انتخاب دوره» در فرم ثبت‌نام:
 *  ۱) اگر مدیر در تنظیمات فهرست دستی وارد کرده باشد، همان؛
 *  ۲) در غیر این صورت به‌صورت خودکار از کارت‌های «دوره‌های آموزشی» ساخته می‌شود.
 */
function farzaneh_enroll_course_options(): array
{
    $manual = trim((string)farzaneh_opt_raw('farzanehEnrollCourses'));
    if ($manual !== '') {
        $items = array_filter(array_map('trim', explode(',', $manual)), function ($v) {
            return $v !== '';
        });
        if (!empty($items)) {
            return array_values($items);
        }
    }
    $courses = farzaneh_parse_courses(farzaneh_opt_raw('farzanehCourses'));
    $out = [];
    foreach ($courses as $course) {
        if (trim($course['title']) !== '') {
            $out[] = $course['title'];
        }
    }
    return $out;
}

/**
 * پردازش درخواست ثبت‌نام — POST به نقطهٔ پایانی /farzaneh-register (یا هر صفحهٔ پوسته).
 *
 * حالت‌ها (مثل افزونهٔ Booking):
 *  - پیش‌فرض  : ثبت درخواست جدید (فرم عمومی؛ پارامتر farzanehEnroll=1)
 *  - mode=approve | reject | delete : مدیریت ثبت‌نام (فقط اعضای مجاز)
 */
function farzaneh_handle_enroll($request): void
{
    // ---------- حالت‌های مدیریتی (تأیید/رد/حذف) ----------
    $mode = trim((string)$request->get('mode', ''));
    if (in_array($mode, ['approve', 'reject', 'delete'], true)) {
        farzaneh_handle_enroll_manage($request, $mode);
        return;
    }

    // ---------- توکن امنیتی (CSRF) ----------
    if (!farzaneh_enroll_token_ok($request)) {
        farzaneh_json(['ok' => false, 'error' => 'درخواست از منبع نامعتبر است؛ صفحه را رفرش کنید و دوباره تلاش کنید.'], 403);
    }

    // ---------- تلهٔ هرزنامه (honeypot باید خالی باشد) ----------
    $hp = trim((string)$request->get('farzanehHp', ''));
    if ($hp !== '') {
        farzaneh_json(['ok' => true, 'stored' => true]); // پاسخ مثبت کاذب برای ربات‌ها
    }

    // ---------- داده‌های فرم (ارقام فارسی → انگلیسی) ----------
    $name  = trim((string)$request->get('farzanehName', ''));
    $phone = farzaneh_to_english_digits(trim((string)$request->get('farzanehPhone', '')));
    $phone = str_replace([' ', '-', '(', ')', "\t"], '', $phone);
    $mail  = trim((string)$request->get('farzanehMail', ''));
    $course = trim((string)$request->get('farzanehCourse', ''));
    $level = trim((string)$request->get('farzanehLevel', ''));
    $grade = trim((string)$request->get('farzanehGrade', ''));
    $time  = trim((string)$request->get('farzanehTime', ''));
    $note  = trim((string)$request->get('farzanehNote', ''));

    // ---------- اعتبارسنجی ----------
    if (mb_strlen($name) < 2) {
        farzaneh_json(['ok' => false, 'error' => 'نام را کامل وارد کنید.'], 422);
    }
    if (!farzaneh_valid_phone($phone)) {
        farzaneh_json(['ok' => false, 'error' => 'شمارهٔ تلفن معتبر نیست (مثال: ۰۹۱۲۳۴۵۶۷۸۹).'], 422);
    }
    if ($mail !== '' && !filter_var($mail, FILTER_VALIDATE_EMAIL)) {
        farzaneh_json(['ok' => false, 'error' => 'ایمیل واردشده معتبر نیست.'], 422);
    }

    // برش طولانی‌ها (مثل افزونهٔ Booking)
    $name   = mb_substr($name, 0, 150);
    $mail   = mb_substr($mail, 0, 150);
    $course = mb_substr($course, 0, 150);
    $level  = mb_substr($level, 0, 150);
    $grade  = mb_substr($grade, 0, 150);
    $time   = mb_substr($time, 0, 150);
    $note   = mb_substr($note, 0, 2000);

    // ---------- ذخیره به‌صورت دیدگاه مخفی روی برگهٔ دفتر ثبت‌نام ----------
    $cid = farzaneh_reserve_cid();
    if ($cid < 1) {
        farzaneh_json(['ok' => false, 'error' => 'خطای سرور در ساخت دفتر ثبت‌نام؛ لطفاً چند لحظه بعد دوباره تلاش کنید.'], 500);
    }

    try {
        $options = \Widget\Options::alloc();
        $db = \Typecho\Db::get();

        $ownerRow = $db->fetchRow(
            $db->select('authorId')->from('table.contents')->where('cid = ?', $cid)->limit(1)
        );
        $ownerId = (int)($ownerRow['authorId'] ?? 1);

        /*
         * محدودیت فاصلهٔ ارسال (مثل Widget\Feedback و افزونهٔ Booking):
         * اگر گزینهٔ commentsPostIntervalEnable فعال باشد و آخرین ارسالِ همین IP
         * روی این برگه کمتر از commentsPostInterval ثانیه پیش بوده باشد، رد می‌شود.
         */
        $intervalBlocked = false;
        try {
            if (!\Widget\User::alloc()->pass('editor', true) && $options->commentsPostIntervalEnable) {
                $latest = $db->fetchRow(
                    $db->select('created')->from('table.comments')
                        ->where('cid = ? AND ip = ?', $cid, $request->getIp())
                        ->order('created', \Typecho\Db::SORT_DESC)
                        ->limit(1)
                );
                if ($latest && (int)$options->time - (int)$latest['created'] >= 0
                    && (int)$options->time - (int)$latest['created'] < (int)$options->commentsPostInterval) {
                    $intervalBlocked = true;
                }
            }
        } catch (\Throwable $e) {
        }
        if ($intervalBlocked) {
            farzaneh_json(['ok' => false, 'error' => 'ارسال‌ها بیش از حد نزدیک است؛ چند دقیقه بعد دوباره تلاش کنید.'], 429);
        }

        // متن خوانا برای پنل مدیریت (نمایش عمومی ندارد)
        $lines = ['[درخواست ثبت‌نام دوره]'];
        $lines[] = 'نام: ' . $name;
        $lines[] = 'تلفن: ' . $phone;
        if ($mail !== '') {
            $lines[] = 'ایمیل: ' . $mail;
        }
        if ($course !== '') {
            $lines[] = 'دوره: ' . $course;
        }
        if ($level !== '') {
            $lines[] = 'سطح: ' . $level;
        }
        if ($grade !== '') {
            $lines[] = 'پایه: ' . $grade;
        }
        if ($time !== '') {
            $lines[] = 'زمان: ' . $time;
        }
        if ($note !== '') {
            $lines[] = 'توضیحات: ' . $note;
        }

        // ثبت (شمارهٔ تلفن در فیلد url — الگوی افزونهٔ Booking)
        // توجه: در هستهٔ تایپ‌رینیو Db::query برای INSERT همان شناسهٔ درج‌شده را برمی‌گرداند
        $coid = (int)$db->query(
            $db->insert('table.comments')->rows([
                'cid'      => $cid,
                'created'  => (int)$options->time,
                'author'   => $name,
                'authorId' => 0,
                'ownerId'  => $ownerId,
                'mail'     => $mail,
                'url'      => $phone,
                'ip'       => substr((string)$request->getIp(), 0, 64),
                'agent'    => substr((string)$request->getAgent(), 0, 511),
                'text'     => implode("\n", $lines),
                'type'     => 'comment',
                'status'   => 'waiting', // هرگز عمومی نمی‌شود؛ فقط پنل مدیریت و برگهٔ مدیریت ثبت‌نام‌ها
                'parent'   => 0,
            ])
        );

        // شمارندهٔ دیدگاه‌های برگه (برای پنل مدیریت درست باشد)
        try {
            $db->query(
                $db->update('table.contents')
                    ->expression('commentsNum', 'commentsNum + 1')
                    ->where('cid = ?', $cid)
            );
        } catch (\Throwable $e) {
        }

        // اطلاع‌رسانی ایمیلی مدیر (در صورت پیکربندی ایمیل در تایپ‌رینیو)
        try {
            $farzanehAdminMail = trim((string)($options->mailFrom ?? $options->mailSmtpUser ?? ''));
            if ($farzanehAdminMail === '') {
                $farzanehAdminMail = trim((string)($options->adminMail ?? ''));
            }
            if ($farzanehAdminMail !== '' && filter_var($farzanehAdminMail, FILTER_VALIDATE_EMAIL)
                && class_exists('\Typecho\Mail\Message') && class_exists('\Typecho\Mail\Queue')) {
                $manageUrl = farzaneh_manage_url();
                $farzanehMailText = implode("\n", $lines)
                    . ($manageUrl !== '' ? "\n\nمشاهده و مدیریت:\n" . $manageUrl : '');
                $farzanehMailHtml = '<div style="font-family:Tahoma,Arial,sans-serif;direction:rtl;text-align:right;line-height:2">'
                    . nl2br(htmlspecialchars($farzanehMailText, ENT_QUOTES, 'UTF-8')) . '</div>';
                $farzanehMessage = new \Typecho\Mail\Message(
                    $farzanehAdminMail,
                    'درخواست ثبت‌نام جدید — ' . $name,
                    $farzanehMailHtml,
                    $farzanehAdminMail,
                    (string)($options->mailFromName ?? $options->title ?? 'فرزانه'),
                    'مدیر سایت',
                    $farzanehMailText
                );
                \Typecho\Mail\Queue::enqueue('enroll', $farzanehMessage, $db, $options);
            }
        } catch (\Throwable $e) {
            // ایمیل اختیاری است؛ نبود آن خطا محسوب نمی‌شود
        }

        farzaneh_json([
            'ok'     => true,
            'stored' => true,
            'coid'   => $coid,
        ]);
    } catch (\Throwable $e) {
        // ثبت خطای واقعی در لاگ PHP برای عیب‌یابی (پیام کاربر تغییر نمی‌کند)
        try {
            error_log('[farzaneh] enroll save failed: ' . $e->getMessage()
                . ' @ ' . $e->getFile() . ':' . $e->getLine());
        } catch (\Throwable $e2) {
        }
        farzaneh_json(['ok' => false, 'error' => 'خطای سرور در ذخیرهٔ درخواست؛ لطفاً دوباره تلاش کنید.'], 500);
    }
}

/**
 * حالت‌های مدیریتی ثبت‌نام (تأیید/رد/حذف) — فقط اعضای مجاز (مدیر/سردبیر).
 * coid باید متعلق به برگهٔ دفتر ثبت‌نام باشد (بررسی مثل افزونهٔ Booking).
 */
function farzaneh_handle_enroll_manage($request, string $mode): void
{
    if (!farzaneh_can_manage_enrollments()) {
        farzaneh_json(['ok' => false, 'error' => 'برای مدیریت ثبت‌نام‌ها باید با حساب مدیر وارد شوید.'], 403);
    }

    // توکن امنیتی (ادغام با منطق همانند protect)
    if (!farzaneh_enroll_token_ok($request)) {
        farzaneh_json(['ok' => false, 'error' => 'توکن امنیتی نامعتبر است؛ صفحه را رفرش کنید.'], 403);
    }

    $coid = (int)(string)$request->get('coid', '0');
    if ($coid < 1) {
        farzaneh_json(['ok' => false, 'error' => 'شناسهٔ درخواست نامعتبر است.'], 400);
    }

    try {
        $cid = farzaneh_reserve_cid();
        if ($cid < 1) {
            farzaneh_json(['ok' => false, 'error' => 'دفتر ثبت‌نام یافت نشد.'], 500);
        }
        $db = \Typecho\Db::get();

        // فقط درخواست‌های همین دفتر
        $row = $db->fetchRow(
            $db->select('coid, status')->from('table.comments')
                ->where('coid = ? AND cid = ? AND parent = 0 AND type = ?', $coid, $cid, 'comment')
                ->limit(1)
        );
        if (!$row) {
            farzaneh_json(['ok' => false, 'error' => 'درخواستی با این شناسه یافت نشد.'], 404);
        }

        if ($mode === 'delete') {
            $db->query(
                $db->delete('table.comments')->where('coid = ? AND cid = ?', $coid, $cid)
            );
            // کاهش شمارنده
            try {
                $db->query(
                    $db->update('table.contents')
                        ->expression('commentsNum', 'GREATEST(commentsNum - 1, 0)')
                        ->where('cid = ?', $cid)
                );
            } catch (\Throwable $e) {
            }
        } else {
            $status = ($mode === 'approve') ? 'approved' : 'spam';
            $db->query(
                $db->update('table.comments')
                    ->rows(['status' => $status])
                    ->where('coid = ? AND cid = ?', $coid, $cid)
            );
        }

        farzaneh_json([
            'ok'         => true,
            'mode'       => $mode,
            'coid'       => $coid,
            'status'     => ($mode === 'delete') ? 'deleted' : (($mode === 'approve') ? 'approved' : 'spam'),
            'pending'    => farzaneh_pending_enrollments_count(),
        ]);
    } catch (\Throwable $e) {
        farzaneh_json(['ok' => false, 'error' => 'خطای سرور در به‌روزرسانی درخواست.'], 500);
    }
}

/**
 * فهرست ثبت‌نام‌ها برای برگهٔ «مدیریت ثبت‌نام‌ها».
 * ترتیب: در انتظار اول، سپس تأییدشده‌ها و ردشده‌ها (جدید به قدیم).
 */
function farzaneh_enrollments_list(int $limit = 200): array
{
    try {
        $cid = farzaneh_reserve_cid();
        if ($cid < 1) {
            return [];
        }
        $db = \Typecho\Db::get();
        $rows = $db->fetchAll(
            $db->select('coid', 'created', 'author', 'mail', 'url', 'ip', 'text', 'status')
                ->from('table.comments')
                ->where('cid = ? AND parent = 0 AND type = ?', $cid, 'comment')
                ->order('status', \Typecho\Db::SORT_ASC)
                ->order('created', \Typecho\Db::SORT_DESC)
                ->limit($limit)
        );

        // waiting اول، سپس approved، سپس spam — هر کدام جدید به قدیم
        $order = ['waiting' => 0, 'approved' => 1, 'spam' => 2];
        usort($rows, function ($a, $b) use ($order) {
            $ka = $order[$a['status']] ?? 3;
            $kb = $order[$b['status']] ?? 3;
            if ($ka !== $kb) {
                return $ka <=> $kb;
            }
            return (int)$b['created'] <=> (int)$a['created'];
        });

        foreach ($rows as &$r) {
            $r = array_merge($r, farzaneh_parse_enroll_text((string)$r['text']));
        }
        unset($r);

        return $rows;
    } catch (\Throwable $e) {
        return [];
    }
}

/**
 * پارس متن خوانای درخواست به فیلدهای ساختاریافته برای نمایش در برگهٔ مدیریت.
 * (قالب متن را خودمان در farzaneh_handle_enroll می‌نویسیم؛ پس پارس قطعی است.)
 */
function farzaneh_parse_enroll_text(string $text): array
{
    $out = [
        'phone'  => '',
        'mail'   => '',
        'course' => '',
        'level'  => '',
        'grade'  => '',
        'time'   => '',
        'note'   => '',
    ];

    foreach (preg_split('/\r\n|\r|\n/', $text) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '[') {
            continue;
        }
        $pos = strpos($line, ':');
        if ($pos === false) {
            continue;
        }
        $key = trim(substr($line, 0, $pos));
        $val = trim(substr($line, $pos + 1));
        switch ($key) {
            case 'تلفن':
                $out['phone'] = $val;
                break;
            case 'ایمیل':
                $out['mail'] = $val;
                break;
            case 'دوره':
                $out['course'] = $val;
                break;
            case 'سطح':
                $out['level'] = $val;
                break;
            case 'پایه':
                $out['grade'] = $val;
                break;
            case 'زمان':
                $out['time'] = $val;
                break;
            case 'توضیحات':
                $out['note'] = $val;
                break;
        }
    }
    return $out;
}

/* ================================================================
 *  ۶) راه‌انداز پوسته
 * ================================================================ */

// ثبت مسیر اختصاصی ثبت‌نام (یک‌بار؛ idempotent) — باید پیش از رندر فرم اجرا شود
farzaneh_register_enroll_route();

function themeInit($archive)
{
    // هوک شمارش بازدید قبل از رندر
    try {
        \Typecho\Plugin::factory('Widget\Archive')->beforeRender = 'farzaneh_count_view';
    } catch (\Throwable $e) {
    }

    /*
     * نکتهٔ مهم: پراپرتی‌های request و parameter ویجت «محافظت‌شده» (protected) هستند و
     * از یک تابع سراسری، Typecho\Widget::__get() برایشان null برمی‌گرداند؛ یعنی الگوی
     * $archive->request->isPost() هرگز اجرا نمی‌شود. برای همین، کل این بخش داخل یک
     * Closure متصل به اسکوپ کلاس Typecho\Widget اجرا می‌شود تا PHP اجازهٔ دسترسی بدهد.
     */
    try {
        \Closure::bind(function () {
            /** @var \Widget\Archive $this */

            // نقطهٔ پایانی AJAX لایک
            if ($this->request->isPost() && (string)$this->request->get('farzanehLike', '') !== '') {
                farzaneh_handle_like($this->request);
            }

            /*
             * نقطهٔ پایانی AJAX ثبت‌نام — سه مسیر پوشش داده می‌شود:
             *  ۱) POST به مسیر اختصاصی /farzaneh-register (مسیر در functions.php ثبت شده)
             *  ۲) POST به هر صفحهٔ پوسته (پشتیبان؛ مثل رفتار قدیمی)
             *  ۳) POST به مسیر ثبت‌نشده → 404 → ExceptionHandle → Archive(404) → همین themeInit
             */
            if ($this->request->isPost() && (string)$this->request->get('farzanehEnroll', '') !== '') {
                farzaneh_handle_enroll($this->request);
            }

            // درخواست غیر-POST روی نقطهٔ پایانی اختصاصی → 405 (endpoint فقط برای POST است)
            if ((string)$this->request->getPathInfo() === '/' . farzaneh_enroll_route_name()) {
                if (!$this->request->isPost()) {
                    farzaneh_json(['ok' => false, 'error' => 'این نقطهٔ پایانی فقط برای ثبت درخواست ثبت‌نام است.'], 405);
                }
            }

            /*
             * فهرست وبلاگ روی مسیر آرشیو (پیش‌فرض /blog/):
             * هستهٔ تایپ‌رینیو مسیر archive را با ۴۰۴ می‌بندد؛ در حالت پیش‌فرض
             * (صفحهٔ نخست = نوشته‌های اخیر) نوع درخواست را به index تبدیل می‌کنیم تا
             * فهرست مقالات همیشه در /blog/ رندر شود و منوی «مقالات» کار کند.
             */
            $farzanehRouteType = (string)$this->parameter->type;
            if ($farzanehRouteType === 'archive' || $farzanehRouteType === 'archive_page') {
                $farzanehFrontPage = 'recent';
                $farzanehFrontArchive = 0;
                try {
                    $farzanehFrontPage = (string)\Widget\Options::alloc()->frontPage;
                    $farzanehFrontArchive = (int)\Widget\Options::alloc()->frontArchive;
                } catch (\Throwable $e) {
                }
                if ($farzanehFrontPage === 'recent' || $farzanehFrontArchive !== 1) {
                    $this->parameter->type = ($farzanehRouteType === 'archive_page') ? 'index_page' : 'index';
                }
            }
        }, $archive, \Typecho\Widget::class)();
    } catch (\Throwable $e) {
    }
}

/* ================================================================
 *  ۷) پارسرهای بخش‌های داینامیک
 * ================================================================ */

/** پارس خطوط «الف | ب | ج» — جداکننده فقط | */
function farzaneh_parse_lines(?string $text, int $minParts = 1): array
{
    $text = (string)$text;
    if (trim($text) === '') {
        return [];
    }
    $out = [];
    foreach (preg_split('/\r\n|\r|\n/', $text) as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        $parts = preg_split('/\s*\|\s*/', $line);
        $parts = array_map('trim', $parts);
        while (count($parts) > 0 && $parts[count($parts) - 1] === '') {
            array_pop($parts);
        }
        if (count($parts) >= $minParts) {
            $out[] = $parts;
        }
    }
    return $out;
}

/** پارس آمار هیرو: «عدد | عنوان» */
function farzaneh_parse_stats(?string $text): array
{
    $out = [];
    foreach (farzaneh_parse_lines($text, 2) as $parts) {
        $num = toPersianNumbers(preg_replace('/[^0-9+]/', '', $parts[0]));
        $out[] = ['num' => ($num !== '' ? $num : '۰'), 'label' => $parts[1]];
    }
    return $out;
}

/**
 * پارس آمار بخش «فرزانه در یک نگاه»: «عنوان | مقدار | آیکون»
 *
 * مقدار متن آزاد است (مثل «۹۸٪»، «۴۵+» یا «۱۲۰ نفر»)؛ اگر با عدد شروع شود،
 * بخش عددی برای شمارندهٔ انیمیشنی و باقی‌مانده به‌عنوان پسوند جدا می‌شود.
 * آیکان از نقشهٔ آیکون‌های پوسته اعتبارسنجی می‌شود (پیش‌فرض: trophy).
 */
function farzaneh_parse_glance(?string $text): array
{
    $out = [];
    foreach (farzaneh_parse_lines($text, 2) as $parts) {
        $value = trim($parts[1] ?? '');
        $icon  = trim($parts[2] ?? '');
        if ($icon === '' || !farzaneh_icon_exists($icon)) {
            $icon = 'trophy';
        }
        $out[] = [
            'label' => $parts[0],
            'value' => ($value !== '') ? $value : '۰',
            'icon'  => $icon,
        ];
    }
    return $out;
}

/**
 * پارس دوره‌های آموزشی:
 * «عنوان | دسته | استاد | سطح | مدت | قیمت | قیمت قبل | بج | توضیح | تصویر»
 */
function farzaneh_parse_courses(?string $text): array
{
    $out = [];
    foreach (farzaneh_parse_lines($text, 1) as $parts) {
        $image = trim($parts[9] ?? '');
        if ($image !== '' && preg_match('#^(data:|https?://|//)#i', $image) !== 1) {
            $image = farzaneh_asset(ltrim($image, '/'));
        }
        $out[] = [
            'title'    => $parts[0],
            'category' => $parts[1] ?? '',
            'teacher'  => $parts[2] ?? '',
            'level'    => $parts[3] ?? '',
            'duration' => $parts[4] ?? '',
            'price'    => $parts[5] ?? '',
            'oldPrice' => $parts[6] ?? '',
            'badge'    => $parts[7] ?? '',
            'desc'     => $parts[8] ?? '',
            'image'    => $image,
        ];
    }
    return $out;
}

/** نقشهٔ سطح آموزشی → کلاس رنگی کارت دوره */
function farzaneh_level_class(string $level): string
{
    $map = [
        'مبتدی'    => 'lvl-beginner',
        'متوسط'    => 'lvl-intermediate',
        'پیشرفته'  => 'lvl-advanced',
        'همه سطوح' => 'lvl-all',
    ];
    return $map[$level] ?? 'lvl-all';
}

/** نقشهٔ وضعیت کلاس → کلاس رنگی */
function farzaneh_class_status_class(string $status): string
{
    $map = [
        'ثبت‌نام باز'   => 'cls-open',
        'تقریباً تکمیل' => 'cls-almost',
        'تکمیل شده'    => 'cls-full',
    ];
    return $map[$status] ?? 'cls-open';
}

/**
 * پارس کلاس‌های هفتگی:
 * «عنوان | استاد | روزها | ساعت | ظرفیت | وضعیت»
 */
function farzaneh_parse_classes(?string $text): array
{
    $out = [];
    foreach (farzaneh_parse_lines($text, 3) as $parts) {
        $out[] = [
            'title'    => $parts[0],
            'teacher'  => $parts[1] ?? '',
            'days'     => $parts[2] ?? '',
            'time'     => $parts[3] ?? '',
            'capacity' => $parts[4] ?? '',
            'status'   => $parts[5] ?? 'ثبت‌نام باز',
        ];
    }
    return $out;
}

/** پارس ویژگی‌های «چرا ما»: «آیکون | عنوان | توضیح» */
function farzaneh_parse_features(?string $text): array
{
    $out = [];
    foreach (farzaneh_parse_lines($text, 1) as $parts) {
        $out[] = [
            'icon'  => farzaneh_icon_exists($parts[0]) ? $parts[0] : 'check-circle',
            'title' => $parts[1] ?? $parts[0],
            'desc'  => $parts[2] ?? '',
        ];
    }
    return $out;
}

/** پارس نظرات دانش‌آموزان و والدین: «نام | نقش | متن | عکس (اختیاری)» */
function farzaneh_parse_testimonials(?string $text): array
{
    $out = [];
    foreach (farzaneh_parse_lines($text, 3) as $parts) {
        $photo = trim($parts[3] ?? '');
        if ($photo !== '' && preg_match('#^(data:|https?://|//)#i', $photo) !== 1) {
            $photo = farzaneh_asset(ltrim($photo, '/'));
        }
        $out[] = [
            'name'  => $parts[0],
            'meta'  => $parts[1],
            'text'  => $parts[2],
            'photo' => $photo,
        ];
    }
    return $out;
}

/** پارس اساتید: «نام | سمت/تخصص | عکس | توضیح (اختیاری)» */
function farzaneh_parse_team(?string $text): array
{
    $out = [];
    foreach (farzaneh_parse_lines($text, 2) as $parts) {
        $photo = trim($parts[2] ?? '');
        if ($photo !== '' && preg_match('#^(data:|https?://|//)#i', $photo) !== 1) {
            $photo = farzaneh_asset(ltrim($photo, '/'));
        }
        $out[] = [
            'name' => $parts[0],
            'role' => $parts[1],
            'photo' => $photo,
            'desc' => $parts[3] ?? '',
        ];
    }
    return $out;
}

/** پارس سوالات متداول: «سوال | پاسخ» */
function farzaneh_parse_faq(?string $text): array
{
    $out = [];
    foreach (farzaneh_parse_lines($text, 2) as $parts) {
        $out[] = ['q' => $parts[0], 'a' => $parts[1]];
    }
    return $out;
}

/** حرف اول نام → آواتار حرفی */
function farzaneh_initial(string $name): string
{
    $name = trim($name);
    if ($name === '') {
        return '؟';
    }
    return mb_substr($name, 0, 1, 'UTF-8');
}

/* ================================================================
 *  ۸) تصویر شاخص، فیلدهای آموزشی و نوشته‌های مرتبط
 * ================================================================ */

/** تصویر شاخص نوشته: فیلدهای thumb/cover → اولین تصویر متن → پیش‌فرض */
function farzaneh_thumbnail($content, bool $fallback = true): string
{
    // ۱) فیلدهای اختصاصی
    try {
        $fields = $content->fields;
        foreach (['thumb', 'cover', 'img', 'thumbnail', 'banner'] as $key) {
            $value = trim((string)($fields->{$key} ?? ''));
            if ($value !== '') {
                return farzaneh_resolve_url($value);
            }
        }
    } catch (\Throwable $e) {
    }

    // ۲) نخستین تصویر متن خام
    try {
        $text = (string)$content->text;
        if ($text !== '') {
            if (preg_match('#<img[^>]*\bsrc=["\']([^"\']+)["\']#iu', $text, $m)) {
                return farzaneh_resolve_url($m[1]);
            }
            if (preg_match('#!\[[^\]]*\]\(\s*<?([^)\s>]+)[^)]*\)#iu', $text, $m)) {
                return farzaneh_resolve_url($m[1]);
            }
        }
    } catch (\Throwable $e) {
    }

    // ۳) پیش‌فرض (قابل تنظیم توسط مدیر)
    $custom = trim((string)farzaneh_opt_raw('farzanehDefaultCover'));
    if ($custom !== '') {
        return farzaneh_resolve_url($custom);
    }
    return $fallback ? farzaneh_asset('img/default-cover.jpg') : '';
}

/** فیلد زمان مطالعهٔ نوشته (دقیقه) — فیلد اختصاصی readingTime */
function farzaneh_reading_time($content): string
{
    try {
        $fields = $content->fields;
        $value = trim((string)($fields->readingTime ?? ''));
        if ($value !== '' && is_numeric($value)) {
            return toPersianNumbers($value);
        }
    } catch (\Throwable $e) {
    }
    return '';
}

/** فیلد پایهٔ تحصیلی مناسب نوشته — فیلد اختصاصی grade */
function farzaneh_grade($content): string
{
    try {
        $fields = $content->fields;
        $value = trim((string)($fields->grade ?? ''));
        if ($value !== '') {
            return $value;
        }
    } catch (\Throwable $e) {
    }
    return '';
}

/**
 * آخرین مقالات منتشرشده برای صفحهٔ اول:
 * کوئری مستقیم شامل متن (برای چکیده) + فیلدهای اختصاصی (تصویر/زمان مطالعه/پایه) + بازدید.
 */
function farzaneh_recent_posts(int $count = 3): array
{
    $out = [];
    $count = max(1, min(12, $count));
    try {
        $db = \Typecho\Db::get();
        $hasStats = farzaneh_stats_ready();
        $cols = ['table.contents.cid', 'table.contents.title', 'table.contents.slug',
            'table.contents.created', 'table.contents.text'];
        if ($hasStats) {
            $cols[] = 'table.contents.views';
        }
        $rows = $db->fetchAll(
            $db->select(...$cols)
                ->from('table.contents')
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', \Widget\Options::alloc()->time)
                ->where('table.contents.type = ?', 'post')
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit($count)
        );
        if (empty($rows)) {
            return $out;
        }

        // فیلدهای اختصاصی همهٔ نوشته‌ها در یک کوئری
        $cids = array_map(function ($r) { return (int)$r['cid']; }, $rows);
        $fieldMap = [];
        try {
            $frows = $db->fetchAll(
                $db->select()->from('table.fields')->where('cid IN ?', $cids)
            );
            foreach ((array)$frows as $f) {
                $val = ('json' == $f['type']) ? json_decode((string)$f['str_value'], true) : $f[$f['type'] . '_value'];
                $fieldMap[(int)$f['cid']][(string)$f['name']] = (string)$val;
            }
        } catch (\Throwable $e) {
        }

        // مسیر پیوندها
        $siteBase = rtrim((string)\Widget\Options::alloc()->siteUrl, '/');
        $route = \Widget\Options::alloc()->routingTable['post'];
        $routeUrl = is_string($route) ? $route : ($route['url'] ?? '');

        foreach ($rows as $row) {
            $cid = (int)$row['cid'];
            $path = str_replace(['[slug:digital]', '[slug]', '[cid:digital]', '[cid]'],
                [(string)$row['slug'], (string)$row['slug'], (string)$cid, (string)$cid], $routeUrl);
            $text = (string)$row['text'];
            if (strpos($text, '<!--markdown-->') === 0) {
                $text = substr($text, 15);
            }

            // تصویر شاخص: فیلد → اولین تصویر متن → پیش‌فرض
            $thumb = '';
            $fields = $fieldMap[$cid] ?? [];
            foreach (['thumb', 'cover', 'img', 'thumbnail', 'banner'] as $key) {
                if (isset($fields[$key]) && trim($fields[$key]) !== '') {
                    $thumb = farzaneh_resolve_url(trim($fields[$key]));
                    break;
                }
            }
            if ($thumb === '' && preg_match('#<img[^>]*\bsrc=["\']([^"\']+)["\']#iu', $text, $m)) {
                $thumb = farzaneh_resolve_url($m[1]);
            } elseif ($thumb === '' && preg_match('#!\[[^\]]*\]\(\s*<?([^)\s>]+)[^)]*\)#iu', $text, $m)) {
                $thumb = farzaneh_resolve_url($m[1]);
            }
            if ($thumb === '') {
                $thumb = farzaneh_asset('img/default-cover.jpg');
            }

            $out[] = [
                'title'    => (string)$row['title'],
                'url'      => $siteBase . '/' . ltrim($path, '/'),
                'created'  => (int)$row['created'],
                'excerpt'  => trim(strip_tags($text)),
                'thumb'    => $thumb,
                'readingTime' => $fields['readingTime'] ?? '',
                'grade'    => $fields['grade'] ?? '',
                'views'    => $hasStats ? (int)($row['views'] ?? 0) : 0,
            ];
        }
    } catch (\Throwable $e) {
    }
    return $out;
}

/** نوشته‌های مرتبط بر اساس دستهٔ مشترک */
function farzaneh_related_posts($archive, int $count = 3): array
{
    $out = [];
    try {
        $cid = (int)$archive->cid;
        if ($cid < 1) {
            return $out;
        }
        $category = $archive->getCategory ? $archive->getCategory() : [];
        $mid = 0;
        if (is_array($category) && isset($category[0]['mid'])) {
            $mid = (int)$category[0]['mid'];
        }
        if ($mid < 1) {
            return $out;
        }

        $db = \Typecho\Db::get();
        $rows = $db->fetchAll(
            $db->select('table.contents.cid', 'table.contents.title', 'table.contents.slug', 'table.contents.created')
                ->from('table.contents')
                ->join('table.relationships', 'table.contents.cid = table.relationships.cid')
                ->where('table.relationships.mid = ?', $mid)
                ->where('table.contents.cid <> ?', $cid)
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', \Widget\Options::alloc()->time)
                ->where('table.contents.type = ?', 'post')
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit($count)
        );

        foreach ($rows as $row) {
            $route = \Widget\Options::alloc()->routingTable['post'];
            $path = str_replace('[slug:digital]', (string)$row['slug'], is_string($route) ? $route : ($route['url'] ?? ''));
            $path = str_replace(['[slug]', '[cid:digital]', '[cid]'], [(string)$row['slug'], (string)$row['cid'], (string)$row['cid']], $path);
            $out[] = [
                'title' => $row['title'],
                'url' => rtrim((string)\Widget\Options::alloc()->siteUrl, '/') . '/' . ltrim($path, '/'),
                'created' => (int)$row['created'],
            ];
        }
    } catch (\Throwable $e) {
    }
    return $out;
}

/* ================================================================
 *  ۹) لوگو
 * ================================================================ */

/** آدرس لوگو: تنظیمات → فایل محلی img/logo.png → خالی (آیکون پیش‌فرض) */
function farzaneh_logo_url(): string
{
    $setting = farzaneh_opt_raw('farzanehLogoUrl');
    if ($setting !== null) {
        $setting = trim($setting);
        if ($setting !== '') {
            return farzaneh_resolve_url($setting);
        }
    }

    $local = __TYPECHO_ROOT_DIR__ . '/usr/themes/' . basename(__DIR__) . '/img/logo.png';
    if (is_file($local)) {
        return farzaneh_asset('img/logo.png');
    }
    return '';
}

/* ================================================================
 *  ۱۰) فرم تنظیمات پوسته
 * ================================================================ */

function themeConfig($form)
{
    /* ---------- بخش ۱: عمومی ---------- */

    $instituteName = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehInstituteName',
        null,
        'آموزشگاه فرزانه',
        _t('نام آموزشگاه / مدرسه'),
        _t('نام مرکز آموزشی در هدر، فوتر و عنوان صفحهٔ اول نمایش داده می‌شود.')
    );
    $form->addInput($instituteName->addRule('xssCheck', _t('لطفاً نام معتبر وارد کنید')));

    $tagline = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehTagline',
        null,
        'یادگیری، روشن کردن چراغ دانایی است',
        _t('شعار کوتاه'),
        _t('زیر نام آموزشگاه در هدر و جاهای کم‌رنگ‌تر نمایش داده می‌شود.')
    );
    $form->addInput($tagline->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $logoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehLogoUrl',
        null,
        null,
        _t('آدرس لوگو'),
        _t('آدرس تصویر لوگو (اختیاری). اگر خالی باشد و فایل img/logo.png داخل پوسته باشد از آن استفاده می‌شود؛ در غیر این صورت آیکون کلاه فارغ‌التحصیلی نمایش داده می‌شود.')
    );
    $form->addInput($logoUrl->addRule('xssCheck', _t('لطفاً یک آدرس معتبر وارد کنید')));

    $primaryColor = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehPrimaryColor',
        null,
        '#4f46e5',
        _t('رنگ اصلی (نیلی آموزش)'),
        _t('کد HEX مثل #4f46e5 — برای دکمه‌ها، لینک‌ها و تاکیدها.')
    );
    $form->addInput($primaryColor->addRule('xssCheck', _t('کد رنگ HEX وارد کنید (مثل #4f46e5)')));

    $secondaryColor = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehSecondaryColor',
        null,
        '#312e81',
        _t('رنگ دوم (نیلی تیره)'),
        _t('کد HEX مثل #312e81 — برای گرادیان‌ها و متن‌های برجسته.')
    );
    $form->addInput($secondaryColor->addRule('xssCheck', _t('کد رنگ HEX وارد کنید (مثل #312e81)')));

    $showTopbar = new \Typecho\Widget\Helper\Form\Element\Radio(
        'farzanehShowTopbar',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('نوار بالای هدر'),
        _t('نوار باریک بالای هدر شامل تلفن، ساعت کاری و شبکه‌های اجتماعی.')
    );
    $form->addInput($showTopbar);

    $showViews = new \Typecho\Widget\Helper\Form\Element\Radio(
        'farzanehShowViews',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('شمار بازدید'),
        _t('نمایش تعداد بازدید در صفحهٔ نوشته و کارت‌های فهرست وبلاگ. شمارش بازدید خودکار انجام می‌شود.')
    );
    $form->addInput($showViews);

    $showLikes = new \Typecho\Widget\Helper\Form\Element\Radio(
        'farzanehShowLikes',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('دکمهٔ لایک'),
        _t('نمایش دکمهٔ «این مطلب را پسندیدید؟» در انتهای نوشته‌ها.')
    );
    $form->addInput($showLikes);

    $countAdminViews = new \Typecho\Widget\Helper\Form\Element\Radio(
        'farzanehCountAdminViews',
        ['1' => _t('شمرده شود'), '0' => _t('شمرده نشود')],
        '0',
        _t('بازدید مدیران'),
        _t('آیا بازدید مدیران از نوشته‌ها هم شمرده شود؟ (پیش‌فرض: شمرده نمی‌شود)')
    );
    $form->addInput($countAdminViews);

    /* ---------- بخش ۲: هیرو ---------- */

    $heroBadge = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehHeroBadge',
        null,
        'آموزشگاه تخصصی دانش‌آموزی و کنکور',
        _t('هیرو — بج بالای عنوان'),
        _t('متن بج کوچک بالای عنوان اصلی صفحهٔ اول.')
    );
    $form->addInput($heroBadge->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $heroTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehHeroTitle',
        null,
        'مسیر موفقیت تحصیلی، از همین‌جا آغاز می‌شود',
        _t('هیرو — عنوان اصلی'),
        _t('عنوان بزرگ صفحهٔ اول سایت.')
    );
    $form->addInput($heroTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $heroSubtitle = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'farzanehHeroSubtitle',
        null,
        "در فرزانه، اساتید باتجربه با کلاس‌های کم‌جمعیت، آزمون‌های هدفمند و مشاورهٔ تحصیلی فردی، دانش‌آموزان را به قبولی مطمئن می‌رسانند.\nهمین حالا دورهٔ مناسب خود را انتخاب کنید و اولین جلسهٔ مشاوره را رایگان رزرو کنید.",
        _t('هیرو — توضیح'),
        _t('متن توضیح هیرو. هر خط یک پاراگراف است.')
    );
    $form->addInput($heroSubtitle);

    $heroImage = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehHeroImage',
        null,
        null,
        _t('هیرو — تصویر'),
        _t('آدرس تصویر هیرو (خالی = تصویر پیش‌فرض کلاس درس داخل پوسته).')
    );
    $form->addInput($heroImage->addRule('xssCheck', _t('آدرس تصویر معتبر وارد کنید')));

    $heroBtn1Text = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehHeroBtn1Text',
        null,
        'ثبت‌نام دوره‌ها',
        _t('هیرو — دکمهٔ اول (متن)'),
        _t('متن دکمهٔ اصلی هیرو.')
    );
    $form->addInput($heroBtn1Text->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $heroBtn1Url = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehHeroBtn1Url',
        null,
        '#enroll',
        _t('هیرو — دکمهٔ اول (آدرس)'),
        _t('آدرس مقصد؛ برای پرش به فرم ثبت‌نام همان صفحه #enroll بگذارید.')
    );
    $form->addInput($heroBtn1Url->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $heroBtn2Text = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehHeroBtn2Text',
        null,
        'مشاهدهٔ دوره‌ها',
        _t('هیرو — دکمهٔ دوم (متن)'),
        _t('متن دکمهٔ فرعی هیرو (خالی = مخفی).')
    );
    $form->addInput($heroBtn2Text->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $heroBtn2Url = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehHeroBtn2Url',
        null,
        '#courses',
        _t('هیرو — دکمهٔ دوم (آدرس)'),
        _t('آدرس مقصد دکمهٔ دوم.')
    );
    $form->addInput($heroBtn2Url->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $heroStats = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'farzanehHeroStats',
        null,
        "۱۲+ | سال تجربهٔ آموزشی\n۳۵۰۰+ | دانش‌آموز موفق\n۴۰+ | استاد متخصص\n۹۸٪ | رضایت والدین",
        _t('هیرو — آمار'),
        _t('هر خط: «عدد | عنوان». حداکثر ۴ مورد زیر دکمه‌های هیرو نمایش داده می‌شود.')
    );
    $form->addInput($heroStats);

    /* ---------- بخش ۳: دوره‌های آموزشی ---------- */

    $coursesTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehCoursesTitle',
        null,
        'دوره‌های آموزشی فرزانه',
        _t('دوره‌ها — عنوان بخش'),
        _t('اگر خالی باشد، کل بخش دوره‌ها از صفحهٔ اول حذف می‌شود.')
    );
    $form->addInput($coursesTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $coursesSubtitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehCoursesSubtitle',
        null,
        'از تقویتی تا کنکور؛ دوره‌ای که لازم دارید، اینجاست',
        _t('دوره‌ها — توضیح'),
        _t('زیرعنوان بخش دوره‌ها.')
    );
    $form->addInput($coursesSubtitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $courses = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'farzanehCourses',
        null,
        "ریاضی نهم | تقویتی | سرکار خانم احمدی | مبتدی | ۳۰ ساعت / ۱۶ جلسه | ۱٬۸۰۰٬۰۰۰ | ۲٬۲۰۰٬۰۰۰ | پرفروش | تثبیت مفاهیم پایه، حل تمرین هدفمند و آمادگی امتحانات نهایی | | \nفیزیک کنکور | کنکور | دکتر رضایی | پیشرفته | ۴۵ ساعت / ۲۴ جلسه | ۳٬۵۰۰٬۰۰۰ | | جدید | مرور جامع کلِ دروس، تست‌زنی حساب‌شده و آزمون‌های شبیه‌ساز | | \nزبان انگلیسی نوجوانان | مهارتی | سرکار خانم کریمی | همه سطوح | ۲۴ ساعت / ۱۲ جلسه | رایگان جلسهٔ اول | | | مکالمهٔ روزمره، تقویت چهار مهارت با متد بازی‌محور | | \nشیمی دهم | تقویتی | آقای موسوی | متوسط | ۲۸ ساعت / ۱۴ جلسه | ۲٬۰۰۰٬۰۰۰ | ۲٬۵۰۰٬۰۰۰ | تخفیف ویژه | آموزش مفهومی، حل تست ترکیبی و جزوهٔ اختصاصی | | ",
        _t('دوره‌ها — فهرست دوره‌ها'),
        _t('هر خط یک دوره با جداکنندهٔ | : «عنوان | دسته | استاد | سطح (مبتدی/متوسط/پیشرفته/همه سطوح) | مدت | قیمت | قیمت قبل | بج | توضیح | تصویر». تصویر خالی = قالب گرافیکی پیش‌فرض. قیمت «رایگان جلسهٔ اول» یا خالی به‌عنوان متن آزاد نمایش داده می‌شود.')
    );
    $form->addInput($courses);

    /* ---------- بخش ۴: کلاس‌ها و برنامهٔ هفتگی ---------- */

    $classesTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehClassesTitle',
        null,
        'کلاس‌ها و برنامهٔ هفتگی',
        _t('کلاس‌ها — عنوان بخش'),
        _t('اگر خالی باشد، کل بخش کلاس‌ها از صفحهٔ اول حذف می‌شود.')
    );
    $form->addInput($classesTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $classesSubtitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehClassesSubtitle',
        null,
        'برنامهٔ منظم کلاس‌ها با گروه‌های کوچک و پشتیبانی مستقیم استاد',
        _t('کلاس‌ها — توضیح'),
        _t('زیرعنوان بخش کلاس‌ها.')
    );
    $form->addInput($classesSubtitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $classes = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'farzanehClasses',
        null,
        "ریاضی نهم — گروه A | سرکار خانم احمدی | شنبه و دوشنبه | ۱۶:۰۰ تا ۱۷:۳۰ | ۱۲ نفر | ثبت‌نام باز\nفیزیک کنکور — گروه ۱ | دکتر رضایی | یکشنبه و سه‌شنبه | ۱۷:۰۰ تا ۱۹:۰۰ | ۱۵ نفر | تقریباً تکمیل\nزبان انگلیسی نوجوانان | سرکار خانم کریمی | سه‌شنبه | ۱۰:۰۰ تا ۱۱:۳۰ | ۱۰ نفر | ثبت‌نام باز\nشیمی دهم | آقای موسوی | چهارشنبه | ۱۵:۳۰ تا ۱۷:۰۰ | ۱۴ نفر | تکمیل شده",
        _t('کلاس‌ها — فهرست کلاس‌ها'),
        _t('هر خط یک کلاس: «عنوان | استاد | روزها | ساعت | ظرفیت | وضعیت». وضعیت‌های شناخته‌شده: «ثبت‌نام باز»، «تقریباً تکمیل»، «تکمیل شده».')
    );
    $form->addInput($classes);

    /* ---------- بخش ۵: اساتید ---------- */

    $teamTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehTeamTitle',
        null,
        'اساتید ما',
        _t('اساتید — عنوان بخش'),
        _t('اگر خالی باشد، کل بخش اساتید از صفحهٔ اول حذف می‌شود.')
    );
    $form->addInput($teamTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $teamSubtitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehTeamSubtitle',
        null,
        'تیمی از بهترین اساتید و مشاوران تحصیلی کشور',
        _t('اساتید — توضیح'),
        _t('زیرعنوان بخش اساتید.')
    );
    $form->addInput($teamSubtitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $team = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'farzanehTeam',
        null,
        "دکتر امیر رضایی | مدرس فیزیک کنکور — دکترای فیزیک از دانشگاه تهران | | ۱۴ سال سابقهٔ تدریس کنکور و رتبه‌سازی\nسرکار خانم سارا احمدی | مدرس ریاضی متوسطهٔ اول — کارشناسی ارشد آموزش ریاضی | | متد تدریس بازی‌محور و پشتیبانی فردی\nآقای محمد موسوی | مدرس شیمی — رتبهٔ برتر کنکور تجربی | | جزوه‌نویس و مدرس مدارس نمونه\nسرکار خانم نگار کریمی | مدرس زبان انگلیسی — مدرک TESOL | | طراحی دوره‌های مکالمهٔ نوجوانان",
        _t('اساتید — فهرست'),
        _t('هر خط یک استاد: «نام | سمت/تخصص | عکس (اختیاری) | توضیح». بدون عکس، آواتار حرف اول نام نمایش داده می‌شود.')
    );
    $form->addInput($team);

    /* ---------- بخش ۶: چرا فرزانه ---------- */

    $aboutTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehAboutTitle',
        null,
        'چرا آموزشگاه فرزانه؟',
        _t('چرا ما — عنوان'),
        _t('اگر خالی باشد، کل بخش از صفحهٔ اول حذف می‌شود.')
    );
    $form->addInput($aboutTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $aboutText = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'farzanehAboutText',
        null,
        "ما در فرزانه باور داریم هر دانش‌آموز یک مسیر یادگیری منحصربه‌فرد دارد؛ به همین دلیل از روز اول، سطح و نیاز هر فرد سنجیده می‌شود و برنامهٔ مطالعاتی اختصاصی تنظیم می‌شود.\nکلاس‌های کم‌جمعیت، آزمون‌های هفتگی و جلسات مستمر مشاورهٔ تحصیلی، همگی در کنار هم تضمین می‌کنند که هیچ دانش‌آموزی در مسیر تنها نماند.",
        _t('چرا ما — متن'),
        _t('هر خط یک پاراگراف است.')
    );
    $form->addInput($aboutText);

    $aboutImage = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehAboutImage',
        null,
        null,
        _t('چرا ما — تصویر'),
        _t('آدرس تصویر بخش «چرا فرزانه» (خالی = تصویر پیش‌فرض کتابخانه داخل پوسته).')
    );
    $form->addInput($aboutImage->addRule('xssCheck', _t('آدرس تصویر معتبر وارد کنید')));

    $aboutFeatures = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'farzanehAboutFeatures',
        null,
        "users | کلاس‌های کم‌جمعیت | حداکثر ۱۵ نفر در هر کلاس برای اثرگذاری واقعی استاد\nclipboard-check | آزمون و ارزیابی هفتگی | سنجش مستمر پیشرفت با کارنامهٔ تحلیلی برای والدین\nuser | مشاورهٔ تحصیلی فردی | برنامه‌ریزی اختصاصی برای هر دانش‌آموز با پیگیری مستمر\nlaptop | آزمون‌سازی آنلاین | بانک تست هوشمند و آزمون‌های شبیه‌ساز کنکور",
        _t('چرا ما — ویژگی‌ها'),
        _t('هر خط: «آیکون | عنوان | توضیح». آیکون‌ها از مجموع Lucide مثل users، clipboard-check، target، award، brain، lightbulb و…')
    );
    $form->addInput($aboutFeatures);

    $aboutBtnText = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehAboutBtnText',
        null,
        'مشاورهٔ رایگان بگیرید',
        _t('چرا ما — دکمه (متن)'),
        _t('متن دکمهٔ پایین بخش چرا ما (خالی = مخفی).')
    );
    $form->addInput($aboutBtnText->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $aboutBtnUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehAboutBtnUrl',
        null,
        '#enroll',
        _t('چرا ما — دکمه (آدرس)'),
        _t('آدرس مقصد دکمهٔ بخش چرا ما.')
    );
    $form->addInput($aboutBtnUrl->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    /* ---------- بخش ۷: فرزانه در یک نگاه ---------- */

    $statsShow = new \Typecho\Widget\Helper\Form\Element\Radio(
        'farzanehStatsShow',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('بخش «در یک نگاه»'),
        _t('نمایش نوار دستاوردهای آموزشگاه (مثل درصد قبولی کنکور) با مقادیری که خودتان در پایین وارد می‌کنید.')
    );
    $form->addInput($statsShow);

    $statsTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehStatsTitle',
        null,
        'فرزانه در یک نگاه',
        _t('آمار — عنوان بخش'),
        _t('عنوان بخش دستاوردها؛ مثلاً «فرزانه در یک نگاه».')
    );
    $form->addInput($statsTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $glanceStats = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'farzanehGlanceStats',
        null,
        "درصد قبولی کنکور | ۹۸٪ | trophy\nرتبه‌های زیر ۱۰۰۰ کشوری | ۴۵+ | award\nقبولی در رشته‌های موردعلاقه | ۱۲۰+ | heart\nسال تجربهٔ تدریس | ۱۵ | calendar-check",
        _t('آمار — فهرست دستاوردها'),
        _t('هر خط: «عنوان | مقدار | آیکون». مقدار متن آزاد است (مثل «۹۸٪» یا «۴۵+»)؛ اگر با عدد شروع شود با انیمیشن شمرده می‌شود. آیکون‌های موجود: trophy، award، heart، star، target، users، graduation-cap، trending-up، brain، lightbulb، zap، calendar-check، clipboard-check، school، atom و...'
        )
    );
    $form->addInput($glanceStats);

    /* ---------- بخش ۸: نظرات دانش‌آموزان و والدین ---------- */

    $testTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehTestTitle',
        null,
        'دانش‌آموزان و والدین چه می‌گویند؟',
        _t('نظرات — عنوان بخش'),
        _t('اگر خالی باشد، کل بخش نظرات از صفحهٔ اول حذف می‌شود.')
    );
    $form->addInput($testTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $testSubtitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehTestSubtitle',
        null,
        'تجربهٔ واقعی خانواده‌های فرزانه',
        _t('نظرات — توضیح'),
        _t('زیرعنوان بخش نظرات.')
    );
    $form->addInput($testSubtitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $testimonials = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'farzanehTestimonials',
        null,
        "امیرحسین محمدی | دانش‌آموز رشتهٔ تجربی | با برنامه‌ای که مشاوران فرزانه برام نوشتن، رتبهٔ ۴۰۰ کشوری رو گرفتم؛ تست‌زنی و جزوه‌های استادها بی‌نظیره. | | \nخانم شریفی | مادر دانش‌آموز پایهٔ نهم | از لحظه‌ای که بچه‌م به فرزانه اومد، هم نمره‌هاش بالا رفت هم اعتمادبه‌نفسش. کارنامهٔ هفتگی بهم خیلی کمک می‌کنه. | | \nنگار سلطانی | دانش‌آموز کنکور هنر | کلاس‌های کم‌جمعیت یعنی استاد واقعاً وقتی برای هر نفر داره. جلسات مشاورهٔ قبل کنکور رو نمی‌تونم فراموش کنم. | | ",
        _t('نظرات — فهرست'),
        _t('هر خط: «نام | نقش/عنوان (مثل: والدین، دانش‌آموز نهم) | متن | عکس (اختیاری)».')
    );
    $form->addInput($testimonials);

    /* ---------- بخش ۹: وبلاگ ---------- */

    $blogShow = new \Typecho\Widget\Helper\Form\Element\Radio(
        'farzanehBlogShow',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('بخش آخرین مقالات'),
        _t('نمایش آخرین مقالات آموزشی در صفحهٔ اول.')
    );
    $form->addInput($blogShow);

    $blogTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehBlogTitle',
        null,
        'مقالات آموزشی',
        _t('وبلاگ — عنوان بخش'),
        _t('عنوان بخش مقالات صفحهٔ اول.')
    );
    $form->addInput($blogTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $blogSubtitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehBlogSubtitle',
        null,
        'راهنمای درس‌خواندن، تست‌زنی و برنامه‌ریزی تحصیلی',
        _t('وبلاگ — توضیح'),
        _t('زیرعنوان بخش مقالات.')
    );
    $form->addInput($blogSubtitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $blogCount = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehBlogCount',
        null,
        '3',
        _t('وبلاگ — تعداد'),
        _t('تعداد مقالات نمایش‌داده‌شده در صفحهٔ اول (۱ تا ۱۲).')
    );
    $form->addInput($blogCount->addRule('xssCheck', _t('عدد وارد کنید')));

    $blogUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehBlogUrl',
        null,
        null,
        _t('آدرس فهرست مقالات'),
        _t('آدرس صفحهٔ فهرست وبلاگ (خالی = مسیر پیش‌فرض /blog/).')
    );
    $form->addInput($blogUrl->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    /* ---------- بخش ۱۰: پرسش‌های متداول ---------- */

    $faqShow = new \Typecho\Widget\Helper\Form\Element\Radio(
        'farzanehFaqShow',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('بخش پرسش‌های متداول'),
        _t('نمایش سوالات متداول در صفحهٔ اول.')
    );
    $form->addInput($faqShow);

    $faqTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehFaqTitle',
        null,
        'پرسش‌های متداول والدین و دانش‌آموزان',
        _t('پرسش‌ها — عنوان بخش'),
        _t('عنوان بخش سوالات متداول.')
    );
    $form->addInput($faqTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $faq = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'farzanehFaq',
        null,
        "چه‌طور برای فرزندم ثبت‌نام کنم؟ | از فرم «ثبت‌نام دوره» در همین صفحه درخواست بدهید؛ مشاوران ما در اولین فرصت تماس می‌گیرند و پس از سنجش سطح، ثبت‌نام نهایی انجام می‌شود.\nآیا کلاس آزمایشی دارید؟ | بله؛ اولین جلسهٔ همهٔ دوره‌ها به‌صورت آزمایشی و کاملاً رایگان برگزار می‌شود.\nهزینهٔ دوره‌ها چطور پرداخت می‌شود؟ | امکان پرداخت قسطی و یک‌جا وجود دارد؛ برای دوره‌های خاص، بورسیهٔ تخفیف نیز در نظر گرفته شده است.\nاگر از کلاس راضی نبودیم چه؟ | تا پایان جلسهٔ دوم امکان انصراف و عودت کامل شهریه وجود دارد.",
        _t('پرسش‌ها — فهرست'),
        _t('هر خط: «سوال | پاسخ».')
    );
    $form->addInput($faq);

    /* ---------- بخش ۱۱: ثبت‌نام دوره ---------- */

    $enrollTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehEnrollTitle',
        null,
        'ثبت‌نام دوره و دریافت مشاورهٔ رایگان',
        _t('ثبت‌نام — عنوان بخش'),
        _t('عنوان بخش فرم ثبت‌نام در صفحهٔ اول.')
    );
    $form->addInput($enrollTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $enrollSubtitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehEnrollSubtitle',
        null,
        'فرم را پر کنید؛ مشاوران آموزشی فرزانه برای سنجش سطح و تکمیل ثبت‌نام با شما تماس می‌گیرند',
        _t('ثبت‌نام — توضیح'),
        _t('زیرعنوان بخش ثبت‌نام.')
    );
    $form->addInput($enrollSubtitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $enrollCourses = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehEnrollCourses',
        null,
        null,
        _t('ثبت‌نام — گزینه‌های دوره (اختیاری)'),
        _t('گزینه‌های منوی «انتخاب دوره» با کاما جدا کنید (مثال: ریاضی نهم، فیزیک کنکور). خالی = به‌صورت خودکار از فهرست دوره‌های بالا ساخته می‌شود.')
    );
    $form->addInput($enrollCourses->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $enrollLevels = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehEnrollLevels',
        null,
        'نمی‌دانم، مبتدی, متوسط, پیشرفته',
        _t('ثبت‌نام — سطوح آموزشی'),
        _t('گزینه‌های منوی «سطح» با کاما.')
    );
    $form->addInput($enrollLevels->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $enrollGrades = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehEnrollGrades',
        null,
        'هفتم, هشتم, نهم, دهم, یازدهم, دوازدهم, فارغ‌التحصیل',
        _t('ثبت‌نام — پایه‌های تحصیلی'),
        _t('گزینه‌های منوی «پایهٔ تحصیلی» با کاما.')
    );
    $form->addInput($enrollGrades->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $enrollTimes = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehEnrollTimes',
        null,
        'صبح, ظهر, عصر, شب, فرقی ندارد',
        _t('ثبت‌نام — زمان‌های مناسب'),
        _t('گزینه‌های منوی «زمان مناسب کلاس» با کاما.')
    );
    $form->addInput($enrollTimes->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $enrollCid = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehEnrollCid',
        null,
        null,
        _t('شناسهٔ برگهٔ ذخیرهٔ درخواست‌ها (اختیاری)'),
        _t('اگر می‌خواهید درخواست‌های ثبت‌نام روی برگهٔ خاصی ذخیره شوند، شناسهٔ (cid) آن برگه را وارد کنید. خالی = برگهٔ سیستمی خودکار.')
    );
    $form->addInput($enrollCid->addRule('xssCheck', _t('عدد وارد کنید')));

    /* ---------- بخش ۱۲: اطلاعات تماس ---------- */

    $contactPhone = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehContactPhone',
        null,
        '۰۲۱-۸۸۷۷۶۶۵۵',
        _t('تماس — تلفن ثابت'),
        _t('شمارهٔ تلفن آموزشگاه.')
    );
    $form->addInput($contactPhone->addRule('xssCheck', _t('شمارهٔ معتبر وارد کنید')));

    $contactPhone2 = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehContactPhone2',
        null,
        '۰۹۱۲۳۴۵۶۷۸۹',
        _t('تماس — شمارهٔ همراه'),
        _t('شمارهٔ همراه پشتیبانی ثبت‌نام (واتس‌اپ/تلگرام).')
    );
    $form->addInput($contactPhone2->addRule('xssCheck', _t('شمارهٔ معتبر وارد کنید')));

    $contactEmail = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehContactEmail',
        null,
        'info@farzaneh-example.ir',
        _t('تماس — ایمیل'),
        _t('ایمیل آموزشگاه.')
    );
    $form->addInput($contactEmail->addRule('xssCheck', _t('ایمیل معتبر وارد کنید')));

    $contactAddress = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehContactAddress',
        null,
        'تهران، خیابان دانش، کوچهٔ فرزانگی، پلاک ۱۲',
        _t('تماس — آدرس'),
        _t('نشانی آموزشگاه.')
    );
    $form->addInput($contactAddress->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $contactHours = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'farzanehContactHours',
        null,
        "شنبه تا پنجشنبه: ۸ تا ۲۰\nجمعه: ۹ تا ۱۳ (فقط تلفنی)",
        _t('تماس — ساعت کاری'),
        _t('هر خط یک مورد.')
    );
    $form->addInput($contactHours);

    $mapEmbed = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehMapEmbed',
        null,
        null,
        _t('نقشه — کد iframe'),
        _t('کد iframe گوگل‌مپ یا نشان (خالی = بدون نقشه). فقط src آدرس iframe را وارد کنید.')
    );
    $form->addInput($mapEmbed->addRule('xssCheck', _t('کد معتبر وارد کنید')));

    /* ---------- بخش ۱۳: شبکه‌های اجتماعی ---------- */

    $socialInstagram = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehSocialInstagram',
        null,
        null,
        _t('اینستاگرام'),
        _t('آدرس کامل پروفایل (خالی = پنهان).')
    );
    $form->addInput($socialInstagram->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $socialTelegram = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehSocialTelegram',
        null,
        null,
        _t('تلگرام'),
        _t('آدرس کانال یا پروفایل (خالی = پنهان).')
    );
    $form->addInput($socialTelegram->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $socialWhatsapp = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehSocialWhatsapp',
        null,
        null,
        _t('واتس‌اپ'),
        _t('لینک تماس واتس‌اپ مثل https://wa.me/989123456789 (خالی = پنهان).')
    );
    $form->addInput($socialWhatsapp->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $socialYoutube = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehSocialYoutube',
        null,
        null,
        _t('آپارات/یوتیوب'),
        _t('آدرس کانال ویدیوهای آموزشی (خالی = پنهان).')
    );
    $form->addInput($socialYoutube->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    /* ---------- بخش ۱۴: فوتر ---------- */

    $footerText = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'farzanehFooterText',
        null,
        'آموزشگاه فرزانه — سال‌هاست کنار خانواده‌های ایرانی ایستاده‌ایم تا مسیر تحصیلی فرزندان شما روشن‌تر و مطمئن‌تر باشد. یادگیریِ عمیق، آینده‌ای روشن می‌سازد.',
        _t('فوتر — متن معرفی'),
        _t('متن کوتاه معرفی در ستون اول فوتر.')
    );
    $form->addInput($footerText);

    /* ---------- بخش ۱۵: تنظیمات نوشته‌ها ---------- */

    $defaultCover = new \Typecho\Widget\Helper\Form\Element\Text(
        'farzanehDefaultCover',
        null,
        null,
        _t('تصویر شاخص پیش‌فرض نوشته‌ها'),
        _t('آدرس تصویر پیش‌فرض برای نوشته‌های بدون تصویر (خالی = تصویر داخل پوسته).')
    );
    $form->addInput($defaultCover->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $showRelated = new \Typecho\Widget\Helper\Form\Element\Radio(
        'farzanehShowRelated',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('نوشته‌های مرتبط'),
        _t('نمایش نوشته‌های مرتبط در انتهای هر نوشته.')
    );
    $form->addInput($showRelated);

    $showAuthorBox = new \Typecho\Widget\Helper\Form\Element\Radio(
        'farzanehShowAuthorBox',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('جعبهٔ نویسنده'),
        _t('نمایش معرفی نویسنده در انتهای هر نوشته.')
    );
    $form->addInput($showAuthorBox);
}

/* ================================================================
 *  ۱۱) فیلدهای اختصاصی نوشته (قابل استفاده در پیشخوان)
 * ================================================================ */

function themeFields($layout)
{
    $thumb = new \Typecho\Widget\Helper\Form\Element\Text(
        'thumb',
        null,
        null,
        _t('تصویر شاخص'),
        _t('آدرس تصویر شاخص این نوشته (اختیاری؛ خالی = اولین تصویر متن).')
    );
    $layout->addItem($thumb->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $readingTime = new \Typecho\Widget\Helper\Form\Element\Text(
        'readingTime',
        null,
        null,
        _t('زمان مطالعه (دقیقه)'),
        _t('مدت زمان مطالعهٔ مطلب — به‌صورت بج روی کارت و صفحهٔ نوشته نمایش داده می‌شود. (اختیاری)')
    );
    $layout->addItem($readingTime->addRule('xssCheck', _t('عدد وارد کنید')));

    $grade = new \Typecho\Widget\Helper\Form\Element\Text(
        'grade',
        null,
        null,
        _t('پایهٔ تحصیلی مناسب'),
        _t('مثال: نهم، دهم، کنکور — به‌صورت بج روی کارت و صفحهٔ نوشته نمایش داده می‌شود. (اختیاری)')
    );
    $layout->addItem($grade->addRule('xssCheck', _t('متن معتبر وارد کنید')));
}

/* ================================================================
 *  ۱۲) رندر ریسه‌ای دیدگاه‌ها
 * ================================================================ */

function threadedComments($comments, $options)
{
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
    ?>
    <li id="li-<?php $comments->theId(); ?>" class="comment-item<?php
    if ($comments->levels > 0) {
        echo ' comment-child';
        $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
    } else {
        echo ' comment-parent';
    }
    $comments->alt(' comment-odd', ' comment-even');
    echo $commentClass;
    ?>">
        <div id="<?php $comments->theId(); ?>" class="comment-inner">
            <div class="comment-avatar" aria-hidden="true">
                <?php /* d=404: اگر گراواتار واقعی نباشد تصویر لود نمی‌شود و فقط آواتار الفبایی می‌ماند */ ?>
                <?php $comments->gravatar(96, '404', true); ?>
                <span class="comment-avatar-fallback"><?php echo htmlspecialchars(farzaneh_initial((string)$comments->author), ENT_QUOTES); ?></span>
            </div>
            <div class="comment-main">
                <div class="comment-meta">
                    <cite class="comment-author" itemprop="creator" itemscope itemtype="http://schema.org/Person">
                        <?php $comments->author(); ?>
                        <?php if ($comments->authorId && $comments->authorId == $comments->ownerId): ?>
                            <span class="comment-badge-owner"><?php _e('نویسنده'); ?></span>
                        <?php endif; ?>
                    </cite>
                    <span class="comment-time">
                        <?php echo farzaneh_icon('clock', 12); ?>
                        <a href="<?php $comments->permalink(); ?>" itemprop="url">
                            <time datetime="<?php echo farzaneh_iso_date((int)$comments->created); ?>" itemprop="commentTime"><?php echo farzaneh_jalali_date((int)$comments->created, 'j F Y'); ?></time>
                        </a>
                    </span>
                    <?php if ($comments->status == 'waiting'): ?>
                        <span class="comment-badge-waiting"><?php _e('در انتظار تأیید'); ?></span>
                    <?php endif; ?>
                    <span class="comment-reply">
                        <?php $comments->reply(_t('پاسخ')); ?>
                    </span>
                </div>
                <div class="comment-content" itemprop="commentText">
                    <?php $comments->content(); ?>
                </div>
            </div>
        </div>
        <?php if ($comments->children) { ?>
            <div class="comment-children">
                <?php $comments->threadedComments($options); ?>
            </div>
        <?php } ?>
    </li>
    <?php
}
