<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');
?>

<div class="container archive-wrap">
    <header class="archive-head">
        <span class="section-tag"><?php echo farzaneh_icon('file-text', 14); ?> وبلاگ</span>
        <h1 class="archive-title">
            <?php $this->archiveTitle([
                'category' => _t('دستهٔ %s'),
                'search'   => _t('نتایج جستجوی %s'),
                'tag'      => _t('برچسب %s'),
                'author'   => _t('نوشته‌های %s'),
                'date'     => _t('آرشیو %s'),
            ], '', ''); ?>
        </h1>
    </header>

    <?php if ($this->have()): ?>
    <div class="archive-grid">
        <?php while ($this->next()): ?>
        <article class="blog-card">
            <a href="<?php $this->permalink(); ?>" class="blog-card-link">
                <div class="blog-card-thumb">
                    <img src="<?php echo htmlspecialchars(farzaneh_thumbnail($this), ENT_QUOTES); ?>" alt="<?php echo farzaneh_fa_title($this); ?>" loading="lazy">
                    <?php
                    $farzanehArcReading = farzaneh_reading_time($this);
                    $farzanehArcGrade = farzaneh_grade($this);
                    ?>
                    <?php if ($farzanehArcReading !== ''): ?>
                    <span class="blog-card-badge"><?php echo farzaneh_icon('clock', 13); ?> <?php echo $farzanehArcReading; ?> دقیقه مطالعه</span>
                    <?php elseif ($farzanehArcGrade !== ''): ?>
                    <span class="blog-card-badge"><?php echo farzaneh_icon('graduation-cap', 13); ?> <?php echo htmlspecialchars($farzanehArcGrade, ENT_QUOTES); ?></span>
                    <?php endif; ?>
                </div>
                <div class="blog-card-body">
                    <div class="blog-card-meta">
                        <span><?php echo farzaneh_icon('calendar', 13); ?> <?php echo farzaneh_post_date($this, 'j F Y'); ?></span>
                        <?php if (farzaneh_opt('farzanehShowViews', '1') === '1'): ?>
                        <span><?php echo farzaneh_icon('eye', 13); ?> <?php echo farzaneh_num(farzaneh_views($this)); ?></span>
                        <?php endif; ?>
                    </div>
                    <h2 class="blog-card-title"><?php echo farzaneh_fa_title($this); ?></h2>
                    <p class="blog-card-excerpt"><?php echo toPersianNumbers(mb_substr(trim(strip_tags((string)$this->excerpt)), 0, 100, 'UTF-8') . '...'); ?></p>
                    <span class="blog-card-more">ادامه مطلب <?php echo farzaneh_icon('arrow-left', 14); ?></span>
                </div>
            </a>
        </article>
        <?php endwhile; ?>
    </div>

    <?php farzaneh_page_nav($this); ?>
    <?php else: ?>
    <div class="archive-empty">
        <?php echo farzaneh_icon('search', 44); ?>
        <p>چیزی برای نمایش پیدا نشد.</p>
        <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-ghost">بازگشت به خانه</a>
    </div>
    <?php endif; ?>
</div>

<?php $this->need('footer.php'); ?>
