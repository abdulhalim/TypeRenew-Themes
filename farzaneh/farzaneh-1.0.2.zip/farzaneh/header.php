<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="<?php $this->options->charset(); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php if ($this->options->favicon): ?>
    <link rel="icon" href="<?php $this->options->favicon(); ?>">
<?php endif; ?>
<title><?php $this->archiveTitle([
            'category' => _t('دستهٔ %s'),
            'search'   => _t('نتایج جستجوی %s'),
            'tag'      => _t('برچسب %s'),
            'author'   => _t('نوشته‌های %s')
        ], '', ' - '); ?><?php $this->options->title(); ?></title>
<?php
// ---------- توضیحات متا (فقط صفحهٔ اول) ----------
$farzanehMetaDesc = '';
try {
    if (farzaneh_is_front()) {
        $farzanehMetaDesc = trim((string)farzaneh_opt_raw('farzanehHeroSubtitle'));
        $farzanehMetaDesc = $farzanehMetaDesc !== '' ? trim(preg_replace('/\s+/', ' ', strip_tags(str_replace("\n", ' ', $farzanehMetaDesc)))) : '';
        if (mb_strlen($farzanehMetaDesc) > 160) {
            $farzanehMetaDesc = mb_substr($farzanehMetaDesc, 0, 157, 'UTF-8') . '...';
        }
    }
} catch (\Throwable $e) {
}
if ($farzanehMetaDesc !== ''):
?>
<meta name="description" content="<?php echo htmlspecialchars($farzanehMetaDesc, ENT_QUOTES); ?>">
<?php endif; ?>
<?php $this->header(); ?>

<?php
// ---------- رنگ‌های داینامیک ----------
$farzanehPrimary   = farzaneh_opt('farzanehPrimaryColor', '#4f46e5');
$farzanehSecondary = farzaneh_opt('farzanehSecondaryColor', '#312e81');
if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $farzanehPrimary)) { $farzanehPrimary = '#4f46e5'; }
if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $farzanehSecondary)) { $farzanehSecondary = '#312e81'; }
?>

<style>:root{--primary:<?php echo $farzanehPrimary; ?>;--secondary:<?php echo $farzanehSecondary; ?>;}</style>

<!-- ---------- استایل‌های اصلی (با نسخه برای جلوگیری از کش) ---------- -->
<link rel="stylesheet" href="<?php $this->options->themeUrl('css/style.css'); ?>?v=1.0.2">
<link rel="stylesheet" href="<?php $this->options->themeUrl('css/fonts.css'); ?>?v=1.0.0">
</head>
<body class="farzaneh-body farsi-digits">
<a href="#main" class="skip-link">رفتن به محتوای اصلی</a>

<?php
// ---------- داده‌های مشترک ----------
$farzanehInstituteName = farzaneh_opt('farzanehInstituteName', (string)$this->options->title);
$farzanehTagline    = farzaneh_opt('farzanehTagline', 'یادگیری، روشن کردن چراغ دانایی است');
$farzanehLogoUrl    = farzaneh_logo_url();
$farzanehPhone      = farzaneh_opt_raw('farzanehContactPhone');
$farzanehShowTopbar = farzaneh_opt('farzanehShowTopbar', '1') === '1';
$farzanehOnHome     = farzaneh_is_front();
$farzanehBlogUrl    = farzaneh_blog_url();
$farzanehIsBlogPage = in_array(farzaneh_route(), ['archive', 'archive_page'], true);
$farzanehSocial = [
    'instagram' => farzaneh_opt_raw('farzanehSocialInstagram'),
    'telegram'  => farzaneh_opt_raw('farzanehSocialTelegram'),
    'whatsapp'  => farzaneh_opt_raw('farzanehSocialWhatsapp'),
    'youtube'   => farzaneh_opt_raw('farzanehSocialYoutube'),
];
$farzanehHoursLine = trim((string)farzaneh_opt_raw('farzanehContactHours'));
$farzanehHoursLine = ($farzanehHoursLine !== '') ? trim(strtok($farzanehHoursLine, "\n")) : '';
?>

<!-- ---------- نوار بالای هدر ---------- -->
<?php if ($farzanehShowTopbar): ?>
<div class="topbar">
    <div class="container topbar-inner">
        <div class="topbar-item topbar-phone">
            <?php echo farzaneh_icon('phone', 15); ?>
            <?php if ($farzanehPhone !== null && trim($farzanehPhone) !== ''): ?>
                <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $farzanehPhone), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($farzanehPhone), ENT_QUOTES); ?></a>
            <?php endif; ?>
        </div>
        <?php if ($farzanehHoursLine !== ''): ?>
        <div class="topbar-item topbar-hours">
            <?php echo farzaneh_icon('clock', 15); ?>
            <span><?php echo htmlspecialchars(toPersianNumbers($farzanehHoursLine), ENT_QUOTES); ?></span>
        </div>
        <?php endif; ?>
        <div class="topbar-social">
            <?php foreach ($farzanehSocial as $farzanehNet => $farzanehUrl): if (trim((string)$farzanehUrl) !== ''): ?>
                <a href="<?php echo htmlspecialchars($farzanehUrl, ENT_QUOTES); ?>" target="_blank" rel="noopener" aria-label="<?php echo ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام', 'whatsapp' => 'واتس‌اپ', 'youtube' => 'آپارات/یوتیوب'][$farzanehNet]; ?>">
                    <?php echo farzaneh_icon($farzanehNet === 'telegram' ? 'send' : ($farzanehNet === 'whatsapp' ? 'message-circle' : $farzanehNet), 15); ?>
                </a>
            <?php endif; endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ---------- هدر اصلی ---------- -->
<header class="site-header<?php echo $farzanehShowTopbar ? '' : ' no-topbar'; ?>" id="siteHeader">
    <div class="container nav-container">

        <!-- بخش راست: لوگو -->
        <div class="nav-logo">
            <a href="<?php $this->options->siteUrl(); ?>" class="logo-link">
                <?php if ($farzanehLogoUrl !== ''): ?>
                    <img src="<?php echo htmlspecialchars($farzanehLogoUrl, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($farzanehInstituteName, ENT_QUOTES); ?>" class="logo-img">
                <?php else: ?>
                    <span class="logo-mark" aria-hidden="true"><?php echo farzaneh_icon('graduation-cap', 22); ?></span>
                <?php endif; ?>
                <span class="logo-text">
                    <span class="logo-main"><?php echo htmlspecialchars($farzanehInstituteName, ENT_QUOTES); ?></span>
                    <span class="logo-sub"><?php echo htmlspecialchars($farzanehTagline, ENT_QUOTES); ?></span>
                </span>
            </a>
        </div>

        <!-- بخش وسط: منوی اصلی -->
        <nav class="main-nav" aria-label="منوی اصلی">
            <ul class="nav-links">
                <li><a href="<?php $this->options->siteUrl(); ?>" <?php if ($farzanehOnHome): ?>class="active" aria-current="page"<?php endif; ?>><?php echo farzaneh_icon('home', 15); ?> خانه</a></li>
                <li><a href="<?php echo htmlspecialchars(farzaneh_link_url('#courses', $farzanehOnHome), ENT_QUOTES); ?>"><?php echo farzaneh_icon('book-open', 15); ?> دوره‌ها</a></li>
                <li><a href="<?php echo htmlspecialchars(farzaneh_link_url('#classes', $farzanehOnHome), ENT_QUOTES); ?>"><?php echo farzaneh_icon('calendar', 15); ?> کلاس‌ها</a></li>
                <li><a href="<?php echo htmlspecialchars(farzaneh_link_url('#team', $farzanehOnHome), ENT_QUOTES); ?>"><?php echo farzaneh_icon('users', 15); ?> اساتید</a></li>
                <li><a href="<?php echo htmlspecialchars($farzanehOnHome ? '#blog' : $farzanehBlogUrl, ENT_QUOTES); ?>" <?php if (!$farzanehOnHome && ($farzanehIsBlogPage || $this->is('archive') || $this->is('post'))): ?>class="active" aria-current="page"<?php endif; ?>><?php echo farzaneh_icon('file-text', 15); ?> مقالات</a></li>
                <?php
                // ---------- برگه‌های منو (برگه‌های سیستمی ثبت‌نام حذف می‌شوند) ----------
                $farzanehNavPages = \Widget\Contents\Page\Rows::alloc();
                $farzanehNavCount = 0;
                while ($farzanehNavPages->next()):
                    if (farzaneh_is_reserve_cid((int)$farzanehNavPages->cid)) { continue; }
                    $farzanehNavCount++;
                    if ($farzanehNavCount > 3) { break; } // حداکثر ۳ برگه در منو
                ?>
                    <li><a href="<?php $farzanehNavPages->permalink(); ?>" <?php if ($this->is('page', $farzanehNavPages->slug)): ?>class="active" aria-current="page"<?php endif; ?>><?php echo farzaneh_icon('file-text', 15); ?> <?php echo farzaneh_fa_title($farzanehNavPages); ?></a></li>
                <?php endwhile; ?>
                <li><a href="<?php echo htmlspecialchars(farzaneh_link_url('#contact', $farzanehOnHome), ENT_QUOTES); ?>"><?php echo farzaneh_icon('phone', 15); ?> تماس</a></li>
            </ul>
        </nav>

        <!-- بخش چپ: دکمهٔ ثبت‌نام -->
        <div class="nav-actions">
            <?php
            // بج مدیریت ثبت‌نام‌ها — همیشه برای مدیر/سردبیر نمایش داده می‌شود،
            // حتی اگر هنوز درخواستی ثبت نشده باشد (شمارنده ۰ است)
            $farzanehManageUrl = '';
            $farzanehPending = 0;
            if (farzaneh_can_manage_enrollments()) {
                $farzanehPending = farzaneh_pending_enrollments_count();
                $farzanehManageUrl = farzaneh_manage_url();
            }
            if ($farzanehManageUrl !== ''):
            ?>
            <a href="<?php echo htmlspecialchars($farzanehManageUrl, ENT_QUOTES); ?>" class="nav-enrollments-badge" title="مدیریت ثبت‌نام‌ها">
                <?php echo farzaneh_icon('clipboard-check', 15); ?>
                <span>ثبت‌نام‌ها</span>
                <span class="badge-count"><?php echo toPersianNumbers($farzanehPending); ?></span>
            </a>
            <?php endif; ?>
            <?php
            $farzanehCtaText = farzaneh_opt('farzanehHeroBtn1Text', 'ثبت‌نام دوره‌ها');
            $farzanehCtaUrl  = farzaneh_opt('farzanehHeroBtn1Url', '#enroll');
            if (trim($farzanehCtaText) !== '' && trim($farzanehCtaUrl) !== ''):
            ?>
            <a href="<?php echo htmlspecialchars(farzaneh_link_url($farzanehCtaUrl, $farzanehOnHome), ENT_QUOTES); ?>" class="nav-cta">
                <?php echo farzaneh_icon('graduation-cap', 16); ?>
                <span><?php echo htmlspecialchars($farzanehCtaText, ENT_QUOTES); ?></span>
            </a>
            <?php endif; ?>
            <button type="button" class="menu-toggle" id="menuToggle" aria-label="باز کردن منو" aria-expanded="false" aria-controls="mobileMenu">
                <?php echo farzaneh_icon('menu', 22); ?>
            </button>
        </div>
    </div>
</header>

<!-- ---------- منوی موبایل ---------- -->
<div class="mobile-menu" id="mobileMenu" aria-hidden="true">
    <div class="mobile-menu-head">
        <span class="logo-mark" aria-hidden="true"><?php echo farzaneh_icon('graduation-cap', 20); ?></span>
        <span class="mobile-menu-title"><?php echo htmlspecialchars($farzanehInstituteName, ENT_QUOTES); ?></span>
        <button type="button" class="mobile-menu-close" id="menuClose" aria-label="بستن منو">
            <?php echo farzaneh_icon('x', 20); ?>
        </button>
    </div>
    <nav class="mobile-nav" aria-label="منوی موبایل">
        <?php if ($farzanehManageUrl !== ''): ?>
        <a href="<?php echo htmlspecialchars($farzanehManageUrl, ENT_QUOTES); ?>" class="mobile-enrollments-badge">
            <?php echo farzaneh_icon('clipboard-check', 18); ?>
            مدیریت ثبت‌نام‌ها
            <span class="badge-count"><?php echo toPersianNumbers($farzanehPending); ?></span>
        </a>
        <?php endif; ?>
        <a href="<?php $this->options->siteUrl(); ?>" <?php if ($farzanehOnHome): ?>class="active" aria-current="page"<?php endif; ?>><?php echo farzaneh_icon('home', 18); ?> خانه</a>
        <a href="<?php echo htmlspecialchars(farzaneh_link_url('#courses', $farzanehOnHome), ENT_QUOTES); ?>" data-close><?php echo farzaneh_icon('book-open', 18); ?> دوره‌ها</a>
        <a href="<?php echo htmlspecialchars(farzaneh_link_url('#classes', $farzanehOnHome), ENT_QUOTES); ?>" data-close><?php echo farzaneh_icon('calendar', 18); ?> کلاس‌ها</a>
        <a href="<?php echo htmlspecialchars(farzaneh_link_url('#team', $farzanehOnHome), ENT_QUOTES); ?>" data-close><?php echo farzaneh_icon('users', 18); ?> اساتید</a>
        <a href="<?php echo htmlspecialchars(farzaneh_link_url('#stats', $farzanehOnHome), ENT_QUOTES); ?>" data-close><?php echo farzaneh_icon('trending-up', 18); ?> آمار آموزشگاه</a>
        <a href="<?php echo htmlspecialchars($farzanehOnHome ? '#blog' : $farzanehBlogUrl, ENT_QUOTES); ?>" data-close <?php if (!$farzanehOnHome && ($farzanehIsBlogPage || $this->is('archive') || $this->is('post'))): ?>class="active" aria-current="page"<?php endif; ?>><?php echo farzaneh_icon('file-text', 18); ?> مقالات</a>
        <?php
        $farzanehNavPagesM = \Widget\Contents\Page\Rows::allocWithAlias('farzanehMobile');
        while ($farzanehNavPagesM->next()):
            if (farzaneh_is_reserve_cid((int)$farzanehNavPagesM->cid)) { continue; }
        ?>
            <a href="<?php $farzanehNavPagesM->permalink(); ?>"><?php echo farzaneh_icon('file-text', 18); ?> <?php echo farzaneh_fa_title($farzanehNavPagesM); ?></a>
        <?php endwhile; ?>
        <a href="<?php echo htmlspecialchars(farzaneh_link_url('#contact', $farzanehOnHome), ENT_QUOTES); ?>" data-close class="nav-contact-link"><?php echo farzaneh_icon('phone', 18); ?> تماس با ما</a>
    </nav>
    <?php if (trim((string)$farzanehCtaUrl) !== '' && trim($farzanehCtaText) !== ''): ?>
    <a href="<?php echo htmlspecialchars(farzaneh_link_url($farzanehCtaUrl, $farzanehOnHome), ENT_QUOTES); ?>" class="mobile-cta">
        <?php echo farzaneh_icon('graduation-cap', 18); ?>
        <?php echo htmlspecialchars($farzanehCtaText, ENT_QUOTES); ?>
    </a>
    <?php endif; ?>
    <?php if ($farzanehPhone !== null && trim($farzanehPhone) !== ''): ?>
    <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $farzanehPhone), ENT_QUOTES); ?>" class="mobile-cta mobile-cta-phone">
        <?php echo farzaneh_icon('phone-call', 18); ?>
        <?php echo htmlspecialchars(toPersianNumbers($farzanehPhone), ENT_QUOTES); ?>
    </a>
    <?php endif; ?>
</div>
<div class="menu-overlay" id="menuOverlay" aria-hidden="true"></div>

<main id="main" class="site-main">
