<?php
/**
 * مدیریت ثبت‌نام‌های فرزانه — قالب سفارشی برگه
 *
 * نمایش و مدیریت درخواست‌های ثبت‌نام دوره (فقط برای اعضای واردشده با دسترسی مدیر/سردبیر).
 * درخواست‌ها روی برگهٔ «دفتر ثبت‌نام» به‌صورت دیدگاه ذخیره شده‌اند؛ این قالب
 * آن‌ها را به‌صورت ساختاریافته (مثل افزونهٔ Booking) نمایش می‌دهد و دکمه‌های
 * تأیید/رد/حذف دارد که با AJAX به نقطهٔ پایانی /farzaneh-register ارسال می‌شوند.
 *
 * @package custom
 * @author پوردریایی
 * @link https://pourdaryaei.ir
 * @version 1.0.0
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$farzanehManageOk = farzaneh_can_manage_enrollments();
$farzanehEnrollments = $farzanehManageOk ? farzaneh_enrollments_list() : [];
$farzanehStats = ['total' => 0, 'waiting' => 0, 'approved' => 0, 'spam' => 0];
foreach ($farzanehEnrollments as $farzanehE) {
    $farzanehStats['total']++;
    if (isset($farzanehStats[$farzanehE['status']])) {
        $farzanehStats[$farzanehE['status']]++;
    }
}

$farzanehStatusLabels = [
    'waiting'  => 'در انتظار بررسی',
    'approved' => 'تأیید شده',
    'spam'     => 'رد شده',
];
$farzanehStatusClasses = [
    'waiting'  => 'bkst-waiting',
    'approved' => 'bkst-approved',
    'spam'     => 'bkst-rejected',
];

$farzanehManageToken = '';
try {
    $farzanehManageToken = htmlspecialchars(
        \Widget\Security::alloc()->getToken($this->request->getRequestUrl()),
        ENT_QUOTES,
        'UTF-8'
    );
} catch (\Throwable $e) {
}

$farzanehManageEndpoint = farzaneh_enroll_endpoint();
?>

<article class="page-wrap container bk-manage">

    <header class="page-head">
        <nav class="post-breadcrumb" aria-label="مسیر">
            <a href="<?php $this->options->siteUrl(); ?>">خانه</a>
            <span class="crumb-sep">/</span>
            <span aria-current="page">مدیریت ثبت‌نام‌ها</span>
        </nav>
        <h1 class="page-title">
            <?php echo farzaneh_icon('graduation-cap', 22); ?>
            مدیریت ثبت‌نام‌ها
        </h1>
        <p class="bk-manage-sub">درخواست‌های ثبت‌نام دورهٔ ثبت‌شده از فرم سایت — جدیدترین در ابتدا؛ درخواست‌های در انتظار بررسی اولویت دارند.</p>
    </header>

    <?php if (!$farzanehManageOk): ?>
    <div class="bk-manage-notice" role="alert">
        <?php echo farzaneh_icon('lock', 22); ?>
        <div>
            <strong>ورود لازم است</strong>
            <span>برای مشاهده و مدیریت ثبت‌نام‌ها باید با حساب مدیر یا سردبیر وارد سایت شوید.</span>
            <a class="btn btn-primary btn-sm" href="<?php echo htmlspecialchars((string)$this->options->loginUrl, ENT_QUOTES); ?>">ورود به حساب</a>
        </div>
    </div>
    <?php else: ?>

    <div class="bk-manage-stats">
        <div class="bk-stat">
            <span class="bk-stat-num"><?php echo toPersianNumbers($farzanehStats['waiting']); ?></span>
            <span class="bk-stat-label">در انتظار بررسی</span>
        </div>
        <div class="bk-stat bk-stat-approved">
            <span class="bk-stat-num"><?php echo toPersianNumbers($farzanehStats['approved']); ?></span>
            <span class="bk-stat-label">تأیید شده</span>
        </div>
        <div class="bk-stat bk-stat-rejected">
            <span class="bk-stat-num"><?php echo toPersianNumbers($farzanehStats['spam']); ?></span>
            <span class="bk-stat-label">رد شده</span>
        </div>
        <div class="bk-stat bk-stat-total">
            <span class="bk-stat-num"><?php echo toPersianNumbers($farzanehStats['total']); ?></span>
            <span class="bk-stat-label">مجموع</span>
        </div>
    </div>

    <div class="bk-manage-list" id="bkManageList">
        <?php if (empty($farzanehEnrollments)): ?>
        <div class="bk-manage-empty">
            <?php echo farzaneh_icon('inbox', 40); ?>
            <p>هنوز درخواستی ثبت نشده است.</p>
            <p class="bk-manage-empty-sub">به‌محض ثبت اولین فرم ثبت‌نام، اینجا نمایش داده می‌شود.</p>
        </div>
        <?php else: ?>
        <?php foreach ($farzanehEnrollments as $farzanehE): ?>
        <?php
        $farzanehEPhone = trim((string)($farzanehE['phone'] !== '' ? $farzanehE['phone'] : $farzanehE['url']));
        $farzanehETel = preg_replace('/[^0-9+]/', '', $farzanehEPhone);
        ?>
        <div class="bk-card" data-coid="<?php echo (int)$farzanehE['coid']; ?>">
            <div class="bk-card-head">
                <span class="bk-status <?php echo $farzanehStatusClasses[$farzanehE['status']] ?? 'bkst-other'; ?>">
                    <?php echo htmlspecialchars($farzanehStatusLabels[$farzanehE['status']] ?? $farzanehE['status'], ENT_QUOTES); ?>
                </span>
                <span class="bk-card-date">
                    <?php echo farzaneh_icon('clock', 13); ?>
                    <?php echo farzaneh_jalali_date((int)$farzanehE['created'], 'j F Y — H:i'); ?>
                </span>
            </div>

            <div class="bk-card-body">
                <div class="bk-card-main">
                    <div class="bk-card-name">
                        <?php echo farzaneh_icon('user', 16); ?>
                        <strong><?php echo htmlspecialchars((string)$farzanehE['author'], ENT_QUOTES); ?></strong>
                    </div>
                    <?php if ($farzanehEPhone !== ''): ?>
                    <div class="bk-card-field">
                        <?php echo farzaneh_icon('phone', 15); ?>
                        <a href="tel:<?php echo htmlspecialchars($farzanehETel, ENT_QUOTES); ?>" dir="ltr"><?php echo htmlspecialchars(toPersianNumbers($farzanehEPhone), ENT_QUOTES); ?></a>
                    </div>
                    <?php endif; ?>
                    <?php if ($farzanehE['mail'] !== ''): ?>
                    <div class="bk-card-field">
                        <?php echo farzaneh_icon('mail', 15); ?>
                        <a href="mailto:<?php echo htmlspecialchars($farzanehE['mail'], ENT_QUOTES); ?>" dir="ltr"><?php echo htmlspecialchars($farzanehE['mail'], ENT_QUOTES); ?></a>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="bk-card-side">
                    <?php if ($farzanehE['course'] !== ''): ?>
                    <div class="bk-tag"><?php echo farzaneh_icon('book-open', 13); ?> <?php echo htmlspecialchars($farzanehE['course'], ENT_QUOTES); ?></div>
                    <?php endif; ?>
                    <?php if ($farzanehE['level'] !== ''): ?>
                    <div class="bk-tag"><?php echo farzaneh_icon('brain', 13); ?> سطح: <?php echo htmlspecialchars($farzanehE['level'], ENT_QUOTES); ?></div>
                    <?php endif; ?>
                    <?php if ($farzanehE['grade'] !== ''): ?>
                    <div class="bk-tag"><?php echo farzaneh_icon('graduation-cap', 13); ?> پایه: <?php echo htmlspecialchars($farzanehE['grade'], ENT_QUOTES); ?></div>
                    <?php endif; ?>
                    <?php if ($farzanehE['time'] !== ''): ?>
                    <div class="bk-tag"><?php echo farzaneh_icon('clock', 13); ?> زمان: <?php echo htmlspecialchars($farzanehE['time'], ENT_QUOTES); ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($farzanehE['note'] !== ''): ?>
            <div class="bk-card-note">
                <?php echo farzaneh_icon('message-square', 14); ?>
                <p><?php echo htmlspecialchars($farzanehE['note'], ENT_QUOTES); ?></p>
            </div>
            <?php endif; ?>

            <div class="bk-card-actions">
                <?php if ($farzanehE['status'] !== 'approved'): ?>
                <button type="button" class="bk-btn bk-btn-approve" data-mode="approve" data-coid="<?php echo (int)$farzanehE['coid']; ?>">
                    <?php echo farzaneh_icon('check', 14); ?> تأیید
                </button>
                <?php endif; ?>
                <?php if ($farzanehE['status'] !== 'spam'): ?>
                <button type="button" class="bk-btn bk-btn-reject" data-mode="reject" data-coid="<?php echo (int)$farzanehE['coid']; ?>">
                    <?php echo farzaneh_icon('x', 14); ?> رد
                </button>
                <?php endif; ?>
                <button type="button" class="bk-btn bk-btn-delete" data-mode="delete" data-coid="<?php echo (int)$farzanehE['coid']; ?>">
                    <?php echo farzaneh_icon('trash-2', 14); ?> حذف
                </button>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script>
    (function () {
        'use strict';
        var list = document.getElementById('bkManageList');
        if (!list) { return; }
        var endpoint = <?php echo json_encode($farzanehManageEndpoint, JSON_UNESCAPED_SLASHES); ?>;
        var token = <?php echo json_encode($farzanehManageToken); ?>;

        function setBusy(card, busy) {
            Array.prototype.forEach.call(card.querySelectorAll('.bk-btn'), function (b) {
                b.disabled = !!busy;
            });
        }

        list.addEventListener('click', function (e) {
            var btn = e.target.closest ? e.target.closest('.bk-btn') : null;
            if (!btn || btn.disabled) { return; }
            var card = btn.closest('.bk-card');
            if (!card) { return; }
            var coid = parseInt(btn.getAttribute('data-coid'), 10);
            var mode = btn.getAttribute('data-mode');
            if (!coid || !mode) { return; }

            if (mode === 'delete' && !window.confirm('این درخواست برای همیشه حذف شود؟')) { return; }

            setBusy(card, true);
            btn.classList.add('loading');

            var body = new URLSearchParams();
            body.append('farzanehEnroll', '1');
            body.append('mode', mode);
            body.append('coid', String(coid));
            if (token) { body.append('_', token); }

            fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' },
                body: body.toString(),
                credentials: 'same-origin'
            })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (data && data.ok) {
                        // ساده و مطمئن: بارگذاری مجدد صفحه
                        window.location.reload();
                    } else {
                        alert((data && data.error) ? data.error : 'خطا در به‌روزرسانی درخواست.');
                        setBusy(card, false);
                        btn.classList.remove('loading');
                    }
                })
                .catch(function () {
                    alert('خطای ارتباط با سرور؛ دوباره تلاش کنید.');
                    setBusy(card, false);
                    btn.classList.remove('loading');
                });
        });
    })();
    </script>
    <?php endif; ?>

</article>

<?php $this->need('footer.php'); ?>
