<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

if (! defined('AVA_VERSION')) {
    define('AVA_VERSION', '1.0.0');
}

/* منطقه زمانی پیش‌فرض */
if (! date_default_timezone_set('Asia/Tehran')) {
    date_default_timezone_set('UTC');
}

/* ============================================================
 * ۰) لایه سازگاری Typecho / TypeRenew
 * نام‌های فضایی مدرن با بازگشت به کلاس‌های قدیمی
 * ============================================================ */

if (! function_exists('ava_db')) {
    /** @return mixed نمونه دیتابیس یا null */
    function ava_db()
    {
        if (class_exists('\\Typecho\\Db')) {
            return \Typecho\Db::get();
        }
        if (class_exists('Typecho_Db')) {
            return Typecho_Db::get();
        }
        return null;
    }
}

if (! function_exists('ava_cookie_get')) {
    function ava_cookie_get($name, $default = '')
    {
        if (class_exists('\\Typecho\\Cookie')) {
            return \Typecho\Cookie::get($name, $default);
        }
        if (class_exists('Typecho_Cookie')) {
            return Typecho_Cookie::get($name, $default);
        }
        return $default;
    }
}

if (! function_exists('ava_cookie_set')) {
    function ava_cookie_set($name, $value, $expires = 0)
    {
        if (class_exists('\\Typecho\\Cookie')) {
            \Typecho\Cookie::set($name, $value, $expires);
        } elseif (class_exists('Typecho_Cookie')) {
            Typecho_Cookie::set($name, $value, $expires);
        }
    }
}

if (! function_exists('ava_widget')) {
    /** ساخت ویجت با نام؛ سازگار با هر دو نسل کلاس */
    function ava_widget($widget)
    {
        try {
            return \Typecho_Widget::widget($widget);
        } catch (Throwable $e) {
            return null;
        }
    }
}

/* ============================================================
 * ۱) خواندن تنظیمات پوسته
 * ============================================================ */

if (! function_exists('ava_opt')) {
    function ava_opt($name, $default = null)
    {
        try {
            $value = \Widget\Options::alloc()->{$name};
        } catch (Throwable $e) {
            $value = null;
        }
        return ($value === null || $value === '') ? $default : $value;
    }
}

if (! function_exists('ava_on')) {
    function ava_on($name, $default = '1')
    {
        return ((string) ava_opt($name, $default)) === '1';
    }
}

if (! function_exists('ava_e')) {
    /** خروجی امن HTML */
    function ava_e($text)
    {
        return htmlspecialchars((string) $text, ENT_QUOTES, 'UTF-8');
    }
}

if (! function_exists('ava_theme_url')) {
    /** نشانی پایه assetهای پوسته */
    function ava_theme_url($path = '')
    {
        try {
            $themeUrl = \Widget\Options::alloc()->themeUrl;
        } catch (Throwable $e) {
            $themeUrl = '';
        }
        return rtrim((string) $themeUrl, '/') . '/' . ltrim((string) $path, '/');
    }
}

if (! function_exists('ava_pages_list')) {
    /**
     * وهلهٔ تازه از فهرست برگه‌های مستقل سایت (قابل پیمایش مجدد)
     * سازگار با TypeRenew 1.6+ و Typecho 1.2+
     */
    function ava_pages_list()
    {
        /* روش ۱: کارخانهٔ ایستا با نام مستعار تازه (در پیشخوان و فرانت‌اند) */
        foreach (['\Typecho\Widget', 'Typecho_Widget'] as $cls) {
            try {
                if (class_exists($cls) && method_exists($cls, 'widget')) {
                    foreach (['Widget_Contents_Page_List@ava-pages-helper', '\Widget\Contents\Page\List@ava-pages-helper'] as $name) {
                        try {
                            $w = call_user_func([$cls, 'widget'], $name);
                            if ($w) {
                                return $w;
                            }
                        } catch (Throwable $e) {
                            // نام بعدی
                        }
                    }
                }
            } catch (Throwable $e) {
                // کلاس بعدی
            }
        }

        /* روش ۲: از طریق Widget_Archive (فقط فرانت‌اند) */
        try {
            if (class_exists('\Widget\Archive') || class_exists('Widget_Archive')) {
                $archive = class_exists('\Widget\Archive')
                    ? \Widget\Archive::alloc()
                    : Widget_Archive::alloc();
                if ($archive && method_exists($archive, 'widget')) {
                    $pages = $archive->widget('Widget_Contents_Page_List@ava-pages-helper');
                    if ($pages) {
                        return $pages;
                    }
                }
            }
        } catch (Throwable $e) {
            // نادیده بگیر
        }

        return null;
    }
}

if (! function_exists('ava_pages_index')) {
    /**
     * فهرست برگه‌های مستقل سایت به‌صورت آرایهٔ ساده (cid، نامک، عنوان، نشانی).
     * برخلاف وهلهٔ ویجت، این فهرست چند‌بار قابل پیمایش است و برای چند تنظیم
     * (دربارهٔ من، آرشیو کامل) به‌کار می‌رود.
     */
    function ava_pages_index()
    {
        static $rows = null;
        if (is_array($rows)) {
            return $rows;
        }
        $rows = [];

        try {
            $pages = null;
            foreach (['\Typecho\Widget', 'Typecho_Widget'] as $cls) {
                if (class_exists($cls) && method_exists($cls, 'widget')) {
                    try {
                        $pages = call_user_func([$cls, 'widget'], 'Widget_Contents_Page_List@ava-pages-index');
                        break;
                    } catch (Throwable $e) {
                        $pages = null;
                    }
                }
            }

            /* روش پشتیبان: از طریق Widget_Archive (فقط فرانت‌اند) */
            if (! $pages && (class_exists('\Widget\Archive') || class_exists('Widget_Archive'))) {
                try {
                    $archive = class_exists('\Widget\Archive')
                        ? \Widget\Archive::alloc()
                        : Widget_Archive::alloc();
                    if ($archive && method_exists($archive, 'widget')) {
                        $pages = $archive->widget('Widget_Contents_Page_List@ava-pages-index2');
                    }
                } catch (Throwable $e) {
                    $pages = null;
                }
            }

            if ($pages && $pages->have()) {
                while ($pages->next()) {
                    $rows[] = [
                        'cid'       => (int) $pages->cid,
                        'slug'      => (string) $pages->slug,
                        'title'     => (string) $pages->title,
                        'permalink' => (string) $pages->permalink,
                    ];
                }
            }
        } catch (Throwable $e) {
            $rows = [];
        }

        return $rows;
    }
}

if (! function_exists('ava_page_url_by_setting')) {
    /**
     * نشانی برگهٔ انتخاب‌شده در یک تنظیم پوسته (مقدار: cid عددی یا نامک).
     * بدون انتخاب، رشتهٔ خالی برمی‌گردد و دکمهٔ مربوط پنهان می‌شود.
     */
    function ava_page_url_by_setting($settingName)
    {
        static $cache = [];
        if (isset($cache[$settingName])) {
            return $cache[$settingName];
        }

        $cache[$settingName] = '';
        $selected = trim((string) ava_opt($settingName, ''));
        if ($selected === '' || $selected === 'none') {
            return '';
        }

        $selCid = ctype_digit($selected) ? (int) $selected : 0;

        foreach (ava_pages_index() as $page) {
            $matched = ($selCid > 0 && $page['cid'] === $selCid)
                || ($selCid === 0 && $page['slug'] === $selected);
            if ($matched) {
                $cache[$settingName] = $page['permalink'];
                break;
            }
        }

        return $cache[$settingName];
    }
}

if (! function_exists('ava_about_url')) {
    /** نشانی صفحهٔ «دربارهٔ من» — از تنظیم aboutPage */
    function ava_about_url()
    {
        return ava_page_url_by_setting('aboutPage');
    }
}

if (! function_exists('ava_archive_url')) {
    /** نشانی صفحهٔ «آرشیو کامل» — از تنظیم archivePage */
    function ava_archive_url()
    {
        return ava_page_url_by_setting('archivePage');
    }
}

/* ============================================================
 * ۲) ارقام فارسی و قالب‌بندی اعداد
 * ============================================================ */

if (! function_exists('ava_fa')) {
    /** تبدیل ارقام لاتین به فارسی */
    function ava_fa($text)
    {
        return strtr((string) $text, [
            '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
            '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
        ]);
    }
}

if (! function_exists('ava_en_num')) {
    /** تبدیل ارقام فارسی/عربی به لاتین */
    function ava_en_num($text)
    {
        return strtr((string) $text, [
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ]);
    }
}

if (! function_exists('ava_fa_html')) {
    /**
     * تبدیل ارقام به فارسی «فقط در متنِ HTML» — داخل تگ‌ها و صفت‌ها (نشانی‌ها،
     * datetime، onerror و…) هیچ تغییری نمی‌شود.
     * ریشهٔ خطای Router Exception: ava_fa روی کل HTML لیست دیدگاه‌ها نشانی
     * avatar-480.png را به avatar-۴۸۰.png (ارقام فارسی) تبدیل می‌کرد.
     */
    function ava_fa_html($html)
    {
        $html = (string) $html;
        if ($html === '' || strpos($html, '<') === false) {
            return ava_fa($html);
        }
        $parts = preg_split('/(<[^>]*>)/', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
        if (! is_array($parts) || count($parts) < 2) {
            return ava_fa($html);
        }
        $out = '';
        foreach ($parts as $i => $part) {
            /* اندیس‌های فرد = تگ‌ها (دست‌نخورده)، اندیس‌های زوج = متن‌ها (فارسی) */
            $out .= ($i % 2 === 1) ? $part : ava_fa($part);
        }
        return $out;
    }
}

if (! function_exists('ava_format_count')) {
    /** عدد با جداکننده هزارگان فارسی: 4849 → ۴٬۸۴۹ */
    function ava_format_count($num)
    {
        $num = max(0, (int) $num);
        return ava_fa(number_format($num, 0, '.', '٬'));
    }
}

if (! function_exists('ava_published_posts_count')) {
    /** شمارش نوشته‌های منتشرشده (اختیاری: فقط یک دسته) — برای شمارندهٔ صفحات سفارشی */
    function ava_published_posts_count($mid = 0)
    {
        $mid = (int) $mid;
        try {
            $db = ava_db();
            if (! $db) {
                return 0;
            }
            $select = $db->select(['COUNT(*)' => 'total'])
                ->from('table.contents')
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.status = ?', 'publish')
                ->where("table.contents.password IS NULL OR table.contents.password = ''");
            if ($mid > 0) {
                $select->join('table.relationships', 'table.relationships.cid = table.contents.cid')
                    ->where('table.relationships.mid = ?', $mid);
            }
            $row = $db->fetchObject($select);
            return (int) ($row->total ?? 0);
        } catch (Throwable $e) {
            return 0;
        }
    }
}

/* ============================================================
 * ۳) موتور تاریخ شمسی (جلالی) — الگوریتم استاندارد jdf
 * دقت تضمین‌شده برای سال‌های ۱۱۷۸ تا ۱۶۳۳ شمسی
 * ============================================================ */

if (! function_exists('ava_g2j')) {
    /** میلادی → جلالی؛ خروجی [سال، ماه، روز] */
    function ava_g2j($gy, $gm, $gd)
    {
        $gDaysInMonth = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

        $gy = (int) $gy;
        $gm = (int) $gm;
        $gd = (int) $gd;

        if ($gm < 1 || $gm > 12) {
            $gm = 1;
        }
        if ($gd < 1 || $gd > 31) {
            $gd = 1;
        }
        if ($gy < 1700 || $gy > 2400) {
            $gy = 2000;
        }

        $gy2 = ($gm > 2) ? ($gy + 1) : $gy;

        $days = 355666 + (365 * $gy)
            + intdiv($gy2 + 3, 4)
            - intdiv($gy2 + 99, 100)
            + intdiv($gy2 + 399, 400)
            + $gd
            + $gDaysInMonth[$gm - 1];

        $jy = -1595 + (33 * intdiv($days, 12053));
        $days %= 12053;

        $jy += 4 * intdiv($days, 1461);
        $days %= 1461;

        if ($days > 365) {
            $jy += intdiv($days - 1, 365);
            $days = ($days - 1) % 365;
        }

        if ($days < 186) {
            $jm = 1 + intdiv($days, 31);
            $jd = 1 + ($days % 31);
        } else {
            $jm = 7 + intdiv($days - 186, 30);
            $jd = 1 + (($days - 186) % 30);
        }

        return [$jy, $jm, $jd];
    }
}

if (! function_exists('ava_j_month_name')) {
    function ava_j_month_name($jm)
    {
        $names = [
            1 => 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
            'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
        ];
        $jm = (int) $jm;
        return $names[$jm] ?? '';
    }
}

if (! function_exists('ava_jdate')) {
    /**
     * تاریخ شمسی با ارقام فارسی
     * قالب‌ها: Y، m، d، n، F، M، Y/m/d، «j F Y»، H:i و ...
     */
    function ava_jdate($format, $timestamp = null)
    {
        if ($timestamp === null) {
            $timestamp = time();
        }
        $timestamp = (int) $timestamp;

        $gy = (int) date('Y', $timestamp);
        $gm = (int) date('n', $timestamp);
        $gd = (int) date('j', $timestamp);

        [$jy, $jm, $jd] = ava_g2j($gy, $gm, $gd);

        $out = (string) $format;
        $out = str_replace('F', ava_j_month_name($jm), $out);
        $out = str_replace('M', mb_substr(ava_j_month_name($jm), 0, 3, 'UTF-8'), $out);
        $out = str_replace('Y', (string) $jy, $out);
        $out = str_replace('y', substr((string) $jy, -2), $out);
        $out = str_replace('m', str_pad((string) $jm, 2, '0', STR_PAD_LEFT), $out);
        $out = str_replace('n', (string) $jm, $out);
        $out = str_replace('d', str_pad((string) $jd, 2, '0', STR_PAD_LEFT), $out);
        $out = str_replace('j', (string) $jd, $out);

        /* اجزای ساعت (بدون تغییر) */
        if (strpos($out, 'H') !== false || strpos($out, 'i') !== false || strpos($out, 's') !== false) {
            $out = str_replace(['H', 'i', 's'], [date('H', $timestamp), date('i', $timestamp), date('s', $timestamp)], $out);
        }

        return ava_fa($out);
    }
}

/* ============================================================
 * ۴) سیستم آمار بازدید نوشته‌ها
 * الگو: ستون views جدول contents (ساخت خودکار در نخستین استفاده)
 * ============================================================ */

if (! function_exists('ava_views_schema_ready')) {
    /**
     * اطمینان از وجود ستون views در جدول محتوا — یکپارچه‌سازی خودکار.
     * آمار احتمالی پوسته‌های دیگر (فیلد views در جدول fields) در نخستین
     * اجرا به ستون جدید منتقل می‌شود؛ نتیجه در طول درخواست کش می‌شود.
     */
    function ava_views_schema_ready()
    {
        static $ready = null;
        if ($ready !== null) {
            return $ready;
        }

        $ready = false;

        try {
            $db = ava_db();
            if (! $db) {
                return false;
            }

            $columnExists = false;
            try {
                $db->fetchRow($db->select('table.contents.views')->from('table.contents')->limit(1));
                $columnExists = true;
            } catch (Throwable $e) {
                $columnExists = false;
            }

            if (! $columnExists) {
                $prefix = $db->getPrefix();
                $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT DEFAULT 0');

                /* انتقال آمار احتمالی پوسته‌های دیگر (اختیاری) */
                try {
                    $db->query(
                        'UPDATE `' . $prefix . 'contents` SET views = COALESCE((SELECT SUM(f.int_value)'
                        . ' FROM `' . $prefix . 'fields` f WHERE f.cid = `' . $prefix
                        . 'contents`.cid AND f.name = \'views\' AND f.type = \'int\'), 0)'
                    );
                    $db->query('DELETE FROM `' . $prefix . 'fields` WHERE name = \'views\' AND type = \'int\'');
                } catch (Throwable $e) {
                    // انتقال آمار اختیاری است
                }
            }

            $ready = true;
        } catch (Throwable $e) {
            $ready = false;
        }

        return $ready;
    }
}

if (! function_exists('ava_get_views')) {
    /** تعداد بازدید نوشته از ستون views */
    function ava_get_views($widget)
    {
        try {
            return max(0, (int) $widget->views);
        } catch (Throwable $e) {
            return 0;
        }
    }
}

if (! function_exists('ava_count_view')) {
    /**
     * شمارش بازدید صفحات تکی — با قلاب beforeRender فراخوانی می‌شود.
     * اگر پلاگین مستقل ViewsCounter فعال باشد، شمارش تکراری نمی‌شود.
     */
    function ava_count_view($archive)
    {
        /* احترام به پلاگین شمارنده مستقل */
        try {
            $options = \Widget\Options::alloc();
            $activated = $options->plugins;
            if (is_array($activated) && isset($activated['activated']['ViewsCounter'])) {
                return;
            }
        } catch (Throwable $e) {
            // نادیده بگیر
        }

        /* شمارش بازدید کاربران واردشده اختیاری است */
        if (! ava_on('countLoggedInViews', '0')) {
            try {
                $user = null;
                if (class_exists('\\Widget\\User')) {
                    $user = \Widget\User::alloc();
                } elseif (class_exists('Widget_User')) {
                    $user = Widget_User::alloc();
                }
                if ($user && method_exists($user, 'hasLogin') && $user->hasLogin()) {
                    return;
                }
            } catch (Throwable $e) {
                // نادیده بگیر
            }
        }

        /* فقط صفحات تکی */
        try {
            if (! method_exists($archive, 'is') || ! $archive->is('single')) {
                return;
            }
        } catch (Throwable $e) {
            return;
        }

        try {
            $cid = (int) $archive->cid;
        } catch (Throwable $e) {
            $cid = 0;
        }
        if ($cid < 1) {
            return;
        }

        /* جلوگیری از شمارش بازدید مکرر با کوکی */
        $interval = (int) ava_opt('viewsInterval', '3600');
        if ($interval > 0) {
            $viewed    = (string) ava_cookie_get('avaViews', '');
            $viewedIds = ($viewed === '') ? [] : explode(',', $viewed);

            if (in_array((string) $cid, $viewedIds, true)) {
                return;
            }

            $viewedIds[] = (string) $cid;
            if (count($viewedIds) > 100) {
                $viewedIds = array_slice($viewedIds, -100);
            }

            ava_cookie_set('avaViews', implode(',', $viewedIds), time() + $interval);
        }

        if (! ava_views_schema_ready()) {
            return;
        }

        try {
            $db = ava_db();
            $db->query(
                $db->update('table.contents')
                    ->expression('views', 'views + 1')
                    ->where('cid = ?', $cid)
            );
        } catch (Throwable $e) {
            // خطا نباید نمایش صفحه را متوقف کند
        }
    }
}

/* ============================================================
 * ۵) سیستم لایک (پسند) — ستون likes + نقطه پایانی AJAX
 * ============================================================ */

if (! function_exists('ava_likes_schema_ready')) {
    /** اطمینان از وجود ستون likes در جدول محتوا */
    function ava_likes_schema_ready()
    {
        static $ready = null;
        if ($ready !== null) {
            return $ready;
        }

        $ready = false;

        try {
            $db = ava_db();
            if (! $db) {
                return false;
            }

            $columnExists = false;
            try {
                $db->fetchRow($db->select('table.contents.likes')->from('table.contents')->limit(1));
                $columnExists = true;
            } catch (Throwable $e) {
                $columnExists = false;
            }

            if (! $columnExists) {
                $prefix = $db->getPrefix();
                $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `likes` INT DEFAULT 0');
            }

            $ready = true;
        } catch (Throwable $e) {
            $ready = false;
        }

        return $ready;
    }
}

if (! function_exists('ava_likes')) {
    /** تعداد پسند نوشته */
    function ava_likes($widget)
    {
        try {
            return max(0, (int) $widget->likes);
        } catch (Throwable $e) {
            return 0;
        }
    }
}

if (! function_exists('ava_user_likes')) {
    /** شناسه‌های پسندیده‌شدهٔ این بازدیدکننده (کوکی avaLikes) */
    function ava_user_likes()
    {
        $raw = (string) ava_cookie_get('avaLikes', '');
        if ($raw === '') {
            return [];
        }

        $ids = [];
        foreach (explode(',', $raw) as $id) {
            $id = trim($id);
            if ($id !== '' && ctype_digit($id) && ! in_array($id, $ids, true)) {
                $ids[] = $id;
            }
        }
        return $ids;
    }
}

if (! function_exists('ava_is_liked')) {
    function ava_is_liked($cid)
    {
        $cid = (int) $cid;
        return $cid > 0 && in_array((string) $cid, ava_user_likes(), true);
    }
}

if (! function_exists('ava_json_exit')) {
    /** خروجی JSON و پایان درخواست */
    function ava_json_exit($payload, $status = 200)
    {
        if (! headers_sent()) {
            http_response_code($status);
            header('Content-Type: application/json; charset=UTF-8', true);
        }
        echo json_encode($payload, JSON_UNESCAPED_UNICODE);
        exit;
    }
}

if (! function_exists('ava_handle_like')) {
    /**
     * پردازش درخواست پسند — POST با پارامتر avaLike=<cid>
     * پاسخ: {"ok":true,"likes":N,"liked":bool}
     */
    function ava_handle_like($request)
    {
        $cid = (int) (string) $request->get('avaLike');

        if ($cid < 1) {
            ava_json_exit(['ok' => false, 'error' => 'bad-request'], 400);
        }

        /* جلوگیری ساده از CSRF با بررسی مبدا */
        try {
            $siteHost = (string) parse_url((string) \Widget\Options::alloc()->siteUrl, PHP_URL_HOST);
        } catch (Throwable $e) {
            $siteHost = '';
        }
        $referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');
        if ($referer !== '' && $siteHost !== '' && stripos($referer, $siteHost) === false) {
            ava_json_exit(['ok' => false, 'error' => 'cross-origin'], 403);
        }

        if (! ava_likes_schema_ready()) {
            ava_json_exit(['ok' => false, 'error' => 'db-error'], 500);
        }

        try {
            $db = ava_db();
            $row = $db->fetchRow(
                $db->select('table.contents.type', 'table.contents.status', 'table.contents.password', 'table.contents.created')
                    ->from('table.contents')
                    ->where('table.contents.cid = ?', $cid)
            );

            $valid = is_array($row)
                && $row['status'] === 'publish'
                && in_array($row['type'], ['post', 'page'], true)
                && empty($row['password'])
                && (int) $row['created'] <= \Widget\Options::alloc()->time;

            if (! $valid) {
                ava_json_exit(['ok' => false, 'error' => 'not-found'], 404);
            }

            $likedIds = ava_user_likes();
            $wasLiked = in_array((string) $cid, $likedIds, true);

            if ($wasLiked) {
                $likedIds = array_values(array_filter(
                    $likedIds,
                    static function ($id) use ($cid) {
                        return $id !== (string) $cid;
                    }
                ));
                $delta = -1;
            } else {
                $likedIds[] = (string) $cid;
                $delta = 1;
            }

            if (count($likedIds) > 200) {
                $likedIds = array_slice($likedIds, -200);
            }
            ava_cookie_set('avaLikes', implode(',', $likedIds), time() + 31536000);

            $current = (int) $db->fetchObject(
                $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
            )->likes;

            if ($delta > 0 || $current > 0) {
                $db->query(
                    $db->update('table.contents')
                        ->expression('likes', $delta > 0 ? 'likes + 1' : 'likes - 1')
                        ->where('table.contents.cid = ?', $cid)
                );
            }

            $newLikes = (int) $db->fetchObject(
                $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
            )->likes;

            ava_json_exit([
                'ok'    => true,
                'likes' => max(0, $newLikes),
                'liked' => ! $wasLiked,
            ]);
        } catch (Throwable $e) {
            ava_json_exit(['ok' => false, 'error' => 'server-error'], 500);
        }
    }
}

/* ============================================================
 * ۶) راه‌انداز پوسته — قلاب شمارش بازدید + نقطه پایانی لایک
 * ============================================================ */

if (! function_exists('themeInit')) {
    function themeInit($archive)
    {
        /* شمارنده بازدید صفحات تکی */
        try {
            \Typecho\Plugin::factory('Widget\Archive')->beforeRender = 'ava_count_view';
        } catch (Throwable $e) {
            try {
                Typecho_Plugin::factory('Widget_Archive')->beforeRender = 'ava_count_view';
            } catch (Throwable $e2) {
                // نادیده بگیر
            }
        }

        /* نقطه پایانی AJAX پسند */
        try {
            if ($archive->request->isPost() && $archive->request->is('avaLike')) {
                ava_handle_like($archive->request);
            }
        } catch (Throwable $e) {
            // نادیده بگیر
        }
    }
}

/* ============================================================
 * ۷) آمار کلی سایت (نوشته، بازدید، لایک، دسته/برچسب)
 * ============================================================ */

if (! function_exists('ava_stats')) {
    function ava_stats()
    {
        $stats = [
            'posts'      => 0,
            'views'      => 0,
            'likes'      => 0,
            'comments'   => 0,
            'categories' => 0,
            'tags'       => 0,
        ];

        try {
            $db = ava_db();
            if (! $db) {
                return $stats;
            }

            $stats['posts'] = (int) $db->fetchObject(
                $db->select(['COUNT(table.contents.cid)' => 'num'])
                    ->from('table.contents')
                    ->where('table.contents.type = ?', 'post')
                    ->where('table.contents.status = ?', 'publish')
            )->num;

            if (ava_views_schema_ready()) {
                $stats['views'] = (int) $db->fetchObject(
                    $db->select(['COALESCE(SUM(table.contents.views), 0)' => 'total'])
                        ->from('table.contents')
                        ->where('table.contents.type = ?', 'post')
                        ->where('table.contents.status = ?', 'publish')
                )->total;
            }

            if (ava_likes_schema_ready()) {
                $stats['likes'] = (int) $db->fetchObject(
                    $db->select(['COALESCE(SUM(table.contents.likes), 0)' => 'total'])
                        ->from('table.contents')
                        ->where('table.contents.type = ?', 'post')
                        ->where('table.contents.status = ?', 'publish')
                )->total;
            }

            $stats['comments'] = (int) $db->fetchObject(
                $db->select(['COUNT(table.comments.coid)' => 'num'])
                    ->from('table.comments')
                    ->where('table.comments.status = ?', 'approved')
                    ->where('table.comments.type = ?', 'comment')
            )->num;

            $stats['categories'] = (int) $db->fetchObject(
                $db->select(['COUNT(table.metas.mid)' => 'num'])
                    ->from('table.metas')
                    ->where('table.metas.type = ?', 'category')
            )->num;

            $stats['tags'] = (int) $db->fetchObject(
                $db->select(['COUNT(table.metas.mid)' => 'num'])
                    ->from('table.metas')
                    ->where('table.metas.type = ?', 'tag')
            )->num;
        } catch (Throwable $e) {
            // آمار نباید سایت را متوقف کند
        }

        return $stats;
    }
}

/* ============================================================
 * ۸) کتابخانه آیکون‌های Lucide (SVG اینلاین)
 * ============================================================ */

if (! function_exists('ava_icon')) {
    /**
     * آیکون Lucide به‌صورت SVG اینلاین
     * مسیرها از کتابخانه Lucide (پروانه ISC) برداشته شده‌اند.
     */
    function ava_icon($name, $size = 18)
    {
        $paths = [
            'home'       => '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline>',
            'user'       => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle>',
            'users'      => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path>',
            'search'     => '<circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line>',
            'menu'       => '<line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line>',
            'x'          => '<line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>',
            'sun'        => '<circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>',
            'moon'       => '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>',
            'heart'      => '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>',
            'eye'        => '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle>',
            'comment'    => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>',
            'calendar'   => '<rect x="3" y="4" width="18" height="18" rx="2.5"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line>',
            'clock'      => '<circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline>',
            'tag'        => '<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line>',
            'folder'     => '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>',
            'file-text'  => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line>',
            'book-open'  => '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>',
            'sparkles'   => '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"></path><path d="M19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9z"></path>',
            'star'       => '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>',
            'download'   => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line>',
            'arrow-left' => '<line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline>',
            'arrow-right'=> '<line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline>',
            'arrow-up'   => '<line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline>',
            'chevron-left'  => '<polyline points="15 18 9 12 15 6"></polyline>',
            'chevron-right' => '<polyline points="9 18 15 12 9 6"></polyline>',
            'mail'       => '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline>',
            'share'      => '<circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>',
            'link'       => '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>',
            'image'      => '<rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline>',
            'camera'     => '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle>',
            'trending'   => '<polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline>',
            'pen'        => '<path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>',
            'coffee'     => '<path d="M18 8h1a4 4 0 0 1 0 8h-1"></path><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path><line x1="6" y1="1" x2="6" y2="4"></line><line x1="10" y1="1" x2="10" y2="4"></line><line x1="14" y1="1" x2="14" y2="4"></line>',
            'map-pin'    => '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle>',
            'send'       => '<line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>',
            'rss'        => '<path d="M4 11a9 9 0 0 1 9 9"></path><path d="M4 4a16 16 0 0 1 16 16"></path><circle cx="5" cy="19" r="1"></circle>',
            'github'     => '<path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path>',
            'instagram'  => '<rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>',
            'twitter'    => '<path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path>',
            'linkedin'   => '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4V8h4v1.5A6 6 0 0 1 16 8z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle>',
            'telegram'   => '<path d="M22 2L11 13"></path><path d="M22 2l-7 20-4-9-9-4 20-7z"></path>',
            'message'    => '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>',
            'check'      => '<polyline points="20 6 9 17 4 12"></polyline>',
            'alert'      => '<circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line>',
            'zap'        => '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>',
            'award'      => '<circle cx="12" cy="8" r="7"></circle><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"></polyline>',
            'briefcase'  => '<rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>',
            'edit'       => '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>',
            'archive'    => '<rect x="2" y="3" width="20" height="5" rx="1"></rect><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"></path><path d="M10 12h4"></path>',
            'layout-grid'=> '<rect x="3" y="3" width="7" height="7" rx="1"></rect><rect x="14" y="3" width="7" height="7" rx="1"></rect><rect x="14" y="14" width="7" height="7" rx="1"></rect><rect x="3" y="14" width="7" height="7" rx="1"></rect>',
            /* آیکون‌های عمومی (دسته‌بندی، برچسب، متا) */
            'code'       => '<polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline>',
            'pen-tool'   => '<path d="M12 19l7-7 3 3-7 7-3-3z"></path><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path><path d="M2 2l7.586 7.586"></path><circle cx="11" cy="11" r="2"></circle>',
            'terminal'   => '<polyline points="4 17 10 11 4 5"></polyline><line x1="12" y1="19" x2="20" y2="19"></line>',
            'cpu'        => '<rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line>',
            'globe'      => '<circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>',
            'music'      => '<path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle>',
            'video'      => '<polygon points="23 7 16 12 23 17 23 7"></polygon><rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>',
            'mic'        => '<path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line>',
            'smartphone' => '<rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line>',
            'wrench'     => '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>',
            'layers'     => '<polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline>',
            'bar-chart'  => '<line x1="12" y1="20" x2="12" y2="10"></line><line x1="18" y1="20" x2="18" y2="4"></line><line x1="6" y1="20" x2="6" y2="16"></line>',
            'box'        => '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line>',
            'graduation-cap' => '<path d="M22 10v6M2 10l10-5 10 5-10 5z"></path><path d="M6 12v5c3 3 9 3 12 0v-5"></path>',
            'laptop'     => '<rect x="2" y="4" width="20" height="14" rx="2" ry="2"></rect><line x1="2" y1="20" x2="22" y2="20"></line>',
            'languages'  => '<path d="M5 8l6 6"></path><path d="M4 14l6-6 2-3"></path><path d="M2 5h12"></path><path d="M7 2h1"></path><path d="M22 22l-5-10-5 10"></path><path d="M14 18h6"></path>',
        ];

        $path = $paths[$name] ?? $paths['sparkles'];

        return '<svg width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
    }
}

if (! function_exists('ava_social_icon')) {
    /** آیکون‌های برند که به fill نیاز دارند */
    function ava_social_icon($name, $size = 18)
    {
        $brand = [
            'telegram' => '<path d="M21.9 4.6l-3.1 14.7c-.2 1-.8 1.3-1.7.8l-4.7-3.5-2.3 2.2c-.25.25-.47.47-.94.47l.33-4.8L18.2 6.6c.37-.33-.08-.52-.58-.19L6.9 13.7l-4.6-1.44c-1-.31-1-1 .21-1.48L20.6 3.1c.83-.3 1.56.2 1.3 1.5z" fill="currentColor" stroke="none"></path>',
            'github'   => '<path d="M12 .5A11.5 11.5 0 0 0 .5 12a11.5 11.5 0 0 0 7.86 10.91c.58.11.79-.25.79-.56v-2.17c-3.2.7-3.87-1.36-3.87-1.36-.53-1.34-1.28-1.7-1.28-1.7-1.05-.72.08-.7.08-.7 1.16.08 1.77 1.19 1.77 1.19 1.03 1.77 2.7 1.26 3.36.96.1-.75.4-1.26.73-1.55-2.55-.29-5.23-1.28-5.23-5.68 0-1.26.45-2.28 1.19-3.09-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.17 1.18a11 11 0 0 1 5.77 0c2.2-1.49 3.16-1.18 3.16-1.18.63 1.59.24 2.76.12 3.05.74.81 1.18 1.83 1.18 3.09 0 4.41-2.68 5.38-5.24 5.67.41.35.78 1.05.78 2.11v3.13c0 .31.2.68.8.56A11.5 11.5 0 0 0 23.5 12 11.5 11.5 0 0 0 12 .5z" fill="currentColor" stroke="none"></path>',
            'linkedin' => '<path d="M4.98 3.5C4.98 4.88 3.87 6 2.5 6S0 4.88 0 3.5 1.12 1 2.5 1s2.48 1.12 2.48 2.5zM.22 8.1h4.56V23H.22V8.1zM8.34 8.1h4.37v2.03h.06c.61-1.15 2.1-2.37 4.32-2.37 4.62 0 5.47 3.04 5.47 7v8.24h-4.55v-7.3c0-1.74-.03-3.98-2.43-3.98-2.43 0-2.8 1.9-2.8 3.85V23H8.34V8.1z" fill="currentColor" stroke="none"></path>',
        ];

        if (isset($brand[$name])) {
            return '<svg width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $brand[$name] . '</svg>';
        }

        return ava_icon($name, $size);
    }
}

/* ============================================================
 * ۹) آواتار — تنظیم پوسته ← آواتار پیش‌فرض ← گراواتار ← حرف آغازین
 * ============================================================ */

if (! function_exists('ava_image_ok')) {
    /**
     * نشانی معتبر تصویر: کامل (http/https)، ریشه‌ای (/path) یا نسبی با پسوند تصویر
     * (نشانی‌های نسبی مانند img/pic.jpg یا ../Ava/… هم پذیرفته می‌شوند)
     */
    function ava_image_ok($url)
    {
        $url = trim((string) $url);
        if ($url === '') {
            return false;
        }
        if (preg_match('#^(https?:)?//#i', $url) || $url[0] === '/' || $url[0] === '.') {
            return true;
        }
        /* مسیر نسبی بدون اسلش آغازین — فقط اگر پسوند تصویر داشته باشد */
        return (bool) preg_match('#^[\w\-./%~=!]+\.(png|jpe?g|gif|webp|avif|svg|bmp)([?\#].*)?$#iu', $url);
    }
}

if (! function_exists('ava_resolve_url')) {
    /** تبدیل مسیر نسبی به نشانی کامل (ارقام فارسی/عربی به لاتین) */
    function ava_resolve_url($url)
    {
        $url = trim((string) $url);
        if ($url === '') {
            return '';
        }
        /* ارقام فارسی/عربی در نشانی‌ها به لاتین تبدیل می‌شوند
           (خطای رایج صفحه‌کلید فارسی: avatar-۴۸۰.png ← avatar-480.png) */
        $url = ava_en_num($url);
        if (preg_match('#^(https?:)?//#i', $url)) {
            return $url;
        }
        try {
            $site = \Widget\Options::alloc()->siteUrl;
        } catch (Throwable $e) {
            $site = '';
        }
        return rtrim((string) $site, '/') . '/' . ltrim($url, '/');
    }
}

if (! function_exists('ava_avatar_tone')) {
    /** شاخص رنگ پایدار برای آواتار حرف‌آغازین (۱ تا ۷) بر پایهٔ نام */
    function ava_avatar_tone($name)
    {
        $hash = abs(crc32(mb_strtolower(trim((string) $name), 'UTF-8')));
        return ($hash % 7) + 1;
    }
}

if (! function_exists('ava_site_logo_url')) {
    /**
     * لوگوی تصویری سایت — از تنظیم siteLogo.
     * نشانی نسبی به کامل تبدیل می‌شود و ارقام فارسی/عربی به لاتین؛
     * در صورت خالی‌بودن یا نامعتبربودن، رشتهٔ خالی برمی‌گردد (نشان پیش‌فرض نمایش داده می‌شود).
     */
    function ava_site_logo_url()
    {
        $logo = ava_en_num(trim((string) ava_opt('siteLogo', '')));
        if ($logo === '' || ! ava_image_ok($logo)) {
            return '';
        }
        return ava_resolve_url($logo);
    }
}

if (! function_exists('ava_gravatar_url')) {
    /**
     * نشانی گراواتار برای ایمیل دیدگاه — با d=404 (فقط اگر کاربر واقعاً
     * گراواتار داشته باشد تصویر برمی‌گردد؛ در غیر این صورت ۴۰۴ می‌گیرد و
     * پیش‌فرض سیستم باقی می‌ماند). ایمیل نامعتبر/خالی ← رشتهٔ خالی.
     */
    function ava_gravatar_url($email, $size = 84)
    {
        $email = trim((string) $email);
        if ($email === '' || ! filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return '';
        }
        $hash = md5(mb_strtolower($email, 'UTF-8'));
        return 'https://www.gravatar.com/avatar/' . $hash . '?s=' . max(16, (int) $size) . '&d=404&r=g';
    }
}

if (! function_exists('ava_avatar_html')) {
    /**
     * آواتار با اندازهٔ دلخواه — تصویر یا حرف آغازین رنگی (محلی).
     * اگر تصویر به هر دلیلی بارگذاری نشود (نشانی اشتباه/شکسته)،
     * به‌طور خودکار حرف آغازین رنگی جایگزین می‌شود — بدون خطای صفحه.
     */
    function ava_avatar_html($name, $url, $size = 44, $class = 'author-avatar', $gravatar = '')
    {
        $url      = ava_en_num(trim((string) $url));
        $name     = trim((string) $name);
        $gravatar = trim((string) $gravatar);
        /* نشانی گراواتار معتبر → در data-gravatar می‌نشیند تا اسکریپت پوسته در صورت
           دسترسی موفق، تصویر گراواتار را جایگزین پیش‌فرض سیستم کند */
        $gAttr    = ($gravatar !== '' && preg_match('#^https?://#i', $gravatar))
            ? ' data-gravatar="' . ava_e($gravatar) . '"'
            : '';
        $initial = mb_substr($name !== '' ? $name : '؟', 0, 1, 'UTF-8');

        if (ava_image_ok($url)) {
            $resolved = ava_resolve_url($url);
            /* پشتیبان پنهان: در onerror تصویر پنهان و حرف آغازین نمایان می‌شود */
            return '<img class="' . ava_e($class) . '" src="' . ava_e($resolved) . '" alt="' . ava_e($name)
                . '" width="' . (int) $size . '" height="' . (int) $size . '" loading="lazy" decoding="async"'
                . ' onerror="this.style.display=&#39;none&#39;;var f=this.nextElementSibling;if(f){f.style.display=&#39;&#39;;}">'
                . '<span class="' . ava_e($class) . ' avatar-fallback tone-' . ava_avatar_tone($name)
                . '" style="width:' . (int) $size . 'px;height:' . (int) $size . 'px;display:none"' . $gAttr . '>'
                . ava_e($initial) . '</span>';
        }

        return '<span class="' . ava_e($class) . ' avatar-fallback tone-' . ava_avatar_tone($name)
            . '" style="width:' . (int) $size . 'px;height:' . (int) $size . 'px"' . $gAttr . '>' . ava_e($initial) . '</span>';
    }
}

if (! function_exists('ava_default_avatar_url')) {
    /** آواتار پیش‌فرض بستهٔ پوسته */
    function ava_default_avatar_url()
    {
        return ava_theme_url('images/avatar-480.png');
    }
}

if (! function_exists('ava_comment_avatar_url')) {
    /**
     * آواتار محلی برای دیدگاه‌ها (فهرست دیدگاه‌ها + آخرین دیدگاه‌های سایدبار):
     * تنظیم «نشانی آواتار نویسنده» ← آواتار بستهٔ پوسته — بدون گراواتار.
     */
    function ava_comment_avatar_url()
    {
        /* ارقام فارسی/عربی نشانی به لاتین تبدیل می‌شوند (خطای رایج صفحه‌کلید فارسی) */
        $custom = ava_en_num(trim((string) ava_opt('authorAvatar', '')));
        if (ava_image_ok($custom)) {
            return ava_resolve_url($custom);
        }
        return ava_default_avatar_url();
    }
}

if (! function_exists('ava_author_avatar_url')) {
    /** آواتار نویسنده: تنظیم ← پیش‌فرض پوسته */
    function ava_author_avatar_url($author = null)
    {
        /* ارقام فارسی/عربی نشانی به لاتین تبدیل می‌شوند (خطای رایج صفحه‌کلید فارسی) */
        $custom = ava_en_num(trim((string) ava_opt('authorAvatar', '')));
        if (ava_image_ok($custom)) {
            return ava_resolve_url($custom);
        }

        /* آواتار پیش‌فرض پوسته (آواتار شخصی آوا) */
        $defaultAvatar = ava_default_avatar_url();

        /* آواتار اختصاصی کاربر (بستهٔ پوسته) همیشه در دسترس است */
        return $defaultAvatar;
    }
}

if (! function_exists('ava_author_name')) {
    function ava_author_name($author = null)
    {
        $name = '';
        try {
            if ($author) {
                $name = (string) $author->screenName;
                if ($name === '') {
                    $name = (string) $author->name;
                }
            }
        } catch (Throwable $e) {
            $name = '';
        }
        return $name !== '' ? $name : 'آوا';
    }
}

/* ============================================================
 * ۱۰) بندانگشتی نوشته — فیلد سفارشی ← نخستین تصویر متن ← پیش‌فرض
 * ============================================================ */

if (! function_exists('ava_first_image')) {
    /**
     * نخستین تصویر متن — HTML یا مارک‌داون (![alt](url) و ![alt][n] با تعریف [n]: url)
     */
    function ava_first_image($text)
    {
        $text = (string) $text;
        if ($text === '') {
            return '';
        }

        /* تصویر HTML */
        if (preg_match('/<img[^>]+src=["\']([^"\']+)["\']/i', $text, $m)) {
            return $m[1];
        }

        /* تصویر درون‌خطی مارک‌داون: ![alt](url "title") */
        if (preg_match('/!\[[^\]]*\]\(\s*<?([^\)\s>]+)>?[^\)]*\)/u', $text, $m)) {
            return $m[1];
        }

        /* تصویر مرجع مارک‌داون: ![alt][n] + [n]: url */
        if (preg_match('/!\[[^\]]*\]\[([^\]]+)\]/u', $text, $m)) {
            $ref = trim($m[1]);
            if ($ref !== '' && preg_match(
                '/^[ \t]*\[' . preg_quote($ref, '/') . '\]:[ \t]+<?([^\s>]+)>?/miu',
                $text,
                $mm
            )) {
                return $mm[1];
            }
        }

        /* تصویر مرجع بدون برچسب: ![][n] */
        if (preg_match('/!\[\]\[([^\]]+)\]/u', $text, $m)) {
            $ref = trim($m[1]);
            if ($ref !== '' && preg_match(
                '/^[ \t]*\[' . preg_quote($ref, '/') . '\]:[ \t]+<?([^\s>]+)>?/miu',
                $text,
                $mm
            )) {
                return $mm[1];
            }
        }

        return '';
    }
}

if (! function_exists('ava_post_thumbnail')) {
    function ava_post_thumbnail($widget)
    {
        /* ۱) فیلد سفارشی thumb */
        try {
            $field = trim((string) $widget->fields->thumb);
            if (ava_image_ok($field)) {
                return ava_resolve_url($field);
            }
        } catch (Throwable $e) {
            // فیلد وجود ندارد
        }

        /* ۲) نخستین تصویر متن */
        try {
            $img = ava_first_image((string) $widget->text);
            if ($img !== '' && ava_image_ok($img)) {
                return ava_resolve_url($img);
            }
        } catch (Throwable $e) {
            // نادیده بگیر
        }

        /* ۳) تصویر پیش‌فرض */
        return ava_theme_url('images/default-thumb.png');
    }
}

/* ============================================================
 * ۱۱) زمان مطالعه و خلاصه
 * ============================================================ */

if (! function_exists('ava_reading_time')) {
    function ava_reading_time($widget)
    {
        try {
            $text = strip_tags((string) $widget->text);
        } catch (Throwable $e) {
            return 1;
        }
        $words = count(preg_split('/\s+/u', trim($text), -1, PREG_SPLIT_NO_EMPTY));
        $minutes = max(1, (int) ceil($words / 200));
        return $minutes;
    }
}

if (! function_exists('ava_plain_text')) {
    /**
     * متن ساده و تمیز از HTML/مارک‌داون — بدون تصویر، لینک و نشانه‌گذاری.
     * تصاویر مارک‌داون (از جمله لینک‌های مرجع ![alt][1] و تعریف [1]: url) حذف می‌شوند
     * تا خلاصهٔ نوشته‌های تصویری خالی/به‌هم‌ریخته نشود.
     */
    function ava_plain_text($text)
    {
        $text = (string) $text;
        if ($text === '') {
            return '';
        }

        /* تصاویر مارک‌داون: ![alt](url) و ![alt][ref] */
        $text = preg_replace('/!\[[^\]]*\]\([^\)]*\)/u', '', $text);
        $text = preg_replace('/!\[[^\]]*\]\[[^\]]*\]/u', '', $text);
        /* تعریف مرجع در خط جدا: [1]: https://… */
        $text = preg_replace('/^[ \t]*\[[^\]]+\]:[ \t]+\S+.*$/mu', '', $text);
        /* لینک مارک‌داون به متن داخلی */
        $text = preg_replace('/\[([^\]]*)\]\([^\)]*\)/u', '$1', $text);
        $text = preg_replace('/\[([^\]]*)\]\[[^\]]*\]/u', '$1', $text);

        /* HTML */
        $text = strip_tags($text);

        /* فاصله‌ها */
        $text = preg_replace('/\s+/u', ' ', $text);
        return trim((string) $text);
    }
}

if (! function_exists('ava_truncate')) {
    /** کوتاه‌کردن متن با طول کاراکتر */
    function ava_truncate($text, $length = 60)
    {
        $text = trim((string) $text);
        if ($text === '') {
            return '';
        }
        if (mb_strlen($text, 'UTF-8') > (int) $length) {
            return mb_substr($text, 0, (int) $length, 'UTF-8') . '…';
        }
        return $text;
    }
}

if (! function_exists('ava_widget_text_field')) {
    /** نخستین مقدار غیرخالی از فیلدهای محتوایی ویجت (به ترتیب اطمینان) */
    function ava_widget_text_field($widget, array $fields)
    {
        foreach ($fields as $field) {
            try {
                $raw = (string) $widget->{$field};
            } catch (Throwable $e) {
                $raw = '';
            }
            $plain = ava_plain_text($raw);
            if ($plain !== '') {
                return $plain;
            }
        }
        return '';
    }
}

if (! function_exists('ava_excerpt')) {
    /** خلاصهٔ تمیز بدون HTML و مارک‌داون با طول مشخص (به کلمه) */
    function ava_excerpt($widget, $words = 28)
    {
        /* زنجیرهٔ منابع: خلاصهٔ خودکار ← خلاصهٔ ساده ← متن خام ← محتوای رندرشده */
        $plain = ava_widget_text_field($widget, ['excerpt', 'plainExcerpt', 'text', 'content']);
        if ($plain === '') {
            return '';
        }

        $parts = preg_split('/\s+/u', $plain, $words + 1, PREG_SPLIT_NO_EMPTY);
        if (is_array($parts) && count($parts) > $words) {
            array_pop($parts);
            return implode(' ', $parts) . '…';
        }
        return $plain;
    }
}

if (! function_exists('ava_excerpt_chars')) {
    /** خلاصه بر پایهٔ تعداد کاراکتر (برای کارت نوشتهٔ ویژه و…) */
    function ava_excerpt_chars($widget, $chars = 150)
    {
        /* زنجیرهٔ منابع: خلاصهٔ خودکار ← خلاصهٔ ساده ← متن خام ← محتوای رندرشده */
        $plain = ava_widget_text_field($widget, ['excerpt', 'plainExcerpt', 'text', 'content']);
        if ($plain === '') {
            return '';
        }
        return ava_truncate($plain, (int) $chars);
    }
}

/* ============================================================
 * ۱۲) رنگ برچسب دسته‌بندی بر پایه شناسه
 * ============================================================ */

if (! function_exists('ava_badge_class')) {
    function ava_badge_class($mid)
    {
        $palette = ['b-soft', 'b-tech', 'b-code', 'b-book', 'b-life', 'b-blue'];
        return 'badge ' . $palette[((int) $mid) % count($palette)];
    }
}

if (! function_exists('ava_cat_dot_color')) {
    function ava_cat_dot_color($mid)
    {
        $colors = [
            'var(--primary)', 'var(--badge-life)', 'var(--badge-tech)',
            'var(--badge-book)', 'var(--badge-blue)', 'var(--badge-code)',
        ];
        return $colors[((int) $mid) % count($colors)];
    }
}

/* ============================================================
 * ۱۲-ب) دسته‌های یک نوشته، نشانی مسیرها و آخرین دیدگاه‌ها
 * ============================================================ */

if (! function_exists('ava_router_url')) {
    /** نشانی یک مسیر Typecho/TypeRenew با سازگاری دو نسل کلاس */
    function ava_router_url($route, $params, $fallback = '#')
    {
        try {
            $site = \Widget\Options::alloc()->siteUrl;
            if (class_exists('\Typecho\Router')) {
                return (string) \Typecho\Router::url($route, $params, $site);
            }
            if (class_exists('Typecho_Router')) {
                return (string) Typecho_Router::url($route, $params, $site);
            }
        } catch (Throwable $e) {
            // مسیر در دسترس نیست
        }
        return $fallback;
    }
}

if (! function_exists('ava_post_categories')) {
    /**
     * دسته‌های نوشتهٔ مشخص (cid) به‌صورت آرایهٔ [mid, name, permalink].
     * برای ویجت‌هایی که دسته را در ردیف‌هایشان ندارند (مثل آخرین نوشته‌ها).
     */
    function ava_post_categories($cid)
    {
        static $cache = [];
        $cid = (int) $cid;
        if ($cid < 1) {
            return [];
        }
        if (isset($cache[$cid])) {
            return $cache[$cid];
        }

        $cats = [];
        try {
            $db = ava_db();
            if ($db) {
                $prefix = $db->getPrefix();
                $rows = $db->fetchAll(
                    'SELECT m.mid, m.name, m.slug'
                    . ' FROM `' . $prefix . 'metas` m'
                    . ' INNER JOIN `' . $prefix . 'relationships` r ON r.mid = m.mid'
                    . ' WHERE r.cid = ' . $cid
                    . " AND m.type = 'category'"
                    . ' ORDER BY m.mid ASC'
                );
                foreach ((array) $rows as $row) {
                    $cats[] = [
                        'mid'       => (int) $row['mid'],
                        'name'      => (string) $row['name'],
                        'permalink' => ava_router_url('category', ['slug' => (string) $row['slug']]),
                    ];
                }
            }
        } catch (Throwable $e) {
            $cats = [];
        }

        $cache[$cid] = $cats;
        return $cats;
    }
}

if (! function_exists('ava_recent_comments')) {
    /**
     * آخرین دیدگاه‌های تأییدشدهٔ سایت — برای ویجت سایدبار.
     * الگوی خام SQL (سازگار با TypeRenew و Typecho).
     */
    function ava_recent_comments($limit = 5)
    {
        $items = [];
        $limit = max(1, (int) $limit);

        try {
            $db = ava_db();
            if (! $db) {
                return $items;
            }
            $prefix = $db->getPrefix();

            $rows = $db->fetchAll(
                'SELECT c.coid, c.author AS commentAuthor, c.authorId AS commentAuthorId,'
                . ' c.text AS commentText, c.created AS commentCreated, c.mail AS commentMail,'
                . ' t.cid, t.slug, t.title, t.type, t.status, t.password, t.authorId AS postAuthorId'
                . ' FROM `' . $prefix . 'comments` c'
                . ' LEFT JOIN `' . $prefix . 'contents` t ON t.cid = c.cid'
                . " WHERE c.status = 'approved' AND c.type = 'comment'"
                . " AND t.status = 'publish' AND t.type IN ('post', 'page')"
                . ' ORDER BY c.coid DESC LIMIT ' . $limit
            );

            foreach ((array) $rows as $row) {
                if (! empty($row['password'])) {
                    continue;
                }

                $link = '#';
                if (! empty($row['cid'])) {
                    $link = ava_router_url(
                        (string) $row['type'],
                        ['cid' => (int) $row['cid'], 'slug' => (string) $row['slug']]
                    );
                }
                $link .= '#comments';

                $items[] = [
                    'author'  => (string) $row['commentAuthor'],
                    'mail'    => (string) ($row['commentMail'] ?? ''),
                    'authorId' => (int) ($row['commentAuthorId'] ?? 0),
                    'ownerId'  => (int) ($row['postAuthorId'] ?? 0),
                    'text'    => ava_plain_text((string) $row['commentText']),
                    'created' => (int) $row['commentCreated'],
                    'title'   => (string) $row['title'],
                    'link'    => $link,
                ];
            }
        } catch (Throwable $e) {
            return [];
        }

        return $items;
    }
}

/* ============================================================
 * ۱۳) ویجت مطالب محبوب — پر بازدیدترین نوشته‌ها (ستون views)
 * ============================================================ */

if (! class_exists('AvaPopularPosts')) {
    if (class_exists('\\Widget\\Base\\Contents')) {
        class AvaPopularPosts extends \Widget\Base\Contents
        {
            public function execute()
            {
                $this->parameter->setDefault(['pageSize' => 3]);
                $limit = max(1, (int) $this->parameter->pageSize);

                /* ستون مرتب‌سازی: بازدید — یا دیدگاه اگر آماری ثبت نشده */
                $orderColumn = 'table.contents.commentsNum';
                if (ava_views_schema_ready()) {
                    try {
                        $totalViews = (int) $this->db->fetchObject(
                            $this->db->select(['COALESCE(SUM(table.contents.views), 0)' => 'total'])
                                ->from('table.contents')
                                ->where('table.contents.type = ?', 'post')
                                ->where('table.contents.status = ?', 'publish')
                        )->total;

                        if ($totalViews > 0) {
                            $orderColumn = 'table.contents.views';
                        }
                    } catch (Throwable $e) {
                        // با پایه دیدگاه ادامه می‌دهیم
                    }
                }

                $select = $this->select('table.contents.*')
                    ->where('table.contents.status = ?', 'publish')
                    ->where('table.contents.created < ?', $this->options->time)
                    ->where('table.contents.type = ?', 'post')
                    ->where("table.contents.password IS NULL OR table.contents.password = ''")
                    ->order($orderColumn, 'DESC')
                    ->order('table.contents.created', 'DESC')
                    ->limit($limit);

                $this->db->fetchAll($select, [$this, 'push']);
            }
        }
    }
}

/* ============================================================
 * ۱۴) گالری تصاویر — ساده و درون‌متنی (مثل پوستهٔ مژگان)
 * چند تصویر پشت‌سرهم ← یک گرید بندانگشتی؛ بدون تکرار تصویر
 * ============================================================ */

if (! function_exists('ava_img_attrs')) {
    /** استخراج src و alt از تگ img رندرشده */
    function ava_img_attrs($tag)
    {
        $src = '';
        $alt = '';
        if (is_array($tag)) {
            $tag = (string) reset($tag);
        }
        $tag = (string) $tag;
        if (preg_match('/\\bsrc\\s*=\\s*(["\'])(.*?)\\1/is', $tag, $sm)) {
            $src = trim($sm[2]);
        }
        if (preg_match('/\\balt\\s*=\\s*(["\'])(.*?)\\1/is', $tag, $am)) {
            $alt = trim($am[2]);
        }
        return ['url' => $src, 'alt' => $alt];
    }
}

if (! function_exists('ava_inline_gallery')) {
    /**
     * گالری سادهٔ درون‌متنی:
     * هر جا چند بندِ فقط-تصویری پشت‌سرهم قرار بگیرند (یا یک بند چند تصویر
     * داشته باشد)، همهٔ آن‌ها با یک گرید بندانگشتی جایگزین می‌شوند —
     * یعنی هر تصویر فقط یک‌بار و فقط به‌صورت بندانگشتی نمایش داده می‌شود.
     * تصویر تک (بدون همسایه) دست‌نخورده در متن می‌ماند.
     */
    function ava_inline_gallery($html, $min = 2)
    {
        $html = (string) $html;
        if ($html === '' || strpos($html, '<img') === false) {
            return $html;
        }

        /* «اتم» تصویر: img تنها یا داخل لینک */
        $atom   = '(?:<a\\b[^>]*>\\s*)?<img\\b[^>]*>(?:\\s*</a>)?';
        $filler = '(?:\\s|&nbsp;|<br\\s*/?>)*';
        /* جداکنندهٔ ~ — خود الگو کاراکتر / دارد (مثل </a> و <br/>)
           و جداکنندهٔ / خطای «Unknown modifier» ایجاد می‌کند */
        $par    = '~<p\\b[^>]*>' . $filler . '((?:' . $atom . $filler . ')+' . $filler . ')</p>~iu';

        if (! @preg_match_all($par, $html, $matches, PREG_OFFSET_CAPTURE)) {
            return $html;
        }

        /* گروه‌بندی بندهای تصویریِ پشت‌سرهم (فقط فاصله بین آن‌ها) */
        $runs = [];
        $cur  = null;
        foreach ($matches[0] as $i => [$fullTag, $offset]) {
            $end = $offset + strlen($fullTag);

            $between = ($cur !== null) ? substr($html, $cur['end'], $offset - $cur['end']) : "\n";
            if ($cur !== null && preg_match('/^[\\s]*$/u', $between)) {
                $cur['end'] = $end;
            } else {
                if ($cur !== null) {
                    $runs[] = $cur;
                }
                $cur = ['start' => $offset, 'end' => $end, 'html' => ''];
            }

            /* تصاویر این بند */
            preg_match_all('/<img\\b[^>]*>/iu', $fullTag, $imgs);
            foreach ($imgs[0] as $imgTag) {
                $info = ava_img_attrs($imgTag);
                if ($info['url'] === '' || ! ava_image_ok($info['url'])) {
                    continue 2;
                }
                $cur['html'] .= $imgTag . "\x00";
            }
        }
        if ($cur !== null) {
            $runs[] = $cur;
        }

        /* جایگزینی گروه‌های ۲+ تصویری از انتها (برای حفظ درستی جابه‌جایی‌ها) */
        foreach (array_reverse($runs) as $run) {
            $imgs = array_values(array_filter(explode("\x00", $run['html'])));
            if (count($imgs) < (int) $min) {
                continue;
            }

            $grid = '<div class="gallery-grid ava-inline-gallery">';
            foreach ($imgs as $imgTag) {
                $info   = ava_img_attrs($imgTag);
                $url    = ava_resolve_url($info['url']);
                $grid  .= '<figure class="gallery-item" data-src="' . ava_e($url) . '" data-alt="' . ava_e($info['alt']) . '">'
                    . '<img src="' . ava_e($url) . '" alt="' . ava_e($info['alt']) . '" loading="lazy" decoding="async">'
                    . '</figure>';
            }
            $grid .= '</div>';

            $html = substr_replace($html, $grid, $run['start'], $run['end'] - $run['start']);
        }

        return (string) $html;
    }
}

/* ============================================================
 * ۱۵) فیلدهای سفارشی نوشته (ویرایشگر پیشخوان)
 * ============================================================ */

if (! function_exists('themeFields')) {
    function themeFields($layout)
    {
        try {
            $thumb = new \Typecho\Widget\Helper\Form\Element\Text(
                'thumb',
                null,
                null,
                _t('تصویر شاخص'),
                _t('نشانی تصویر شاخص نوشته. در صورت خالی‌بودن، نخستین تصویر متن یا تصویر پیش‌فرض پوسته نمایش داده می‌شود.')
            );
            $layout->addItem($thumb);
        } catch (Throwable $e) {
            // نادیده بگیر
        }
    }
}

/* ============================================================
 * ۱۵-ب) ساختار دیدگاه‌ها — با آواتار محلی
 * ============================================================ */

if (! function_exists('threadedComments')) {
    function threadedComments($comments, $options)
    {
        $commentClass = '';
        if ($comments->authorId) {
            if ($comments->authorId == $comments->ownerId) {
                $commentClass .= ' comment-by-author';
            } else {
                $commentClass .= ' comment-by-user';
            }
        }

        /* آواتار محلی: دیدگاه نویسندهٔ نوشته ← تصویر آواتار؛ سایر کاربران ← حرف آغازین رنگی */
        $avaIsOwner = ((int) $comments->authorId > 0 && (int) $comments->authorId === (int) $comments->ownerId);
        $avaAvatarUrl = $avaIsOwner ? ava_comment_avatar_url() : '';
        /* زنجیرهٔ آواتار: «اول پیش‌فرض سیستم، سپس گراواتار» — نویسندهٔ نوشته ← تصویر محلی؛
           سایر کاربران ← حرف آغازین رنگی فوراً نمایش داده می‌شود و اگر ایمیلشان
           گراواتار داشته باشد و سرویس در دسترس باشد، اسکریپت آن را جایگزین می‌کند */
        $avaGravUrl = $avaIsOwner ? '' : ava_gravatar_url((string) $comments->mail, 84);
        ?>
        <li id="li-<?php $comments->theId(); ?>" class="comment-body<?php
            if ($comments->levels > 0) {
                echo ' comment-child';
                $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
            } else {
                echo ' comment-parent';
            }
            $comments->alt(' comment-odd', ' comment-even');
            echo $commentClass;
        ?>">
            <div id="<?php $comments->theId(); ?>">
                <div class="comment-meta">
                    <span class="comment-avatar">
                        <?php echo ava_avatar_html(
                            (string) $comments->author,
                            $avaAvatarUrl,
                            42,
                            'comment-avatar-img',
                            $avaGravUrl
                        ); ?>
                    </span>
                    <cite class="comment-author" itemprop="creator" itemscope itemtype="http://schema.org/Person">
                        <?php $comments->author(); ?>
                        <?php if ($comments->authorId && $comments->authorId == $comments->ownerId): ?>
                            <span class="comment-badge-owner"><?php _e('نویسنده'); ?></span>
                        <?php endif; ?>
                    </cite>
                    <span class="comment-time">
                        <a href="<?php $comments->permalink(); ?>" itemprop="url">
                            <time datetime="<?php echo date('c', (int) $comments->created); ?>" itemprop="commentTime">
                                <?php echo ava_jdate('j F Y، H:i', (int) $comments->created); ?>
                            </time>
                        </a>
                    </span>
                    <?php if ($comments->status == 'waiting'): ?>
                        <span class="comment-status"><?php _e('در انتظار تأیید'); ?></span>
                    <?php endif; ?>
                    <span class="comment-reply">
                        <?php $comments->reply(_t('پاسخ')); ?>
                    </span>
                </div>
                <div class="comment-content" itemprop="commentText">
                    <?php $comments->content(); ?>
                </div>
            </div>
            <?php if ($comments->children) { ?>
                <div class="comment-children">
                    <?php $comments->threadedComments($options); ?>
                </div>
            <?php } ?>
        </li>
        <?php
    }
}

/* ============================================================
 * ۱۶) فرم تنظیمات پوسته (پیشخوان → ظاهر → تنظیمات پوسته)
 * ============================================================ */

if (! function_exists('themeConfig')) {
    function themeConfig($form)
    {
        $yes = _t('نمایش');
        $no  = _t('پنهان');

        /* ---------- هویت و ظاهر ---------- */

        $colorSchema = new \Typecho\Widget\Helper\Form\Element\Select(
            'colorSchema',
            [
                'light' => _t('روشن (پیشنهادی)'),
                'dark'  => _t('تیره'),
                'auto'  => _t('خودکار (پیروی از سیستم کاربر)'),
            ],
            'light',
            _t('حالت رنگی پیش‌فرض'),
            _t('بازدیدکننده می‌تواند با دکمهٔ ماه/خورشید در سربرگ، حالت را عوض کند.')
        );
        $form->addInput($colorSchema);

        $siteLogo = new \Typecho\Widget\Helper\Form\Element\Text(
            'siteLogo',
            null,
            null,
            _t('لوگوی تصویری سایت'),
            _t('نشانی تصویر لوگو (PNG، SVG، JPG یا WebP — مثلاً نشانی تصویر بارگذاری‌شده در رسانه‌ها). در صورت پرشدن، به‌جای نشان پیش‌فرض در سربرگ و فوتر سایت نمایش داده می‌شود. نشانی نسبی و ارقام فارسی به‌طور خودکار اصلاح می‌شوند؛ خالی بگذارید تا نشان پیش‌فرض (آیکون) نمایش داده شود.')
        );
        $form->addInput($siteLogo->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

        /* ---------- دربارهٔ نویسنده ---------- */

        $authorName = new \Typecho\Widget\Helper\Form\Element\Text(
            'authorName',
            null,
            'آوا',
            _t('نام نویسنده'),
            _t('نامی که در هیرو، سایدبار و باکس نویسندهٔ نوشته‌ها نمایش داده می‌شود.')
        );
        $form->addInput($authorName);

        $authorRole = new \Typecho\Widget\Helper\Form\Element\Text(
            'authorRole',
            null,
            'نویسنده و طراح وب‌سایت',
            _t('عنوان شغلی / نقش نویسنده'),
            _t('مثلاً: نویسنده و طراح وب‌سایت — زیر نام نویسنده نمایش داده می‌شود.')
        );
        $form->addInput($authorRole);

        $authorBio = new \Typecho\Widget\Helper\Form\Element\Textarea(
            'authorBio',
            null,
            'عاشق فناوری، طراحی و نویسندگی. قصد دارم تجربه‌ام و دانشم را با شما به اشتراک بگذارم.',
            _t('معرفی کوتاه نویسنده'),
            _t('در جعبهٔ نویسندهٔ سایدبار و صفحهٔ «درباره» نمایش داده می‌شود.')
        );
        $form->addInput($authorBio);

        $authorAvatar = new \Typecho\Widget\Helper\Form\Element\Text(
            'authorAvatar',
            null,
            null,
            _t('نشانی آواتار محلی سایت'),
            _t('نشانی تصویر آواتار محلی (مثلاً نشانی تصویر بارگذاری‌شده در رسانه‌ها). این آواتار برای نویسنده، فهرست دیدگاه‌ها و آخرین دیدگاه‌های سایدبار استفاده می‌شود؛ در صورت خالی‌بودن، آواتار بستهٔ پوسته نمایش داده می‌شود.')
        );
        $form->addInput($authorAvatar->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

        /* ---------- برگه‌های انتخابی (درباره / آرشیو کامل) ---------- */

        $pageOptions = ['' => _t('— انتخاب نشده (دکمه پنهان می‌شود) —')];
        foreach (ava_pages_index() as $avaPage) {
            $pageTitle = trim((string) $avaPage['title']);
            if ($pageTitle === '') {
                $pageTitle = 'برگهٔ ' . ava_fa((string) $avaPage['cid']);
            }
            $pageOptions[(string) $avaPage['cid']] = $pageTitle;
        }

        $aboutPage = new \Typecho\Widget\Helper\Form\Element\Select(
            'aboutPage',
            $pageOptions,
            '',
            _t('صفحهٔ «دربارهٔ من»'),
            _t('برگی که دکمهٔ «درباره من» در سایدبار، هیرو و باکس نویسندهٔ نوشته‌ها به آن پیوند می‌شود. برگهٔ دلخواه را بسازید و این‌جا انتخابش کنید (به نامک about وصل نمی‌شود).')
        );
        $form->addInput($aboutPage);

        /* ---------- هیرو صفحهٔ اصلی ---------- */

        $heroShow = new \Typecho\Widget\Helper\Form\Element\Radio(
            'heroShow',
            ['1' => $yes, '0' => $no],
            '1',
            _t('بخش هیرو صفحهٔ اصلی'),
            _t('کارت خوش‌آمدگویی با آواتار و دکمه‌های اقدام در بالای صفحهٔ نخست.')
        );
        $form->addInput($heroShow);

        $heroBadge = new \Typecho\Widget\Helper\Form\Element\Text(
            'heroBadge',
            null,
            'خوش آمدید به دنیای وبلاگ‌نویسی',
            _t('برچسب بالای عنوان هیرو')
        );
        $form->addInput($heroBadge);

        $heroTitle = new \Typecho\Widget\Helper\Form\Element\Text(
            'heroTitle',
            null,
            'سلام، من آوا هستم',
            _t('عنوان هیرو'),
            _t('کلمهٔ «آوا» به‌طور خودکار با رنگ اصلی هایلایت می‌شود؛ نام را داخل عنوان بنویسید.')
        );
        $form->addInput($heroTitle);

        $heroDesc = new \Typecho\Widget\Helper\Form\Element\Textarea(
            'heroDesc',
            null,
            'عاشق فناوری، طراحی و نویسندگی هستم. در این وبلاگ تجربه‌ها، یادگیری‌ها و کشفیاتم را درباره دنیای وب و زندگی دیجیتال با شما به اشتراک می‌گذارم.',
            _t('توضیح هیرو')
        );
        $form->addInput($heroDesc);

        $heroArchiveText = new \Typecho\Widget\Helper\Form\Element\Text(
            'heroArchiveText',
            null,
            'آرشیو کامل',
            _t('متن دکمهٔ آرشیو هیرو'),
            _t('دکمهٔ اصلی هیرو؛ به برگهٔ انتخاب‌شده در تنظیم «صفحهٔ آرشیو کامل» پایین‌تر پیوند می‌شود.')
        );
        $form->addInput($heroArchiveText);

        $heroAboutText = new \Typecho\Widget\Helper\Form\Element\Text(
            'heroAboutText',
            null,
            'درباره من',
            _t('متن دکمهٔ «دربارهٔ من» هیرو'),
            _t('پیوند این دکمه از تنظیم «صفحهٔ دربارهٔ من» بالای همین بخش خوانده می‌شود.')
        );
        $form->addInput($heroAboutText);

        $archivePage = new \Typecho\Widget\Helper\Form\Element\Select(
            'archivePage',
            $pageOptions,
            '',
            _t('صفحهٔ «آرشیو کامل»'),
            _t('یک برگهٔ جدید با «قالب سفارشی: بایگانی مطالب» بسازید و این‌جا انتخاب کنید. دکمهٔ «آرشیو کامل» هیرو، دکمهٔ «همه نوشته‌ها» و دکمهٔ آرشیو صفحهٔ درباره به این برگه پیوند می‌شوند.')
        );
        $form->addInput($archivePage);

        $archiveStyle = new \Typecho\Widget\Helper\Form\Element\Select(
            'archiveStyle',
            [
                'cards' => _t('کارت — گرید با تصویر کاور'),
                'list'  => _t('لیست — ردیف‌های تصویری (با بندانگشتی)'),
            ],
            'cards',
            _t('سبک نمایش صفحهٔ بایگانی'),
            _t('در صفحهٔ «بایگانی مطالب»، نوشته‌ها یا به‌صورت گرید کارت با تصویر کاور یا ردیف‌های تصویری با بندانگشتی و خلاصه نمایش داده می‌شوند (بدون گروه‌بندی سالانه).')
        );
        $form->addInput($archiveStyle);

        $archivePerPage = new \Typecho\Widget\Helper\Form\Element\Select(
            'archivePerPage',
            [
                '6'  => _t('۶ نوشته'),
                '9'  => _t('۹ نوشته'),
                '12' => _t('۱۲ نوشته'),
                '15' => _t('۱۵ نوشته'),
                '18' => _t('۱۸ نوشته'),
                '24' => _t('۲۴ نوشته'),
                '30' => _t('۳۰ نوشته'),
            ],
            '12',
            _t('تعداد نوشتهٔ هر صفحهٔ بایگانی'),
            _t('در صفحهٔ «بایگانی مطالب» همین تعداد نوشته در هر صفحه نمایش داده می‌شود؛ صفحه‌بندی به‌صورت خودکار ساخته می‌شود و در حالت کارتی، گرید سه‌ستونه است.')
        );
        $form->addInput($archivePerPage);

        /* ---------- بخش‌های صفحهٔ اصلی ---------- */

        $showStats = new \Typecho\Widget\Helper\Form\Element\Radio(
            'showStats',
            ['1' => $yes, '0' => $no],
            '1',
            _t('نوار آمار'),
            _t('تعداد نوشته، بازدید کل، لایک کل و دسته‌بندی‌ها در یک کارت واحد.')
        );
        $form->addInput($showStats);

        $showFeatured = new \Typecho\Widget\Helper\Form\Element\Radio(
            'showFeatured',
            ['1' => $yes, '0' => $no],
            '1',
            _t('نوشتهٔ ویژه'),
            _t('آخرین نوشته به‌صورت کارت بزرگ پیش از گرید نوشته‌های اخیر.')
        );
        $form->addInput($showFeatured);

        $showSidebar = new \Typecho\Widget\Helper\Form\Element\Radio(
            'showSidebar',
            ['1' => $yes, '0' => $no],
            '1',
            _t('سایدبار صفحهٔ اصلی'),
            _t('جعبهٔ نویسنده، دسته‌بندی‌ها و محبوب‌ترین‌ها.')
        );
        $form->addInput($showSidebar);

        $promoShow = new \Typecho\Widget\Helper\Form\Element\Radio(
            'promoShow',
            ['1' => $yes, '0' => $no],
            '1',
            _t('نوار اقدام (CTA)'),
            _t('نوار دانلود/فراخوان در پایین صفحهٔ نخست؛ متن و دکمه در پایین همین فرم تنظیم می‌شود.')
        );
        $form->addInput($promoShow);

        /* ---------- امکانات نوشته‌ها ---------- */

        $showLikes = new \Typecho\Widget\Helper\Form\Element\Radio(
            'showLikes',
            ['1' => $yes, '0' => $no],
            '1',
            _t('دکمهٔ پسندیدن (لایک)'),
            _t('ذخیره در ستون likes جدول contents — بدون نیاز به افزونه.')
        );
        $form->addInput($showLikes);

        $showRelated = new \Typecho\Widget\Helper\Form\Element\Radio(
            'showRelated',
            ['1' => $yes, '0' => $no],
            '1',
            _t('مطالب مرتبط'),
            _t('در پایان هر نوشته، نوشته‌های مرتبط بر پایهٔ برچسب‌ها نمایش داده می‌شود.')
        );
        $form->addInput($showRelated);

        $relatedCount = new \Typecho\Widget\Helper\Form\Element\Select(
            'relatedCount',
            ['2' => '۲', '3' => '۳', '4' => '۴', '6' => '۶'],
            '3',
            _t('تعداد مطالب مرتبط')
        );
        $form->addInput($relatedCount);

        $showGallery = new \Typecho\Widget\Helper\Form\Element\Radio(
            'showGallery',
            ['1' => $yes, '0' => $no],
            '1',
            _t('گالری تصاویر نوشته (درون‌متنی)'),
            _t('هر چند تصویر پشت‌سرهم در متن نوشته، به‌صورت یک گرید بندانگشتی ساده (بدون تکرار) نمایش داده می‌شود؛ تصویر تنها همان‌جا در متن می‌ماند.')
        );
        $form->addInput($showGallery);

        $showAuthorBox = new \Typecho\Widget\Helper\Form\Element\Radio(
            'showAuthorBox',
            ['1' => $yes, '0' => $no],
            '1',
            _t('باکس نویسنده در نوشته'),
            _t('کارت نویسنده با آواتار، نقش و لینک صفحهٔ درباره.')
        );
        $form->addInput($showAuthorBox);

        /* ---------- آمار بازدید ---------- */

        $countLoggedInViews = new \Typecho\Widget\Helper\Form\Element\Radio(
            'countLoggedInViews',
            ['1' => _t('شمارش شود'), '0' => _t('شمرده نشود')],
            '0',
            _t('بازدید کاربران واردشده'),
            _t('آیا بازدید مدیر و نویسندگان واردشده هم شمرده شود؟')
        );
        $form->addInput($countLoggedInViews);

        $viewsInterval = new \Typecho\Widget\Helper\Form\Element\Select(
            'viewsInterval',
            [
                '1800'  => _t('۳۰ دقیقه'),
                '3600'  => _t('۱ ساعت (پیشنهادی)'),
                '21600' => _t('۶ ساعت'),
                '86400' => _t('۲۴ ساعت'),
                '0'     => _t('بدون محدودیت (هر بازدید شمرده می‌شود)'),
            ],
            '3600',
            _t('فاصلهٔ شمارش بازدیدهای تکراری'),
            _t('با کوکی مرورگر، بازدیدهای تکراری یک نوشته در این بازه فقط یک‌بار شمرده می‌شود.')
        );
        $form->addInput($viewsInterval);

        /* ---------- شبکه‌های اجتماعی ---------- */

        $socialTelegram = new \Typecho\Widget\Helper\Form\Element\Text(
            'socialTelegram',
            null,
            null,
            _t('نشانی تلگرام')
        );
        $form->addInput($socialTelegram->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

        $socialInstagram = new \Typecho\Widget\Helper\Form\Element\Text(
            'socialInstagram',
            null,
            null,
            _t('نشانی اینستاگرام')
        );
        $form->addInput($socialInstagram->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

        $socialTwitter = new \Typecho\Widget\Helper\Form\Element\Text(
            'socialTwitter',
            null,
            null,
            _t('نشانی توییتر / X')
        );
        $form->addInput($socialTwitter->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

        $socialGithub = new \Typecho\Widget\Helper\Form\Element\Text(
            'socialGithub',
            null,
            null,
            _t('نشانی گیت‌هاب')
        );
        $form->addInput($socialGithub->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

        $socialLinkedin = new \Typecho\Widget\Helper\Form\Element\Text(
            'socialLinkedin',
            null,
            null,
            _t('نشانی لینکدین')
        );
        $form->addInput($socialLinkedin->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

        $socialEmail = new \Typecho\Widget\Helper\Form\Element\Text(
            'socialEmail',
            null,
            null,
            _t('نشانی ایمیل (mailto)')
        );
        $form->addInput($socialEmail->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

        /* ---------- نوار اقدام (CTA) ---------- */

        $promoTitle = new \Typecho\Widget\Helper\Form\Element\Text(
            'promoTitle',
            null,
            'دانلود پوسته آوا',
            _t('عنوان نوار اقدام')
        );
        $form->addInput($promoTitle);

        $promoDesc = new \Typecho\Widget\Helper\Form\Element\Text(
            'promoDesc',
            null,
            'نسخه کامل قالب وبلاگ · نسخه ۱٫۰٫۰ · فرمت ZIP',
            _t('توضیح نوار اقدام')
        );
        $form->addInput($promoDesc);

        $promoBtnText = new \Typecho\Widget\Helper\Form\Element\Text(
            'promoBtnText',
            null,
            'دانلود رایگان',
            _t('متن دکمهٔ نوار اقدام')
        );
        $form->addInput($promoBtnText);

        $promoBtnUrl = new \Typecho\Widget\Helper\Form\Element\Text(
            'promoBtnUrl',
            null,
            null,
            _t('نشانی دکمهٔ نوار اقدام'),
            _t('مثلاً نشانی دانلود فایل، رزومه یا هر فراخوان دیگری.')
        );
        $form->addInput($promoBtnUrl->addRule('xssCheck', _t('لطفاً یک نشانی معتبر وارد کنید')));

        /* ---------- فوتر ---------- */

        $footerDesc = new \Typecho\Widget\Helper\Form\Element\Textarea(
            'footerDesc',
            null,
            'نویسنده، طراح و وبلاگ‌نویس. جایی برای به اشتراک‌گذاری تجربه‌ها و دانسته‌ها درباره فناوری، طراحی و زندگی.',
            _t('توضیح کوتاه فوتر')
        );
        $form->addInput($footerDesc);

        $copyright = new \Typecho\Widget\Helper\Form\Element\Text(
            'copyright',
            null,
            null,
            _t('متن کپی‌رایت اختصاصی'),
            _t('در صورت خالی‌بودن: «© سال شمسی · نام سایت — ساخته شده با ❤ و TypeRenew»')
        );
        $form->addInput($copyright);
    }
}
