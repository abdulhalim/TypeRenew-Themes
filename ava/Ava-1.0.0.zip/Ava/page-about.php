<?php
/**
 * دربارهٔ نویسنده
 *
 * @package custom
 */

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');

/* هویت نویسنده از تنظیمات پوسته */
$authorName = (string) ava_opt('authorName', 'آوا');
$authorRole = (string) ava_opt('authorRole', 'نویسنده و طراح وب‌سایت');
$authorBio  = (string) ava_opt('authorBio', 'عاشق فناوری، طراحی و نویسندگی. قصد دارم تجربه‌ام و دانشم را با شما به اشتراک بگذارم.');
$avatarUrl  = ava_author_avatar_url();

/* متن برگه */
ob_start();
$this->content();
$aboutContent = trim((string) ob_get_clean());

/* آمار سایت */
$stats = ava_stats();

/* شبکه‌های اجتماعی */
$aboutSocials = [
    ['socialTelegram', 'telegram', 'تلگرام'],
    ['socialInstagram', 'instagram', 'اینستاگرام'],
    ['socialTwitter', 'twitter', 'توییتر'],
    ['socialGithub', 'github', 'گیت‌هاب'],
    ['socialLinkedin', 'linkedin', 'لینکدین'],
    ['socialEmail', 'mail', 'ایمیل'],
];

/* نشانی صفحهٔ «آرشیو کامل» — از تنظیمات پوسته (تنظیم «صفحهٔ آرشیو کامل») */
$aboutArchiveUrl = ava_archive_url();
?>
<div class="container">

    <!-- ===== سربرگ درباره ===== -->
    <section class="about-hero animate-fade-up">
        <div class="about-media">
            <?php echo ava_avatar_html($authorName, $avatarUrl, 210); ?>
        </div>
        <div class="about-intro">
            <span class="about-kicker">
                <?php echo ava_icon('sparkles', 15); ?>
                دربارهٔ من
            </span>
            <h1 class="about-name"><?php echo ava_e($authorName); ?></h1>
            <?php if ($authorRole !== ''): ?>
            <p class="about-role"><?php echo ava_e($authorRole); ?></p>
            <?php endif; ?>
            <?php if ($authorBio !== ''): ?>
            <p class="about-bio"><?php echo ava_e($authorBio); ?></p>
            <?php endif; ?>

            <div class="about-social">
                <?php
                $hasSocial = false;
                foreach ($aboutSocials as [$key, $icon, $label]) {
                    $url = trim((string) ava_opt($key, ''));
                    if ($url === '') {
                        continue;
                    }
                    $hasSocial = true;
                    $href = $key === 'socialEmail'
                        ? (preg_match('/^mailto:/i', $url) ? $url : 'mailto:' . $url)
                        : ava_resolve_url($url);
                    echo '<a href="' . ava_e($href) . '" class="social-link" aria-label="' . ava_e($label) . '" title="' . ava_e($label) . '"'
                        . ($key === 'socialEmail' ? '' : ' target="_blank" rel="noopener"') . '>'
                        . ava_social_icon($icon, 19) . '</a>';
                }
                if (! $hasSocial) {
                    echo '<a href="' . ava_e(ava_resolve_url('/feed')) . '" class="social-link" aria-label="خوراک RSS" title="خوراک RSS">' . ava_icon('rss', 19) . '</a>';
                }
                ?>
            </div>

            <div class="hero-actions" style="margin-top:22px;">
                <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-primary">
                    <?php echo ava_icon('book-open', 16); ?>
                    خواندن نوشته‌های وبلاگ
                </a>
                <?php if ($aboutArchiveUrl !== ''): ?>
                <a href="<?php echo ava_e($aboutArchiveUrl); ?>" class="btn btn-outline">
                    <?php echo ava_icon('archive', 16); ?>
                    آرشیو کامل
                </a>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- ===== آمار ===== -->
    <section class="stats-bar about-stats animate-fade-up">
        <div class="stat-item">
            <span class="stat-icon"><?php echo ava_icon('file-text', 22); ?></span>
            <div><div class="stat-num"><?php echo ava_format_count($stats['posts']); ?></div><div class="stat-label">نوشته</div></div>
        </div>
        <div class="stat-item">
            <span class="stat-icon t2"><?php echo ava_icon('eye', 22); ?></span>
            <div><div class="stat-num"><?php echo ava_format_count($stats['views']); ?></div><div class="stat-label">بازدید</div></div>
        </div>
        <div class="stat-item">
            <span class="stat-icon t3"><?php echo ava_icon('heart', 22); ?></span>
            <div><div class="stat-num"><?php echo ava_format_count($stats['likes']); ?></div><div class="stat-label">لایک</div></div>
        </div>
        <div class="stat-item">
            <span class="stat-icon t4"><?php echo ava_icon('comment', 22); ?></span>
            <div><div class="stat-num"><?php echo ava_format_count($stats['comments']); ?></div><div class="stat-label">دیدگاه</div></div>
        </div>
    </section>

    <!-- ===== متن برگه ===== -->
    <?php if ($aboutContent !== ''): ?>
    <section class="about-content animate-fade-up">
        <h2 class="section-title" style="margin-bottom:20px;">
            <?php echo ava_icon('pen', 18); ?>
            بیشتر دربارهٔ من
        </h2>
        <div class="prose-ava post-content">
            <?php echo $aboutContent; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- ===== آخرین نوشته‌ها ===== -->
    <?php
    $aboutRecent = null;
    try {
    $this->widget('Widget_Contents_Post_Recent@ava-about', 'pageSize=3')->to($aboutRecent);
    } catch (Throwable $e) {
        $aboutRecent = null;
    }
    ?>
    <?php if ($aboutRecent && $aboutRecent->have()): ?>
    <section class="related-posts animate-fade-up" aria-label="آخرین نوشته‌ها">
        <div class="section-head">
            <h2 class="section-title">
                <?php echo ava_icon('book-open', 18); ?>
                آخرین نوشته‌های من
            </h2>
        </div>
        <div class="related-grid">
            <?php while ($aboutRecent->next()): ?>
            <article class="post-card">
                <div class="post-card-media">
                    <a href="<?php $aboutRecent->permalink(); ?>" tabindex="-1" aria-hidden="true">
                        <img src="<?php echo ava_e(ava_post_thumbnail($aboutRecent)); ?>" alt="<?php $aboutRecent->title(); ?>" loading="lazy" decoding="async">
                    </a>
                </div>
                <div class="post-card-body">
                    <h3 class="post-card-title"><a href="<?php $aboutRecent->permalink(); ?>"><?php $aboutRecent->title(); ?></a></h3>
                    <footer class="post-card-meta">
                        <span><?php echo ava_icon('calendar', 14); ?><?php echo ava_jdate('j F Y', (int) $aboutRecent->created); ?></span>
                        <span><?php echo ava_icon('clock', 14); ?><?php echo ava_fa(ava_reading_time($aboutRecent)); ?> دقیقه</span>
                    </footer>
                </div>
            </article>
            <?php endwhile; ?>
        </div>
    </section>
    <?php endif; ?>
</div>

<?php $this->need('footer.php'); ?>
