<?php
/**
 * بایگانی مطالب
 *
 * @package custom
 */

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');

/* سبک نمایش: cards = گرید سه‌ستونه با کاور، list = ردیف‌های تصویری با بندانگشتی */
$archiveStyle = (string) ava_opt('archiveStyle', 'cards');
if (! in_array($archiveStyle, ['cards', 'list'], true)) {
    $archiveStyle = 'cards';
}

/* تعداد نوشتهٔ هر صفحه — بر اساس انتخاب کاربر در تنظیمات پوسته */
$avaPerPage = (int) ava_en_num((string) ava_opt('archivePerPage', '12'));
$avaPerPage = max(4, min(60, $avaPerPage));

/* شمارهٔ صفحهٔ جاری (?page=N) — ارقام فارسی هم پذیرفته می‌شود */
$avaPage = 1;
if (isset($_GET['page'])) {
    $avaPage = (int) ava_en_num((string) $_GET['page']);
}
$avaPage = max(1, $avaPage);

/* متن برگه (توضیح اختیاری بالای فهرست) */
ob_start();
$this->content();
$pageContent = trim((string) ob_get_clean());

/* همهٔ نوشته‌های منتشرشده — یک‌جا جمع می‌شوند تا صفحه‌بندی دقیق ساخته شود */
$avaAll = [];
$archiveItems = null;
try {
    $this->widget('Widget_Contents_Post_Recent@ava-full-archive', 'pageSize=1000')->to($archiveItems);
} catch (Throwable $e) {
    $archiveItems = null;
}

if ($archiveItems) {
    while ($archiveItems->next()) {
        /* برچسب دسته روی تصویر کارت‌ها (categories در آرشیو آرایه است) */
        $avaBadge = '';
        if ($archiveStyle === 'cards') {
            try {
                $avaItemCats = $archiveItems->categories;
                if (! empty($avaItemCats) && is_array($avaItemCats)) {
                    $ic        = $avaItemCats[0];
                    $avaBadge  = '<a class="badge on-image ' . ava_e(str_replace('badge ', '', ava_badge_class((int) ($ic['mid'] ?? 0))))
                        . '" href="' . ava_e($ic['permalink']) . '">' . ava_e($ic['name']) . '</a>';
                }
            } catch (Throwable $e) {
                $avaBadge = '';
            }
        }

        $avaItem = [
            'title'    => (string) $archiveItems->title,
            'url'      => (string) $archiveItems->permalink,
            'created'  => (int) $archiveItems->created,
            'comments' => (int) $archiveItems->commentsNum,
            'views'    => ava_get_views($archiveItems),
            'thumb'    => (string) ava_post_thumbnail($archiveItems),
            'badge'    => $avaBadge,
            'catName'  => '',
            'excerpt'  => '',
        ];

        /* دادهٔ اضافی حالت لیست: دسته و خلاصه */
        if ($archiveStyle === 'list') {
            try {
                $avaCats2 = ava_post_categories((int) $archiveItems->cid);
                if (! empty($avaCats2)) {
                    $avaItem['catName'] = (string) $avaCats2[0]['name'];
                }
            } catch (Throwable $e) {
                $avaItem['catName'] = '';
            }
            $avaItem['excerpt'] = ava_excerpt_chars($archiveItems, 110);
        }

        $avaAll[] = $avaItem;
    }
}

/* محاسبات صفحه‌بندی */
$avaTotal  = count($avaAll);
$avaPages  = max(1, (int) ceil($avaTotal / $avaPerPage));
$avaPage   = min($avaPage, $avaPages);
$avaOffset = ($avaPage - 1) * $avaPerPage;
$avaSlice  = array_slice($avaAll, $avaOffset, $avaPerPage);
$avaFrom   = ($avaTotal > 0) ? ($avaOffset + 1) : 0;
$avaTo     = $avaOffset + count($avaSlice);

/* پنجرهٔ شماره‌ها: ۱ … (جاری-۱) جاری (جاری+۱) … آخر */
$avaWindow = [];
if ($avaPages <= 7) {
    for ($avaI = 1; $avaI <= $avaPages; $avaI++) {
        $avaWindow[] = $avaI;
    }
} else {
    $avaWindow[] = 1;
    $avaS = max(2, $avaPage - 1);
    $avaE = min($avaPages - 1, $avaPage + 1);
    if ($avaS > 2) {
        $avaWindow[] = '...';
    }
    for ($avaI = $avaS; $avaI <= $avaE; $avaI++) {
        $avaWindow[] = $avaI;
    }
    if ($avaE < $avaPages - 1) {
        $avaWindow[] = '...';
    }
    $avaWindow[] = $avaPages;
}

/* نشانی صفحه‌ها (?page=N) — با سازندهٔ نشانی خود Typecho */
$avaUrls = [];
foreach ($avaWindow as $avaN) {
    if ($avaN === '...') {
        continue;
    }
    try {
        $avaUrls[$avaN] = (string) $this->request->makeUriByRequest(['page' => (int) $avaN]);
    } catch (Throwable $e) {
        $avaUrls[$avaN] = '?page=' . (int) $avaN;
    }
}
$avaPrevUrl = '';
$avaNextUrl = '';
if ($avaPage > 1) {
    try {
        $avaPrevUrl = (string) $this->request->makeUriByRequest(['page' => $avaPage - 1]);
    } catch (Throwable $e) {
        $avaPrevUrl = '?page=' . ($avaPage - 1);
    }
}
if ($avaPage < $avaPages) {
    try {
        $avaNextUrl = (string) $this->request->makeUriByRequest(['page' => $avaPage + 1]);
    } catch (Throwable $e) {
        $avaNextUrl = '?page=' . ($avaPage + 1);
    }
}
?>
<div class="container">

    <nav class="breadcrumb" aria-label="مسیر صفحه">
        <a href="<?php $this->options->siteUrl(); ?>">خانه</a>
        <span class="sep">/</span>
        <span class="current"><?php $this->title(); ?></span>
    </nav>

    <section class="full-archive animate-fade-up">
        <div class="section-head">
            <h1 class="section-title">
                <?php echo ava_icon('archive', 20); ?>
                <?php $this->title(); ?>
            </h1>
            <span class="cat-count"><?php echo ava_fa((string) $avaTotal); ?> نوشته</span>
        </div>

        <?php if ($pageContent !== ''): ?>
        <div class="prose-ava post-content archive-page-intro">
            <?php echo $pageContent; ?>
        </div>
        <?php endif; ?>

        <?php if ($avaTotal > 0): ?>

            <?php if ($archiveStyle === 'cards'): ?>
            <!-- ===== گرید سه‌ستونهٔ کارت ===== -->
            <div class="posts-grid archive-cards">
                <?php foreach ($avaSlice as $avaItem): ?>
                <article class="post-card">
                    <div class="post-card-media">
                        <a href="<?php echo ava_e($avaItem['url']); ?>" tabindex="-1" aria-hidden="true">
                            <img src="<?php echo ava_e($avaItem['thumb']); ?>" alt="<?php echo ava_e($avaItem['title']); ?>" loading="lazy" decoding="async">
                        </a>
                        <?php echo $avaItem['badge']; ?>
                    </div>
                    <div class="post-card-body">
                        <h3 class="post-card-title"><a href="<?php echo ava_e($avaItem['url']); ?>"><?php echo ava_e($avaItem['title']); ?></a></h3>
                        <footer class="post-card-meta">
                            <span><?php echo ava_icon('calendar', 14); ?><?php echo ava_jdate('j F Y', $avaItem['created']); ?></span>
                            <span><?php echo ava_icon('eye', 14); ?><?php echo ava_format_count($avaItem['views']); ?> بازدید</span>
                            <span><?php echo ava_icon('comment', 14); ?><?php echo ava_format_count($avaItem['comments']); ?> نظر</span>
                        </footer>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>

            <?php else: ?>
            <!-- ===== ردیف‌های تصویری (با بندانگشتی و خلاصه) ===== -->
            <div class="archive-list media-list">
                <?php foreach ($avaSlice as $avaItem): ?>
                <a class="archive-row" href="<?php echo ava_e($avaItem['url']); ?>">
                    <span class="archive-row-thumb">
                        <img src="<?php echo ava_e($avaItem['thumb']); ?>" alt="<?php echo ava_e($avaItem['title']); ?>" loading="lazy" decoding="async">
                    </span>
                    <span class="archive-row-body">
                        <span class="archive-title"><?php echo ava_e($avaItem['title']); ?></span>
                        <?php if ($avaItem['excerpt'] !== ''): ?>
                        <span class="archive-row-excerpt"><?php echo ava_e($avaItem['excerpt']); ?></span>
                        <?php endif; ?>
                        <span class="archive-meta">
                            <time class="archive-date"><?php echo ava_jdate('j F Y', $avaItem['created']); ?></time>
                            <?php if ($avaItem['catName'] !== ''): ?>
                            <span class="archive-cat"><?php echo ava_e($avaItem['catName']); ?></span>
                            <?php endif; ?>
                            <span><?php echo ava_icon('eye', 13); ?><?php echo ava_format_count($avaItem['views']); ?></span>
                            <span><?php echo ava_icon('comment', 13); ?><?php echo ava_format_count($avaItem['comments']); ?></span>
                        </span>
                    </span>
                </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if ($avaPages > 1): ?>
            <!-- ===== صفحه‌بندی ===== -->
            <p class="archive-range">
                نمایش <?php echo ava_fa((string) $avaFrom); ?> تا <?php echo ava_fa((string) $avaTo); ?>
                از <?php echo ava_fa((string) $avaTotal); ?> نوشته
            </p>
            <nav class="pagination archive-pagination" aria-label="صفحه‌بندی بایگانی">
                <ul>
                    <?php if ($avaPrevUrl !== ''): ?>
                    <li class="prev"><a href="<?php echo ava_e($avaPrevUrl); ?>" aria-label="صفحهٔ قبلی"><?php echo ava_icon('chevron-right', 15); ?></a></li>
                    <?php endif; ?>

                    <?php foreach ($avaWindow as $avaN): ?>
                        <?php if ($avaN === '...'): ?>
                        <li><span>…</span></li>
                        <?php elseif ((int) $avaN === (int) $avaPage): ?>
                        <li class="current"><a href="<?php echo ava_e($avaUrls[$avaN]); ?>" aria-current="page"><?php echo ava_fa((string) $avaN); ?></a></li>
                        <?php else: ?>
                        <li><a href="<?php echo ava_e($avaUrls[$avaN]); ?>"><?php echo ava_fa((string) $avaN); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; ?>

                    <?php if ($avaNextUrl !== ''): ?>
                    <li class="next"><a href="<?php echo ava_e($avaNextUrl); ?>" aria-label="صفحهٔ بعدی"><?php echo ava_icon('chevron-left', 15); ?></a></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>

        <?php else: ?>
        <div class="widget" style="text-align:center; padding:48px 24px;">
            <p style="font-weight:700; margin-bottom:8px;">هنوز نوشته‌ای منتشر نشده است</p>
            <p class="text-muted" style="font-size:.9rem;">به‌محض انتشار نخستین نوشته، بایگانی مطالب در همین صفحه نمایش داده می‌شود.</p>
        </div>
        <?php endif; ?>
    </section>
</div>

<?php $this->need('footer.php'); ?>
