(function () {
    'use strict';

    var d = document;
    var root = d.documentElement;

    /* ---------- toast ---------- */
    var toastEl = d.getElementById('avaToast');
    var toastTimer = null;
    function toast(msg) {
        if (!toastEl) return;
        toastEl.textContent = msg;
        toastEl.classList.add('show');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function () {
            toastEl.classList.remove('show');
        }, 2600);
    }

    /* ---------- تم روشن/تاریک ---------- */
    var themeBtn = d.getElementById('themeToggle');
    function applyTheme(next) {
        root.setAttribute('data-theme', next);
        root.classList.toggle('dark', next === 'dark');
        root.style.colorScheme = next;
        try { localStorage.setItem('ava-theme', next); } catch (e) {}
    }
    function syncThemeIcons() {
        if (!themeBtn) return;
        var sun = themeBtn.querySelector('.icon-sun');
        var moon = themeBtn.querySelector('.icon-moon');
        var dark = root.getAttribute('data-theme') === 'dark';
        if (sun) sun.hidden = dark;
        if (moon) moon.hidden = !dark;
    }
    if (themeBtn) {
        themeBtn.addEventListener('click', function () {
            var dark = root.getAttribute('data-theme') === 'dark';
            applyTheme(dark ? 'light' : 'dark');
            syncThemeIcons();
        });
        syncThemeIcons();
    }

    /* ---------- منوی موبایل ---------- */
    var menuBtn = d.getElementById('menuToggle');
    var mobileNav = d.getElementById('mobileNav');
    if (menuBtn && mobileNav) {
        menuBtn.addEventListener('click', function () {
            var open = mobileNav.classList.toggle('open');
            menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
        d.addEventListener('click', function (ev) {
            if (mobileNav.classList.contains('open')
                && !mobileNav.contains(ev.target)
                && !menuBtn.contains(ev.target)) {
                mobileNav.classList.remove('open');
                menuBtn.setAttribute('aria-expanded', 'false');
            }
        });
    }

    /* ---------- جستجوی هدر (فرم همیشه‌نمایان — نیازی به اسکریپت ندارد) ---------- */

    /* ---------- بازگشت به بالا ---------- */
    var backTop = d.getElementById('backToTop');
    if (backTop) {
        window.addEventListener('scroll', function () {
            backTop.classList.toggle('show', window.scrollY > 420);
        }, { passive: true });
        backTop.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    /* ---------- ارقام فارسی ---------- */
    var faMap = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    function faDigits(s) {
        return String(s).replace(/[0-9]/g, function (c) {
            return faMap[+c];
        });
    }

    /* ---------- لایک (پسند) با AJAX ---------- */
    var likeBtn = d.getElementById('likeBtn');
    if (likeBtn) {
        likeBtn.addEventListener('click', function () {
            var cid = parseInt(likeBtn.getAttribute('data-cid'), 10);
            if (!cid || likeBtn.disabled) return;
            likeBtn.disabled = true;

            fetch(window.location.href, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: 'avaLike=' + encodeURIComponent(cid),
                credentials: 'same-origin'
            })
            .then(function (res) { return res.json(); })
            .then(function (data) {
                likeBtn.disabled = false;
                if (data && data.ok) {
                    var countEl = d.getElementById('likeCount');
                    if (countEl) {
                        countEl.textContent = faDigits(String(data.likes));
                    }
                    likeBtn.classList.toggle('liked', !!data.liked);
                    likeBtn.setAttribute('aria-pressed', data.liked ? 'true' : 'false');
                    toast(data.liked ? 'نوشته را پسندیدید — سپاس!' : 'پسند شما برداشته شد');
                } else {
                    toast('خطا در ثبت پسند — دوباره تلاش کنید');
                }
            })
            .catch(function () {
                likeBtn.disabled = false;
                toast('ارتباط با سرور برقرار نشد');
            });
        });
    }

    /* ---------- کپی نشانی نوشته ---------- */
    var copyBtn = d.getElementById('copyLinkBtn');
    if (copyBtn) {
        copyBtn.addEventListener('click', function () {
            var url = copyBtn.getAttribute('data-url') || window.location.href;
            function done() { toast('نشانی نوشته کپی شد'); }
            function fallback() {
                var ta = d.createElement('textarea');
                ta.value = url;
                ta.style.position = 'fixed';
                ta.style.opacity = '0';
                d.body.appendChild(ta);
                ta.select();
                try { d.execCommand('copy'); done(); } catch (e) {}
                d.body.removeChild(ta);
            }
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(url).then(done, fallback);
            } else {
                fallback();
            }
        });
    }

    /* ---------- لایت‌باکس (نمایشگر تصویر) ---------- */
    var lightbox = d.getElementById('avaLightbox');
    if (lightbox) {
        var lbImg = lightbox.querySelector('.lightbox-img');
        var lbCaption = lightbox.querySelector('.lightbox-caption');
        var lbCounter = lightbox.querySelector('.lightbox-counter');
        var lbPrev = lightbox.querySelector('.lightbox-prev');
        var lbNext = lightbox.querySelector('.lightbox-next');
        var lbClose = lightbox.querySelector('.lightbox-close');
        var lbItems = [];
        var lbIndex = 0;

        function collectImages() {
            var items = [];
            var seen = {};
            function push(src, alt) {
                if (!src || seen[src]) return;
                seen[src] = true;
                items.push({ src: src, alt: alt || '' });
            }
            /* آیتم‌های گالری */
            Array.prototype.forEach.call(d.querySelectorAll('.gallery-item'), function (el) {
                var img = el.querySelector('img');
                if (img) {
                    push(el.getAttribute('data-src') || img.getAttribute('src'), el.getAttribute('data-alt') || img.getAttribute('alt'));
                }
            });
            /* تصاویر داخل متن */
            Array.prototype.forEach.call(d.querySelectorAll('.post-content img'), function (img) {
                push(img.getAttribute('src'), img.getAttribute('alt'));
            });
            return items;
        }

        function lbShow(index) {
            if (!lbItems.length) return;
            lbIndex = (index + lbItems.length) % lbItems.length;
            var item = lbItems[lbIndex];
            lbImg.setAttribute('src', item.src);
            lbImg.setAttribute('alt', item.alt);
            if (item.alt) {
                lbCaption.hidden = false;
                lbCaption.textContent = item.alt;
            } else {
                lbCaption.hidden = true;
            }
            lbCounter.hidden = false;
            lbCounter.textContent = faDigits((lbIndex + 1) + ' / ' + lbItems.length);
            lbPrev.hidden = lbItems.length < 2;
            lbNext.hidden = lbItems.length < 2;
        }

        function lbOpen(index) {
            lbItems = collectImages();
            if (!lbItems.length) return;
            lightbox.hidden = false;
            requestAnimationFrame(function () {
                lightbox.classList.add('open');
            });
            lbShow(index);
            d.body.style.overflow = 'hidden';
            lbClose.focus();
        }

        function lbCloseFn() {
            lightbox.classList.remove('open');
            d.body.style.overflow = '';
            setTimeout(function () {
                lightbox.hidden = true;
            }, 260);
        }

        lbClose.addEventListener('click', lbCloseFn);
        lbPrev.addEventListener('click', function () { lbShow(lbIndex - 1); });
        lbNext.addEventListener('click', function () { lbShow(lbIndex + 1); });

        lightbox.addEventListener('click', function (ev) {
            if (ev.target === lightbox) lbCloseFn();
        });

        d.addEventListener('keydown', function (ev) {
            if (!lightbox.classList.contains('open')) return;
            if (ev.key === 'Escape') lbCloseFn();
            else if (ev.key === 'ArrowRight') lbShow(lbIndex - 1); /* در RTL راست = قبلی */
            else if (ev.key === 'ArrowLeft') lbShow(lbIndex + 1);  /* در RTL چپ = بعدی */
        });

        /* کلیک روی آیتم‌های گالری */
        Array.prototype.forEach.call(d.querySelectorAll('.gallery-item'), function (el) {
            el.addEventListener('click', function () {
                var src = el.getAttribute('data-src')
                    || (el.querySelector('img') && el.querySelector('img').getAttribute('src'));
                var idx = 0;
                lbItems = collectImages();
                lbItems.forEach(function (it, k) { if (it.src === src) idx = k; });
                lbOpen(idx);
            });
        });

        /* کلیک روی تصاویر متن (تصاویر گالری درون‌متنی را خودِ آیتم گالری مدیریت می‌کند) */
        Array.prototype.forEach.call(d.querySelectorAll('.post-content img'), function (img) {
            if (img.closest && img.closest('.gallery-item')) return;
            img.addEventListener('click', function () {
                var idx = 0;
                lbItems = collectImages();
                lbItems.forEach(function (it, k) { if (it.src === img.getAttribute('src')) idx = k; });
                lbOpen(idx);
            });
        });
    }

    /* ---------- انیمیشن ورود بخش‌ها ---------- */
    if ('IntersectionObserver' in window) {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (en.isIntersecting) {
                    en.target.classList.add('in');
                    io.unobserve(en.target);
                }
            });
        }, { threshold: 0.08 });
        Array.prototype.forEach.call(d.querySelectorAll('.reveal'), function (el) { io.observe(el); });
    } else {
        Array.prototype.forEach.call(d.querySelectorAll('.reveal'), function (el) { el.classList.add('in'); });
    }

    /* ---------- آواتار دیدگاه‌ها: اول پیش‌فرض سیستم، سپس گراواتار ---------- */
    (function () {
        var gNodes = d.querySelectorAll('[data-gravatar]');
        if (!gNodes.length) { return; }
        Array.prototype.forEach.call(gNodes, function (el) {
            var gUrl = el.getAttribute('data-gravatar');
            if (!gUrl) { return; }
            var probe = new Image();
            probe.referrerPolicy = 'no-referrer';
            probe.onload = function () {
                /* گراواتار موجود و در دسترس — جایگزین پیش‌فرض سیستم */
                el.classList.add('gravatar-on');
                el.textContent = '';
                el.style.backgroundImage = 'url("' + gUrl.replace(/"/g, '%22') + '")';
            };
            probe.onerror = function () {
                /* بدون گراواتار یا بدون دسترسی — پیش‌فرض سیستم باقی می‌ماند */
            };
            probe.src = gUrl;
        });
    })();

    /* ---------- اعداد باقی‌مانده به فارسی ---------- */
    Array.prototype.forEach.call(
        d.querySelectorAll('.farsi-digits time, .farsi-digits .stat-num, .farsi-digits .cat-count, .farsi-digits .comments-count'),
        function (el) {
            var t = el.textContent;
            if (t && /[0-9]/.test(t)) {
                el.textContent = faDigits(t);
            }
        }
    );
})();
