<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');

$showLikes     = ava_on('showLikes', '1');
$showRelated   = ava_on('showRelated', '1');
$showGallery   = ava_on('showGallery', '1');
$showAuthorBox = ava_on('showAuthorBox', '1');
$relatedCount  = max(1, (int) ava_opt('relatedCount', '3'));
$postAuthorName = ava_author_name($this->author);
$postAvatarUrl  = ava_author_avatar_url($this->author);
$authorRole     = (string) ava_opt('authorRole', 'نویسنده و طراح وب‌سایت');

/* نشانی صفحهٔ «دربارهٔ من» — تنها از تنظیمات پوسته (تنظیم «صفحهٔ دربارهٔ من») */
$aboutUrl = ava_about_url();

/* آمار این نوشته */
$postViews  = ava_get_views($this);
$postLikes  = ava_likes($this);
$postLiked  = $showLikes ? ava_is_liked($this->cid) : false;

/* دسته‌های نوشته (در آرشیو، categories آرایه است) */
$postCats = [];
try {
    $rawCats = $this->categories;
    if (! empty($rawCats) && is_array($rawCats)) {
        $postCats = $rawCats;
    }
} catch (Throwable $e) {
    $postCats = [];
}
if (empty($postCats)) {
    $postCats = ava_post_categories((int) $this->cid);
}

/* مسیر (breadcrumb) با دستهٔ نخست */
$crumb = '';
if (! empty($postCats)) {
    $c0 = $postCats[0];
    $crumb = '<a href="' . ava_e($c0['permalink']) . '">' . ava_e($c0['name']) . '</a>'
        . ' <span class="sep">/</span> ';
}

?>
<div class="container">

    <!-- ===== سربرگ ===== -->
    <nav class="breadcrumb" aria-label="مسیر صفحه">
        <a href="<?php $this->options->siteUrl(); ?>">خانه</a>
        <span class="sep">/</span>
        <?php echo $crumb; ?>
        <span class="current"><?php $this->title(); ?></span>
    </nav>

    <div class="home-layout">
        <div class="content-area">

            <!-- ===== نوشته ===== -->
            <article class="single-post">
                <?php
                $thumb = ava_post_thumbnail($this);
                $hasCustomThumb = false;
                try {
                    $hasCustomThumb = trim((string) $this->fields->thumb) !== '';
                } catch (Throwable $e) {
                    $hasCustomThumb = false;
                }
                $firstImg = ava_first_image((string) $this->text);
                if ($hasCustomThumb || ($firstImg !== '' && ava_image_ok($firstImg))):
                ?>
                <div class="single-media">
                    <img src="<?php echo ava_e($thumb); ?>" alt="<?php $this->title(); ?>">
                </div>
                <?php endif; ?>

                <div class="single-body">
                    <?php
                    /* برچسب دسته */
                    if (! empty($postCats)) {
                        $bc = $postCats[0];
                        echo '<a class="' . ava_e(ava_badge_class((int) ($bc['mid'] ?? 0))) . '" href="' . ava_e($bc['permalink']) . '">' . ava_e($bc['name']) . '</a>';
                    }
                    ?>

                    <h1 class="post-title"><?php $this->title(); ?></h1>

                    <div class="post-meta">
                        <span>
                            <?php echo ava_avatar_html($postAuthorName, $postAvatarUrl, 30, 'post-meta-avatar'); ?>
                            <a href="<?php $this->author->permalink(); ?>"><?php echo ava_e($postAuthorName); ?></a>
                        </span>
                        <span><?php echo ava_icon('calendar', 15); ?><?php echo ava_jdate('j F Y', (int) $this->created); ?></span>
                        <?php if (! empty($postCats)): ?>
                        <span class="meta-cats">
                            <?php echo ava_icon('folder', 15); ?>
                            <?php echo implode('، ', array_map(static function ($pc) {
                                return '<a href="' . ava_e($pc['permalink']) . '">' . ava_e($pc['name']) . '</a>';
                            }, $postCats)); ?>
                        </span>
                        <?php endif; ?>
                        <span><?php echo ava_icon('clock', 15); ?><?php echo ava_fa(ava_reading_time($this)); ?> دقیقه مطالعه</span>
                        <span><?php echo ava_icon('eye', 15); ?><?php echo ava_format_count($postViews); ?> بازدید</span>
                        <span><?php echo ava_icon('comment', 15); ?><?php echo ava_format_count((int) $this->commentsNum); ?> دیدگاه</span>
                    </div>

                    <!-- متن نوشته -->
                    <div class="prose-ava post-content" id="postBody" itemprop="articleBody">
                        <?php
                        /* گالری سادهٔ درون‌متنی (مثل مژگان):
                           چند تصویر پشت‌سرهم ← یک گرید بندانگشتی؛ بدون تکرار تصویر */
                        ob_start();
                        $this->content();
                        $postHtml = (string) ob_get_clean();
                        echo $showGallery ? ava_inline_gallery($postHtml) : $postHtml;
                        ?>
                    </div>

                    <?php if ($showLikes): ?>
                    <!-- ===== لایک و اشتراک‌گذاری ===== -->
                    <div class="post-actions">
                        <button type="button" class="like-btn<?php echo $postLiked ? ' liked' : ''; ?>" id="likeBtn"
                                data-cid="<?php echo (int) $this->cid; ?>"
                                aria-label="پسندیدن این نوشته"
                                <?php echo $postLiked ? 'aria-pressed="true"' : 'aria-pressed="false"'; ?>>
                            <?php echo ava_icon('heart', 18); ?>
                            <span>پسندیدم</span>
                            <span class="like-count" id="likeCount"><?php echo ava_format_count($postLikes); ?></span>
                        </button>

                        <div class="share-row">
                            <span class="share-label">اشتراک‌گذاری:</span>
                            <a class="social-link" href="<?php echo ava_e('https://telegram.me/share/url?url=' . rawurlencode($this->permalink) . '&text=' . rawurlencode($this->title)); ?>" target="_blank" rel="noopener" aria-label="اشتراک در تلگرام" title="تلگرام"><?php echo ava_social_icon('send', 17); ?></a>
                            <a class="social-link" href="<?php echo ava_e('https://twitter.com/intent/tweet?url=' . rawurlencode($this->permalink) . '&text=' . rawurlencode($this->title)); ?>" target="_blank" rel="noopener" aria-label="اشتراک در توییتر" title="توییتر"><?php echo ava_social_icon('twitter', 17); ?></a>
                            <button type="button" class="social-link" id="copyLinkBtn" data-url="<?php $this->permalink(); ?>" aria-label="کپی نشانی نوشته" title="کپی نشانی"><?php echo ava_icon('link', 17); ?></button>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php
                    /* برچسب‌ها */
                    try {
                        if ($this->tags && $this->tags->have()) {
                            echo '<div class="tag-row"><span class="tags-label">' . ava_icon('tag', 15) . 'برچسب‌ها:</span>';
                            while ($this->tags->have()) {
                                $this->tags->next();
                                echo '<a class="tag-pill" href="' . ava_e($this->tags->permalink) . '">' . $this->tags->name . '</a>';
                            }
                            echo '</div>';
                        }
                    } catch (Throwable $e) {
                        // نادیده بگیر
                    }
                    ?>

                    <?php if ($showAuthorBox): ?>
                    <!-- ===== باکس نویسنده ===== -->
                    <section class="post-author" aria-label="دربارهٔ نویسنده">
                        <?php echo ava_avatar_html($postAuthorName, $postAvatarUrl, 76); ?>
                        <div>
                            <div class="author-head">
                                <span class="author-name"><?php echo ava_e($postAuthorName); ?></span>
                                <span class="author-role"><?php echo ava_e($authorRole); ?></span>
                            </div>
                            <p class="author-bio"><?php echo ava_e((string) ava_opt('authorBio', '')); ?></p>
                            <?php if ($aboutUrl !== ''): ?>
                            <a href="<?php echo ava_e($aboutUrl); ?>" class="author-link">
                                <?php echo ava_icon('user', 14); ?>
                                نوشته‌های بیشتر از این نویسنده
                            </a>
                            <?php endif; ?>
                        </div>
                    </section>
                    <?php endif; ?>
                </div>
            </article>

            <!-- ===== ناوبری قبلی/بعدی ===== -->
            <?php
            /* بررسی وجود نوشتهٔ قبلی/بعدی برای رندر فقط در صورت نیاز */
            $hasPrev = false;
            $hasNext = false;
            try {
                ob_start();
                $this->thePrev('%s', '');
                $prevHtml = trim((string) ob_get_clean());
                $hasPrev  = ($prevHtml !== '');

                ob_start();
                $this->theNext('%s', '');
                $nextHtml = trim((string) ob_get_clean());
                $hasNext  = ($nextHtml !== '');
            } catch (Throwable $e) {
                $hasPrev = false;
                $hasNext = false;
                $prevHtml = '';
                $nextHtml = '';
            }
            ?>
            <?php if ($hasPrev || $hasNext): ?>
            <nav class="post-navigation" aria-label="ناوبری نوشته‌ها">
                <?php if ($hasPrev): ?>
                <div class="post-nav-card prev">
                    <span class="post-nav-label"><?php echo ava_icon('chevron-right', 14); ?>نوشتهٔ قبلی</span>
                    <span class="post-nav-title"><?php echo $prevHtml; ?></span>
                </div>
                <?php else: ?>
                <span class="post-nav-card"></span>
                <?php endif; ?>
                <?php if ($hasNext): ?>
                <div class="post-nav-card next">
                    <span class="post-nav-label">نوشتهٔ بعدی<?php echo ava_icon('chevron-left', 14); ?></span>
                    <span class="post-nav-title"><?php echo $nextHtml; ?></span>
                </div>
                <?php endif; ?>
            </nav>
            <?php endif; ?>

            <?php if ($showRelated): ?>
            <!-- ===== مطالب مرتبط ===== -->
            <?php
            $relatedPosts = null;
            try {
                $this->related($relatedCount)->to($relatedPosts);
            } catch (Throwable $e) {
                $relatedPosts = null;
            }
            ?>
            <?php if ($relatedPosts && $relatedPosts->have()): ?>
            <section class="related-posts" aria-label="مطالب مرتبط">
                <div class="section-head">
                    <h2 class="section-title">
                        <?php echo ava_icon('link', 18); ?>
                        مطالب مرتبط
                    </h2>
                </div>
                <div class="related-grid">
                    <?php while ($relatedPosts->next()): ?>
                    <article class="post-card">
                        <div class="post-card-media">
                            <a href="<?php $relatedPosts->permalink(); ?>" tabindex="-1" aria-hidden="true">
                                <img src="<?php echo ava_e(ava_post_thumbnail($relatedPosts)); ?>" alt="<?php $relatedPosts->title(); ?>" loading="lazy" decoding="async">
                            </a>
                        </div>
                        <div class="post-card-body">
                            <h3 class="post-card-title"><a href="<?php $relatedPosts->permalink(); ?>"><?php $relatedPosts->title(); ?></a></h3>
                            <footer class="post-card-meta">
                                <span><?php echo ava_icon('calendar', 14); ?><?php echo ava_jdate('j F Y', (int) $relatedPosts->created); ?></span>
                                <span><?php echo ava_icon('eye', 14); ?><?php echo ava_format_count(ava_get_views($relatedPosts)); ?> بازدید</span>
                            </footer>
                        </div>
                    </article>
                    <?php endwhile; ?>
                </div>
            </section>
            <?php endif; ?>
            <?php endif; ?>

            <!-- ===== دیدگاه‌ها ===== -->
            <?php $this->need('comments.php'); ?>
        </div>

        <?php $this->need('sidebar.php'); ?>
    </div>
</div>

<?php $this->need('footer.php'); ?>
