<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');
?>
<div class="container">
    <div class="error-wrap animate-fade-up">
        <div class="error-code">۴۰۴</div>
        <h1 class="error-title">این صفحه پیدا نشد</h1>
        <p class="error-desc">
            صفحه‌ای که دنبالش بودید جابه‌جا یا حذف شده است.
            نگران نباشید — از این‌جا می‌توانید به مسیر درست برگردید.
        </p>
        <div class="hero-actions" style="justify-content:center;">
            <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-primary">
                <?php echo ava_icon('home', 16); ?>
                بازگشت به خانه
            </a>
            <form class="search-form" action="<?php $this->options->siteUrl(); ?>" method="post" role="search" style="max-width:320px;">
                <input type="text" name="s" placeholder="جستجو در وبلاگ…" aria-label="جستجو در وبلاگ">
                <button class="btn btn-outline btn-sm" type="submit"><?php echo ava_icon('search', 15); ?></button>
            </form>
        </div>
    </div>
</div>

<?php $this->need('footer.php'); ?>
