<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$footerDesc = trim((string) ava_opt('footerDesc', 'نویسنده، طراح و وبلاگ‌نویس. جایی برای به اشتراک‌گذاری تجربه‌ها و دانسته‌ها درباره فناوری، طراحی و زندگی.'));
$brandName  = (string) ava_opt('brandName', 'آوا');
$brandSub   = trim((string) ava_opt('brandSub', 'وبلاگ شخصی'));
$copyright  = trim((string) ava_opt('copyright', ''));

/* لوگوی تصویری سایت (تنظیم siteLogo) — در صورت خالی‌بودن، نشان پیش‌فرض */
$siteLogoUrl = ava_site_logo_url();

/* شبکه‌های اجتماعی از تنظیمات */
$ava_socials = [
    ['socialTelegram', 'telegram', 'تلگرام'],
    ['socialInstagram', 'instagram', 'اینستاگرام'],
    ['socialTwitter', 'twitter', 'توییتر'],
    ['socialGithub', 'github', 'گیت‌هاب'],
    ['socialLinkedin', 'linkedin', 'لینکدین'],
    ['socialEmail', 'mail', 'ایمیل'],
];
?>
    </main>

    <footer class="site-footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <a href="<?php $this->options->siteUrl(); ?>" class="brand" aria-label="<?php $this->options->title(); ?>">
                        <?php if ($siteLogoUrl !== ''): ?>
                        <img class="brand-logo" src="<?php echo ava_e($siteLogoUrl); ?>" alt="<?php echo ava_e($brandName); ?>" width="170" height="42" decoding="async" onerror="this.style.display=&#39;none&#39;;var f=this.nextElementSibling;if(f){f.style.display=&#39;&#39;;}">
                        <span class="brand-mark" style="display:none">
                            <?php echo ava_icon('sparkles', 22); ?>
                        </span>
                        <?php else: ?>
                        <span class="brand-mark">
                            <?php echo ava_icon('sparkles', 22); ?>
                        </span>
                        <?php endif; ?>
                        <span class="brand-text">
                            <span class="brand-name"><?php echo ava_e($brandName); ?></span>
                            <?php if ($brandSub !== ''): ?>
                            <span class="brand-sub"><?php echo ava_e($brandSub); ?></span>
                            <?php endif; ?>
                        </span>
                    </a>
                    <?php if ($footerDesc !== ''): ?>
                    <p class="footer-desc"><?php echo ava_e($footerDesc); ?></p>
                    <?php endif; ?>
                </div>

                <div class="footer-social-col">
                    <div class="footer-social-label">از من چه خبر؟</div>
                    <div class="footer-social">
                        <?php
                        $hasSocial = false;
                        foreach ($ava_socials as [$key, $icon, $label]) {
                            $url = trim((string) ava_opt($key, ''));
                            if ($url === '') {
                                continue;
                            }
                            $hasSocial = true;
                            $href = $key === 'socialEmail'
                                ? (preg_match('/^mailto:/i', $url) ? $url : 'mailto:' . $url)
                                : ava_resolve_url($url);
                            echo '<a href="' . ava_e($href) . '" class="social-link" aria-label="' . ava_e($label) . '" title="' . ava_e($label) . '"'
                                . ($key === 'socialEmail' ? '' : ' target="_blank" rel="noopener"') . '>'
                                . ava_social_icon($icon, 19) . '</a>';
                        }
                        if (! $hasSocial) {
                            echo '<a href="' . ava_e(ava_resolve_url('/feed')) . '" class="social-link" aria-label="خوراک RSS" title="خوراک RSS">' . ava_icon('rss', 19) . '</a>';
                        }
                        ?>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <div>
                    <?php if ($copyright !== ''): ?>
                        <?php echo ava_e($copyright); ?>
                    <?php else: ?>
                        © <?php echo ava_jdate('Y', time()); ?> <?php $this->options->title(); ?> —
                        ساخته شده با <span class="heart"><?php echo ava_icon('heart', 13); ?></span>
                    <?php endif; ?>
                </div>
                <div>قدرت‌گرفته از <a href="https://typerenew.ir" target="_blank" rel="noopener">TypeRenew</a></div>
            </div>
        </div>
    </footer>
</div>

<!-- نمایشگر تصویر (لایت‌باکس) -->
<div class="lightbox" id="avaLightbox" hidden role="dialog" aria-modal="true" aria-label="نمایش تصویر">
    <button type="button" class="lightbox-close" aria-label="بستن"><?php echo ava_icon('x', 22); ?></button>
    <button type="button" class="lightbox-nav lightbox-prev" aria-label="تصویر قبلی" hidden><?php echo ava_icon('chevron-right', 26); ?></button>
    <figure class="lightbox-figure">
        <img class="lightbox-img" src="" alt="">
        <figcaption class="lightbox-caption" hidden></figcaption>
    </figure>
    <button type="button" class="lightbox-nav lightbox-next" aria-label="تصویر بعدی" hidden><?php echo ava_icon('chevron-left', 26); ?></button>
    <span class="lightbox-counter" dir="ltr" hidden></span>
</div>

<button type="button" class="back-to-top" id="backToTop" aria-label="بازگشت به بالای صفحه" title="بازگشت به بالا">
    <?php echo ava_icon('arrow-up', 19); ?>
</button>

<div class="toast" id="avaToast" role="status" aria-live="polite"></div>

<?php $this->footer(); ?>

<script src="<?php echo ava_e(ava_theme_url('js/main.js')); ?>?v=<?php echo AVA_VERSION; ?>" defer></script>
</body>
</html>
