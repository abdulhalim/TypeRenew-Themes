<?php
/**
 * آوا — پوسته شخصی برای وبلاگ‌نویسی ساده
 *
 * @package آوا
 * @author  پوردریایی
 * @version 1.0.0
 * @link    https://pourdaryaei.ir
 */

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');

/* تنظیمات بخش‌ها */
$showHero     = ava_on('heroShow', '1');
$showStats    = ava_on('showStats', '1');
$showFeatured = ava_on('showFeatured', '1');
$showSidebar  = ava_on('showSidebar', '1');
$showPromo    = ava_on('promoShow', '1');
$showLikes    = ava_on('showLikes', '1');

/* نشانی برگه‌های انتخابی از تنظیمات پوسته */
$aboutUrl   = ava_about_url();
$archiveUrl = ava_archive_url();

/* هویت نویسنده */
$authorName  = (string) ava_opt('authorName', 'آوا');
$authorRole  = (string) ava_opt('authorRole', 'نویسنده و طراح وب‌سایت');
$authorBio   = (string) ava_opt('authorBio', 'عاشق فناوری، طراحی و نویسندگی. قصد دارم تجربه‌ام و دانشم را با شما به اشتراک بگذارم.');
$avatarUrl   = ava_author_avatar_url();

/* هیرو */
$heroBadge    = (string) ava_opt('heroBadge', 'خوش آمدید به دنیای وبلاگ‌نویسی');
$heroTitle    = (string) ava_opt('heroTitle', 'سلام، من آوا هستم');
$heroDesc     = (string) ava_opt('heroDesc', 'عاشق فناوری، طراحی و نویسندگی هستم. در این وبلاگ تجربه‌ها، یادگیری‌ها و کشفیاتم را درباره دنیای وب و زندگی دیجیتال با شما به اشتراک می‌گذارم.');
$heroArchiveText    = trim((string) ava_opt('heroArchiveText', 'آرشیو کامل'));
$heroAboutText      = trim((string) ava_opt('heroAboutText', 'درباره من'));

/* هایلایت نام نویسنده در عنوان */
$heroTitleHtml = ava_e($heroTitle);
if ($authorName !== '' && mb_strpos($heroTitle, $authorName, 0, 'UTF-8') !== false) {
    $heroTitleHtml = ava_e(str_replace($authorName, '§AVA§', $heroTitle));
    $heroTitleHtml = str_replace('§AVA§', '<span class="hl">' . ava_e($authorName) . '</span>', $heroTitleHtml);
}

/* صفحهٔ نخست؟ (هیرو فقط در نخستین صفحه) */
$isFirstPage = true;
try {
    $isFirstPage = ((int) $this->getCurrentPage() <= 1);
} catch (Throwable $e) {
    $isFirstPage = true;
}

/* نوشتهٔ ویژه: جدیدترین نوشته (فقط صفحهٔ اول) */
$featured = null;
$featuredViews = 0;
$featuredLikes = 0;
if ($showFeatured && $isFirstPage && $this->have()) {
    try {
        $this->widget('Widget_Contents_Post_Recent@ava-featured', 'pageSize=1')->to($featured);
        if ($featured && $featured->have()) {
            $featured->next();
            $featuredViews = ava_get_views($featured);
            $featuredLikes = ava_likes($featured);
        }
    } catch (Throwable $e) {
        $featured = null;
    }
}
?>

<div class="container">

<?php if ($isFirstPage && $showHero): ?>
<!-- ===== هیرو ===== -->
<section class="hero animate-fade-up">
    <div class="hero-inner">
        <div class="hero-text">
            <?php if ($heroBadge !== ''): ?>
            <span class="hero-badge">
                <?php echo ava_icon('sparkles', 15); ?>
                <?php echo ava_e($heroBadge); ?>
            </span>
            <?php endif; ?>
            <h1 class="hero-title"><?php echo $heroTitleHtml; ?></h1>
            <?php if ($heroDesc !== ''): ?>
            <p class="hero-desc"><?php echo ava_e($heroDesc); ?></p>
            <?php endif; ?>
            <div class="hero-actions">
                <?php if ($heroArchiveText !== ''): ?>
                <a href="<?php echo ava_e($archiveUrl !== '' ? $archiveUrl : $this->options->siteUrl); ?>" class="btn btn-primary">
                    <?php echo ava_icon('archive', 16); ?>
                    <?php echo ava_e($heroArchiveText); ?>
                    <?php echo ava_icon('arrow-left', 16); ?>
                </a>
                <?php endif; ?>
                <?php if ($heroAboutText !== '' && $aboutUrl !== ''): ?>
                <a href="<?php echo ava_e($aboutUrl); ?>" class="btn btn-outline">
                    <?php echo ava_icon('user', 16); ?>
                    <?php echo ava_e($heroAboutText); ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="hero-media">
            <img class="hero-avatar" src="<?php echo ava_e($avatarUrl); ?>" alt="<?php echo ava_e($authorName); ?>" width="190" height="190">
        </div>
    </div>
</section>
<?php endif; ?>

<?php if ($isFirstPage && $showStats): ?>
<!-- ===== نوار آمار ===== -->
<?php
$stats = ava_stats();
$statItems = [
    ['file-text', '',      $stats['posts'], 'نوشته'],
    ['eye',       't2',    $stats['views'], 'بازدید'],
    ['heart',     't3',    $stats['likes'], 'لایک'],
    ['tag',       't4',    $stats['categories'], 'دسته‌بندی'],
];
?>
<section class="stats-bar animate-fade-up">
    <?php foreach ($statItems as [$icon, $cls, $num, $label]): ?>
    <div class="stat-item">
        <span class="stat-icon <?php echo ava_e($cls); ?>"><?php echo ava_icon($icon, 22); ?></span>
        <div>
            <div class="stat-num"><?php echo ava_format_count($num); ?></div>
            <div class="stat-label"><?php echo ava_e($label); ?></div>
        </div>
    </div>
    <?php endforeach; ?>
</section>
<?php endif; ?>

<?php if ($featured && $showFeatured && $isFirstPage): ?>
<!-- ===== نوشتهٔ ویژه ===== -->
<section class="featured-wrap animate-fade-up">
    <div class="section-head">
        <h2 class="section-title">
            <?php echo ava_icon('sparkles', 19); ?>
            جدیدترین نوشته
        </h2>
    </div>
    <article class="featured-post">
        <div class="featured-media">
            <a href="<?php $featured->permalink(); ?>" tabindex="-1" aria-hidden="true">
                <img src="<?php echo ava_e(ava_post_thumbnail($featured)); ?>" alt="<?php $featured->title(); ?>" loading="lazy" decoding="async">
            </a>
            <?php
            /* برچسب نخستین دسته روی تصویر */
            $featuredCats = ava_post_categories((int) $featured->cid);
            if (! empty($featuredCats)) {
                $fc = $featuredCats[0];
                echo '<a class="badge on-image ' . ava_e(str_replace('badge ', '', ava_badge_class($fc['mid'])))
                    . '" href="' . ava_e($fc['permalink']) . '">' . ava_e($fc['name']) . '</a>';
            }
            ?>
        </div>
        <div class="featured-body">
            <span class="badge b-soft">
                <?php echo ava_jdate('j F Y', (int) $featured->created); ?>
            </span>
            <h2 class="featured-title"><a href="<?php $featured->permalink(); ?>"><?php $featured->title(); ?></a></h2>
            <?php $featuredExcerpt = ava_excerpt_chars($featured, 150); ?>
            <?php if ($featuredExcerpt !== ''): ?>
            <p class="post-card-excerpt featured-excerpt"><?php echo ava_e($featuredExcerpt); ?></p>
            <?php endif; ?>
            <div class="meta-row">
                <span><?php echo ava_icon('calendar', 15); ?><?php echo ava_jdate('Y/m/d', (int) $featured->created); ?></span>
                <span><?php echo ava_icon('user', 15); ?><?php $featured->author(); ?></span>
                <span><?php echo ava_icon('clock', 15); ?><?php echo ava_fa(ava_reading_time($featured)); ?> دقیقه مطالعه</span>
                <span><?php echo ava_icon('eye', 15); ?><?php echo ava_format_count($featuredViews); ?> بازدید</span>
                <span><?php echo ava_icon('comment', 15); ?><?php echo ava_format_count((int) $featured->commentsNum); ?> نظر</span>
                <?php if ($showLikes): ?>
                <span><?php echo ava_icon('heart', 15); ?><?php echo ava_format_count($featuredLikes); ?> لایک</span>
                <?php endif; ?>
            </div>
            <a href="<?php $featured->permalink(); ?>" class="btn btn-primary">
                ادامه مطلب
                <?php echo ava_icon('arrow-left', 16); ?>
            </a>
        </div>
    </article>
</section>
<?php endif; ?>

<!-- ===== گرید نوشته‌ها + سایدبار ===== -->
<div class="home-layout<?php echo $showSidebar ? '' : ' home-layout--full'; ?>">
    <div class="content-area">
        <section aria-label="نوشته‌های اخیر">
            <div class="section-head">
                <h2 class="section-title">
                    <?php echo ava_icon('book-open', 18); ?>
                    <?php echo $isFirstPage ? 'نوشته‌های اخیر' : 'صفحهٔ ' . ava_fa((string) $this->getCurrentPage()); ?>
                </h2>
                <?php if ($isFirstPage): ?>
                <a href="<?php echo ava_e($archiveUrl !== '' ? $archiveUrl : $this->options->siteUrl); ?>" class="section-link">
                    همه نوشته‌ها
                    <?php echo ava_icon('arrow-left', 15); ?>
                </a>
                <?php endif; ?>
            </div>

            <?php if ($this->have()): ?>
            <div class="posts-grid">
                <?php while ($this->next()): ?>
                <?php
                /* رد کردن نوشتهٔ ویژه از گرید (صفحهٔ اول) */
                if ($featured && $isFirstPage && (int) $this->cid === (int) $featured->cid) {
                    continue;
                }
                /* دستهٔ نخست برای برچسب روی تصویر (categories در آرشیو آرایه است) */
                $catBadge = '';
                try {
                    $gridCats = $this->categories;
                    if (! empty($gridCats) && is_array($gridCats)) {
                        $gc = $gridCats[0];
                        $catBadge = '<a class="badge on-image ' . ava_e(str_replace('badge ', '', ava_badge_class((int) ($gc['mid'] ?? 0))))
                            . '" href="' . ava_e($gc['permalink']) . '">' . ava_e($gc['name']) . '</a>';
                    }
                } catch (Throwable $e) {
                    $catBadge = '';
                }
                ?>
                <article class="post-card">
                    <div class="post-card-media">
                        <a href="<?php $this->permalink(); ?>" tabindex="-1" aria-hidden="true">
                            <img src="<?php echo ava_e(ava_post_thumbnail($this)); ?>" alt="<?php $this->title(); ?>" loading="lazy" decoding="async">
                        </a>
                        <?php echo $catBadge; ?>
                    </div>
                    <div class="post-card-body">
                        <h3 class="post-card-title"><a href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a></h3>
                        <?php $cardExcerpt = ava_excerpt($this, 24); ?>
                        <?php if ($cardExcerpt !== ''): ?>
                        <p class="post-card-excerpt"><?php echo ava_e($cardExcerpt); ?></p>
                        <?php endif; ?>
                        <footer class="post-card-meta">
                            <span><?php echo ava_icon('calendar', 14); ?><?php echo ava_jdate('j F Y', (int) $this->created); ?></span>
                            <span><?php echo ava_icon('user', 14); ?><?php $this->author(); ?></span>
                            <?php if ($showLikes): ?>
                            <span><?php echo ava_icon('heart', 14); ?><?php echo ava_format_count(ava_likes($this)); ?></span>
                            <?php endif; ?>
                            <span><?php echo ava_icon('comment', 14); ?><?php echo ava_format_count((int) $this->commentsNum); ?> نظر</span>
                        </footer>
                    </div>
                </article>
                <?php endwhile; ?>
            </div>

            <nav class="pagination" aria-label="ناوبری صفحات">
                <?php $this->pageNav(
                    ava_icon('chevron-right', 16),
                    ava_icon('chevron-left', 16),
                    3,
                    '…',
                    ['wrapTag' => 'ul', 'wrapClass' => '', 'itemTag' => 'li', 'textTag' => 'span', 'currentClass' => 'current', 'prevClass' => 'prev', 'nextClass' => 'next']
                ); ?>
            </nav>

            <?php else: ?>
            <div class="widget" style="text-align:center; padding:48px 24px;">
                <p style="font-weight:700; margin-bottom:8px;">هنوز نوشته‌ای منتشر نشده است</p>
                <p class="text-muted" style="font-size:.9rem;">اولین نوشتهٔ خود را از پیشخوان منتشر کنید تا این‌جا نمایش داده شود.</p>
            </div>
            <?php endif; ?>
        </section>
    </div>

    <?php if ($showSidebar): ?>
    <?php $this->need('sidebar.php'); ?>
    <?php endif; ?>
</div>

<?php if ($showPromo && $isFirstPage): ?>
<!-- ===== نوار اقدام ===== -->
<?php
$promoTitle   = (string) ava_opt('promoTitle', 'دانلود پوسته آوا');
$promoDesc    = (string) ava_opt('promoDesc', 'نسخه کامل قالب وبلاگ · نسخه ۱٫۰٫۰ · فرمت ZIP');
$promoBtnText = (string) ava_opt('promoBtnText', 'دانلود رایگان');
$promoBtnUrl  = trim((string) ava_opt('promoBtnUrl', ''));
?>
<section class="promo-bar animate-fade-up">
    <span class="promo-icon">
        <?php echo ava_icon('download', 24); ?>
    </span>
    <div class="promo-body">
        <div class="promo-title"><?php echo ava_e($promoTitle); ?></div>
        <?php if ($promoDesc !== ''): ?>
        <div class="promo-desc"><?php echo ava_e($promoDesc); ?></div>
        <?php endif; ?>
    </div>
    <?php if ($promoBtnText !== ''): ?>
    <a href="<?php echo ava_e($promoBtnUrl !== '' ? ava_resolve_url($promoBtnUrl) : $this->options->siteUrl); ?>" class="btn btn-primary">
        <?php echo ava_icon('download', 16); ?>
        <?php echo ava_e($promoBtnText); ?>
    </a>
    <?php endif; ?>
</section>
<?php endif; ?>

</div><!-- /.container -->

<?php $this->need('footer.php'); ?>
