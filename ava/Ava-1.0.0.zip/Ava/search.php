<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');

/* عبارت جستجو */
$keywords = '';
try {
    $keywords = (string) $this->request->filter('search')->get('keywords');
} catch (Throwable $e) {
    $keywords = '';
}
if ($keywords === '') {
    try {
        ob_start();
        $this->archiveTitle([], '', '');
        $raw = trim((string) ob_get_clean());
        /* «کلیدواژه: xxx» استخراج می‌شود */
        if (mb_strpos($raw, ':') !== false) {
            $keywords = trim(mb_substr($raw, mb_strpos($raw, ':') + 1));
        } else {
            $keywords = $raw;
        }
    } catch (Throwable $e) {
        $keywords = '';
    }
}
?>
<div class="container">

    <div class="archive-head animate-fade-up">
        <span class="archive-head-icon">
            <?php echo ava_icon('search', 22); ?>
        </span>
        <div>
            <h1 class="archive-head-title">نتایج جستجو<?php if ($keywords !== ''): ?>: «<?php echo ava_e($keywords); ?>»<?php endif; ?></h1>
            <div class="archive-head-desc">نوشته‌های منطبق با عبارت شما</div>
        </div>
    </div>

    <div class="home-layout">
        <div class="content-area">
            <?php if ($this->have()): ?>
            <div class="posts-grid">
                <?php while ($this->next()): ?>
                <article class="post-card">
                    <div class="post-card-media">
                        <a href="<?php $this->permalink(); ?>" tabindex="-1" aria-hidden="true">
                            <img src="<?php echo ava_e(ava_post_thumbnail($this)); ?>" alt="<?php $this->title(); ?>" loading="lazy" decoding="async">
                        </a>
                    </div>
                    <div class="post-card-body">
                        <h3 class="post-card-title"><a href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a></h3>
                        <p class="post-card-excerpt"><?php echo ava_e(ava_excerpt($this, 24)); ?></p>
                        <footer class="post-card-meta">
                            <span><?php echo ava_icon('calendar', 14); ?><?php echo ava_jdate('j F Y', (int) $this->created); ?></span>
                            <span><?php echo ava_icon('user', 14); ?><?php $this->author(); ?></span>
                        </footer>
                    </div>
                </article>
                <?php endwhile; ?>
            </div>

            <nav class="pagination" aria-label="ناوبری صفحات">
                <?php $this->pageNav(
                    ava_icon('chevron-right', 16),
                    ava_icon('chevron-left', 16),
                    3,
                    '…',
                    ['wrapTag' => 'ul', 'wrapClass' => '', 'itemTag' => 'li', 'textTag' => 'span', 'currentClass' => 'current', 'prevClass' => 'prev', 'nextClass' => 'next']
                ); ?>
            </nav>

            <?php else: ?>
            <div class="widget" style="text-align:center; padding:48px 24px;">
                <span style="color:var(--primary); margin-bottom:12px; display:inline-grid;">
                    <?php echo ava_icon('search', 44); ?>
                </span>
                <p style="font-weight:700; margin-bottom:8px;">چیزی پیدا نشد!</p>
                <p class="text-muted" style="font-size:.9rem;">عبارت دیگری را امتحان کنید یا از فهرست دسته‌بندی‌ها استفاده کنید.</p>
                <form class="search-form" action="<?php $this->options->siteUrl(); ?>" method="post" role="search" style="margin-top:18px; max-width:420px; margin-inline:auto;">
                    <input type="text" name="s" placeholder="جستجوی جدید…" aria-label="جستجوی جدید" value="<?php echo ava_e($keywords); ?>">
                    <button class="btn btn-primary btn-sm" type="submit"><?php echo ava_icon('search', 15); ?></button>
                </form>
            </div>
            <?php endif; ?>
        </div>

        <?php $this->need('sidebar.php'); ?>
    </div>
</div>

<?php $this->need('footer.php'); ?>
