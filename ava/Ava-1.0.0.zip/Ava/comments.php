<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
?>
<div id="comments" class="comments-area">

    <div class="comments-header">
        <h2 class="comments-title">
            <?php echo ava_icon('comment', 20); ?>
            دیدگاه‌ها
            <span class="count-badge">
                <?php $this->commentsNum(_t('۰'), _t('۱'), _t('%d')); ?>
            </span>
        </h2>
    </div>

    <?php $this->comments()->to($comments); ?>

    <?php if ($comments->have()): ?>
    <div class="comments-body">
        <?php
        /* اعداد فارسی در فهرست دیدگاه‌ها */
        ob_start();
        $comments->listComments([
            'before'        => '<ol class="comment-list">',
            'after'         => '</ol>',
            'commentStatus' => _t('در انتظار تأیید'),
        ]);
        $listHtml = (string) ob_get_clean();
        /* اعداد فارسی فقط در متن‌ها — نشانی‌ها/صفت‌ها (مثل src="...avatar-480.png")
           هرگز فارسی نمی‌شوند؛ در غیر این صورت درخواست به روتر می‌رسد و
           Fatal Error: Router Exception می‌گیرد */
        echo ava_fa_html($listHtml);
        ?>

        <?php
        ob_start();
        $comments->pageNav(
            ava_icon('chevron-right', 15),
            ava_icon('chevron-left', 15),
            3,
            '…',
            ['wrapTag' => 'ul', 'wrapClass' => '', 'itemTag' => 'li', 'textTag' => 'span', 'currentClass' => 'current', 'prevClass' => 'prev', 'nextClass' => 'next']
        );
        $navHtml = (string) ob_get_clean();
        if (trim($navHtml) !== '') {
            echo '<nav class="pagination" style="margin-top:20px;">' . ava_fa_html($navHtml) . '</nav>';
        }
        ?>
    </div>
    <?php endif; ?>

    <?php if ($this->allow('comment')): ?>
    <div id="<?php $this->respondId(); ?>" class="respond">
        <div class="cancel-comment-reply">
            <?php $comments->cancelReply(); ?>
        </div>

        <h3 id="response" class="respond-title"><?php _e('دیدگاه خود را بنویسید'); ?></h3>

        <form method="post" action="<?php $this->commentUrl(); ?>" id="comment-form" role="form" class="comment-form">
            <?php
            /* توکن امنیتی */
            try {
                $security = \Widget\Security::alloc();
                $token    = $security->getToken($this->request->getRequestUrl());
            } catch (Throwable $e) {
                $token = '';
            }
            ?>
            <?php if ($token !== ''): ?>
            <input type="hidden" name="_" value="<?php echo ava_e($token); ?>">
            <?php endif; ?>

            <?php if ($this->user->hasLogin()): ?>
            <p class="comment-logged-in">
                <?php _e('ورود با حساب'); ?>:
                <a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>
                <a class="comment-logout" href="<?php $this->options->logoutUrl(); ?>"><?php _e('خروج'); ?></a>
            </p>
            <?php else: ?>
            <div class="comment-form-fields">
                <input type="text" name="author" id="author" placeholder="نام شما *" value="" required aria-label="نام شما">
                <input type="email" name="mail" id="mail" placeholder="ایمیل *" value="" required aria-label="ایمیل شما"
                       <?php if ($this->options->commentsRequireMail): ?>required<?php endif; ?>>
                <input type="url" name="url" id="url" placeholder="وب‌سایت (اختیاری)" value="" aria-label="وب‌سایت شما">
            </div>
            <?php endif; ?>

            <textarea name="text" id="textarea" class="comment-textarea" placeholder="دیدگاه شما… (حداقل ۲ کاراکتر)" required aria-label="متن دیدگاه"></textarea>

            <button type="submit" class="btn btn-primary">
                <?php echo ava_icon('send', 16); ?>
                ارسال دیدگاه
            </button>
        </form>
    </div>
    <?php else: ?>
    <div class="respond" style="text-align:center;">
        <p class="text-muted" style="font-size:.92rem;">
            <?php echo ava_icon('alert', 16); ?>
            دیدگاه‌های این نوشته بسته شده‌اند.
        </p>
    </div>
    <?php endif; ?>
</div>
