<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');

/* مشخصات آرشیو */
$arcTitle = 'آرشیو';
$arcDesc  = '';
$arcIcon  = 'book-open';

try {
    if ($this->is('category')) {
        $arcTitle = 'دسته‌بندی';
        $arcIcon  = 'folder';
        $arcDesc  = 'همهٔ نوشته‌های این دسته';
    } elseif ($this->is('tag')) {
        $arcTitle = 'برچسب';
        $arcIcon  = 'tag';
        $arcDesc  = 'نوشته‌های دارای این برچسب';
    } elseif ($this->is('author')) {
        $arcTitle = 'نویسنده: ' . ava_author_name($this->author);
        $arcIcon  = 'user';
        $arcDesc  = 'نوشته‌های این نویسنده';
    } elseif ($this->is('date')) {
        $arcTitle = 'آرشیو زمانی';
        $arcIcon  = 'calendar';
        $arcDesc  = 'نوشته‌های این بازهٔ زمانی';
    }
} catch (Throwable $e) {
    // پیش‌فرض
}

/* عنوان دقیق از خود آرشیو */
try {
    ob_start();
    $this->archiveTitle([], '', '');
    $archiveTitleRaw = trim((string) ob_get_clean());
    if ($archiveTitleRaw !== '' && ! $this->is('author')) {
        $arcTitle = $archiveTitleRaw;
    }
} catch (Throwable $e) {
    // نگه‌داشتن پیش‌فرض
}
?>
<div class="container">

    <div class="archive-head animate-fade-up">
        <span class="archive-head-icon">
            <?php echo ava_icon($arcIcon, 22); ?>
        </span>
        <div>
            <h1 class="archive-head-title"><?php echo ava_e($arcTitle); ?></h1>
            <?php if ($arcDesc !== ''): ?>
            <div class="archive-head-desc"><?php echo ava_e($arcDesc); ?></div>
            <?php endif; ?>
        </div>
    </div>

    <div class="home-layout">
        <div class="content-area">
            <?php if ($this->have()): ?>
            <div class="posts-grid">
                <?php while ($this->next()): ?>
                <?php
                $catBadge = '';
                try {
                    if ($this->categories && $this->categories->have()) {
                        $this->categories->next();
                        $catBadge = '<a class="badge on-image ' . ava_e(str_replace('badge ', '', ava_badge_class($this->categories->mid))) . '" href="'
                            . ava_e($this->categories->permalink) . '">' . $this->categories->name . '</a>';
                    }
                } catch (Throwable $e) {
                    $catBadge = '';
                }
                ?>
                <article class="post-card">
                    <div class="post-card-media">
                        <a href="<?php $this->permalink(); ?>" tabindex="-1" aria-hidden="true">
                            <img src="<?php echo ava_e(ava_post_thumbnail($this)); ?>" alt="<?php $this->title(); ?>" loading="lazy" decoding="async">
                        </a>
                        <?php echo $catBadge; ?>
                    </div>
                    <div class="post-card-body">
                        <h3 class="post-card-title"><a href="<?php $this->permalink(); ?>"><?php $this->title(); ?></a></h3>
                        <p class="post-card-excerpt"><?php echo ava_e(ava_excerpt($this, 24)); ?></p>
                        <footer class="post-card-meta">
                            <span><?php echo ava_icon('calendar', 14); ?><?php echo ava_jdate('j F Y', (int) $this->created); ?></span>
                            <span><?php echo ava_icon('user', 14); ?><?php $this->author(); ?></span>
                            <span><?php echo ava_icon('eye', 14); ?><?php echo ava_format_count(ava_get_views($this)); ?> بازدید</span>
                            <span><?php echo ava_icon('comment', 14); ?><?php echo ava_format_count((int) $this->commentsNum); ?> نظر</span>
                        </footer>
                    </div>
                </article>
                <?php endwhile; ?>
            </div>

            <nav class="pagination" aria-label="ناوبری صفحات">
                <?php $this->pageNav(
                    ava_icon('chevron-right', 16),
                    ava_icon('chevron-left', 16),
                    3,
                    '…',
                    ['wrapTag' => 'ul', 'wrapClass' => '', 'itemTag' => 'li', 'textTag' => 'span', 'currentClass' => 'current', 'prevClass' => 'prev', 'nextClass' => 'next']
                ); ?>
            </nav>

            <?php else: ?>
            <div class="widget" style="text-align:center; padding:48px 24px;">
                <p style="font-weight:700; margin-bottom:8px;">نوشته‌ای یافت نشد</p>
                <p class="text-muted" style="font-size:.9rem;">برای این آرشیو هنوز محتوایی منتشر نشده است.</p>
                <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-primary btn-sm" style="margin-top:14px;">
                    <?php echo ava_icon('home', 15); ?>
                    بازگشت به خانه
                </a>
            </div>
            <?php endif; ?>
        </div>

        <?php $this->need('sidebar.php'); ?>
    </div>
</div>

<?php $this->need('footer.php'); ?>
