<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$authorName = (string) ava_opt('authorName', 'آوا');
$authorRole = (string) ava_opt('authorRole', 'نویسنده و طراح وب‌سایت');
$authorBio  = (string) ava_opt('authorBio', 'عاشق فناوری، طراحی و نویسندگی. قصد دارم تجربه‌ام و دانشم را با شما به اشتراک بگذارم.');
$avatarUrl  = ava_author_avatar_url();

/* نشانی صفحهٔ «دربارهٔ من» — تنها از تنظیمات پوسته (تنظیم «صفحهٔ دربارهٔ من») */
$aboutUrl = ava_about_url();
?>
<aside class="sidebar" aria-label="نوار کناری">

    <!-- جعبهٔ نویسنده -->
    <section class="widget author-box">
        <?php echo ava_avatar_html($authorName, $avatarUrl, 92); ?>
        <div class="author-name"><?php echo ava_e($authorName); ?></div>
        <?php if ($authorRole !== ''): ?>
        <div class="author-role"><?php echo ava_e($authorRole); ?></div>
        <?php endif; ?>
        <?php if ($authorBio !== ''): ?>
        <p class="author-bio"><?php echo ava_e($authorBio); ?></p>
        <?php endif; ?>
        <?php if ($aboutUrl !== ''): ?>
        <a href="<?php echo ava_e($aboutUrl); ?>" class="btn btn-outline btn-block btn-sm">
            <?php echo ava_icon('user', 15); ?>
            درباره من
        </a>
        <?php endif; ?>
    </section>

    <!-- دسته‌بندی‌ها -->
    <section class="widget">
        <h3 class="widget-title">
            <?php echo ava_icon('folder', 17); ?>
            دسته‌بندی‌ها
        </h3>
        <div class="cat-list">
            <?php try {
                $avaCats = $this->widget('Widget_Metas_Category_List@ava');
                if ($avaCats && $avaCats->have()) {
                    while ($avaCats->next()) {
                        echo '<div class="cat-item"><a href="' . ava_e($avaCats->permalink) . '">'
                            . '<span class="cat-dot" style="background:' . ava_e(ava_cat_dot_color($avaCats->mid)) . '"></span>'
                            . $avaCats->name
                            . '<span class="cat-count">' . ava_format_count($avaCats->count) . '</span>'
                            . '</a></div>';
                    }
                } else {
                    echo '<p class="text-muted" style="font-size:.85rem;">دسته‌بندی‌ای تعریف نشده است.</p>';
                }
            } catch (Throwable $e) {
                echo '<p class="text-muted" style="font-size:.85rem;">دسته‌بندی‌ای تعریف نشده است.</p>';
            } ?>
        </div>
    </section>

    <!-- محبوب‌ترین‌ها -->
    <section class="widget">
        <h3 class="widget-title">
            <?php echo ava_icon('trending', 17); ?>
            محبوب‌ترین‌ها
        </h3>
        <div class="pop-list">
            <?php
            $popular = null;
            try {
                if (class_exists('AvaPopularPosts')) {
                    $this->widget('AvaPopularPosts@ava', 'pageSize=3')->to($popular);
                }
            } catch (Throwable $e) {
                $popular = null;
            }

            /* جایگزین: آخرین نوشته‌ها اگر ویجت محبوب در دسترس نبود */
            if (! $popular || ! $popular->have()) {
                try {
                    $this->widget('Widget_Contents_Post_Recent@ava-pop-fallback', 'pageSize=3')->to($popular);
                } catch (Throwable $e) {
                    $popular = null;
                }
            }

            if ($popular && $popular->have()) {
                $rank = 0;
                while ($popular->next()) {
                    $rank++;
                    echo '<div class="pop-item">'
                        . '<span class="pop-rank">' . ava_fa($rank) . '</span>'
                        . '<div class="pop-body">'
                        . '<div class="pop-title"><a href="' . ava_e($popular->permalink) . '">'
                        . ava_e((string) $popular->title) . '</a></div>'
                        . '<div class="pop-meta">' . ava_icon('eye', 12) . ava_format_count(ava_get_views($popular)) . ' بازدید</div>'
                        . '</div></div>';
                }
            } else {
                echo '<p class="text-muted" style="font-size:.85rem;">هنوز نوشته‌ای برای نمایش وجود ندارد.</p>';
            }
            ?>
        </div>
    </section>

    <!-- آخرین دیدگاه‌ها -->
    <?php $recentComments = ava_recent_comments((int) ava_opt('recentCommentsCount', '5')); ?>
    <?php if (! empty($recentComments)): ?>
    <section class="widget">
        <h3 class="widget-title">
            <?php echo ava_icon('message', 17); ?>
            آخرین دیدگاه‌ها
        </h3>
        <div class="rc-list">
            <?php foreach ($recentComments as $rc): ?>
            <?php
            /* آواتار محلی: دیدگاه نویسندهٔ نوشته ← تصویر آواتار؛ سایر کاربران ← حرف آغازین رنگی */
            $rcIsOwner = ((int) ($rc['authorId'] ?? 0) > 0 && (int) ($rc['authorId'] ?? 0) === (int) ($rc['ownerId'] ?? 0));
            $rcAvatarUrl = $rcIsOwner ? ava_comment_avatar_url() : '';
            /* گراواتار برای بازدیدکنندگان: پیش‌فرض سیستم اول، سپس در صورت دسترس بودن گراواتار */
            $rcGravUrl = $rcIsOwner ? '' : ava_gravatar_url((string) ($rc['mail'] ?? ''), 68);
            ?>
            <div class="rc-item">
                <a class="rc-link" href="<?php echo ava_e($rc['link']); ?>" title="<?php echo ava_e(ava_truncate($rc['title'], 40)); ?>">
                    <?php echo ava_avatar_html($rc['author'], $rcAvatarUrl, 34, 'rc-avatar', $rcGravUrl); ?>
                    <span class="rc-body">
                        <span class="rc-text"><?php echo ava_e(ava_truncate($rc['text'], 64)); ?></span>
                        <span class="rc-meta">
                            <strong><?php echo ava_e(ava_truncate($rc['author'], 18)); ?></strong>
                            <?php echo ava_jdate('j F', $rc['created']); ?>
                            <span class="rc-on">در «<?php echo ava_e(ava_truncate($rc['title'], 22)); ?>»</span>
                        </span>
                    </span>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- جستجو -->
    <section class="widget">
        <div class="widget-search-box">
            <?php echo ava_icon('search', 17); ?>
            <form action="<?php $this->options->siteUrl(); ?>" method="post" role="search">
                <input type="text" name="s" placeholder="جستجو در وبلاگ…" aria-label="جستجو در وبلاگ">
            </form>
        </div>
    </section>
</aside>
