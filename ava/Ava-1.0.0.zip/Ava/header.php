<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/* حالت رنگی پیش‌فرض */
$themeMode = (string) ava_opt('colorSchema', 'light');
if (! in_array($themeMode, ['auto', 'light', 'dark'], true)) {
    $themeMode = 'light';
}

$siteTitle = '';
try {
    $siteTitle = (string) $this->options->title;
} catch (Throwable $e) {
    $siteTitle = '';
}

$siteDesc = '';
try {
    $siteDesc = (string) $this->options->description;
} catch (Throwable $e) {
    $siteDesc = '';
}

$brandName = (string) ava_opt('brandName', 'آوا');
$brandSub  = trim((string) ava_opt('brandSub', 'وبلاگ شخصی'));

/* لوگوی تصویری سایت (تنظیم siteLogo) — در صورت خالی‌بودن، نشان پیش‌فرض */
$siteLogoUrl = ava_site_logo_url();

/* حالت فعال صفحه برای منو */
$isHome = false;
try {
    $isHome = $this->is('index');
} catch (Throwable $e) {
    $isHome = false;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="theme-color" content="#fcf8f2" media="(prefers-color-scheme: light)">
    <meta name="theme-color" content="#201a17" media="(prefers-color-scheme: dark)">

    <link rel="icon" href="<?php echo ava_e(ava_theme_url('images/favicon.png')); ?>">

    <title>
        <?php if ($this->is('index')): ?>
            <?php $this->options->title(); ?><?php if ($siteDesc !== ''): ?> — <?php echo ava_e($siteDesc); ?><?php endif; ?>
        <?php else: ?>
            <?php $this->archiveTitle([], '', ''); ?> — <?php $this->options->title(); ?>
        <?php endif; ?>
    </title>

    <?php $this->header(); ?>

    <link rel="stylesheet" href="<?php echo ava_e(ava_theme_url('style.css')); ?>?v=<?php echo AVA_VERSION; ?>">

    <script>
    // اعمال سریع تم (روز/شب) پیش از رندر — جلوگیری از فلش روشن/تیره
    (function () {
        try {
            var mode = <?php echo json_encode($themeMode); ?>;
            var saved = null;
            try { saved = localStorage.getItem('ava-theme'); } catch (e) {}
            var theme;
            if (saved === 'light' || saved === 'dark') {
                theme = saved;
            } else if (mode === 'light' || mode === 'dark') {
                theme = mode;
            } else {
                theme = window.matchMedia
                    && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
            }
            document.documentElement.setAttribute('data-theme', theme);
            document.documentElement.classList.toggle('dark', theme === 'dark');
            document.documentElement.style.colorScheme = theme;
        } catch (e) {}
    })();
    </script>
</head>

<body>
<div class="site-wrapper farsi-digits" id="siteWrapper">

    <a class="skip-link" href="#main">پرش به محتوای اصلی</a>

    <header class="site-header">
        <div class="container header-inner">
            <a href="<?php $this->options->siteUrl(); ?>" class="brand" aria-label="<?php $this->options->title(); ?>">
                <?php if ($siteLogoUrl !== ''): ?>
                <img class="brand-logo" src="<?php echo ava_e($siteLogoUrl); ?>" alt="<?php echo ava_e($siteTitle !== '' ? $siteTitle : $brandName); ?>" width="170" height="42" decoding="async" onerror="this.style.display=&#39;none&#39;;var f=this.nextElementSibling;if(f){f.style.display=&#39;&#39;;}">
                <span class="brand-mark" style="display:none">
                    <?php echo ava_icon('sparkles', 22); ?>
                </span>
                <?php else: ?>
                <span class="brand-mark">
                    <?php echo ava_icon('sparkles', 22); ?>
                </span>
                <?php endif; ?>
                <span class="brand-text">
                    <span class="brand-name"><?php echo ava_e($brandName); ?></span>
                    <?php if ($brandSub !== ''): ?>
                    <span class="brand-sub"><?php echo ava_e($brandSub); ?></span>
                    <?php endif; ?>
                </span>
            </a>

            <nav class="main-nav" aria-label="منوی اصلی">
                <a href="<?php $this->options->siteUrl(); ?>" <?php if ($isHome): ?>class="active"<?php endif; ?>>
                    <?php echo ava_icon('home', 16); ?>خانه
                </a>
                <?php try {
                    $navPages = $this->widget('Widget_Contents_Page_List@ava-nav');
                    if ($navPages && $navPages->have()) {
                        while ($navPages->next()) {
                            $active = '';
                            try {
                                $active = $this->is('page', $navPages->slug) ? ' class="active"' : '';
                            } catch (Throwable $e) {
                                $active = '';
                            }
                            echo '<a href="' . ava_e($navPages->permalink) . '"' . $active . '>'
                                . ava_e((string) $navPages->title) . '</a>';
                        }
                    }
                } catch (Throwable $e) {
                    // نادیده بگیر
                } ?>
            </nav>

            <div class="header-tools">
                <form class="header-search" action="<?php $this->options->siteUrl(); ?>" method="post" role="search">
                    <span class="hs-icon" aria-hidden="true"><?php echo ava_icon('search', 17); ?></span>
                    <input type="text" name="s" placeholder="جستجو…" aria-label="جستجو در وبلاگ" autocomplete="off">
                </form>
                <button type="button" class="icon-btn primary-hover" id="themeToggle" aria-label="تغییر حالت روشن/تاریک">
                    <span class="icon-sun"><?php echo ava_icon('sun', 19); ?></span>
                    <span class="icon-moon" hidden><?php echo ava_icon('moon', 19); ?></span>
                </button>
                <button type="button" class="icon-btn menu-toggle" id="menuToggle" aria-label="منو" aria-expanded="false">
                    <?php echo ava_icon('menu', 21); ?>
                </button>
            </div>
        </div>

        <div class="container mobile-nav" id="mobileNav">
            <form class="mobile-search search-form" action="<?php $this->options->siteUrl(); ?>" method="post" role="search">
                <input type="text" name="s" placeholder="جستجو در وبلاگ…" aria-label="جستجو در وبلاگ">
                <button class="btn btn-primary btn-sm" type="submit">جستجو</button>
            </form>
            <a href="<?php $this->options->siteUrl(); ?>" <?php if ($isHome): ?>class="active"<?php endif; ?>>
                <?php echo ava_icon('home', 17); ?>خانه
            </a>
            <?php try {
                $mobilePages = $this->widget('Widget_Contents_Page_List@ava-mobile-nav');
                if ($mobilePages && $mobilePages->have()) {
                    while ($mobilePages->next()) {
                        echo '<a href="' . ava_e($mobilePages->permalink) . '">'
                            . ava_e((string) $mobilePages->title) . '</a>';
                    }
                }
            } catch (Throwable $e) {
                // نادیده بگیر
            } ?>
        </div>
    </header>

    <main id="main" class="site-main">
