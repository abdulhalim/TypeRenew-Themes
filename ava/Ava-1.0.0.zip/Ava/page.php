<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');

$postAuthorName = ava_author_name($this->author);
?>
<div class="container">

    <nav class="breadcrumb" aria-label="مسیر صفحه">
        <a href="<?php $this->options->siteUrl(); ?>">خانه</a>
        <span class="sep">/</span>
        <span class="current"><?php $this->title(); ?></span>
    </nav>

    <div class="home-layout">
        <div class="content-area">
            <article class="single-post">
                <div class="single-body">
                    <h1 class="post-title"><?php $this->title(); ?></h1>
                    <div class="post-meta">
                        <span><?php echo ava_icon('user', 15); ?><?php echo ava_e($postAuthorName); ?></span>
                        <span><?php echo ava_icon('calendar', 15); ?><?php echo ava_jdate('j F Y', (int) $this->created); ?></span>
                    </div>

                    <div class="prose-ava post-content" id="postBody" itemprop="articleBody">
                        <?php $this->content(); ?>
                    </div>

                    <?php if ($this->allow('comment')): ?>
                    <div class="post-actions" style="justify-content: center;">
                        <span class="share-label"><?php echo ava_icon('comment', 16); ?>دیدگاه‌های این برگه باز است — پایین صفحه بنویسید</span>
                    </div>
                    <?php endif; ?>
                </div>
            </article>

            <?php $this->need('comments.php'); ?>
        </div>

        <?php $this->need('sidebar.php'); ?>
    </div>
</div>

<?php $this->need('footer.php'); ?>
