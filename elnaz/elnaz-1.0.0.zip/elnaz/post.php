<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$GLOBALS['elnazPostJs'] = true;

$this->need('header.php');

$elnazShowViews = elnaz_opt('elnazShowViews', '1') === '1';
$elnazShowLikes = elnaz_opt('elnazShowLikes', '1') === '1';
$elnazShowRelated = elnaz_opt('elnazShowRelated', '1') === '1';
$elnazShowAuthorBox = elnaz_opt('elnazShowAuthorBox', '1') === '1';
$elnazClinicName = elnaz_opt('elnazClinicName', (string)$this->options->title);
$elnazPostCalories = elnaz_calories($this);
$elnazPostCook = elnaz_cook_time($this);
?>

<article class="post-wrap container" itemscope itemtype="https://schema.org/BlogPosting">

    <!-- ---------- سربرگ نوشته ---------- -->
    <header class="post-head">
        <nav class="post-breadcrumb" aria-label="مسیر">
            <a href="<?php $this->options->siteUrl(); ?>">خانه</a>
            <span class="crumb-sep">/</span>
            <a href="<?php echo htmlspecialchars(elnaz_blog_url(), ENT_QUOTES); ?>">مقالات</a>
            <span class="crumb-sep">/</span>
            <span aria-current="page"><?php echo elnaz_fa_title($this); ?></span>
        </nav>

        <h1 class="post-title" itemprop="name headline"><?php echo elnaz_fa_title($this); ?></h1>

        <div class="post-meta">
            <span class="post-meta-item" itemprop="author" itemscope itemtype="https://schema.org/Person">
                <?php echo elnaz_icon('user', 15); ?>
                <span itemprop="name"><?php $this->author(); ?></span>
            </span>
            <span class="post-meta-item">
                <?php echo elnaz_icon('calendar', 15); ?>
                <time datetime="<?php $this->date('c'); ?>" itemprop="datePublished"><?php echo elnaz_post_date($this, 'j F Y'); ?></time>
            </span>
            <span class="post-meta-item">
                <?php echo elnaz_icon('folder', 15); ?>
                <?php $this->category(','); ?>
            </span>
            <?php if ($elnazPostCalories !== ''): ?>
            <span class="post-meta-item post-meta-badge">
                <?php echo elnaz_icon('flame', 15); ?>
                <?php echo $elnazPostCalories; ?> کیلوکالری
            </span>
            <?php endif; ?>
            <?php if ($elnazPostCook !== ''): ?>
            <span class="post-meta-item post-meta-badge">
                <?php echo elnaz_icon('clock', 15); ?>
                <?php echo $elnazPostCook; ?> دقیقه
            </span>
            <?php endif; ?>
            <?php if ($elnazShowViews): ?>
            <span class="post-meta-item post-views" id="postViews">
                <?php echo elnaz_icon('eye', 15); ?>
                <?php echo elnaz_num(elnaz_views($this)); ?> بازدید
            </span>
            <?php endif; ?>
            <span class="post-meta-item">
                <?php echo elnaz_icon('message-square', 15); ?>
                <a href="#comments"><?php ob_start(); $this->commentsNum('بدون دیدگاه', '۱ دیدگاه', '%d دیدگاه'); echo toPersianNumbers(ob_get_clean()); ?></a>
            </span>
        </div>
    </header>

    <!-- ---------- تصویر شاخص ---------- -->
    <?php $elnazCover = elnaz_thumbnail($this, false); if ($elnazCover !== ''): ?>
    <figure class="post-cover">
        <img src="<?php echo htmlspecialchars($elnazCover, ENT_QUOTES); ?>" alt="<?php echo elnaz_fa_title($this); ?>" itemprop="image">
    </figure>
    <?php endif; ?>

    <!-- ---------- محتوای نوشته ---------- -->
    <div class="post-content" itemprop="articleBody">
        <?php $this->content(); ?>
    </div>

    <!-- ---------- تگ‌ها ---------- -->
    <?php if ($this->tags): ?>
    <div class="post-tags">
        <?php echo elnaz_icon('tag', 15); ?>
        <?php $this->tags(' ', true, ''); ?>
    </div>
    <?php endif; ?>

    <!-- ---------- لایک ---------- -->
    <?php if ($elnazShowLikes): ?>
    <?php
    $elnazLikes = elnaz_likes($this);
    $elnazLiked = elnaz_is_liked((int)$this->cid) ? '1' : '0';
    ?>
    <div class="post-like-row" id="elnazLikeFloat">
        <button type="button" class="like-btn<?php echo $elnazLiked === '1' ? ' is-liked' : ''; ?>" id="elnazLikeBtn"
                data-cid="<?php echo (int)$this->cid; ?>" data-likes="<?php echo $elnazLikes; ?>" data-liked="<?php echo $elnazLiked; ?>"
                aria-pressed="<?php echo $elnazLiked === '1' ? 'true' : 'false'; ?>">
            <?php echo elnaz_icon('heart', 18); ?>
            <span class="like-label"><?php echo $elnazLiked === '1' ? 'پسندیدید' : 'این مطلب را پسندیدید؟'; ?></span>
            <span class="like-count"><?php echo elnaz_num($elnazLikes); ?></span>
        </button>
    </div>
    <?php endif; ?>

    <!-- ---------- نویسنده ---------- -->
    <?php if ($elnazShowAuthorBox): ?>
    <aside class="author-box">
        <span class="author-avatar">
            <?php $this->author->gravatar(96); ?>
            <span class="author-avatar-fallback" aria-hidden="true"><?php echo htmlspecialchars(elnaz_initial((string)$this->author->screenName), ENT_QUOTES); ?></span>
        </span>
        <div class="author-info">
            <strong class="author-name"><a href="<?php $this->author->permalink(); ?>" rel="author"><?php $this->author(); ?></a></strong>
            <span class="author-role">نویسنده در <?php echo htmlspecialchars($elnazClinicName, ENT_QUOTES); ?></span>
            <?php if (trim((string)$this->author->description) !== ''): ?>
            <p class="author-desc"><?php $this->author->description(); ?></p>
            <?php endif; ?>
        </div>
    </aside>
    <?php endif; ?>

    <!-- ---------- نوشته‌های مرتبط ---------- -->
    <?php
    $elnazRelated = $elnazShowRelated ? elnaz_related_posts($this, 3) : [];
    if (!empty($elnazRelated)):
    ?>
    <section class="related-posts">
        <h2 class="related-title"><?php echo elnaz_icon('file-text', 18); ?> نوشته‌های مرتبط</h2>
        <div class="related-grid">
            <?php foreach ($elnazRelated as $elnazRelatedPost): ?>
            <a href="<?php echo htmlspecialchars($elnazRelatedPost['url'], ENT_QUOTES); ?>" class="related-card">
                <span class="related-card-title"><?php echo toPersianNumbers(htmlspecialchars($elnazRelatedPost['title'], ENT_QUOTES)); ?></span>
                <span class="related-card-date"><?php echo elnaz_post_date($elnazRelatedPost['created'], 'j F Y'); ?></span>
                <span class="related-card-more">خواندن <?php echo elnaz_icon('arrow-left', 14); ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- ---------- نظرات ---------- -->
    <?php $this->need('comments.php'); ?>

</article>

<?php $this->need('footer.php'); ?>
