<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
</main>

<!-- ---------- فوتر سایت ---------- -->
<footer class="site-footer">
    <?php
    // ---------- داده‌های فوتر ----------
    $elnazClinicName = elnaz_opt('elnazClinicName', (string)$this->options->title);
    $elnazTagline    = elnaz_opt('elnazTagline', 'بدن قوی، ذهن قوی');
    $elnazLogoUrl    = elnaz_logo_url();
    $elnazFooterText = elnaz_opt('elnazFooterText', 'باشگاه الناز — با مربیان مجرب، تجهیزات حرفه‌ای و برنامه‌های شخصی‌سازی‌شده، قدرتمندترین نسخهٔ خودت را می‌سازیم.');
    $elnazPhone      = elnaz_opt_raw('elnazContactPhone');
    $elnazPhone2     = elnaz_opt_raw('elnazContactPhone2');
    $elnazEmail      = elnaz_opt_raw('elnazContactEmail');
    $elnazAddress    = elnaz_opt_raw('elnazContactAddress');
    $elnazHours      = (string)elnaz_opt_raw('elnazContactHours');
    $elnazSocial = [
        'instagram' => elnaz_opt_raw('elnazSocialInstagram'),
        'telegram'  => elnaz_opt_raw('elnazSocialTelegram'),
        'whatsapp'  => elnaz_opt_raw('elnazSocialWhatsapp'),
        'youtube'   => elnaz_opt_raw('elnazSocialYoutube'),
    ];
    $elnazSocialNames = ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام', 'whatsapp' => 'واتس‌اپ', 'youtube' => 'یوتیوب'];
    ?>

    <!-- بخش اصلی فوتر -->
    <div class="container">
        <div class="footer-grid">

            <!-- ستون ۱: لوگو و معرفی -->
            <div class="footer-col footer-about">
                <div class="footer-logo">
                    <a href="<?php $this->options->siteUrl(); ?>" class="footer-logo-link">
                        <?php if ($elnazLogoUrl !== ''): ?>
                            <img src="<?php echo htmlspecialchars($elnazLogoUrl, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($elnazClinicName, ENT_QUOTES); ?>" class="footer-logo-img">
                        <?php else: ?>
                            <span class="footer-logo-mark" aria-hidden="true"><?php echo elnaz_icon('dumbbell', 20); ?></span>
                        <?php endif; ?>
                        <span class="footer-logo-text"><?php echo htmlspecialchars($elnazClinicName, ENT_QUOTES); ?></span>
                    </a>
                </div>
                <p class="footer-desc"><?php echo htmlspecialchars($elnazFooterText, ENT_QUOTES); ?></p>
                <div class="footer-social">
                    <?php foreach ($elnazSocial as $elnazNet => $elnazUrl): if (trim((string)$elnazUrl) !== ''): ?>
                        <a href="<?php echo htmlspecialchars($elnazUrl, ENT_QUOTES); ?>" target="_blank" rel="noopener" aria-label="<?php echo $elnazSocialNames[$elnazNet]; ?>">
                            <?php echo elnaz_icon($elnazNet === 'telegram' ? 'send' : ($elnazNet === 'whatsapp' ? 'message-circle' : $elnazNet), 17); ?>
                        </a>
                    <?php endif; endforeach; ?>
                </div>
            </div>

            <!-- ستون ۲: لینک‌های سریع -->
            <div class="footer-col">
                <h3 class="footer-title"><?php echo elnaz_icon('zap', 17); ?> دسترسی سریع</h3>
                <ul class="footer-links">
                    <li><a href="<?php echo htmlspecialchars(elnaz_link_url('#services', elnaz_is_front()), ENT_QUOTES); ?>">خدمات باشگاه</a></li>
                    <li><a href="<?php echo htmlspecialchars(elnaz_link_url('#packages', elnaz_is_front()), ENT_QUOTES); ?>">اشتراک‌ها</a></li>
                    <li><a href="<?php echo htmlspecialchars(elnaz_link_url('#team', elnaz_is_front()), ENT_QUOTES); ?>">مربیان</a></li>
                    <li><a href="<?php echo htmlspecialchars(elnaz_link_url('#booking', elnaz_is_front()), ENT_QUOTES); ?>">رزرو جلسهٔ رایگان</a></li>
                    <li><a href="<?php echo htmlspecialchars(elnaz_blog_url(), ENT_QUOTES); ?>">مقالات تناسب اندام</a></li>
                    <?php
                    $elnazFooterPages = \Widget\Contents\Page\Rows::allocWithAlias('elnazFooter');
                    $elnazFooterPageCount = 0;
                    while ($elnazFooterPages->next()):
                        if (elnaz_is_reserve_cid((int)$elnazFooterPages->cid)) { continue; }
                        $elnazFooterPageCount++;
                        if ($elnazFooterPageCount > 4) { break; }
                    ?>
                        <li><a href="<?php $elnazFooterPages->permalink(); ?>"><?php echo elnaz_fa_title($elnazFooterPages); ?></a></li>
                    <?php endwhile; ?>
                </ul>
            </div>

            <!-- ستون ۳: اطلاعات تماس -->
            <div class="footer-col footer-contact-col">
                <h3 class="footer-title"><?php echo elnaz_icon('phone-call', 17); ?> تماس با ما</h3>
                <ul class="footer-contact">
                    <?php if ($elnazAddress !== null && trim($elnazAddress) !== ''): ?>
                    <li>
                        <?php echo elnaz_icon('map-pin', 16); ?>
                        <span><?php echo htmlspecialchars($elnazAddress, ENT_QUOTES); ?></span>
                    </li>
                    <?php endif; ?>
                    <?php if ($elnazPhone !== null && trim($elnazPhone) !== ''): ?>
                    <li>
                        <?php echo elnaz_icon('phone', 16); ?>
                        <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $elnazPhone), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($elnazPhone), ENT_QUOTES); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if ($elnazPhone2 !== null && trim($elnazPhone2) !== ''): ?>
                    <li>
                        <?php echo elnaz_icon('message-circle', 16); ?>
                        <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $elnazPhone2), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($elnazPhone2), ENT_QUOTES); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if ($elnazEmail !== null && trim($elnazEmail) !== ''): ?>
                    <li>
                        <?php echo elnaz_icon('mail', 16); ?>
                        <a href="mailto:<?php echo htmlspecialchars($elnazEmail, ENT_QUOTES); ?>"><?php echo htmlspecialchars($elnazEmail, ENT_QUOTES); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php foreach (array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $elnazHours))) as $elnazHour): ?>
                    <li>
                        <?php echo elnaz_icon('clock', 16); ?>
                        <span><?php echo htmlspecialchars(toPersianNumbers($elnazHour), ENT_QUOTES); ?></span>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <!-- خط جداکننده و کپی‌رایت -->
    <div class="footer-bottom">
        <div class="container footer-bottom-inner">
            <div class="copyright">
                <span>© <?php echo elnaz_jalali_year(); ?> <?php echo htmlspecialchars($elnazClinicName, ENT_QUOTES); ?> — تمامی حقوق محفوظ است.</span>
            </div>
            <div class="footer-powered">
                <span>قدرت گرفته از <a href="https://typerenew.com" target="_blank" rel="noopener">تایپ‌رینیو</a></span>
            </div>
        </div>
    </div>
</footer>

<!-- ---------- دکمهٔ بازگشت به بالا ---------- -->
<button type="button" class="back-to-top" id="backToTop" aria-label="بازگشت به بالا" title="بازگشت به بالا">
    <?php echo elnaz_icon('arrow-up', 19); ?>
</button>

<!-- ---------- اسکریپت‌ها ---------- -->
<script src="<?php $this->options->themeUrl('js/main.js'); ?>?v=1.0.0"></script>
<?php if (isset($GLOBALS['elnazPostJs']) && $GLOBALS['elnazPostJs']): ?>
<!-- لایک — فقط صفحات نوشته -->
<script src="<?php $this->options->themeUrl('js/likes.js'); ?>?v=1.0.0"></script>
<?php endif; ?>

<?php $this->footer(); ?>
</body>
</html>
