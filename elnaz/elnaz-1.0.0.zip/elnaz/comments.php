<?php

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$requireUrl = isset($this->options->commentsRequireUrl) ? $this->options->commentsRequireUrl : $this->options->commentsRequireURL;
?>

<div id="comments" class="comments-area">

    <div class="comments-header">
        <h2 class="comments-title">
            <?php echo elnaz_icon('message-square', 20); ?>
            <?php _e('دیدگاه‌ها'); ?>
            <span class="comments-count"><?php ob_start(); $this->commentsNum('۰', '۱', '%d'); echo toPersianNumbers(ob_get_clean()); ?></span>
        </h2>
    </div>

    <?php $this->comments()->to($comments); ?>

    <?php if ($comments->have()): ?>
    <div class="comments-body">
        <?php $comments->listComments([
            'before'        => '<ol class="comment-list">',
            'after'         => '</ol>',
            'commentStatus' => _t('در انتظار تأیید')
        ]); ?>

        <?php $comments->pageNav(
            '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 6 15 12 9 18"></polyline></svg>',
            '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 6 9 12 15 18"></polyline></svg>'
        ); ?>
    </div>
    <?php endif; ?>

    <?php if ($this->allow('comment')): ?>
    <div id="<?php $this->respondId(); ?>" class="respond">
        <div class="cancel-comment-reply">
            <?php $comments->cancelReply(); ?>
        </div>

        <h3 id="response" class="respond-title"><?php _e('دیدگاه خود را بنویسید'); ?></h3>

        <form method="post" action="<?php $this->commentUrl(); ?>" id="comment-form" role="form" class="comment-form">
            <?php $security = \Widget\Security::alloc(); ?>
            <input type="hidden" name="_" value="<?php echo htmlspecialchars($security->getToken($this->request->getRequestUrl()), ENT_QUOTES, 'UTF-8'); ?>">

            <?php if ($this->user->hasLogin()): ?>
            <p class="comment-logged-in">
                <?php echo elnaz_icon('user', 15); ?>
                <?php _e('ورود با حساب'); ?>:
                <a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>
                <a class="comment-logout" href="<?php $this->options->logoutUrl(); ?>"><?php _e('خروج'); ?></a>
            </p>
            <?php else: ?>
            <div class="comment-form-row">
                <div class="form-group">
                    <label for="author"><?php _e('نام'); ?> <span class="req">*</span></label>
                    <input type="text" name="author" id="author" class="form-input" placeholder="نام شما" value="<?php $this->remember('author'); ?>" required>
                </div>
                <div class="form-group">
                    <label for="mail"><?php _e('ایمیل'); ?><?php if ($this->options->commentsRequireMail): ?> <span class="req">*</span><?php endif; ?></label>
                    <input type="email" name="mail" id="mail" class="form-input" dir="ltr" placeholder="you@example.com" value="<?php $this->remember('mail'); ?>"<?php if ($this->options->commentsRequireMail): ?> required<?php endif; ?>>
                </div>
                <div class="form-group">
                    <label for="url"><?php _e('وبسایت'); ?><?php if ($requireUrl): ?> <span class="req">*</span><?php endif; ?></label>
                    <input type="url" name="url" id="url" class="form-input" dir="ltr" placeholder="https://" value="<?php $this->remember('url'); ?>"<?php if ($requireUrl): ?> required<?php endif; ?>>
                </div>
            </div>
            <?php endif; ?>

            <div class="form-group">
                <label for="textarea"><?php _e('متن دیدگاه'); ?> <span class="req">*</span></label>
                <textarea name="text" id="textarea" class="form-input" rows="5" placeholder="نظر شما دربارهٔ این مطلب..." required><?php $this->remember('text'); ?></textarea>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary comment-submit">
                    <?php echo elnaz_icon('send', 16); ?>
                    <?php _e('ارسال دیدگاه'); ?>
                </button>
            </div>
        </form>
    </div>
    <?php else: ?>
    <p class="comments-closed"><?php _e('امکان ارسال دیدگاه برای این مطلب غیرفعال است.'); ?></p>
    <?php endif; ?>
</div>
