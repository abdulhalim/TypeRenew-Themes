<?php

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/* ================================================================
 *  ۱) ابزارهای عمومی
 * ================================================================ */

/** خواندن تنظیم پوسته با مقدار پیش‌فرض (مقدار خالی → پیش‌فرض) */
function elnaz_opt(string $name, ?string $default = null): string
{
    try {
        $value = \Widget\Options::alloc()->{$name};
    } catch (\Throwable $e) {
        $value = null;
    }
    return ($value === null || $value === '') ? (string)$default : (string)$value;
}

/** مانند elnaz_opt اما «مقدار خالی» را نیز برمی‌گرداند (تمایز تنظیم‌نشده/خالی‌شده) */
function elnaz_opt_raw(string $name): ?string
{
    try {
        $value = \Widget\Options::alloc()->{$name};
    } catch (\Throwable $e) {
        return null;
    }
    return ($value === null) ? null : (string)$value;
}

/** تبدیل ارقام لاتین به فارسی */
if (!function_exists('toPersianNumbers')) {
    function toPersianNumbers($num)
    {
        $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return str_replace(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], $persian, (string)$num);
    }
}

/** عدد فارسی با جداکنندهٔ هزارگان: 1234 → ۱٬۲۳۴ */
function elnaz_num($num): string
{
    return toPersianNumbers(str_replace(',', '٬', number_format(max(0, (float)$num))));
}

/** عدد فارسی اعشاری (برای کالری و ماکرو) */
function elnaz_dec($num, int $digits = 1): string
{
    return toPersianNumbers(number_format((float)$num, $digits, '.', '٬'));
}

/** عنوان محتوا برای نمایش: HTML-escaped + ارقام فارسی */
function elnaz_fa_title($widget): string
{
    $title = '';
    try {
        $title = (string)$widget->title;
    } catch (\Throwable $e) {
        $title = '';
    }
    return toPersianNumbers(htmlspecialchars($title, ENT_QUOTES, 'UTF-8'));
}

/** نرمال‌سازی آدرس تصویر (نسبی → مطلق) — آدرس‌های دارای scheme دست‌نخورده می‌مانند */
function elnaz_resolve_url(string $url): string
{
    $url = trim($url);
    if ($url === '' || preg_match('#^(data:|[a-z][a-z0-9+.\-]*:|//)#i', $url)) {
        return $url;
    }
    try {
        $base = rtrim((string)\Widget\Options::alloc()->siteUrl, '/');
    } catch (\Throwable $e) {
        $base = '';
    }
    return $base . '/' . ltrim($url, '/');
}

/**
 * آدرس نهایی دکمه‌ها و لینک‌های منو:
 *  - «#hash» فقط در صفحهٔ اول همان اسکرول درون‌صفحه است؛ در صفحات دیگر به «siteUrl/#hash» تبدیل می‌شود
 *  - آدرس‌های دارای scheme (tel: / mailto: / https: …) و // و data: عیناً حفظ می‌شوند
 */
function elnaz_link_url(string $url, bool $onHome = true): string
{
    $url = trim($url);
    if ($url === '') {
        return '';
    }
    if (preg_match('#^(data:|[a-z][a-z0-9+.\-]*:|//)#i', $url)) {
        return $url;
    }
    if ($url[0] === '#') {
        if ($onHome) {
            return $url;
        }
        try {
            $base = rtrim((string)\Widget\Options::alloc()->siteUrl, '/');
        } catch (\Throwable $e) {
            $base = '';
        }
        return $base . '/' . $url;
    }
    return elnaz_resolve_url($url);
}

/** نام مسیر (route) جاری تایپ‌رینیو؛ در نبود روتر خالی برمی‌گردد */
function elnaz_route(): string
{
    try {
        if (class_exists('\Typecho\Router') && isset(\Typecho\Router::$current)) {
            return (string)\Typecho\Router::$current;
        }
    } catch (\Throwable $e) {
    }
    return '';
}

/** آیا همین صفحه «صفحهٔ اول» سایت است؟ (بر مبنای مسیر جاری) */
function elnaz_is_front(): bool
{
    return elnaz_route() === 'index';
}

/** آدرس فهرست مقالات (وبلاگ) */
function elnaz_blog_url(): string
{
    $custom = trim((string)elnaz_opt_raw('elnazBlogUrl'));
    if ($custom !== '') {
        return elnaz_link_url($custom);
    }
    try {
        if (class_exists('\Typecho\Router')) {
            $url = \Typecho\Router::url('archive', [], (string)\Widget\Options::alloc()->index);
            if (is_string($url) && $url !== '' && $url !== '#') {
                return $url;
            }
        }
    } catch (\Throwable $e) {
    }
    try {
        return rtrim((string)\Widget\Options::alloc()->siteUrl, '/') . '/';
    } catch (\Throwable $e) {
        return '#';
    }
}

/**
 * صفحه‌بندی فهرست مقالات با فراخوانی صحیحِ Widget\Archive::pageNav.
 * امضای هستهٔ تایپ‌رینیو ۱.۶: pageNav(string $prev, string $next, int $splitPage, string $splitWord, $template)
 * itemTag خالی → کلاس‌ها مستقیم روی <a> می‌نشینند (طرح فعال صفحهٔ جاری در CSS).
 */
function elnaz_page_nav($archive): void
{
    if ($archive === null || !method_exists($archive, 'pageNav')) {
        return;
    }
    ob_start();
    $archive->pageNav(
        toPersianNumbers('قبلی'),
        toPersianNumbers('بعدی'),
        2,
        '...',
        [
            'wrapTag'      => 'nav',
            'wrapClass'    => 'pagination',
            'itemTag'      => '',
            'textTag'      => '',
            'currentClass' => 'page-current',
            'prevClass'    => 'page-prev',
            'nextClass'    => 'page-next',
        ]
    );
    $html = (string)ob_get_clean();
    if ($html === '') {
        return;
    }
    echo preg_replace_callback(
        '/>([^<>]*)</',
        function ($m) {
            return '>' . toPersianNumbers($m[1]) . '<';
        },
        $html
    );
}

/** آدرس یک فایل داخل پوسته */
function elnaz_asset(string $path): string
{
    try {
        return rtrim((string)\Widget\Options::alloc()->themeUrl, '/') . '/' . ltrim($path, '/');
    } catch (\Throwable $e) {
        return $path;
    }
}
/* ================================================================
 *  ۲) آیکون‌های Lucide (SVG درون‌خطی — بدون نیاز به اینترنت)
 * ================================================================ */

/** نقشهٔ آیکون‌های Lucide — همه ۲۴×۲۴ با stroke */
function elnaz_icons(): array
{
    static $icons = null;
    if ($icons !== null) {
        return $icons;
    }

    $icons = [
        // برند
        'leaf' => '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>',
        'sparkles' => '<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/><path d="M20 3v4"/><path d="M22 5h-4"/><path d="M4 17v2"/><path d="M5 18H3"/>',
        'flower' => '<circle cx="12" cy="12" r="3"/><path d="M12 2a3 3 0 0 1 3 3c0 1.5-1.5 3-3 3s-3-1.5-3-3a3 3 0 0 1 3-3Z"/><path d="M12 22a3 3 0 0 0 3-3c0-1.5-1.5-3-3-3s-3 1.5-3 3a3 3 0 0 0 3 3Z"/><path d="M2 12a3 3 0 0 1 3-3c1.5 0 3 1.5 3 3s-1.5 3-3 3a3 3 0 0 1-3-3Z"/><path d="M22 12a3 3 0 0 0-3-3c-1.5 0-3 1.5-3 3s1.5 3 3 3a3 3 0 0 0 3-3Z"/>',
        'timer' => '<line x1="10" x2="14" y1="2" y2="2"/><line x1="12" x2="15" y1="14" y2="11"/><circle cx="12" cy="14" r="8"/>',
        'heart' => '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
        'heart-pulse' => '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/><path d="M3.22 12H9.5l.5-1 2 4.5 2-7 1.5 3.5h5.27"/>',

        // ورزش و باشگاه
        'apple' => '<path d="M12 20.94c1.5 0 2.75 1.06 4 1.06 3 0 6-8 6-12.22A4.91 4.91 0 0 0 17 5c-2.22 0-4 1.44-5 2-1-.56-2.78-2-5-2a4.9 4.9 0 0 0-5 4.78C2 14 5 22 8 22c1.25 0 2.5-1.06 4-1.06Z"/><path d="M10 2c1 .5 2 2 2 5"/>',
        'salad' => '<path d="M7 21h10"/><path d="M12 21a9 9 0 0 0 9-9H3a9 9 0 0 0 9 9Z"/><path d="M12 12a9 9 0 0 0 9-9 3 3 0 0 0-3 3 9 9 0 0 0-6 6Z"/><path d="M12 12a9 9 0 0 1-9-9 3 3 0 0 1 3 3 9 9 0 0 1 6 6Z"/>',
        'carrot' => '<path d="M2.27 21.7 9 15"/><path d="M12 15a10 10 0 0 0 10-10c0-.6-.5-1.1-1.1-1.1A10 10 0 0 0 11 14"/><path d="M9 15H5.5A2.5 2.5 0 0 1 3 12.5c0-1 .6-1.8 1.5-2.2l1.5-.7A10 10 0 0 0 12 15v-3.5A2.5 2.5 0 0 1 14.5 9c1 0 1.8.6 2.2 1.5"/>',
        'wheat' => '<path d="M2 22 16 8"/><path d="M3.47 12.53 5 11l1.53 1.53a3.5 3.5 0 0 1 0 4.94L5 19l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z"/><path d="M7.47 8.53 9 7l1.53 1.53a3.5 3.5 0 0 1 0 4.94L9 15l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z"/><path d="M11.47 4.53 13 3l1.53 1.53a3.5 3.5 0 0 1 0 4.94L13 11l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z"/><path d="M20 2h2v2a4 4 0 0 1-4 4h-2V6a4 4 0 0 1 4-4Z"/>',
        'fish' => '<path d="M6.5 12c.94-3.46 4.94-6 8.5-6 3.56 0 6.06 2.54 7 6-.94 3.47-3.44 6-7 6s-7.56-2.53-8.5-6Z"/><path d="M18 12v.5"/><path d="M16 17.93a9.77 9.77 0 0 1 0-11.86"/><path d="M7 10.67C7 8 5.58 5.97 2.73 5.5c-1 1.5-1 5 .23 6.5-1.24 1.5-1.24 5-.23 6.5C5.58 18.03 7 16 7 13.32"/><path d="m10 6 1.5-1.5"/>',
        'egg' => '<path d="M12 22c4 0 7-2.5 7-7 0-3.5-2.5-6-4-8.5C13.5 4 13 2 12 2s-1.5 2-3 4.5C7.5 9 5 11.5 5 15c0 4.5 3 7 7 7Z"/>',
        'milk' => '<path d="M8 2h8"/><path d="M9 2v6.4L5.4 13A6 6 0 0 0 4 16.6V20a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3.4a6 6 0 0 0-1.4-3.6L15 8.4V2"/><path d="M7 16h10"/><path d="M7.5 12.5h9"/>',
        'citrus' => '<circle cx="12" cy="12" r="10"/><path d="M5 5c1.5 1.5 2 3 2 7s-.5 5.5-2 7"/><path d="M19 5c-1.5 1.5-2 3-2 7s.5 5.5 2 7"/><path d="M12 2v20"/>',
        'utensils' => '<path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"/><path d="M7 2v20"/><path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3zm0 0v7"/>',
        'droplet' => '<path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"/>',

        // سلامت و اندازه‌گیری
        'weight' => '<circle cx="12" cy="5" r="3"/><path d="M6.5 8a2 2 0 0 0-1.905 1.46L2.1 18.5A2 2 0 0 0 4 21h16a2 2 0 0 0 1.9-2.5L17.4 9.5A2 2 0 0 0 15.5 8Z"/>',
        'scale' => '<path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="M7 21h10"/><path d="M12 3v18"/><path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2"/>',
        'calculator' => '<rect width="16" height="20" x="4" y="2" rx="2"/><line x1="8" x2="16" y1="6" y2="6"/><line x1="16" x2="16" y1="14" y2="18"/><path d="M16 10h.01"/><path d="M12 10h.01"/><path d="M8 10h.01"/><path d="M12 14h.01"/><path d="M8 14h.01"/><path d="M12 18h.01"/><path d="M8 18h.01"/>',
        'activity' => '<path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>',
        'flame' => '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>',
        'gauge' => '<path d="m12 14 4-4"/><path d="M3.34 19a10 10 0 1 1 17.32 0"/>',
        'ruler' => '<path d="M21.3 15.3 15.3 21.3a1 1 0 0 1-1.4 0l-1.8-1.8 8.5-8.5 1.8 1.8a1 1 0 0 1 0 1.4Z"/><path d="m15.9 6.1 1.8 1.8"/><path d="m12.2 9.8 1.8 1.8"/><path d="m8.5 13.5 1.8 1.8"/><path d="m4.8 17.2 1.8 1.8"/><path d="M3.9 2.7 2.7 3.9a1 1 0 0 0 0 1.4l2.4 2.4 2.6-.4.4-2.6-2.4-2.4a1 1 0 0 0-1.4 0Z"/>',
        'pill' => '<path d="M10.5 20.5 3.5 13.5a4.95 4.95 0 1 1 7-7l7 7a4.95 4.95 0 1 1-7 7Z"/><path d="m8.5 8.5 7 7"/>',
        'stethoscope' => '<path d="M4.8 2.3A.3.3 0 1 0 5 2H4a2 2 0 0 0-2 2v5a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6V4a2 2 0 0 0-2-2h-1a.2.2 0 1 0 .3.3"/><path d="M8 15v1a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6v-4"/><circle cx="20" cy="10" r="2"/>',
        'dumbbell' => '<path d="M14.4 14.4 9.6 9.6"/><path d="M18.657 21.485a2 2 0 1 1-2.829-2.828l-1.767 1.768a2 2 0 1 1-2.829-2.829l6.364-6.364a2 2 0 1 1 2.829 2.829l1.767-1.768a2 2 0 1 1 2.828 2.829z"/><path d="m21.5 21.5-1.4-1.4"/><path d="M3.9 3.9 2.5 2.5"/><path d="M6.404 12.768a2 2 0 1 1-2.829-2.829l1.768-1.767a2 2 0 1 1-2.828-2.829l2.828-2.828a2 2 0 1 1 2.829 2.828l1.767-1.768a2 2 0 1 1 2.829 2.829z"/>',
        'baby' => '<path d="M9 12h.01"/><path d="M15 12h.01"/><path d="M10 16c.5.3 1.2.5 2 .5s1.5-.2 2-.5"/><path d="M19 6.3a9 9 0 0 1 1.8 3.9 2 2 0 0 1 0 3.6 9 9 0 0 1-17.6 0 2 2 0 0 1 0-3.6A9 9 0 0 1 12 3c2 0 3.5 1.1 3.5 2.5s-.9 2.5-2 2.5c-.8 0-1.5-.4-1.5-1"/>',
        'lightbulb' => '<path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/>',
        'brain' => '<path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/><path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/><path d="M15 13H9"/>',
        'moon' => '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
        'sun' => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',

        // وضعیت و هدف
        'trending-down' => '<polyline points="22 17 13.5 8.5 8.5 13.5 2 7"/><polyline points="16 17 22 17 22 11"/>',
        'trending-up' => '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
        'target' => '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
        'zap' => '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',

        // رابط کاربری
        'user' => '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'users' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'clipboard-check' => '<rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/>',
        'clipboard-list' => '<rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/>',
        'calendar' => '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/>',
        'calendar-check' => '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="m9 16 2 2 4-4"/>',
        'phone' => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
        'phone-call' => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/><path d="M14.05 2a9 9 0 0 1 8 7.94"/><path d="M14.05 6A5 5 0 0 1 18 10"/>',
        'mail' => '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
        'map-pin' => '<path d="M20 10c0 4.99-5.54 10.19-7.4 11.79a1 1 0 0 1-1.2 0C9.54 20.19 4 14.99 4 10a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
        'clock' => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
        'message-circle' => '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>',
        'message-square' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
        'send' => '<path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>',
        'check-circle' => '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
        'shield-check' => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1 1 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
        'star' => '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
        'award' => '<circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>',
        'quote' => '<path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z"/><path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z"/>',
        'book-open' => '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
        'file-text' => '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M16 13H8"/><path d="M16 17H8"/><path d="M10 9H8"/>',
        'folder' => '<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>',
        'tag' => '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"/>',
        'eye' => '<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>',
        'arrow-up' => '<path d="m5 12 7-7 7 7"/><path d="M12 19V5"/>',
        'arrow-left' => '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
        'chevron-left' => '<path d="m15 18-6-6 6-6"/>',
        'chevron-right' => '<path d="m9 18 6-6-6-6"/>',
        'chevron-down' => '<path d="m6 9 6 6 6-6"/>',
        'menu' => '<line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="18" y2="18"/>',
        'x' => '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
        'check' => '<path d="M20 6 9 17l-5-5"/>',
        'lock' => '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
        'inbox' => '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
        'cake' => '<path d="M20 21v-8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8"/><path d="M4 16s.5-2 2-2 2.5 2 4 2 2.5-2 4-2 2.5 2 4 2 2-2 2-2"/><path d="M2 21h20"/><path d="M7 8v3"/><path d="M12 8v3"/><path d="M17 8v3"/><path d="M7 4h.01"/><path d="M12 4h.01"/><path d="M17 4h.01"/>',
        'trash-2' => '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
        'home' => '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
        'search' => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
        'instagram' => '<rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>',
        'youtube' => '<path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/><path d="m10 15 5-3-5-3z"/>',
    ];
    return $icons;
}

/** رندر آیکون Lucide — خروجی SVG درون‌خطی */
function elnaz_icon(string $name, int $size = 24, string $class = ''): string
{
    $icons = elnaz_icons();
    $path = $icons[$name] ?? $icons['dumbbell'];
    $classAttr = $class !== '' ? ' class="' . htmlspecialchars($class, ENT_QUOTES) . '"' : '';
    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"' . $classAttr . '>' . $path . '</svg>';
}

/** آیا نام آیکون معتبر است؟ (برای اعتبارسنجی ورودی) */
function elnaz_icon_exists(string $name): bool
{
    return array_key_exists($name, elnaz_icons());
}

/* ================================================================
 *  ۳) تاریخ شمسی
 * ================================================================ */

/** میلادی → جلالی (الگوریتم استاندارد) */
function elnaz_to_jalali(int $gy, int $gm, int $gd): array
{
    $g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100))
        + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
    $jy = -1595 + (33 * ((int)($days / 12053)));
    $days %= 12053;
    $jy += 4 * ((int)($days / 1461));
    $days %= 1461;
    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + (int)($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }
    return [$jy, $jm, $jd];
}

/** آیا افزونهٔ JalaliDate فعال است؟ */
function elnaz_jalali_plugin_active(): bool
{
    try {
        $plugins = \Widget\Options::alloc()->plugins;
        if (is_array($plugins) && isset($plugins['activated']) && is_array($plugins['activated'])) {
            foreach (array_keys($plugins['activated']) as $key) {
                if (stripos((string)$key, 'jalali') !== false) {
                    return true;
                }
            }
        }
    } catch (\Throwable $e) {
    }
    return false;
}

/** تاریخ شمسی از timestamp — اگر افزونهٔ شمسی فعال باشد از همان */
function elnaz_jalali_date($timestamp = null, string $format = 'Y/m/d'): string
{
    if ($timestamp === null) {
        $timestamp = time();
    }
    $timestamp = (int)$timestamp;
    if ($timestamp <= 0) {
        $timestamp = time();
    }
    if (elnaz_jalali_plugin_active() && function_exists('jdate')) {
        $out = @jdate($format, $timestamp);
        if (is_string($out) && $out !== '') {
            return $out;
        }
    }
    return elnaz_format_jalali($timestamp, $format);
}

/** قالب‌بندی تاریخ شمسی */
function elnaz_format_jalali(int $timestamp, string $format): string
{
    $gy = (int)date('Y', $timestamp);
    $gm = (int)date('n', $timestamp);
    $gd = (int)date('j', $timestamp);
    [$jy, $jm, $jd] = elnaz_to_jalali($gy, $gm, $gd);

    $months = [
        1 => 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
    ];

    $out = $format;
    $out = str_replace('Y', (string)$jy, $out);
    $out = str_replace('y', substr((string)$jy, -2), $out);
    $out = str_replace('m', str_pad((string)$jm, 2, '0', STR_PAD_LEFT), $out);
    $out = str_replace('n', (string)$jm, $out);
    $out = str_replace('d', str_pad((string)$jd, 2, '0', STR_PAD_LEFT), $out);
    $out = str_replace('j', (string)$jd, $out);
    $out = str_replace('F', $months[$jm], $out);
    $out = str_replace('H', date('H', $timestamp), $out);
    $out = str_replace('i', date('i', $timestamp), $out);
    return toPersianNumbers($out);
}

/** تاریخ شمسی یک محتوا (نوشته/برگه) */
function elnaz_post_date($archive, string $format = 'j F Y'): string
{
    try {
        $timestamp = (int)$archive->created;
    } catch (\Throwable $e) {
        $timestamp = time();
    }
    return elnaz_jalali_date($timestamp, $format);
}

/** سال شمسی جاری برای کپی‌رایت */
function elnaz_jalali_year(): string
{
    return elnaz_jalali_date(time(), 'Y');
}

/* ================================================================
 *  ۴) بازدید و لایک
 * ================================================================ */

/** آیا افزونهٔ ViewsCounter فعال است؟ */
function elnaz_views_counter_active(): bool
{
    try {
        $plugins = \Widget\Options::alloc()->plugins;
        if (is_array($plugins) && isset($plugins['activated']) && is_array($plugins['activated'])) {
            foreach (array_keys($plugins['activated']) as $key) {
                if (stripos((string)$key, 'views') !== false) {
                    return true;
                }
            }
        }
    } catch (\Throwable $e) {
    }
    return false;
}

/** اطمینان از وجود ستون‌های views و likes (در نبود، ساخته می‌شوند) */
function elnaz_stats_ready(): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }

    $ready = false;
    try {
        $db = \Typecho\Db::get();
        $prefix = $db->getPrefix();

        $columns = [];
        try {
            // MySQL
            $rows = $db->fetchAll("SHOW COLUMNS FROM `{$prefix}contents`");
            foreach ($rows as $row) {
                $columns[] = is_array($row) ? (string)reset($row) : (string)$row->Field;
            }
        } catch (\Throwable $e) {
            $columns = [];
        }

        if (empty($columns)) {
            foreach (['views', 'likes'] as $col) {
                try {
                    $db->fetchRow($db->select("table.contents.{$col}")->from('table.contents')->limit(1));
                } catch (\Throwable $e) {
                    try {
                        $db->query("ALTER TABLE `{$prefix}contents` ADD `{$col}` INT DEFAULT 0");
                    } catch (\Throwable $e2) {
                    }
                }
            }
        } else {
            foreach (['views', 'likes'] as $col) {
                if (!in_array($col, $columns, true)) {
                    try {
                        $db->query("ALTER TABLE `{$prefix}contents` ADD `{$col}` INT DEFAULT 0");
                    } catch (\Throwable $e) {
                    }
                }
            }
        }

        $ready = true;
    } catch (\Throwable $e) {
        $ready = false;
    }
    return $ready;
}

/** تعداد بازدید نوشته */
function elnaz_views($archive): int
{
    if (elnaz_views_counter_active()) {
        try {
            $v = (int)$archive->views;
            if ($v > 0) {
                return $v;
            }
        } catch (\Throwable $e) {
        }
    }
    try {
        $cid = (int)$archive->cid;
        if ($cid < 1 || !elnaz_stats_ready()) {
            return 0;
        }
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.views')->from('table.contents')->where('table.contents.cid = ?', $cid)
        );
        return (int)($row['views'] ?? 0);
    } catch (\Throwable $e) {
        return 0;
    }
}

/** تعداد لایک نوشته */
function elnaz_likes($archive): int
{
    try {
        $cid = (int)$archive->cid;
        if ($cid < 1 || !elnaz_stats_ready()) {
            return 0;
        }
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        );
        return (int)($row['likes'] ?? 0);
    } catch (\Throwable $e) {
        return 0;
    }
}

/** شمارش بازدید صفحات تکی با کوکی ضد تکرار */
function elnaz_count_view($archive): void
{
    try {
        if (!method_exists($archive, 'is') || !$archive->is('single')) {
            return;
        }
        if (elnaz_opt('elnazCountAdminViews', '0') !== '1') {
            try {
                $user = \Widget\User::alloc();
                if ($user->hasLogin() && $user->pass('administrator', true)) {
                    return;
                }
            } catch (\Throwable $e) {
            }
        }
        $cid = (int)$archive->cid;
        if ($cid < 1 || !elnaz_stats_ready()) {
            return;
        }
        $cookieName = 'elnazV' . $cid;
        if (isset($_COOKIE[$cookieName])) {
            return;
        }
        $db = \Typecho\Db::get();
        $db->query(
            $db->update('table.contents')
                ->expression('views', 'views + 1')
                ->where('table.contents.cid = ?', $cid)
        );
        \Typecho\Cookie::set($cookieName, '1', time() + 86400);
    } catch (\Throwable $e) {
    }
}

/** شناسه‌های لایک‌شدهٔ این بازدیدکننده (کوکی elnazLikes) */
function elnaz_user_likes(): array
{
    $raw = $_COOKIE['elnazLikes'] ?? '';
    $ids = array_filter(array_map('trim', explode(',', (string)$raw)));
    $out = [];
    foreach ($ids as $id) {
        if (ctype_digit((string)$id)) {
            $out[] = (string)(int)$id;
        }
    }
    return $out;
}

/** آیا این بازدیدکننده این نوشته را لایک کرده؟ */
function elnaz_is_liked($cid): bool
{
    return in_array((string)(int)$cid, elnaz_user_likes(), true);
}

/** خروجی JSON و پایان درخواست — سخت‌سازی‌شده (الگو از افزونهٔ Booking) */
function elnaz_json(array $payload, int $status = 200): void
{
    /*
     * هر بافر خروجی باز (حتی هشدارهای PHP در حالت display_errors) پاک می‌شود تا
     * پاسخ همیشه JSON خالص باشد و سمت کلاینت res.json() هرگز شکست نخورد.
     */
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('X-Content-Type-Options: nosniff');
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** پردازش درخواست لایک — POST با پارامتر elnazLike=<cid> */
function elnaz_handle_like($request): void
{
    $cid = (int)(string)$request->get('elnazLike');
    if ($cid < 1) {
        elnaz_json(['ok' => false, 'error' => 'bad-request'], 400);
        return;
    }

    // جلوگیری ساده از CSRF
    try {
        $siteHost = (string)parse_url((string)\Widget\Options::alloc()->siteUrl, PHP_URL_HOST);
        $referer = (string)($_SERVER['HTTP_REFERER'] ?? '');
        if ($referer !== '' && $siteHost !== '' && stripos($referer, $siteHost) === false) {
            elnaz_json(['ok' => false, 'error' => 'cross-origin'], 403);
            return;
        }
    } catch (\Throwable $e) {
    }

    if (!elnaz_stats_ready()) {
        elnaz_json(['ok' => false, 'error' => 'db-error'], 500);
        return;
    }

    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        );
        if (!$row) {
            elnaz_json(['ok' => false, 'error' => 'not-found'], 404);
            return;
        }

        $likes = max(0, (int)$row['likes']);
        $likedIds = elnaz_user_likes();
        $wasLiked = in_array((string)$cid, $likedIds, true);

        if ($wasLiked) {
            $likes = max(0, $likes - 1);
            $likedIds = array_values(array_diff($likedIds, [(string)$cid]));
        } else {
            $likes = $likes + 1;
            $likedIds[] = (string)$cid;
        }

        try {
            \Typecho\Cookie::set('elnazLikes', implode(',', $likedIds), time() + 31536000);
        } catch (\Throwable $e) {
        }

        $db->query(
            $db->update('table.contents')
                ->expression('likes', 'likes + ' . ($wasLiked ? -1 : 1))
                ->where('table.contents.cid = ?', $cid)
        );

        elnaz_json([
            'ok'    => true,
            'cid'   => $cid,
            'likes' => $likes,
            'liked' => !$wasLiked,
        ]);
    } catch (\Throwable $e) {
        elnaz_json(['ok' => false, 'error' => 'server-error'], 500);
    }
}

/* ================================================================
 *  ۵) سیستم رزرو — الگوبرداری‌شده از افزونهٔ Booking
 * ================================================================
 *
 * معماری (مطابق افزونهٔ Booking pourdaryaei.ir):
 *   ۱) فرم به یک «نقطهٔ پایانی اختصاصی» POST می‌شود (نه آدرس صفحهٔ جاری):
 *      مسیر /elnaz-booking یک‌بار در جدول مسیریابی ثبت می‌شود و همیشه توسط
 *      هسته به Widget\Archive سپرده می‌شود → themeInit حتماً اجرا می‌شود و
 *      نتیجه JSON خالص است؛ مستقل از نوع صفحه، صفحهٔ نخست یا قالب سفارشی.
 *   ۲) درخواست‌ها مانند افزونه به‌صورت دیدگاه روی یک «برگهٔ پشتیبان مخفی»
 *      ذخیره می‌شوند (وضعیت waiting → عمومی نیست، شماره تلفن در فیلد url).
 *   ۳) امنیت: توکن CSRF هسته (Security::getToken) + تلهٔ هرزنامه +
 *      فاصلهٔ زمانی ارسال (commentsPostInterval) + اعتبارسنجی ایرانی.
 *   ۴) نمایش: برگهٔ «مدیریت رزروها» (قالب booking-manage.php) برای اعضای
 *      مجاز + همان دیدگاه‌ها در پنل مدیریت ← دیدگاه‌های در انتظار.
 */

/** نام مسیر نقطهٔ پایانی رزرو */
function elnaz_booking_route_name(): string
{
    return 'elnaz-booking';
}

/**
 * ثبت مسیر /elnaz-booking در جدول مسیریابی (یک‌بار — idempotent).
 * پس از ثبت، جدول مسیرِ درون‌حافظه‌ای هم همگام می‌شود تا در همان درخواست
 * اول Router::url کار کند. خطاها بی‌صدا بلعیده می‌شوند.
 */
function elnaz_register_booking_route(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    try {
        $options = \Widget\Options::alloc();
        $routingTable = $options->routingTable;

        if (!is_array($routingTable) || !isset($routingTable[elnaz_booking_route_name()])) {
            \Utils\Helper::addRoute(
                elnaz_booking_route_name(),
                '/' . elnaz_booking_route_name(),
                '\Widget\Archive',
                'render'
            );

            // همگام‌سازی جدول مسیرِ درون‌حافظه‌ای (مثل Widget\Init)
            \Typecho\Router::setRoutes($options->routingTable);
        }
    } catch (\Throwable $e) {
        // ثبت نشد؟ فرم همچنان به آدرس صفحهٔ جاری POST می‌شود و همان مسیر قدیمی کار می‌کند
    }
}

/** نشانی نقطهٔ پایانی ثبت رزرو (با جایگزین خانه در نبود مسیر) */
function elnaz_booking_endpoint(): string
{
    try {
        $url = \Typecho\Router::url(elnaz_booking_route_name(), [], \Widget\Options::alloc()->index);
        if ($url !== '#' && $url !== '') {
            return $url;
        }
    } catch (\Throwable $e) {
    }
    try {
        return (string)\Widget\Options::alloc()->siteUrl;
    } catch (\Throwable $e) {
        return '/';
    }
}

/** اسلاگ برگهٔ ذخیرهٔ رزرو (برگهٔ سیستمی پوسته) */
function elnaz_reserve_slug(): string
{
    return 'elnaz-reserve';
}

/** اسلاگ برگهٔ «مدیریت رزروها» (برگهٔ سیستمی پوسته با قالب booking-manage) */
function elnaz_manage_slug(): string
{
    return 'elnaz-bookings';
}

/** اسلاگ‌های قابل قبول برای برگهٔ دفتر رزرو (اسلاگ‌های عمومی رایج) */
function elnaz_reserve_slug_list(): array
{
    return [elnaz_reserve_slug(), 'booking', 'rezerv', 'reserve', 'nobat', 'appointment'];
}

/**
 * یافتن شناسهٔ برگهٔ دفتر رزرو:
 *  ۱) تنظیم سفارشی مدیر؛
 *  ۲) جست‌وجوی برگه‌هایی با اسلاگ رایج رزرو؛
 *  ۳) ساخت خودکار برگهٔ سیستمی «مخفی» در نخستین نیاز (مثل افزونهٔ Booking).
 */
function elnaz_reserve_cid(): int
{
    static $cid = null;
    if ($cid !== null) {
        return $cid;
    }

    try {
        $db = \Typecho\Db::get();

        // ۱) تنظیم سفارشی
        $custom = (int)elnaz_opt('elnazBookingCid', '0');
        if ($custom > 0) {
            $row = $db->fetchRow(
                $db->select('cid')->from('table.contents')->where('cid = ?', $custom)->limit(1)
            );
            if ($row) {
                $cid = (int)$row['cid'];
                return $cid;
            }
        }

        // ۲) جست‌وجوی اسلاگ‌های رایج (شامل نسخه‌های قبلی پوسته)
        $row = $db->fetchRow(
            $db->select('cid')->from('table.contents')
                ->where('type = ?', 'page')
                ->where('slug IN ?', elnaz_reserve_slug_list())
                ->limit(1)
        );
        if ($row) {
            $cid = (int)$row['cid'];
            return $cid;
        }

        // ۳) ساخت خودکار برگهٔ سیستمی «دفتر رزرو» — مخفی (مثل افزونهٔ Booking)
        $now = time();
        $adminUid = 1;
        try {
            $user = \Widget\User::alloc();
            if ($user->hasLogin()) {
                $adminUid = (int)$user->uid;
            }
        } catch (\Throwable $e) {
        }

        $text = "<!-- الناز --> برگهٔ سیستمی پوسته الناز؛ درخواست‌های رزرو و مشاورهٔ فرم سایت به‌صورت دیدگاه «در انتظار تأیید» روی همین برگه ذخیره می‌شوند. مشاهده و مدیریت از برگهٔ «مدیریت رزروها» یا مدیریت ← دیدگاه‌ها. لطفاً این برگه را حذف نکنید.";
        // Db::query برای INSERT شناسهٔ درج‌شده را برمی‌گرداند (متد Db::lastInsertId در هسته وجود ندارد)
        $cid = (int)$db->query(
            $db->insert('table.contents')->rows([
                'title'        => 'دفتر رزرو',
                'slug'         => elnaz_reserve_slug(),
                'created'      => $now,
                'modified'     => $now,
                'text'         => $text,
                'order'        => 9999,
                'authorId'     => $adminUid,
                'template'     => '',
                'type'         => 'page',
                'status'       => 'hidden',
                'password'     => '',
                'commentsNum'  => 0,
                'allowComment' => 1,
                'allowPing'    => 0,
                'allowFeed'    => 0,
                'parent'       => 0,
            ])
        );
        return $cid;
    } catch (\Throwable $e) {
        $cid = 0;
    }
    return 0;
}

/**
 * شناسهٔ برگهٔ «مدیریت رزروها» — در نبودش خودکار ساخته می‌شود (مخفی).
 * قالب برگه: booking-manage.php (فایل پوسته).
 */
function elnaz_manage_cid(): int
{
    static $cid = null;
    if ($cid !== null) {
        return $cid;
    }

    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('cid')->from('table.contents')
                ->where('type = ?', 'page')
                ->where('slug = ?', elnaz_manage_slug())
                ->limit(1)
        );
        if ($row) {
            $cid = (int)$row['cid'];
            return $cid;
        }

        $now = time();
        $adminUid = 1;
        try {
            $user = \Widget\User::alloc();
            if ($user->hasLogin()) {
                $adminUid = (int)$user->uid;
            }
        } catch (\Throwable $e) {
        }

        // Db::query برای INSERT شناسهٔ درج‌شده را برمی‌گرداند (متد Db::lastInsertId در هسته وجود ندارد)
        $cid = (int)$db->query(
            $db->insert('table.contents')->rows([
                'title'        => 'مدیریت رزروها',
                'slug'         => elnaz_manage_slug(),
                'created'      => $now,
                'modified'     => $now,
                'text'         => "<!-- الناز --> برگهٔ سیستمی پوسته الناز برای مشاهده و مدیریت درخواست‌های رزرو. فقط برای اعضای واردشده (مدیر/سردبیر) قابل استفاده است.",
                'order'        => 9999,
                'authorId'     => $adminUid,
                'template'     => 'booking-manage.php',
                'type'         => 'page',
                'status'       => 'hidden',
                'password'     => '',
                'commentsNum'  => 0,
                'allowComment' => 0,
                'allowPing'    => 0,
                'allowFeed'    => 0,
                'parent'       => 0,
            ])
        );
        return $cid;
    } catch (\Throwable $e) {
        $cid = 0;
    }
    return 0;
}

/** نشانی برگهٔ مدیریت رزروها (یا '') */
function elnaz_manage_url(): string
{
    try {
        $cid = elnaz_manage_cid();
        if ($cid < 1) {
            return '';
        }
        $url = \Typecho\Router::url('page', ['slug' => elnaz_manage_slug()], \Widget\Options::alloc()->index);
        return ($url === '#') ? '' : (string)$url;
    } catch (\Throwable $e) {
        return '';
    }
}

/** آیا این cid، برگهٔ سیستمی رزرو است؟ (برای حذف از منوها و دیدگاه‌های عمومی) */
function elnaz_is_reserve_cid(int $pageCid): bool
{
    if ($pageCid < 1) {
        return false;
    }
    $custom = (int)elnaz_opt('elnazBookingCid', '0');
    if ($custom === $pageCid) {
        return true;
    }
    try {
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('slug')->from('table.contents')->where('cid = ?', $pageCid)->limit(1)
        );
        if ($row && (in_array((string)$row['slug'], elnaz_reserve_slug_list(), true)
            || (string)$row['slug'] === elnaz_manage_slug())) {
            return true;
        }
    } catch (\Throwable $e) {
    }
    return false;
}

/** آیا کاربر فعلی اجازهٔ مدیریت رزروها را دارد؟ (مدیر/سردبیر) */
function elnaz_can_manage_bookings(): bool
{
    try {
        $user = \Widget\User::alloc();
        return $user->hasLogin() && $user->pass('editor', true);
    } catch (\Throwable $e) {
        return false;
    }
}

/** تعداد رزروهای در انتظار بررسی */
function elnaz_pending_bookings_count(): int
{
    try {
        $cid = elnaz_reserve_cid();
        if ($cid < 1) {
            return 0;
        }
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select(['COUNT(coid)' => 'n'])->from('table.comments')
                ->where('cid = ? AND parent = 0 AND type = ? AND status = ?', $cid, 'comment', 'waiting')
        );
        return (int)($row['n'] ?? 0);
    } catch (\Throwable $e) {
        return 0;
    }
}

/** تبدیل ارقام فارسی/عربی به انگلیسی (مثل افزونهٔ Booking) */
function elnaz_to_english_digits(string $s): string
{
    return strtr($s, [
        '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
        '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
        '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
        '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
    ]);
}

/** اعتبارسنجی شمارهٔ تلفن ایرانی: 09xxxxxxxxx / +98… / 0xxxxxxxxx */
function elnaz_valid_phone(string $phone): bool
{
    $phone = elnaz_to_english_digits(trim($phone));
    $phone = str_replace([' ', '-', '(', ')', "\t"], '', $phone);
    return (bool)preg_match('/^(\+98|98|0098|0)?9\d{9}$/', $phone)
        || (bool)preg_match('/^0\d{9,10}$/', $phone);
}

/**
 * اعتبارسنجی توکن امنیتی CSRF — همان منطق Widget\Security::protect با
 * دو پذیرش جانبی: ارجاع هم‌مبدأ و (در نبود هر دو) ارجاع خالی، تا فرم
 * هرگز برای کاربر واقعی نشکند (الگوی protect افزونهٔ Booking).
 */
function elnaz_booking_token_ok($request): bool
{
    try {
        $security = \Widget\Security::alloc();
        $token = (string)$request->get('_', '');
        $referer = (string)$request->getReferer();

        if ($token !== '') {
            if (hash_equals($security->getToken($referer), $token)) {
                return true;
            }
            if (hash_equals($security->getToken((string)$request->getRequestUrl()), $token)) {
                return true;
            }
        }

        // پذیرش جانبی ۱: ارجاع هم‌مبدأ (رفتار پیش‌فرض مرورگرها برای POST هم‌مبدأ)
        if ($referer !== '') {
            $siteHost = (string)parse_url((string)\Widget\Options::alloc()->siteUrl, PHP_URL_HOST);
            $refHost = (string)parse_url($referer, PHP_URL_HOST);
            if ($siteHost !== '' && strcasecmp($siteHost, $refHost) === 0) {
                return true;
            }
            return false; // ارجاع بیگانه → رد
        }

        // پذیرش جانبی ۲: بدون ارجاع (مرورگرهای حریم‌خصوصی) → قبول؛
        // تلهٔ هرزنامه و محدودیت ارسال همچنان محافظت می‌کنند
        return true;
    } catch (\Throwable $e) {
        return true;
    }
}

/**
 * پردازش درخواست رزرو — POST به نقطهٔ پایانی /elnaz-booking (یا هر صفحهٔ پوسته).
 *
 * حالت‌ها (مثل افزونهٔ Booking):
 *  - پیش‌فرض  : ثبت رزرو جدید (فرم عمومی؛ پارامتر elnazBooking=1)
 *  - mode=approve | reject | delete : مدیریت رزرو (فقط اعضای مجاز)
 */
function elnaz_handle_booking($request): void
{
    // ---------- حالت‌های مدیریتی (تأیید/رد/حذف) ----------
    $mode = trim((string)$request->get('mode', ''));
    if (in_array($mode, ['approve', 'reject', 'delete'], true)) {
        elnaz_handle_booking_manage($request, $mode);
        return;
    }

    // ---------- توکن امنیتی (CSRF) ----------
    if (!elnaz_booking_token_ok($request)) {
        elnaz_json(['ok' => false, 'error' => 'درخواست از منبع نامعتبر است؛ صفحه را رفرش کنید و دوباره تلاش کنید.'], 403);
    }

    // ---------- تلهٔ هرزنامه (honeypot باید خالی باشد) ----------
    $hp = trim((string)$request->get('elnazHp', ''));
    if ($hp !== '') {
        elnaz_json(['ok' => true, 'stored' => true]); // پاسخ مثبت کاذب برای ربات‌ها
    }

    // ---------- داده‌های فرم (ارقام فارسی → انگلیسی) ----------
    $name    = trim((string)$request->get('elnazName', ''));
    $phone   = elnaz_to_english_digits(trim((string)$request->get('elnazPhone', '')));
    $phone   = str_replace([' ', '-', '(', ')', "\t"], '', $phone);
    $mail    = trim((string)$request->get('elnazMail', ''));
    $service = trim((string)$request->get('elnazService', ''));
    $goal    = trim((string)$request->get('elnazGoal', ''));
    $age     = elnaz_to_english_digits(trim((string)$request->get('elnazAge', '')));
    $height  = elnaz_to_english_digits(trim((string)$request->get('elnazHeight', '')));
    $weight  = elnaz_to_english_digits(trim((string)$request->get('elnazWeight', '')));
    $note    = trim((string)$request->get('elnazNote', ''));

    // ---------- اعتبارسنجی ----------
    if (mb_strlen($name) < 2) {
        elnaz_json(['ok' => false, 'error' => 'نام را کامل وارد کنید.'], 422);
    }
    if (!elnaz_valid_phone($phone)) {
        elnaz_json(['ok' => false, 'error' => 'شمارهٔ تلفن معتبر نیست (مثال: ۰۹۱۲۳۴۵۶۷۸۹).'], 422);
    }
    if ($mail !== '' && !filter_var($mail, FILTER_VALIDATE_EMAIL)) {
        elnaz_json(['ok' => false, 'error' => 'ایمیل واردشده معتبر نیست.'], 422);
    }
    $ageInt = (int)$age;
    if ($age !== '' && ($ageInt < 2 || $ageInt > 120)) {
        elnaz_json(['ok' => false, 'error' => 'سن واردشده معتبر نیست.'], 422);
    }

    // برش طولانی‌ها (مثل افزونهٔ Booking)
    $name    = mb_substr($name, 0, 150);
    $mail    = mb_substr($mail, 0, 150);
    $service = mb_substr($service, 0, 150);
    $goal    = mb_substr($goal, 0, 150);
    $note    = mb_substr($note, 0, 2000);

    // ---------- ذخیره به‌صورت دیدگاه مخفی روی برگهٔ دفتر رزرو ----------
    $cid = elnaz_reserve_cid();
    if ($cid < 1) {
        elnaz_json(['ok' => false, 'error' => 'خطای سرور در ساخت دفتر رزرو؛ لطفاً چند لحظه بعد دوباره تلاش کنید.'], 500);
    }

    try {
        $options = \Widget\Options::alloc();
        $db = \Typecho\Db::get();

        $ownerRow = $db->fetchRow(
            $db->select('authorId')->from('table.contents')->where('cid = ?', $cid)->limit(1)
        );
        $ownerId = (int)($ownerRow['authorId'] ?? 1);

        /*
         * محدودیت فاصلهٔ ارسال (مثل Widget\Feedback و افزونهٔ Booking):
         * اگر گزینهٔ commentsPostIntervalEnable فعال باشد و آخرین ارسالِ همین IP
         * روی این برگه کمتر از commentsPostInterval ثانیه پیش بوده باشد، رد می‌شود.
         */
        $intervalBlocked = false;
        try {
            if (!\Widget\User::alloc()->pass('editor', true) && $options->commentsPostIntervalEnable) {
                $latest = $db->fetchRow(
                    $db->select('created')->from('table.comments')
                        ->where('cid = ? AND ip = ?', $cid, $request->getIp())
                        ->order('created', \Typecho\Db::SORT_DESC)
                        ->limit(1)
                );
                if ($latest && (int)$options->time - (int)$latest['created'] >= 0
                    && (int)$options->time - (int)$latest['created'] < (int)$options->commentsPostInterval) {
                    $intervalBlocked = true;
                }
            }
        } catch (\Throwable $e) {
        }
        if ($intervalBlocked) {
            elnaz_json(['ok' => false, 'error' => 'ارسال‌ها بیش از حد نزدیک است؛ چند دقیقه بعد دوباره تلاش کنید.'], 429);
        }

        // متن خوانا برای پنل مدیریت (نمایش عمومی ندارد)
        $lines = ['[درخواست جلسهٔ رایگان باشگاه]'];
        $lines[] = 'نام: ' . $name;
        $lines[] = 'تلفن: ' . $phone;
        if ($mail !== '') {
            $lines[] = 'ایمیل: ' . $mail;
        }
        if ($service !== '') {
            $lines[] = 'نوع خدمت: ' . $service;
        }
        if ($goal !== '') {
            $lines[] = 'هدف: ' . $goal;
        }
        if ($age !== '' || $height !== '' || $weight !== '') {
            $lines[] = 'سن: ' . ($age !== '' ? toPersianNumbers($age) : '—')
                . ' | قد: ' . ($height !== '' ? toPersianNumbers($height) : '—')
                . ' | وزن: ' . ($weight !== '' ? toPersianNumbers($weight) : '—');
        }
        if ($note !== '') {
            $lines[] = 'توضیحات: ' . $note;
        }

        // ثبت (شمارهٔ تلفن در فیلد url — الگوی افزونهٔ Booking)
        // توجه: در هستهٔ تایپ‌رینیو Db::query برای INSERT همان شناسهٔ درج‌شده را برمی‌گرداند
        // و متد عمومی Db::lastInsertId وجود ندارد؛ الگوی صحیح همین است.
        $coid = (int)$db->query(
            $db->insert('table.comments')->rows([
                'cid'      => $cid,
                'created'  => (int)$options->time,
                'author'   => $name,
                'authorId' => 0,
                'ownerId'  => $ownerId,
                'mail'     => $mail,
                'url'      => $phone,
                'ip'       => substr((string)$request->getIp(), 0, 64),
                'agent'    => substr((string)$request->getAgent(), 0, 511),
                'text'     => implode("\n", $lines),
                'type'     => 'comment',
                'status'   => 'waiting', // هرگز عمومی نمی‌شود؛ فقط پنل مدیریت و برگهٔ مدیریت رزروها
                'parent'   => 0,
            ])
        );

        // شمارندهٔ دیدگاه‌های برگه (برای پنل مدیریت درست باشد)
        try {
            $db->query(
                $db->update('table.contents')
                    ->expression('commentsNum', 'commentsNum + 1')
                    ->where('cid = ?', $cid)
            );
        } catch (\Throwable $e) {
        }

        // اطلاع‌رسانی ایمیلی مدیر (در صورت پیکربندی ایمیل در تایپ‌رینیو)
        try {
            $elnazAdminMail = trim((string)($options->mailFrom ?? $options->mailSmtpUser ?? ''));
            if ($elnazAdminMail === '') {
                $elnazAdminMail = trim((string)($options->adminMail ?? ''));
            }
            if ($elnazAdminMail !== '' && filter_var($elnazAdminMail, FILTER_VALIDATE_EMAIL)
                && class_exists('\Typecho\Mail\Message') && class_exists('\Typecho\Mail\Queue')) {
                $manageUrl = elnaz_manage_url();
                $elnazMailText = implode("\n", $lines)
                    . ($manageUrl !== '' ? "\n\nمشاهده و مدیریت:\n" . $manageUrl : '');
                $elnazMailHtml = '<div style="font-family:Tahoma,Arial,sans-serif;direction:rtl;text-align:right;line-height:2">'
                    . nl2br(htmlspecialchars($elnazMailText, ENT_QUOTES, 'UTF-8')) . '</div>';
                $elnazMessage = new \Typecho\Mail\Message(
                    $elnazAdminMail,
                    'درخواست رزرو جدید — ' . $name,
                    $elnazMailHtml,
                    $elnazAdminMail,
                    (string)($options->mailFromName ?? $options->title ?? 'الناز'),
                    'مدیر سایت',
                    $elnazMailText
                );
                \Typecho\Mail\Queue::enqueue('booking', $elnazMessage, $db, $options);
            }
        } catch (\Throwable $e) {
            // ایمیل اختیاری است؛ نبود آن خطا محسوب نمی‌شود
        }

        elnaz_json([
            'ok'     => true,
            'stored' => true,
            'coid'   => $coid,
        ]);
    } catch (\Throwable $e) {
        // ثبت خطای واقعی در لاگ PHP برای عیب‌یابی (پیام کاربر تغییر نمی‌کند)
        try {
            error_log('[elnaz] booking save failed: ' . $e->getMessage()
                . ' @ ' . $e->getFile() . ':' . $e->getLine());
        } catch (\Throwable $e2) {
        }
        elnaz_json(['ok' => false, 'error' => 'خطای سرور در ذخیرهٔ درخواست؛ لطفاً دوباره تلاش کنید.'], 500);
    }
}

/**
 * حالت‌های مدیریتی رزرو (تأیید/رد/حذف) — فقط اعضای مجاز (مدیر/سردبیر).
 * coid باید متعلق به برگهٔ دفتر رزرو باشد (بررسی مثل افزونهٔ Booking).
 */
function elnaz_handle_booking_manage($request, string $mode): void
{
    if (!elnaz_can_manage_bookings()) {
        elnaz_json(['ok' => false, 'error' => 'برای مدیریت رزروها باید با حساب مدیر وارد شوید.'], 403);
    }

    // توکن امنیتی (ادغام با منطق همانند protect)
    if (!elnaz_booking_token_ok($request)) {
        elnaz_json(['ok' => false, 'error' => 'توکن امنیتی نامعتبر است؛ صفحه را رفرش کنید.'], 403);
    }

    $coid = (int)(string)$request->get('coid', '0');
    if ($coid < 1) {
        elnaz_json(['ok' => false, 'error' => 'شناسهٔ رزرو نامعتبر است.'], 400);
    }

    try {
        $cid = elnaz_reserve_cid();
        if ($cid < 1) {
            elnaz_json(['ok' => false, 'error' => 'دفتر رزرو یافت نشد.'], 500);
        }
        $db = \Typecho\Db::get();

        // فقط رزروهای همین دفتر
        $row = $db->fetchRow(
            $db->select('coid, status')->from('table.comments')
                ->where('coid = ? AND cid = ? AND parent = 0 AND type = ?', $coid, $cid, 'comment')
                ->limit(1)
        );
        if (!$row) {
            elnaz_json(['ok' => false, 'error' => 'رزروی با این شناسه یافت نشد.'], 404);
        }

        if ($mode === 'delete') {
            $db->query(
                $db->delete('table.comments')->where('coid = ? AND cid = ?', $coid, $cid)
            );
            // کاهش شمارنده
            try {
                $db->query(
                    $db->update('table.contents')
                        ->expression('commentsNum', 'GREATEST(commentsNum - 1, 0)')
                        ->where('cid = ?', $cid)
                );
            } catch (\Throwable $e) {
            }
        } else {
            $status = ($mode === 'approve') ? 'approved' : 'spam';
            $db->query(
                $db->update('table.comments')
                    ->rows(['status' => $status])
                    ->where('coid = ? AND cid = ?', $coid, $cid)
            );
        }

        elnaz_json([
            'ok'         => true,
            'mode'       => $mode,
            'coid'       => $coid,
            'status'     => ($mode === 'delete') ? 'deleted' : (($mode === 'approve') ? 'approved' : 'spam'),
            'pending'    => elnaz_pending_bookings_count(),
        ]);
    } catch (\Throwable $e) {
        elnaz_json(['ok' => false, 'error' => 'خطای سرور در به‌روزرسانی رزرو.'], 500);
    }
}

/**
 * فهرست رزروها برای برگهٔ «مدیریت رزروها».
 * ترتیب: در انتظار اول، سپس تأییدشده‌ها و ردشده‌ها (جدید به قدیم).
 */
function elnaz_bookings_list(int $limit = 200): array
{
    try {
        $cid = elnaz_reserve_cid();
        if ($cid < 1) {
            return [];
        }
        $db = \Typecho\Db::get();
        $rows = $db->fetchAll(
            $db->select('coid', 'created', 'author', 'mail', 'url', 'ip', 'text', 'status')
                ->from('table.comments')
                ->where('cid = ? AND parent = 0 AND type = ?', $cid, 'comment')
                ->order('status', \Typecho\Db::SORT_ASC)   // approved < spam < waiting (الفبایی: در انتظار آخر؛ چیدمان نهایی پایین)
                ->order('created', \Typecho\Db::SORT_DESC)
                ->limit($limit)
        );

        // waiting اول، سپس approved، سپس spam — هر کدام جدید به قدیم
        $order = ['waiting' => 0, 'approved' => 1, 'spam' => 2];
        usort($rows, function ($a, $b) use ($order) {
            $ka = $order[$a['status']] ?? 3;
            $kb = $order[$b['status']] ?? 3;
            if ($ka !== $kb) {
                return $ka <=> $kb;
            }
            return (int)$b['created'] <=> (int)$a['created'];
        });

        foreach ($rows as &$r) {
            $r = array_merge($r, elnaz_parse_booking_text((string)$r['text']));
        }
        unset($r);

        return $rows;
    } catch (\Throwable $e) {
        return [];
    }
}

/**
 * پارس متن خوانای رزرو به فیلدهای ساختاریافته برای نمایش در برگهٔ مدیریت.
 * (قالب متن را خودمان در elnaz_handle_booking می‌نویسیم؛ پس پارس قطعی است.)
 */
function elnaz_parse_booking_text(string $text): array
{
    $out = [
        'phone'   => '',
        'mail'    => '',
        'service' => '',
        'goal'    => '',
        'age'     => '',
        'height'  => '',
        'weight'  => '',
        'bmi'     => '',
        'note'    => '',
    ];

    foreach (preg_split('/\r\n|\r|\n/', $text) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '[') {
            continue;
        }
        $pos = strpos($line, ':');
        if ($pos === false) {
            continue;
        }
        $key = trim(substr($line, 0, $pos));
        $val = trim(substr($line, $pos + 1));
        switch ($key) {
            case 'تلفن':
                $out['phone'] = $val;
                break;
            case 'ایمیل':
                $out['mail'] = $val;
                break;
            case 'نوع خدمت':
                $out['service'] = $val;
                break;
            case 'هدف':
                $out['goal'] = $val;
                break;
            case 'کالری هدف':
                $out['bmi'] = $val;
                break;
            case 'توضیحات':
                $out['note'] = $val;
                break;
            case 'سن': // «سن: ۳۲ | قد: ۱۶۵ | وزن: ۷۰»
                foreach (explode('|', $val) as $part) {
                    $part = trim($part);
                    $p = strpos($part, ':');
                    if ($p === false) {
                        continue;
                    }
                    $k = trim(substr($part, 0, $p));
                    $v = trim(substr($part, $p + 1));
                    if ($k === 'سن') {
                        $out['age'] = ($v === '—') ? '' : $v;
                    } elseif ($k === 'قد') {
                        $out['height'] = ($v === '—') ? '' : $v;
                    } elseif ($k === 'وزن') {
                        $out['weight'] = ($v === '—') ? '' : $v;
                    }
                }
                break;
        }
    }
    return $out;
}

/* ================================================================
 *  ۶) راه‌انداز پوسته
 * ================================================================ */

// ثبت مسیر اختصاصی رزرو (یک‌بار؛ idempotent) — باید پیش از رندر فرم اجرا شود
elnaz_register_booking_route();

function themeInit($archive)
{
    // هوک شمارش بازدید قبل از رندر
    try {
        \Typecho\Plugin::factory('Widget\Archive')->beforeRender = 'elnaz_count_view';
    } catch (\Throwable $e) {
    }

    /*
     * نکتهٔ مهم: پراپرتی‌های request و parameter ویجت «محافظت‌شده» (protected) هستند و
     * از یک تابع سراسری، Typecho\Widget::__get() برایشان null برمی‌گرداند؛ یعنی الگوی
     * $archive->request->isPost() هرگز اجرا نمی‌شود. برای همین، کل این بخش داخل یک
     * Closure متصل به اسکوپ کلاس Typecho\Widget اجرا می‌شود تا PHP اجازهٔ دسترسی بدهد.
     */
    try {
        \Closure::bind(function () {
            /** @var \Widget\Archive $this */

            // نقطهٔ پایانی AJAX لایک
            if ($this->request->isPost() && (string)$this->request->get('elnazLike', '') !== '') {
                elnaz_handle_like($this->request);
            }

            /*
             * نقطهٔ پایانی AJAX رزرو — سه مسیر پوشش داده می‌شود:
             *  ۱) POST به مسیر اختصاصی /elnaz-booking (مسیر در functions.php ثبت شده)
             *  ۲) POST به هر صفحهٔ پوسته (پشتیبان؛ مثل رفتار قدیمی)
             *  ۳) POST به مسیر ثبت‌نشده → 404 → ExceptionHandle → Archive(404) → همین themeInit
             */
            if ($this->request->isPost() && (string)$this->request->get('elnazBooking', '') !== '') {
                elnaz_handle_booking($this->request);
            }

            // درخواست غیر-POST روی نقطهٔ پایانی اختصاصی → 405 (endpoint فقط برای POST است)
            if ((string)$this->request->getPathInfo() === '/' . elnaz_booking_route_name()) {
                if (!$this->request->isPost()) {
                    elnaz_json(['ok' => false, 'error' => 'این نقطهٔ پایانی فقط برای ثبت درخواست رزرو است.'], 405);
                }
            }

            /*
             * فهرست وبلاگ روی مسیر آرشیو (پیش‌فرض /blog/):
             * هستهٔ تایپ‌رینیو مسیر archive را با ۴۰۴ می‌بندد؛ در حالت پیش‌فرض
             * (صفحهٔ نخست = نوشته‌های اخیر) نوع درخواست را به index تبدیل می‌کنیم تا
             * فهرست مقالات همیشه در /blog/ رندر شود و منوی «مقالات» کار کند.
             */
            $elnazRouteType = (string)$this->parameter->type;
            if ($elnazRouteType === 'archive' || $elnazRouteType === 'archive_page') {
                $elnazFrontPage = 'recent';
                $elnazFrontArchive = 0;
                try {
                    $elnazFrontPage = (string)\Widget\Options::alloc()->frontPage;
                    $elnazFrontArchive = (int)\Widget\Options::alloc()->frontArchive;
                } catch (\Throwable $e) {
                }
                if ($elnazFrontPage === 'recent' || $elnazFrontArchive !== 1) {
                    $this->parameter->type = ($elnazRouteType === 'archive_page') ? 'index_page' : 'index';
                }
            }
        }, $archive, \Typecho\Widget::class)();
    } catch (\Throwable $e) {
    }
}

/* ================================================================
 *  ۷) پارسرهای بخش‌های داینامیک
 * ================================================================ */

/** پارس خطوط «الف | ب | ج» — جداکننده فقط | */
function elnaz_parse_lines(?string $text, int $minParts = 1): array
{
    $text = (string)$text;
    if (trim($text) === '') {
        return [];
    }
    $out = [];
    foreach (preg_split('/\r\n|\r|\n/', $text) as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        $parts = preg_split('/\s*\|\s*/', $line);
        $parts = array_map('trim', $parts);
        while (count($parts) > 0 && $parts[count($parts) - 1] === '') {
            array_pop($parts);
        }
        if (count($parts) >= $minParts) {
            $out[] = $parts;
        }
    }
    return $out;
}

/** پارس آمار هیرو: «عدد | عنوان» */
function elnaz_parse_stats(?string $text): array
{
    $out = [];
    foreach (elnaz_parse_lines($text, 2) as $parts) {
        $num = toPersianNumbers(preg_replace('/[^0-9+]/', '', $parts[0]));
        $out[] = ['num' => ($num !== '' ? $num : '۰'), 'label' => $parts[1]];
    }
    return $out;
}

/** پارس خدمات: «آیکون | عنوان | توضیح | آدرس (اختیاری)» */
function elnaz_parse_services(?string $text): array
{
    $out = [];
    foreach (elnaz_parse_lines($text, 2) as $parts) {
        $out[] = [
            'icon'  => elnaz_icon_exists($parts[0]) ? $parts[0] : 'leaf',
            'title' => $parts[1],
            'desc'  => $parts[2] ?? '',
            'url'   => $parts[3] ?? '',
        ];
    }
    return $out;
}

/** پارس پکیج‌ها: «عنوان | قیمت | قیمت قبل | توضیح | ویژگی‌ها (با , جدا) | آدرس | بج */
function elnaz_parse_packages(?string $text): array
{
    $out = [];
    foreach (elnaz_parse_lines($text, 2) as $parts) {
        $out[] = [
            'title'    => $parts[0],
            'price'    => $parts[1] ?? '',
            'oldPrice' => $parts[2] ?? '',
            'desc'     => $parts[3] ?? '',
            'items'    => array_filter(array_map('trim', explode(',', (string)($parts[4] ?? '')))),
            'url'      => $parts[5] ?? '',
            'badge'    => $parts[6] ?? '',
        ];
    }
    return $out;
}

/** پارس تیم: «نام | سمت | عکس | توضیح (اختیاری)» */
function elnaz_parse_team(?string $text): array
{
    $out = [];
    foreach (elnaz_parse_lines($text, 2) as $parts) {
        $photo = trim($parts[2] ?? '');
        if ($photo !== '' && preg_match('#^(data:|https?://|//)#i', $photo) !== 1) {
            $photo = elnaz_asset(ltrim($photo, '/'));
        }
        $out[] = [
            'name' => $parts[0],
            'role' => $parts[1],
            'photo' => $photo,
            'desc' => $parts[3] ?? '',
        ];
    }
    return $out;
}

/** حرف اول نام → آواتار حرفی */
function elnaz_initial(string $name): string
{
    $name = trim($name);
    if ($name === '') {
        return '؟';
    }
    return mb_substr($name, 0, 1, 'UTF-8');
}

/* ================================================================
 *  ۸) تصویر شاخص، فیلدهای اختصاصی و نوشته‌های مرتبط
 * ================================================================ */

/** تصویر شاخص نوشته: فیلدهای thumb/cover → اولین تصویر متن → پیش‌فرض */
function elnaz_thumbnail($content, bool $fallback = true): string
{
    // ۱) فیلدهای اختصاصی
    try {
        $fields = $content->fields;
        foreach (['thumb', 'cover', 'img', 'thumbnail', 'banner'] as $key) {
            $value = trim((string)($fields->{$key} ?? ''));
            if ($value !== '') {
                return elnaz_resolve_url($value);
            }
        }
    } catch (\Throwable $e) {
    }

    // ۲) نخستین تصویر متن خام
    try {
        $text = (string)$content->text;
        if ($text !== '') {
            if (preg_match('#<img[^>]*\bsrc=["\']([^"\']+)["\']#iu', $text, $m)) {
                return elnaz_resolve_url($m[1]);
            }
            if (preg_match('#!\[[^\]]*\]\(\s*<?([^)\s>]+)[^)]*\)#iu', $text, $m)) {
                return elnaz_resolve_url($m[1]);
            }
        }
    } catch (\Throwable $e) {
    }

    // ۳) پیش‌فرض
    return $fallback ? elnaz_asset('img/default-cover.jpg') : '';
}

/** فیلد کالری نوشته (اگر از فیلدهای اختصاصی تنظیم شده باشد) */
function elnaz_calories($content): string
{
    try {
        $fields = $content->fields;
        $value = trim((string)($fields->calories ?? ''));
        if ($value !== '' && is_numeric($value)) {
            return toPersianNumbers($value);
        }
    } catch (\Throwable $e) {
    }
    return '';
}

/** زمان تهیهٔ دستور پخت (دقیقه) — فیلد اختصاصی cookTime */
function elnaz_cook_time($content): string
{
    try {
        $fields = $content->fields;
        $value = trim((string)($fields->cookTime ?? ''));
        if ($value !== '' && is_numeric($value)) {
            return toPersianNumbers($value);
        }
    } catch (\Throwable $e) {
    }
    return '';
}

/**
 * آخرین مقالات منتشرشده برای صفحهٔ اول:
 * کوئری مستقیم شامل متن (برای چکیده) + فیلدهای اختصاصی (تصویر/کالری/زمان تهیه) + بازدید.
 */
function elnaz_recent_posts(int $count = 3): array
{
    $out = [];
    $count = max(1, min(12, $count));
    try {
        $db = \Typecho\Db::get();
        $hasStats = elnaz_stats_ready();
        $cols = ['table.contents.cid', 'table.contents.title', 'table.contents.slug',
            'table.contents.created', 'table.contents.text'];
        if ($hasStats) {
            $cols[] = 'table.contents.views';
        }
        $rows = $db->fetchAll(
            $db->select(...$cols)
                ->from('table.contents')
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', \Widget\Options::alloc()->time)
                ->where('table.contents.type = ?', 'post')
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit($count)
        );
        if (empty($rows)) {
            return $out;
        }

        // فیلدهای اختصاصی همهٔ نوشته‌ها در یک کوئری
        $cids = array_map(function ($r) { return (int)$r['cid']; }, $rows);
        $fieldMap = [];
        try {
            $frows = $db->fetchAll(
                $db->select()->from('table.fields')->where('cid IN ?', $cids)
            );
            foreach ((array)$frows as $f) {
                $val = ('json' == $f['type']) ? json_decode((string)$f['str_value'], true) : $f[$f['type'] . '_value'];
                $fieldMap[(int)$f['cid']][(string)$f['name']] = (string)$val;
            }
        } catch (\Throwable $e) {
        }

        // مسیر پیوندها
        $siteBase = rtrim((string)\Widget\Options::alloc()->siteUrl, '/');
        $route = \Widget\Options::alloc()->routingTable['post'];
        $routeUrl = is_string($route) ? $route : ($route['url'] ?? '');

        foreach ($rows as $row) {
            $cid = (int)$row['cid'];
            $path = str_replace(['[slug:digital]', '[slug]', '[cid:digital]', '[cid]'],
                [(string)$row['slug'], (string)$row['slug'], (string)$cid, (string)$cid], $routeUrl);
            $text = (string)$row['text'];
            if (strpos($text, '<!--markdown-->') === 0) {
                $text = substr($text, 15);
            }

            // تصویر شاخص: فیلد → اولین تصویر متن → پیش‌فرض
            $thumb = '';
            $fields = $fieldMap[$cid] ?? [];
            foreach (['thumb', 'cover', 'img', 'thumbnail', 'banner'] as $key) {
                if (isset($fields[$key]) && trim($fields[$key]) !== '') {
                    $thumb = elnaz_resolve_url(trim($fields[$key]));
                    break;
                }
            }
            if ($thumb === '' && preg_match('#<img[^>]*\bsrc=["\']([^"\']+)["\']#iu', $text, $m)) {
                $thumb = elnaz_resolve_url($m[1]);
            } elseif ($thumb === '' && preg_match('#!\[[^\]]*\]\(\s*<?([^)\s>]+)[^)]*\)#iu', $text, $m)) {
                $thumb = elnaz_resolve_url($m[1]);
            }
            if ($thumb === '') {
                $thumb = elnaz_asset('img/default-cover.jpg');
            }

            $out[] = [
                'title'    => (string)$row['title'],
                'url'      => $siteBase . '/' . ltrim($path, '/'),
                'created'  => (int)$row['created'],
                'excerpt'  => trim(strip_tags($text)),
                'thumb'    => $thumb,
                'calories' => $fields['calories'] ?? '',
                'cookTime' => $fields['cookTime'] ?? '',
                'views'    => $hasStats ? (int)($row['views'] ?? 0) : 0,
            ];
        }
    } catch (\Throwable $e) {
    }
    return $out;
}

/** نوشته‌های مرتبط بر اساس دستهٔ مشترک */
function elnaz_related_posts($archive, int $count = 3): array
{

    $out = [];
    try {
        $cid = (int)$archive->cid;
        if ($cid < 1) {
            return $out;
        }
        $category = $archive->getCategory ? $archive->getCategory() : [];
        $mid = 0;
        if (is_array($category) && isset($category[0]['mid'])) {
            $mid = (int)$category[0]['mid'];
        }
        if ($mid < 1) {
            return $out;
        }

        $db = \Typecho\Db::get();
        $rows = $db->fetchAll(
            $db->select('table.contents.cid', 'table.contents.title', 'table.contents.slug', 'table.contents.created')
                ->from('table.contents')
                ->join('table.relationships', 'table.contents.cid = table.relationships.cid')
                ->where('table.relationships.mid = ?', $mid)
                ->where('table.contents.cid <> ?', $cid)
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', \Widget\Options::alloc()->time)
                ->where('table.contents.type = ?', 'post')
                ->order('table.contents.created', \Typecho\Db::SORT_DESC)
                ->limit($count)
        );

        foreach ($rows as $row) {
            $route = \Widget\Options::alloc()->routingTable['post'];
            $path = str_replace('[slug:digital]', (string)$row['slug'], is_string($route) ? $route : ($route['url'] ?? ''));
            $path = str_replace(['[slug]', '[cid:digital]', '[cid]'], [(string)$row['slug'], (string)$row['cid'], (string)$row['cid']], $path);
            $out[] = [
                'title' => $row['title'],
                'url' => rtrim((string)\Widget\Options::alloc()->siteUrl, '/') . '/' . ltrim($path, '/'),
                'created' => (int)$row['created'],
            ];
        }
    } catch (\Throwable $e) {
    }
    return $out;
}

/* ================================================================
 *  ۹) لوگو
 * ================================================================ */

/** آدرس لوگو: تنظیمات → فایل محلی img/logo.png → خالی (آیکون پیش‌فرض) */
function elnaz_logo_url(): string
{
    $setting = elnaz_opt_raw('elnazLogoUrl');
    if ($setting !== null) {
        $setting = trim($setting);
        if ($setting !== '') {
            return elnaz_resolve_url($setting);
        }
    }

    $local = __TYPECHO_ROOT_DIR__ . '/usr/themes/' . basename(__DIR__) . '/img/logo.png';
    if (is_file($local)) {
        return elnaz_asset('img/logo.png');
    }
    return '';
}

/* ================================================================
 *  ۱۰) فرم تنظیمات پوسته
 * ================================================================ */

function themeConfig($form)
{
    /* ---------- بخش ۱: عمومی ---------- */

    $clinicName = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazClinicName',
        null,
        'باشگاه الناز',
        _t('نام کلینیک / مرکز'),
        _t('نام مرکز در هدر، فوتر و عنوان صفحهٔ اول نمایش داده می‌شود.')
    );
    $form->addInput($clinicName->addRule('xssCheck', _t('لطفاً نام معتبر وارد کنید')));

    $tagline = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazTagline',
        null,
        'بدن قوی، ذهن قوی',
        _t('شعار کوتاه'),
        _t('زیر نام مرکز در هدر و جاهای کم‌رنگ‌تر نمایش داده می‌شود.')
    );
    $form->addInput($tagline->addRule('xssCheck', _t('لطفاً متن معتبر وارد کنید')));

    $logoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazLogoUrl',
        null,
        null,
        _t('آدرس لوگو'),
        _t('آدرس تصویر لوگو (اختیاری). اگر خالی باشد و فایل img/logo.png داخل پوسته باشد از آن استفاده می‌شود؛ در غیر این صورت آیکون دمبل الناز نمایش داده می‌شود.')
    );
    $form->addInput($logoUrl->addRule('xssCheck', _t('لطفاً یک آدرس معتبر وارد کنید')));

    $primaryColor = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazPrimaryColor',
        null,
        '#d4af37',
        _t('رنگ اصلی (طلایی)'),
        _t('کد HEX مثل #d4af37 — برای دکمه‌ها، لینک‌ها و تاکیدها.')
    );
    $form->addInput($primaryColor->addRule('xssCheck', _t('کد رنگ HEX وارد کنید (مثل #d4af37)')));

    $secondaryColor = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazSecondaryColor',
        null,
        '#b8860b',
        _t('رنگ دوم (طلایی تیره)'),
        _t('کد HEX مثل #b8860b — برای گرادیان‌ها و متن‌های برجسته.')
    );
    $form->addInput($secondaryColor->addRule('xssCheck', _t('کد رنگ HEX وارد کنید (مثل #b8860b)')));

    $showTopbar = new \Typecho\Widget\Helper\Form\Element\Radio(
        'elnazShowTopbar',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('نوار بالای هدر'),
        _t('نوار باریک بالای هدر شامل تلفن، ساعت کاری و شبکه‌های اجتماعی.')
    );
    $form->addInput($showTopbar);

    $showViews = new \Typecho\Widget\Helper\Form\Element\Radio(
        'elnazShowViews',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('شمار بازدید'),
        _t('نمایش تعداد بازدید در صفحهٔ نوشته و کارت‌های فهرست وبلاگ.')
    );
    $form->addInput($showViews);

    $showLikes = new \Typecho\Widget\Helper\Form\Element\Radio(
        'elnazShowLikes',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('دکمهٔ لایک'),
        _t('دکمهٔ پسندیدن نوشته‌ها با شمارش AJAX.')
    );
    $form->addInput($showLikes);

    $countAdminViews = new \Typecho\Widget\Helper\Form\Element\Radio(
        'elnazCountAdminViews',
        ['0' => _t('نشمرده شود'), '1' => _t('شمرده شود')],
        '0',
        _t('بازدید مدیر'),
        _t('آیا بازدید مدیر سایت هم شمرده شود؟')
    );
    $form->addInput($countAdminViews);

    /* ---------- بخش ۲: هیرو ---------- */

    $heroBadge = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazHeroBadge',
        null,
        'باشگاه تخصصی بدنسازی و پیلاتس',
        _t('هیرو — متن بج'),
        _t('متن بج کوچک بالای عنوان اصلی هیرو.')
    );
    $form->addInput($heroBadge->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $heroTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazHeroTitle',
        null,
        'قدرتمندترین نسخهٔ خودت را بساز',
        _t('هیرو — عنوان اصلی'),
        _t('عنوان بزرگ صفحهٔ اول. ساده و کوتاه نگه دارید.')
    );
    $form->addInput($heroTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $heroSubtitle = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'elnazHeroSubtitle',
        null,
        "در الناز با مربیان مجرب، تجهیزات حرفه‌ای و برنامه‌های کاملاً شخصی‌سازی‌شده، مسیر رسیدن به فرم ایده‌آل را سریع‌تر و امن‌تر طی می‌کنی.\nهمین حالا اولین جلسهٔ رایگانت را رزرو کن و مسیرت را شروع کن.",
        _t('هیرو — توضیح'),
        _t('متن توضیح هیرو. هر خط یک پاراگراف است.')
    );
    $form->addInput($heroSubtitle);

    $heroImage = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazHeroImage',
        null,
        null,
        _t('هیرو — تصویر'),
        _t('آدرس تصویر هیرو (خالی = تصویر پیش‌فرض باشگاه داخل پوسته).')
    );
    $form->addInput($heroImage->addRule('xssCheck', _t('آدرس تصویر معتبر وارد کنید')));

    $heroBtn1Text = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazHeroBtn1Text',
        null,
        'رزرو جلسهٔ رایگان',
        _t('هیرو — دکمهٔ اول (متن)'),
        _t('متن دکمهٔ اصلی هیرو.')
    );
    $form->addInput($heroBtn1Text->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $heroBtn1Url = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazHeroBtn1Url',
        null,
        '#booking',
        _t('هیرو — دکمهٔ اول (آدرس)'),
        _t('آدرس مقصد؛ برای پرش به فرم رزرو همان صفحه #booking بگذارید.')
    );
    $form->addInput($heroBtn1Url->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $heroBtn2Text = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazHeroBtn2Text',
        null,
        'مشاهدهٔ خدمات',
        _t('هیرو — دکمهٔ دوم (متن)'),
        _t('متن دکمهٔ دوم هیرو (اختیاری).')
    );
    $form->addInput($heroBtn2Text->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $heroBtn2Url = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazHeroBtn2Url',
        null,
        '#services',
        _t('هیرو — دکمهٔ دوم (آدرس)'),
        _t('آدرس مقصد دکمهٔ دوم؛ برای پرش به بخش خدمات همان صفحه #services بگذارید.')
    );
    $form->addInput($heroBtn2Url->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $heroStats = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'elnazHeroStats',
        null,
        "500+ | عضو فعال\n12 | مربی حرفه‌ای\n10 | سال تجربه\n98% | رضایت اعضا",
        _t('هیرو — آمار'),
        _t('هر خط: «عدد | عنوان». حداقل ۲ و حداکثر ۴ مورد. خالی = بدون آمار.')
    );
    $form->addInput($heroStats);

    /* ---------- بخش ۳: خدمات ---------- */

    $servicesTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazServicesTitle',
        null,
        'خدمات باشگاه الناز',
        _t('خدمات — عنوان'),
        _t('عنوان بخش خدمات. برای مخفی‌شدن کل بخش، عنوان یا فهرست را خالی بگذارید.')
    );
    $form->addInput($servicesTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $servicesSubtitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazServicesSubtitle',
        null,
        'هر هدفی که داشته باشی، یک مسیر حرفه‌ای برایش داریم',
        _t('خدمات — توضیح'),
        _t('متن کوتاه زیر عنوان خدمات.')
    );
    $form->addInput($servicesSubtitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $services = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'elnazServices',
        null,
        "dumbbell | بدنسازی و قدرت | تمرین با وزنه و دستگاه‌های حرفه‌ای برای عضله‌سازی و افزایش قدرت\nflower | پیلاتس | تمرینات تقویت مرکز بدن، انعطاف و اصلاح پوسچر با تجهیزات مخصوص\nzap | کراس‌فیت و HIIT | تمرینات شدید و پرانرژی برای چربی‌سوزی حداکثری و آمادگی بالا\nuser | تربیت خصوصی | مربی اختصاصی و برنامهٔ کاملاً شخصی‌سازی‌شده برای رسیدن سریع به هدفت\nusers | تمرینات گروهی | کلاس‌های گروهی انگیزشی با انرژی بالا و هم‌تیمی‌های قدرتمند\nactivity | حرکات اصلاحی | اصلاح قوز، کمر‌درد و آسیب‌های حرکتی با تمرینات تخصصی",
        _t('خدمات — فهرست'),
        _t('هر خط: «آیکون | عنوان | توضیح». آیکون‌های موجود: dumbbell, flower, zap, timer, user, users, activity, flame, heart-pulse, target, trending-up, trending-down, star, award و آیکون‌های عمومی.')
    );
    $form->addInput($services);

    /* ---------- بخش ۴: پکیج‌ها ---------- */

    $packagesTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazPackagesTitle',
        null,
        'اشتراک‌های باشگاه',
        _t('پکیج‌ها — عنوان'),
        _t('عنوان بخش اشتراک‌ها. برای مخفی‌شدن کل بخش، عنوان یا فهرست را خالی بگذارید.')
    );
    $form->addInput($packagesTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $packagesSubtitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazPackagesSubtitle',
        null,
        'اشتراک مناسب خودت را انتخاب کن؛ اولین جلسه همیشه رایگان است',
        _t('پکیج‌ها — توضیح'),
        _t('متن کوتاه زیر عنوان اشتراک‌ها.')
    );
    $form->addInput($packagesSubtitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $packages = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'elnazPackages',
        null,
        "اشتراک ماهانه | ۸۵۰ هزار تومان | ۹۵۰ هزار تومان | ورود نامحدود به سالن و کلاس‌ها | تمرین نامحدود,کلاس‌های گروهی,برنامهٔ تمرینی ماهانه,مشاورهٔ تغذیهٔ ورزشی | #booking | \nاشتراک سه‌ماهه | ۲٬۳۰۰ هزار تومان | ۲٬۷۰۰ هزار تومان | مسیر کامل تبدیل با پیگیری مستمر مربی | همهٔ مزایای ماهانه,برنامهٔ سه‌ماههٔ دوره‌ای,پیگیری هفتگی مربی,ارزیابی ماهانهٔ پیشرفت,دسترسی به سونای بخار | #booking | محبوب‌ترین\nتربیت خصوصی VIP | ۱٬۵۰۰ هزار تومان | | جلسات یک‌به‌یک با مربی ارشد + برنامهٔ اختصاصی | ۸ جلسهٔ خصوصی در ماه,برنامهٔ تمرینی و غذایی اختصاصی,پیگیری روزانه,اولویت رزرو تجهیزات | #booking |",
        _t('پکیج‌ها — فهرست'),
        _t('هر خط: «عنوان | قیمت | قیمت قبل (اختیاری) | توضیح | ویژگی‌ها با کاما | آدرس | بج». قیمت‌ها می‌توانند خالی باشند (مثلاً برای تماس برای قیمت). پیش‌فرض ۳ اشتراک در ۳ ستون است؛ جلسهٔ رایگان از بخش «رزرو جلسهٔ رایگان» جداگانه ارائه می‌شود.')
    );
    $form->addInput($packages);

    /* ---------- بخش ۵: مربیان ---------- */

    $teamTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazTeamTitle',
        null,
        'مربیان الناز',
        _t('مربیان — عنوان'),
        _t('عنوان بخش مربیان. خالی = بخش مخفی.')
    );
    $form->addInput($teamTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $teamSubtitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazTeamSubtitle',
        null,
        'مربیانی که کنارت می‌مانند تا به نتیجه برسی',
        _t('مربیان — توضیح'),
        _t('متن کوتاه زیر عنوان مربیان.')
    );
    $form->addInput($teamSubtitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $team = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'elnazTeam',
        null,
        "امیر روشندل | مربی بدنسازی و قدرت | img/coach-1.jpg | ۱۲ سال سابقهٔ مربیگری؛ متخصص تمرینات قدرتی و آماده‌سازی مسابقات\nسارا محمدی | مربی پیلاتس و حرکات اصلاحی | img/coach-2.jpg | مدرس بین‌المللی پیلاتس؛ متخصص اصلاح پوسچر و تمرینات بانوان\nرضا کریمی | مربی کراس‌فیت و کوندیشنینگ | img/coach-3.jpg | قهرمان سابق کاپ power؛ طراح تمرینات HIIT و گروهی\nعقیق خلیلی | کارشناس تربیت بدنی و تغذیهٔ ورزشی | img/coach-4.jpg | برنامه‌های ترکیبی تمرین و تغذیهٔ ورزشی برای اهداف عضله‌سازی و کات",
        _t('مربیان — فهرست'),
        _t('هر خط: «نام | سمت | عکس (اختیاری) | توضیح». با عکس، کارت تصویری بزرگ (پرترهٔ ۳:۴) نمایش داده می‌شود؛ بدون عکس، آواتار حرفی. پیش‌فرض ۴ مربی با عکس داخل پوسته (img/coach-1.jpg تا coach-4.jpg) است؛ می‌توانید آدرس عکس دلخواه بگذارید. با کمتر از ۴ نفر، کارت‌ها داینامیک چیده می‌شوند (یک نفر = نمایش ردیفی).')
    );
    $form->addInput($team);

    /* ---------- بخش ۶: وبلاگ (آرشیو و صفحهٔ اول) ---------- */

    $blogShow = new \Typecho\Widget\Helper\Form\Element\Radio(
        'elnazBlogShow',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('وبلاگ — نمایش در صفحهٔ اول'),
        _t('نمایش آخرین مقالات در صفحهٔ اول (اگر مقاله‌ای منتشر نشده باشد، بخش نمایش داده نمی‌شود).')
    );
    $form->addInput($blogShow);


    $blogTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazBlogTitle',
        null,
        'مقالات تناسب اندام',
        _t('وبلاگ — عنوان'),
        _t('عنوان فهرست مقالات (مسیر /blog/).')
    );
    $form->addInput($blogTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $blogSubtitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazBlogSubtitle',
        null,
        'آخرین نکات علمی تمرین، تغذیهٔ ورزشی و تناسب اندام',
        _t('وبلاگ — توضیح'),
        _t('متن کوتاه زیر عنوان مقالات.')
    );
    $form->addInput($blogSubtitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $blogCount = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazBlogCount',
        null,
        '3',
        _t('وبلاگ — تعداد'),
        _t('تعداد مقالات نمایشی در فهرست (۱ تا ۶).')
    );
    $form->addInput($blogCount->addRule('xssCheck', _t('عدد وارد کنید')));

    $blogUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazBlogUrl',
        null,
        null,
        _t('وبلاگ — آدرس فهرست مقالات'),
        _t('آدرس سفارشی فهرست مقالات (اختیاری). خالی = مسیر پیش‌فرض آرشیو.')
    );
    $form->addInput($blogUrl->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    /* ---------- بخش ۷: رزرو ---------- */

    $bookingTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazBookingTitle',
        null,
        'رزرو جلسهٔ رایگان',
        _t('رزرو — عنوان'),
        _t('عنوان بخش فرم رزرو/تماس در صفحهٔ اول.')
    );
    $form->addInput($bookingTitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $bookingSubtitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazBookingSubtitle',
        null,
        'فرم را پر کن؛ مربیان ما در اولین فرصت برای هماهنگی جلسهٔ رایگان با تو تماس می‌گیرند',
        _t('رزرو — توضیح'),
        _t('متن کوتاه زیر عنوان فرم.')
    );
    $form->addInput($bookingSubtitle->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $bookingServices = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazBookingServices',
        null,
        'بدنسازی, پیلاتس, کراس‌فیت و HIIT, تربیت خصوصی, حرکات اصلاحی, تمرین گروهی, مشاورهٔ عمومی',
        _t('رزرو — گزینه‌های تمرین'),
        _t('گزینه‌های منوی «نوع تمرین» در فرم رزرو؛ با کاما جدا کنید.')
    );
    $form->addInput($bookingServices->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $bookingGoals = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazBookingGoals',
        null,
        'کاهش وزن, عضله‌سازی, افزایش آمادگی, اصلاح آسیب, سلامت عمومی',
        _t('رزرو — گزینه‌های هدف'),
        _t('گزینه‌های منوی «هدف» در فرم رزرو؛ با کاما جدا کنید.')
    );
    $form->addInput($bookingGoals->addRule('xssCheck', _t('متن معتبر وارد کنید')));

    $bookingCid = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazBookingCid',
        null,
        '0',
        _t('رزرو — برگهٔ ذخیرهٔ درخواست‌ها'),
        _t('شناسهٔ (cid) برگه‌ای که درخواست‌های رزرو به‌صورت دیدگاه مخفی روی آن ذخیره می‌شود. ۰ = خودکار (برگهٔ مخفی «دفتر رزرو» و برگهٔ «مدیریت رزروها» ساخته می‌شوند). مشاهده درخواست‌ها: مدیریت ← دیدگاه‌های در انتظار، یا برگهٔ «مدیریت رزروها» که برای مدیران از هدر سایت لینک می‌شود.')
    );
    $form->addInput($bookingCid->addRule('xssCheck', _t('عدد وارد کنید')));

    /* ---------- بخش ۱۲: تماس ---------- */

    $contactPhone = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazContactPhone',
        null,
        '021-12345678',
        _t('تماس — تلفن'),
        _t('شمارهٔ تلفن اصلی. خالی = حذف.')
    );
    $form->addInput($contactPhone->addRule('xssCheck', _t('شمارهٔ معتبر وارد کنید')));

    $contactPhone2 = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazContactPhone2',
        null,
        '0912-345-6789',
        _t('تماس — موبایل'),
        _t('شمارهٔ همراه (خط دوم). خالی = حذف.')
    );
    $form->addInput($contactPhone2->addRule('xssCheck', _t('شمارهٔ معتبر وارد کنید')));

    $contactEmail = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazContactEmail',
        null,
        'info@elnaz.ir',
        _t('تماس — ایمیل'),
        _t('ایمیل ارتباطی. خالی = حذف.')
    );
    $form->addInput($contactEmail->addRule('xssCheck', _t('ایمیل معتبر وارد کنید')));

    $contactAddress = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazContactAddress',
        null,
        'تهران، خیابان ولیعصر، بالاتر از پارک ساعی، پلاک ۲۴، باشگاه الناز — طبقهٔ ۲ و ۳',
        _t('تماس — آدرس'),
        _t('نشانی باشگاه. خالی = حذف.')
    );
    $form->addInput($contactAddress->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $contactHours = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'elnazContactHours',
        null,
        "شنبه تا پنجشنبه: ۷ صبح تا ۱۱ شب\nجمعه: ۹ صبح تا ۱۸\nبدون توقف — تعطیلی نداریم",
        _t('تماس — ساعت کاری'),
        _t('هر خط یک مورد. خالی = بدون نمایش.')
    );
    $form->addInput($contactHours);

    $mapEmbed = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazMapEmbed',
        null,
        null,
        _t('تماس — نقشه'),
        _t('آدرس iframe نقشه (گوگل‌مپ/نشان). خالی = بدون نقشه.')
    );
    $form->addInput($mapEmbed->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $socialInstagram = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazSocialInstagram',
        null,
        'https://instagram.com/elnaz',
        _t('اینستاگرام'),
        _t('آدرس اینستاگرام. خالی = حذف آیکون.')
    );
    $form->addInput($socialInstagram->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $socialTelegram = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazSocialTelegram',
        null,
        'https://t.me/elnaz',
        _t('تلگرام'),
        _t('آدرس تلگرام. خالی = حذف آیکون.')
    );
    $form->addInput($socialTelegram->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $socialWhatsapp = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazSocialWhatsapp',
        null,
        'https://wa.me/989123456789',
        _t('واتس‌اپ'),
        _t('آدرس واتس‌اپ. خالی = حذف آیکون.')
    );
    $form->addInput($socialWhatsapp->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $socialYoutube = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazSocialYoutube',
        null,
        null,
        _t('یوتیوب'),
        _t('آدرس کانال یوتیوب. خالی = حذف آیکون.')
    );
    $form->addInput($socialYoutube->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    /* ---------- بخش ۱۳: فوتر و نوشته‌ها ---------- */

    $footerText = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'elnazFooterText',
        null,
        'باشگاه الناز — با مربیان مجرب، تجهیزات حرفه‌ای و برنامه‌های شخصی‌سازی‌شده، قدرتمندترین نسخهٔ خودت را می‌سازیم.',
        _t('متن فوتر'),
        _t('متن کوتاه معرفی در ستون اول فوتر.')
    );
    $form->addInput($footerText);

    $defaultCover = new \Typecho\Widget\Helper\Form\Element\Text(
        'elnazDefaultCover',
        null,
        null,
        _t('تصویر پیش‌فرض نوشته‌ها'),
        _t('آدرس تصویر شاخص پیش‌فرض وبلاگ (خالی = img/default-cover.jpg پوسته).')
    );
    $form->addInput($defaultCover->addRule('xssCheck', _t('آدرس تصویر معتبر وارد کنید')));

    $showRelated = new \Typecho\Widget\Helper\Form\Element\Radio(
        'elnazShowRelated',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('نوشته‌های مرتبط'),
        _t('در انتهای هر نوشتهٔ وبلاگ، نوشته‌های مرتبط از همان دسته نمایش داده می‌شود.')
    );
    $form->addInput($showRelated);

    $showAuthorBox = new \Typecho\Widget\Helper\Form\Element\Radio(
        'elnazShowAuthorBox',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('باکس نویسنده'),
        _t('کارت معرفی نویسنده در انتهای نوشته.')
    );
    $form->addInput($showAuthorBox);
}

/* ================================================================
 *  ۱۱) فیلدهای اختصاصی نوشته (قابل استفاده در پیشخوان)
 * ================================================================ */

function themeFields($layout)
{
    $thumb = new \Typecho\Widget\Helper\Form\Element\Text(
        'thumb',
        null,
        null,
        _t('تصویر شاخص'),
        _t('آدرس تصویر شاخص این نوشته (اختیاری؛ خالی = اولین تصویر متن).')
    );
    $layout->addItem($thumb->addRule('xssCheck', _t('آدرس معتبر وارد کنید')));

    $calories = new \Typecho\Widget\Helper\Form\Element\Text(
        'calories',
        null,
        null,
        _t('کالری (کیلوکالری)'),
        _t('مقدار کالری کل دستور غذایی — به‌صورت بج روی کارت و صفحهٔ نوشته نمایش داده می‌شود. (اختیاری)')
    );
    $layout->addItem($calories->addRule('xssCheck', _t('عدد وارد کنید')));

    $cookTime = new \Typecho\Widget\Helper\Form\Element\Text(
        'cookTime',
        null,
        null,
        _t('زمان تهیه (دقیقه)'),
        _t('مدت زمان آماده‌سازی — به‌صورت بج روی کارت و صفحهٔ نوشته نمایش داده می‌شود. (اختیاری)')
    );
    $layout->addItem($cookTime->addRule('xssCheck', _t('عدد وارد کنید')));
}

/* ================================================================
 *  ۱۲) رندر ریسه‌ای دیدگاه‌ها
 * ================================================================ */

function threadedComments($comments, $options)
{
    $commentClass = '';
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
    ?>
    <li id="li-<?php $comments->theId(); ?>" class="comment-item<?php
    if ($comments->levels > 0) {
        echo ' comment-child';
        $comments->levelsAlt(' comment-level-odd', ' comment-level-even');
    } else {
        echo ' comment-parent';
    }
    $comments->alt(' comment-odd', ' comment-even');
    echo $commentClass;
    ?>">
        <div id="<?php $comments->theId(); ?>" class="comment-inner">
            <div class="comment-avatar" aria-hidden="true">
                <?php $comments->gravatar(96, 'mp', true); ?>
                <span class="comment-avatar-fallback"><?php echo htmlspecialchars(elnaz_initial((string)$comments->author), ENT_QUOTES); ?></span>
            </div>
            <div class="comment-main">
                <div class="comment-meta">
                    <cite class="comment-author" itemprop="creator" itemscope itemtype="http://schema.org/Person">
                        <?php $comments->author(); ?>
                        <?php if ($comments->authorId && $comments->authorId == $comments->ownerId): ?>
                            <span class="comment-badge-owner"><?php _e('نویسنده'); ?></span>
                        <?php endif; ?>
                    </cite>
                    <span class="comment-time">
                        <?php echo elnaz_icon('clock', 12); ?>
                        <a href="<?php $comments->permalink(); ?>" itemprop="url">
                            <time datetime="<?php echo date('c', (int)$comments->created); ?>" itemprop="commentTime"><?php echo elnaz_jalali_date((int)$comments->created, 'j F Y'); ?></time>
                        </a>
                    </span>
                    <?php if ($comments->status == 'waiting'): ?>
                        <span class="comment-badge-waiting"><?php _e('در انتظار تأیید'); ?></span>
                    <?php endif; ?>
                    <span class="comment-reply">
                        <?php $comments->reply(_t('پاسخ')); ?>
                    </span>
                </div>
                <div class="comment-content" itemprop="commentText">
                    <?php $comments->content(); ?>
                </div>
            </div>
        </div>
        <?php if ($comments->children) { ?>
            <div class="comment-children">
                <?php $comments->threadedComments($options); ?>
            </div>
        <?php } ?>
    </li>
    <?php
}

