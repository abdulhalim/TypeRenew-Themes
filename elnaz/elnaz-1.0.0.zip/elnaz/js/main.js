/* ================================================================
 *  الناز — اسکریپت اصلی
 *  منو + فرم رزرو + ابزارهای عمومی
 * ================================================================ */
(function () {
    'use strict';

    /* ---------- تبدیل ارقام فارسی/عربی به لاتین ---------- */
    function enNum(str) {
        return String(str)
            .replace(/[۰-۹]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); })
            .replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); });
    }

    /* ---------- منوی موبایل ---------- */
    var menu = document.getElementById('mobileMenu');
    var overlay = document.getElementById('menuOverlay');
    var toggle = document.getElementById('menuToggle');
    var closeBtn = document.getElementById('menuClose');

    function openMenu() {
        if (!menu) { return; }
        menu.classList.add('open');
        if (overlay) { overlay.classList.add('show'); }
        menu.setAttribute('aria-hidden', 'false');
        if (toggle) { toggle.setAttribute('aria-expanded', 'true'); }
        document.body.style.overflow = 'hidden';
    }

    function closeMenu() {
        if (!menu) { return; }
        menu.classList.remove('open');
        if (overlay) { overlay.classList.remove('show'); }
        menu.setAttribute('aria-hidden', 'true');
        if (toggle) { toggle.setAttribute('aria-expanded', 'false'); }
        document.body.style.overflow = '';
    }

    if (toggle) { toggle.addEventListener('click', openMenu); }
    if (closeBtn) { closeBtn.addEventListener('click', closeMenu); }
    if (overlay) { overlay.addEventListener('click', closeMenu); }

    document.querySelectorAll('.mobile-nav a[data-close]').forEach(function (link) {
        link.addEventListener('click', closeMenu);
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') { closeMenu(); }
    });

    /* ---------- سایهٔ هدر بعد از اسکرول + دکمهٔ بالا ---------- */
    var header = document.getElementById('siteHeader');
    var backToTop = document.getElementById('backToTop');

    function onScroll() {
        var y = window.scrollY || window.pageYOffset;
        if (header) {
            if (y > 10) { header.classList.add('scrolled'); }
            else { header.classList.remove('scrolled'); }
        }
        if (backToTop) {
            if (y > 460) { backToTop.classList.add('show'); }
            else { backToTop.classList.remove('show'); }
        }
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    if (backToTop) {
        backToTop.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }


    /* ================================================================
     *  فرم رزرو — AJAX به نقطهٔ پایانی اختصاصی /elnaz-booking
     *  (الگو از افزونهٔ Booking؛ توکن _ و تلهٔ هرزنامه همراه فرم ارسال می‌شود)
     * ================================================================ */
    function initBooking() {
        var form = document.getElementById('bookingForm');
        if (!form) { return; }

        var submitBtn = document.getElementById('bookingSubmitBtn');
        var successEl = document.getElementById('bookingSuccess');
        var errorEl = document.getElementById('bookingError');
        var errorText = document.getElementById('bookingErrorText');

        function showMsg(el, textEl, msg) {
            if (el) { el.hidden = false; }
            if (textEl && typeof msg === 'string' && msg !== '') { textEl.textContent = msg; }
            if (el) {
                try { el.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); } catch (e) { }
            }
        }

        form.addEventListener('submit', function (e) {
            e.preventDefault();

            // مخفی‌کردن پیام‌های قبلی
            if (successEl) { successEl.hidden = true; }
            if (errorEl) { errorEl.hidden = true; }

            // اعتبارسنجی سمت کلاینت
            var name = (form.querySelector('#elnazName') || {}).value || '';
            var phone = (form.querySelector('#elnazPhone') || {}).value || '';
            phone = enNum(String(phone)).replace(/[\s\-()]/g, '');

            if (name.trim().length < 2) {
                showMsg(errorEl, errorText, 'لطفاً نام خود را کامل وارد کنید.');
                return;
            }
            if (!/^(\+98|98|0098|0)?9\d{9}$/.test(phone) && !/^0\d{9,10}$/.test(phone)) {
                showMsg(errorEl, errorText, 'شمارهٔ تلفن معتبر نیست (مثال: ۰۹۱۲۳۴۵۶۷۸۹).');
                return;
            }

            // حالت بارگذاری
            if (submitBtn) {
                submitBtn.classList.add('loading');
                submitBtn.setAttribute('disabled', 'disabled');
            }

            // گردآوری همهٔ فیلدهای فرم (شامل توکن _ و تلهٔ هرزنامه)
            var body = new URLSearchParams();
            Array.prototype.forEach.call(form.elements, function (el) {
                if (!el.name || el.disabled) { return; }
                var tag = (el.tagName || '').toLowerCase();
                if (tag === 'select') {
                    body.append(el.name, el.value || '');
                } else if (el.type === 'checkbox' || el.type === 'radio') {
                    if (el.checked) { body.append(el.name, el.value || ''); }
                } else if (el.type !== 'file' && el.type !== 'button' && el.type !== 'submit') {
                    body.append(el.name, el.value || '');
                }
            });
            body.set('elnazBooking', '1');
            // شمارهٔ نرمال‌شده
            body.set('elnazPhone', phone);

            // نقطهٔ پایانی اختصاصی؛ در نبودش آدرس صفحهٔ جاری
            var endpoint = form.getAttribute('action') || window.location.href;
            if (!endpoint || endpoint === '#' || endpoint.charAt(0) === '#') {
                endpoint = window.location.href;
            }

            fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: body.toString(),
                credentials: 'same-origin',
                redirect: 'follow'
            })
                .then(function (res) {
                    // اگر پاسخ JSON نبود (مثلاً HTML)، متن را برای تشخیص خطا بخوان
                    var contentType = (res.headers.get('content-type') || '');
                    if (contentType.indexOf('application/json') !== -1) {
                        return res.json().then(function (data) { return data; });
                    }
                    return res.text().then(function () {
                        return { ok: false, error: 'پاسخ سرور قابل پردازش نبود؛ صفحه را رفرش کنید و دوباره تلاش کنید. (HTTP ' + res.status + ')' };
                    });
                })
                .then(function (data) {
                    if (data && data.ok) {
                        try { form.reset(); } catch (e) { }
                        if (successEl) { successEl.hidden = false; }
                        if (successEl) {
                            successEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                        }
                    } else {
                        var msg = (data && data.error && typeof data.error === 'string')
                            ? data.error
                            : 'ارسال درخواست ناموفق بود؛ لطفاً دوباره تلاش کنید.';
                        showMsg(errorEl, errorText, msg);
                    }
                })
                .catch(function () {
                    showMsg(errorEl, errorText, 'خطای ارتباط با سرور؛ اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.');
                })
                .finally(function () {
                    if (submitBtn) {
                        submitBtn.classList.remove('loading');
                        submitBtn.removeAttribute('disabled');
                    }
                });
        });
    }
    initBooking();

    /* ---------- دکمهٔ کپی کد ---------- */
    document.querySelectorAll('.post-content pre').forEach(function (pre) {
        var btn = pre.querySelector('.copy-code-btn');
        if (!btn) {
            btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'copy-code-btn';
            btn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg> کپی';
            pre.appendChild(btn);
        }
        btn.addEventListener('click', function () {
            var text = pre.querySelector('code') ? pre.querySelector('code').innerText : pre.innerText;
            var done = function () {
                btn.classList.add('copied');
                var old = btn.innerHTML;
                btn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 7 17l-5-5"/><path d="m22 10-7.5 7.5L13 16"/></svg> کپی شد';
                setTimeout(function () { btn.classList.remove('copied'); btn.innerHTML = old; }, 1600);
            };
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(done).catch(function () { });
            } else {
                var ta = document.createElement('textarea');
                ta.value = text;
                document.body.appendChild(ta);
                ta.select();
                try { document.execCommand('copy'); done(); } catch (e) { }
                document.body.removeChild(ta);
            }
        });
    });

    /* ---------- اسکرول نرم برای لینک‌های # ---------- */
    document.querySelectorAll('a[href^="#"]').forEach(function (link) {
        link.addEventListener('click', function (e) {
            var id = link.getAttribute('href');
            if (!id || id === '#' || id.length < 2) { return; }
            var target = document.querySelector(id);
            if (!target) { return; }
            e.preventDefault();
            closeMenu();
            var headerH = header ? header.offsetHeight : 0;
            var top = target.getBoundingClientRect().top + window.pageYOffset - headerH - 14;
            window.scrollTo({ top: top, behavior: 'smooth' });
        });
    });

    /* ---------- ورود با #hash از صفحهٔ دیگر ---------- */
    if (window.location.hash && window.location.hash.length > 1) {
        try {
            var hashTarget = document.querySelector(window.location.hash);
            if (hashTarget) {
                setTimeout(function () {
                    var headerH = header ? header.offsetHeight : 0;
                    var top = hashTarget.getBoundingClientRect().top + window.pageYOffset - headerH - 14;
                    window.scrollTo({ top: top, behavior: 'smooth' });
                }, 80);
            }
        } catch (e) { }
    }

})();
