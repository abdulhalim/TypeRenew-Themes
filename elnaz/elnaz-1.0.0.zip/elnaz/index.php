<?php
/**
 * پوستهٔ اختصاصی باشگاه بدنسازی و پیلاتس، مناسب برای معرفی خدمات و فضای باشگاه
 *
 * @package الناز
 * @author پوردریایی
 * @link https://pourdaryaei.ir
 * @version 1.0.0
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');


if (elnaz_is_front()):

    /* ================================================================
     *  صفحهٔ اصلی — لندینگ باشگاه بدنسازی و پیلاتس
     * ================================================================ */

    // ---------- داده‌های هیرو ----------
    $elnazHeroBadge    = elnaz_opt('elnazHeroBadge', 'باشگاه تخصصی بدنسازی و پیلاتس');
    $elnazHeroTitle    = elnaz_opt('elnazHeroTitle', 'قدرتمندترین نسخهٔ خودت را بساز');
    $elnazHeroSubtitle = trim((string)elnaz_opt_raw('elnazHeroSubtitle'));
    $elnazHeroSubtitle = ($elnazHeroSubtitle === '') ? "در الناز با مربیان مجرب، تجهیزات حرفه‌ای و برنامه‌های کاملاً شخصی‌سازی‌شده، مسیر رسیدن به فرم ایده‌آل را سریع‌تر و امن‌تر طی می‌کنی.\nهمین حالا اولین جلسهٔ رایگانت را رزرو کن و مسیرت را شروع کن." : $elnazHeroSubtitle;
    $elnazHeroImageRaw = trim((string)elnaz_opt_raw('elnazHeroImage'));
    $elnazHeroImage    = ($elnazHeroImageRaw !== '') ? elnaz_resolve_url($elnazHeroImageRaw) : elnaz_asset('img/hero.jpg');
    $elnazHeroBtn1Text = elnaz_opt('elnazHeroBtn1Text', 'رزرو جلسهٔ رایگان');
    $elnazHeroBtn1Url  = elnaz_opt('elnazHeroBtn1Url', '#booking');
    $elnazHeroBtn2Text = elnaz_opt_raw('elnazHeroBtn2Text');
    $elnazHeroBtn2Url  = elnaz_opt_raw('elnazHeroBtn2Url');
    if ($elnazHeroBtn2Text === null) { $elnazHeroBtn2Text = 'مشاهدهٔ خدمات'; }
    if ($elnazHeroBtn2Url === null) { $elnazHeroBtn2Url = '#services'; }
    $elnazHeroStats    = elnaz_parse_stats(elnaz_opt_raw('elnazHeroStats'));
    $elnazHeroStats    = array_slice($elnazHeroStats, 0, 4);
    $elnazHeroTitleParts = preg_split('/\s+/', trim($elnazHeroTitle), 2);

    // ---------- داده‌های وبلاگ صفحهٔ اول ----------
    $elnazBlogShow  = elnaz_opt('elnazBlogShow', '1') === '1';
    $elnazBlogPosts = $elnazBlogShow ? elnaz_recent_posts((int)elnaz_opt('elnazBlogCount', '3')) : [];

    // ---------- داده‌های بخش‌ها ----------
    $elnazServicesTitle = trim((string)elnaz_opt_raw('elnazServicesTitle'));
    $elnazServices      = elnaz_parse_services(elnaz_opt_raw('elnazServices'));
    $elnazServicesSubtitle = elnaz_opt('elnazServicesSubtitle', 'هر هدفی که داشته باشی، یک مسیر حرفه‌ای برایش داریم');

    $elnazPackagesTitle = trim((string)elnaz_opt_raw('elnazPackagesTitle'));
    $elnazPackagesSubtitle = elnaz_opt('elnazPackagesSubtitle', 'اشتراک مناسب خودت را انتخاب کن؛ اولین جلسه همیشه رایگان است');
    $elnazPackages = elnaz_parse_packages(elnaz_opt_raw('elnazPackages'));

    $elnazTeamTitle    = trim((string)elnaz_opt_raw('elnazTeamTitle'));
    $elnazTeamSubtitle = elnaz_opt('elnazTeamSubtitle', 'مربیانی که کنارت می‌مانند تا به نتیجه برسی');
    $elnazTeam         = elnaz_parse_team(elnaz_opt_raw('elnazTeam'));

    // ---------- داده‌های رزرو و تماس ----------
    $elnazBookingTitle    = elnaz_opt('elnazBookingTitle', 'رزرو جلسهٔ رایگان');
    $elnazBookingSubtitle = elnaz_opt('elnazBookingSubtitle', 'فرم را پر کن؛ مربیان ما در اولین فرصت برای هماهنگی جلسهٔ رایگان با تو تماس می‌گیرند');
    $elnazBookingServices = array_filter(array_map('trim', explode(',', (string)elnaz_opt('elnazBookingServices', 'بدنسازی, پیلاتس, کراس‌فیت و HIIT, تربیت خصوصی, حرکات اصلاحی, تمرین گروهی, مشاورهٔ عمومی'))));
    $elnazBookingGoals    = array_filter(array_map('trim', explode(',', (string)elnaz_opt('elnazBookingGoals', 'کاهش وزن, عضله‌سازی, افزایش آمادگی, اصلاح آسیب, سلامت عمومی'))));
    $elnazContactPhone  = elnaz_opt_raw('elnazContactPhone');
    $elnazContactPhone2 = elnaz_opt_raw('elnazContactPhone2');
    $elnazContactEmail  = elnaz_opt_raw('elnazContactEmail');
    $elnazContactAddr   = elnaz_opt_raw('elnazContactAddress');
    $elnazContactHours  = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string)elnaz_opt_raw('elnazContactHours'))));
    $elnazMapEmbed = trim((string)elnaz_opt_raw('elnazMapEmbed'));
?>

    <!-- ==================== هیرو ==================== -->
    <section class="hero" id="home">
        <div class="hero-decor hero-decor-1" aria-hidden="true"></div>
        <div class="hero-decor hero-decor-2" aria-hidden="true"></div>
        <div class="hero-grid-lines" aria-hidden="true"></div>
        <span class="hero-watermark" aria-hidden="true">ELNAZ</span>
        <div class="container hero-inner">
            <div class="hero-content">
                <?php if ($elnazHeroBadge !== ''): ?>
                <span class="hero-badge">
                    <?php echo elnaz_icon('sparkles', 15); ?>
                    <?php echo htmlspecialchars($elnazHeroBadge, ENT_QUOTES); ?>
                </span>
                <?php endif; ?>
                <h1 class="hero-title">
                    <?php if (trim((string)($elnazHeroTitleParts[1] ?? '')) !== ''): ?>
                    <span class="hero-title-lead"><?php echo htmlspecialchars($elnazHeroTitleParts[0], ENT_QUOTES); ?></span>
                    <span class="hero-title-gold"><?php echo htmlspecialchars(trim($elnazHeroTitleParts[1]), ENT_QUOTES); ?></span>
                    <?php else: ?>
                    <span class="hero-title-gold"><?php echo htmlspecialchars($elnazHeroTitle, ENT_QUOTES); ?></span>
                    <?php endif; ?>
                </h1>
                <div class="hero-subtitle">
                    <?php foreach (array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $elnazHeroSubtitle))) as $elnazHeroP): ?>
                    <p><?php echo htmlspecialchars($elnazHeroP, ENT_QUOTES); ?></p>
                    <?php endforeach; ?>
                </div>
                <div class="hero-actions">
                    <?php if (trim($elnazHeroBtn1Text) !== ''): ?>
                    <a href="<?php echo htmlspecialchars(elnaz_link_url($elnazHeroBtn1Url), ENT_QUOTES); ?>" class="btn btn-primary btn-lg">
                        <?php echo elnaz_icon('calendar-check', 18); ?>
                        <?php echo htmlspecialchars($elnazHeroBtn1Text, ENT_QUOTES); ?>
                    </a>
                    <?php endif; ?>
                    <?php if (trim((string)$elnazHeroBtn2Text) !== ''): ?>
                    <a href="<?php echo htmlspecialchars(elnaz_link_url((string)$elnazHeroBtn2Url), ENT_QUOTES); ?>" class="btn btn-ghost btn-lg">
                        <?php echo elnaz_icon('zap', 17); ?>
                        <?php echo htmlspecialchars($elnazHeroBtn2Text, ENT_QUOTES); ?>
                    </a>
                    <?php endif; ?>
                </div>
                <div class="hero-trust">
                    <div class="hero-trust-text">
                        <span class="hero-stars" aria-hidden="true">
                            <?php for ($elnazStarI = 0; $elnazStarI < 5; $elnazStarI++): ?>
                            <?php echo elnaz_icon('star', 13); ?>
                            <?php endfor; ?>
                        </span>
                        <span>رضایت <?php echo toPersianNumbers('500'); ?>+ عضو فعال الناز</span>
                    </div>
                </div>
            </div>
            <div class="hero-visual">
                <div class="hero-ring" aria-hidden="true"></div>
                <div class="hero-img-frame">
                    <img src="<?php echo htmlspecialchars($elnazHeroImage, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($elnazHeroTitle, ENT_QUOTES); ?>" class="hero-img" fetchpriority="high">
                </div>
                <div class="hero-card hero-card-1">
                    <?php echo elnaz_icon('dumbbell', 20); ?>
                    <div>
                        <strong>برنامهٔ تمرینی اختصاصی</strong>
                        <span>متناسب با بدن و هدفت</span>
                    </div>
                </div>
                <div class="hero-card hero-card-2">
                    <?php echo elnaz_icon('award', 18); ?>
                    <div>
                        <strong>مربیان مدرک‌دار</strong>
                        <span>همراهت تا نتیجه</span>
                    </div>
                </div>
                <div class="hero-exp" aria-hidden="true">
                    <strong><?php echo toPersianNumbers('10'); ?>+</strong>
                    <span>سال تجربه</span>
                </div>
            </div>
        </div>
        <?php if (!empty($elnazHeroStats)): ?>
        <div class="container">
            <div class="hero-stats-bar">
                <?php foreach ($elnazHeroStats as $elnazStat): ?>
                <div class="hero-stat">
                    <span class="hero-stat-num"><?php echo toPersianNumbers(htmlspecialchars($elnazStat['num'], ENT_QUOTES)); ?></span>
                    <span class="hero-stat-label"><?php echo htmlspecialchars($elnazStat['label'], ENT_QUOTES); ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </section>

    <?php if (!empty($elnazServices)): ?>
    <!-- ==================== نوار متحرک خدمات ==================== -->
    <div class="ticker" aria-hidden="true">
        <div class="ticker-track">
            <?php for ($elnazTickerI = 0; $elnazTickerI < 2; $elnazTickerI++): ?>
            <div class="ticker-group">
                <?php foreach ($elnazServices as $elnazTickerService): ?>
                <span class="ticker-item">
                    <?php echo elnaz_icon('dumbbell', 15); ?>
                    <?php echo htmlspecialchars($elnazTickerService['title'], ENT_QUOTES); ?>
                </span>
                <?php endforeach; ?>
            </div>
            <?php endfor; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($elnazServices) && $elnazServicesTitle !== ''): ?>
    <!-- ==================== خدمات ==================== -->
    <section class="section services-section" id="services">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo elnaz_icon('zap', 14); ?> خدمات ما</span>
                <h2 class="section-title"><?php echo htmlspecialchars($elnazServicesTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($elnazServicesSubtitle, ENT_QUOTES); ?></p>
            </div>
            <div class="services-grid">
                <?php foreach ($elnazServices as $elnazService): ?>
                <div class="service-card">
                    <span class="service-icon"><?php echo elnaz_icon($elnazService['icon'], 26); ?></span>
                    <h3 class="service-title">
                        <?php if (trim($elnazService['url']) !== ''): ?>
                        <a href="<?php echo htmlspecialchars(elnaz_link_url($elnazService['url']), ENT_QUOTES); ?>"><?php echo htmlspecialchars($elnazService['title'], ENT_QUOTES); ?></a>
                        <?php else: ?>
                        <?php echo htmlspecialchars($elnazService['title'], ENT_QUOTES); ?>
                        <?php endif; ?>
                    </h3>
                    <?php if ($elnazService['desc'] !== ''): ?>
                    <p class="service-desc"><?php echo htmlspecialchars($elnazService['desc'], ENT_QUOTES); ?></p>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($elnazPackages) && $elnazPackagesTitle !== ''): ?>
    <!-- ==================== پکیج‌ها ==================== -->
    <section class="section packages-section" id="packages">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo elnaz_icon('clipboard-list', 14); ?> اشتراک‌ها</span>
                <h2 class="section-title"><?php echo htmlspecialchars($elnazPackagesTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($elnazPackagesSubtitle, ENT_QUOTES); ?></p>
            </div>
            <div class="packages-grid">
                <?php foreach ($elnazPackages as $elnazPackage): ?>
                <div class="package-card<?php echo trim($elnazPackage['badge']) !== '' ? ' is-featured' : ''; ?>">
                    <?php if (trim($elnazPackage['badge']) !== ''): ?>
                    <span class="package-badge"><?php echo htmlspecialchars($elnazPackage['badge'], ENT_QUOTES); ?></span>
                    <?php endif; ?>
                    <h3 class="package-title"><?php echo htmlspecialchars($elnazPackage['title'], ENT_QUOTES); ?></h3>
                    <div class="package-price">
                        <?php if ($elnazPackage['price'] !== ''): ?>
                        <span class="package-price-current"><?php echo toPersianNumbers(htmlspecialchars($elnazPackage['price'], ENT_QUOTES)); ?></span>
                        <?php if ($elnazPackage['oldPrice'] !== ''): ?>
                        <span class="package-price-old"><?php echo toPersianNumbers(htmlspecialchars($elnazPackage['oldPrice'], ENT_QUOTES)); ?></span>
                        <?php endif; ?>
                        <?php else: ?>
                        <span class="package-price-current">تماس بگیرید</span>
                        <?php endif; ?>
                    </div>
                    <?php if ($elnazPackage['desc'] !== ''): ?>
                    <p class="package-desc"><?php echo htmlspecialchars($elnazPackage['desc'], ENT_QUOTES); ?></p>
                    <?php endif; ?>
                    <?php if (!empty($elnazPackage['items'])): ?>
                    <ul class="package-items">
                        <?php foreach ($elnazPackage['items'] as $elnazPackageItem): ?>
                        <li><?php echo elnaz_icon('check-circle', 15); ?><span><?php echo htmlspecialchars($elnazPackageItem, ENT_QUOTES); ?></span></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                    <a href="<?php echo htmlspecialchars(elnaz_link_url($elnazPackage['url'] !== '' ? $elnazPackage['url'] : '#booking'), ENT_QUOTES); ?>" class="btn btn-package<?php echo trim($elnazPackage['badge']) !== '' ? ' btn-primary' : ' btn-ghost'; ?>">
                        <?php echo elnaz_icon('send', 15); ?>
                        <?php echo $elnazPackage['price'] !== '' ? 'ثبت اشتراک' : 'استعلام قیمت'; ?>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($elnazTeam) && $elnazTeamTitle !== ''): ?>
    <!-- ==================== مربیان ==================== -->
    <section class="section team-section" id="team">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo elnaz_icon('award', 14); ?> تیم مربیان</span>
                <h2 class="section-title"><?php echo htmlspecialchars($elnazTeamTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($elnazTeamSubtitle, ENT_QUOTES); ?></p>
            </div>
            <?php
            /* شبکهٔ داینامیک: ۴ کارت پیش‌فرض؛ با تعداد کمتر، کارت‌ها کش می‌آیند و
               جای کارت حذف‌شده را پر می‌کنند؛ یک مربی به شکل ردیف (افقی) نمایش داده می‌شود */
            $elnazTeamCount = count($elnazTeam);
            $elnazTeamCols = max(1, min(4, $elnazTeamCount));
            ?>
            <div class="team-grid cols-<?php echo $elnazTeamCols; ?><?php echo $elnazTeamCount === 1 ? ' team-single' : ''; ?>">
                <?php foreach ($elnazTeam as $elnazMember): ?>
                <?php $elnazMemberPhoto = trim($elnazMember['photo']); ?>
                <div class="team-card<?php echo $elnazMemberPhoto !== '' ? '' : ' team-card-simple'; ?>">
                    <?php if ($elnazMemberPhoto !== ''): ?>
                    <div class="team-media">
                        <img src="<?php echo htmlspecialchars($elnazMemberPhoto, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($elnazMember['name'], ENT_QUOTES); ?>" class="team-photo" loading="lazy">
                        <span class="team-role-chip"><?php echo htmlspecialchars($elnazMember['role'], ENT_QUOTES); ?></span>
                    </div>
                    <?php else: ?>
                    <span class="team-avatar"><?php echo htmlspecialchars(elnaz_initial($elnazMember['name']), ENT_QUOTES); ?></span>
                    <span class="team-role"><?php echo htmlspecialchars($elnazMember['role'], ENT_QUOTES); ?></span>
                    <?php endif; ?>
                    <div class="team-info">
                        <strong class="team-name"><?php echo htmlspecialchars($elnazMember['name'], ENT_QUOTES); ?></strong>
                        <?php if ($elnazMember['desc'] !== ''): ?>
                        <p class="team-desc"><?php echo htmlspecialchars($elnazMember['desc'], ENT_QUOTES); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if (!empty($elnazBlogPosts)): ?>
    <!-- ==================== آخرین مقالات ==================== -->
    <section class="section blog-section" id="blog">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo elnaz_icon('book-open', 14); ?> وبلاگ</span>
                <h2 class="section-title"><?php echo htmlspecialchars(elnaz_opt('elnazBlogTitle', 'مقالات تناسب اندام'), ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars(elnaz_opt('elnazBlogSubtitle', 'آخرین نکات علمی تمرین، تغذیهٔ ورزشی و تناسب اندام'), ENT_QUOTES); ?></p>
            </div>
            <div class="blog-grid">
                <?php foreach ($elnazBlogPosts as $elnazBlogPost): ?>
                <article class="blog-card">
                    <a href="<?php echo htmlspecialchars($elnazBlogPost['url'], ENT_QUOTES); ?>" class="blog-card-link">
                        <div class="blog-card-thumb">
                            <img src="<?php echo htmlspecialchars($elnazBlogPost['thumb'], ENT_QUOTES); ?>" alt="<?php echo toPersianNumbers(htmlspecialchars($elnazBlogPost['title'], ENT_QUOTES)); ?>" loading="lazy">
                            <?php if (is_numeric($elnazBlogPost['calories']) && (int)$elnazBlogPost['calories'] > 0): ?>
                            <span class="blog-card-badge"><?php echo elnaz_icon('flame', 13); ?> <?php echo toPersianNumbers($elnazBlogPost['calories']); ?> کیلوکالری</span>
                            <?php elseif (is_numeric($elnazBlogPost['cookTime']) && (int)$elnazBlogPost['cookTime'] > 0): ?>
                            <span class="blog-card-badge"><?php echo elnaz_icon('clock', 13); ?> <?php echo toPersianNumbers($elnazBlogPost['cookTime']); ?> دقیقه</span>
                            <?php endif; ?>
                        </div>
                        <div class="blog-card-body">
                            <div class="blog-card-meta">
                                <span><?php echo elnaz_icon('calendar', 13); ?> <?php echo elnaz_jalali_date($elnazBlogPost['created'], 'j F Y'); ?></span>
                                <?php if (elnaz_opt('elnazShowViews', '1') === '1' && $elnazBlogPost['views'] > 0): ?>
                                <span><?php echo elnaz_icon('eye', 13); ?> <?php echo elnaz_num($elnazBlogPost['views']); ?></span>
                                <?php endif; ?>
                            </div>
                            <h3 class="blog-card-title"><?php echo toPersianNumbers(htmlspecialchars($elnazBlogPost['title'], ENT_QUOTES)); ?></h3>
                            <p class="blog-card-excerpt"><?php echo toPersianNumbers(mb_substr($elnazBlogPost['excerpt'], 0, 100, 'UTF-8') . '…'); ?></p>
                            <span class="blog-card-more">ادامه مطلب <?php echo elnaz_icon('arrow-left', 14); ?></span>
                        </div>
                    </a>
                </article>
                <?php endforeach; ?>
            </div>
            <div class="section-more">
                <a href="<?php echo htmlspecialchars(elnaz_blog_url(), ENT_QUOTES); ?>" class="btn btn-ghost">
                    مشاهدهٔ همهٔ مقالات
                    <?php echo elnaz_icon('arrow-left', 15); ?>
                </a>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- ==================== رزرو و تماس ==================== -->
    <section class="section contact-section" id="booking">
        <div class="container">
            <div class="section-head">
                <span class="section-tag"><?php echo elnaz_icon('calendar-check', 14); ?> شروع رایگان</span>
                <h2 class="section-title"><?php echo htmlspecialchars($elnazBookingTitle, ENT_QUOTES); ?></h2>
                <p class="section-subtitle"><?php echo htmlspecialchars($elnazBookingSubtitle, ENT_QUOTES); ?></p>
            </div>

            <?php
            $elnazSocial = [
                'instagram' => elnaz_opt_raw('elnazSocialInstagram'),
                'telegram'  => elnaz_opt_raw('elnazSocialTelegram'),
                'whatsapp'  => elnaz_opt_raw('elnazSocialWhatsapp'),
                'youtube'   => elnaz_opt_raw('elnazSocialYoutube'),
            ];
            $elnazSocialActive = array_filter($elnazSocial, function ($u) { return trim((string)$u) !== ''; });
            ?>

            <div class="booking-split">
                <!-- پنل طلایی مزایا -->
                <aside class="booking-side">
                    <span class="booking-side-tag"><?php echo elnaz_icon('sparkles', 15); ?> هدیهٔ ورودی الناز</span>
                    <h3 class="booking-side-title">اولین جلسهٔ تو <em>رایگان</em> است!</h3>
                    <p class="booking-side-desc">بدون هیچ هزینه و تعهدی شروع کن؛ با یک جلسهٔ کامل، فضای باشگاه، مربیان و مسیر پیشنهادی‌ات را از نزدیک ببین.</p>
                    <ul class="booking-perks">
                        <li><?php echo elnaz_icon('check-circle', 17); ?><span>مشاورهٔ اختصاصی و بررسی ترکیب بدنی</span></li>
                        <li><?php echo elnaz_icon('check-circle', 17); ?><span>یک جلسهٔ تمرین کامل همراه با مربی</span></li>
                        <li><?php echo elnaz_icon('check-circle', 17); ?><span>معرفی سالن، تجهیزات و برنامهٔ پیشنهادی</span></li>
                    </ul>
                    <div class="booking-side-foot">
                        <?php if ($elnazContactPhone !== null && trim($elnazContactPhone) !== ''): ?>
                        <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $elnazContactPhone), ENT_QUOTES); ?>" class="booking-call">
                            <?php echo elnaz_icon('phone-call', 17); ?>
                            <span><?php echo htmlspecialchars(toPersianNumbers($elnazContactPhone), ENT_QUOTES); ?></span>
                        </a>
                        <?php endif; ?>
                        <?php if (!empty($elnazContactHours)): ?>
                        <span class="booking-hours">
                            <?php echo elnaz_icon('clock', 15); ?>
                            <?php echo htmlspecialchars(toPersianNumbers($elnazContactHours[0]), ENT_QUOTES); ?>
                        </span>
                        <?php endif; ?>
                    </div>
                </aside>

                <!-- فرم رزرو -->
                <div class="booking-panel">
                    <?php
                    /*
                     * ارسال به نقطهٔ پایانی اختصاصی /elnaz-booking (الگو از افزونهٔ Booking)؛
                     * اگر مسیر هنوز ثبت نشده باشد، آدرس صفحهٔ جاری جایگزین می‌شود.
                     * توکن امنیتی _ مطابق Widget\Security::getToken برای همان صفحه تولید می‌شود
                     * و سمت سرور با getToken(referer) اعتبارسنجی می‌شود.
                     */
                    $elnazBookingAction = elnaz_booking_endpoint();
                    try {
                        $elnazBookingToken = htmlspecialchars(
                            \Widget\Security::alloc()->getToken($this->request->getRequestUrl()),
                            ENT_QUOTES,
                            'UTF-8'
                        );
                    } catch (\Throwable $e) {
                        $elnazBookingToken = '';
                    }
                    ?>
                    <div class="booking-panel-head">
                        <span class="booking-panel-ic"><?php echo elnaz_icon('calendar-check', 22); ?></span>
                        <div>
                            <strong>فرم رزرو جلسهٔ رایگان</strong>
                            <span>کمتر از یک دقیقه طول می‌کشد</span>
                        </div>
                    </div>
                    <form class="booking-form" id="bookingForm" method="post"
                          action="<?php echo htmlspecialchars($elnazBookingAction, ENT_QUOTES); ?>" novalidate>
                        <input type="hidden" name="elnazBooking" value="1">
                        <?php if ($elnazBookingToken !== ''): ?>
                        <input type="hidden" name="_" value="<?php echo $elnazBookingToken; ?>">
                        <?php endif; ?>

                        <!-- تلهٔ هرزنامه — باید خالی بماند -->
                        <input type="text" name="elnazHp" class="hp-field" tabindex="-1" autocomplete="off" aria-hidden="true">

                        <div class="booking-form-row">
                            <div class="booking-field">
                                <label for="elnazName">نام و نام خانوادگی <span class="req">*</span></label>
                                <input type="text" id="elnazName" name="elnazName" class="booking-input" placeholder="مثلاً: آرش رضایی" required>
                            </div>
                            <div class="booking-field">
                                <label for="elnazPhone">شمارهٔ تلفن همراه <span class="req">*</span></label>
                                <input type="tel" id="elnazPhone" name="elnazPhone" class="booking-input" placeholder="۰۹۱۲۳۴۵۶۷۸۹" required>
                            </div>
                        </div>

                        <div class="booking-form-row">
                            <?php if (!empty($elnazBookingServices)): ?>
                            <div class="booking-field">
                                <label for="elnazService">نوع تمرین موردنیاز</label>
                                <select id="elnazService" name="elnazService" class="booking-input booking-select">
                                    <option value="">انتخاب کنید…</option>
                                    <?php foreach ($elnazBookingServices as $elnazBookingService): ?>
                                    <option value="<?php echo htmlspecialchars($elnazBookingService, ENT_QUOTES); ?>"><?php echo htmlspecialchars($elnazBookingService, ENT_QUOTES); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($elnazBookingGoals)): ?>
                            <div class="booking-field">
                                <label for="elnazGoal">هدف شما</label>
                                <select id="elnazGoal" name="elnazGoal" class="booking-input booking-select">
                                    <option value="">انتخاب کنید…</option>
                                    <?php foreach ($elnazBookingGoals as $elnazBookingGoal): ?>
                                    <option value="<?php echo htmlspecialchars($elnazBookingGoal, ENT_QUOTES); ?>"><?php echo htmlspecialchars($elnazBookingGoal, ENT_QUOTES); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="booking-form-row booking-form-row-3">
                            <div class="booking-field">
                                <label for="elnazAge">سن</label>
                                <input type="number" id="elnazAge" name="elnazAge" class="booking-input" min="8" max="90" placeholder="مثلاً: ۲۸">
                            </div>
                            <div class="booking-field">
                                <label for="elnazHeight">قد (cm)</label>
                                <input type="number" id="elnazHeight" name="elnazHeight" class="booking-input" min="140" max="210" placeholder="۱۷۵">
                            </div>
                            <div class="booking-field">
                                <label for="elnazWeight">وزن (kg)</label>
                                <input type="number" id="elnazWeight" name="elnazWeight" class="booking-input" min="40" max="160" placeholder="۸۰">
                            </div>
                        </div>

                        <div class="booking-field">
                            <label for="elnazNote">توضیحات (اختیاری)</label>
                            <textarea id="elnazNote" name="elnazNote" class="booking-input" rows="3" placeholder="هر نکته‌ای که لازم است بدانیم: سابقهٔ تمرین، آسیب‌های حرکتی، ساعت مناسب تمرین…"></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg btn-block" id="bookingSubmitBtn">
                            <?php echo elnaz_icon('send', 17); ?>
                            <span>ثبت درخواست جلسهٔ رایگان</span>
                        </button>

                        <p class="booking-form-note">
                            <?php echo elnaz_icon('shield-check', 13); ?>
                            اطلاعات شما محفوظ است و فقط برای هماهنگی جلسهٔ رایگان استفاده می‌شود.
                        </p>

                        <div class="booking-alert booking-alert-success" id="bookingSuccess" hidden>
                            <?php echo elnaz_icon('check-circle', 20); ?>
                            <div>
                                <strong>جلسهٔ رایگان شما رزرو شد!</strong>
                                <span>مربیان ما در اولین فرصت برای هماهنگی با شما تماس می‌گیرند.</span>
                            </div>
                        </div>
                        <div class="booking-alert booking-alert-error" id="bookingError" hidden>
                            <?php echo elnaz_icon('x', 20); ?>
                            <div>
                                <strong>خطا در ثبت درخواست!</strong>
                                <span id="bookingErrorText">لطفاً دوباره تلاش کنید.</span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <?php
            $elnazContactCards = [];
            if ($elnazContactPhone !== null && trim($elnazContactPhone) !== '') {
                $elnazContactCards[] = ['icon' => 'phone', 'label' => 'تلفن ثابت', 'value' => toPersianNumbers($elnazContactPhone), 'href' => 'tel:' . preg_replace('/[^0-9+]/', '', $elnazContactPhone)];
            }
            if ($elnazContactPhone2 !== null && trim($elnazContactPhone2) !== '') {
                $elnazContactCards[] = ['icon' => 'message-circle', 'label' => 'شمارهٔ همراه', 'value' => toPersianNumbers($elnazContactPhone2), 'href' => 'tel:' . preg_replace('/[^0-9+]/', '', $elnazContactPhone2)];
            }
            if ($elnazContactEmail !== null && trim($elnazContactEmail) !== '') {
                $elnazContactCards[] = ['icon' => 'mail', 'label' => 'ایمیل', 'value' => $elnazContactEmail, 'href' => 'mailto:' . $elnazContactEmail];
            }
            if ($elnazContactAddr !== null && trim($elnazContactAddr) !== '') {
                $elnazContactCards[] = ['icon' => 'map-pin', 'label' => 'آدرس باشگاه', 'value' => toPersianNumbers($elnazContactAddr), 'href' => ''];
            }
            ?>
            <?php if (!empty($elnazContactCards) || !empty($elnazContactHours) || !empty($elnazSocialActive)): ?>
            <div class="contact-cards" id="contact">
                <?php foreach ($elnazContactCards as $elnazContactCard): ?>
                <div class="contact-card">
                    <span class="contact-card-ic"><?php echo elnaz_icon($elnazContactCard['icon'], 19); ?></span>
                    <div class="contact-card-body">
                        <strong><?php echo htmlspecialchars($elnazContactCard['label'], ENT_QUOTES); ?></strong>
                        <?php if ($elnazContactCard['href'] !== ''): ?>
                        <a href="<?php echo htmlspecialchars($elnazContactCard['href'], ENT_QUOTES); ?>"><?php echo htmlspecialchars($elnazContactCard['value'], ENT_QUOTES); ?></a>
                        <?php else: ?>
                        <span><?php echo htmlspecialchars($elnazContactCard['value'], ENT_QUOTES); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php if (!empty($elnazContactHours)): ?>
                <div class="contact-card contact-card-hours">
                    <span class="contact-card-ic"><?php echo elnaz_icon('clock', 19); ?></span>
                    <div class="contact-card-body">
                        <strong>ساعت کاری</strong>
                        <?php foreach ($elnazContactHours as $elnazContactHour): ?>
                        <span class="contact-hours-line"><?php echo htmlspecialchars(toPersianNumbers($elnazContactHour), ENT_QUOTES); ?></span>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                <?php if (!empty($elnazSocialActive)): ?>
                <div class="contact-card contact-card-social">
                    <span class="contact-card-ic"><?php echo elnaz_icon('users', 19); ?></span>
                    <div class="contact-card-body">
                        <strong>ما را دنبال کنید</strong>
                        <div class="contact-social">
                            <?php foreach ($elnazSocialActive as $elnazNet => $elnazUrl): ?>
                            <a href="<?php echo htmlspecialchars($elnazUrl, ENT_QUOTES); ?>" target="_blank" rel="noopener" aria-label="<?php echo ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام', 'whatsapp' => 'واتس‌اپ', 'youtube' => 'یوتیوب'][$elnazNet]; ?>">
                                <?php echo elnaz_icon($elnazNet === 'telegram' ? 'send' : ($elnazNet === 'whatsapp' ? 'message-circle' : $elnazNet), 17); ?>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php if ($elnazMapEmbed !== ''): ?>
            <div class="contact-map">
                <?php echo $elnazMapEmbed; ?>
            </div>
            <?php endif; ?>
        </div>
    </section>

<?php

else:

    /* ================================================================
     *  فهرست وبلاگ — مسیر آرشیو (/blog/) و صفحه‌بندی آن
     * ================================================================ */
?>
    <div class="container archive-wrap">
        <header class="archive-head">
            <span class="section-tag"><?php echo elnaz_icon('file-text', 14); ?> وبلاگ</span>
            <h1 class="archive-title">
                <?php if ($this->is('archive')): ?>
                    <?php $this->archiveTitle(['category' => _t('دستهٔ %s'), 'search' => _t('جستجو: %s'), 'tag' => _t('برچسب %s'), 'author' => _t('نوشته‌های %s'), 'date' => _t('آرشیو %s')], '', ''); ?>
                <?php else: ?>
                    <?php echo htmlspecialchars(elnaz_opt('elnazBlogTitle', 'مقالات تناسب اندام') === 'مقالات تناسب اندام' ? 'همهٔ مقالات' : elnaz_opt('elnazBlogTitle', 'مقالات تناسب اندام'), ENT_QUOTES); ?>
                <?php endif; ?>
            </h1>
            <p class="section-subtitle"><?php echo htmlspecialchars(elnaz_opt('elnazBlogSubtitle', 'آخرین نکات علمی تمرین، تغذیهٔ ورزشی و تناسب اندام'), ENT_QUOTES); ?></p>
        </header>

        <?php if ($this->have()): ?>
        <div class="archive-grid">
            <?php while ($this->next()): ?>
            <article class="blog-card">
                <a href="<?php $this->permalink(); ?>" class="blog-card-link">
                    <div class="blog-card-thumb">
                        <img src="<?php echo htmlspecialchars(elnaz_thumbnail($this), ENT_QUOTES); ?>" alt="<?php echo elnaz_fa_title($this); ?>" loading="lazy">
                        <?php
                        $elnazListCalories = elnaz_calories($this);
                        $elnazListCook = elnaz_cook_time($this);
                        ?>
                        <?php if ($elnazListCalories !== ''): ?>
                        <span class="blog-card-badge"><?php echo elnaz_icon('flame', 13); ?> <?php echo $elnazListCalories; ?> کیلوکالری</span>
                        <?php elseif ($elnazListCook !== ''): ?>
                        <span class="blog-card-badge"><?php echo elnaz_icon('clock', 13); ?> <?php echo $elnazListCook; ?> دقیقه</span>
                        <?php endif; ?>
                    </div>
                    <div class="blog-card-body">
                        <div class="blog-card-meta">
                            <span><?php echo elnaz_icon('calendar', 13); ?> <?php echo elnaz_post_date($this, 'j F Y'); ?></span>
                            <?php if (elnaz_opt('elnazShowViews', '1') === '1'): ?>
                            <span><?php echo elnaz_icon('eye', 13); ?> <?php echo elnaz_num(elnaz_views($this)); ?></span>
                            <?php endif; ?>
                        </div>
                        <h2 class="blog-card-title"><?php echo elnaz_fa_title($this); ?></h2>
                        <p class="blog-card-excerpt"><?php echo toPersianNumbers(mb_substr(trim(strip_tags((string)$this->excerpt)), 0, 100, 'UTF-8') . '...'); ?></p>
                        <span class="blog-card-more">ادامه مطلب <?php echo elnaz_icon('arrow-left', 14); ?></span>
                    </div>
                </a>
            </article>
            <?php endwhile; ?>
        </div>
        <?php else: ?>
        <div class="archive-empty">
            <?php echo elnaz_icon('search', 44); ?>
            <p>هنوز مقاله‌ای منتشر نشده است.</p>
            <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-ghost">بازگشت به خانه</a>
        </div>
        <?php endif; ?>

        <?php elnaz_page_nav($this); ?>
    </div>
<?php endif;

$this->need('footer.php');
