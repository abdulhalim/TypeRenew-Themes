<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<section class="container error-404-wrap">
    <div class="error-404-box">
        <span class="error-404-code"><?php echo elnaz_icon('search', 56); ?></span>
        <h1 class="error-404-title">۴۰۴ — صفحه پیدا نشد!</h1>
        <p class="error-404-text">صفحه‌ای که دنبالش بودید حذف شده یا آدرس آن عوض شده است. از این‌جا مسیرتان را ادامه دهید:</p>
        <div class="error-404-actions">
            <a href="<?php $this->options->siteUrl(); ?>" class="btn btn-primary"><?php echo elnaz_icon('home', 16); ?> بازگشت به خانه</a>
            <a href="<?php echo htmlspecialchars(elnaz_blog_url(), ENT_QUOTES); ?>" class="btn btn-ghost"><?php echo elnaz_icon('file-text', 16); ?> مرور مقالات</a>
            <a href="<?php echo htmlspecialchars(elnaz_link_url('#services', false), ENT_QUOTES); ?>" class="btn btn-ghost"><?php echo elnaz_icon('dumbbell', 16); ?> خدمات باشگاه</a>
        </div>
    </div>
</section>

<?php $this->need('footer.php'); ?>
