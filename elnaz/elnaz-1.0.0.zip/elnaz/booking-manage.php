<?php
/**
 * مدیریت رزروهای الناز — قالب سفارشی برگه
 *
 * نمایش و مدیریت درخواست‌های رزرو (فقط برای اعضای واردشده با دسترسی مدیر/سردبیر).
 * درخواست‌ها روی برگهٔ «دفتر رزرو» به‌صورت دیدگاه ذخیره شده‌اند؛ این قالب
 * آن‌ها را به‌صورت ساختاریافته (مثل افزونهٔ Booking) نمایش می‌دهد و دکمه‌های
 * تأیید/رد/حذف دارد که با AJAX به نقطهٔ پایانی /elnaz-booking ارسال می‌شوند.
 *
 * @package custom
 * @author پوردریایی
 * @link https://pourdaryaei.ir
 * @version 1.0.0
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');

$elnazManageOk = elnaz_can_manage_bookings();
$elnazBookings = $elnazManageOk ? elnaz_bookings_list() : [];
$elnazStats = ['total' => 0, 'waiting' => 0, 'approved' => 0, 'spam' => 0];
foreach ($elnazBookings as $elnazB) {
    $elnazStats['total']++;
    if (isset($elnazStats[$elnazB['status']])) {
        $elnazStats[$elnazB['status']]++;
    }
}

$elnazStatusLabels = [
    'waiting'  => 'در انتظار بررسی',
    'approved' => 'تأیید شده',
    'spam'     => 'رد شده',
];
$elnazStatusClasses = [
    'waiting'  => 'bkst-waiting',
    'approved' => 'bkst-approved',
    'spam'     => 'bkst-rejected',
];

$elnazManageToken = '';
try {
    $elnazManageToken = htmlspecialchars(
        \Widget\Security::alloc()->getToken($this->request->getRequestUrl()),
        ENT_QUOTES,
        'UTF-8'
    );
} catch (\Throwable $e) {
}

$elnazManageEndpoint = elnaz_booking_endpoint();
?>

<article class="page-wrap container bk-manage">

    <header class="page-head">
        <nav class="post-breadcrumb" aria-label="مسیر">
            <a href="<?php $this->options->siteUrl(); ?>">خانه</a>
            <span class="crumb-sep">/</span>
            <span aria-current="page">مدیریت رزروها</span>
        </nav>
        <h1 class="page-title">
            <?php echo elnaz_icon('calendar-check', 22); ?>
            مدیریت رزروها
        </h1>
        <p class="bk-manage-sub">درخواست‌های جلسهٔ رایگان ثبت‌شده از فرم سایت — جدیدترین در ابتدا؛ درخواست‌های در انتظار بررسی اولویت دارند.</p>
    </header>

    <?php if (!$elnazManageOk): ?>
    <div class="bk-manage-notice" role="alert">
        <?php echo elnaz_icon('lock', 22); ?>
        <div>
            <strong>ورود لازم است</strong>
            <span>برای مشاهده و مدیریت رزروها باید با حساب مدیر یا سردبیر وارد سایت شوید.</span>
            <a class="btn btn-primary btn-sm" href="<?php echo htmlspecialchars((string)$this->options->loginUrl, ENT_QUOTES); ?>">ورود به حساب</a>
        </div>
    </div>
    <?php else: ?>

    <div class="bk-manage-stats">
        <div class="bk-stat">
            <span class="bk-stat-num"><?php echo toPersianNumbers($elnazStats['waiting']); ?></span>
            <span class="bk-stat-label">در انتظار بررسی</span>
        </div>
        <div class="bk-stat bk-stat-approved">
            <span class="bk-stat-num"><?php echo toPersianNumbers($elnazStats['approved']); ?></span>
            <span class="bk-stat-label">تأیید شده</span>
        </div>
        <div class="bk-stat bk-stat-rejected">
            <span class="bk-stat-num"><?php echo toPersianNumbers($elnazStats['spam']); ?></span>
            <span class="bk-stat-label">رد شده</span>
        </div>
        <div class="bk-stat bk-stat-total">
            <span class="bk-stat-num"><?php echo toPersianNumbers($elnazStats['total']); ?></span>
            <span class="bk-stat-label">مجموع</span>
        </div>
    </div>

    <div class="bk-manage-list" id="bkManageList">
        <?php if (empty($elnazBookings)): ?>
        <div class="bk-manage-empty">
            <?php echo elnaz_icon('inbox', 40); ?>
            <p>هنوز درخواستی ثبت نشده است.</p>
            <p class="bk-manage-empty-sub">به‌محض ثبت اولین درخواست جلسهٔ رایگان، اینجا نمایش داده می‌شود.</p>
        </div>
        <?php else: ?>
        <?php foreach ($elnazBookings as $elnazB): ?>
        <?php
        $elnazBPhone = trim((string)($elnazB['phone'] !== '' ? $elnazB['phone'] : $elnazB['url']));
        $elnazBTel = preg_replace('/[^0-9+]/', '', $elnazBPhone);
        ?>
        <div class="bk-card" data-coid="<?php echo (int)$elnazB['coid']; ?>">
            <div class="bk-card-head">
                <span class="bk-status <?php echo $elnazStatusClasses[$elnazB['status']] ?? 'bkst-other'; ?>">
                    <?php echo htmlspecialchars($elnazStatusLabels[$elnazB['status']] ?? $elnazB['status'], ENT_QUOTES); ?>
                </span>
                <span class="bk-card-date">
                    <?php echo elnaz_icon('clock', 13); ?>
                    <?php echo elnaz_jalali_date((int)$elnazB['created'], 'j F Y — H:i'); ?>
                </span>
            </div>

            <div class="bk-card-body">
                <div class="bk-card-main">
                    <div class="bk-card-name">
                        <?php echo elnaz_icon('user', 16); ?>
                        <strong><?php echo htmlspecialchars((string)$elnazB['author'], ENT_QUOTES); ?></strong>
                    </div>
                    <?php if ($elnazBPhone !== ''): ?>
                    <div class="bk-card-field">
                        <?php echo elnaz_icon('phone', 15); ?>
                        <a href="tel:<?php echo htmlspecialchars($elnazBTel, ENT_QUOTES); ?>" dir="ltr"><?php echo htmlspecialchars(toPersianNumbers($elnazBPhone), ENT_QUOTES); ?></a>
                    </div>
                    <?php endif; ?>
                    <?php if ($elnazB['mail'] !== ''): ?>
                    <div class="bk-card-field">
                        <?php echo elnaz_icon('mail', 15); ?>
                        <a href="mailto:<?php echo htmlspecialchars($elnazB['mail'], ENT_QUOTES); ?>" dir="ltr"><?php echo htmlspecialchars($elnazB['mail'], ENT_QUOTES); ?></a>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="bk-card-side">
                    <?php if ($elnazB['service'] !== ''): ?>
                    <div class="bk-tag"><?php echo elnaz_icon('dumbbell', 13); ?> <?php echo htmlspecialchars($elnazB['service'], ENT_QUOTES); ?></div>
                    <?php endif; ?>
                    <?php if ($elnazB['goal'] !== ''): ?>
                    <div class="bk-tag"><?php echo elnaz_icon('target', 13); ?> <?php echo htmlspecialchars($elnazB['goal'], ENT_QUOTES); ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($elnazB['age'] !== '' || $elnazB['height'] !== '' || $elnazB['weight'] !== ''): ?>
            <div class="bk-card-metrics">
                <?php if ($elnazB['age'] !== ''): ?><span><?php echo elnaz_icon('cake', 13); ?> سن: <strong><?php echo htmlspecialchars($elnazB['age'], ENT_QUOTES); ?></strong></span><?php endif; ?>
                <?php if ($elnazB['height'] !== ''): ?><span><?php echo elnaz_icon('ruler', 13); ?> قد: <strong><?php echo htmlspecialchars($elnazB['height'], ENT_QUOTES); ?> سانتی‌متر</strong></span><?php endif; ?>
                <?php if ($elnazB['weight'] !== ''): ?><span><?php echo elnaz_icon('scale', 13); ?> وزن: <strong><?php echo htmlspecialchars($elnazB['weight'], ENT_QUOTES); ?> کیلوگرم</strong></span><?php endif; ?>
            </div>
            <?php endif; ?>

            <?php if ($elnazB['note'] !== ''): ?>
            <div class="bk-card-note">
                <?php echo elnaz_icon('message-square', 14); ?>
                <p><?php echo htmlspecialchars($elnazB['note'], ENT_QUOTES); ?></p>
            </div>
            <?php endif; ?>

            <div class="bk-card-actions">
                <?php if ($elnazB['status'] !== 'approved'): ?>
                <button type="button" class="bk-btn bk-btn-approve" data-mode="approve" data-coid="<?php echo (int)$elnazB['coid']; ?>">
                    <?php echo elnaz_icon('check', 14); ?> تأیید
                </button>
                <?php endif; ?>
                <?php if ($elnazB['status'] !== 'spam'): ?>
                <button type="button" class="bk-btn bk-btn-reject" data-mode="reject" data-coid="<?php echo (int)$elnazB['coid']; ?>">
                    <?php echo elnaz_icon('x', 14); ?> رد
                </button>
                <?php endif; ?>
                <button type="button" class="bk-btn bk-btn-delete" data-mode="delete" data-coid="<?php echo (int)$elnazB['coid']; ?>">
                    <?php echo elnaz_icon('trash-2', 14); ?> حذف
                </button>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script>
    (function () {
        'use strict';
        var list = document.getElementById('bkManageList');
        if (!list) { return; }
        var endpoint = <?php echo json_encode($elnazManageEndpoint, JSON_UNESCAPED_SLASHES); ?>;
        var token = <?php echo json_encode($elnazManageToken); ?>;

        function setBusy(card, busy) {
            Array.prototype.forEach.call(card.querySelectorAll('.bk-btn'), function (b) {
                b.disabled = !!busy;
            });
        }

        list.addEventListener('click', function (e) {
            var btn = e.target.closest ? e.target.closest('.bk-btn') : null;
            if (!btn || btn.disabled) { return; }
            var card = btn.closest('.bk-card');
            if (!card) { return; }
            var coid = parseInt(btn.getAttribute('data-coid'), 10);
            var mode = btn.getAttribute('data-mode');
            if (!coid || !mode) { return; }

            if (mode === 'delete' && !window.confirm('این رزرو برای همیشه حذف شود؟')) { return; }

            setBusy(card, true);
            btn.classList.add('loading');

            var body = new URLSearchParams();
            body.append('elnazBooking', '1');
            body.append('mode', mode);
            body.append('coid', String(coid));
            if (token) { body.append('_', token); }

            fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' },
                body: body.toString(),
                credentials: 'same-origin'
            })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    if (data && data.ok) {
                        // ساده و مطمئن: بارگذاری مجدد صفحه
                        window.location.reload();
                    } else {
                        alert((data && data.error) ? data.error : 'خطا در به‌روزرسانی رزرو.');
                        setBusy(card, false);
                        btn.classList.remove('loading');
                    }
                })
                .catch(function () {
                    alert('خطای ارتباط با سرور؛ دوباره تلاش کنید.');
                    setBusy(card, false);
                    btn.classList.remove('loading');
                });
        });
    })();
    </script>
    <?php endif; ?>

</article>

<?php $this->need('footer.php'); ?>
