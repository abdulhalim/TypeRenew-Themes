<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="<?php $this->options->charset(); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php if ($this->options->favicon): ?>
    <link rel="icon" href="<?php $this->options->favicon(); ?>">
<?php endif; ?>
<title><?php $this->archiveTitle([
            'category' => _t('دستهٔ %s'),
            'search'   => _t('نتایج جستجوی %s'),
            'tag'      => _t('برچسب %s'),
            'author'   => _t('نوشته‌های %s')
        ], '', ' - '); ?><?php $this->options->title(); ?></title>
<?php
// ---------- توضیحات متا (فقط صفحهٔ اول) ----------
$elnazMetaDesc = '';
try {
    if (elnaz_is_front()) {
        $elnazMetaDesc = trim((string)elnaz_opt_raw('elnazHeroSubtitle'));
        $elnazMetaDesc = $elnazMetaDesc !== '' ? trim(preg_replace('/\s+/', ' ', strip_tags(str_replace("\n", ' ', $elnazMetaDesc)))) : '';
        if (mb_strlen($elnazMetaDesc) > 160) {
            $elnazMetaDesc = mb_substr($elnazMetaDesc, 0, 157, 'UTF-8') . '...';
        }
    }
} catch (\Throwable $e) {
}
if ($elnazMetaDesc !== ''):
?>
<meta name="description" content="<?php echo htmlspecialchars($elnazMetaDesc, ENT_QUOTES); ?>">
<?php endif; ?>
<?php $this->header(); ?>

<?php
// ---------- رنگ‌های داینامیک ----------
$elnazPrimary   = elnaz_opt('elnazPrimaryColor', '#d4af37');
$elnazSecondary = elnaz_opt('elnazSecondaryColor', '#b8860b');
if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $elnazPrimary)) { $elnazPrimary = '#d4af37'; }
if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $elnazSecondary)) { $elnazSecondary = '#b8860b'; }
?>

<style>:root{--primary:<?php echo $elnazPrimary; ?>;--secondary:<?php echo $elnazSecondary; ?>;}</style>

<!-- ---------- استایل‌های اصلی (با نسخه برای جلوگیری از کش) ---------- -->
<link rel="stylesheet" href="<?php $this->options->themeUrl('css/style.css'); ?>?v=1.0.0">
<link rel="stylesheet" href="<?php $this->options->themeUrl('css/fonts.css'); ?>?v=1.0.0">
</head>
<body class="elnaz-body farsi-digits">
<a href="#main" class="skip-link">رفتن به محتوای اصلی</a>

<?php
// ---------- داده‌های مشترک ----------
$elnazClinicName = elnaz_opt('elnazClinicName', (string)$this->options->title);
$elnazTagline    = elnaz_opt('elnazTagline', 'بدن قوی، ذهن قوی');
$elnazLogoUrl    = elnaz_logo_url();
$elnazPhone      = elnaz_opt_raw('elnazContactPhone');
$elnazShowTopbar = elnaz_opt('elnazShowTopbar', '1') === '1';
$elnazOnHome     = elnaz_is_front();
$elnazBlogUrl    = elnaz_blog_url();
$elnazIsBlogPage = in_array(elnaz_route(), ['archive', 'archive_page'], true);
$elnazSocial = [
    'instagram' => elnaz_opt_raw('elnazSocialInstagram'),
    'telegram'  => elnaz_opt_raw('elnazSocialTelegram'),
    'whatsapp'  => elnaz_opt_raw('elnazSocialWhatsapp'),
    'youtube'   => elnaz_opt_raw('elnazSocialYoutube'),
];
$elnazHoursLine = trim((string)elnaz_opt_raw('elnazContactHours'));
$elnazHoursLine = ($elnazHoursLine !== '') ? trim(strtok($elnazHoursLine, "\n")) : '';
?>

<!-- ---------- نوار بالای هدر ---------- -->
<?php if ($elnazShowTopbar): ?>
<div class="topbar">
    <div class="container topbar-inner">
        <div class="topbar-item topbar-phone">
            <?php echo elnaz_icon('phone', 15); ?>
            <?php if ($elnazPhone !== null && trim($elnazPhone) !== ''): ?>
                <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $elnazPhone), ENT_QUOTES); ?>"><?php echo htmlspecialchars(toPersianNumbers($elnazPhone), ENT_QUOTES); ?></a>
            <?php endif; ?>
        </div>
        <?php if ($elnazHoursLine !== ''): ?>
        <div class="topbar-item topbar-hours">
            <?php echo elnaz_icon('clock', 15); ?>
            <span><?php echo htmlspecialchars(toPersianNumbers($elnazHoursLine), ENT_QUOTES); ?></span>
        </div>
        <?php endif; ?>
        <div class="topbar-social">
            <?php foreach ($elnazSocial as $elnazNet => $elnazUrl): if (trim((string)$elnazUrl) !== ''): ?>
                <a href="<?php echo htmlspecialchars($elnazUrl, ENT_QUOTES); ?>" target="_blank" rel="noopener" aria-label="<?php echo ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام', 'whatsapp' => 'واتس‌اپ', 'youtube' => 'یوتیوب'][$elnazNet]; ?>">
                    <?php echo elnaz_icon($elnazNet === 'telegram' ? 'send' : ($elnazNet === 'whatsapp' ? 'message-circle' : $elnazNet), 15); ?>
                </a>
            <?php endif; endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ---------- هدر اصلی ---------- -->
<header class="site-header<?php echo $elnazShowTopbar ? '' : ' no-topbar'; ?>" id="siteHeader">
    <div class="container nav-container">

        <!-- بخش راست: لوگو -->
        <div class="nav-logo">
            <a href="<?php $this->options->siteUrl(); ?>" class="logo-link">
                <?php if ($elnazLogoUrl !== ''): ?>
                    <img src="<?php echo htmlspecialchars($elnazLogoUrl, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($elnazClinicName, ENT_QUOTES); ?>" class="logo-img">
                <?php else: ?>
                    <span class="logo-mark" aria-hidden="true"><?php echo elnaz_icon('dumbbell', 22); ?></span>
                <?php endif; ?>
                <span class="logo-text">
                    <span class="logo-main"><?php echo htmlspecialchars($elnazClinicName, ENT_QUOTES); ?></span>
                    <span class="logo-sub"><?php echo htmlspecialchars($elnazTagline, ENT_QUOTES); ?></span>
                </span>
            </a>
        </div>

        <!-- بخش وسط: منوی اصلی -->
        <nav class="main-nav" aria-label="منوی اصلی">
            <ul class="nav-links">
                <li><a href="<?php $this->options->siteUrl(); ?>" <?php if ($elnazOnHome): ?>class="active" aria-current="page"<?php endif; ?>>خانه</a></li>
                <li><a href="<?php echo htmlspecialchars(elnaz_link_url('#services', $elnazOnHome), ENT_QUOTES); ?>">خدمات</a></li>
                <li><a href="<?php echo htmlspecialchars(elnaz_link_url('#packages', $elnazOnHome), ENT_QUOTES); ?>">اشتراک‌ها</a></li>
                <li><a href="<?php echo htmlspecialchars(elnaz_link_url('#team', $elnazOnHome), ENT_QUOTES); ?>">مربیان</a></li>
                <li><a href="<?php echo htmlspecialchars($elnazOnHome ? '#blog' : $elnazBlogUrl, ENT_QUOTES); ?>" <?php if (!$elnazOnHome && ($elnazIsBlogPage || $this->is('archive') || $this->is('post'))): ?>class="active" aria-current="page"<?php endif; ?>>مقالات</a></li>
                <?php
                // ---------- برگه‌های منو (برگهٔ دفتر رزرو حذف می‌شود) ----------
                $elnazNavPages = \Widget\Contents\Page\Rows::alloc();
                $elnazNavCount = 0;
                while ($elnazNavPages->next()):
                    if (elnaz_is_reserve_cid((int)$elnazNavPages->cid)) { continue; }
                    $elnazNavCount++;
                    if ($elnazNavCount > 3) { break; } // حداکثر ۳ برگه در منو
                ?>
                    <li><a href="<?php $elnazNavPages->permalink(); ?>" <?php if ($this->is('page', $elnazNavPages->slug)): ?>class="active" aria-current="page"<?php endif; ?>><?php echo elnaz_fa_title($elnazNavPages); ?></a></li>
                <?php endwhile; ?>
                <li><a href="<?php echo htmlspecialchars(elnaz_link_url('#contact', $elnazOnHome), ENT_QUOTES); ?>">تماس</a></li>
            </ul>
        </nav>

        <!-- بخش چپ: دکمهٔ رزرو -->
        <div class="nav-actions">
            <?php
            // بج مدیریت رزروها — همیشه برای مدیر/سردبیر نمایش داده می‌شود،
            // حتی اگر هنوز رزروی ثبت نشده باشد (شمارنده ۰ است)
            $elnazManageUrl = '';
            $elnazPending = 0;
            if (elnaz_can_manage_bookings()) {
                $elnazPending = elnaz_pending_bookings_count();
                $elnazManageUrl = elnaz_manage_url();
            }
            if ($elnazManageUrl !== ''):
            ?>
            <a href="<?php echo htmlspecialchars($elnazManageUrl, ENT_QUOTES); ?>" class="nav-bookings-badge" title="مدیریت رزروها">
                <?php echo elnaz_icon('calendar-check', 15); ?>
                <span>رزروها</span>
                <span class="badge-count"><?php echo toPersianNumbers($elnazPending); ?></span>
            </a>
            <?php endif; ?>
            <?php
            $elnazCtaText = elnaz_opt('elnazHeroBtn1Text', 'رزرو جلسهٔ رایگان');
            $elnazCtaUrl  = elnaz_opt('elnazHeroBtn1Url', '#booking');
            if (trim($elnazCtaText) !== '' && trim($elnazCtaUrl) !== ''):
            ?>
            <a href="<?php echo htmlspecialchars(elnaz_link_url($elnazCtaUrl, $elnazOnHome), ENT_QUOTES); ?>" class="nav-cta">
                <?php echo elnaz_icon('calendar-check', 16); ?>
                <span><?php echo htmlspecialchars($elnazCtaText, ENT_QUOTES); ?></span>
            </a>
            <?php endif; ?>
            <button type="button" class="menu-toggle" id="menuToggle" aria-label="باز کردن منو" aria-expanded="false" aria-controls="mobileMenu">
                <?php echo elnaz_icon('menu', 22); ?>
            </button>
        </div>
    </div>
</header>

<!-- ---------- منوی موبایل ---------- -->
<div class="mobile-menu" id="mobileMenu" aria-hidden="true">
    <div class="mobile-menu-head">
        <span class="logo-mark" aria-hidden="true"><?php echo elnaz_icon('dumbbell', 20); ?></span>
        <span class="mobile-menu-title"><?php echo htmlspecialchars($elnazClinicName, ENT_QUOTES); ?></span>
        <button type="button" class="mobile-menu-close" id="menuClose" aria-label="بستن منو">
            <?php echo elnaz_icon('x', 20); ?>
        </button>
    </div>
    <nav class="mobile-nav" aria-label="منوی موبایل">
        <?php if ($elnazManageUrl !== ''): ?>
        <a href="<?php echo htmlspecialchars($elnazManageUrl, ENT_QUOTES); ?>" class="mobile-bookings-badge">
            <?php echo elnaz_icon('calendar-check', 18); ?>
            مدیریت رزروها
            <span class="badge-count"><?php echo toPersianNumbers($elnazPending); ?></span>
        </a>
        <?php endif; ?>
        <a href="<?php $this->options->siteUrl(); ?>" <?php if ($elnazOnHome): ?>class="active" aria-current="page"<?php endif; ?>><?php echo elnaz_icon('home', 18); ?> خانه</a>
        <a href="<?php echo htmlspecialchars(elnaz_link_url('#services', $elnazOnHome), ENT_QUOTES); ?>" data-close><?php echo elnaz_icon('dumbbell', 18); ?> خدمات</a>
        <a href="<?php echo htmlspecialchars(elnaz_link_url('#packages', $elnazOnHome), ENT_QUOTES); ?>" data-close><?php echo elnaz_icon('clipboard-list', 18); ?> اشتراک‌ها</a>
        <a href="<?php echo htmlspecialchars(elnaz_link_url('#team', $elnazOnHome), ENT_QUOTES); ?>" data-close><?php echo elnaz_icon('award', 18); ?> مربیان</a>
        <a href="<?php echo htmlspecialchars($elnazOnHome ? '#blog' : $elnazBlogUrl, ENT_QUOTES); ?>" data-close <?php if (!$elnazOnHome && ($elnazIsBlogPage || $this->is('archive') || $this->is('post'))): ?>class="active" aria-current="page"<?php endif; ?>><?php echo elnaz_icon('file-text', 18); ?> مقالات</a>
        <?php
        $elnazNavPagesM = \Widget\Contents\Page\Rows::allocWithAlias('elnazMobile');
        while ($elnazNavPagesM->next()):
            if (elnaz_is_reserve_cid((int)$elnazNavPagesM->cid)) { continue; }
        ?>
            <a href="<?php $elnazNavPagesM->permalink(); ?>"><?php echo elnaz_icon('file-text', 18); ?> <?php echo elnaz_fa_title($elnazNavPagesM); ?></a>
        <?php endwhile; ?>
        <a href="<?php echo htmlspecialchars(elnaz_link_url('#contact', $elnazOnHome), ENT_QUOTES); ?>" data-close class="nav-contact-link"><?php echo elnaz_icon('phone', 18); ?> تماس با ما</a>
    </nav>
    <?php if (trim((string)$elnazCtaUrl) !== '' && trim($elnazCtaText) !== ''): ?>
    <a href="<?php echo htmlspecialchars(elnaz_link_url($elnazCtaUrl, $elnazOnHome), ENT_QUOTES); ?>" class="mobile-cta">
        <?php echo elnaz_icon('calendar-check', 18); ?>
        <?php echo htmlspecialchars($elnazCtaText, ENT_QUOTES); ?>
    </a>
    <?php endif; ?>
    <?php if ($elnazPhone !== null && trim($elnazPhone) !== ''): ?>
    <a href="tel:<?php echo htmlspecialchars(preg_replace('/[^0-9+]/', '', $elnazPhone), ENT_QUOTES); ?>" class="mobile-cta mobile-cta-phone">
        <?php echo elnaz_icon('phone-call', 18); ?>
        <?php echo htmlspecialchars(toPersianNumbers($elnazPhone), ENT_QUOTES); ?>
    </a>
    <?php endif; ?>
</div>
<div class="menu-overlay" id="menuOverlay" aria-hidden="true"></div>

<main id="main" class="site-main">
