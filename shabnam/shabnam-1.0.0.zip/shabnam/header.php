<?php
if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

// اطلاعات هیرو (با تقدم به تنظیمات پوسته؛ در نبود از اطلاعات سایت)
$heroTitle = shabnam_opt('heroTitle');
if ($heroTitle === null || $heroTitle === '') {
    $heroTitle = (string) $this->options->title;
}
$heroDesc  = shabnam_opt('heroDesc');
if ($heroDesc === null || $heroDesc === '') {
    $heroDesc = (string) $this->options->description;
}
$heroBadge = shabnam_opt('heroBadge');
$heroAvatarUrl = shabnam_hero_avatar_url();

// فقط در صفحهٔ نخست نمایش داده شود
try {
    $currentPage = (int) $this->currentPage;
} catch (\Throwable $e) {
    $currentPage = 1;
}
$showHero = $this->is('index') && $currentPage <= 1;

// نحوهٔ نمایش لوگو در ناوبری
$logoMode = shabnam_logo_display_mode();
$siteTitle = (string) $this->options->title;
$logoUrl = trim((string) $this->options->logoUrl);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="<?php echo shabnam_e('#1a1520'); ?>">

    <title><?php
    $this->archiveTitle(
        [
            'category' => _t('دسته‌بندی: %s'),
            'search'   => _t('نتایج جستجو برای: %s'),
            'tag'      => _t('برچسب: %s'),
            'author'   => _t('مطالب نویسنده: %s'),
        ],
        '',
        ' - ',
    );
    $this->options->title();
    ?></title>

    <?php if ($this->options->favicon): ?>
        <link rel="icon" href="<?php echo shabnam_e($this->options->favicon); ?>">
    <?php endif; ?>

    <!-- CSS and Fonts -->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('style.css'); ?>?v=<?php echo shabnam_version(); ?>">

    <?php $this->header(); ?>
</head>
<body class="<?php echo $this->is('index') ? 'page-home' : 'page-inner'; ?>">

<div class="wrapper ss01">

    <header id="header">
        <nav class="main-nav">

            <!-- برند سمت راست (در RTL) — فقط لوگو یا فقط متن یا هر دو -->
            <div class="nav-brand-group">
                <a href="<?php $this->options->siteUrl(); ?>" class="nav-brand" aria-label="<?php echo shabnam_e($siteTitle); ?>">
                    <?php if ($logoMode === 'logo-only' && $logoUrl !== ''): ?>
                        <img src="<?php echo shabnam_e($logoUrl); ?>" alt="<?php echo shabnam_e($siteTitle); ?>" class="nav-brand-logo">
                    <?php elseif ($logoMode === 'both' && $logoUrl !== ''): ?>
                        <img src="<?php echo shabnam_e($logoUrl); ?>" alt="<?php echo shabnam_e($siteTitle); ?>" class="nav-brand-logo">
                        <span class="nav-brand-text"><?php echo shabnam_e($siteTitle); ?></span>
                    <?php else: /* text-only — آیکون پیش‌فرض + متن */ ?>
                        <span class="nav-brand-icon"><?php echo shabnam_default_logo_icon(); ?></span>
                        <span class="nav-brand-text"><?php echo shabnam_e($siteTitle); ?></span>
                    <?php endif; ?>
                </a>
            </div>

            <!-- منوهای اصلی - وسط چین -->
            <div class="nav-menu-center">
                <ul class="menu-links" id="mainMenu">
                    <!-- خانه -->
                    <li class="<?php $this->is('index') ? 'current' : ''; ?>">
                        <a href="<?php $this->options->siteUrl(); ?>"><?php _e('خانه'); ?></a>
                    </li>

                    <?php \Widget\Metas\Category\Rows::allocWithAlias('shabnamNav')->to($navCategories); ?>
                    <?php while ($navCategories->next()): ?>
                        <li class="<?php $this->is('category', $navCategories->slug) ? 'current' : ''; ?>">
                            <a href="<?php $navCategories->permalink(); ?>"><?php $navCategories->name(); ?></a>
                        </li>
                    <?php endwhile; ?>

                    <?php if ($this->options->customMenuLinks): ?>
                        <?php foreach (shabnam_parse_lines($this->options->customMenuLinks, 2) as $linkParts): ?>
                            <li>
                                <a href="<?php echo shabnam_e($linkParts[1]); ?>" rel="noopener noreferrer"><?php echo shabnam_e($linkParts[0]); ?></a>
                            </li>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <?php \Widget\Contents\Page\Rows::alloc()->to($navPages); ?>
                    <?php while ($navPages->next()): ?>
                        <li class="<?php $this->is('page', $navPages->slug) ? 'current' : ''; ?>">
                            <a href="<?php $navPages->permalink(); ?>"><?php $navPages->title(); ?></a>
                        </li>
                    <?php endwhile; ?>
                </ul>
            </div>

            <!-- اکشن‌ها سمت چپ — جستجو + دکمه همبرگری (موبایل) -->
            <div class="nav-actions">
                <button class="search-open-button" aria-label="جستجو">
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                </button>

                <!-- دکمه همبرگری (فقط موبایل) -->
                <button class="menu-toggle" aria-label="باز کردن منو" aria-expanded="false" aria-controls="mainMenu">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>

        </nav>
    </header>

    <?php if ($showHero): ?>
    <div class="site-hero">
        <a href="<?php $this->options->siteUrl(); ?>" class="site-hero-link" aria-label="<?php echo shabnam_e($heroTitle); ?>">
            <span class="site-hero-avatar-wrap">
                <img src="<?php echo shabnam_e($heroAvatarUrl); ?>" alt="<?php echo shabnam_e($heroTitle); ?>" class="site-hero-logo" loading="eager">
            </span>
            <?php if ($heroBadge !== null && $heroBadge !== ''): ?>
                <span class="site-hero-badge"><?php echo shabnam_e($heroBadge); ?></span>
            <?php endif; ?>
            <h1 class="site-hero-title"><?php echo shabnam_e($heroTitle); ?></h1>
            <?php if ($heroDesc !== ''): ?>
                <span class="site-hero-desc"><?php echo shabnam_e($heroDesc); ?></span>
            <?php endif; ?>
        </a>
    </div>
    <?php endif; ?>

    <!-- پوشش پس‌زمینه برای منوی موبایل — خارج از ناوبری تا منو تار نشود -->
    <div class="menu-overlay" aria-hidden="true"></div>

    <div id="fullscreen-search-container" role="dialog" aria-modal="true" aria-label="جستجو در سایت">
        <button class="search-close-button" aria-label="بستن جستجو">&times;</button>
        <form class="search-form" method="get" action="<?php $this->options->siteUrl(); ?>">
            <div class="search-input-wrapper">
                <input type="text" name="s" class="search-input" placeholder="دنبال چی می‌گردی؟" autocomplete="off">
                <button type="submit" class="search-submit-button" aria-label="ارسال جستجو">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                </button>
            </div>
        </form>
    </div>

    <main id="main-content">
    <div class="container">
