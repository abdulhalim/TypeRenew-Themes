<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

// اطلاعات «درباره» برای سایدبار
$aboutName = shabnam_author_name();
$aboutBio = shabnam_opt('aboutBio');
if ($aboutBio === null || $aboutBio === '') {
    $aboutBio = (string) $this->options->description;
}
$aboutAvatar = shabnam_opt('aboutAvatar');
if ($aboutAvatar === null || $aboutAvatar === '') {
    $aboutAvatar = shabnam_default_avatar_url();
} else {
    $aboutAvatar = shabnam_resolve_url($aboutAvatar);
}

$socialLinks = shabnam_social_list();

// بارگذاری داده‌ها برای ویجت‌ها
$sidebarRecentPosts = null;
if (shabnam_sidebar_visible('sidebarRecentPosts')) {
    try {
        $sidebarRecentPosts = \Widget\Contents\Post\Recent::allocWithAlias('shabnamSideRecent', 'pageSize=5');
    } catch (\Throwable $e) {
    }
}

$popularPosts = [];
if (shabnam_sidebar_visible('sidebarPopularPosts')) {
    $popularPosts = shabnam_most_viewed(5);
}

$sidebarComments = null;
if (shabnam_sidebar_visible('sidebarRecentComments')) {
    try {
        $sidebarComments = \Widget\Comments\Recent::allocWithAlias('shabnamSideComments', 'pageSize=5');
    } catch (\Throwable $e) {
    }
}

$sidebarTags = [];
if (shabnam_sidebar_visible('sidebarTags')) {
    try {
        $tagCloud = \Widget\Metas\Tag\Cloud::allocWithAlias('shabnamSideTags', 'ignoreZeroCount=1&limit=12');
        while ($tagCloud->next()) {
            $sidebarTags[] = [
                'name' => (string) $tagCloud->name,
                'permalink' => (string) $tagCloud->permalink,
                'count' => (int) $tagCloud->count,
            ];
        }
    } catch (\Throwable $e) {
    }
}

$friendLinks = [];
if (shabnam_sidebar_visible('sidebarFriendLinks')) {
    try {
        $friendLinks = shabnam_parse_lines($this->options->friendLinks, 2);
    } catch (\Throwable $e) {
    }
}

// پیش‌بارگذاری کاورهای پست‌های پربازدید — اکنون مستقیم از table.fields
// در نسخه‌های قدیمی از روی متن محتوا (regex) می‌گرفتیم که چون thumb در
// table.fields ذخیره می‌شود، همیشه به پیش‌فرض می‌رسید. اکنون درست است.
$popCovers = [];
$popDefault = shabnam_theme_url('assets/img/default.jpg');
if (! empty($popularPosts)) {
    foreach ($popularPosts as $pop) {
        $popCid = (int) $pop['cid'];
        if ($popCid > 0) {
            $popCovers[$popCid] = shabnam_cover_by_cid($popCid, $popDefault);
        }
    }
}

// کاورهای پست‌های اخیر در ویجت «آخرین نوشته‌ها» — داخل حلقه از
// shabnam_cover_by_cid() استفاده می‌کنیم (مستقیم از table.fields)،
// تا بهáte به هر پست تصویر کاور اختصاصی خودش نمایش داده شود.

// آواتار پیش‌فرض برای کامنت‌های نویسنده — هماهنگ با بقیه آواتارها
$authorAvatarForComments = $aboutAvatar;
?>
<aside class="site-sidebar sidebar-v2">

    <?php if (shabnam_sidebar_visible('sidebarAbout')): ?>
    <section class="sidebar-section sidebar-about sidebar-v2-about">
        <div class="sidebar-v2-about-decor" aria-hidden="true"></div>
        <div class="about-avatar-wrap">
            <img src="<?php echo shabnam_e($aboutAvatar); ?>" alt="<?php echo shabnam_e($aboutName); ?>" class="about-avatar" width="96" height="96" loading="lazy">
        </div>
        <h3 class="about-name"><?php echo shabnam_e($aboutName); ?></h3>
        <?php if ($aboutBio !== ''): ?>
            <p class="about-bio"><?php echo nl2br(shabnam_e($aboutBio)); ?></p>
        <?php endif; ?>
        <?php if (! empty($socialLinks)): ?>
            <div class="about-social">
                <?php foreach ($socialLinks as $social): ?>
                    <a href="<?php echo shabnam_e($social['url']); ?>" target="_blank" rel="noopener noreferrer"
                       title="<?php echo shabnam_e($social['title']); ?>" aria-label="<?php echo shabnam_e($social['title']); ?>">
                        <?php echo shabnam_social_icon($social['key']); ?>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
    <?php endif; ?>

    <?php if ($sidebarRecentPosts !== null): ?>
    <section class="sidebar-section sidebar-v2-card sidebar-v2-recent-section">
        <h3 class="sidebar-title sidebar-v2-title">
            <span class="sidebar-v2-title-icon" aria-hidden="true"><?php echo shabnam_icon('clock', 16); ?></span>
            <span class="sidebar-v2-title-text"><?php _e('آخرین نوشته‌ها'); ?></span>
        </h3>
        <ul class="sidebar-list sidebar-v2-list">
            <?php $rpIndex = 0; while ($sidebarRecentPosts->next()): $rpIndex++;
                $rpCid = (int) $sidebarRecentPosts->cid;
                $rpCover = $rpCid > 0 ? shabnam_cover_by_cid($rpCid, $popDefault) : $popDefault;
            ?>
                <li class="sidebar-list-item sidebar-v2-list-item sidebar-v2-recent-item">
                    <span class="sidebar-v2-rank" aria-hidden="true"><?php echo shabnam_fa_num((string) $rpIndex); ?></span>
                    <a href="<?php $sidebarRecentPosts->permalink(); ?>" class="sidebar-list-link sidebar-v2-list-link sidebar-v2-recent-link">
                        <span class="sidebar-v2-recent-thumb" style="background-image: url('<?php echo shabnam_e($rpCover); ?>')" aria-hidden="true"></span>
                        <span class="sidebar-v2-recent-body">
                            <span class="sidebar-list-title"><?php $sidebarRecentPosts->title(); ?></span>
                            <time class="sidebar-list-meta sidebar-v2-list-meta"><?php echo shabnam_date($sidebarRecentPosts->created, 'j F Y'); ?></time>
                        </span>
                    </a>
                </li>
            <?php endwhile; ?>
        </ul>
    </section>
    <?php endif; ?>

    <?php if (! empty($popularPosts)): ?>
    <section class="sidebar-section sidebar-v2-card">
        <h3 class="sidebar-title sidebar-v2-title">
            <span class="sidebar-v2-title-icon" aria-hidden="true"><?php echo shabnam_icon('flame', 16); ?></span>
            <span class="sidebar-v2-title-text"><?php _e('پربازدیدترین نوشته‌ها'); ?></span>
        </h3>
        <ul class="sidebar-list sidebar-v2-list">
            <?php $ppIndex = 0; foreach ($popularPosts as $pop):
                $ppIndex++;
                $popCid = (int) $pop['cid'];
                $popCover = $popCovers[$popCid] ?? $popDefault;
            ?>
                <li class="sidebar-list-item sidebar-list-item-popular sidebar-v2-list-item sidebar-v2-popular">
                    <span class="sidebar-v2-rank sidebar-v2-rank-hot" aria-hidden="true"><?php echo shabnam_fa_num((string) $ppIndex); ?></span>
                    <a href="<?php echo shabnam_e($pop['url']); ?>" class="sidebar-list-link sidebar-popular-link sidebar-v2-popular-link">
                        <span class="sidebar-popular-thumb sidebar-v2-popular-thumb" style="background-image: url('<?php echo shabnam_e($popCover); ?>')" aria-hidden="true"></span>
                        <span class="sidebar-popular-body sidebar-v2-popular-body">
                            <span class="sidebar-list-title"><?php echo shabnam_e($pop['title']); ?></span>
                            <span class="sidebar-list-meta sidebar-views"><?php echo shabnam_icon('eye', 12); ?><?php echo shabnam_fa_num((string) $pop['views']); ?> <?php _e('بازدید'); ?></span>
                        </span>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </section>
    <?php endif; ?>

    <?php if ($sidebarComments !== null): ?>
    <section class="sidebar-section sidebar-v2-card">
        <h3 class="sidebar-title sidebar-v2-title">
            <span class="sidebar-v2-title-icon" aria-hidden="true"><?php echo shabnam_icon('message', 16); ?></span>
            <span class="sidebar-v2-title-text"><?php _e('آخرین دیدگاه‌ها'); ?></span>
        </h3>
        <ul class="sidebar-list sidebar-comments-list sidebar-v2-list">
            <?php while ($sidebarComments->next()):
                $commentExcerpt = shabnam_excerpt($sidebarComments->text, 50);
                $isAuthorComment = shabnam_is_author_comment($sidebarComments);
                // نام نمایشی — اگر دیدگاه از نویسندهٔ پست است و نام نویسنده در پوسته وارد شده، از آن استفاده شود
                $commentAuthor  = shabnam_comment_display_name($sidebarComments);
                $commentMail    = '';
                try {
                    $commentMail = (string) $sidebarComments->mail;
                } catch (\Throwable $e) {
                }
                // برای دیدگاه‌های نویسنده از آواتار نویسنده پوسته استفاده می‌کنیم
                if ($isAuthorComment) {
                    $commentAvatar = $authorAvatarForComments;
                } else {
                    $commentAvatar = shabnam_avatar_url($commentMail, 64);
                }
                $commentUrl     = shabnam_comment_permalink($sidebarComments);
            ?>
                <li class="sidebar-list-item sidebar-comment-item sidebar-v2-list-item sidebar-v2-comment-item">
                    <a href="<?php echo shabnam_e($commentUrl); ?>" class="sidebar-comment-link sidebar-v2-comment-link">
                        <span class="sidebar-comment-avatar sidebar-v2-comment-avatar">
                            <img src="<?php echo shabnam_e($commentAvatar); ?>" alt="<?php echo shabnam_e($commentAuthor); ?>" width="32" height="32" loading="lazy">
                        </span>
                        <span class="sidebar-comment-body sidebar-v2-comment-body">
                            <span class="sidebar-comment-author sidebar-v2-comment-author<?php if ($isAuthorComment) echo ' sidebar-v2-comment-author-owner'; ?>"><?php echo shabnam_e($commentAuthor); ?></span>
                            <span class="sidebar-comment-excerpt"><?php echo shabnam_e($commentExcerpt); ?></span>
                            <time class="sidebar-list-meta sidebar-v2-list-meta"><?php echo shabnam_date($sidebarComments->created, 'j F Y'); ?></time>
                        </span>
                    </a>
                </li>
            <?php endwhile; ?>
        </ul>
    </section>
    <?php endif; ?>

    <?php if (! empty($sidebarTags)): ?>
    <section class="sidebar-section sidebar-v2-card">
        <h3 class="sidebar-title sidebar-v2-title">
            <span class="sidebar-v2-title-icon" aria-hidden="true"><?php echo shabnam_icon('tag', 16); ?></span>
            <span class="sidebar-v2-title-text"><?php _e('برچسب‌ها'); ?></span>
        </h3>
        <div class="sidebar-tags sidebar-v2-tags">
            <?php foreach ($sidebarTags as $tag): ?>
                <a href="<?php echo shabnam_e($tag['permalink']); ?>" class="sidebar-tag sidebar-v2-tag" title="<?php echo shabnam_e($tag['name']); ?>">
                    <span class="sidebar-v2-tag-text"><?php echo shabnam_e($tag['name']); ?></span>
                    <?php if (! empty($tag['count']) && $tag['count'] > 0): ?>
                        <span class="sidebar-v2-tag-count"><?php echo shabnam_fa_num((string) $tag['count']); ?></span>
                    <?php endif; ?>
                </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <?php if (! empty($friendLinks)): ?>
    <section class="sidebar-section sidebar-v2-card">
        <h3 class="sidebar-title sidebar-v2-title">
            <span class="sidebar-v2-title-icon" aria-hidden="true"><?php echo shabnam_icon('link', 16); ?></span>
            <span class="sidebar-v2-title-text"><?php _e('لینک‌های مفید'); ?></span>
        </h3>
        <ul class="sidebar-list sidebar-v2-list sidebar-v2-friend-list">
            <?php foreach ($friendLinks as $link): ?>
                <li class="sidebar-list-item sidebar-v2-list-item sidebar-v2-friend-item">
                    <a href="<?php echo shabnam_e($link[1]); ?>" target="_blank" rel="noopener noreferrer" class="sidebar-list-link sidebar-v2-list-link sidebar-v2-friend-link">
                        <span class="sidebar-v2-friend-dot" aria-hidden="true"></span>
                        <span class="sidebar-list-title"><?php echo shabnam_e($link[0]); ?></span>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </section>
    <?php endif; ?>

</aside>
