<?php
if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
?>
    </div><!-- .container -->
    </main>
    <footer id="footer" class="site-footer" role="contentinfo">
        <div class="container">
            <?php $socialLinks = shabnam_social_list(); ?>
            <?php if (! empty($socialLinks)): ?>
                <section class="footer-social" aria-label="شبکه‌های اجتماعی">
                    <?php foreach ($socialLinks as $social): ?>
                        <a href="<?php echo shabnam_e($social['url']); ?>" target="_blank" rel="noopener noreferrer"
                           title="<?php echo shabnam_e($social['title']); ?>" aria-label="<?php echo shabnam_e($social['title']); ?>">
                            <?php echo shabnam_social_icon($social['key']); ?>
                        </a>
                    <?php endforeach; ?>
                </section>
            <?php endif; ?>

            <div class="footer-divider" aria-hidden="true"></div>

            <section class="footer-row footer-meta">
                <div class="footer-copyright">
                    &copy; <?php echo shabnam_jalali_year(); ?>
                    <span class="footer-dot" aria-hidden="true"></span>
                    <?php _e('طراحی توسط'); ?>
                    <a href="https://pourdaryaei.ir" target="_blank" rel="noopener">پوردریایی</a>
                    <span class="footer-dot" aria-hidden="true"></span>
                    <?php _e('قدرت گرفته از'); ?>
                    <a href="https://typerenew.ir" target="_blank" rel="noopener">تایپ‌رینیو</a>
                </div>
            </section>
        </div>
    </footer>
</div><!-- .wrapper -->

<!-- مودال لایت‌باکس با دکمه‌های ناوبری -->
<div class="simple-lightbox-modal" id="simpleLightboxModal" role="dialog" aria-modal="true" aria-label="نمایش تصویر">
    <span class="simple-lightbox-close" id="simpleLightboxClose" aria-label="بستن">&times;</span>
    <span class="simple-lightbox-prev" id="simpleLightboxPrev" aria-label="تصویر قبلی">&#10094;</span>
    <span class="simple-lightbox-next" id="simpleLightboxNext" aria-label="تصویر بعدی">&#10095;</span>
    <img id="simpleLightboxImg" src="" alt="تصویر بزرگ‌شده">
</div>

<?php $this->footer(); ?>

<script src="<?php $this->options->themeUrl('assets/js/scripts.js'); ?>?v=<?php echo shabnam_version(); ?>"></script>

</body>
</html>
