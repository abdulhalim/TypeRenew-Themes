<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
$this->need('header.php');
?>

<div class="archive-header">
    <h1>
        <?php $this->archiveTitle(
            [
                'category' => _t('دسته‌بندی: %s'),
                'search'   => _t('نتایج جستجو برای: %s'),
                'tag'      => _t('برچسب: %s'),
                'author'   => _t('نویسنده: %s'),
            ],
            '',
            ''
        ); ?>
    </h1>
    <p class="archive-count"><?php echo shabnam_fa_num((string) $this->getTotal()); ?> <?php _e('نوشته'); ?></p>
</div>

<?php if ($this->have()): ?>
    <div class="posts-list">
        <?php while ($this->next()):
            $cover     = shabnam_cover($this);
            $hasCover  = shabnam_has_cover($this);
            $title     = (string) $this->title;
            $permalink = (string) $this->permalink;
            $created   = (int) $this->created;
            $excerpt   = shabnam_excerpt($this->excerpt ?: $this->content, 130);
            $author    = shabnam_card_author_name($this);
            $views     = shabnam_views($this);
            $firstCat  = null;
            try {
                if (! empty($this->categories) && is_array($this->categories)) {
                    $firstCat = $this->categories[0];
                }
            } catch (\Throwable $e) {
            }
        ?>
            <article class="list-card" itemscope itemtype="http://schema.org/BlogPosting">
                <a class="list-card-cover" href="<?php echo shabnam_e($permalink); ?>" aria-hidden="true" tabindex="-1">
                    <?php if ($cover !== ''): ?>
                        <img src="<?php echo shabnam_e($cover); ?>" alt="<?php echo shabnam_e($title); ?>" loading="lazy" itemprop="image">
                    <?php else: ?>
                        <span class="list-card-pattern" aria-hidden="true"></span>
                    <?php endif; ?>
                </a>
                <div class="list-card-body">
                    <div class="list-card-kicker">
                        <?php if ($firstCat): ?>
                            <a class="chip chip-category" href="<?php echo shabnam_e($firstCat['permalink']); ?>"><?php echo shabnam_e($firstCat['name']); ?></a>
                        <?php endif; ?>
                        <time class="list-card-date" datetime="<?php echo date('c', $created); ?>"><?php echo shabnam_date($created, 'j F Y'); ?></time>
                    </div>
                    <h2 class="list-card-title" itemprop="name headline">
                        <a href="<?php echo shabnam_e($permalink); ?>" itemprop="url"><?php echo shabnam_e($title); ?></a>
                    </h2>
                    <?php if ($excerpt !== ''): ?>
                        <p class="list-card-excerpt"><?php echo shabnam_e($excerpt); ?></p>
                    <?php endif; ?>
                    <div class="list-card-meta">
                        <span class="meta-item"><?php echo shabnam_icon('user', 14); ?><?php echo shabnam_e($author); ?></span>
                        <span class="meta-item"><?php echo shabnam_icon('calendar'); ?><?php echo shabnam_date($created, 'j F Y'); ?></span>
                        <?php if ($views > 0): ?>
                            <span class="meta-item meta-views"><?php echo shabnam_icon('eye'); ?><?php echo shabnam_fa_num((string) $views); ?> <?php _e('بازدید'); ?></span>
                        <?php endif; ?>
                    </div>
                    <a class="card-continue-link" href="<?php echo shabnam_e($permalink); ?>">
                        <span><?php _e('ادامه مطلب'); ?></span>
                        <?php echo shabnam_icon('arrow-left', 16); ?>
                    </a>
                </div>
            </article>
        <?php endwhile; ?>
    </div>

    <?php $this->pageNav('&laquo; ' . _t('قبلی'), _t('بعدی') . ' &raquo;'); ?>
<?php else: ?>
    <div class="empty-state">
        <h2><?php _e('مطلبی یافت نشد'); ?></h2>
        <p class="archive-count"><?php _e('هنوز در این بخش نوشته‌ای منتشر نشده است.'); ?></p>
    </div>
<?php endif; ?>

<?php $this->need('footer.php'); ?>
