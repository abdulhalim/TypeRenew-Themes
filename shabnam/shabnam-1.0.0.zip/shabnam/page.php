<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
$this->need('header.php');

// تصویر شاخص: فقط از فیلد thumb
$thumbUrl = '';
try {
    $thumbUrl = trim((string) $this->fields->thumb);
} catch (\Throwable $e) {
}
if ($thumbUrl !== '') {
    $thumbUrl = shabnam_resolve_url($thumbUrl);
}
?>
<article class="post post-page" itemscope itemtype="http://schema.org/BlogPosting">
    <h1 class="post-title"><?php $this->title(); ?></h1>
    <?php if ($thumbUrl !== ''): ?>
        <div class="post-banner">
            <img src="<?php echo shabnam_e($thumbUrl); ?>" alt="<?php $this->title(); ?>" loading="eager">
        </div>
    <?php endif; ?>
    <div class="post-content" itemprop="articleBody">
        <?php $this->content(); ?>
    </div>
</article>

<?php $this->need('comments.php'); ?>

<?php $this->need('footer.php'); ?>
