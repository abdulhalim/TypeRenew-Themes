<?php
/**
 * پوستهٔ شبنم — صفحهٔ اختصاصی «درباره من»
 *
 * @package custom
 * @author  پوردریایی
 * @link    https://pourdaryaei.ir
 */

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');

// خواندن تنظیمات
$aboutName = shabnam_author_name();
$aboutBio = shabnam_opt('aboutBio');
if ($aboutBio === null || $aboutBio === '') {
    $aboutBio = (string) $this->options->description;
}
$aboutAvatar = shabnam_opt('aboutAvatar');
if ($aboutAvatar === null || $aboutAvatar === '') {
    $aboutAvatar = shabnam_default_avatar_url();
} else {
    $aboutAvatar = shabnam_resolve_url($aboutAvatar);
}
$socialLinks       = shabnam_social_list();
$aboutLikes        = shabnam_list_items((string) shabnam_opt('aboutLikes', ''));
$aboutSpecialties  = shabnam_list_items((string) shabnam_opt('aboutSpecialties', ''));
$aboutExperience   = shabnam_list_items((string) shabnam_opt('aboutExperience', ''));
$aboutContact      = trim((string) shabnam_opt('aboutContact', ''));

// محتوای صفحه (در صورت وارد کردن در ویرایشگر برگه)
$pageContent = '';
try {
    ob_start();
    $this->content();
    $pageContent = trim((string) ob_get_clean());
} catch (\Throwable $e) {
    $pageContent = '';
}

// محاسبهٔ آمار سریع از داده‌ها
$statsTotalExperience = 0;
$statsExperienceCount = count($aboutExperience);
foreach ($aboutExperience as $exp) {
    [$num] = shabnam_extract_leading_number($exp);
    if ($num !== null) {
        $maxNum = (int) str_replace(['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'], ['0','1','2','3','4','5','6','7','8','9'], $num);
        if ($maxNum > $statsTotalExperience) {
            $statsTotalExperience = $maxNum;
        }
    }
}
$statsLikesCount = count($aboutLikes);
$statsSkillsCount = count($aboutSpecialties);
?>

<div class="about-page">
    <!-- کارت معرفی -->
    <section class="about-hero">
        <!-- عناصر تزئینی شناور -->
        <span class="about-hero-decor about-hero-decor-1" aria-hidden="true"></span>
        <span class="about-hero-decor about-hero-decor-2" aria-hidden="true"></span>
        <span class="about-hero-decor about-hero-decor-3" aria-hidden="true"></span>

        <div class="about-hero-avatar-wrap">
            <img src="<?php echo shabnam_e($aboutAvatar); ?>" alt="<?php echo shabnam_e($aboutName); ?>" class="about-hero-avatar" width="160" height="160" loading="eager">
        </div>

        <h1 class="about-hero-name"><?php echo shabnam_e($aboutName); ?></h1>

        <?php if ($aboutBio !== ''): ?>
            <p class="about-hero-bio"><?php echo nl2br(shabnam_e($aboutBio)); ?></p>
        <?php endif; ?>

        <?php if (! empty($socialLinks)): ?>
            <div class="about-hero-social">
                <?php foreach ($socialLinks as $social): ?>
                    <a href="<?php echo shabnam_e($social['url']); ?>" target="_blank" rel="noopener noreferrer"
                       class="about-social-link"
                       title="<?php echo shabnam_e($social['title']); ?>"
                       aria-label="<?php echo shabnam_e($social['title']); ?>">
                        <?php echo shabnam_social_icon($social['key']); ?>
                        <span class="about-social-label"><?php echo shabnam_e($social['title']); ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- آمار سریع -->
    <?php if ($statsExperienceCount > 0 || $statsLikesCount > 0 || $statsSkillsCount > 0): ?>
        <section class="about-stats">
            <?php if ($statsExperienceCount > 0): ?>
                <div class="about-stat-item">
                    <span class="about-stat-number"><?php echo shabnam_fa_num((string) $statsExperienceCount); ?></span>
                    <span class="about-stat-label"><?php _e('سابقه و تجربه'); ?></span>
                </div>
            <?php endif; ?>
            <?php if ($statsSkillsCount > 0): ?>
                <div class="about-stat-item">
                    <span class="about-stat-number"><?php echo shabnam_fa_num((string) $statsSkillsCount); ?></span>
                    <span class="about-stat-label"><?php _e('تخصص و مهارت'); ?></span>
                </div>
            <?php endif; ?>
            <?php if ($statsLikesCount > 0): ?>
                <div class="about-stat-item">
                    <span class="about-stat-number"><?php echo shabnam_fa_num((string) $statsLikesCount); ?></span>
                    <span class="about-stat-label"><?php _e('علاقه‌مندی'); ?></span>
                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if (! empty($aboutLikes) || ! empty($aboutSpecialties)): ?>
        <section class="about-tags-row">
            <?php if (! empty($aboutLikes)): ?>
                <div class="about-tag-block about-tag-block-likes">
                    <h3 class="about-tag-title">
                        <span class="about-tag-icon" aria-hidden="true">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                        </span>
                        <?php _e('چیزهایی که دوست دارم'); ?>
                    </h3>
                    <div class="about-tag-list">
                        <?php foreach ($aboutLikes as $item): ?>
                            <span class="about-tag about-tag-likes"><?php echo shabnam_e($item); ?></span>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (! empty($aboutSpecialties)): ?>
                <div class="about-tag-block about-tag-block-specialties">
                    <h3 class="about-tag-title">
                        <span class="about-tag-icon" aria-hidden="true">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        </span>
                        <?php _e('تخصص‌ها و مهارت‌ها'); ?>
                    </h3>
                    <div class="about-tag-list">
                        <?php foreach ($aboutSpecialties as $item): ?>
                            <span class="about-tag about-tag-specialties"><?php echo shabnam_e($item); ?></span>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if (! empty($aboutExperience)): ?>
        <section class="about-experience">
            <h3 class="about-section-title">
                <span class="about-tag-icon" aria-hidden="true">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                </span>
                <?php _e('سوابق و تجربه‌ها'); ?>
            </h3>
            <ul class="about-experience-list">
                <?php foreach ($aboutExperience as $item):
                    [$number, $rest] = shabnam_extract_leading_number($item);
                    $hasNumber = $number !== null;
                ?>
                    <li class="about-exp-item <?php echo $hasNumber ? 'about-exp-has-number' : 'about-exp-no-number'; ?>">
                        <span class="about-exp-badge" aria-hidden="true">
                            <?php if ($hasNumber): ?>
                                <span class="about-exp-number"><?php echo shabnam_e($number); ?></span>
                            <?php else: ?>
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                            <?php endif; ?>
                        </span>
                        <span class="about-exp-text"><?php echo shabnam_e($hasNumber ? $rest : $item); ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    <?php endif; ?>

    <!-- محتوای اختیاری برگه -->
    <?php if ($pageContent !== ''): ?>
        <section class="about-content post-content">
            <?php echo $pageContent; /* محتوای برگه — از ویرایشگر تایپ‌رینیو، امن است */ ?>
        </section>
    <?php endif; ?>

    <?php if ($aboutContact !== ''): ?>
        <section class="about-contact">
            <p><?php echo nl2br(shabnam_e($aboutContact)); ?></p>
        </section>
    <?php endif; ?>
</div>

<?php $this->need('footer.php'); ?>
