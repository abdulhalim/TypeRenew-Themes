<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
$this->need('header.php');

// عبارت جستجو — از درخواست GET یا از ویجت آرشیو
$shabnamSearchTerm = '';
try {
    $shabnamSearchTerm = trim((string) $this->request->get('s'));
} catch (\Throwable $e) {
}
// اگر خالی بود، از keywords ویجت آرشیو بگیر (بعد از redirect به /search/keyword/)
if ($shabnamSearchTerm === '') {
    try {
        $shabnamSearchTerm = trim((string) $this->keywords);
    } catch (\Throwable $e) {
    }
}

// آیا در حالت جستجو هستیم؟
$isSearch = false;
try {
    $isSearch = (bool) $this->is('search');
} catch (\Throwable $e) {
    $isSearch = $shabnamSearchTerm !== '';
}
?>

<div class="search-page">
    <!-- فیلد جستجوی یکپارچه -->
    <form class="shabnam-search-form" method="get" action="<?php $this->options->siteUrl(); ?>">
        <div class="shabnam-search-input-wrapper">
            <span class="shabnam-search-icon" aria-hidden="true">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            </span>
            <input
                type="text"
                name="s"
                class="shabnam-search-input"
                placeholder="<?php _e('دنبال چی می‌گردی؟'); ?>"
                value="<?php echo shabnam_e($shabnamSearchTerm); ?>"
                autocomplete="off"
                required
            >
            <button type="submit" class="shabnam-search-submit" aria-label="<?php _e('جستجو'); ?>">
                <?php _e('جستجو'); ?>
            </button>
        </div>
    </form>

    <?php if ($isSearch): ?>
        <?php if ($this->have()): ?>
            <div class="archive-header">
                <h1><?php _e('نتایج جستجو'); ?></h1>
                <?php if ($shabnamSearchTerm !== ''): ?>
                    <p class="archive-count"><?php echo shabnam_fa_num((string) $this->getTotal()); ?> <?php _e('نوشته'); ?></p>
                <?php endif; ?>
            </div>

            <div class="posts-list">
                <?php while ($this->next()):
                    $cover    = shabnam_cover($this);
                    $hasCover = shabnam_has_cover($this);
                    $title    = (string) $this->title;
                    $permalink = (string) $this->permalink;
                    $created  = (int) $this->created;
                    $excerpt  = shabnam_excerpt($this->excerpt ?: $this->content, 130);
                    $author   = shabnam_card_author_name($this);
                    $views    = shabnam_views($this);
                    $firstCat = null;
                    try {
                        if (! empty($this->categories) && is_array($this->categories)) {
                            $firstCat = $this->categories[0];
                        }
                    } catch (\Throwable $e) {
                    }
                ?>
                    <article class="list-card" itemscope itemtype="http://schema.org/BlogPosting">
                        <a class="list-card-cover" href="<?php echo shabnam_e($permalink); ?>" aria-hidden="true" tabindex="-1">
                            <?php if ($cover !== ''): ?>
                                <img src="<?php echo shabnam_e($cover); ?>" alt="<?php echo shabnam_e($title); ?>" loading="lazy" itemprop="image">
                            <?php else: ?>
                                <span class="list-card-pattern" aria-hidden="true"></span>
                            <?php endif; ?>
                        </a>
                        <div class="list-card-body">
                            <div class="list-card-kicker">
                                <?php if ($firstCat): ?>
                                    <a class="chip chip-category" href="<?php echo shabnam_e($firstCat['permalink']); ?>"><?php echo shabnam_e($firstCat['name']); ?></a>
                                <?php endif; ?>
                                <time class="list-card-date" datetime="<?php echo date('c', $created); ?>"><?php echo shabnam_date($created, 'j F Y'); ?></time>
                            </div>
                            <h2 class="list-card-title" itemprop="name headline">
                                <a href="<?php echo shabnam_e($permalink); ?>" itemprop="url"><?php echo shabnam_e($title); ?></a>
                            </h2>
                            <?php if ($excerpt !== ''): ?>
                                <p class="list-card-excerpt"><?php echo shabnam_e($excerpt); ?></p>
                            <?php endif; ?>
                            <div class="list-card-meta">
                                <span class="meta-item"><?php echo shabnam_icon('user', 14); ?><?php echo shabnam_e($author); ?></span>
                                <span class="meta-item"><?php echo shabnam_icon('calendar'); ?><?php echo shabnam_date($created, 'j F Y'); ?></span>
                                <?php if ($views > 0): ?>
                                    <span class="meta-item meta-views"><?php echo shabnam_icon('eye'); ?><?php echo shabnam_fa_num((string) $views); ?> <?php _e('بازدید'); ?></span>
                                <?php endif; ?>
                            </div>
                            <a class="card-continue-link" href="<?php echo shabnam_e($permalink); ?>">
                                <span><?php _e('ادامه مطلب'); ?></span>
                                <?php echo shabnam_icon('arrow-left', 16); ?>
                            </a>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>

            <?php $this->pageNav('&laquo; ' . _t('قبلی'), _t('بعدی') . ' &raquo;'); ?>
        <?php else: ?>
            <div class="empty-state empty-state-search">
                <div class="empty-ornament" aria-hidden="true">
                    <svg viewBox="0 0 48 48" width="64" height="64" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round">
                        <circle cx="22" cy="22" r="12"/>
                        <line x1="32" y1="32" x2="42" y2="42"/>
                    </svg>
                </div>
                <h2 class="empty-title"><?php _e('جستجوی شما نتیجه‌ای در بر نداشت'); ?></h2>
                <p class="empty-desc"><?php _e('می‌توانید کلمهٔ دیگری را امتحان کنید یا عبارت را دقیق‌تر وارد نمایید.'); ?></p>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="empty-state empty-state-search">
            <div class="empty-ornament" aria-hidden="true">
                <svg viewBox="0 0 48 48" width="64" height="64" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round">
                    <circle cx="22" cy="22" r="12"/>
                    <line x1="32" y1="32" x2="42" y2="42"/>
                </svg>
            </div>
            <h2 class="empty-title"><?php _e('عبارت جستجو را وارد کنید'); ?></h2>
            <p class="empty-desc"><?php _e('برای یافتن مطالب، کلمه یا عبارت مورد نظر خود را در فیلد بالا بنویسید.'); ?></p>
        </div>
    <?php endif; ?>
</div>

<?php $this->need('footer.php'); ?>
