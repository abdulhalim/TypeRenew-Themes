<?php
if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
$this->need('header.php');

// تصویر شاخص: فقط از فیلد thumb
$thumbUrl = '';
try {
    $thumbUrl = trim((string) $this->fields->thumb);
} catch (\Throwable $e) {
}
if ($thumbUrl !== '') {
    $thumbUrl = shabnam_resolve_url($thumbUrl);
}

// آواتار نویسنده — اولویت با تنظیم aboutAvatar پوسته، سپس آواتار محلی/گراواتار
$authorAvatar = '';
$customAuthorAvatar = shabnam_opt('aboutAvatar');
if ($customAuthorAvatar !== null && $customAuthorAvatar !== '') {
    $authorAvatar = shabnam_resolve_url($customAuthorAvatar);
} else {
    $authorMail = '';
    try {
        $authorMail = (string) $this->author->mail;
    } catch (\Throwable $e) {
    }
    $authorAvatar = shabnam_avatar_url($authorMail, 180);
}

// نام نمایشی نویسنده — اولویت با تنظیم پوسته، سپس screenName نویسندهٔ مطلب
$authorDisplayName = shabnam_author_name($this);

// متن معرفی نویسنده — از همان تنظیم aboutBio پوسته که در ویجت نویسنده
// سایدبار و صفحهٔ درباره به‌کار رفته استفاده می‌کنیم، تا همه‌جا یکدست باشد.
// در نبود، از توضیحات نویسندهٔ مطلب استفاده می‌شود.
$authorBio = shabnam_opt('aboutBio');
if ($authorBio === null || $authorBio === '') {
    try {
        $authorBio = trim((string) $this->author->description);
    } catch (\Throwable $e) {
        $authorBio = '';
    }
}
if ($authorBio === '') {
    try {
        $authorBio = trim((string) $this->options->description);
    } catch (\Throwable $e) {
        $authorBio = '';
    }
}

// شبکه‌های اجتماعی نویسنده — همانند ویجت نویسنده و صفحهٔ درباره
$authorSocialLinks = shabnam_social_list();
?>

<div class="post-page-container">
    <div class="post-container">

        <?php if ($thumbUrl !== ''): ?>
            <div class="post-banner">
                <img src="<?php echo shabnam_e($thumbUrl); ?>" alt="<?php $this->title(); ?>" loading="eager">
            </div>
        <?php endif; ?>

        <article class="post-single">
            <div class="post-header">
                <h1 class="post-title"><?php $this->title(); ?></h1>
                <div class="post-meta">
                    <span class="meta-item"><?php echo shabnam_icon('calendar'); ?><?php echo shabnam_date($this->created, 'j F Y'); ?></span>
                    <span class="meta-item meta-views"><?php echo shabnam_icon('eye'); ?><?php echo shabnam_fa_num((string) shabnam_views($this)); ?> <?php _e('بازدید'); ?></span>
                </div>
            </div>

            <div class="post-content">
                <?php
                $content = (string) $this->content;

                // لینک‌هایی که دقیقاً به خودِ تصویر اشاره می‌کنند باز می‌شوند تا لایت‌باکس خودمان بگیردشان؛
                // لینک‌های به صفحات دیگر دست‌نخورده می‌مانند (در پوستهٔ قبلی همهٔ لینک‌ها حذف می‌شدند).
                $content = preg_replace_callback(
                    '/<a([^>]*?)href=["\']([^"\']+)["\']([^>]*)>\s*(<img[^>]+>)\s*<\/a>/iu',
                    function ($m) {
                        $href = $m[2];
                        if (preg_match('/\.(jpe?g|png|gif|webp|avif|svg)(\?|#|$)/iu', $href)) {
                            return $m[4]; // لینکِ تصویر → باز کن تا لایت‌باکس دوباره بگیرد
                        }
                        return $m[0]; // لینکِ صفحه → دست‌نخورده
                    },
                    $content
                );

                // تصاویرِ بدون لینک → لایت‌باکس
                $postTitle = (string) $this->title;
                $content = preg_replace_callback(
                    '/<img((?:(?!data-lightbox)[^>])*)src="([^"]+)"([^>]*)>/iu',
                    function ($m) use ($postTitle) {
                        $imgTag = '<img' . $m[1] . 'src="' . $m[2] . '"' . $m[3] . ' loading="lazy">';
                        return '<a href="' . shabnam_e($m[2]) . '" data-lightbox="post-images" data-title="' . shabnam_e($postTitle) . '" class="lightbox-link">' . $imgTag . '</a>';
                    },
                    $content
                );

                echo $content;
                ?>

                <?php
                $galleryUrlsRaw = '';
                try {
                    $galleryUrlsRaw = trim((string) $this->fields->gallery_urls);
                } catch (\Throwable $e) {
                }
                if ($galleryUrlsRaw !== ''):
                    $imageUrls = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/u', $galleryUrlsRaw)));
                    if (! empty($imageUrls)):
                        $galleryClass = '';
                        try {
                            $galleryClass = trim((string) $this->fields->gallery_style) ?: 'gallery-grid-zoom';
                        } catch (\Throwable $e) {
                        }
                        if ($galleryClass === '') {
                            $galleryClass = 'gallery-grid-zoom';
                        }
                ?>
                        <div class="post-gallery-section">
                            <h3><?php _e('گالری تصاویر'); ?></h3>
                            <div class="custom-gallery <?php echo shabnam_e($galleryClass); ?>">
                                <?php foreach ($imageUrls as $url): ?>
                                    <a href="<?php echo shabnam_e($url); ?>" data-lightbox="post-gallery">
                                        <img src="<?php echo shabnam_e($url); ?>" alt="<?php _e('تصویر گالری'); ?>" loading="lazy">
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>


            </div>

            <div class="post-footer">
                <?php if ($this->tags): ?>
                    <div class="post-tags">
                        <?php $this->tags(' ', true, 'بدون برچسب'); ?>
                    </div>
                <?php endif; ?>

                <div class="post-author-box">
                    <div class="author-avatar">
                        <img src="<?php echo shabnam_e($authorAvatar); ?>" alt="<?php echo shabnam_e($authorDisplayName); ?>" width="90" height="90" loading="lazy">
                    </div>
                    <div class="author-info">
                        <h3><?php echo shabnam_e($authorDisplayName); ?></h3>
                        <?php if ($authorBio !== ''): ?>
                            <p class="author-bio"><?php echo nl2br(shabnam_e($authorBio)); ?></p>
                        <?php elseif (trim((string) $this->author->description) !== ''): ?>
                            <p class="author-bio"><?php $this->author->description(); ?></p>
                        <?php endif; ?>
                        <?php if (! empty($authorSocialLinks)): ?>
                            <div class="author-social">
                                <?php foreach ($authorSocialLinks as $social): ?>
                                    <a href="<?php echo shabnam_e($social['url']); ?>" target="_blank" rel="noopener noreferrer"
                                       class="author-social-link"
                                       title="<?php echo shabnam_e($social['title']); ?>"
                                       aria-label="<?php echo shabnam_e($social['title']); ?>">
                                        <?php echo shabnam_social_icon($social['key']); ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </article>

        <?php $this->need('comments.php'); ?>
    </div>

    <?php $this->need('sidebar.php'); ?>
</div>

<?php $this->need('footer.php'); ?>
