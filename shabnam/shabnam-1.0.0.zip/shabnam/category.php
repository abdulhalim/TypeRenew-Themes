<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
$this->need('header.php');
?>

<div class="archive-header">
    <h1><?php $this->archiveTitle(); ?></h1>
    <p class="archive-count"><?php echo shabnam_fa_num((string) $this->getTotal()); ?> <?php _e('نوشته'); ?></p>
</div>

<?php if ($this->have()): ?>
    <div class="polaroid-grid">
        <?php while ($this->next()):
            $cover     = shabnam_cover($this);
            $hasCover  = shabnam_has_cover($this);
            $title     = (string) $this->title;
            $permalink = (string) $this->permalink;
            $created   = (int) $this->created;
            $excerpt   = shabnam_excerpt($this->excerpt ?: $this->content, 100);
            $author    = shabnam_card_author_name($this);
            $views     = shabnam_views($this);
            $firstCat  = null;
            try {
                if (! empty($this->categories) && is_array($this->categories)) {
                    $firstCat = $this->categories[0];
                }
            } catch (\Throwable $e) {
            }
        ?>
            <article class="polaroid-card" itemscope itemtype="http://schema.org/BlogPosting">
                <a href="<?php echo shabnam_e($permalink); ?>" class="polaroid-image-link" aria-hidden="true" tabindex="-1">
                    <div class="polaroid-image" style="background-image: url('<?php echo shabnam_e($cover); ?>')">
                        <?php if (! $hasCover): ?>
                            <div class="default-image-overlay"></div>
                        <?php endif; ?>
                        <?php if ($firstCat): ?>
                            <span class="polaroid-cat-badge"><?php echo shabnam_e($firstCat['name']); ?></span>
                        <?php endif; ?>
                    </div>
                </a>

                <div class="polaroid-footer">
                    <h2 class="polaroid-title"><a href="<?php echo shabnam_e($permalink); ?>" itemprop="url" itemprop="name headline"><?php echo shabnam_e($title); ?></a></h2>
                    <?php if ($excerpt !== ''): ?>
                        <p class="polaroid-excerpt"><?php echo shabnam_e($excerpt); ?></p>
                    <?php endif; ?>
                    <div class="polaroid-meta">
                        <span class="meta-item"><?php echo shabnam_icon('user', 14); ?><?php echo shabnam_e($author); ?></span>
                        <span class="meta-item"><?php echo shabnam_icon('calendar'); ?><?php echo shabnam_date($created, 'j F Y'); ?></span>
                        <?php if ($views > 0): ?>
                            <span class="meta-item meta-views"><?php echo shabnam_icon('eye'); ?><?php echo shabnam_fa_num((string) $views); ?></span>
                        <?php endif; ?>
                    </div>
                    <a class="card-continue-link card-continue-link-polaroid" href="<?php echo shabnam_e($permalink); ?>">
                        <span><?php _e('ادامه مطلب'); ?></span>
                        <?php echo shabnam_icon('arrow-left', 16); ?>
                    </a>
                </div>
            </article>
        <?php endwhile; ?>
    </div>

    <?php $this->pageNav('&laquo; ' . _t('قبلی'), _t('بعدی') . ' &raquo;'); ?>
<?php else: ?>
    <div class="empty-state">
        <h2><?php _e('مطلبی یافت نشد'); ?></h2>
        <p class="archive-count"><?php _e('هنوز در این دسته نوشته‌ای منتشر نشده است.'); ?></p>
    </div>
<?php endif; ?>

<?php $this->need('footer.php'); ?>
