<?php
if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/** ساخت لینک «@نویسنده» برای پاسخ دیدگاه‌ها */
function shabnam_comment_parent_link($coid)
{
    try {
        $db  = \Typecho\Db::get();
        $row = $db->fetchRow($db->select('author', 'type')->from('table.comments')->where('coid = ?', $coid));
        if (empty($row)) {
            return '';
        }
        // theId = type-coid (مثلاً comment-123) — مطابق با id المان <li>
        $type = (string) ($row['type'] ?? 'comment');
        $anchor = $type . '-' . (int) $coid;
        return '<a href="#' . shabnam_e($anchor) . '" class="comment-parent">@' . shabnam_e($row['author']) . '</a> ';
    } catch (\Throwable $e) {
        return '';
    }
}

/** نشانی آواتار دیدگاه — از shabnam_avatar_url (محلی یا گراواتار بسته به تنظیمات) */
function shabnam_comment_avatar_url($comments): string
{
    $mail = '';
    try {
        $mail = (string) $comments->mail;
    } catch (\Throwable $e) {
    }
    return shabnam_avatar_url($mail, 112);
}

/** نمایش هر دیدگاه (درختی) */
function threadedComments($comments, $options)
{
    $commentClass = '';
    $isAuthorComment = false;
    if ($comments->authorId) {
        if ($comments->authorId == $comments->ownerId) {
            $commentClass .= ' comment-by-author';
            $isAuthorComment = true;
        } else {
            $commentClass .= ' comment-by-user';
        }
    }
    $avatarUrl = shabnam_comment_avatar_url($comments);
    // نام نمایشی — اگر دیدگاه از نویسندهٔ پست است و نام نویسنده در پوسته وارد شده، از آن استفاده شود
    $authorName = shabnam_comment_display_name($comments);
    // اگر دیدگاه از نویسندهٔ پست است، آواتار نویسنده پوسته را به‌نمایش می‌گذاریم
    if ($isAuthorComment) {
        $authorAvatar = shabnam_opt('aboutAvatar');
        if ($authorAvatar !== null && $authorAvatar !== '') {
            $avatarUrl = shabnam_resolve_url($authorAvatar);
        } else {
            $avatarUrl = shabnam_default_avatar_url();
        }
    }
    ?>
    <li id="<?php $comments->theId(); ?>" class="comment-item<?php echo $commentClass; ?>">
        <div class="comment-avatar">
            <img src="<?php echo shabnam_e($avatarUrl); ?>" alt="<?php echo shabnam_e($authorName); ?>" width="56" height="56" loading="lazy">
        </div>
        <div class="comment-body">
            <div class="comment-meta">
                <span class="comment-author<?php if ($isAuthorComment) echo ' comment-author-owner'; ?>">
                    <?php if ($comments->url): ?>
                        <a href="<?php $comments->url(); ?>" rel="nofollow" target="_blank"><?php echo shabnam_e($authorName); ?></a>
                    <?php else: ?>
                        <?php echo shabnam_e($authorName); ?>
                    <?php endif; ?>
                    <?php if ($isAuthorComment): ?>
                        <span class="comment-owner-label"><?php _e('نویسنده'); ?></span>
                    <?php endif; ?>
                </span>
                <div class="comment-meta-side">
                    <span class="comment-date"><?php echo shabnam_date($comments->created, 'H:i — Y/m/d'); ?></span>
                    <span class="comment-reply"><?php $comments->reply(_t('پاسخ')); ?></span>
                </div>
            </div>
            <div class="comment-content">
                <?php if ($comments->parent) {
                    echo shabnam_comment_parent_link($comments->parent);
                } ?>
                <?php $comments->content(); ?>
            </div>
            <?php if ($comments->children): ?>
                <ul class="comment-children">
                    <?php $comments->threadedComments($options); ?>
                </ul>
            <?php endif; ?>
        </div>
    </li>
    <?php
}
?>

<div id="comments">

    <?php $this->comments()->to($comments); ?>
    <?php if ($comments->have()): ?>
        <h3 class="comments-title">
            <?php $this->commentsNum(_t('بدون دیدگاه'), _t('یک دیدگاه'), _t('%s دیدگاه')); ?>
        </h3>
        <ul class="comment-list">
            <?php $comments->listComments(['callback' => 'threadedComments']); ?>
        </ul>
        <nav class="navigation comments-pagination">
            <?php $comments->pageNav(); ?>
        </nav>
    <?php endif; ?>

    <?php if ($this->allow('comment')): ?>
    <div class="respond" id="<?php $this->respondId(); ?>">
        <h3 class="comment-reply-title"><?php _e('ارسال دیدگاه جدید'); ?>
            <small><?php $comments->cancelReply(); ?></small>
        </h3>
        <form method="post" action="<?php $this->commentUrl(); ?>" id="comment-form">
            <?php
            // توکن امنیتی CSRF — مطابق الگوی هستهٔ تایپ‌رینیو
            $security = \Widget\Security::alloc();
            ?>
            <input type="hidden" name="_" value="<?php echo shabnam_e($security->getToken($this->request->getRequestUrl())); ?>">

            <?php if ($this->user->hasLogin()): ?>
                <p class="comment-logged-in">
                    <?php _e('شما با حساب کاربری'); ?>
                    <a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a>
                    <?php _e('وارد شده‌اید.'); ?>
                    <a href="<?php $this->options->logoutUrl(); ?>" title="خروج"><?php _e('[خروج]'); ?></a>
                </p>
            <?php else: ?>
                <div class="comment-fields-row">
                    <div>
                        <label for="author"><?php _e('نام'); ?><span class="required">*</span></label>
                        <input type="text" name="author" id="author" value="<?php $this->remember('author'); ?>" required autocomplete="name">
                    </div>
                    <div>
                        <label for="mail"><?php _e('ایمیل'); ?><span class="required">*</span></label>
                        <input type="email" name="mail" id="mail" value="<?php $this->remember('mail'); ?>" required autocomplete="email">
                    </div>
                    <div>
                        <label for="url"><?php _e('وب‌سایت'); ?></label>
                        <input type="url" name="url" id="url" value="<?php $this->remember('url'); ?>" autocomplete="url">
                    </div>
                </div>
            <?php endif; ?>
            <div class="comment-textarea-row">
                <label for="textarea"><?php _e('متن دیدگاه'); ?><span class="required">*</span></label>
                <textarea name="text" id="textarea" rows="4" required><?php $this->remember('text'); ?></textarea>
            </div>
            <button type="submit" class="submit" id="misubmit"><?php _e('ارسال دیدگاه'); ?></button>
        </form>
    </div>
    <?php else: ?>
        <p class="comments-closed"><?php _e('بخش دیدگاه‌ها برای این نوشته بسته است.'); ?></p>
    <?php endif; ?>

</div>
