<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
$this->need('header.php');
?>

<div class="error-page-container">
    <div class="error-code" aria-hidden="true">۴۰۴</div>
    <h1 class="error-message">
        <?php _e('صفحه‌ مورد نظر پیدا نشد!'); ?>
    </h1>
    <p class="error-hint">
        <?php _e('آدرس واردشده وجود ندارد یا به مکان دیگری منتقل شده است.'); ?>
        <?php _e('می‌توانید به صفحهٔ اصلی بازگردید یا در سایت جستجو کنید.'); ?>
    </p>
    <div class="error-actions">
        <a href="<?php $this->options->siteUrl(); ?>" class="error-home-link">
            <?php echo shabnam_icon('home'); ?>
            <?php _e('بازگشت به صفحهٔ اصلی'); ?>
        </a>
        <button type="button" class="error-search-link" id="errorOpenSearch">
            <?php echo shabnam_icon('search'); ?>
            <?php _e('جستجو در سایت'); ?>
        </button>
    </div>
</div>

<?php $this->need('footer.php'); ?>
