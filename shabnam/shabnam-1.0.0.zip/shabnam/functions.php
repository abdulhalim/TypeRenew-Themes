<?php

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

/* ================================================================
 *  ۱) تنظیمات پوسته
 * ================================================================ */

/**
 * خواندن تنظیمات پوسته با مقدار پیش‌فرض
 */
function shabnam_opt(string $name, ?string $default = null): ?string
{
    try {
        $value = \Widget\Options::alloc()->{$name};
        return ($value === null || $value === '') ? $default : (string) $value;
    } catch (\Throwable $e) {
        return $default;
    }
}

/**
 * نشانی پوسته — روش امن و بدون وابستگی به $widget->options
 */
function shabnam_theme_url(string $relative = ''): string
{
    static $cached = null;
    if ($cached === null) {
        try {
            $cached = rtrim((string) \Widget\Options::alloc()->themeUrl, '/');
        } catch (\Throwable $e) {
            $cached = '';
        }
    }
    return $cached . ($relative !== '' ? '/' . ltrim($relative, '/') : '');
}

/**
 * نشانی سایت
 */
function shabnam_site_url(): string
{
    try {
        return rtrim((string) \Widget\Options::alloc()->siteUrl, '/');
    } catch (\Throwable $e) {
        return '';
    }
}

/**
 * فیلدهای صفحهٔ «پیکربندی پوستهٔ جاری»
 *
 * @param \Typecho\Widget\Helper\Form $form
 */
function themeConfig(\Typecho\Widget\Helper\Form $form)
{
    /* --- هویت ناوبری --- */

    $logoUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'logoUrl',
        null,
        null,
        _t('آدرس لوگوی ناوبری'),
        _t('نشانی کامل فایل لوگوی سایت برای نوار ناوبری (PNG/SVG). در صورت خالی بودن، فقط عنوان سایت نمایش داده می‌شود.')
    );
    $form->addInput($logoUrl);

    $logoDisplayMode = new \Typecho\Widget\Helper\Form\Element\Select(
        'logoDisplayMode',
        [
            'auto'       => _t('خودکار (اگر لوگو هست، لوگو + عنوان؛ اگر نیست، فقط عنوان)'),
            'logo-only'  => _t('فقط لوگو (بدون عنوان سایت)'),
            'text-only'  => _t('فقط عنوان سایت (بدون لوگو)'),
            'both'       => _t('هم لوگو و هم عنوان سایت'),
        ],
        'auto',
        _t('نحوه نمایش لوگو و عنوان سایت در نوار ناوبری'),
        _t('در حالت «خودکار»، اگر لوگو تنظیم شده باشد فقط لوگو نمایش داده می‌شود و در غیر این صورت عنوان سایت. می‌توانید صراحتاً انتخاب کنید کدام یک نمایش داده شود.')
    );
    $form->addInput($logoDisplayMode);

    $favicon = new \Typecho\Widget\Helper\Form\Element\Text(
        'favicon',
        null,
        null,
        _t('آدرس فاویکون'),
        _t('نشانی فایل فاویکون سایت (.ico یا .png یا .svg). اگر خالی باشد از فاویکون پیش‌فرض تایپ‌رینیو استفاده می‌شود.')
    );
    $form->addInput($favicon);

    /* --- منبع آواتار --- */

    $avatarSource = new \Typecho\Widget\Helper\Form\Element\Select(
        'avatarSource',
        [
            'local'    => _t('آواتار محلی پیش‌فرض (avatar.webp) — همه‌جا'),
            'gravatar' => _t('گراواتار با fallback به آواتار محلی'),
        ],
        'local',
        _t('منبع آواتار کاربران و نویسندگان'),
        _t('در حالت «محلی»، از avatar.webp پوسته برای همه استفاده می‌شود (لیست کامنت‌ها، ویجت کامنت‌ها، باکس نویسنده، ویجت نویسنده و غیره). در حالت «گراواتار»، ابتدا گراواتار بررسی می‌شود و در نبود، آواتار محلی نمایش داده می‌شود.')
    );
    $form->addInput($avatarSource);

    /* --- هیرو (بنر اصلی بالای صفحه نخست) --- */

    $heroAvatarUrl = new \Typecho\Widget\Helper\Form\Element\Text(
        'heroAvatarUrl',
        null,
        null,
        _t('آواتار هیرو'),
        _t('نشانی تصویر آواتار نویسنده/وبلاگ برای بنر هیرو. در صورت خالی بودن، آواتار پیش‌فرض پوسته (avatar.webp) به کار می‌رود. این تصویر با لوگوی ناوبری متفاوت است.')
    );
    $form->addInput($heroAvatarUrl);

    $heroTitle = new \Typecho\Widget\Helper\Form\Element\Text(
        'heroTitle',
        null,
        null,
        _t('عنوان هیرو'),
        _t('عنوان بنر هیرو در بالای صفحه نخست. در صورت خالی بودن از عنوان سایت استفاده می‌شود.')
    );
    $form->addInput($heroTitle);

    $heroDesc = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'heroDesc',
        null,
        null,
        _t('توضیحات هیرو'),
        _t('متن کوتاه معرفی زیر عنوان هیرو. در صورت خالی بودن از توضیحات سایت استفاده می‌شود.')
    );
    $form->addInput($heroDesc);

    $heroBadge = new \Typecho\Widget\Helper\Form\Element\Text(
        'heroBadge',
        null,
        null,
        _t('نشان هیرو (اختیاری)'),
        _t('متن کوتاه یک‌خطی بالای عنوان هیرو، مثلاً «وبلاگ شخصی». اختیاری است.')
    );
    $form->addInput($heroBadge);

    /* --- چیدمان صفحه نخست --- */

    $homeLayout = new \Typecho\Widget\Helper\Form\Element\Select(
        'homeLayout',
        [
            'grid'  => _t('شبکه‌ای (کارت‌های پولاروید)'),
            'list'  => _t('لیستی (تصویر کنار متن)'),
            'hero-grid' => _t('هیرو + گرید (تازه‌ترین پست بزرگ، بقیه گرید)'),
            'hero-list' => _t('هیرو + لیست (تازه‌ترین پست بزرگ، بقیه لیست)'),
        ],
        'hero-grid',
        _t('چیدمان صفحه نخست'),
        _t('نحوه نمایش پست‌ها در صفحه اصلی را انتخاب کنید.')
    );
    $form->addInput($homeLayout);

    /* --- لینک‌های سفارشی --- */

    $customLinks = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'customMenuLinks',
        null,
        null,
        _t('لینک‌های سفارشی منو'),
        _t('هر خط یک لینک به فرمت «عنوان|نشانی». این لینک‌ها پیش از صفحات، در منوی اصلی نمایش داده می‌شوند.')
    );
    $form->addInput($customLinks);

    $friendLinks = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'friendLinks',
        null,
        "تایپ‌رینیو|https://typerenew.ir\nپوردریایی|https://pourdaryaei.ir",
        _t('لینک‌های مفید (نوار کناری)'),
        _t('هر خط یک لینک به فرمت «عنوان|نشانی». این لینک‌ها در بخش «لینک‌های مفید» نوار کناری نمایش داده می‌شوند.')
    );
    $form->addInput($friendLinks);

    /* --- شبکه‌های اجتماعی (فیلدهای مجزا) --- */

    $socialInstagram = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialInstagram',
        null,
        null,
        _t('نام کاربری اینستاگرام'),
        _t('فقط نام کاربری اینستاگرام را وارد کنید. مثال: pourdaryaei')
    );
    $form->addInput($socialInstagram);

    $socialTelegram = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialTelegram',
        null,
        null,
        _t('نام کاربری تلگرام'),
        _t('فقط نام کاربری تلگرام را وارد کنید. مثال: pourdaryaei')
    );
    $form->addInput($socialTelegram);

    $socialGithub = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialGithub',
        null,
        null,
        _t('نام کاربری گیت‌هاب'),
        _t('فقط نام کاربری گیت‌هاب را وارد کنید. مثال: pourdaryaei')
    );
    $form->addInput($socialGithub);

    $socialYoutube = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialYoutube',
        null,
        null,
        _t('نام کاربری یا آدرس یوتیوب'),
        _t('نام کاربری یا آدرس کانال یوتیوب. مثال: @channel یا https://youtube.com/@channel')
    );
    $form->addInput($socialYoutube);

    $socialLinkedin = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialLinkedin',
        null,
        null,
        _t('نام کاربری لینکدین'),
        _t('فقط نام کاربری لینکدین را وارد کنید. مثال: pourdaryaei')
    );
    $form->addInput($socialLinkedin);

    $socialTwitter = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialTwitter',
        null,
        null,
        _t('نام کاربری توییتر'),
        _t('فقط نام کاربری توییتر را وارد کنید. مثال: pourdaryaei')
    );
    $form->addInput($socialTwitter);

    $socialWhatsapp = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialWhatsapp',
        null,
        null,
        _t('شماره واتساپ'),
        _t('شماره واتساپ با کد کشور، بدون +. مثال: 989123456789')
    );
    $form->addInput($socialWhatsapp);

    $socialEmail = new \Typecho\Widget\Helper\Form\Element\Text(
        'socialEmail',
        null,
        null,
        _t('ایمیل تماس'),
        _t('نشانی ایمیل تماس. مثال: hi@example.com')
    );
    $form->addInput($socialEmail);

    $socialRss = new \Typecho\Widget\Helper\Form\Element\Radio(
        'socialRss',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('آیکون RSS'),
        _t('نمایش یا مخفی کردن آیکون آر-اس-اس در فوتر.')
    );
    $form->addInput($socialRss);

    /* --- نویسنده وبلاگ (نام نمایشی پیش‌فرض برای باکس نویسنده، دیدگاه‌ها و صفحهٔ درباره) --- */

    $authorName = new \Typecho\Widget\Helper\Form\Element\Text(
        'authorName',
        null,
        null,
        _t('نام نویسنده وبلاگ'),
        _t('نام نمایشی نویسنده وبلاگ. در باکس نویسنده، لیست دیدگاه‌ها و صفحهٔ «درباره من» استفاده می‌شود. در صورت خالی بودن از نام مستعار نویسندهٔ مطلب یا نام صفحهٔ «درباره من» استفاده می‌شود.')
    );
    $form->addInput($authorName);

    /* --- متن «درباره من» (صفحه about.php) --- */

    $aboutName = new \Typecho\Widget\Helper\Form\Element\Text(
        'aboutName',
        null,
        null,
        _t('نام برای صفحهٔ «درباره من»'),
        _t('نام نمایشی در صفحهٔ «درباره من». در صورت خالی بودن از «نام نویسنده وبلاگ» یا عنوان سایت استفاده می‌شود.')
    );
    $form->addInput($aboutName);

    $aboutBio = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'aboutBio',
        null,
        null,
        _t('معرفی کوتاه (درباره من)'),
        _t('چند جمله دربارهٔ خودتان برای صفحهٔ «درباره من».')
    );
    $form->addInput($aboutBio);

    $aboutAvatar = new \Typecho\Widget\Helper\Form\Element\Text(
        'aboutAvatar',
        null,
        null,
        _t('آواتار صفحهٔ «درباره من»'),
        _t('نشانی تصویر پروفایل صفحهٔ درباره من. در صورت خالی بودن از آواتار پیش‌فرض پوسته استفاده می‌شود.')
    );
    $form->addInput($aboutAvatar);

    $aboutLikes = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'aboutLikes',
        null,
        null,
        _t('چیزهایی که دوست دارم'),
        _t('هر مورد را در یک خط جداگانه وارد کنید. مثال: عکاسی، موسیقی، کوهنوردی. در صفحهٔ «درباره من» به‌صورت تگ نمایش داده می‌شوند.')
    );
    $form->addInput($aboutLikes);

    $aboutSpecialties = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'aboutSpecialties',
        null,
        null,
        _t('تخصص‌ها و مهارت‌ها'),
        _t('هر تخصص را در یک خط جداگانه وارد کنید. مثال: توسعهٔ PHP، طراحی رابط کاربری، مدیریت سرور. در صفحهٔ «درباره من» به‌صورت تگ نمایش داده می‌شوند.')
    );
    $form->addInput($aboutSpecialties);

    $aboutExperience = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'aboutExperience',
        null,
        null,
        _t('سوابق و تجربه‌ها'),
        _t('هر سابقه را در یک خط جداگانه وارد کنید. مثال: ۵ سال تجربهٔ توسعهٔ وب، بنیان‌گذار پروژهٔ X. در صفحهٔ «درباره من» به‌صورت لیست نمایش داده می‌شود.')
    );
    $form->addInput($aboutExperience);

    $aboutContact = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'aboutContact',
        null,
        null,
        _t('متن تماس (اختیاری)'),
        _t('متن کوتاهی که در پایین صفحهٔ «درباره من» نمایش داده می‌شود؛ مثلاً «برای همکاری با من در ارتباط باشید.»')
    );
    $form->addInput($aboutContact);

    /* --- ویجت‌های سایدبار (فعال/غیرفعال) --- */

    $sidebarAbout = new \Typecho\Widget\Helper\Form\Element\Radio(
        'sidebarAbout',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('سایدبار: باکس درباره'),
        _t('نمایش یا مخفی کردن باکس «درباره» در بالای سایدبار.')
    );
    $form->addInput($sidebarAbout);

    $sidebarRecentPosts = new \Typecho\Widget\Helper\Form\Element\Radio(
        'sidebarRecentPosts',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('سایدبار: آخرین نوشته‌ها'),
        _t('نمایش یا مخفی کردن بخش «آخرین نوشته‌ها» در سایدبار.')
    );
    $form->addInput($sidebarRecentPosts);

    $sidebarPopularPosts = new \Typecho\Widget\Helper\Form\Element\Radio(
        'sidebarPopularPosts',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('سایدبار: پربازدیدترین نوشته‌ها'),
        _t('نمایش یا مخفی کردن بخش «پربازدیدترین نوشته‌ها» در سایدبار.')
    );
    $form->addInput($sidebarPopularPosts);

    $sidebarRecentComments = new \Typecho\Widget\Helper\Form\Element\Radio(
        'sidebarRecentComments',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('سایدبار: آخرین دیدگاه‌ها'),
        _t('نمایش یا مخفی کردن بخش «آخرین دیدگاه‌ها» در سایدبار.')
    );
    $form->addInput($sidebarRecentComments);

    $sidebarTags = new \Typecho\Widget\Helper\Form\Element\Radio(
        'sidebarTags',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('سایدبار: برچسب‌ها'),
        _t('نمایش یا مخفی کردن بخش «برچسب‌ها» در سایدبار.')
    );
    $form->addInput($sidebarTags);

    $sidebarFriendLinks = new \Typecho\Widget\Helper\Form\Element\Radio(
        'sidebarFriendLinks',
        ['1' => _t('نمایش'), '0' => _t('مخفی')],
        '1',
        _t('سایدبار: لینک‌های مفید'),
        _t('نمایش یا مخفی کردن بخش «لینک‌های مفید» در سایدبار.')
    );
    $form->addInput($sidebarFriendLinks);
}

/**
 * فیلدهای سفارشی ویرایشگر نوشته/برگه
 *
 * @param \Typecho\Widget\Helper\Layout $layout
 */
function themeFields($layout)
{
    $thumb = new \Typecho\Widget\Helper\Form\Element\Text(
        'thumb',
        null,
        null,
        _t('تصویر شاخص'),
        _t('نشانی کامل تصویر شاخص این نوشته (در کارت‌های فهرست و ابتدای صفحهٔ نوشته نمایش داده می‌شود). اگر خالی بماند، اولین تصویر متن به‌طور خودکار استفاده می‌شود.')
    );
    $layout->addItem($thumb);

    $gallery_urls = new \Typecho\Widget\Helper\Form\Element\Textarea(
        'gallery_urls',
        null,
        null,
        _t('لینک‌های گالری تصاویر'),
        _t('هر نشانی تصویر را در یک خط جداگانه وارد کنید. این تصاویر به‌صورت گالری نمایش داده می‌شوند.')
    );
    $layout->addItem($gallery_urls);

    $gallery_style = new \Typecho\Widget\Helper\Form\Element\Select(
        'gallery_style',
        [
            'gallery-grid-zoom'  => _t('گرید با انیمیشن زوم'),
            'gallery-grid-fade'  => _t('گرید با روکش محو شونده'),
            'gallery-grid-slide' => _t('گرید با روکش متحرک'),
            'gallery-grid-focus' => _t('گرید با افکت فوکوس و تاری'),
        ],
        'gallery-grid-zoom',
        _t('استایل نمایش گالری'),
        _t('یکی از ۴ مدل گرید با انیمیشن‌های مختلف را انتخاب کنید.')
    );
    $layout->addItem($gallery_style);
}

/* ================================================================
 *  ۲) ابزار عمومی
 * ================================================================ */

/** فرار امن کاراکترهای ویژهٔ HTML */
function shabnam_e($text): string
{
    return htmlspecialchars((string) $text, ENT_QUOTES, 'UTF-8');
}

/** تبدیل ارقام لاتین به فارسی */
function shabnam_fa_num($value): string
{
    $en = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    $fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return str_replace($en, $fa, (string) $value);
}

/** نرمال‌سازی نشانی نسبی به مطلق */
function shabnam_resolve_url(string $url): string
{
    $url = trim($url);
    if ($url === '') {
        return '';
    }
    if (preg_match('#^(data:|https?://|//|mailto:|tel:)#i', $url)) {
        return $url;
    }
    if ($url === '/feed/' || $url === 'feed/') {
        return shabnam_site_url() . '/feed/';
    }
    return shabnam_site_url() . '/' . ltrim($url, '/');
}

/** استخراج نشانی اولین تصویر از محتوای HTML/مارک‌داون */
function shabnam_first_image($content): string
{
    $content = (string) $content;
    if (preg_match('#<img[^>]*\bsrc=["\']([^"\']+)["\']#iu', $content, $m)) {
        return $m[1];
    }
    // پشتیبان مارک‌داون: ![alt](url)
    if (preg_match('#!\[[^\]]*\]\(\s*<?([^)\s>]+)[^)]*\)#iu', $content, $m)) {
        return $m[1];
    }
    return '';
}

/**
 * نشانی تصویر روی جلد یک محتوا.
 *
 * اولویت: ۱) فیلد thumb  →  ۲) اولین تصویر محتوا  →  ۳) پیش‌فرض پوسته
 *
 * این تابع از \Widget\Options::alloc() مستقیماً استفاده می‌کند تا
 * حتی در مواردی که $widget->options برابر null است (مانند ویجت Recent Posts
 * داخل سایدبار) کار کند و خطای "Attempt to read property themeUrl on null"
 * رخ ندهد.
 *
 * @param \Typecho\Widget $widget ویجت محتوا (نوشته/برگه)
 */
function shabnam_cover($widget, string $defaultUrl = ''): string
{
    // ۱) فیلد thumb (تقدم اصلی)
    $thumb = '';
    try {
        $thumb = trim((string) $widget->fields->thumb);
    } catch (\Throwable $e) {
    }
    if ($thumb !== '') {
        return shabnam_resolve_url($thumb);
    }

    // ۲) اولین تصویر محتوا
    $first = '';
    try {
        $first = shabnam_first_image($widget->content);
    } catch (\Throwable $e) {
    }
    if ($first !== '') {
        return shabnam_resolve_url($first);
    }

    // ۳) پیش‌فرض پوسته — از shabnam_theme_url() استفاده می‌کنیم
    if ($defaultUrl === '') {
        $defaultUrl = shabnam_theme_url('assets/img/default.jpg');
    }
    return $defaultUrl;
}

/** آیا محتوا تصویر اختصاصی (thumb یا تصویر درون محتوا) دارد؟ */
function shabnam_has_cover($widget): bool
{
    $val = '';
    try {
        $val = trim((string) $widget->fields->thumb);
    } catch (\Throwable $e) {
    }
    if ($val !== '') {
        return true;
    }
    try {
        return shabnam_first_image($widget->content) !== '';
    } catch (\Throwable $e) {
        return false;
    }
}

/** مختصر امن متن برای چکیده */
function shabnam_excerpt($content, int $length = 90): string
{
    $text = trim(strip_tags((string) $content));
    if (function_exists('mb_substr')) {
        return mb_substr($text, 0, $length, 'UTF-8') . (mb_strlen($text, 'UTF-8') > $length ? '…' : '');
    }
    return substr($text, 0, $length);
}

/** پارس خطوط «الف | ب» — خروجی: آرایهٔ [تک‌مقدارها] */
function shabnam_parse_lines($text, int $minParts = 1): array
{
    $out = [];
    foreach (preg_split('/\r\n|\r|\n/u', (string) $text) as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        $parts = array_map('trim', preg_split('/\s*\|\s*/u', $line));
        while (count($parts) > 0 && $parts[count($parts) - 1] === '') {
            array_pop($parts);
        }
        if (count($parts) >= $minParts) {
            $out[] = $minParts === 1 ? $parts[0] : $parts;
        }
    }
    return $out;
}

/**
 * پارس فهرست ساده (هر خط یک مورد).
 *
 * مفید برای فیلدهایی مثل «علاقه‌مندی‌ها» و «تخصص‌ها» که فقط یک مقدار در هر خط دارند.
 * کاراکترهای - و * و • و شماره‌گذاری در ابتدای خط حذف می‌شوند.
 */
function shabnam_list_items($text): array
{
    $out = [];
    foreach (preg_split('/\r\n|\r|\n/u', (string) $text) as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        // حذف پیشوندهای رایج: - * • یا عدد + نقطه/پرانتز
        $line = preg_replace('/^[-*•·▪►»]\s+/u', '', $line);
        $line = preg_replace('/^\d+[.)-]\s+/u', '', $line);
        $line = trim($line);
        if ($line !== '') {
            $out[] = $line;
        }
    }
    return $out;
}

/**
 * استخراج عدد ابتدای یک رشته (مثلاً "10 سال تجربه" → [10, "سال تجربه"]).
 *
 * @return array{0: string|null, 1: string} — [عدد فارسی|null, بقیه متن]
 */
function shabnam_extract_leading_number(string $text): array
{
    if (preg_match('/^(\d+)\s*(.*)$/u', $text, $m)) {
        return [shabnam_fa_num($m[1]), trim($m[2])];
    }
    return [null, $text];
}

/**
 * نشانی کامل دیدگاه: نشانی پست + #comment-{coid}
 *
 * ویجت‌هایی مثل Recent Comments گاهی فقط نشانی پست را برمی‌گردانند
 * و لنگر دیدگاه را شامل نمی‌شوند. این تابع لنگر را اضافه می‌کند.
 *
 * @param \Typecho\Widget $commentWidget ویجت دیدگاه
 */
function shabnam_comment_permalink($commentWidget): string
{
    $url  = '';
    $coid = '';
    $theId = '';

    try {
        $url    = (string) $commentWidget->permalink;
        $coid   = (string) $commentWidget->coid;
        $theId  = (string) $commentWidget->theId;
    } catch (\Throwable $e) {
    }

    // اگر لنگر از قبل موجود بود (TypeRenew خودش permalink را با #theId می‌دهد)، همان را برگردان
    if (strpos($url, '#') !== false) {
        return $url;
    }

    // اگر نشانی پست داشتیم و coid، لنگر را اضافه کن
    // theId معمولاً comment-{coid} است؛ اگر داشتیم از همان استفاده می‌کنیم
    if ($url !== '' && $coid !== '') {
        $anchor = $theId !== '' ? $theId : ('comment-' . $coid);
        return $url . '#' . $anchor;
    }

    // fallback: اگر هیچ‌کدام نبود، حداقل نشانی سایت را برگردان
    if ($url === '') {
        return shabnam_site_url();
    }
    return $url;
}

/** نسخهٔ فعلی پوسته — برای کش‌باستینگ دارایی‌ها */
function shabnam_version(): string
{
    return '1.6.2';
}

/* ================================================================
 *  ۲-ب) آواتار پیش‌فرض و شبکه‌های اجتماعی
 * ================================================================ */

/**
 * نشانی آواتار پیش‌فرض پوسته (avatar.webp).
 * اولویت اول همه‌جا از این آواتار استفاده می‌شود.
 */
function shabnam_default_avatar_url(): string
{
    return shabnam_theme_url('assets/img/avatar.webp');
}

/**
 * نشانی آواتار برای یک کاربر/دیدگاه.
 *
 * بسته به تنظیم `avatarSource` پوسته:
 *   - 'local' (پیش‌فرض): همیشه آواتار محلی avatar.webp
 *   - 'gravatar': گاواتار با fallback به آواتار محلی
 *
 * @param string|null $mail ایمیل کاربر/دیدگاه (برای گراواتار)
 * @param int $size اندازهٔ تصویر مورد نظر (پیکسل)
 */
function shabnam_avatar_url(?string $mail = null, int $size = 80): string
{
    $default = shabnam_default_avatar_url();
    $source  = (string) shabnam_opt('avatarSource', 'local');

    if ($source === 'gravatar' && $mail !== null && $mail !== '') {
        $hash = md5(strtolower(trim($mail)));
        return 'https://www.gravatar.com/avatar/' . $hash . '?s=' . $size . '&d=' . rawurlencode($default);
    }

    return $default;
}

/**
 * نشانی آواتار هیرو: تنظیمات پوسته (heroAvatarUrl) → آواتار پیش‌فرض.
 * با لوگوی ناوبری (logoUrl) متفاوت است.
 */
function shabnam_hero_avatar_url(): string
{
    $custom = shabnam_opt('heroAvatarUrl');
    if ($custom !== null && $custom !== '') {
        return shabnam_resolve_url($custom);
    }
    return shabnam_default_avatar_url();
}

/**
 * تشخیص نحوهٔ نمایش لوگو/عنوان در نوار ناوبری.
 *
 * خروجی یکی از این مقادیر است:
 *   - 'logo-only' : فقط لوگو
 *   - 'text-only' : فقط متن عنوان سایت
 *   - 'both'      : لوگو + متن عنوان
 *   - 'none'      : هیچ‌کدام (مثلاً اگر تنظیم خاصی خواسته شده باشد و هر دو خالی باشند)
 *
 * حالت پیش‌فرض 'auto' معادل این است:
 *   - اگر logoUrl پر باشد → 'logo-only'
 *   - اگر logoUrl خالی باشد → 'text-only'
 */
function shabnam_logo_display_mode(): string
{
    $mode   = (string) shabnam_opt('logoDisplayMode', 'auto');
    $logo   = trim((string) shabnam_opt('logoUrl', ''));
    $title  = trim((string) shabnam_opt('siteTitle', ''));
    // خواندن عنوان سایت واقعی
    try {
        $title = trim((string) \Widget\Options::alloc()->title);
    } catch (\Throwable $e) {
    }

    if ($mode === 'logo-only') {
        return $logo !== '' ? 'logo-only' : 'text-only';
    }
    if ($mode === 'text-only') {
        return 'text-only';
    }
    if ($mode === 'both') {
        return $logo !== '' ? 'both' : 'text-only';
    }
    // auto
    return $logo !== '' ? 'logo-only' : 'text-only';
}

/**
 * آیکون پیش‌فرض لوگو (SVG) — برای نمایش کنار متن عنوان سایت
 * در حالت text-only یا both بدون logoUrl.
 *
 * از ایکون «قطره آب» (droplet) به‌سبک Lucide استفاده می‌شود که با نام
 * «شبنم» هماهنگ است. روی پس‌زمینهٔ گرادیانی بنفش-آبی قرار می‌گیرد.
 */
function shabnam_default_logo_icon(): string
{
    return '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none" aria-hidden="true">'
        . '<defs>'
        . '<linearGradient id="shabnamLogoGrad" x1="0%" y1="0%" x2="100%" y2="100%">'
        . '<stop offset="0%" stop-color="#9c27b0"/>'
        . '<stop offset="100%" stop-color="#311b92"/>'
        . '</linearGradient>'
        . '</defs>'
        . '<rect x="2" y="2" width="28" height="28" rx="8" fill="url(#shabnamLogoGrad)"/>'
        // قطره آب Lucide droplet — هماهنگ با نام «شبنم»
        . '<path d="M16 7 C16 7 22 14 22 18 A6 6 0 0 1 10 18 C10 14 16 7 16 7 Z" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>'
        . '</svg>';
}

/**
 * نام نمایشی نویسنده وبلاگ.
 *
 * اولویت:
 *   ۱. تنظیم `authorName` پوسته
 *   ۲. تنظیم `aboutName` پوسته
 *   ۳. نام مستعار (screenName) نویسندهٔ مطلب جاری
 *   ۴. نام نویسندهٔ مطلب
 *   ۵. عنوان سایت
 *
 * @param \Typecho\Widget|null $post ویجت مطلب جاری (برای screenName)
 */
function shabnam_author_name($post = null): string
{
    // ۱) تنظیم authorName پوسته
    $name = trim((string) shabnam_opt('authorName', ''));
    if ($name !== '') {
        return $name;
    }

    // ۲) تنظیم aboutName پوسته
    $name = trim((string) shabnam_opt('aboutName', ''));
    if ($name !== '') {
        return $name;
    }

    // ۳ و ۴) screenName یا name نویسندهٔ مطلب
    if ($post !== null) {
        try {
            $sn = trim((string) $post->author->screenName);
            if ($sn !== '') {
                return $sn;
            }
        } catch (\Throwable $e) {
        }
        try {
            $n = trim((string) $post->author->name);
            if ($n !== '') {
                return $n;
            }
        } catch (\Throwable $e) {
        }
    }

    // ۵) عنوان سایت
    try {
        $title = trim((string) \Widget\Options::alloc()->title);
        if ($title !== '') {
            return $title;
        }
    } catch (\Throwable $e) {
    }

    return '';
}

/**
 * بررسی فعال بودن یک ویجت سایدبار.
 *
 * @param string $key کلید تنظیم (sidebarAbout, sidebarRecentPosts, ...)
 */
function shabnam_sidebar_visible(string $key): bool
{
    return shabnam_opt($key, '1') === '1';
}

/**
 * ساخت لیست شبکه‌های اجتماعی از فیلدهای مجزا.
 *
 * هر فیلد فقط نام کاربری می‌گیرد و این تابع نشانی کامل را می‌سازد.
 *
 * @return array<int, array{title: string, url: string, key: string}>
 */
function shabnam_social_list(): array
{
    $items = [];

    // نگاشت فیلد → [عنوان، قالب نشانی]
    $map = [
        'socialInstagram' => ['اینستاگرام', 'https://instagram.com/%s'],
        'socialTelegram'  => ['تلگرام',     'https://t.me/%s'],
        'socialGithub'    => ['گیت‌هاب',    'https://github.com/%s'],
        'socialYoutube'   => ['یوتیوب',     ''], // خاص: می‌تواند @ یا URL کامل باشد
        'socialLinkedin'  => ['لینکدین',    'https://linkedin.com/in/%s'],
        'socialTwitter'   => ['توییتر',  'https://x.com/%s'],
        'socialWhatsapp'  => ['واتساپ',     'https://wa.me/%s'],
        'socialEmail'     => ['ایمیل',      'mailto:%s'],
    ];

    foreach ($map as $key => [$title, $urlTemplate]) {
        $value = shabnam_opt($key);
        if ($value === null || $value === '') {
            continue;
        }
        $value = trim($value);

        if ($key === 'socialYoutube') {
            // یوتیوب: اگر URL کامل بود، همان استفاده شود؛ وگرنه https://youtube.com/@username
            if (preg_match('#^https?://#i', $value)) {
                $url = $value;
            } else {
                $username = ltrim($value, '@');
                $url = 'https://youtube.com/@' . $username;
            }
        } elseif ($key === 'socialWhatsapp') {
            // شماره تلفن: فقط ارقام
            $digits = preg_replace('/\D+/', '', $value);
            if ($digits === '') {
                continue;
            }
            $url = sprintf($urlTemplate, $digits);
        } else {
            $username = ltrim($value, '@');
            $url = sprintf($urlTemplate, $username);
        }

        $items[] = [
            'title' => $title,
            'url'   => $url,
            'key'   => $key,
        ];
    }

    // RSS همیشه آخر
    if (shabnam_opt('socialRss', '1') === '1') {
        $items[] = [
            'title' => 'آر-اس-اس',
            'url'   => shabnam_site_url() . '/feed/',
            'key'   => 'rss',
        ];
    }

    return $items;
}

/* ================================================================
 *  ۳) تاریخ شمسی (جلالی)
 *
 *  پوستهٔ «زیبا» به تابع جانالی خارجی وابسته بود که در تایپ‌رینیو
 *  وجود ندارد و باعث «Call to undefined function jalali_date()» می‌شد.
 *  در شبنم، مبدل کامل به‌صورت داخلی پیاده شده و بدون هیچ افزونه‌ای
 *  کار می‌کند. اگر افزونه/پوستهٔ دیگری تابع jalali_date() تعریف کرده
 *  باشد، از همان استفاده می‌شود (سازگاری رو به عقب).
 * ================================================================ */

/** میلادی → جلالی (الگوریتم استاندارد تقویم جلالی) */
function shabnam_to_jalali(int $gy, int $gm, int $gd): array
{
    $g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + intdiv($gy2 + 3, 4) - intdiv($gy2 + 99, 100)
        + intdiv($gy2 + 399, 400) + $gd + $g_d_m[$gm - 1];
    $jy = -1595 + (33 * intdiv($days, 12053));
    $days %= 12053;
    $jy += 4 * intdiv($days, 1461);
    $days %= 1461;
    if ($days > 365) {
        $jy += intdiv($days - 1, 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + intdiv($days, 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + intdiv($days - 186, 30);
        $jd = 1 + (($days - 186) % 30);
    }
    return [$jy, $jm, $jd];
}

/** نام ماه‌های شمسی */
function shabnam_jalali_months(): array
{
    return [
        1 => 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
    ];
}

/** نام روزهای هفته (۰ = یکشنبه) */
function shabnam_weekday_name(int $wday): string
{
    $days = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
    return $days[$wday % 7];
}

/**
 * قالب‌بندی تاریخ شمسی معادل date() در PHP
 *
 * توکن‌های پشتیبانی‌شده: d j n m Y y F M H G h i s A a l D و U
 * خروجی با ارقام فارسی است تا با ظاهر فارسی سایت هماهنگ باشد.
 */
function shabnam_format_jalali(int $timestamp, string $format): string
{
    // منطقهٔ زمانی سایت؛ در نبود، تهران
    $tzId = 'Asia/Tehran';
    try {
        $opt = (string) \Typecho\Date::$timezoneId;
        if ($opt !== '') {
            $tzId = $opt;
        }
    } catch (\Throwable $e) {
    }
    try {
        $dt = new \DateTimeImmutable('@' . $timestamp);
        $dt = $dt->setTimezone(new \DateTimeZone($tzId));
    } catch (\Throwable $e) {
        $dt = new \DateTimeImmutable('@' . $timestamp);
    }

    $gy  = (int) $dt->format('Y');
    $gm  = (int) $dt->format('n');
    $gd  = (int) $dt->format('j');
    [$jy, $jm, $jd] = shabnam_to_jalali($gy, $gm, $gd);
    $months = shabnam_jalali_months();

    $out = '';
    $len = strlen($format);
    for ($i = 0; $i < $len; $i++) {
        $ch = $format[$i];
        if ($ch === '\\' && $i + 1 < $len) {
            $out .= $format[++$i];
            continue;
        }
        switch ($ch) {
            case 'd': $out .= str_pad((string) $jd, 2, '0', STR_PAD_LEFT); break;
            case 'j': $out .= (string) $jd; break;
            case 'n': $out .= (string) $jm; break;
            case 'm': $out .= str_pad((string) $jm, 2, '0', STR_PAD_LEFT); break;
            case 'Y': $out .= (string) $jy; break;
            case 'y': $out .= substr((string) $jy, -2); break;
            case 'F': $out .= $months[$jm]; break;
            case 'M': $out .= $months[$jm]; break;
            case 'l': $out .= shabnam_weekday_name((int) $dt->format('w')); break;
            case 'D': $out .= shabnam_weekday_name((int) $dt->format('w')); break;
            case 'H': $out .= $dt->format('H'); break;
            case 'G': $out .= $dt->format('G'); break;
            case 'h': $out .= $dt->format('h'); break;
            case 'g': $out .= $dt->format('g'); break;
            case 'i': $out .= $dt->format('i'); break;
            case 's': $out .= $dt->format('s'); break;
            case 'A': $out .= ((int) $dt->format('G')) < 12 ? 'ق.ظ' : 'ب.ظ'; break;
            case 'a': $out .= ((int) $dt->format('G')) < 12 ? 'ق.ظ' : 'ب.ظ'; break;
            case 'U': $out .= (string) $timestamp; break;
            default:  $out .= $ch; break;
        }
    }
    return shabnam_fa_num($out);
}

/**
 * تابع سازگار با پوستهٔ قدیمی — همان امضای jalali_date()
 * اگر افزونهٔ دیگری آن را تعریف کرده باشد تعریف مجدد نمی‌شود.
 */
if (! function_exists('jalali_date')) {
    function jalali_date($format, $timestamp = null)
    {
        $timestamp = ($timestamp === null || (int) $timestamp <= 0) ? time() : (int) $timestamp;
        return shabnam_format_jalali($timestamp, (string) $format);
    }
}

/** تاریخ شمسی یک محتوا (نوشته/برگه/دیدگاه) */
function shabnam_date($created, string $format = 'j F Y'): string
{
    $timestamp = (int) $created;
    if ($timestamp <= 0) {
        $timestamp = time();
    }
    return shabnam_format_jalali($timestamp, $format);
}

/** سال شمسی جاری برای کپی‌رایت فوتر */
function shabnam_jalali_year(): string
{
    return shabnam_format_jalali(time(), 'Y');
}

/* ================================================================
 *  ۴) سیستم بازدید داخلی
 *
 *  پوستهٔ «زیبا» به افزونهٔ ViewsCounter وابسته بود؛ در نبود افزونه
 *  هر دو صفحهٔ نوشته و نوار کناری با خطای مهلک متوقف می‌شدند. شبنم
 *  شمارندهٔ خود را دارد: ستون views روی جدول contents؛ اگر افزونهٔ
 *  ViewsCounter فعال باشد از دادهٔ آن هم استفاده می‌شود.
 * ================================================================ */

/** آیا افزونهٔ ViewsCounter فعال است؟ */
function shabnam_views_counter_active(): bool
{
    try {
        $plugins = \Widget\Options::alloc()->plugins;
        if (is_array($plugins) && isset($plugins['activated']) && is_array($plugins['activated'])) {
            foreach (array_keys($plugins['activated']) as $key) {
                if (stripos((string) $key, 'views') !== false) {
                    return true;
                }
            }
        }
    } catch (\Throwable $e) {
    }
    return false;
}

/** اطمینان از وجود ستون views (در نبود، ساخته می‌شود) */
function shabnam_stats_ready(): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }

    $ready = false;
    try {
        $db = \Typecho\Db::get();
        $prefix = $db->getPrefix();

        $columns = [];
        try {
            // SQLite / MySQL — SHOW COLUMNS روی MySQL
            $rows = $db->fetchAll("SHOW COLUMNS FROM `{$prefix}contents`");
            foreach ($rows as $row) {
                $columns[] = is_array($row) ? (string) reset($row) : (string) $row->Field;
            }
        } catch (\Throwable $e) {
            $columns = [];
        }

        if (empty($columns)) {
            try {
                $db->fetchRow($db->select('table.contents.views')->from('table.contents')->limit(1));
                $columns = ['views'];
            } catch (\Throwable $e) {
                $columns = [];
            }
        }

        if (! in_array('views', $columns, true)) {
            try {
                $db->query("ALTER TABLE `{$prefix}contents` ADD `views` INT DEFAULT 0");
            } catch (\Throwable $e) {
            }
        }

        $ready = true;
    } catch (\Throwable $e) {
        $ready = false;
    }
    return $ready;
}

/** تعداد بازدید نوشته */
function shabnam_views($widget): int
{
    if (shabnam_views_counter_active()) {
        try {
            $v = (int) $widget->views;
            if ($v > 0) {
                return $v;
            }
        } catch (\Throwable $e) {
        }
    }
    try {
        $cid = (int) $widget->cid;
        if ($cid < 1 || ! shabnam_stats_ready()) {
            return 0;
        }
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.views')->from('table.contents')->where('table.contents.cid = ?', $cid)
        );
        return (int) ($row['views'] ?? 0);
    } catch (\Throwable $e) {
        return 0;
    }
}

/** شمارش بازدید صفحات تکی با کوکی ضد تکرار (۲۴ ساعت) */
function shabnam_count_view($archive): void
{
    try {
        if (! method_exists($archive, 'is') || ! $archive->is('single')) {
            return;
        }
        // بازدید مدیرها شمرده نشود
        try {
            $user = \Widget\User::alloc();
            if ($user->hasLogin() && $user->pass('administrator', true)) {
                return;
            }
        } catch (\Throwable $e) {
        }
        $cid = (int) $archive->cid;
        if ($cid < 1 || ! shabnam_stats_ready()) {
            return;
        }
        $cookieName = 'shabnamV' . $cid;
        if (isset($_COOKIE[$cookieName])) {
            return;
        }
        $db = \Typecho\Db::get();
        $db->query(
            $db->update('table.contents')
                ->expression('views', 'views + 1')
                ->where('table.contents.cid = ?', $cid)
        );
        \Typecho\Cookie::set($cookieName, '1', time() + 86400);
    } catch (\Throwable $e) {
    }
}

/**
 * پربازدیدترین نوشته‌ها — جایگزین ViewsCounter_Plugin::getMostViewed
 *
 * خروجی: آرایه‌ای از [title, url, created, views, cid]
 */
function shabnam_most_viewed(int $limit = 5): array
{
    $out = [];
    $limit = max(1, min(20, $limit));
    try {
        if (! shabnam_stats_ready()) {
            return $out;
        }
        $db = \Typecho\Db::get();
        $rows = $db->fetchAll(
            $db->select('table.contents.cid', 'table.contents.title', 'table.contents.slug', 'table.contents.created', 'table.contents.views')
                ->from('table.contents')
                ->where('table.contents.type = ?', 'post')
                ->where('table.contents.status = ?', 'publish')
                ->where('table.contents.created < ?', \Widget\Options::alloc()->gmtTime)
                ->where('table.contents.views > 0')
                ->order('table.contents.views', \Typecho\Db::SORT_DESC)
                ->limit($limit)
        );
        if (empty($rows)) {
            return $out;
        }

        $siteBase = shabnam_site_url();
        $route = \Widget\Options::alloc()->routingTable['post'];
        $routeUrl = is_string($route) ? $route : (string) ($route['url'] ?? '');

        foreach ($rows as $row) {
            $cid = (int) $row['cid'];
            $slug = (string) $row['slug'];
            $path = str_replace(
                ['[slug:digital]', '[slug]', '[cid:digital]', '[cid]'],
                [$slug, $slug, (string) $cid, (string) $cid],
                $routeUrl
            );
            $out[] = [
                'cid'     => $cid,
                'title'   => (string) $row['title'],
                'url'     => $siteBase . '/' . ltrim($path, '/'),
                'created' => (int) $row['created'],
                'views'   => (int) ($row['views'] ?? 0),
            ];
        }
    } catch (\Throwable $e) {
    }
    return $out;
}

/* ================================================================
 *  ۵) آیکون‌های درون‌خطی (سبک Lucide — بدون وابستگی خارجی)
 * ================================================================ */

/** مجموعهٔ آیکون‌های SVG درون‌خطی */
function shabnam_icons(): array
{
    return [
        'calendar' => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
        'eye'      => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
        'clock'    => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
        'tag'      => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>',
        'user'     => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
        'search'   => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
        'home'     => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
        'download' => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
        'preview'  => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
        'file'     => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
        'message'  => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
        'flame'    => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>',
        'sparkles' => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l1.9 5.8a2 2 0 0 0 1.3 1.3L21 12l-5.8 1.9a2 2 0 0 0-1.3 1.3L12 21l-1.9-5.8a2 2 0 0 0-1.3-1.3L3 12l5.8-1.9a2 2 0 0 0 1.3-1.3L12 3z"/></svg>',
        'mail'     => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
        // شبکه‌های اجتماعی
        'instagram' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>',
        'telegram'  => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M21.94 4.6l-3.13 14.8c-.24 1.05-.87 1.31-1.76.82l-4.85-3.58-2.34 2.25c-.26.26-.48.48-.96.48l.34-4.81L18.1 6.6c.39-.35-.08-.55-.6-.2L6.93 13.24l-4.78-1.5c-1.04-.32-1.05-1.04.22-1.54l18.65-7.19c.86-.32 1.62.2 1.34 1.29z"/></svg>',
        'github'    => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.11.79-.25.79-.55v-2.17c-3.2.7-3.87-1.36-3.87-1.36-.52-1.33-1.28-1.68-1.28-1.68-1.05-.72.08-.7.08-.7 1.16.08 1.77 1.19 1.77 1.19 1.03 1.77 2.7 1.26 3.36.96.1-.75.4-1.26.72-1.55-2.55-.29-5.23-1.28-5.23-5.68 0-1.26.45-2.29 1.19-3.1-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.18 1.18a11.1 11.1 0 0 1 5.8 0c2.2-1.49 3.17-1.18 3.17-1.18.63 1.59.23 2.76.11 3.05.74.81 1.19 1.84 1.19 3.1 0 4.41-2.69 5.38-5.25 5.66.41.35.77 1.05.77 2.12v3.14c0 .3.21.67.8.55A10.52 10.52 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5z"/></svg>',
        'youtube'   => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M23.5 6.2a3.02 3.02 0 0 0-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.5A3.02 3.02 0 0 0 .5 6.2C0 8.07 0 12 0 12s0 3.93.5 5.8a3.02 3.02 0 0 0 2.12 2.14c1.88.51 9.38.51 9.38.51s7.5 0 9.38-.5a3.02 3.02 0 0 0 2.12-2.14C24 15.93 24 12 24 12s0-3.93-.5-5.8zM9.55 15.57V8.43L15.82 12l-6.27 3.57z"/></svg>',
        'linkedin'  => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M20.45 20.45h-3.55v-5.57c0-1.33-.03-3.04-1.85-3.04-1.86 0-2.14 1.45-2.14 2.94v5.67H9.35V9h3.41v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12zM7.12 20.45H3.56V9h3.56v11.45z"/></svg>',
        'whatsapp'  => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.64.07-.3-.15-1.26-.46-2.39-1.47-.88-.79-1.48-1.76-1.65-2.06-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.61-.91-2.2-.24-.58-.48-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.01-1.04 2.47s1.06 2.86 1.21 3.06c.15.2 2.1 3.2 5.07 4.49.71.3 1.26.49 1.69.63.71.22 1.36.19 1.87.12.57-.09 1.76-.72 2.01-1.41.25-.7.25-1.29.17-1.42-.07-.12-.27-.2-.57-.35zM12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.46 1.32 4.96L2 22l5.25-1.38a9.87 9.87 0 0 0 4.79 1.22h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0 0 12.04 2z"/></svg>',
        'twitter'   => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M18.24 2.25h3.31l-7.23 8.26 8.5 11.24h-6.65l-5.2-6.82-5.96 6.82H1.68l7.74-8.84L1.25 2.25h6.82l4.71 6.23 5.46-6.23zm-1.16 17.52h1.83L7.08 4.13H5.12l11.96 15.64z"/></svg>',
        'rss'       => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 11a9 9 0 0 1 9 9"/><path d="M4 4a16 16 0 0 1 16 16"/><circle cx="5" cy="19" r="1"/></svg>',
        'link'      => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>',
        'arrow-left' => '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="11 6 5 12 11 18"/></svg>',
        // نشان «نویسنده» — Lucide crown برای متمایز کردن دیدگاه‌های نویسنده
        'crown'    => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 4 L2 9 C2 9 5 9 7 7 M7 7 L12 4 L17 7 M17 7 C19 9 22 9 22 9 L22 4 L17 7 M7 7 L7 18 C7 19 8 20 9 20 L15 20 C16 20 17 19 17 18 L17 7"/><path d="M5 20 L19 20"/></svg>',
        // قطره آب Lucide droplet — برای نشانهائی که به آبی/بنفش نیاز دارند
        'droplet'  => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/></svg>',
        // قلب Lucide heart — برای «چیزهایی که دوست دارم»
        'heart'    => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.29 1.51 4.04 3 5.5l7 7 7-7z"/></svg>',
        // ستاره Lucide star — برای تخصص‌ها
        'star'     => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
        // زیگزاگ Lucide zap — برای انرژی/پویایی
        'zap'      => '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
    ];
}

/** دریافت HTML آیکون درون‌خطی */
function shabnam_icon(string $name, int $size = 15): string
{
    $icons = shabnam_icons();
    if (! isset($icons[$name])) {
        return '';
    }
    $svg = $icons[$name];
    if ($size !== 15 && $size !== 18) {
        $svg = str_replace(['width="15" height="15"', 'width="18" height="18"'], "width=\"{$size}\" height=\"{$size}\"", $svg);
    }
    return $svg;
}

/** انتخاب آیکون شبکهٔ اجتماعی از روی کلید فیلد یا نشانی */
function shabnam_social_icon(string $keyOrUrl, string $title = ''): string
{
    // پشتیبان: اگر کلید فیلد داده شد
    $keyMap = [
        'socialInstagram' => 'instagram',
        'socialTelegram'  => 'telegram',
        'socialGithub'    => 'github',
        'socialYoutube'   => 'youtube',
        'socialLinkedin'  => 'linkedin',
        'socialTwitter'   => 'twitter',
        'socialWhatsapp'  => 'whatsapp',
        'socialEmail'     => 'mail',
        'rss'             => 'rss',
    ];
    if (isset($keyMap[$keyOrUrl])) {
        return shabnam_icon($keyMap[$keyOrUrl], 18);
    }

    // پشتیبان: تشخیص از روی URL (کد قدیمی)
    $hay = strtolower($keyOrUrl . ' ' . $title);
    $map = [
        'instagram' => 'instagram', 'instagr' => 'instagram',
        'telegram' => 'telegram', 't.me' => 'telegram',
        'github' => 'github',
        'youtube' => 'youtube', 'youtu' => 'youtube',
        'linkedin' => 'linkedin',
        'whatsapp' => 'whatsapp', 'wa.me' => 'whatsapp',
        'twitter' => 'twitter', 'x.com' => 'twitter',
        'mailto' => 'mail', 'email' => 'mail',
        'rss' => 'rss', 'feed' => 'rss',
    ];
    foreach ($map as $needle => $icon) {
        if (strpos($hay, $needle) !== false) {
            return shabnam_icon($icon, 18);
        }
    }
    return shabnam_icon('link', 18);
}

/* ================================================================
 *  ۵-ب) کمک‌های یکپارچهٔ کارت‌ها و کامنت‌ها (نسخهٔ ۱٫۵)
 * ================================================================ */

/**
 * نمایش نام نویسندهٔ وبلاگ برای کارت‌های فهرست/آرشیو.
 *
 * اولویت: تنظیم authorName پوسته → screenName نویسندهٔ مطلب → name نویسنده → عنوان سایت.
 * به این ترتیب در صورت ورود «نام نویسنده» در تنظیمات پوسته، همان در همهٔ کارت‌ها
 * (ایندکس، دسته، برچسب، جستجو، آرشیو) به‌نمایش درمی‌آید.
 */
function shabnam_card_author_name($post = null): string
{
    // ۱) تنظیم authorName پوسته — بالاترین اولویت
    $name = trim((string) shabnam_opt('authorName', ''));
    if ($name !== '') {
        return $name;
    }
    // ۲) تنظیم aboutName پوسته
    $name = trim((string) shabnam_opt('aboutName', ''));
    if ($name !== '') {
        return $name;
    }
    // ۳) screenName یا name نویسندهٔ مطلب
    if ($post !== null) {
        try {
            $sn = trim((string) $post->author->screenName);
            if ($sn !== '') {
                return $sn;
            }
        } catch (\Throwable $e) {
        }
        try {
            $n = trim((string) $post->author->name);
            if ($n !== '') {
                return $n;
            }
        } catch (\Throwable $e) {
        }
    }
    // ۴) عنوان سایت
    try {
        $title = trim((string) \Widget\Options::alloc()->title);
        if ($title !== '') {
            return $title;
        }
    } catch (\Throwable $e) {
    }
    return '';
}

/**
 * آیا دیدگاهِ داده‌شده از سوی نویسندهٔ مطلب است؟
 *
 * در ویجت کامنت‌های اخیر سایدبار و در صفحهٔ نوشته، با این تابع تشخیص می‌دهیم
 * که آیا دیدگاه از سوی نویسندهٔ پست ارسال شده است. در این صورت نام نمایشی
 * نویسندهٔ پوسته (از تنظیمات) به‌جای نام ارسال‌کننده دیدگاه نمایش داده می‌شود.
 *
 * @param mixed $commentWidget ویجت دیدگاه (در سایدبار یا در صفحهٔ نوشته)
 * @return bool
 */
function shabnam_is_author_comment($commentWidget): bool
{
    try {
        $authorId = (int) ($commentWidget->authorId ?? 0);
        if ($authorId <= 0) {
            return false;
        }
        // در صفحهٔ نوشته ownerId مستقیماً در دسترس است
        $ownerId = (int) ($commentWidget->ownerId ?? 0);
        if ($ownerId > 0) {
            return $authorId === $ownerId;
        }
        // در ویجت کامنت‌های اخیر، cid پست را داریم — ownerId را از جدول contents می‌گیریم
        $cid = (int) ($commentWidget->cid ?? 0);
        if ($cid <= 0) {
            return false;
        }
        $db = \Typecho\Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.authorId AS ownerId')
                ->from('table.contents')
                ->where('table.contents.cid = ?', $cid)
        );
        if ($row && (int) ($row['ownerId'] ?? 0) === $authorId) {
            return true;
        }
    } catch (\Throwable $e) {
    }
    return false;
}

/**
 * نام نمایشی برای نویسندهٔ یک دیدگاه.
 *
 * اگر دیدگاه از سوی نویسندهٔ مطلب باشد و نام نویسنده در تنظیمات پوسته وارد شده
 * باشد، همان نام به‌نمایش درمی‌آید؛ وگرنه نام ارسال‌کنندهٔ دیدگاه.
 *
 * @param mixed $commentWidget
 * @return string
 */
function shabnam_comment_display_name($commentWidget): string
{
    if (shabnam_is_author_comment($commentWidget)) {
        $name = shabnam_author_name();
        if ($name !== '') {
            return $name;
        }
    }
    $name = '';
    try {
        $name = trim((string) $commentWidget->author);
    } catch (\Throwable $e) {
    }
    return $name !== '' ? $name : 'ناشناس';
}

/**
 * نشانی تصویر شاخص یک پست بر اساس cid — با کوئری مستقیم از table.fields.
 *
 * این تابع برای ویجت پربازدیدها کاربرد دارد؛ در آنجا cid چند پست را داریم و
 * باید تصویر شاخص هر کدام را گرفت. قبلاً از روی متن محتوا (regex) می‌گرفتیم
 * که کار درستی نبود چون فیلد سفارشی thumb در جدول fields ذخیره
 * می‌شود، نه در متن. اکنون مستقیماً از table.fields می‌خوانیم.
 *
 * اولویت: ۱) thumb در table.fields →
 *          ۲) اولین تصویر محتوا → ۳) نشانی پیش‌فرض پوسته
 *
 * @param int $cid شناسهٔ محتوا
 * @param string $defaultUrl نشانی پیش‌فرض در نبود تصویر
 * @return string
 */
function shabnam_cover_by_cid(int $cid, string $defaultUrl = ''): string
{
    if ($cid <= 0) {
        return $defaultUrl !== '' ? $defaultUrl : shabnam_theme_url('assets/img/default.jpg');
    }
    try {
        $db = \Typecho\Db::get();
        // ۱) فیلد thumb از table.fields
        $rows = $db->fetchAll(
            $db->select('table.fields.name', 'table.fields.str_value', 'table.fields.int_value')
                ->from('table.fields')
                ->where('table.fields.cid = ?', $cid)
                ->where("table.fields.name = 'thumb'")
        );
        $thumbVal = '';
        foreach ($rows as $r) {
            $v = trim((string) ($r['str_value'] !== null && $r['str_value'] !== '' ? $r['str_value'] : $r['int_value'] ?? ''));
            if ($v !== '') {
                $thumbVal = $v;
                break;
            }
        }
        if ($thumbVal !== '') {
            return shabnam_resolve_url($thumbVal);
        }
        // ۲) اولین تصویر از متن پست
        $row = $db->fetchRow(
            $db->select('table.contents.text')->from('table.contents')->where('table.contents.cid = ?', $cid)
        );
        if ($row) {
            $text = (string) ($row['text'] ?? '');
            $first = shabnam_first_image($text);
            if ($first !== '') {
                return shabnam_resolve_url($first);
            }
        }
    } catch (\Throwable $e) {
    }
    return $defaultUrl !== '' ? $defaultUrl : shabnam_theme_url('assets/img/default.jpg');
}

/* ================================================================
 *  ۶) راه‌انداز پوسته
 * ================================================================ */

/**
 * هوک شروع رندر — شمارش بازدید صفحات تکی
 * این تابع به‌صورت خودکار توسط هستهٔ تایپ‌رینیو فراخوانی می‌شود.
 */
function themeInit($archive)
{
    try {
        \Typecho\Plugin::factory('Widget\Archive')->beforeRender = 'shabnam_count_view';
    } catch (\Throwable $e) {
    }
}
