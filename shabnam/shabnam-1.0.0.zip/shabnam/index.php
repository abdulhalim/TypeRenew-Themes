<?php
/**
 * پوستهٔ شبنم — پوسته‌ای سبک و ساده با طراحی مینیمال و مناسب برای راه‌اندازی یک سایت شخصی یا محتوایی.
 *
 * @package شبنم
 * @author  پوردریایی
 * @version 1.0.0
 * @link    https://pourdaryaei.ir
 */

if (! defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

$this->need('header.php');

$homeLayout   = shabnam_opt('homeLayout', 'hero-grid');
$isHome       = $this->is('index');
$currentPage  = 1;
try {
    $currentPage = (int) $this->currentPage;
} catch (\Throwable $e) {
    $currentPage = 1;
}
$firstPage    = $isHome && $currentPage <= 1;
$showHeroPost = $firstPage && in_array($homeLayout, ['hero-grid', 'hero-list'], true);
$useList      = in_array($homeLayout, ['list', 'hero-list'], true);
$postIndex    = 0;
$hasRestIntro = false;
?>

<div class="archive-header">
    <h2 class="archive-title"><?php _e('جدیدترین مطالب'); ?></h2>
    <p class="archive-count"><?php echo shabnam_fa_num((string) $this->getTotal()); ?> <?php _e('نوشته'); ?></p>
</div>

<?php if ($this->have()): ?>

    <?php while ($this->next()): $postIndex++; ?>

        <?php
        $cover    = shabnam_cover($this);
        $hasCover = shabnam_has_cover($this);
        $title    = (string) $this->title;
        $permalink = (string) $this->permalink;
        $created  = (int) $this->created;
        $excerpt  = shabnam_excerpt($this->excerpt ?: $this->content, 100);
        $author   = shabnam_card_author_name($this);
        $views    = shabnam_views($this);
        $firstCat = null;
        try {
            if (! empty($this->categories) && is_array($this->categories)) {
                $firstCat = $this->categories[0];
            }
        } catch (\Throwable $e) {
        }
        ?>

        <?php if ($showHeroPost && $postIndex === 1): ?>
            <!-- کارت بزرگ تازه‌ترین نوشته -->
            <article class="hero-card" itemscope itemtype="http://schema.org/BlogPosting">
                <a class="hero-cover" href="<?php echo shabnam_e($permalink); ?>" aria-hidden="true" tabindex="-1">
                    <?php if ($cover !== ''): ?>
                        <img src="<?php echo shabnam_e($cover); ?>" alt="<?php echo shabnam_e($title); ?>" loading="eager" itemprop="image">
                    <?php else: ?>
                        <span class="hero-cover-fallback" aria-hidden="true"></span>
                    <?php endif; ?>
                </a>
                <div class="hero-body">
                    <div class="hero-kicker">
                        <span class="chip chip-new"><?php _e('تازه‌ترین نوشته'); ?></span>
                        <?php if ($firstCat): ?>
                            <a class="chip chip-category" href="<?php echo shabnam_e($firstCat['permalink']); ?>"><?php echo shabnam_e($firstCat['name']); ?></a>
                        <?php endif; ?>
                    </div>
                    <h2 class="hero-title" itemprop="name headline">
                        <a href="<?php echo shabnam_e($permalink); ?>" itemprop="url"><?php echo shabnam_e($title); ?></a>
                    </h2>
                    <?php if ($excerpt !== ''): ?>
                        <p class="hero-excerpt"><?php echo shabnam_e($excerpt); ?></p>
                    <?php endif; ?>
                    <div class="hero-meta">
                        <span class="meta-item"><?php echo shabnam_icon('user', 14); ?><?php echo shabnam_e($author); ?></span>
                        <span class="meta-item"><?php echo shabnam_icon('calendar'); ?><?php echo shabnam_date($created, 'j F Y'); ?></span>
                        <?php if ($views > 0): ?>
                            <span class="meta-item meta-views"><?php echo shabnam_icon('eye'); ?><?php echo shabnam_fa_num((string) $views); ?> <?php _e('بازدید'); ?></span>
                        <?php endif; ?>
                    </div>
                    <a class="hero-more" href="<?php echo shabnam_e($permalink); ?>">
                        <?php _e('ادامهٔ خواندن'); ?>
                        <?php echo shabnam_icon('arrow-left', 16); ?>
                    </a>
                </div>
            </article>

            <?php if ($this->length > 1): ?>
                <div class="posts-heading">
                    <h2 class="posts-heading-title"><?php _e('نوشته‌های دیگر'); ?></h2>
                </div>
                <?php if ($useList): ?>
                    <div class="posts-list">
                <?php else: ?>
                    <div class="polaroid-grid">
                <?php endif; ?>
            <?php endif; ?>

            <?php continue; ?>
        <?php elseif (! $showHeroPost && $postIndex === 1): ?>
            <?php if ($useList): ?>
                <div class="posts-list">
            <?php else: ?>
                <div class="polaroid-grid">
            <?php endif; ?>
        <?php endif; ?>

        <?php if ($useList): ?>
            <!-- کارت لیستی -->
            <article class="list-card" itemscope itemtype="http://schema.org/BlogPosting">
                <a class="list-card-cover" href="<?php echo shabnam_e($permalink); ?>" aria-hidden="true" tabindex="-1">
                    <?php if ($cover !== ''): ?>
                        <img src="<?php echo shabnam_e($cover); ?>" alt="<?php echo shabnam_e($title); ?>" loading="lazy" itemprop="image">
                    <?php else: ?>
                        <span class="list-card-pattern" aria-hidden="true"></span>
                    <?php endif; ?>
                </a>
                <div class="list-card-body">
                    <div class="list-card-kicker">
                        <?php if ($firstCat): ?>
                            <a class="chip chip-category" href="<?php echo shabnam_e($firstCat['permalink']); ?>"><?php echo shabnam_e($firstCat['name']); ?></a>
                        <?php endif; ?>
                        <time class="list-card-date" datetime="<?php echo date('c', $created); ?>"><?php echo shabnam_date($created, 'j F Y'); ?></time>
                    </div>
                    <h2 class="list-card-title" itemprop="name headline">
                        <a href="<?php echo shabnam_e($permalink); ?>" itemprop="url"><?php echo shabnam_e($title); ?></a>
                    </h2>
                    <?php if ($excerpt !== ''): ?>
                        <p class="list-card-excerpt"><?php echo shabnam_e($excerpt); ?></p>
                    <?php endif; ?>
                    <div class="list-card-meta">
                        <span class="meta-item"><?php echo shabnam_icon('user', 14); ?><?php echo shabnam_e($author); ?></span>
                        <span class="meta-item"><?php echo shabnam_icon('calendar'); ?><?php echo shabnam_date($created, 'j F Y'); ?></span>
                        <?php if ($views > 0): ?>
                            <span class="meta-item meta-views"><?php echo shabnam_icon('eye'); ?><?php echo shabnam_fa_num((string) $views); ?> <?php _e('بازدید'); ?></span>
                        <?php endif; ?>
                    </div>
                    <a class="card-continue-link" href="<?php echo shabnam_e($permalink); ?>">
                        <span><?php _e('ادامه مطلب'); ?></span>
                        <?php echo shabnam_icon('arrow-left', 16); ?>
                    </a>
                </div>
            </article>
        <?php else: ?>
            <!-- کارت پولاروید — مینیمال با متای کامل -->
            <article class="polaroid-card" itemscope itemtype="http://schema.org/BlogPosting">
                <a href="<?php echo shabnam_e($permalink); ?>" class="polaroid-image-link" aria-hidden="true" tabindex="-1">
                    <div class="polaroid-image" style="background-image: url('<?php echo shabnam_e($cover); ?>')">
                        <?php if (! $hasCover): ?>
                            <div class="default-image-overlay"></div>
                        <?php endif; ?>
                        <?php if ($firstCat): ?>
                            <span class="polaroid-cat-badge"><?php echo shabnam_e($firstCat['name']); ?></span>
                        <?php endif; ?>
                    </div>
                </a>

                <div class="polaroid-footer">
                    <h2 class="polaroid-title"><a href="<?php echo shabnam_e($permalink); ?>" itemprop="url" itemprop="name headline"><?php echo shabnam_e($title); ?></a></h2>
                    <?php if ($excerpt !== ''): ?>
                        <p class="polaroid-excerpt"><?php echo shabnam_e($excerpt); ?></p>
                    <?php endif; ?>
                    <div class="polaroid-meta">
                        <span class="meta-item"><?php echo shabnam_icon('user', 14); ?><?php echo shabnam_e($author); ?></span>
                        <span class="meta-item"><?php echo shabnam_icon('calendar'); ?><?php echo shabnam_date($created, 'j F Y'); ?></span>
                        <?php if ($views > 0): ?>
                            <span class="meta-item meta-views"><?php echo shabnam_icon('eye'); ?><?php echo shabnam_fa_num((string) $views); ?></span>
                        <?php endif; ?>
                    </div>
                    <a class="card-continue-link card-continue-link-polaroid" href="<?php echo shabnam_e($permalink); ?>">
                        <span><?php _e('ادامه مطلب'); ?></span>
                        <?php echo shabnam_icon('arrow-left', 16); ?>
                    </a>
                </div>
            </article>
        <?php endif; ?>

    <?php endwhile; ?>

    <?php /* بستن container که در طول حلقه باز شده */ ?>
    <?php if ($showHeroPost && $this->length > 1): ?>
        </div><!-- posts-list / polaroid-grid -->
    <?php elseif (! $showHeroPost): ?>
        </div><!-- posts-list / polaroid-grid -->
    <?php endif; ?>

    <?php $this->pageNav('&laquo; قبلی', 'بعدی &raquo;'); ?>

<?php else: ?>
    <div class="empty-state">
        <h2><?php _e('هنوز نوشته‌ای منتشر نشده است.'); ?></h2>
    </div>
<?php endif; ?>

<?php $this->need('footer.php'); ?>
