/* پوستهٔ شبنم — اسکریپت‌های اصلی (v1.4.0) */
document.addEventListener('DOMContentLoaded', function () {
  'use strict';

  /* --- لایت‌باکس گالری با ناوبری --- */
  var galleryLinks = document.querySelectorAll('a[data-lightbox]');
  var modal = document.getElementById('simpleLightboxModal');

  if (modal && galleryLinks.length > 0) {
    var modalImg = document.getElementById('simpleLightboxImg');
    var closeBtn = document.getElementById('simpleLightboxClose');
    var prevBtn = document.getElementById('simpleLightboxPrev');
    var nextBtn = document.getElementById('simpleLightboxNext');
    var currentIndex = 0;

    var images = Array.prototype.map.call(galleryLinks, function (link) {
      return link.getAttribute('href');
    });

    function showImage(index) {
      if (index < 0 || index >= images.length) return;
      currentIndex = index;
      modalImg.src = images[currentIndex];
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }

    function closeModal() {
      modal.classList.remove('active');
      document.body.style.overflow = '';
    }

    Array.prototype.forEach.call(galleryLinks, function (link, index) {
      link.addEventListener('click', function (e) {
        e.preventDefault();
        showImage(index);
      });
    });

    closeBtn.addEventListener('click', closeModal);

    // بستن لایت‌باکس با کلیک روی پس‌زمینه (خارج از تصویر)
    modal.addEventListener('click', function (e) {
      if (e.target === this) closeModal();
    });

    // همچنین کلیک روی خود تصویر هم نباید ببندد، اما کلیک روی هر جای دیگر
    // داخل مودال که تصویر نیست (نه دکمه‌ها) هم می‌بندد
    modalImg.addEventListener('click', function (e) {
      e.stopPropagation();
    });

    nextBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      showImage((currentIndex + 1) % images.length);
    });

    prevBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      showImage((currentIndex - 1 + images.length) % images.length);
    });

    document.addEventListener('keydown', function (e) {
      if (!modal.classList.contains('active')) return;
      if (e.key === 'ArrowRight') nextBtn.click();
      else if (e.key === 'ArrowLeft') prevBtn.click();
      else if (e.key === 'Escape') closeModal();
    });
  }

  /* --- منوی موبایل --- */
  var menuToggle = document.querySelector('.menu-toggle');
  var menuLinks = document.querySelector('.menu-links');
  var body = document.body;
  var menuOverlay = document.querySelector('.menu-overlay');

  function openMenu() {
    if (!menuToggle || !menuLinks) return;
    menuToggle.classList.add('open');
    menuLinks.classList.add('open');
    body.classList.add('menu-open');
    menuToggle.setAttribute('aria-expanded', 'true');
    if (menuOverlay) {
      menuOverlay.setAttribute('aria-hidden', 'false');
    }
  }

  function closeMenu() {
    if (!menuToggle || !menuLinks) return;
    menuToggle.classList.remove('open');
    menuLinks.classList.remove('open');
    body.classList.remove('menu-open');
    menuToggle.setAttribute('aria-expanded', 'false');
    if (menuOverlay) {
      menuOverlay.setAttribute('aria-hidden', 'true');
    }
  }

  if (menuToggle && menuLinks) {
    menuToggle.addEventListener('click', function (e) {
      e.stopPropagation();
      if (menuLinks.classList.contains('open')) {
        closeMenu();
      } else {
        openMenu();
      }
    });

    if (menuOverlay) {
      menuOverlay.addEventListener('click', closeMenu);
    }

    // بستن منو با Escape
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && body.classList.contains('menu-open')) closeMenu();
    });

    // جلوگیری از کلیک‌های داخل منو باعث بستن آن نشوند
    menuLinks.addEventListener('click', function (e) {
      e.stopPropagation();
    });
  }

  /* --- جستجوی تمام‌صفحه --- */
  var searchOpenBtn = document.querySelector('.search-open-button');
  var searchCloseBtn = document.querySelector('.search-close-button');
  var searchContainer = document.getElementById('fullscreen-search-container');
  var searchInput = document.querySelector('.search-input');
  var searchForm = document.querySelector('#fullscreen-search-container .search-form');
  var searchInputWrapper = document.querySelector('#fullscreen-search-container .search-input-wrapper');

  function openSearch() {
    if (!searchContainer) return;
    searchContainer.classList.add('active');
    setTimeout(function () { if (searchInput) searchInput.focus(); }, 250);
  }

  function closeSearch() {
    if (!searchContainer) return;
    searchContainer.classList.remove('active');
    // پاک کردن فیلد جستجو موقع بستن — تجربهٔ بهتر
    if (searchInput) {
      searchInput.value = '';
    }
  }

  if (searchOpenBtn && searchContainer) {
    searchOpenBtn.addEventListener('click', openSearch);

    if (searchCloseBtn) {
      searchCloseBtn.addEventListener('click', closeSearch);
    }

    // بستن جستجو با کلیک روی فضای بیرون فیلد (خارج از فرم و دکمه‌ها)
    // این مهم است: کلیک روی خود کانتینر (نه فرم) → بستن.
    // کلیک داخل فرم یا دکمه‌ها → stopPropagation می‌کنیم تا کانتینر نبندد.
    searchContainer.addEventListener('click', function (e) {
      // اگر هدف کلیک خودِ کانتینر بود (نه فرزندانش)، ببند
      if (e.target === searchContainer) {
        closeSearch();
        return;
      }
    });

    // جلوگیری از کلیک روی فرم/دکمه‌ها باعث بسته‌شدن کانتینر نشود
    if (searchForm) {
      searchForm.addEventListener('click', function (e) {
        e.stopPropagation();
      });
    }
    if (searchInputWrapper) {
      searchInputWrapper.addEventListener('click', function (e) {
        e.stopPropagation();
      });
    }
    if (searchCloseBtn) {
      searchCloseBtn.addEventListener('click', function (e) {
        e.stopPropagation();
      });
    }

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && searchContainer.classList.contains('active')) {
        closeSearch();
      }
    });
  }

  // دکمهٔ جستجو در صفحهٔ ۴۰۴ همان اورلی را باز می‌کند
  var errorSearchLink = document.getElementById('errorOpenSearch');
  if (errorSearchLink && searchContainer) {
    errorSearchLink.addEventListener('click', openSearch);
  }

  /* --- دکمهٔ کپی کد --- */
  document.querySelectorAll('pre').forEach(function (pre) {
    var button = document.createElement('button');
    button.className = 'copy-code-btn';
    button.textContent = 'کپی کد';
    button.title = 'کپی به کلیپ‌بورد';
    button.setAttribute('aria-label', 'کپی کد');

    pre.appendChild(button);

    button.addEventListener('click', function () {
      var code = pre.querySelector('code') ? pre.querySelector('code').innerText : '';
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(code).then(function () {
          button.textContent = 'کپی شد!';
          button.classList.add('copied');
          setTimeout(function () {
            button.textContent = 'کپی کد';
            button.classList.remove('copied');
          }, 2000);
        }).catch(function (err) {
          console.error('خطا در کپی کردن: ', err);
        });
      }
    });
  });

  /* --- دکمهٔ بازگشت به بالا --- */
  var backToTopBtn = document.createElement('button');
  backToTopBtn.className = 'back-to-top';
  backToTopBtn.innerHTML = '&uarr;';
  backToTopBtn.title = 'بازگشت به بالا';
  backToTopBtn.setAttribute('aria-label', 'بازگشت به بالا');
  document.body.appendChild(backToTopBtn);

  var lastKnownScroll = 0;
  window.addEventListener('scroll', function () {
    lastKnownScroll = window.pageYOffset;
    if (lastKnownScroll > 300) {
      backToTopBtn.classList.add('show');
    } else {
      backToTopBtn.classList.remove('show');
    }
  }, { passive: true });

  backToTopBtn.addEventListener('click', function () {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  /* --- رسپانسیو منو در تغییر سایز --- */
  window.addEventListener('resize', function () {
    if (window.innerWidth > 991) {
      closeMenu();
    }
  });
});
