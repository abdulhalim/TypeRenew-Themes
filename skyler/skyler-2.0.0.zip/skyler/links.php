<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * صفحه لینک‌تری
 *
 * @package custom
 */
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <?php $this->header(); ?>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لینک‌ها | <?php $this->options->title(); ?></title>
    
    <!-- ---------- فونت و آیکون‌ها (آفلاین — از خود پوسته) ---------- -->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/fonts.css'); ?>">
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/all.css'); ?>">
    
    <!-- ---------- فراخوانی استایل اصلی قالب ---------- -->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/style.css'); ?>">
    
    <style>
        /* ---------- استایل اختصاصی صفحه لینک‌ها ---------- */
        body {
            background-color: var(--bg-body);
            font-family: var(--font-main);
            margin: 0;
            padding: 40px 20px;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow-x: hidden;
        }

        .links-container {
            width: 100%;
            max-width: 500px;
            margin: 0 auto;
        }

        .links-card {
            background: var(--bg-card);
            padding: 40px;
            border-radius: var(--radius);
            border: 1px solid var(--border);
            box-shadow: var(--shadow-md);
            text-align: center;
            animation: slideUp 0.6s ease-out;
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .links-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid var(--primary);
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin: 0 auto 25px auto;
            display: block;
        }

        .links-card h1 {
            font-size: 1.6rem;
            color: var(--dark);
            margin-bottom: 10px;
            margin-top: 0;
        }

        .links-card p {
            color: var(--gray);
            font-size: 0.95rem;
            margin-bottom: 35px;
        }

        .link-btn {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            padding: 15px 20px;
            margin-bottom: 12px;
            background: var(--light);
            border: 1px solid var(--border);
            border-radius: 12px;
            text-decoration: none;
            color: var(--dark);
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .link-btn:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
            transform: translateX(-5px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.2);
        }

        .link-btn i.left-icon {
            font-size: 1.2rem;
            width: 30px;
            text-align: center;
        }

        .link-btn i.right-icon {
            font-size: 0.9rem;
            opacity: 0.5;
            transition: 0.3s;
        }

        .link-btn:hover i.right-icon {
            opacity: 1;
            transform: rotate(-45deg);
            color: white;
        }

        .divider {
            height: 1px;
            background: var(--border);
            margin: 25px 0;
        }

        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            margin-top: 20px;
            padding: 12px 25px;
            border: 2px solid var(--border);
            border-radius: 50px;
            text-decoration: none;
            color: var(--gray);
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .back-btn:hover {
            border-color: var(--dark);
            color: var(--dark);
            background: var(--light);
        }

        @media (max-width: 480px) {
            .links-card {
                padding: 30px 20px;
            }
            .links-card h1 {
                font-size: 1.4rem;
            }
        }
    </style>
</head>
<body>

    <div class="links-container">
        <div class="links-card">
            
            <?php
            // ---------- آواتار نویسنده ----------
            // اولویت: تنظیم پوسته (authorAvatar) → img/avatar.png داخل پوسته → گراواتار
            $avatarUrl = getAuthorAvatar(null);
            ?>

            <!-- ---------- آواتار نویسنده ---------- -->
            <img src="<?php echo htmlspecialchars($avatarUrl); ?>" alt="Avatar" class="links-avatar">
            
            <!-- ---------- عنوان و توضیحات صفحه ---------- -->
            <h1>پوسته اسکایلر</h1>
            <p>لینک‌ها، شبکه‌های اجتماعی و پروژه‌ها</p>

            <!-- ---------- لینک نمونه ---------- -->
            <a href="https://example.com" target="_blank" class="link-btn">
                <span><i class="fa-solid fa-globe left-icon"></i> وبلاگ نمونه</span>
                <i class="fa-solid fa-arrow-up-right-from-square right-icon"></i>
            </a>

            <!-- ---------- شبکه‌های اجتماعی ---------- -->
            <?php if($this->options->socialTelegram): ?>
            <a href="<?php $this->options->socialTelegram(); ?>" target="_blank" class="link-btn">
                <span><i class="fa-brands fa-telegram left-icon"></i> تلگرام</span>
            </a>
            <?php endif; ?>

            <?php if($this->options->socialGithub): ?>
            <a href="<?php $this->options->socialGithub(); ?>" target="_blank" class="link-btn">
                <span><i class="fa-brands fa-github left-icon"></i> گیت‌هاب</span>
            </a>
            <?php endif; ?>

            <?php if($this->options->socialTwitter): ?>
            <a href="<?php $this->options->socialTwitter(); ?>" target="_blank" class="link-btn">
                <span><i class="fa-brands fa-twitter left-icon"></i> توییتر</span>
            </a>
            <?php endif; ?>

            <?php if($this->options->socialInstagram): ?>
            <a href="<?php $this->options->socialInstagram(); ?>" target="_blank" class="link-btn">
                <span><i class="fa-brands fa-instagram left-icon"></i> اینستاگرام</span>
            </a>
            <?php endif; ?>

            <?php if($this->options->socialLinkedin): ?>
            <a href="<?php $this->options->socialLinkedin(); ?>" target="_blank" class="link-btn">
                <span><i class="fa-brands fa-linkedin left-icon"></i> لینکدین</span>
            </a>
            <?php endif; ?>

            <!-- ---------- دکمه بازگشت به صفحه اصلی ---------- -->
            <a href="<?php $this->options->siteUrl(); ?>" class="back-btn">
                <i class="fa-solid fa-arrow-right"></i> بازگشت به صفحه اصلی
            </a>

        </div>
    </div>

</body>
</html>
