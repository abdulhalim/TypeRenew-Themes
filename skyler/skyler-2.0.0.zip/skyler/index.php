<?php
/**
 * اسکایلر - یک پوسته مدرن، زیبا و بهینه با طراحی مینیمال و ریسپانسیو
 * 
 * @package اسکایلر
 * @author پوردریایی
 * @version 2.0.0
 * @link http://pourdaryaei.ir
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<?php $this->need('header.php'); ?>

<?php
// ---------- تنظیمات نمایش آمار در فهرست‌ها ----------
$skylerShowViews = skyler_opt('skylerShowViews', '1') === '1';
$viewsCounterActive = skyler_views_counter_active();

// ---------- چیدمان فهرست: فهرستی یا گرید کارتی ----------
$skylerIndexLayout = (skyler_opt('skylerIndexLayout', 'list') === 'grid') ? 'grid' : 'list';
$skylerIsGrid = ($skylerIndexLayout === 'grid');
?>

<?php if ($this->have()): ?>

<?php if ($skylerIsGrid): ?>
<!-- ---------- شروع حلقهٔ نمایش پست‌ها — حالت گرید کارتی (دو ستونه) ---------- -->
<div class="skyler-index-grid">
<?php else: ?>
<!-- ---------- شروع حلقهٔ نمایش پست‌ها ---------- -->
<?php endif; ?>

<?php while($this->next()): ?>

<article class="index-post-card<?php echo $skylerIsGrid ? ' index-post-card-grid' : ''; ?>">
    
    <?php 
    // ---------- تصویر شاخص (کاور کارت) — با پشتیبانی فیلد thumb دیتابیس ----------
    // اولویت: فیلد سفارشی banner → فیلد thumb ثبت‌شده در دیتابیس →
    // اولین تصویر محتوا → تصویر پیش‌فرض پوسته → تصویر تصادفی
    $banner = skyler_post_banner($this);
    ?>

    <!-- ---------- کانتینر تصویر شاخص ---------- -->
    <div class="index-post-thumb-wrapper">
        <a href="<?php $this->permalink(); ?>" title="<?php $this->title(); ?>">
            <img src="<?php echo htmlspecialchars($banner); ?>" alt="<?php $this->title(); ?>" loading="lazy">
        </a>
    </div>

    <!-- ---------- کانتینر محتوای پست ---------- -->
    <div class="index-post-content-wrapper">

        <!-- ---------- متادیتای پست ---------- -->
        <div class="post-meta index-post-meta">
            <span class="index-meta-item"><i class="fa-regular fa-calendar"></i> <?php echo getLocalizedDate($this->created); ?></span>
            
            <span class="index-meta-item"><i class="fa-regular fa-folder"></i> <?php $this->category(', '); ?></span>
            
            <?php if ($skylerShowViews): ?>
                <span class="index-meta-item skyler-meta-views">
                    <i class="fa-regular fa-eye"></i>
                    <?php
                    if ($viewsCounterActive && method_exists('ViewsCounter_Plugin', 'getViewsById')) {
                        echo ViewsCounter_Plugin::getViewsById((int)$this->cid);
                    } else {
                        echo skyler_num(skyler_views($this->cid));
                    }
                    ?>
                </span>
            <?php endif; ?>
            
            <span class="index-meta-item"><i class="fa-regular fa-comment"></i> <?php $this->commentsNum('بدون نظر', '۱ دیدگاه', '%d دیدگاه'); ?></span>
        </div>

        <!-- ---------- عنوان پست ---------- -->
        <h2 class="index-post-title">
            <a href="<?php $this->permalink(); ?>" title="<?php $this->title(); ?>">
                <?php $this->title(); ?>
            </a>
        </h2>

        <!-- ---------- خلاصه پست ---------- -->
        <div class="index-post-excerpt">
            <?php $this->excerpt(120, '...'); ?>
        </div>

        <!-- ---------- دکمه ادامه مطلب ---------- -->
        <a href="<?php $this->permalink(); ?>" class="index-read-more">
            ادامه مطلب <i class="fa-solid fa-arrow-left-long"></i>
        </a>
    </div>
</article>

<?php endwhile; ?>

<?php if ($skylerIsGrid): ?>
</div>
<?php endif; ?>
<!-- ---------- پایان حلقه پست‌ها ---------- -->

<!-- ---------- صفحه‌بندی ---------- -->
<div class="comments-page-navigator">
    <?php $this->pageNav('&laquo; قبلی', 'بعدی &raquo;'); ?>
</div>

<?php else: ?>

<!-- ---------- حالت خالی: هیچ پستی وجود ندارد ---------- -->
<article class="index-post-card">
    <div class="index-post-content-wrapper" style="text-align: center; padding: 60px 30px;">
        <i class="fa-regular fa-face-frown" style="font-size: 3.5rem; color: var(--gray); margin-bottom: 20px; display: block;"></i>
        <h2 class="index-post-title" style="margin-bottom: 12px;">هنوز مطلبی نوشته نشده است</h2>
        <p class="index-post-excerpt" style="margin: 0 auto; max-width: 480px;">
            به‌زودی نوشته‌های تازه اینجا منتشر می‌شوند. دوباره سر بزنید!
        </p>
    </div>
</article>

<?php endif; ?>

</main>
<!-- ---------- پایان بخش محتوای اصلی ---------- -->

<!-- ---------- فراخوانی سایدبار ---------- -->
<?php $this->need('sidebar.php'); ?>

</div>
<!-- ---------- پایان کانتینر اصلی ---------- -->

<!-- ---------- فراخوانی فوتر ---------- -->
<?php $this->need('footer.php'); ?>