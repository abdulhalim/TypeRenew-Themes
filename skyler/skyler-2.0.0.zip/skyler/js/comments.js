(function() {
    // اگر آبجکت TypechoComment وجود ندارد، آن را می‌سازیم
    if (typeof TypechoComment === 'undefined') {
        window.TypechoComment = {};
    }

    // بازنویسی تابع پاسخ (Reply) برای جلوگیری از جابجایی فرم
    TypechoComment.reply = function(cid, coid) {
        // دریافت آی دی داینامیک فرم
        // از متغیر سراسری respondId استفاده می‌کنیم که تایپوچو در صفحه تعریف می‌کند
        var respondId = window.respondId || 'respond'; 
        var comment = document.getElementById(cid);
        var respond = document.getElementById(respondId);
        
        if (!comment || !respond) return false;

        // 1. پیدا کردن یا ساخت اینپوت مخفی (Parent ID)
        var parent = document.getElementById('comment-parent');
        if (!parent) {
            parent = document.createElement('input');
            parent.type = 'hidden';
            parent.name = 'parent';
            parent.id = 'comment-parent';
            respond.querySelector('form').appendChild(parent);
        }
        // تنظیم آی دی کامنت پدر
        parent.value = coid;

        // 2. تغییر متن عنوان فرم (بدون جابجایی)
        var author = 'کاربر';
        var authorEl = comment.querySelector('.comment-author');
        if (authorEl) author = authorEl.innerText;

        var title = document.getElementById('response');
        if (title) {
            title.innerHTML = 'در حال پاسخ به <span style="color:var(--primary); font-weight:bold;">' + author + '</span> <a href="#comment-' + coid + '" onclick="return TypechoComment.cancelReply();" style="color:var(--accent); font-size:0.8em; margin-right:10px;">(لغو)</a>';
        }

        // 3. اسکرول نرم به فرم و فوکوس کردن
        respond.scrollIntoView({ behavior: 'smooth', block: 'center' });

        var textarea = document.getElementById('textarea');
        if (textarea) textarea.focus();

        return false; // جلوگیری از هرگونه عملکرد پیش‌فرض دیگر
    };

    // بازنویسی تابع لغو پاسخ (Cancel Reply)
    TypechoComment.cancelReply = function() {
        var parent = document.getElementById('comment-parent');
        if (parent) parent.value = '';
        
        var title = document.getElementById('response');
        if (title) title.innerHTML = 'ارسال نظر جدید';
        
        return false;
    };
})();