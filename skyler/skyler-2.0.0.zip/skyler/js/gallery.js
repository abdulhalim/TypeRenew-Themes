document.addEventListener('DOMContentLoaded', function () {
    var modal = document.getElementById('simpleLightboxModal');
    if (!modal) { return; }

    var modalImg = document.getElementById('simpleLightboxImg');
    var closeBtn = document.getElementById('simpleLightboxClose');
    var prevBtn = document.getElementById('simpleLightboxPrev');
    var nextBtn = document.getElementById('simpleLightboxNext');
    var currentIndex = 0;

    var images = [];
    var seen = Object.create(null);

    function addImage(src) {
        if (!src || seen[src]) { return -1; }
        seen[src] = true;
        images.push(src);
        return images.length - 1;
    }

    function showImage(index) {
        if (index < 0 || index >= images.length) { return; }
        currentIndex = index;
        if (modalImg) { modalImg.src = images[currentIndex]; }
        modal.classList.add('active');
    }

    function closeModal() {
        modal.classList.remove('active');
    }

    // ---------- ۱) گالری فیلد سفارشی (لینک اصلی = تصویر کامل) ----------
    document.querySelectorAll('.gallery-link').forEach(function (link) {
        var href = link.getAttribute('href') || '';
        var idx = addImage(href);
        if (idx < 0) { idx = images.indexOf(href); }
        link.addEventListener('click', function (e) {
            e.preventDefault();
            showImage(idx);
        });
    });

    // ---------- ۲) گرید بندانگشتی خودکار (لینک = تصویر کامل، تصویر = بندانگشتی) ----------
    document.querySelectorAll('.skyler-img-grid .skyler-grid-link').forEach(function (link) {
        var href = link.getAttribute('href') || '';
        var img = link.querySelector('img');
        var full = /\.(jpe?g|png|gif|webp|avif|bmp|svg)([?#]|$)/i.test(href) ? href : (img ? img.src : '');
        var idx = addImage(full);
        if (idx < 0) { idx = images.indexOf(full); }
        link.addEventListener('click', function (e) {
            e.preventDefault();
            showImage(idx);
        });
    });

    // ---------- ۳) تصاویر آزاد محتوا (بدون لینک، خارج از گرید و گالری) ----------
    document.querySelectorAll('.single-post-content img, .page-static-content img').forEach(function (img) {
        if (img.closest('.skyler-img-grid') || img.closest('.gallery-item')) { return; }
        if (img.closest('a')) { return; } // تصویر لینک‌شده — رفتار لینک حفظ می‌شود
        var idx = addImage(img.src);
        if (idx < 0) { idx = images.indexOf(img.src); }
        img.addEventListener('click', function (e) {
            e.stopPropagation();
            showImage(idx);
        });
    });

    if (images.length === 0) { return; }

    // ---------- کنترل‌های مودال ----------
    if (closeBtn) {
        closeBtn.onclick = function () {
            closeModal();
        };
    }

    // بستن با کلیک روی پس‌زمینه
    modal.addEventListener('click', function (e) {
        if (e.target === this) { closeModal(); }
    });

    // دکمه بعدی
    if (nextBtn) {
        nextBtn.onclick = function () {
            showImage((currentIndex + 1) % images.length);
        };
    }

    // دکمه قبلی
    if (prevBtn) {
        prevBtn.onclick = function () {
            showImage((currentIndex - 1 + images.length) % images.length);
        };
    }

    // پشتیبانی از کیبورد
    document.addEventListener('keydown', function (e) {
        if (!modal.classList.contains('active')) { return; }
        if (e.key === 'ArrowRight') { if (nextBtn) { nextBtn.click(); } }
        else if (e.key === 'ArrowLeft') { if (prevBtn) { prevBtn.click(); } }
        else if (e.key === 'Escape') { if (closeBtn) { closeBtn.click(); } }
    });
});
