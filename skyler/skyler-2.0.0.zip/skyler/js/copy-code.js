document.addEventListener('DOMContentLoaded', function() {
    // انتخاب تمام بلوک‌های کد
    const codeBlocks = document.querySelectorAll('pre code');

    codeBlocks.forEach((block) => {
        const pre = block.parentElement;

        // ساخت دکمه کپی
        const button = document.createElement('button');
        button.className = 'copy-code-btn';
        button.type = 'button';
        button.innerHTML = '<i class="fa-regular fa-copy"></i> کپی کد';
        button.setAttribute('title', 'کپی در کلیپ‌بورد');

        // استایل دهی اولیه برای قرارگیری
        pre.style.position = 'relative';

        // اضافه کردن دکمه به قبل از بلوک کد (داخل pre)
        pre.insertBefore(button, block);

        // رویداد کلیک
        button.addEventListener('click', () => {
            const code = block.innerText;
            
            // کپی کردن در کلیپ‌بورد
            navigator.clipboard.writeText(code).then(() => {
                // تغییر متن دکمه
                button.innerHTML = '<i class="fa-solid fa-check"></i> کپی شد';
                button.classList.add('copied');
                
                // بازگشت به حالت اول بعد از ۲ ثانیه
                setTimeout(() => {
                    button.innerHTML = '<i class="fa-regular fa-copy"></i> کپی کد';
                    button.classList.remove('copied');
                }, 2000);
            }).catch(err => {
                console.error('Failed to copy: ', err);
            });
        });
    });
});