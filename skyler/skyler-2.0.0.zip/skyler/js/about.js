(function () {
    'use strict';

    var items = Array.prototype.slice.call(document.querySelectorAll('.about-skill-item'));
    if (items.length === 0) {
        return;
    }

    var reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';

    /** تبدیل ارقام لاتین به فارسی */
    function toFa(num) {
        return String(num).replace(/[0-9]/g, function (d) {
            return FA_DIGITS.charAt(+d);
        });
    }

    /** قالب‌بندی برچسب درصد مطابق سبک ورودی کاربر */
    function formatLabel(value, useFa) {
        return (useFa ? toFa(value) : String(value)) + (useFa ? '٪' : '%');
    }

    /** شمارندهٔ عدد درصد هم‌زمان با پر شدن نوار */
    function countUp(label, target, useFa, duration) {
        var startedAt = null;

        function frame(now) {
            if (startedAt === null) {
                startedAt = now;
            }
            var progress = Math.min(1, (now - startedAt) / duration);
            var eased = 1 - Math.pow(1 - progress, 3); // easeOutCubic
            label.textContent = formatLabel(Math.round(target * eased), useFa);
            if (progress < 1) {
                requestAnimationFrame(frame);
            }
        }

        requestAnimationFrame(frame);
    }

    /** اجرای انیمیشن یک مهارت (با تأخیر پلکانی بر اساس ترتیب) */
    function animate(item, index) {
        var fill = item.querySelector('.about-skill-fill');
        var label = item.querySelector('.about-skill-percent');
        if (!fill || !label) {
            return;
        }

        var target = parseInt(fill.getAttribute('data-percent'), 10);
        if (isNaN(target)) {
            target = 100;
        }
        var useFa = fill.getAttribute('data-fa') === '1';

        if (reducedMotion) {
            fill.style.width = target + '%';
            label.textContent = formatLabel(target, useFa);
            return;
        }

        var delay = index * 140;
        var duration = 1200;

        fill.style.transitionDelay = delay + 'ms';
        setTimeout(function () {
            countUp(label, target, useFa, duration);
        }, delay);
        requestAnimationFrame(function () {
            fill.style.width = target + '%';
        });
    }

    if (!reducedMotion) {
        // بازنشانی به صفر پیش از انیمیشن (بدون گذرِ ناگهانی، برای همین گذر موقتاً خاموش می‌شود)
        items.forEach(function (item) {
            var fill = item.querySelector('.about-skill-fill');
            var label = item.querySelector('.about-skill-percent');
            if (!fill || !label) {
                return;
            }
            var useFa = fill.getAttribute('data-fa') === '1';
            fill.style.transition = 'none';
            fill.style.width = '0%';
            void fill.offsetWidth; // اعمال فوری بازنشانی پیش از فعال‌شدن دوبارهٔ گذر
            fill.style.transition = '';
            label.textContent = formatLabel(0, useFa);
        });
    }

    if (reducedMotion || !('IntersectionObserver' in window)) {
        // بدون انیمیشن یا مرورگر خیلی قدیمی: مقادیر نهایی مستقیم
        items.forEach(animate);
        return;
    }

    var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (!entry.isIntersecting) {
                return;
            }
            var item = entry.target;
            observer.unobserve(item);
            animate(item, items.indexOf(item));
        });
    }, { threshold: 0.25 });

    items.forEach(function (item) {
        observer.observe(item);
    });
})();
