(function () {
    'use strict';

    var HIDE_DELAY = 1200; // میلی‌ثانیه تأخیر پیش از پنهان‌شدن دکمه

    function faNum(n) {
        var map = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return String(n).replace(/\d/g, function (d) { return map[+d]; });
    }

    function paintLike(btn, likes, liked) {
        var count = btn.querySelector('.skyler-like-count');
        if (count) { count.textContent = faNum(Math.max(0, likes)); }
        if (liked) { btn.classList.add('is-liked'); } else { btn.classList.remove('is-liked'); }
        btn.setAttribute('data-likes', String(Math.max(0, likes)));
        btn.setAttribute('data-liked', liked ? '1' : '0');
        btn.setAttribute('aria-pressed', liked ? 'true' : 'false');
    }

    /** پنهان/نمایش جعبهٔ شناور پس از تأیید سرور */
    function applyFloatVisibility(floatBox, liked, delay) {
        if (!floatBox) { return; }
        if (liked) {
            window.setTimeout(function () {
                floatBox.classList.add('is-hidden');
            }, delay);
        } else {
            floatBox.classList.remove('is-hidden');
        }
    }

    function initLikeButton() {
        var likeBtn = document.getElementById('skyler-like-btn');
        if (!likeBtn || !likeBtn.getAttribute('data-cid')) { return; }
        var likeBusy = false;
        var floatBox = document.getElementById('skylerLikeFloat');

        // اگر از ابتدا پسندیده شده، دکمهٔ شناور پنهان است
        if (floatBox && likeBtn.getAttribute('data-liked') === '1') {
            floatBox.classList.add('is-hidden');
        }

        likeBtn.addEventListener('click', function () {
            if (likeBusy) { return; }
            likeBusy = true;

            var cid = String(likeBtn.getAttribute('data-cid') || '');
            var before = {
                likes: parseInt(likeBtn.getAttribute('data-likes'), 10) || 0,
                liked: likeBtn.getAttribute('data-liked') === '1'
            };
            var delta = before.liked ? -1 : 1;

            // رابط خوش‌بینانه
            paintLike(likeBtn, before.likes + delta, !before.liked);
            if (delta > 0) {
                likeBtn.classList.add('pop');
                window.setTimeout(function () { likeBtn.classList.remove('pop'); }, 650);
            }

            var body = new URLSearchParams();
            body.append('skylerLike', cid);

            fetch(window.location.href, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: body.toString(),
                credentials: 'same-origin'
            })
                .then(function (res) { return res.json(); })
                .then(function (data) {
                    likeBusy = false;
                    if (!data || !data.ok) {
                        paintLike(likeBtn, before.likes, before.liked);
                        applyFloatVisibility(floatBox, before.liked, 0);
                        return;
                    }
                    paintLike(likeBtn, data.likes, data.liked);
                    // پس از پسندیدن، دکمهٔ شناور پنهان می‌شود
                    applyFloatVisibility(floatBox, data.liked, HIDE_DELAY);
                })
                .catch(function () {
                    likeBusy = false;
                    paintLike(likeBtn, before.likes, before.liked);
                    applyFloatVisibility(floatBox, before.liked, 0);
                });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initLikeButton);
    } else {
        initLikeButton();
    }
})();
