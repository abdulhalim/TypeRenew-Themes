<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<!-- ---------- شروع نوار کناری (سایدبار) ---------- -->
<aside class="sidebar">
    
    <?php
    // ---------- دریافت تنظیمات ویجت‌های سایدبار ----------
    $options = $this->options->sidebarBlock;
    
    // ---------- تنظیمات پیش‌فرض در صورت خالی بودن ----------
    if (empty($options)) {
        $options = ['ShowSearch', 'ShowAboutAuthor', 'ShowRecentPosts', 'ShowRecentComments', 'ShowCategory', 'ShowTags'];
    }
    ?>

    <!-- ---------- ویجت ۱: جستجو ---------- -->
    <?php if (in_array('ShowSearch', $options)): ?>
    <div class="widget">
        <h3 class="widget-title">جستجو</h3>
        <form action="<?php $this->options->siteUrl(); ?>" method="get" class="sidebar-search-form">
            <input type="text" name="s" placeholder="جستجو" class="sidebar-search-input">
            <button type="submit" class="btn-primary sidebar-search-btn">
                <i class="fa-solid fa-magnifying-glass"></i> جستجو
            </button>
        </form>
    </div>
    <?php endif; ?>

    <!-- ---------- ویجت ۲: درباره نویسنده ---------- -->
    <?php if (in_array('ShowAboutAuthor', $options)): ?>
    <?php 
        // ---------- بررسی فعال بودن استایل رنگی ----------
        $aboutClass = 'widget widget-about-author';
        if ($this->options->isAboutAuthorStyled && in_array('1', $this->options->isAboutAuthorStyled)) {
            $aboutClass .= ' widget-styled-primary';
        }
    ?>
    <div class="<?php echo $aboutClass; ?>">
        
        <?php if (in_array('ShowAboutAuthorTitle', $options)): ?>
            <h3 class="widget-title">درباره نویسنده</h3>
        <?php endif; ?>
        
        <div class="sidebar-author-box">
            
            <?php
            // ---------- منطق نمایش آواتار نویسنده ----------
            // اولویت: تنظیم پوسته (authorAvatar) → img/avatar.png داخل پوسته → گراواتار
            $avatarUrl = getAuthorAvatar(null);
            $skylerAvatarFallback = skyler_local_avatar_url();
            ?>
            
            <!-- ---------- تصویر آواتار ---------- -->
            <div class="text-center author-avatar-container">
                <img src="<?php echo htmlspecialchars($avatarUrl); ?>" alt="نویسنده" class="sidebar-author-avatar"<?php echo ($skylerAvatarFallback !== '' && $avatarUrl !== $skylerAvatarFallback) ? ' onerror="this.onerror=null; this.src=\'' . htmlspecialchars($skylerAvatarFallback, ENT_QUOTES) . '\';"' : ''; ?>>
            </div>
            
            <!-- ---------- نام نویسنده (داینامیک: نام/نام خانوادگی تنظیمات → نام مدیر → عنوان سایت) ---------- -->
            <?php $skylerSidebarName = skyler_author_display_name(); ?>
            <?php if ($skylerSidebarName !== ''): ?>
                <h4 class="author-name text-center"><?php echo htmlspecialchars($skylerSidebarName); ?></h4>
            <?php endif; ?>
            
            <!-- ---------- بیوگرافی نویسنده ---------- -->
            <?php if ($this->options->authorBio): ?>
                <p class="sidebar-author-bio text-center">
                    <?php echo $this->options->authorBio; ?>
                </p>
            <?php endif; ?>
            
            <!-- ---------- دکمه بیشتر بدانید ---------- -->
            <div class="text-center author-links">
                <?php 
                $linkTarget = $this->options->aboutAuthorPage ? $this->options->aboutAuthorPage : $this->options->siteUrl . 'about.html';
                ?>
                <a href="<?php echo $linkTarget; ?>" class="btn-secondary sidebar-author-link">
                    <i class="fa-solid fa-user"></i> بیشتر بدانید
                </a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- ---------- ویجت ۳: آخرین نوشته‌ها ---------- -->
    <?php if (in_array('ShowRecentPosts', $options)): ?>
    <div class="widget">
        <h3 class="widget-title">آخرین نوشته‌ها</h3>
        <?php $this->widget('Widget_Contents_Post_Recent', 'pageSize=5')->to($recent); ?>
        <?php if ($recent->have()): ?>
            <ul class="sidebar-recent-posts">
                <?php while ($recent->next()): ?>
                <li>
                    <a href="<?php $recent->permalink(); ?>" title="<?php $recent->title(); ?>">
                        <i class="fa-regular fa-file-lines sidebar-post-icon"></i>
                        <?php $recent->title(40, '...'); ?>
                    </a>
                </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p class="sidebar-no-content">هنوز مطلبی نوشته نشده است.</p>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- ---------- ویجت ۴: نظرات اخیر ---------- -->
    <?php if (in_array('ShowRecentComments', $options)): ?>
    <div class="widget">
        <h3 class="widget-title">نظرات اخیر</h3>
        <?php $this->widget('Widget_Comments_Recent', 'pageSize=5')->to($comments); ?>
        <?php if ($comments->have()): ?>
            <ul class="sidebar-recent-comments">
                <?php while ($comments->next()): ?>
                <li>
                    <a href="<?php $comments->permalink(); ?>" class="sidebar-comment-link">
                        <strong class="sidebar-comment-author"><?php $comments->author(false); ?></strong>
                        <span class="sidebar-comment-excerpt">
                            <?php $comments->excerpt(35, '...'); ?>
                        </span>
                    </a>
                </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p class="sidebar-no-content">هنوز نظری ثبت نشده است.</p>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- ---------- ویجت ۵: دسته‌بندی‌ها ---------- -->
    <?php if (in_array('ShowCategory', $options)): ?>
    <div class="widget">
        <h3 class="widget-title">دسته‌بندی‌ها</h3>
        <?php $this->widget('Widget_Metas_Category_List')->to($category); ?>
        <?php if ($category->have()): ?>
            <?php $skylerSidebarCatIcons = parseCustomIcons($this->options->categoryIcons); ?>
            <ul class="sidebar-categories">
                <?php while ($category->next()): 
                    $skylerCatIcon = isset($skylerSidebarCatIcons[$category->slug])
                        ? skyler_fa_class($skylerSidebarCatIcons[$category->slug], 'fa-folder')
                        : 'fa-regular fa-folder';
                ?>
                <li>
                    <a href="<?php $category->permalink(); ?>" title="<?php $category->name(); ?>" class="sidebar-category-link">
                        <i class="<?php echo htmlspecialchars($skylerCatIcon); ?> sidebar-category-icon"></i>
                        <?php $category->name(); ?>
                        <span class="sidebar-category-count">(<?php $category->count(); ?>)</span>
                    </a>
                </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p class="sidebar-no-content">دسته‌بندی یافت نشد.</p>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- ---------- ویجت ۶: ابر برچسب‌ها ---------- -->
    <?php if (in_array('ShowTags', $options)): ?>
    <div class="widget">
        <h3 class="widget-title">ابر برچسب‌ها</h3>
        <?php $this->widget('Widget_Metas_Tag_Cloud', 'sort=mid&ignoreZeroCount=1&desc=0&limit=20')->to($tags); ?>
        <?php if ($tags->have()): ?>
            <div class="sidebar-tags-cloud">
                <?php while ($tags->next()): ?>
                <a href="<?php $tags->permalink(); ?>" class="sidebar-tag-item">
                    <?php $tags->name(); ?>
                </a>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p class="sidebar-no-content">برچسبی یافت نشد.</p>
        <?php endif; ?>
    </div>
    <?php endif; ?>

</aside>
<!-- ---------- پایان نوار کناری (سایدبار) ---------- -->