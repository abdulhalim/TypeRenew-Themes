<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;


/* ================================================================
 *  ۱) ابزارهای عمومی
 * ================================================================ */

/** خواندن تنظیم پوسته با مقدار پیش‌فرض */
function skyler_opt($name, $default = null)
{
    try {
        $value = Typecho_Widget::widget('Widget_Options')->{$name};
    } catch (Exception $e) {
        $value = null;
    }
    return ($value === null || $value === '') ? $default : $value;
}

/** تبدیل ارقام لاتین به فارسی */
if (!function_exists('toPersianNumbers')) {
    function toPersianNumbers($num)
    {
        $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return str_replace(['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], $persian, (string)$num);
    }
}

/** عدد با جداکنندهٔ هزارگان فارسی: 1234 → ۱٬۲۳۴ */
function skyler_num($num)
{
    return toPersianNumbers(str_replace(',', '٬', number_format(max(0, (int)$num))));
}

/** آیا پلاگین ViewsCounter فعال است؟ */
function skyler_views_counter_active()
{
    static $active = null;
    if ($active !== null) {
        return $active;
    }
    $active = false;
    try {
        $activated = Typecho_Widget::widget('Widget_Options')->plugins;
        if (is_array($activated) && isset($activated['activated']['ViewsCounter'])) {
            $active = true;
        }
    } catch (Exception $e) {
    }
    return $active;
}

/* ================================================================
 *  ۱-۲) تصویر شاخص نوشته — با پشتیبانی فیلد thumb دیتابیس
 *      اولویت: فیلد سفارشی banner → فیلد thumb ثبت‌شده در
 *      دیتابیس (پوسته‌های قبلی) → اولین تصویر محتوا →
 *      تصویر پیش‌فرض پوسته → تصویر تصادفی
 * ================================================================ */

/** خواندن امن یک فیلد سفارشی (رشته یا آرایه) */
function skyler_field_str($fields, $name)
{
    try {
        $raw = $fields->{$name};
    } catch (Exception $e) {
        $raw = null;
    }
    if ($raw === null || $raw === '') {
        return '';
    }
    if (is_array($raw)) {
        foreach ($raw as $v) {
            if (is_string($v) && trim($v) !== '') {
                return trim($v);
            }
        }
        return '';
    }
    return trim((string)$raw);
}

/** تصویر شاخص نوشته با اولویت کامل (کاور کارت‌ها و بنر پست)
 *  $fallback = false فقط برای بنر پست (بدون تصویر پیش‌فرض/تصادفی) */
function skyler_post_banner($archive, $fallback = true)
{
    // اولویت ۱: فیلد سفارشی banner پوسته
    $banner = skyler_field_str($archive->fields, 'banner');
    if ($banner !== '') {
        return $banner;
    }

    // اولویت ۲: فیلد thumb که قبلاً در دیتابیس ثبت شده (پوسته‌های دیگر)
    $banner = skyler_field_str($archive->fields, 'thumb');
    if ($banner !== '') {
        return $banner;
    }

    // اولویت ۳: اولین تصویر داخل محتوای نوشته
    if (preg_match('/<img[^>]+src=[\'"](.*?)[\'"][^>]*>/i', (string)$archive->content, $matches)
        && !empty($matches[1])
    ) {
        return $matches[1];
    }

    // بدون تصویر پیش‌فرض (حالت بنر پست)
    if (!$fallback) {
        return '';
    }

    // اولویت ۴: تصویر پیش‌فرض پوسته
    $themeDir = basename(__DIR__);
    $defaultPath = __TYPECHO_ROOT_DIR__ . '/usr/themes/' . $themeDir . '/img/default-image.jpg';
    if (file_exists($defaultPath)) {
        return Typecho_Widget::widget('Widget_Options')->siteUrl . 'usr/themes/' . $themeDir . '/img/default-image.jpg';
    }

    // آخرین چاره: تصویر تصادفی
    return 'https://picsum.photos/seed/' . (int)$archive->cid . '/600/400';
}

/* ================================================================
 *  ۲) تاریخ شمسی داخلی (بدون نیاز به افزونه)
 * ================================================================ */

/** تبدیل میلادی به جلالی */
function skyler_to_jalali($gy, $gm, $gd)
{
    $gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

    $jy = ($gy <= 1600) ? 0 : 979;
    $gy -= ($gy <= 1600) ? 621 : 1600;

    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = (365 * $gy)
        + intdiv($gy2 + 3, 4)
        - intdiv($gy2 + 99, 100)
        + intdiv($gy2 + 399, 400)
        - 80
        + $gd
        + $gdm[$gm - 1];

    $jy += 33 * intdiv($days, 12053);
    $days %= 12053;
    $jy += 4 * intdiv($days, 1461);
    $days %= 1461;

    if ($days > 365) {
        $jy += intdiv($days - 1, 365);
        $days = ($days - 1) % 365;
    }

    if ($days < 186) {
        $jm = 1 + intdiv($days, 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + intdiv($days - 186, 30);
        $jd = 1 + (($days - 186) % 30);
    }

    return [$jy, $jm, $jd];
}

/** تاریخ شمسی — اگر افزونهٔ jalali_date موجود باشد از همان، وگرنه تبدیل داخلی */
if (!function_exists('getLocalizedDate')) {
    function getLocalizedDate($timestamp = NULL, $format = 'Y/m/d')
    {
        if ($timestamp === NULL) {
            $timestamp = time();
        } elseif (is_string($timestamp) && !is_numeric($timestamp)) {
            $timestamp = strtotime($timestamp);
        }

        if (function_exists('jalali_date')) {
            return toPersianNumbers(jalali_date($format, $timestamp));
        }

        [$jy, $jm, $jd] = skyler_to_jalali((int)date('Y', $timestamp), (int)date('n', $timestamp), (int)date('j', $timestamp));

        $out = str_replace(
            ['Y', 'm', 'd'],
            [sprintf('%04d', $jy), sprintf('%02d', $jm), sprintf('%02d', $jd)],
            $format
        );
        return toPersianNumbers($out);
    }
}

/** سال جاری شمسی برای پاورقی */
function skyler_jalali_year()
{
    if (function_exists('jalali_date')) {
        return toPersianNumbers(jalali_date('Y', time()));
    }
    [$jy] = skyler_to_jalali((int)date('Y'), (int)date('n'), (int)date('j'));
    return toPersianNumbers((string)$jy);
}

/* ================================================================
 *  ۳) آمار: ستون‌های views و likes جدول محتوا
 *     (شمارش‌ها در جدول نوشته‌ها نگه داشته می‌شوند و هنگام
 *      جابه‌جایی پوسته از دست نمی‌روند)
 * ================================================================ */

/** اطمینان از وجود ستون‌های views و likes */
function skyler_stats_ready()
{
    static $ready = null;
    if ($ready !== null) return $ready;

    $ready = false;
    try {
        $db = Typecho_Db::get();
        $prefix = $db->getPrefix();

        $columns = [];
        try {
            $rows = $db->fetchAll("SHOW COLUMNS FROM `{$prefix}contents`");
            foreach ($rows as $row) {
                $columns[] = is_array($row) ? (string)reset($row) : (string)$row->Field;
            }
        } catch (Exception $e) {
            $columns = [];
        }

        if (empty($columns)) {
            foreach (['views', 'likes'] as $col) {
                try {
                    $db->fetchRow($db->select("table.contents.{$col}")->from('table.contents')->limit(1));
                } catch (Exception $e) {
                    $db->query("ALTER TABLE `{$prefix}contents` ADD `{$col}` INT DEFAULT 0");
                }
            }
        } else {
            foreach (['views', 'likes'] as $col) {
                if (!in_array($col, $columns, true)) {
                    $db->query("ALTER TABLE `{$prefix}contents` ADD `{$col}` INT DEFAULT 0");
                }
            }
        }

        $ready = true;
    } catch (Exception $e) {
        $ready = false;
    }
    return $ready;
}

/** تعداد بازدید نوشته */
function skyler_views($archive)
{
    static $cache = [];
    $cid = is_object($archive) ? (int)$archive->cid : (int)$archive;
    if ($cid < 1) return 0;
    if (!isset($cache[$cid])) {
        $cache[$cid] = 0;
        if (skyler_stats_ready()) {
            try {
                $db = Typecho_Db::get();
                $row = $db->fetchRow(
                    $db->select('table.contents.views')->from('table.contents')->where('table.contents.cid = ?', $cid)
                );
                $cache[$cid] = $row ? max(0, (int)$row['views']) : 0;
            } catch (Exception $e) {
            }
        }
    }
    return $cache[$cid];
}

/** تعداد لایک نوشته */
function skyler_likes($archive)
{
    static $cache = [];
    $cid = is_object($archive) ? (int)$archive->cid : (int)$archive;
    if ($cid < 1) return 0;
    if (!isset($cache[$cid])) {
        $cache[$cid] = 0;
        if (skyler_stats_ready()) {
            try {
                $db = Typecho_Db::get();
                $row = $db->fetchRow(
                    $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
                );
                $cache[$cid] = $row ? max(0, (int)$row['likes']) : 0;
            } catch (Exception $e) {
            }
        }
    }
    return $cache[$cid];
}

/* ================================================================
 *  ۴) شمارش بازدید
 * ================================================================ */

/** شمارش بازدید صفحات تکی با کوکی ضد تکرار */
function skyler_count_view($archive)
{
    // اگر پلاگین ViewsCounter فعال است، پوسته کنار می‌کشد
    if (skyler_views_counter_active()) {
        return;
    }

    // بازدید مدیر، طبق تنظیم
    try {
        $countAdmin = Typecho_Widget::widget('Widget_Options')->skylerCountAdminViews;
        if (Typecho_Widget::widget('Widget_User')->hasLogin() && !$countAdmin) {
            return;
        }
    } catch (Exception $e) {
    }

    if (!is_object($archive) || !method_exists($archive, 'is') || !$archive->is('single')) {
        return;
    }

    $cid = (int)$archive->cid;
    if ($cid < 1 || !skyler_stats_ready()) return;

    // بازدید تکراری همین بازدیدکننده تا ۶ ساعت شمرده نمی‌شود
    try {
        $viewed = (string)Typecho_Cookie::get('skylerViews', '');
        if ($viewed !== '') {
            $ids = explode(',', $viewed);
            if (in_array((string)$cid, $ids, true)) return;
            $ids[] = (string)$cid;
            if (count($ids) > 100) $ids = array_slice($ids, -100);
            Typecho_Cookie::set('skylerViews', implode(',', $ids), time() + 21600);
        } else {
            Typecho_Cookie::set('skylerViews', (string)$cid, time() + 21600);
        }
    } catch (Exception $e) {
    }

    try {
        $db = Typecho_Db::get();
        $db->query(
            $db->update('table.contents')
                ->expression('views', 'views + 1')
                ->where('table.contents.cid = ?', $cid)
        );
    } catch (Exception $e) {
    }
}

/* ================================================================
 *  ۵) لایک — ستون likes + نقطهٔ پایانی AJAX
 * ================================================================ */

/** شناسه‌های لایک‌شدهٔ این بازدیدکننده (کوکی skylerLikes) */
function skyler_user_likes()
{
    $raw = (string)Typecho_Cookie::get('skylerLikes', '');
    if ($raw === '') return [];
    $ids = [];
    foreach (explode(',', $raw) as $id) {
        $id = trim($id);
        if ($id !== '' && ctype_digit($id) && !in_array($id, $ids, true)) {
            $ids[] = $id;
        }
    }
    return $ids;
}

/** آیا این بازدیدکننده این نوشته را لایک کرده؟ */
function skyler_is_liked($cid)
{
    return $cid > 0 && in_array((string)$cid, skyler_user_likes(), true);
}

/** خروجی JSON و پایان درخواست */
function skyler_json($payload, $status = 200)
{
    try {
        $response = Typecho_Response::getInstance();
        $response->setStatus($status);
        $response->setContentType('application/json');
        $response->addResponder(function () use ($payload) {
            echo json_encode($payload, JSON_UNESCAPED_UNICODE);
        });
        $response->respond();
    } catch (Exception $e) {
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=UTF-8', true, $status);
        }
        echo json_encode($payload, JSON_UNESCAPED_UNICODE);
        exit;
    }
    exit;
}

/** پردازش درخواست لایک — POST با پارامتر skylerLike=<cid> */
function skyler_handle_like($request)
{
    $cid = (int)(string)$request->get('skylerLike');

    if ($cid < 1) {
        skyler_json(['ok' => false, 'error' => 'bad-request'], 400);
        return;
    }

    // جلوگیری ساده از CSRF
    $siteHost = (string)parse_url((string)Typecho_Widget::widget('Widget_Options')->siteUrl, PHP_URL_HOST);
    $referer = (string)($_SERVER['HTTP_REFERER'] ?? '');
    if ($referer !== '' && $siteHost !== '' && stripos($referer, $siteHost) === false) {
        skyler_json(['ok' => false, 'error' => 'cross-origin'], 403);
        return;
    }

    if (!skyler_stats_ready()) {
        skyler_json(['ok' => false, 'error' => 'db-error'], 500);
        return;
    }

    try {
        $db = Typecho_Db::get();
        $row = $db->fetchRow(
            $db->select('table.contents.type', 'table.contents.status', 'table.contents.password', 'table.contents.created')
                ->from('table.contents')
                ->where('table.contents.cid = ?', $cid)
        );

        $valid = is_array($row)
            && $row['status'] === 'publish'
            && in_array($row['type'], ['post', 'page'], true)
            && empty($row['password'])
            && (int)$row['created'] <= Typecho_Widget::widget('Widget_Options')->time;

        if (!$valid) {
            skyler_json(['ok' => false, 'error' => 'not-found'], 404);
            return;
        }

        $likedIds = skyler_user_likes();
        $wasLiked = in_array((string)$cid, $likedIds, true);

        if ($wasLiked) {
            $likedIds = array_values(array_filter(
                $likedIds,
                function ($id) use ($cid) {
                    return $id !== (string)$cid;
                }
            ));
            $delta = -1;
        } else {
            $likedIds[] = (string)$cid;
            $delta = 1;
        }

        if (count($likedIds) > 200) {
            $likedIds = array_slice($likedIds, -200);
        }
        Typecho_Cookie::set('skylerLikes', implode(',', $likedIds), time() + 31536000);

        $current = (int)$db->fetchObject(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        )->likes;

        if ($delta > 0 || $current > 0) {
            $db->query(
                $db->update('table.contents')
                    ->expression('likes', $delta > 0 ? 'likes + 1' : 'likes - 1')
                    ->where('table.contents.cid = ?', $cid)
            );
        }

        $newLikes = (int)$db->fetchObject(
            $db->select('table.contents.likes')->from('table.contents')->where('table.contents.cid = ?', $cid)
        )->likes;

        skyler_json([
            'ok'    => true,
            'likes' => $newLikes,
            'liked' => !$wasLiked,
        ]);
    } catch (Exception $e) {
        skyler_json(['ok' => false, 'error' => 'server-error'], 500);
    }
}

/* ================================================================
 *  ۶) راه‌انداز پوسته
 * ================================================================ */

function themeInit($archive)
{
    // هوک شمارش بازدید قبل از رندر
    Typecho_Plugin::factory('Widget\Archive')->beforeRender = 'skyler_count_view';

    if ($archive->request->isPost() && $archive->request->is('skylerLike')) {
        skyler_handle_like($archive->request);
    }
}

/* ================================================================
 *  ۷) آیکون‌های سفارشی (آیکون پیکر)
 * ================================================================ */

/** تبدیل JSON آیکون‌ها به آرایه */
function parseCustomIcons($jsonString)
{
    if (empty($jsonString)) return [];
    $decoded = json_decode((string)$jsonString, true);
    return is_array($decoded) ? $decoded : [];
}

/** دریافت کلاس آیکون برای دسته‌بندی */
function getCategoryIcon($slug)
{
    static $icons = null;
    if ($icons === null) {
        try {
            $json = Typecho_Widget::widget('Widget_Options')->categoryIcons;
        } catch (Exception $e) {
            $json = null;
        }
        $icons = parseCustomIcons($json);
    }
    return isset($icons[$slug]) ? $icons[$slug] : 'fa-folder';
}

/** دریافت کلاس آیکون برای صفحه */
function getPageIcon($slug)
{
    static $icons = null;
    if ($icons === null) {
        try {
            $json = Typecho_Widget::widget('Widget_Options')->pageIcons;
        } catch (Exception $e) {
            $json = null;
        }
        $icons = parseCustomIcons($json);
    }
    return isset($icons[$slug]) ? $icons[$slug] : 'fa-file-lines';
}

/** نرمال‌سازی کلاس فونت‌آیکون: هر مقداری کار کند (fa-x / x / fa-solid fa-x / fas fa-x) */
function skyler_fa_class($value, $default = 'fa-user')
{
    $v = trim((string)$value);
    if ($v === '') {
        $v = (string)$default;
    }
    // جدا کردن پیشوندها
    $v = preg_replace('/^(fa-solid|fa-regular|fa-brands|fas|far|fab|fa)\s+/iu', '', $v);
    $v = trim($v);
    if ($v === '') {
        $v = (string)$default;
    }
    if (!preg_match('/^fa-/iu', $v)) {
        $v = 'fa-' . $v;
    }
    return 'fas ' . $v;
}

/** خروجی امن آیکون: <i class="fa-solid fa-x"></i> */
function skyler_icon($value, $default = 'fa-folder')
{
    echo '<i class="fa-solid ' . htmlspecialchars(substr(skyler_fa_class($value, $default), 4), ENT_QUOTES) . '"></i>';
}

/* ================================================================
 *  ۸) گالری گرید دوتایی تصاویر محتوا
 *     پاراگراف‌های پیوستهٔ «فقط-تصویر» (تصاویر مارک‌داون، تصاویرِ
 *     لینک‌شده و لینک‌های مستقیم تصویر) به گرید بندانگشتی دوتایی
 *     تبدیل می‌شوند — مثل پوسته‌های گالری‌دار.
 * ================================================================ */

/** آیا این نشانی به فایل تصویر اشاره می‌کند؟ */
function skyler_is_image_url($url)
{
    return (bool)preg_match('~\.(jpe?g|png|gif|webp|avif|bmp|svg)(?:[?#]|$)~iu', (string)$url);
}

/** سلول‌های تصویرِ یک پاراگراف — null یعنی پاراگراف فقط-تصویر نیست
 *  خروجی: فهرستی از [imgElement|null, linkElement|null, src, href] */
function skyler_para_image_cells($p)
{
    $cells = [];
    foreach ($p->childNodes as $ch) {
        // متن سفید-فاصله و <br> نادیده گرفته می‌شوند
        if ($ch instanceof DOMText) {
            if (trim($ch->wholeText) !== '') return null;
            continue;
        }
        if (!($ch instanceof DOMElement)) return null;
        if ($ch->nodeName === 'br') continue;

        if ($ch->nodeName === 'img') {
            $src = trim($ch->getAttribute('src'));
            if ($src === '') return null;
            $cells[] = ['img' => $ch, 'a' => null, 'src' => $src, 'href' => null];
            continue;
        }

        if ($ch->nodeName === 'a') {
            $href = trim($ch->getAttribute('href'));
            $imgs = [];
            $hasText = false;
            foreach ($ch->childNodes as $gch) {
                if ($gch instanceof DOMText) {
                    if (trim($gch->wholeText) !== '') $hasText = true;
                    continue;
                }
                if ($gch instanceof DOMElement && $gch->nodeName === 'img') {
                    $imgs[] = $gch;
                    continue;
                }
                return null; // عنصر دیگر داخل لینک
            }
            if (count($imgs) === 1 && !$hasText) {
                // [![بندانگشتی](thumb)](full) — تصویرِ لینک‌شده
                $src = trim($imgs[0]->getAttribute('src'));
                if ($src === '') return null;
                $cells[] = ['img' => $imgs[0], 'a' => $ch, 'src' => $src, 'href' => $href];
                continue;
            }
            if (count($imgs) === 0 && $href !== '' && skyler_is_image_url($href)) {
                // لینک مستقیم تصویر: https://…/photo.jpg (متن لینک هرچه باشد)
                $cells[] = ['img' => null, 'a' => $ch, 'src' => $href, 'href' => $href];
                continue;
            }
            return null;
        }

        return null; // هر عنصر دیگر → پاراگراف معمولی
    }
    return $cells; // ممکن است خالی باشد (مثل <p><br></p>)
}

/** تبدیل محتوای HTML: گروه‌های پیوستهٔ تصویر → گرید دوتایی */
function skyler_image_grid($html)
{
    $html = (string)$html;
    if ($html === '' || (stripos($html, '<img') === false && stripos($html, '<a') === false)) {
        return $html;
    }
    if (!class_exists('DOMDocument')) {
        return $html;
    }

    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $wrapped = '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head>'
        . '<body><div id="skyler-grid-root">' . $html . '</div></body></html>';
    if (!$dom->loadHTML($wrapped, LIBXML_NONET)) {
        libxml_clear_errors();
        return $html;
    }
    libxml_clear_errors();

    $body = $dom->getElementsByTagName('body')->item(0);
    $root = $body ? $body->firstChild : null;
    if (!$root) {
        return $html;
    }

    // پیمایش فرزندان ریشه و یافتن گروه‌های پیوستهٔ فقط-تصویر
    $children = [];
    foreach ($root->childNodes as $node) {
        $children[] = $node;
    }

    $i = 0;
    $count = count($children);
    while ($i < $count) {
        $node = $children[$i];
        if (!($node instanceof DOMElement) || $node->nodeName !== 'p') {
            $i++;
            continue;
        }
        $cells = skyler_para_image_cells($node);
        if (!is_array($cells) || count($cells) === 0) {
            $i++;
            continue;
        }

        // گروه را تا پاراگراف بعدی فقط-تصویر ادامه بده
        $groupNodes = [$node];
        $groupCells = $cells;
        $j = $i + 1;
        while ($j < $count) {
            $next = $children[$j];
            if (!($next instanceof DOMElement) || $next->nodeName !== 'p') break;
            $nextCells = skyler_para_image_cells($next);
            if (!is_array($nextCells) || count($nextCells) === 0) break;
            $groupNodes[] = $next;
            $groupCells = array_merge($groupCells, $nextCells);
            $j++;
        }

        if (count($groupCells) >= 2) {
            // ساخت گرید
            $grid = $dom->createElement('div');
            $grid->setAttribute('class', 'skyler-img-grid');
            $grid->setAttribute('data-count', (string)count($groupCells));

            foreach ($groupCells as $cell) {
                $cellDiv = $dom->createElement('div');
                $cellDiv->setAttribute('class', 'skyler-grid-cell');

                $link = $dom->createElement('a');
                $link->setAttribute('class', 'skyler-grid-link');
                $href = ($cell['href'] !== null && $cell['href'] !== '') ? $cell['href'] : $cell['src'];
                $link->setAttribute('href', $href);

                $img = $dom->createElement('img');
                $img->setAttribute('src', $cell['src']);
                $alt = $cell['img'] ? trim($cell['img']->getAttribute('alt')) : '';
                $title = $cell['img'] ? trim($cell['img']->getAttribute('title')) : '';
                if ($alt !== '') $img->setAttribute('alt', $alt); else $img->setAttribute('alt', '');
                if ($title !== '') $img->setAttribute('title', $title);
                $img->setAttribute('loading', 'lazy');

                $link->appendChild($img);
                $cellDiv->appendChild($link);
                $grid->appendChild($cellDiv);
            }

            // جای‌گذاری گرید به‌جای نخستین پاراگراف گروه و حذف بقیه
            $firstNode = $groupNodes[0];
            $firstNode->parentNode->insertBefore($grid, $firstNode);
            foreach ($groupNodes as $gn) {
                if ($gn->parentNode) $gn->parentNode->removeChild($gn);
            }
            $i = $j;
        } else {
            $i++;
        }
    }

    $parts = [];
    foreach ($root->childNodes as $child) {
        $parts[] = $dom->saveHTML($child);
    }
    $out = implode('', $parts);
    return ($out === '') ? $html : $out;
}

/* ================================================================
 *  ۹) انتخابگر آیکون (آیکون پیکر) — بخش مدیریت
 * ================================================================ */

/** ساخت دادهٔ انتخابگر آیکون (بدون خروجی) — با کش درخواست */
function skyler_icon_picker_data()
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    $cats = [];
    try {
        // نمونهٔ اختصاصی با پسوند @ تا با پیمایشگرهای فرم/منو تداخل نکند
        $categories = Typecho_Widget::widget('Widget_Metas_Category_List@skyler-icon-picker');
        if ($categories->have()) {
            while ($categories->next()) {
                $cats[] = ['slug' => (string)$categories->slug, 'name' => (string)$categories->name];
            }
        }
    } catch (Exception $e) {
    }

    $pages = [];
    try {
        $pageList = Typecho_Widget::widget('Widget_Contents_Page_List@skyler-icon-picker');
        if ($pageList->have()) {
            while ($pageList->next()) {
                $pages[] = ['slug' => (string)$pageList->slug, 'name' => (string)$pageList->title];
            }
        }
    } catch (Exception $e) {
    }

    $cache = ['categories' => $cats, 'pages' => $pages];
    return $cache;
}

/** HTML انتخابگر آیکون برای فیلد JSON (دسته‌ها یا صفحات) */
function skyler_icon_picker_html($targetField, $defaultIcon, $title)
{
    $options = Typecho_Widget::widget('Widget_Options');
    $data = skyler_icon_picker_data();
    $items = ($targetField === 'categoryIcons') ? $data['categories'] : $data['pages'];

    if (empty($items)) {
        return '<span class="skyler-picker-root" data-target="' . htmlspecialchars($targetField) . '" '
            . 'data-default="' . htmlspecialchars($defaultIcon) . '" data-themeurl="' . htmlspecialchars((string)$options->themeUrl) . '" '
            . 'data-title="' . htmlspecialchars($title) . '"></span>'
            . skyler_picker_script_tag((string)$options->themeUrl);
    }

    return '<span class="skyler-picker-root" data-target="' . htmlspecialchars($targetField) . '" '
        . 'data-default="' . htmlspecialchars($defaultIcon) . '" '
        . 'data-items="' . htmlspecialchars(json_encode($items, JSON_UNESCAPED_UNICODE), ENT_QUOTES) . '" '
        . 'data-themeurl="' . htmlspecialchars((string)$options->themeUrl) . '" '
        . 'data-title="' . htmlspecialchars($title) . '"></span>'
        . skyler_picker_script_tag((string)$options->themeUrl);
}

/** HTML انتخابگر آیکون برای فیلد متن تکی */
function skyler_single_icon_picker_html($targetField, $defaultIcon, $title)
{
    $options = Typecho_Widget::widget('Widget_Options');

    return '<span class="skyler-picker-root" data-target="' . htmlspecialchars($targetField) . '" '
        . 'data-default="' . htmlspecialchars($defaultIcon) . '" data-single="1" '
        . 'data-themeurl="' . htmlspecialchars((string)$options->themeUrl) . '" '
        . 'data-title="' . htmlspecialchars($title) . '"></span>'
        . skyler_picker_script_tag((string)$options->themeUrl);
}

/** تگ اسکریپت انتخابگر (یک‌بار در هر درخواست تزریق می‌شود) */
function skyler_picker_script_tag($themeUrl)
{
    if (!empty($GLOBALS['skyler_picker_script_included'])) {
        return '';
    }
    $GLOBALS['skyler_picker_script_included'] = true;
    return '<script defer src="' . htmlspecialchars($themeUrl) . '/js/admin-icon-picker.js"></script>';
}

/* ================================================================
 *  ۱۰) تنظیمات پوسته
 * ================================================================ */

/**
 * تنظیمات اصلی پوسته
 */
function themeConfig($form) {
    // ---------- تنظیمات عمومی ----------
    
    $logoUrl = new Typecho_Widget_Helper_Form_Element_Text(
        'logoUrl', 
        NULL, 
        NULL, 
        _t('آدرس لوگو سایت'), 
        _t('آدرس تصویر لوگو را وارد کنید.')
    );
    $form->addInput($logoUrl->addRule('url', _t('لطفا آدرس معتبر وارد کنید')));

    $favicon = new Typecho_Widget_Helper_Form_Element_Text(
        'favicon', 
        NULL, 
        NULL, 
        _t('آدرس فاویکون'), 
        _t('آدرس فایل فاویکون سایت (.ico, .png, .svg) را وارد کنید.')
    );
    $form->addInput($favicon);

    $authorAvatar = new Typecho_Widget_Helper_Form_Element_Text(
        'authorAvatar', 
        NULL, 
        NULL, 
        _t('آدرس آواتار نویسنده'), 
        _t('آدرس عکس پروفایل را وارد کنید.')
    );
    $form->addInput($authorAvatar);

    $authorBio = new Typecho_Widget_Helper_Form_Element_Textarea(
        'authorBio',
        NULL,
        NULL,
        _t('توضیحات کوتاه درباره نویسنده'),
        _t('این متن در سایدبار نمایش داده می‌شود.')
    );
    $form->addInput($authorBio);

    // ---------- تنظیمات هدر صفحهٔ اصلی (ایندکس نوشته‌ها) ----------

    $skylerIndexTitle = new Typecho_Widget_Helper_Form_Element_Text(
        'skylerIndexTitle',
        NULL,
        'پوسته اسکایلر',
        _t('عنوان صفحهٔ اصلی'),
        _t('عنوان بزرگ (H1) بالای فهرست نوشته‌ها در صفحهٔ اول. آخرین کلمهٔ عنوان به رنگ اصلی پوسته برجسته می‌شود. اگر خالی باشد، عنوان سایت نمایش داده می‌شود.')
    );
    $form->addInput($skylerIndexTitle);

    $skylerIndexSubtitle = new Typecho_Widget_Helper_Form_Element_Text(
        'skylerIndexSubtitle',
        NULL,
        'یک پوسته مدرن، زیبا و بهینه برای تایپچو با طراحی مینیمال و ریسپانسیو',
        _t('توضیح صفحهٔ اصلی'),
        _t('متن کوتاه زیر عنوان در صفحهٔ اول. اگر خالی باشد، این خط به‌کلی نمایش داده نمی‌شود.')
    );
    $form->addInput($skylerIndexSubtitle);

    // ---------- تنظیمات شبکه‌های اجتماعی ----------
    
    $socialTwitter = new Typecho_Widget_Helper_Form_Element_Text('socialTwitter', NULL, NULL, _t('لینک توییتر (X)'), _t('آدرس پروفایل توییتر خود را وارد کنید.'));
    $form->addInput($socialTwitter->addRule('url', _t('آدرس معتبر نیست')));

    $socialTelegram = new Typecho_Widget_Helper_Form_Element_Text('socialTelegram', NULL, NULL, _t('لینک تلگرام'), _t('آدرس پروفایل تلگرام خود را وارد کنید.'));
    $form->addInput($socialTelegram->addRule('url', _t('آدرس معتبر نیست')));

    $socialInstagram = new Typecho_Widget_Helper_Form_Element_Text('socialInstagram', NULL, NULL, _t('لینک اینستاگرام'), _t('آدرس پروفایل اینستاگرام خود را وارد کنید.'));
    $form->addInput($socialInstagram->addRule('url', _t('آدرس معتبر نیست')));

    $socialLinkedin = new Typecho_Widget_Helper_Form_Element_Text('socialLinkedin', NULL, NULL, _t('لینک لینکدین'), _t('آدرس پروفایل لینکدین خود را وارد کنید.'));
    $form->addInput($socialLinkedin->addRule('url', _t('آدرس معتبر نیست')));

    $socialGithub = new Typecho_Widget_Helper_Form_Element_Text('socialGithub', NULL, NULL, _t('لینک گیت‌هاب'), _t('آدرس پروفایل گیت‌هاب خود را وارد کنید.'));
    $form->addInput($socialGithub->addRule('url', _t('آدرس معتبر نیست')));

    // ---------- دریافت لیست صفحات برای منوها ----------
    
    $pagesList = Typecho_Widget::widget('Widget_Contents_Page_List');
    $pageOptions = [];
    while ($pagesList->next()) {
        $pageOptions[$pagesList->permalink] = $pagesList->title;
    }

    // ---------- تنظیمات ویجت درباره نویسنده ----------
    
    $aboutAuthorPage = new Typecho_Widget_Helper_Form_Element_Select(
        'aboutAuthorPage',
        $pageOptions,
        '', 
        _t('صفحه "درباره من"'),
        _t('صفحه‌ای را که می‌خواهید دکمه "بیشتر بدانید" به آن لینک شود، انتخاب کنید.')
    );
    $form->addInput($aboutAuthorPage);

    $isAboutAuthorStyled = new Typecho_Widget_Helper_Form_Element_Checkbox(
        'isAboutAuthorStyled',
        ['1' => _t('فعال‌سازی استایل پرایمری (رنگی)')],
        [],
        _t('سبک ویژه درباره نویسنده'),
        _t('اگر این گزینه را تیک بزنید، پس‌زمینه، حاشیه و دکمه ویجت درباره نویسنده به رنگ اصلی پوسته تغییر می‌کند.')
    );
    $form->addInput($isAboutAuthorStyled->multiMode());

    // ---------- تنظیمات صفحهٔ «درباره من» — اطلاعات شخصی ----------

    $aboutBadgeText = new Typecho_Widget_Helper_Form_Element_Text(
        'aboutBadgeText',
        NULL,
        'درباره من',
        _t('متن نشان (بج) صفحهٔ درباره من'),
        _t('متن کوچکی که داخل بجِ بالای نام نمایش داده می‌شود.')
    );
    $form->addInput($aboutBadgeText);

    $aboutFirstName = new Typecho_Widget_Helper_Form_Element_Text(
        'aboutFirstName',
        NULL,
        NULL,
        _t('نام'),
        _t('نام خود را وارد کنید. در صفحهٔ «درباره من» (عنوان اصلی) و ویجت نویسندهٔ سایدبار نمایش داده می‌شود. در صورت خالی بودن، نام نمایشی مدیر سایت استفاده می‌شود.')
    );
    $form->addInput($aboutFirstName);

    $aboutLastName = new Typecho_Widget_Helper_Form_Element_Text(
        'aboutLastName',
        NULL,
        NULL,
        _t('نام خانوادگی'),
        _t('نام خانوادگی خود را وارد کنید.')
    );
    $form->addInput($aboutLastName);

    $aboutJobTitle = new Typecho_Widget_Helper_Form_Element_Text(
        'aboutJobTitle',
        NULL,
        NULL,
        _t('عنوان شغلی / زیرعنوان'),
        _t('مثال: توسعه‌دهندهٔ وب و مدرس برنامه‌نویسی. در صورت خالی بودن، «توضیحات کوتاه نویسنده» نمایش داده می‌شود.')
    );
    $form->addInput($aboutJobTitle);

    $aboutBio = new Typecho_Widget_Helper_Form_Element_Textarea(
        'aboutBio',
        NULL,
        NULL,
        _t('معرفی کامل (بیوگرافی)'),
        _t('متن معرفی صفحهٔ «درباره من». اگر خالی باشد، محتوای خود برگهٔ «درباره من» نمایش داده می‌شود.')
    );
    $form->addInput($aboutBio);

    $aboutEmail = new Typecho_Widget_Helper_Form_Element_Text(
        'aboutEmail',
        NULL,
        NULL,
        _t('ایمیل'),
        _t('در کارت «اطلاعات شخصی» نمایش داده می‌شود و به لینک ایمیل (mailto) تبدیل می‌گردد.')
    );
    $form->addInput($aboutEmail);

    $aboutPhone = new Typecho_Widget_Helper_Form_Element_Text(
        'aboutPhone',
        NULL,
        NULL,
        _t('شماره تماس'),
        _t('در کارت «اطلاعات شخصی» نمایش داده می‌شود و به لینک تلفن (tel) تبدیل می‌گردد.')
    );
    $form->addInput($aboutPhone);

    $aboutLocation = new Typecho_Widget_Helper_Form_Element_Text(
        'aboutLocation',
        NULL,
        NULL,
        _t('محل سکونت'),
        _t('مثال: تهران، ایران. در کارت «اطلاعات شخصی» نمایش داده می‌شود.')
    );
    $form->addInput($aboutLocation);

    $aboutBirthday = new Typecho_Widget_Helper_Form_Element_Text(
        'aboutBirthday',
        NULL,
        NULL,
        _t('تاریخ تولد'),
        _t('مثال: ۱۳۷۰/۰۵/۱۲. در کارت «اطلاعات شخصی» نمایش داده می‌شود.')
    );
    $form->addInput($aboutBirthday);

    $aboutEducation = new Typecho_Widget_Helper_Form_Element_Text(
        'aboutEducation',
        NULL,
        NULL,
        _t('تحصیلات'),
        _t('مثال: کارشناسی مهندسی کامپیوتر. در کارت «اطلاعات شخصی» نمایش داده می‌شود.')
    );
    $form->addInput($aboutEducation);

    $aboutLanguages = new Typecho_Widget_Helper_Form_Element_Text(
        'aboutLanguages',
        NULL,
        NULL,
        _t('زبان‌ها'),
        _t('مثال: فارسی، انگلیسی. در کارت «اطلاعات شخصی» نمایش داده می‌شود.')
    );
    $form->addInput($aboutLanguages);

    $aboutInfoTitle = new Typecho_Widget_Helper_Form_Element_Text(
        'aboutInfoTitle',
        NULL,
        'اطلاعات شخصی',
        _t('عنوان کارت اطلاعات شخصی'),
        _t('عنوان کارتی که ایمیل، تماس، سکونت و… را در صفحهٔ «درباره من» نمایش می‌دهد.')
    );
    $form->addInput($aboutInfoTitle);

    $aboutSkills = new Typecho_Widget_Helper_Form_Element_Textarea(
        'aboutSkills',
        NULL,
        NULL,
        _t('مهارت‌ها'),
        _t('هر خط یک مهارت به شکل «نام مهارت / درصد» وارد کنید (مثال: برنامه نویس / 95). درصد عددی بین ۰ تا ۱۰۰ است و می‌تواند با رقم فارسی (۹۵) و علامت ٪ یا % هم نوشته شود؛ جداکننده می‌تواند / یا | یا : باشد. هر مهارت به شکل نوار پیشرفتی نمایش داده می‌شود که با انیمیشن تا همان درصد پر می‌شود. اگر برای مهارتی درصد ننویسید، همان مهارت به شکل چیپ ساده نمایش داده می‌شود. اگر خالی باشد کارت مهارت‌ها نمایش داده نمی‌شود.')
    );
    $form->addInput($aboutSkills);

    $aboutSkillsTitle = new Typecho_Widget_Helper_Form_Element_Text(
        'aboutSkillsTitle',
        NULL,
        'مهارت‌ها',
        _t('عنوان کارت مهارت‌ها'),
        _t('عنوان کارتی که مهارت‌ها را در صفحهٔ «درباره من» نمایش می‌دهد.')
    );
    $form->addInput($aboutSkillsTitle);

    $aboutCtaText = new Typecho_Widget_Helper_Form_Element_Textarea(
        'aboutCtaText',
        NULL,
        'برای ارتباط با من یا دنبال کردن فعالیت‌هایم می‌تونید به لینک‌تری من سر بزنید یا از طریق شبکه‌های اجتماعی با من در تماس باشید.',
        _t('متن دعوت به اقدام (CTA) صفحهٔ درباره من'),
        _t('متنی که در کادر رنگی انتهای صفحهٔ «درباره من» نمایش داده می‌شود. توجه: اگر مقصد دکمه (برگهٔ لینک‌ها یا آدرس جایگزین) موجود نباشد، کل این کادر به‌کلی نمایش داده نمی‌شود.')
    );
    $form->addInput($aboutCtaText);

    $aboutCtaBtnText = new Typecho_Widget_Helper_Form_Element_Text(
        'aboutCtaBtnText',
        NULL,
        'لینک‌های من',
        _t('متن دکمهٔ CTA صفحهٔ درباره من'),
        _t('متن دکمه‌ای که داخل کادر رنگی انتهای صفحهٔ «درباره من» نمایش داده می‌شود.')
    );
    $form->addInput($aboutCtaBtnText);

    $aboutCtaBtnUrl = new Typecho_Widget_Helper_Form_Element_Text(
        'aboutCtaBtnUrl',
        NULL,
        NULL,
        _t('آدرس جایگزین دکمهٔ CTA صفحهٔ درباره من'),
        _t('آدرس جایگزین دکمهٔ CTA را وارد کنید (داخلی یا خارجی). اولویت مقصد دکمه: ۱) برگهٔ ساخته‌شده با قالب سفارشی «لینک‌ها» (صفحهٔ لینک‌تری شما) ۲) همین آدرس. اگر هیچ‌کدام موجود نباشد، کادر CTA به‌کلی نمایش داده نمی‌شود (بدون لینک شکسته). لینک‌های خارجی در تب جدید و لینک‌های داخلی در همان تب باز می‌شوند.')
    );
    $form->addInput($aboutCtaBtnUrl);


    // ---------- تنظیمات ویجت‌های سایدبار ----------
    
    $sidebarBlock = new Typecho_Widget_Helper_Form_Element_Checkbox(
        'sidebarBlock',
        [
            'ShowSearch'            => _t('نمایش جستجو'),
            'ShowAboutAuthor'       => _t('نمایش درباره نویسنده'),
            'ShowAboutAuthorTitle'  => _t('نمایش عنوان «درباره نویسنده»'),
            'ShowRecentPosts'       => _t('نمایش پست‌های اخیر'),
            'ShowRecentComments'    => _t('نمایش نظرات اخیر'),
            'ShowCategory'          => _t('نمایش دسته‌بندی'),            
            'ShowTags'             => _t('نمایش برچسب‌ها')
        ],
        ['ShowSearch', 'ShowAboutAuthor', 'ShowRecentPosts', 'ShowRecentComments', 'ShowCategory', 'ShowTags', 'ShowAboutAuthorTitle'],
        _t('نمایش نوار کناری')
    );
    $form->addInput($sidebarBlock->multiMode());

    // ---------- تنظیمات آمار: بازدید و لایک ----------

    $yes = 'روشن';
    $no  = 'خاموش';

    $showViews = new Typecho_Widget_Helper_Form_Element_Radio(
        'skylerShowViews',
        ['1' => $yes, '0' => $no],
        '1',
        _t('نمایش شمار بازدید'),
        _t('شمار بازدید در صفحهٔ خود نوشته و در کارت‌های فهرست (صفحه اصلی و آرشیو) نمایش داده می‌شود. اگر افزونهٔ ViewsCounter فعال باشد، از شمارش همان افزونه استفاده می‌شود.')
    );
    $form->addInput($showViews);

    $showLikes = new Typecho_Widget_Helper_Form_Element_Radio(
        'skylerShowLikes',
        ['1' => $yes, '0' => $no],
        '1',
        _t('دکمهٔ لایک (پسند)'),
        _t('دکمهٔ پسند در صفحهٔ خود نوشته (پایین محتوا) نمایش داده می‌شود؛ شمارش در جدول نوشته‌ها نگه داشته می‌شود.')
    );
    $form->addInput($showLikes);

    $countAdminViews = new Typecho_Widget_Helper_Form_Element_Radio(
        'skylerCountAdminViews',
        ['1' => $yes, '0' => $no],
        '0',
        _t('شمارش بازدید مدیر'),
        _t('اگر روشن باشد، بازدید کاربران واردشده (خودتان) هم شمرده می‌شود.')
    );
    $form->addInput($countAdminViews);

    // ---------- چیدمان فهرست نوشته‌ها (فهرستی / گرید کارتی) ----------

    $indexLayout = new Typecho_Widget_Helper_Form_Element_Radio(
        'skylerIndexLayout',
        [
            'list' => _t('فهرستی (کارت‌های افقی)'),
            'grid' => _t('گرید کارتی (کارت‌های عمودی دو ستونه)'),
        ],
        'list',
        _t('چیدمان نوشته‌های فهرست‌ها'),
        _t('نحوهٔ نمایش پست‌ها در صفحهٔ اصلی و فهرست‌ها را انتخاب کنید؛ حالت گرید، کارت‌ها را در دو ستون با کاور تصویری نمایش می‌دهد.')
    );
    $form->addInput($indexLayout);

    // ---------- تنظیمات دکمهٔ CTA نوار ناوبری ----------

    $navCtaText = new Typecho_Widget_Helper_Form_Element_Text(
        'navCtaText',
        NULL,
        'من را دنبال کنید',
        _t('متن دکمهٔ CTA نوار ناوبری'),
        _t('متن دکمهٔ اقدام (CTA) که در نوار ناوبری و منوی موبایل نمایش داده می‌شود.')
    );
    $form->addInput($navCtaText);

    $navCtaUrl = new Typecho_Widget_Helper_Form_Element_Text(
        'navCtaUrl',
        NULL,
        NULL,
        _t('آدرس دکمهٔ CTA نوار ناوبری'),
        _t('آدرس مقصد دکمهٔ CTA را وارد کنید (داخلی یا خارجی). اگر خالی باشد، دکمه در ناوبری نمایش داده نمی‌شود.')
    );
    $form->addInput($navCtaUrl);

    $navCtaIcon = new Typecho_Widget_Helper_Form_Element_Text(
        'navCtaIcon',
        NULL,
        'fa-user-plus',
        _t('آیکون دکمهٔ CTA نوار ناوبری'),
        _t('آیکون دکمهٔ CTA را از پنجرهٔ انتخابگر برگزینید.') . '<br>' . skyler_single_icon_picker_html('navCtaIcon', 'fa-user-plus', 'آیکون دکمهٔ CTA')
    );
    $form->addInput($navCtaIcon);

    // ---------- تنظیمات دسته‌بندی‌های منوی بالا ----------
    
    $categoryList = Typecho_Widget::widget('Widget_Metas_Category_List');
    $catOptions = [];
    while ($categoryList->next()) {
        $catOptions[$categoryList->slug] = $categoryList->name;
    }

    $navCategories = new Typecho_Widget_Helper_Form_Element_Checkbox(
        'navCategories',
        $catOptions,
        [],
        _t('دسته‌بندی‌های منوی بالا'),
        _t('دسته‌بندی‌هایی که می‌خواهید در منوی ناوبری (بین خانه و صفحات) نمایش داده شوند را انتخاب کنید.')
    );
    $form->addInput($navCategories->multiMode());

    // ---------- تنظیمات صفحات منوی بالا ----------
    
    $navPages = new Typecho_Widget_Helper_Form_Element_Checkbox(
        'navPages',
        $pageOptions,
        [],
        _t('صفحات منوی بالا'),
        _t('صفحات مستقلی که می‌خواهید در منوی بالای سایت نمایش داده شوند را انتخاب کنید.')
    );
    $form->addInput($navPages->multiMode());

    // ---------- آیکون‌های دسته‌بندی — با انتخابگر گرافیکی ----------

    $categoryIcons = new Typecho_Widget_Helper_Form_Element_Textarea(
        'categoryIcons',
        NULL,
        NULL,
        _t('آیکون‌های دسته‌بندی'),
        _t('آیکون هر دسته‌بندی را از پنجرهٔ انتخابگر برگزینید. این آیکون در منوی بالا، منوی موبایل، ویجت دسته‌بندی‌های سایدبار و متادیتای نوشته‌ها نمایش داده می‌شود.') . '<br>' . skyler_icon_picker_html('categoryIcons', 'fa-folder', 'آیکون دسته‌بندی‌ها')
    );
    $form->addInput($categoryIcons);

    // ---------- آیکون‌های صفحات — با انتخابگر گرافیکی ----------

    $pageIcons = new Typecho_Widget_Helper_Form_Element_Textarea(
        'pageIcons',
        NULL,
        NULL,
        _t('آیکون‌های صفحات'),
        _t('آیکون هر برگهٔ مستقل را از پنجرهٔ انتخابگر برگزینید. این آیکون در منوی بالا، منوی موبایل و لینک‌های فوتر نمایش داده می‌شود.') . '<br>' . skyler_icon_picker_html('pageIcons', 'fa-file-lines', 'آیکون برگه‌ها')
    );
    $form->addInput($pageIcons);

    // ---------- تنظیمات صفحات فوتر ----------
    
    $footerPages = new Typecho_Widget_Helper_Form_Element_Checkbox(
        'footerPages',
        $pageOptions,
        [],
        _t('صفحات فوتر'),
        _t('صفحاتی را که می‌خواهید در بخش فوتر سایت نمایش داده شوند را انتخاب کنید.')
    );
    $form->addInput($footerPages->multiMode());
}

/**
 * فیلدهای سفارشی نوشته‌ها
 */
function themeFields($layout) {
    // ---------- تصویر شاخص (بنر) ----------
    $banner = new Typecho_Widget_Helper_Form_Element_Text(
        'banner', 
        NULL, 
        NULL, 
        _t('آدرس تصویر شاخص (بنر)'), 
        _t('آدرس تصویر شاخص را وارد کنید.')
    );
    $layout->addItem($banner);

    // ---------- لینک دانلود فایل ----------
    $download_link = new Typecho_Widget_Helper_Form_Element_Text(
        'download_link',
        NULL,
        NULL,
        _t('لینک دانلود فایل'),
        _t('آدرس کامل فایل برای دکمه دانلود را وارد کنید.')
    );
    $layout->addItem($download_link);

    // ---------- لینک پیش‌نمایش ----------
    $preview_link = new Typecho_Widget_Helper_Form_Element_Text(
        'preview_link',
        NULL,
        NULL,
        _t('لینک پیش‌نمایش'),
        _t('آدرس کامل برای دکمه پیش‌نمایش را وارد کنید.')
    );
    $layout->addItem($preview_link);

    // ---------- گالری تصاویر ----------
    $gallery_urls = new Typecho_Widget_Helper_Form_Element_Textarea(
        'gallery_urls',
        NULL,
        NULL,
        _t('لینک‌های گالری تصاویر'),
        _t('هر آدرس تصویر را در یک خط جداگانه وارد کنید. این تصاویر به صورت گالری نمایش داده خواهند شد.')
    );
    $layout->addItem($gallery_urls);

    $gallery_style = new Typecho_Widget_Helper_Form_Element_Select(
        'gallery_style',
        [
            'style-zoom'  => _t('گرید با انیمیشن زوم (مدرن)'),
            'style-dark'  => _t('گرید با روکش تیره (کلاسیک)'),
        ],
        'style-zoom', 
        _t('استایل نمایش گالری'),
        _t('مدل نمایش تصاویر را انتخاب کنید.')
    );
    $layout->addItem($gallery_style);

    $gallery_columns = new Typecho_Widget_Helper_Form_Element_Select(
        'gallery_columns',
        [
            '2' => _t('۲ ستون'),
            '3' => _t('۳ ستون'),
            '4' => _t('۴ ستون'),
        ],
        '3', 
        _t('تعداد ستون‌ها'),
        _t('تعداد ستون‌های گالری را انتخاب کنید.')
    );
    $layout->addItem($gallery_columns);

    $gallery_ratio = new Typecho_Widget_Helper_Form_Element_Select(
        'gallery_ratio',
        [
            'landscape' => _t('۴ به ۳ (پیش‌فرض)'),
            'portrait'  => _t('عمودی (Portrait)'),
            'square'    => _t('مربع (Square)'),
        ],
        'landscape',
        _t('شکل تصاویر'),
        _t('نسبت تصویر گالری (پیش‌فرض ۴ به ۳ است و تصاویر بزرگ‌تر برش می‌خورند).')
    );
    $layout->addItem($gallery_ratio);
}

/* ================================================================
 *  ۱۱) توابع کمکی قدیمی پوسته
 * ================================================================ */

/**
 * فرمت تاریخ برای صفحه آرشیو
 */
if (!function_exists('formatArchiveDate')) {
    function formatArchiveDate($dateString) {
        $time = strtotime($dateString);
        return getLocalizedDate($time, 'Y/m/d');
    }
}

/**
 * نمایش متادیتای نوشته
 */
if (!function_exists('postMeta')) {
    function postMeta($archive) {
        $titleTag = $archive->is('post') ? 'h1' : 'h2';
    ?>
        <<?php echo $titleTag; ?> class="post-title">
            <a itemprop="url" href="<?php $archive->permalink(); ?>"><?php $archive->title() ?></a>
        </<?php echo $titleTag; ?>>
        
        <?php if (!$archive->is('page')): ?>
        <ul class="post-meta">
            <li itemprop="author"><?php _e('نویسنده'); ?>: <?php $archive->author(); ?></li>
            <li itemprop="datePublished"><?php _e('زمان'); ?>: <time><?php echo getLocalizedDate($archive->created); ?></time></li>
            <li><?php _e('دسته‌بندی'); ?>: <?php $archive->category(','); ?></li>
            <?php if ($archive->is('index')): ?>
                <li itemprop="interactionCount"><a href="<?php $archive->permalink() ?>#comments"><?php $archive->commentsNum(_t('بدون دیدگاه'), _t('1 دیدگاه'), _t('%d دیدگاه')); ?></a></li>
            <?php endif; ?>
        </ul>
        <?php endif; ?>
    <?php
    }
}

/**
 * دریافت آدرس آواتار نویسنده
 * اولویت: تنظیم پوسته (authorAvatar) → img/avatar.png داخل پوسته → گراواتار
 */
function getAuthorAvatar($email = null) {
    $options = Typecho_Widget::widget('Widget_Options');

    // اولویت ۱: آدرس آواتاری که کاربر در تنظیمات پوسته مشخص کرده است
    $settingAvatar = trim((string)$options->authorAvatar);
    if ($settingAvatar !== '') {
        return $settingAvatar;
    }

    // اولویت ۲: آواتار پیش‌فرض داخل پوسته (img/avatar.png)
    $themeDir = basename(__DIR__);
    $localAvatarPath = __TYPECHO_ROOT_DIR__ . '/usr/themes/' . $themeDir . '/img/avatar.png';
    if (file_exists($localAvatarPath)) {
        return $options->siteUrl . 'usr/themes/' . $themeDir . '/img/avatar.png';
    }

    // اولویت ۳: گراواتار (ایمیل داده‌شده؛ در نبودِ آن ایمیل مدیر سایت)
    $email = trim(strtolower((string)$email));
    if ($email === '') {
        try {
            $db = Typecho_Db::get();
            $adminUser = $db->fetchRow(
                $db->select('mail')->from('table.users')->where('table.users.group = ?', 'administrator')->limit(1)
            );
            if ($adminUser && !empty($adminUser['mail'])) {
                $email = trim(strtolower((string)$adminUser['mail']));
            }
        } catch (Exception $e) {
            $email = '';
        }
    }
    if ($email === '') {
        $email = 'guest@example.com';
    }

    $gravatarUrl = 'https://www.gravatar.com/avatar/';
    $gravatarUrl .= md5($email);
    $gravatarUrl .= "?s=200&d=mp&r=g";

    return $gravatarUrl;
}

/**
 * نام نمایشی نویسنده — اولویت: تنظیمات نام/نام خانوادگی → نام مدیر → عنوان سایت
 * (برای عنوان صفحهٔ «درباره من» و ویجت نویسندهٔ سایدبار)
 */
function skyler_author_display_name()
{
    static $name = null;
    if ($name !== null) {
        return $name;
    }

    // اولویت ۱: نام و نام خانوادگی ثبت‌شده در تنظیمات پوسته
    $first = trim((string)skyler_opt('aboutFirstName', ''));
    $last  = trim((string)skyler_opt('aboutLastName', ''));
    $full  = trim($first . ' ' . $last);

    // اولویت ۲: نام نمایشی مدیر سایت
    if ($full === '') {
        try {
            $db = Typecho_Db::get();
            $row = $db->fetchRow(
                $db->select('screenName')
                    ->from('table.users')
                    ->where('table.users.group = ?', 'administrator')
                    ->order('table.users.uid', Typecho_Db::SORT_ASC)
                    ->limit(1)
            );
            if ($row && !empty($row['screenName'])) {
                $full = (string)$row['screenName'];
            }
        } catch (Exception $e) {
            $full = '';
        }
    }

    // اولویت ۳: عنوان سایت
    if ($full === '') {
        try {
            $full = trim((string)Typecho_Widget::widget('Widget_Options')->title);
        } catch (Exception $e) {
            $full = '';
        }
    }

    $name = $full;
    return $name;
}

/**
 * آدرس آواتار محلی پوسته (برای fallback سمت مرورگر) — یا رشتهٔ خالی
 */
function skyler_local_avatar_url()
{
    static $url = null;
    if ($url !== null) {
        return $url;
    }
    $url = '';
    try {
        $options = Typecho_Widget::widget('Widget_Options');
        $themeDir = basename(__DIR__);
        $localAvatarPath = __TYPECHO_ROOT_DIR__ . '/usr/themes/' . $themeDir . '/img/avatar.png';
        if (trim((string)$options->authorAvatar) !== '') {
            $url = trim((string)$options->authorAvatar);
        } elseif (file_exists($localAvatarPath)) {
            $url = $options->siteUrl . 'usr/themes/' . $themeDir . '/img/avatar.png';
        }
    } catch (Exception $e) {
        $url = '';
    }
    return $url;
}

/**
 * آدرس صفحهٔ لینک‌تری — سازگاری با نسخه‌های پیشین (اسم مستعار)
 * @deprecated از skyler_cta_url() استفاده کنید
 */
function skyler_links_page_url()
{
    return skyler_cta_url();
}

/**
 * مقصد دکمهٔ CTA صفحهٔ «درباره من»
 *
 * اولویت:
 *  ۱) صفحهٔ سفارشی لینک‌تری — برگهٔ منتشرشده‌ای که با قالب سفارشی «لینک‌ها»
 *     (links.php) ساخته شده است (پیوند دائمی واقعی همان برگه)
 *  ۲) آدرس جایگزین دکمه (aboutCtaBtnUrl) از تنظیمات پوسته (داخلی یا خارجی)
 *
 * اگر هیچ‌کدام موجود نباشد رشتهٔ خالی برمی‌گردد؛ در این حالت کل کادر CTA
 * صفحهٔ «درباره من» نمایش داده نمی‌شود (هیچ لینک شکسته/404ای ساخته نمی‌شود).
 */
function skyler_cta_url()
{
    // اولویت ۱: صفحهٔ سفارشی لینک‌تری — برگهٔ ساخته‌شده با قالب «لینک‌ها»
    // (از پیوند دائمی واقعی همان برگه استفاده می‌شود؛ مستقل از نامکِ صفحه)
    try {
        $pages = Typecho_Widget::widget('Widget_Contents_Page_List@skylerLinks');
        while ($pages->next()) {
            $tpl = strtolower(trim((string)$pages->template));
            if ($tpl === 'links' || $tpl === 'links.php') {
                $permalink = trim((string)$pages->permalink);
                if ($permalink !== '') {
                    return $permalink;
                }
            }
        }
    } catch (Exception $e) {
        // ستون قالب در دسترس نیست یا ویدجت خطا داد → سراغ اولویت ۲ برو
    }

    // اولویت ۲: آدرس جایگزین دکمهٔ CTA از تنظیمات پوسته
    $url = trim((string)skyler_opt('aboutCtaBtnUrl', ''));
    if ($url !== '') {
        // نرمال‌سازی آدرس نسبیِ بدون اسلش آغازین (مثل «links.html»)
        if ($url[0] !== '/' && !preg_match('~^(https?://|//|mailto:|tel:)~i', $url)) {
            $siteUrl = '';
            try {
                $siteUrl = rtrim((string)Typecho_Widget::widget('Widget_Options')->siteUrl, '/');
            } catch (Exception $e) {
            }
            $url = ($siteUrl !== '' ? $siteUrl . '/' : '/') . ltrim($url, '/');
        }
        return $url;
    }

    // هیچ مقصدی موجود نیست → رشتهٔ خالی (کادر CTA نمایش داده نمی‌شود)
    return '';
}

/**
 * خواندن خام تنظیم: null = تنظیم‌نشده/ذخیره‌نشده؛ '' = کاربر عمداً خالی کرده
 * (برخلاف skyler_opt که مقدار خالی را با پیش‌فرض جایگزین می‌کند)
 */
function skyler_opt_raw($name)
{
    try {
        return Typecho_Widget::widget('Widget_Options')->{$name};
    } catch (Exception $e) {
        return null;
    }
}

/**
 * عنوان صفحهٔ اصلی (H1) — از تنظیم «عنوان صفحهٔ اصلی».
 * تنظیم‌نشده → پیش‌فرض «پوسته اسکایلر»؛ خالی‌شده → عنوان سایت.
 * آخرین کلمهٔ عنوان با رنگ اصلی پوسته برجسته می‌شود؛ نتیجهٔ خالی = عدم نمایش H1.
 */
function skyler_index_title_html()
{
    $raw = skyler_opt_raw('skylerIndexTitle');
    $title = ($raw === null) ? 'پوسته اسکایلر' : trim((string)$raw);

    // کاربر فیلد را خالی کرده است → عنوان سایت
    if ($title === '') {
        $title = trim((string)skyler_opt_raw('title'));
    }
    if ($title === '') {
        return '';
    }

    // تک‌کلمه: کل عنوان داخل span رنگی؛ چندکلمه: فقط آخرین کلمه
    $words = preg_split('~\s+~u', $title);
    $last = array_pop($words);
    $first = implode(' ', $words);

    $html = '';
    if ($first !== '') {
        $html .= htmlspecialchars($first, ENT_QUOTES) . ' ';
    }
    $html .= '<span style="font-size: 2.5rem; color: var(--primary);">'
        . htmlspecialchars($last, ENT_QUOTES) . '</span>';
    return $html;
}

/**
 * توضیح کوتاه زیر عنوان صفحهٔ اصلی — از تنظیم «توضیح صفحهٔ اصلی».
 * تنظیم‌نشده → متن پیش‌فرض؛ خالی‌شده → رشتهٔ خالی (خط زیرعنوان نمایش داده نمی‌شود).
 */
function skyler_index_subtitle_html()
{
    $raw = skyler_opt_raw('skylerIndexSubtitle');
    $subtitle = ($raw === null) ? 'یک پوسته مدرن، زیبا و بهینه برای تایپچو با طراحی مینیمال و ریسپانسیو' : trim((string)$raw);
    if ($subtitle === '') {
        return '';
    }
    return htmlspecialchars($subtitle, ENT_QUOTES);
}

