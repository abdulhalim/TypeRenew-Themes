<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<!-- ---------- شروع محتوای صفحه استاتیک ---------- -->
<main class="main-content">
    
    <article class="page-static-card">
        
        <!-- ---------- عنوان صفحه (H1) ---------- -->
        <div class="page-static-header-text">
            <h1><?php $this->title(); ?></h1>
        </div>

        <!-- ---------- متادیتای صفحه ---------- -->
        <div class="page-static-meta">
            <i class="fa-regular fa-clock"></i>
            <span>آخرین بروزرسانی: <?php echo getLocalizedDate($this->modified); ?></span>
        </div>

        <!-- ---------- محتوای اصلی صفحه ---------- -->
        <div class="page-static-content">
            <?php $this->content(); ?>
        </div>

    </article>

    <!-- ---------- بخش نظرات (در صورت فعال بودن) ---------- -->
    <?php if ($this->allow('comment')): ?>
        <div style="margin-top: 50px;">
            <?php $this->need('comments.php'); ?>
        </div>
    <?php endif; ?>

</main>
<!-- ---------- پایان محتوای صفحه استاتیک ---------- -->

</div>
<!-- ---------- پایان کانتینر wrapper (از هدر) ---------- -->

<!-- ---------- فراخوانی فوتر ---------- -->
<?php $this->need('footer.php'); ?>