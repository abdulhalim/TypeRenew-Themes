<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php $this->need('header.php'); ?>

<?php
// ---------- آمار این نوشته (بازدید و لایک) ----------
$skylerCid = (int)$this->cid;
$skylerViews = skyler_views($skylerCid);
$skylerLikes = skyler_likes($skylerCid);
$skylerLiked = skyler_is_liked($skylerCid);
$skylerShowViews = skyler_opt('skylerShowViews', '1') === '1';
$skylerShowLikes = skyler_opt('skylerShowLikes', '1') === '1';
$viewsCounterActive = skyler_views_counter_active();
?>

<!-- ---------- شروع محتوای پست ---------- -->

<article class="single-post-card">
    
    <!-- ---------- تصویر شاخص (بنر) — با پشتیبانی فیلد thumb دیتابیس ---------- -->
    <?php $banner = skyler_post_banner($this, false); ?>
    
    <?php if ($banner !== ''): ?>
    <div style="margin: -40px -40px 30px -40px; line-height: 0; border-radius: var(--radius) var(--radius) 0 0; overflow: hidden;">
        <img src="<?php echo htmlspecialchars($banner); ?>" alt="<?php $this->title(); ?>" style="width: 100%; height: auto; display: block;">
    </div>
    <?php endif; ?>

    <!-- ---------- هدر پست ---------- -->
    <header class="post-header" style="<?php echo $banner ? 'margin-top: -10px;' : ''; ?>">
        <h1 class="single-post-title"><?php $this->title(); ?></h1>

        <!-- ---------- متادیتای پست ---------- -->
        <div class="single-post-meta">
            <span><i class="fa-regular fa-user"></i> <a href="<?php $this->author->permalink(); ?>" style="color: inherit; text-decoration: none;"><?php $this->author(); ?></a></span>
            <span><i class="fa-regular fa-calendar"></i> <time datetime="<?php $this->date('c'); ?>"><?php echo getLocalizedDate($this->created); ?></time></span>
         
            <?php if ($this->categories): ?>
                <span>
                    <i class="fa-regular fa-folder"></i>
                    <?php $this->category(', '); ?>
                </span>
            <?php endif; ?>
               
            <?php if ($skylerShowViews): ?>
                <span class="skyler-meta-views">
                    <i class="fa-regular fa-eye"></i>
                    <?php
                    if ($viewsCounterActive && method_exists('ViewsCounter_Plugin', 'getViewsById')) {
                        echo ViewsCounter_Plugin::getViewsById($skylerCid);
                    } else {
                        echo skyler_num($skylerViews);
                    }
                    ?>
                </span>
            <?php endif; ?>

            <?php if ($skylerShowLikes): ?>
                <span class="skyler-meta-likes"><i class="fa-solid fa-heart"></i> <?php echo skyler_num($skylerLikes); ?></span>
            <?php endif; ?>
        </div>
    </header>

    <!-- ---------- محتوای اصلی پست (با گرید خودکار تصاویر بندانگشتی) ---------- -->
    <div class="single-post-content">
        <?php echo skyler_image_grid((string)$this->content); ?>
    </div>
    
    <!-- ---------- گالری تصاویر ---------- -->
    <?php 
    if ($this->fields->gallery_urls): 
        $urls = explode("\n", $this->fields->gallery_urls);
        $style = $this->fields->gallery_style ? $this->fields->gallery_style : 'style-zoom';
        $cols = $this->fields->gallery_columns ? $this->fields->gallery_columns : '3';
        $ratio = $this->fields->gallery_ratio ? $this->fields->gallery_ratio : 'landscape';
    ?>
        <div class="post-gallery-wrapper">
            <div class="post-gallery grid-<?php echo htmlspecialchars($cols); ?> <?php echo htmlspecialchars($style); ?> ratio-<?php echo htmlspecialchars($ratio); ?>">
                <?php foreach ($urls as $url): ?>
                    <?php $url = trim($url); 
                    if(!empty($url)): ?>
                    <div class="gallery-item">
                        <a href="<?php echo htmlspecialchars($url); ?>" class="gallery-link" data-fancybox="gallery-<?php $this->cid(); ?>">
                            <img src="<?php echo htmlspecialchars($url); ?>" alt="<?php $this->title(); ?>" loading="lazy">
                            
                            <?php if($style == 'style-dark'): ?>
                                <div class="gallery-overlay">
                                    <i class="fa-solid fa-magnifying-glass-plus"></i>
                                </div>
                            <?php endif; ?>
                        </a>
                    </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- ---------- دکمه‌های دانلود و پیش‌نمایش ---------- -->
    <?php 
    $downloadLink = $this->fields->download_link;
    $previewLink = $this->fields->preview_link;
    ?>

    <?php if ($downloadLink || $previewLink): ?>
        <div class="btn-box-modern">
            
            <?php if ($downloadLink): ?>
                <a href="<?php echo htmlspecialchars($downloadLink); ?>"
                   class="btn btn-download"
                   download
                   target="_blank"
                   rel="noopener noreferrer"
                   aria-label="دانلود فایل">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-download" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                        <polyline points="7 10 12 15 17 10"/>
                        <line x1="12" y1="15" x2="12" y2="3"/>
                    </svg>
                    دانلود فایل
                </a>
            <?php endif; ?>

            <?php if ($previewLink): ?>
                <a href="<?php echo htmlspecialchars($previewLink); ?>"
                   class="btn btn-preview"
                   target="_blank"
                   rel="noopener noreferrer"
                   aria-label="پیش‌نمایش">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-preview" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="3"/>
                        <path d="M2 12s4-8 10-8 10 8 10 8-4 8-10 8-10-8-10-8z"/>
                    </svg>
                    پیش‌نمایش
                </a>
            <?php endif; ?>
            
        </div>
    <?php endif; ?>

    <!-- ---------- برچسب‌ها ---------- -->
    <?php if ($this->tags): ?>
    <div class="single-post-tags">
        <i class="fa-solid fa-tags" style="color: var(--gray); width: 20px;"></i>
        <?php foreach($this->tags as $tag): ?>
            <a href="<?php echo htmlspecialchars($tag['permalink']); ?>" class="single-post-tag-item">
                <?php echo htmlspecialchars($tag['name']); ?>
            </a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- ---------- دکمهٔ لایک (پسند) — شناور ----------
         دکمه به‌صورت شناور در گوشهٔ پایین-چپ نمایش داده می‌شود؛
         پس از پسندیدن، خودکار پنهان می‌شود و در بازدیدهای بعدی
         (تا وقتی کوکی لایک پابرجاست) نمایش داده نمی‌شود. -->
    <?php if ($skylerShowLikes): ?>
    <div class="skyler-like-float<?php echo $skylerLiked ? ' is-hidden' : ''; ?>" id="skylerLikeFloat">
        <button type="button"
                class="skyler-like-btn<?php echo $skylerLiked ? ' is-liked' : ''; ?>"
                id="skyler-like-btn"
                data-cid="<?php echo $skylerCid; ?>"
                data-likes="<?php echo $skylerLikes; ?>"
                data-liked="<?php echo $skylerLiked ? '1' : '0'; ?>"
                aria-pressed="<?php echo $skylerLiked ? 'true' : 'false'; ?>"
                aria-label="پسندیدن این نوشته"
                title="<?php echo $skylerLiked ? 'این نوشته را پسندیده‌اید' : 'این نوشته را بپسند'; ?>">
            <i class="fa-solid fa-heart"></i>
            <span class="skyler-like-count"><?php echo skyler_num($skylerLikes); ?></span>
        </button>
    </div>
    <?php endif; ?>

    <!-- ---------- باکس نویسنده ---------- -->
    <div class="single-author-box">
        
        <!-- ---------- آواتار نویسنده (اولویت: تنظیم پوسته → avatar.png پوسته → گراواتار) ---------- -->
        <div class="single-author-avatar-wrapper">
            <?php
            $authorEmail = $this->author->mail;
            $avatarUrl = getAuthorAvatar($authorEmail);
            $skylerAvatarFallback = skyler_local_avatar_url();
            ?>
            <img src="<?php echo htmlspecialchars($avatarUrl); ?>" alt="<?php $this->author(); ?>" class="single-author-avatar-img"<?php echo ($skylerAvatarFallback !== '' && $avatarUrl !== $skylerAvatarFallback) ? ' onerror="this.onerror=null; this.src=\'' . htmlspecialchars($skylerAvatarFallback, ENT_QUOTES) . '\';"' : ''; ?>>
        </div>
        
        <!-- ---------- اطلاعات نویسنده ---------- -->
        <div class="single-author-details">
            <h3 class="single-author-name">
                <?php $this->author(); ?>
            </h3>
            
            <div class="single-author-bio">
                <?php echo $this->options->authorBio; ?>
            </div>
            
            <!-- ---------- شبکه‌های اجتماعی نویسنده ---------- -->
            <div class="single-author-socials">
                <?php if($this->options->socialTwitter): ?>
                    <a href="<?php $this->options->socialTwitter(); ?>" target="_blank"><i class="fa-brands fa-twitter"></i></a>
                <?php endif; ?>
                
                <?php if($this->options->socialTelegram): ?>
                    <a href="<?php $this->options->socialTelegram(); ?>" target="_blank"><i class="fa-brands fa-telegram"></i></a>
                <?php endif; ?>
                
                <?php if($this->options->socialInstagram): ?>
                    <a href="<?php $this->options->socialInstagram(); ?>" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                <?php endif; ?>

                <?php if($this->options->socialGithub): ?>
                    <a href="<?php $this->options->socialGithub(); ?>" target="_blank"><i class="fa-brands fa-github"></i></a>
                <?php endif; ?>

                <?php if($this->options->socialLinkedin): ?>
                    <a href="<?php $this->options->socialLinkedin(); ?>" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</article>

<!-- ---------- بخش نظرات ---------- -->
<?php $this->need('comments.php'); ?>

</main>
<!-- ---------- پایان محتوای اصلی ---------- -->

<!-- ---------- فراخوانی سایدبار ---------- -->
<?php $this->need('sidebar.php'); ?>

</div>
<!-- ---------- پایان کانتینر wrapper (از هدر) ---------- -->

<!-- ---------- فراخوانی فوتر ---------- -->
<?php $this->need('footer.php'); ?>