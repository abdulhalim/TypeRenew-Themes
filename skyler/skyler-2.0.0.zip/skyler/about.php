<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * درباره من
 *
 * @package custom
 */
?>
<?php $this->need('header.php'); ?>

</main>
</div>

<?php
// ---------- جمع‌آوری تنظیمات داینامیک صفحهٔ درباره من ----------

// نشان بالای نام
$skylerAboutBadge = trim((string)skyler_opt('aboutBadgeText', 'درباره من'));
if ($skylerAboutBadge === '') {
    $skylerAboutBadge = 'درباره من';
}

// نام و نام خانوادگی (اولویت: تنظیمات → نام مدیر → عنوان سایت)
$skylerAboutName = skyler_author_display_name();

// زیرعنوان / عنوان شغلی (اولویت: تنظیمات → توضیحات کوتاه نویسنده)
$skylerAboutJob = trim((string)skyler_opt('aboutJobTitle', ''));
if ($skylerAboutJob === '') {
    $skylerAboutJob = trim((string)skyler_opt('authorBio', ''));
}

// معرفی کامل (اگر خالی باشد محتوای خود برگه نمایش داده می‌شود)
$skylerAboutBio = trim((string)skyler_opt('aboutBio', ''));

// اطلاعات شخصی — هر ردیف: [آیکون، برچسب، مقدار، لینک اختیاری]
$skylerAboutInfo = [];

$skylerTmp = trim((string)skyler_opt('aboutEmail', ''));
if ($skylerTmp !== '') {
    $skylerAboutInfo[] = ['fa-regular fa-envelope', 'ایمیل', $skylerTmp, 'mailto:' . $skylerTmp];
}

$skylerTmp = trim((string)skyler_opt('aboutPhone', ''));
if ($skylerTmp !== '') {
    $skylerAboutPhoneHref = 'tel:' . preg_replace('/[\s\-()]+/', '', $skylerTmp);
    $skylerAboutInfo[] = ['fa-solid fa-phone', 'شماره تماس', $skylerTmp, $skylerAboutPhoneHref];
}

$skylerTmp = trim((string)skyler_opt('aboutLocation', ''));
if ($skylerTmp !== '') {
    $skylerAboutInfo[] = ['fa-solid fa-location-dot', 'محل سکونت', $skylerTmp, null];
}

$skylerTmp = trim((string)skyler_opt('aboutBirthday', ''));
if ($skylerTmp !== '') {
    $skylerAboutInfo[] = ['fa-solid fa-cake-candles', 'تاریخ تولد', $skylerTmp, null];
}

$skylerTmp = trim((string)skyler_opt('aboutEducation', ''));
if ($skylerTmp !== '') {
    $skylerAboutInfo[] = ['fa-solid fa-graduation-cap', 'تحصیلات', $skylerTmp, null];
}

$skylerTmp = trim((string)skyler_opt('aboutLanguages', ''));
if ($skylerTmp !== '') {
    $skylerAboutInfo[] = ['fa-solid fa-language', 'زبان‌ها', $skylerTmp, null];
}

$skylerInfoTitle = trim((string)skyler_opt('aboutInfoTitle', 'اطلاعات شخصی'));
if ($skylerInfoTitle === '') {
    $skylerInfoTitle = 'اطلاعات شخصی';
}

// مهارت‌ها (هر خط: «نام مهارت / درصد» — مثل: برنامه نویس / 95)
$skylerAboutSkills = array_values(array_filter(array_map('trim', explode("\n", (string)skyler_opt('aboutSkills', '')))));
$skylerSkillsTitle = trim((string)skyler_opt('aboutSkillsTitle', 'مهارت‌ها'));
if ($skylerSkillsTitle === '') {
    $skylerSkillsTitle = 'مهارت‌ها';

}

// تفکیک خطوط: دارای درصد → نوار پیشرفت / بدون درصد → چیپ ساده (سازگار با دادهٔ قدیمی)
$skylerSkillBars = array();
$skylerSkillChips = array();
foreach ($skylerAboutSkills as $skylerSkillLine) {
    $skylerSkillParsed = false;

    // الگو: نام + جداکننده (/ یا | یا : یا ؛ یا -) + عدد ۰ تا ۱۰۰ (رقم فارسی/لاتین) + ٪ یا % اختیاری
    if (preg_match('~^(.+?)\s*[/|:؛-]\s*([0-9۰-۹]{1,3})\s*[٪%]?\s*$~u', $skylerSkillLine, $skylerSkillMatch)) {
        $skylerSkillName = trim($skylerSkillMatch[1]);
        $skylerSkillNumRaw = $skylerSkillMatch[2];
        $skylerSkillNum = strtr($skylerSkillNumRaw, array('۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9'));

        if ($skylerSkillName !== '' && $skylerSkillNum !== '') {
            $skylerSkillPercent = max(0, min(100, (int)$skylerSkillNum));
            $skylerSkillFa = ($skylerSkillNumRaw !== $skylerSkillNum);
            $skylerSkillDisplay = $skylerSkillFa
                ? strtr((string)$skylerSkillPercent, array('0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹'))
                : (string)$skylerSkillPercent;

            $skylerSkillBars[] = array(
                'name' => $skylerSkillName,
                'percent' => $skylerSkillPercent,
                'display' => $skylerSkillDisplay,
                'suffix' => $skylerSkillFa ? '٪' : '%',
                'fa' => $skylerSkillFa,
            );
            $skylerSkillParsed = true;
        }
    }

    if (!$skylerSkillParsed) {
        $skylerSkillChips[] = $skylerSkillLine;
    }
}

// بخش CTA انتهای صفحه
$skylerAboutCtaText = trim((string)skyler_opt('aboutCtaText', 'برای ارتباط با من یا دنبال کردن فعالیت‌هایم می‌تونید به لینک‌تری من سر بزنید یا از طریق شبکه‌های اجتماعی با من در تماس باشید.'));
$skylerAboutCtaBtnText = trim((string)skyler_opt('aboutCtaBtnText', 'لینک‌های من'));
if ($skylerAboutCtaBtnText === '') {
    $skylerAboutCtaBtnText = 'لینک‌های من';
}
// آدرس دکمه (داینامیک): صفحهٔ سفارشی لینک‌تری (برگهٔ قالب «لینک‌ها»)
// → آدرس جایگزین دکمه از تنظیمات پوسته.
// اگر هیچ‌کدام موجود نباشد، کل کادر CTA نمایش داده نمی‌شود (بدون لینک شکسته/404).
$skylerAboutCtaBtnUrl = skyler_cta_url();
// لینک خارجی در تب جدید باز می‌شود؛ لینک داخلی (حتی با آدرس مطلق) در همان تب
$skylerAboutCtaBtnTarget = '';
if ($skylerAboutCtaBtnUrl !== '' && preg_match('~^(?:https?:)?//([^/]+)~i', $skylerAboutCtaBtnUrl, $skylerCtaHostMatch)) {
    $skylerSiteHost = (string)parse_url((string)$this->options->siteUrl, PHP_URL_HOST);
    if ($skylerSiteHost === '' || strcasecmp($skylerCtaHostMatch[1], $skylerSiteHost) !== 0) {
        $skylerAboutCtaBtnTarget = ' target="_blank" rel="noopener noreferrer"';
    }
}
?>

<div class="container page-about-wrapper">

    <!-- ---------- بخش هدر درباره من ---------- -->
    <div class="about-hero">

        <!-- ---------- محتوای متنی ---------- -->
        <div class="about-content">
            <?php if ($skylerAboutBadge !== ''): ?>
            <span class="about-badge"><?php echo htmlspecialchars($skylerAboutBadge); ?></span>
            <?php endif; ?>

            <h1><?php echo htmlspecialchars($skylerAboutName); ?></h1>

            <?php if ($skylerAboutJob !== ''): ?>
            <h3><?php echo htmlspecialchars($skylerAboutJob); ?></h3>
            <?php endif; ?>

            <div class="about-intro">
                <?php if ($skylerAboutBio !== ''): ?>
                    <?php echo nl2br(htmlspecialchars($skylerAboutBio)); ?>
                <?php else: ?>
                    <?php $this->content(); ?>
                <?php endif; ?>
            </div>

            <!-- ---------- شبکه‌های اجتماعی ---------- -->
            <div class="about-socials">
                <?php if($this->options->socialTelegram): ?>
                <a href="<?php $this->options->socialTelegram(); ?>" target="_blank"><i class="fa-brands fa-telegram"></i></a>
                <?php endif; ?>
                <?php if($this->options->socialGithub): ?>
                <a href="<?php $this->options->socialGithub(); ?>" target="_blank"><i class="fa-brands fa-github"></i></a>
                <?php endif; ?>
                <?php if($this->options->socialInstagram): ?>
                <a href="<?php $this->options->socialInstagram(); ?>" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                <?php endif; ?>
                <?php if($this->options->socialTwitter): ?>
                <a href="<?php $this->options->socialTwitter(); ?>" target="_blank"><i class="fa-brands fa-twitter"></i></a>
                <?php endif; ?>
                <?php if($this->options->socialLinkedin): ?>
                <a href="<?php $this->options->socialLinkedin(); ?>" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
                <?php endif; ?>
            </div>
        </div>

        <!-- ---------- تصویر آواتار (تنها بخش غیرتنظیمی: تنظیم پوسته → avatar.png → گراواتار) ---------- -->
        <div class="about-image">
            <?php
            // ---------- آواتار نویسنده ----------
            // اولویت: تنظیم پوسته (authorAvatar) → img/avatar.png داخل پوسته → گراواتار
            $avatarUrl = getAuthorAvatar(null);
            $skylerAvatarFallback = skyler_local_avatar_url();
            ?>

            <!-- ---------- تگ تصویر با onerror برای fallback نهایی ---------- -->
            <img src="<?php echo htmlspecialchars($avatarUrl); ?>"
                 alt="<?php echo htmlspecialchars($skylerAboutName); ?>"
                 class="about-avatar-img"
                 loading="lazy"<?php echo ($skylerAvatarFallback !== '' && $avatarUrl !== $skylerAvatarFallback) ? ' onerror="this.onerror=null; this.src=\'' . htmlspecialchars($skylerAvatarFallback, ENT_QUOTES) . '\';"' : ''; ?>>
        </div>
    </div>

    <?php if (!empty($skylerAboutInfo) || !empty($skylerAboutSkills)): ?>
    <!-- ---------- کارت‌های اطلاعات شخصی و مهارت‌ها (داینامیک از تنظیمات پوسته) ---------- -->
    <div class="about-grid">

        <?php if (!empty($skylerAboutInfo)): ?>
        <div class="about-card">
            <div class="card-header">
                <i class="fa-regular fa-id-card"></i>
                <h3><?php echo htmlspecialchars($skylerInfoTitle); ?></h3>
            </div>
            <ul class="about-info-list">
                <?php foreach ($skylerAboutInfo as $skylerRow): ?>
                <li>
                    <span class="about-info-label">
                        <i class="<?php echo htmlspecialchars($skylerRow[0]); ?>"></i>
                        <?php echo htmlspecialchars($skylerRow[1]); ?>
                    </span>
                    <?php if (!empty($skylerRow[3])): ?>
                    <a class="about-info-value" href="<?php echo htmlspecialchars($skylerRow[3]); ?>"><?php echo htmlspecialchars($skylerRow[2]); ?></a>
                    <?php else: ?>
                    <span class="about-info-value"><?php echo htmlspecialchars($skylerRow[2]); ?></span>
                    <?php endif; ?>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>

        <?php if (!empty($skylerSkillBars) || !empty($skylerSkillChips)): ?>
        <div class="about-card">
            <div class="card-header">
                <i class="fa-solid fa-lightbulb"></i>
                <h3><?php echo htmlspecialchars($skylerSkillsTitle); ?></h3>
            </div>

            <?php if (!empty($skylerSkillBars)): ?>
            <!-- ---------- نوارهای پیشرفت درصدی (نام مهارت / درصد) ---------- -->
            <div class="about-skill-list">
                <?php foreach ($skylerSkillBars as $skylerSkill): ?>
                <div class="about-skill-item">
                    <div class="about-skill-head">
                        <span class="about-skill-name"><?php echo htmlspecialchars($skylerSkill['name']); ?></span>
                        <span class="about-skill-percent" dir="ltr"><?php echo htmlspecialchars($skylerSkill['display'] . $skylerSkill['suffix']); ?></span>
                    </div>
                    <div class="about-skill-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo (int)$skylerSkill['percent']; ?>" aria-label="<?php echo htmlspecialchars($skylerSkill['name']); ?>">
                        <div class="about-skill-fill" data-percent="<?php echo (int)$skylerSkill['percent']; ?>"<?php echo !empty($skylerSkill['fa']) ? ' data-fa="1"' : ''; ?> style="width:<?php echo (int)$skylerSkill['percent']; ?>%"></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if (!empty($skylerSkillChips)): ?>
            <!-- ---------- مهارت‌های بدون درصد → چیپ ساده (سازگار با دادهٔ قدیمی) ---------- -->
            <div class="about-skills">
                <?php foreach ($skylerSkillChips as $skylerSkillChip): ?>
                <span class="about-skill-chip"><?php echo htmlspecialchars($skylerSkillChip); ?></span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

    </div>
    <?php endif; ?>

    <?php if ($skylerAboutCtaBtnUrl !== ''): ?>
    <!-- ---------- بخش دعوت به اقدام (CTA) — فقط وقتی مقصد دکمه موجود است نمایش داده می‌شود ---------- -->
    <div class="about-cta">
        <p><?php echo nl2br(htmlspecialchars($skylerAboutCtaText)); ?></p>
        <a href="<?php echo htmlspecialchars($skylerAboutCtaBtnUrl); ?>"<?php echo $skylerAboutCtaBtnTarget; ?> class="btn-primary">
            <i class="fa-solid fa-link"></i> <?php echo htmlspecialchars($skylerAboutCtaBtnText); ?>
        </a>
    </div>
    <?php endif; ?>

</div>

<?php
// بارگذاری js/about.js فقط در همین صفحه و فقط وقتی نوار پیشرفت مهارتی وجود دارد
if (!empty($skylerSkillBars)) {
    $GLOBALS['skylerAboutPageJs'] = true;
}
?>

<?php $this->need('footer.php'); ?>
