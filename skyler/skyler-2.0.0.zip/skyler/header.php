<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php $this->archiveTitle([
        'post'     => '%s',
        'page'     => '%s',
        'category' => _t('دسته‌بندی: %s'),
        'search'   => _t('جستجو: %s'),
        'tag'      => _t('برچسب: %s'),
        'author'   => _t('نوشته‌های %s'),
        'date'     => _t('آرشیو: %s'),
        'archive'  => '%s',
    ], '', ' - '); ?><?php $this->options->title(); ?></title>

    <!-- ---------- فراخوانی هدر تایپچو (برای پلاگین‌ها) ---------- -->
    <?php $this->header(); ?>
    
    <!-- ---------- فاویکون ---------- -->
    <?php if ($this->options->favicon): ?>
        <link rel="icon" href="<?php $this->options->favicon(); ?>">
        <link rel="shortcut icon" href="<?php $this->options->favicon(); ?>">
    <?php endif; ?>
    
    <!-- ---------- استایل‌های اصلی (با نسخه برای جلوگیری از کش مرورگر) ---------- -->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/style.css'); ?>?v=2.0.0">
    
    <!-- ---------- فونت وزیرمتن (آفلاین) ---------- -->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/fonts.css'); ?>">

    <!-- ---------- فونت‌آسام (آفلاین) ---------- -->    
    <link rel="stylesheet" href="<?php $this->options->themeUrl('css/all.css'); ?>">

    <!-- ---------- اسکریپت‌های منوی موبایل ---------- -->
    <script>
        function toggleMenu() {
            var sidebar = document.querySelector('.mobile-menu-sidebar');
            var overlay = document.querySelector('.mobile-menu-overlay');
            if (!sidebar || !overlay) return;
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
            closeSearch();
        }
        function closeMenu() {
            var sidebar = document.querySelector('.mobile-menu-sidebar');
            var overlay = document.querySelector('.mobile-menu-overlay');
            if (sidebar) sidebar.classList.remove('active');
            if (overlay) overlay.classList.remove('active');
        }

        function toggleSearch() {
            var panel = document.querySelector('.mobile-search-panel');
            var overlay = document.querySelector('.mobile-search-overlay');
            if (!panel || !overlay) return;
            panel.classList.toggle('active');
            overlay.classList.toggle('active');
            closeMenu();
            
            if (panel.classList.contains('active')) {
                var input = panel.querySelector('.mobile-search-input');
                if (input) {
                    setTimeout(function () { input.focus(); }, 300);
                }
            }
        }
        function closeSearch() {
            var panel = document.querySelector('.mobile-search-panel');
            var overlay = document.querySelector('.mobile-search-overlay');
            if (panel) panel.classList.remove('active');
            if (overlay) overlay.classList.remove('active');
        }
    </script>
</head>
<body class="farsi-digits">

    <!-- ---------- لایه تاریک منوی موبایل ---------- -->
    <div class="mobile-menu-overlay" onclick="closeMenu()"></div>
    
    <!-- ---------- لایه تاریک جستجوی موبایل ---------- -->
    <div class="mobile-search-overlay" onclick="closeSearch()"></div>
    
    <!-- ---------- پنل جستجوی موبایل ---------- -->
    <div class="mobile-search-panel">
        <div class="close-search-btn" onclick="closeSearch()">
            <i class="fa-solid fa-xmark"></i>
        </div>
        
        <div class="container" style="text-align: center;">
            <h2 style="margin-bottom: 10px; color: var(--dark);">جستجو در سایت</h2>
            <p style="color: var(--gray); margin-bottom: 30px;">کلیدواژه مورد نظر خود را وارد کنید</p>
            
            <form action="<?php $this->options->siteUrl(); ?>" method="get" class="mobile-search-form">
                <input type="text" name="s" placeholder="جستجو..." class="mobile-search-input">
                <button type="submit">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>
            </form>
        </div>
    </div>

    <?php
    // ---------- داده‌های مشترک لوگو و آیکون‌های منو ----------
    $skylerSiteTitle   = (string)$this->options->title;
    $skylerLogoSetting = (string)$this->options->logoUrl;
    $skylerLogoLocal   = file_exists(__TYPECHO_ROOT_DIR__ . '/usr/themes/' . basename(__DIR__) . '/img/logo.png');
    $skylerLogoLocalUrl = rtrim((string)$this->options->themeUrl, '/') . '/img/logo.png';
    $skylerCatIcons    = parseCustomIcons($this->options->categoryIcons);
    $skylerPageIcons   = parseCustomIcons($this->options->pageIcons);

    // ---------- دکمهٔ CTA نوار ناوبری (داینامیک: متن / آدرس / آیکون از تنظیمات پوسته) ----------
    $skylerCtaText = trim((string)skyler_opt('navCtaText', 'من را دنبال کنید'));
    $skylerCtaUrl  = trim((string)skyler_opt('navCtaUrl', ''));
    $skylerCtaIcon = skyler_fa_class(skyler_opt('navCtaIcon', 'fa-user-plus'), 'fa-user-plus');
    $skylerCtaShow = ($skylerCtaText !== '' && $skylerCtaUrl !== '');
    // لینک‌های خارجی در تب جدید؛ لینک‌های داخلی در همان تب
    $skylerCtaTarget = preg_match('~^https?://~i', $skylerCtaUrl) ? ' target="_blank" rel="noopener noreferrer"' : '';
    ?>

    <!-- ---------- سایدبار منوی موبایل ---------- -->
    <aside class="mobile-menu-sidebar">
        <div class="close-menu-btn" onclick="closeMenu()">
            <i class="fa-solid fa-xmark"></i>
        </div>

        <div class="mobile-sidebar-logo">
            <a href="<?php $this->options->siteUrl(); ?>" class="logo-link" style="text-decoration: none; flex-direction: column; align-items: center;">
                
                <?php if ($skylerLogoSetting): ?>
                    <img src="<?php echo htmlspecialchars($skylerLogoSetting); ?>" alt="<?php echo htmlspecialchars($skylerSiteTitle); ?>" class="logo-img">
                <?php elseif ($skylerLogoLocal): ?>
                    <img src="<?php echo htmlspecialchars($skylerLogoLocalUrl); ?>" alt="<?php echo htmlspecialchars($skylerSiteTitle); ?>" class="logo-img">
                <?php else: ?>
                    <div class="logo-icon"><i class="fa-solid fa-pen-nib"></i></div>
                <?php endif; ?>
                
                <?php if (!$skylerLogoSetting && !$skylerLogoLocal): ?>
                    <div class="logo-text" style="margin-top: 10px;">
                        <span class="logo-main"><?php $this->options->title(); ?></span>
                        <span class="logo-sub"><?php $this->options->description(); ?></span>
                    </div>
                <?php endif; ?>
            </a>
        </div>

        <!-- ---------- لینک‌های منوی موبایل ---------- -->
        <div class="mobile-nav-links">
            <a href="<?php $this->options->siteUrl(); ?>" onclick="closeMenu()"><i class="fa-solid fa-house" style="margin-left:8px;"></i> خانه</a>
            
            <?php
            // ---------- دسته‌بندی‌های انتخاب شده در منوی موبایل ----------
            $selectedCats = $this->options->navCategories;
            if (!empty($selectedCats) && is_array($selectedCats)):
                $this->widget('Widget_Metas_Category_List')->to($navCats);
                while($navCats->next()):
                    if (in_array($navCats->slug, $selectedCats)):
                        $skylerCatIcon = isset($skylerCatIcons[$navCats->slug])
                            ? skyler_fa_class($skylerCatIcons[$navCats->slug], 'fa-layer-group')
                            : 'fa-solid fa-layer-group';
            ?>
                        <a href="<?php $navCats->permalink(); ?>" onclick="closeMenu()"><i class="<?php echo htmlspecialchars($skylerCatIcon); ?>" style="margin-left:8px;"></i> <?php $navCats->name(); ?></a>
            <?php
                    endif;
                endwhile;
            endif;
            ?>

            <?php
            // ---------- صفحات انتخاب شده در منوی موبایل ----------
            $selectedPages = $this->options->navPages;
            if (!empty($selectedPages) && is_array($selectedPages)):
                $this->widget('Widget_Contents_Page_List')->to($pages);
                while($pages->next()):
                    if (in_array($pages->permalink, $selectedPages)):
                        $skylerPgIcon = isset($skylerPageIcons[$pages->slug])
                            ? skyler_fa_class($skylerPageIcons[$pages->slug], 'fa-file-lines')
                            : 'fa-regular fa-file-lines';
            ?>
                        <a href="<?php $pages->permalink(); ?>" onclick="closeMenu()"><i class="<?php echo htmlspecialchars($skylerPgIcon); ?>" style="margin-left:8px;"></i> <?php $pages->title(); ?></a>
            <?php
                    endif;
                endwhile;
            endif;
            ?>

            <!-- ---------- دکمهٔ CTA (داینامیک — از تنظیمات پوسته) ---------- -->
            <?php if ($skylerCtaShow): ?>
            <a href="<?php echo htmlspecialchars($skylerCtaUrl); ?>"<?php echo $skylerCtaTarget; ?> onclick="closeMenu()" class="nav-cta" style="margin-top: 20px; text-align: center; background: linear-gradient(135deg, var(--primary), var(--secondary)); color: white; padding: 12px; border-radius: 50px; text-decoration: none; font-weight: bold; display: flex; align-items: center; justify-content: center; gap: 8px;" >
                <i class="<?php echo htmlspecialchars($skylerCtaIcon); ?>"></i> <?php echo htmlspecialchars($skylerCtaText); ?>
            </a>
            <?php endif; ?>
        </div>
    </aside>

    <!-- ---------- ناوبری اصلی (دسکتاپ) ---------- -->
    <nav class="main-nav">
        <div class="container nav-container">
            
            <!-- ---------- بخش چپ: لوگو ---------- -->
            <div class="nav-left">
                <div class="logo">
                    <a href="<?php $this->options->siteUrl(); ?>" class="logo-link">
                        
                        <?php if ($skylerLogoSetting): ?>
                            <img src="<?php echo htmlspecialchars($skylerLogoSetting); ?>" alt="<?php echo htmlspecialchars($skylerSiteTitle); ?>" class="logo-img">
                        <?php elseif ($skylerLogoLocal): ?>
                            <img src="<?php echo htmlspecialchars($skylerLogoLocalUrl); ?>" alt="<?php echo htmlspecialchars($skylerSiteTitle); ?>" class="logo-img">
                        <?php else: ?>
                            <div class="logo-icon">
                                <i class="fa-solid fa-pen-nib"></i> 
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!$skylerLogoSetting && !$skylerLogoLocal): ?>
                            <div class="logo-text">
                                <span class="logo-main"><?php $this->options->title(); ?></span>
                                <span class="logo-sub"><?php $this->options->description(); ?></span>
                            </div>
                        <?php endif; ?>
                    </a>
                </div>
            </div>

            <!-- ---------- بخش وسط: منوی اصلی ---------- -->
            <div class="nav-center">
                <div class="nav-links">
                    <a href="<?php $this->options->siteUrl(); ?>" class="<?php if($this->is('index')): ?>active<?php endif; ?>">
                        <i class="fa-solid fa-house"></i> خانه
                    </a>
                    
                    <?php
                    // ---------- دسته‌بندی‌های منوی دسکتاپ ----------
                    $selectedCats = $this->options->navCategories;
                    if (!empty($selectedCats) && is_array($selectedCats)):
                        $this->widget('Widget_Metas_Category_List')->to($navCats);
                        while($navCats->next()):
                            if (in_array($navCats->slug, $selectedCats)):
                                $skylerCatIcon = isset($skylerCatIcons[$navCats->slug])
                                    ? skyler_fa_class($skylerCatIcons[$navCats->slug], 'fa-layer-group')
                                    : 'fa-solid fa-layer-group';
                    ?>
                                <a href="<?php $navCats->permalink(); ?>" class="<?php if($this->is('category', $navCats->slug)): ?>active<?php endif; ?>">
                                    <i class="<?php echo htmlspecialchars($skylerCatIcon); ?>"></i> <?php $navCats->name(); ?>
                                </a>
                    <?php
                            endif;
                        endwhile;
                    endif;
                    ?>

                    <?php
                    // ---------- صفحات منوی دسکتاپ ----------
                    $selectedPages = $this->options->navPages;
                    if (!empty($selectedPages) && is_array($selectedPages)):
                        $this->widget('Widget_Contents_Page_List')->to($pages);
                        while($pages->next()):
                            if (in_array($pages->permalink, $selectedPages)):
                                $skylerPgIcon = isset($skylerPageIcons[$pages->slug])
                                    ? skyler_fa_class($skylerPageIcons[$pages->slug], 'fa-file-lines')
                                    : 'fa-regular fa-file-lines';
                    ?>
                                <a href="<?php $pages->permalink(); ?>" class="<?php if($this->is('page', $pages->slug)): ?>active<?php endif; ?>">
                                    <i class="<?php echo htmlspecialchars($skylerPgIcon); ?>"></i> <?php $pages->title(); ?>
                                </a>
                    <?php
                            endif;
                        endwhile;
                    endif;
                    ?>
                </div>
            </div>
            
            <!-- ---------- بخش راست: دکمه CTA و کنترل‌های موبایل ---------- -->
            <div class="nav-right">
                <?php if ($skylerCtaShow): ?>
                <a href="<?php echo htmlspecialchars($skylerCtaUrl); ?>"<?php echo $skylerCtaTarget; ?> class="nav-cta">
                    <i class="<?php echo htmlspecialchars($skylerCtaIcon); ?>"></i><?php echo htmlspecialchars($skylerCtaText); ?>
                </a>
                <?php endif; ?>
                
                <!-- ---------- دکمه‌های کنترلی موبایل ---------- -->
                <div class="mobile-actions">
                    <div class="mobile-menu-btn" onclick="toggleMenu()">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>

                    <div class="mobile-search-btn" onclick="toggleSearch()">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- ---------- بخش هیرو (هدر صفحه) ---------- -->
    <header class="page-header">
        <div class="container">
            
            <!-- ---------- بردکرامب (مسیر ناوبری) ---------- -->
            <div class="breadcrumb">
                <?php if ($this->is('index')): ?>
                    <i class="fa-solid fa-house"></i> <span>خانه</span>
                <?php else: ?>
                    <a href="<?php $this->options->siteUrl(); ?>"><i class="fa-solid fa-house"></i> خانه</a>
                    <i class="fa-solid fa-chevron-left" style="font-size: 0.8rem;"></i>
                    <span>
                        <?php if ($this->is('category') && method_exists($this, 'getArchiveSlug')): ?>
                            <i class="fa-solid <?php echo htmlspecialchars(substr(skyler_fa_class(getCategoryIcon($this->getArchiveSlug()), 'fa-folder'), 4), ENT_QUOTES); ?>" style="font-size: 0.9rem; color: var(--primary);"></i>
                        <?php endif; ?>
                        <?php $this->archiveTitle('%s', '', ''); ?>
                    </span>
                <?php endif; ?>
            </div>

            <!-- ---------- عنوان اصلی صفحه (فقط در صفحه اصلی از H1 استفاده می‌شود) ---------- -->
            <?php if ($this->is('index')): ?>
                <?php $skylerIndexTitleHtml = skyler_index_title_html(); ?>
                <?php if ($skylerIndexTitleHtml !== ''): ?>
                <h1 class="page-title"><?php echo $skylerIndexTitleHtml; ?></h1>
                <?php endif; ?>
            <?php else: ?>
                <div class="page-title"><?php $this->archiveTitle([
                    'post'     => '%s',
                    'page'     => '%s',
                    'category' => _t('دسته‌بندی %s'),
                    'search'   => _t('جستجوی %s'),
                    'tag'      => _t('برچسب %s'),
                    'author'   => _t('نوشته‌های %s'),
                    'date'     => _t('آرشیو %s'),
                    'archive'  => '%s',
                ], '', ''); ?></div>
            <?php endif; ?>

            <!-- ---------- زیرعنوان و توضیحات ---------- -->
            <?php if ($this->is('index')): ?>
                <?php $skylerIndexSubtitleHtml = skyler_index_subtitle_html(); ?>
                <?php if ($skylerIndexSubtitleHtml !== ''): ?>
                <!-- ---------- توضیح کوتاه صفحهٔ اصلی — از تنظیمات پوسته ---------- -->
                <p class="page-subtitle"><?php echo $skylerIndexSubtitleHtml; ?></p>
                <?php endif; ?>
            <?php elseif ($this->is('post')): ?>
                <p class="page-subtitle">
                    نویسنده: <?php $this->author(); ?> | تاریخ: <?php echo getLocalizedDate($this->created); ?>
                </p>
            <?php elseif ($this->is('category')): ?>
                <p class="page-subtitle">
                    مشاهده تمام نوشته‌های دسته‌بندی <?php $this->archiveTitle('%s', '', ''); ?>
                </p>
            <?php elseif ($this->is('page')): ?>
                <!-- ---------- صفحه استاتیک - عنوان H1 در خود صفحه نمایش داده می‌شود ---------- -->
                <p class="page-subtitle">&nbsp;</p>
            <?php else: ?>
                <p class="page-subtitle">مرور محتویات سایت</p>
            <?php endif; ?>
        </div>
    </header>

    <!-- ---------- شروع محتوای اصلی ---------- -->
    <?php if ($this->is('page')): ?>
    <div class="container page-content-wrapper" id="posts">
    <?php else: ?>
    <div class="container content-wrapper" id="posts">
    <?php endif; ?>
        <main class="main-content">
