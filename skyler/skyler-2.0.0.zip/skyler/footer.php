<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<!-- ---------- فوتر سایت ---------- -->
<footer class="footer">
    <div class="container">
        <div class="footer-content">
            
            <?php
            // ---------- داده‌های لوگو و آیکون فوتر ----------
            $skylerSiteTitle = (string)$this->options->title;
            $skylerLogoSetting = (string)$this->options->logoUrl;
            $skylerLogoLocal = file_exists(__TYPECHO_ROOT_DIR__ . '/usr/themes/' . basename(__DIR__) . '/img/logo.png');
            $skylerLogoLocalUrl = rtrim((string)$this->options->themeUrl, '/') . '/img/logo.png';
            $skylerFooterPageIcons = parseCustomIcons($this->options->pageIcons);
            ?>

            <!-- ---------- بخش اول: لوگو و توضیحات ---------- -->
            <div class="footer-column">
                <div class="footer-logo">
                    <a href="<?php $this->options->siteUrl(); ?>" class="logo-link">
                        
                        <?php if ($skylerLogoSetting): ?>
                            <img src="<?php echo htmlspecialchars($skylerLogoSetting); ?>" alt="<?php echo htmlspecialchars($skylerSiteTitle); ?>" class="footer-logo-img">
                        <?php elseif ($skylerLogoLocal): ?>
                            <img src="<?php echo htmlspecialchars($skylerLogoLocalUrl); ?>" alt="<?php echo htmlspecialchars($skylerSiteTitle); ?>" class="footer-logo-img">
                        <?php else: ?>
                            <div class="logo-icon" style="background: rgba(255,255,255,0.1);">
                                <i class="fa-solid fa-pen-nib"></i>
                            </div>
                        <?php endif; ?>
                        
                        <!-- ---------- متن لوگو در فوتر (راست‌چین مثل لوگوی هدر) ---------- -->
                        <div class="logo-text-footer">
                            <span class="logo-main"><?php $this->options->title(); ?></span>
                            <span class="logo-sub"><?php $this->options->description(); ?></span>
                        </div>
                    </a>
                </div>
            </div>

            <!-- ---------- بخش دوم: لینک صفحات فوتر ---------- -->
            <div class="footer-column">
                <div class="footer-pages-nav">
                    <?php
                    $selectedFooterPages = $this->options->footerPages;
                    if (!empty($selectedFooterPages) && is_array($selectedFooterPages)):
                        $this->widget('Widget_Contents_Page_List')->to($pages);
                        while($pages->next()):
                            if (in_array($pages->permalink, $selectedFooterPages)):
                                $skylerFpIcon = isset($skylerFooterPageIcons[$pages->slug])
                                    ? skyler_fa_class($skylerFooterPageIcons[$pages->slug], 'fa-file-lines')
                                    : 'fa-regular fa-file-lines';
                    ?>
                        <a href="<?php $pages->permalink(); ?>" class="footer-page-link">
                            <i class="<?php echo htmlspecialchars($skylerFpIcon); ?>" style="margin-left: 6px;"></i> <?php $pages->title(); ?>
                        </a>
                    <?php
                            endif;
                        endwhile;
                    else:
                        echo '<span style="color:#6c757d; font-size:0.9rem;">صفحه‌ای برای نمایش تعریف نشده است.</span>';
                    endif;
                    ?>
                </div>
            </div>

        </div>
    </div>

    <!-- ---------- خط جداکننده فوتر ---------- -->
    <div class="footer-divider"></div>

    <!-- ---------- بخش پایین: کپی رایت ---------- -->
    <div class="container">
        <div class="footer-bottom">
            <div class="copyright-text">
                <span class="copy-year">© <?php echo skyler_jalali_year(); ?></span> 
                <span class="copy-site"><?php $this->options->title(); ?></span> - 
                <span class="copy-reserved">تمامی حقوق محفوظ است</span> | 
                <span class="copy-powered">قدرت گرفته از <a href="https://typecho.org" target="_blank">تایپچو</a></span>
            </div>
        </div>
    </div>
</footer>

<?php $this->footer(); ?>

<!-- ---------- مودال نمایش بزرگ تصاویر (لایت‌باکس) ---------- -->
<div id="simpleLightboxModal" class="slb-modal">
    <span id="simpleLightboxClose" class="slb-close">&times;</span>
    
    <!-- ---------- دکمه قبلی (فلش راست) ---------- -->
    <button id="simpleLightboxPrev" class="slb-prev">&#10095;</button>
    
    <img id="simpleLightboxImg" class="slb-content" alt="">
    
    <!-- ---------- دکمه بعدی (فلش چپ) ---------- -->
    <button id="simpleLightboxNext" class="slb-next">&#10094;</button>
</div>

<!-- ---------- دکمه بازگشت به بالا ---------- -->
<a href="#" id="backToTopBtn" class="back-to-top" title="بازگشت به بالا">
    <i class="fas fa-arrow-up"></i>
</a>

<!-- ---------- فایل‌های جاوااسکریپت ---------- -->
<script src="<?php $this->options->themeUrl('js/go-to-top.js'); ?>"></script>
<script src="<?php $this->options->themeUrl('js/copy-code.js'); ?>"></script>
<script src="<?php $this->options->themeUrl('js/gallery.js'); ?>"></script>
<script src="<?php $this->options->themeUrl('js/likes.js'); ?>"></script>
<?php if (!empty($GLOBALS['skylerAboutPageJs'])): ?>
<!-- ---------- انیمیشن نوارهای پیشرفت مهارت‌ها (فقط صفحهٔ درباره من) ---------- -->
<script src="<?php $this->options->themeUrl('js/about.js'); ?>"></script>
<?php endif; ?>

<!-- ---------- متغیر سراسری برای پاسخ به کامنت ---------- -->
<script>
    window.respondId = '<?php $this->respondId(); ?>';
</script>

<script src="<?php $this->options->themeUrl('js/comments.js'); ?>"></script>

</body>
</html>