<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<?php

function renderCommentRecursive($c, $options, $postAuthorId = 0, $commentsWidget = null) {
    
    // ---------- محاسبه و نمایش آواتار ----------
    $avatarUrl = '';
    $commenterEmail = '';
    
    if (is_array($c)) {
        $commenterEmail = isset($c['mail']) ? $c['mail'] : 'guest@example.com';
    } else {
        $commenterEmail = $c->mail ?: 'guest@example.com';
    }
    
    // نویسندهٔ مطلب؟ (تطبیق شناسهٔ کاربر نویندهٔ دیدگاه با نویسندهٔ محتوا)
    if (is_array($c)) {
        $isAuthor = !empty($postAuthorId) && isset($c['authorId']) && (int)$c['authorId'] === (int)$postAuthorId;
    } else {
        try {
            $isAuthor = $c->authorId && $c->authorId == $c->ownerId;
        } catch (Exception $e) {
            $isAuthor = false;
        }
    }

    // ---------- آواتار محلی (fallback مرورگر برای گراواتار) ----------
    $skylerAvatarFallback = skyler_local_avatar_url();

    if ($isAuthor) {
        // آواتار نویسندهٔ مطلب — اولویت: تنظیم پوسته → avatar.png پوسته → گراواتار
        $avatarUrl = getAuthorAvatar($commenterEmail);
    } else {
        // آواتار بازدیدکننده — گراواتار (با جایگزین محلی در صورت خطا)
        $avatarUrl = 'https://www.gravatar.com/avatar/' . md5(strtolower($commenterEmail)) . '?s=200&d=mp&r=g';
    }

    // ---------- دریافت اطلاعات کامنت (آرایه یا آبجکت) ----------
    $authorName = is_array($c) ? $c['author'] : $c->author;
    $commentId = is_array($c) ? $c['coid'] : $c->coid;
    $commentCreated = is_array($c) ? $c['created'] : $c->created;

    // ---------- قالب‌بندی متن دیدگاه (مثل هستهٔ تایپچو) ----------
    if (is_array($c)) {
        // ردیف خام از دیتابیس: باید مثل هسته پردازش شود (Markdown یا autoP)
        $commentContent = (string)$c['text'];
        if ($commentsWidget && method_exists($commentsWidget, 'autoP')) {
            try {
                if ($options->commentsMarkdown && method_exists($commentsWidget, 'markdown')) {
                    $commentContent = $commentsWidget->markdown($commentContent);
                } else {
                    $commentContent = $commentsWidget->autoP($commentContent);
                }
                if (class_exists('Typecho_Common')) {
                    $commentContent = Typecho_Common::stripTags($commentContent, '<p><br>' . $options->commentsHTMLTagAllowed);
                }
            } catch (Exception $e) {
                // در صورت خطا همان متن خام
            }
        }
    } else {
        $commentContent = $c->content;
    }
    
    // ---------- محاسبه سطح کامنت ----------
    $currentLevel = 0;
    if (is_array($c)) {
        $currentLevel = isset($c['myCustomLevel']) ? $c['myCustomLevel'] : 0;
    } else {
        $currentLevel = $c->levels;
    }

    $is_reply = $currentLevel > 0;
    $reply_class = $is_reply ? ' is-reply' : '';
    
    $reply_style = '';
    if ($is_reply) {
        $margin = ($currentLevel * 30) + 10; 
        $reply_style = 'margin-right: ' . $margin . 'px; border-right: 2px dashed var(--border-color); padding-right: 20px;';
    }
    
    ?>
    
    <li id="comment-<?php echo $commentId; ?>" class="comment-item<?php echo $reply_class; ?>" style="<?php echo $reply_style; ?>">
        
        <!-- ---------- آواتار ---------- -->
        <div class="comment-avatar-wrapper">
            <img src="<?php echo htmlspecialchars($avatarUrl); ?>" alt="<?php echo htmlspecialchars($authorName); ?>" class="avatar"<?php echo ($skylerAvatarFallback !== '' && $avatarUrl !== $skylerAvatarFallback) ? ' onerror="this.onerror=null; this.src=\'' . htmlspecialchars($skylerAvatarFallback, ENT_QUOTES) . '\';"' : ''; ?>>
        </div>
        
        <!-- ---------- بدنه کامنت ---------- -->
        <div class="comment-body">
            <div class="comment-header">
                <div class="comment-meta-group">
                    <span class="comment-author"><?php echo htmlspecialchars($authorName ?? ''); ?></span>
                    <span class="comment-date">
                        <?php 
                        if (function_exists('jalali_date')) {
                            echo '<span class="post-datetime">
                                    <i class="fas fa-calendar-days"></i> ' . 
                                    jalali_date('Y/m/d', $commentCreated) . 
                                    ' &nbsp; <i class="fas fa-clock"></i> ' . 
                                    jalali_date('H:i:s', $commentCreated) . 
                                  '</span>';
                        } else {
                            echo '<span class="post-datetime">
                                    <i class="fas fa-calendar-days" ></i> ' . 
                                    date('Y-m-d', $commentCreated) . 
                                    ' &nbsp; <i class="fas fa-clock"></i> ' . 
                                    date('H:i:s', $commentCreated) . 
                                  '</span>';
                        }
                        ?>                       
                    </span>
                </div>
                
                <!-- ---------- دکمه پاسخ (فقط سطح ۰ و ۱) ---------- -->
                <?php if ($currentLevel < 2): ?>
                    <div class="comment-reply">
                        <a href="#comment-<?php echo $commentId; ?>" 
                           onclick="return TypechoComment.reply('comment-<?php echo $commentId; ?>', <?php echo $commentId; ?>);">پاسخ</a>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="comment-content">
                <?php echo $commentContent; ?>
            </div>
        </div>
    </li>

    <?php
    // ---------- نمایش فرزندان (بازگشتی) ----------
    if ($currentLevel < 2) {
        $db = Typecho_Db::get();
        
        try {
            $childQuery = $db->select()->from('table.comments')
                ->where('cid = ?', (is_array($c) ? $c['cid'] : $c->cid))
                ->where('parent = ?', $commentId)
                ->where('status = ?', 'approved')
                ->order('coid', Typecho_Db::SORT_ASC);

            $children = $db->fetchAll($childQuery);

            if (!empty($children)) {
                foreach ($children as $childRow) {
                    $childRow['myCustomLevel'] = $currentLevel + 1;
                    renderCommentRecursive($childRow, $options, $postAuthorId, $commentsWidget);
                }
            }
        } catch (Exception $e) {
            // خطا نادیده گرفته شود
        }
    }
}
?>

<div id="comments" class="comments-container">
    
    <?php 
        // صفحه‌بندی دیدگاه‌ها از تنظیمات سراسری تایپچو پیروی می‌کند
        $this->comments()->to($comments); 
        $skylerPostAuthorId = (int)$this->authorId;
    ?>
    
    <?php if ($comments->have()): ?>
        
        <hr>

        <ol class="comment-list">
            <?php 
                // ---------- حلقه اصلی (فقط والدین) ----------
                while($comments->next()): 
                
                if ($comments->levels > 0) {
                    continue;
                }
            ?>
                
                <?php renderCommentRecursive($comments, $this->options, $skylerPostAuthorId, $comments); ?>

            <?php endwhile; ?>
        </ol>

        <!-- ---------- صفحه‌بندی نظرات ---------- -->
        <div class="comments-page-navigator-wrapper">
            <?php $comments->pageNav('&laquo;', '&raquo;', 3, '...', array('wrapTag' => 'div', 'wrapClass' => 'comments-page-navigator', 'itemTag' => '', 'textTag' => 'span', 'currentClass' => 'current')); ?>
        </div>

    <?php else: ?>
        
        <!-- ---------- پیام وقتی نظری وجود ندارد ---------- -->
        <h3 class="comments-title">هنوز نظری ثبت نشده است</h3>
        <p class="comments-no-comments">شما اولین نفری هستید که نظر می‌دهید.</p>
    
    <?php endif; ?>

    <!-- ---------- فرم ارسال نظر ---------- -->
    <?php if ($this->allow('comment')): ?>
        
        <div id="<?php $this->respondId(); ?>" class="respond-card">
            
            <!-- ---------- دکمه لغو پاسخ ---------- -->
            <div class="comment-cancel-reply">
                <?php $comments->cancelReply(); ?>
            </div>

            <h3 id="response" class="comments-form-title">ارسال نظر جدید</h3>
            
            <form method="post" action="<?php $this->commentUrl() ?>" id="comment-form" class="comments-respond">
                
                <?php if ($this->user->hasLogin()): ?>
                    
                    <!-- ---------- کاربر وارد شده ---------- -->
                    <p class="comments-login-msg">
                        با نام <a href="<?php $this->options->profileUrl(); ?>"><?php $this->user->screenName(); ?></a> وارد شده‌اید.
                        <a href="<?php $this->options->logoutUrl(); ?>">(خروج) &raquo;</a>
                    </p>
                    <input type="hidden" name="author" value="<?php $this->user->screenName(); ?>">
                    <input type="hidden" name="mail" value="<?php $this->user->mail(); ?>">
                    <input type="hidden" name="url" value="<?php $this->user->url(); ?>">
                
                <?php else: ?>
                    
                    <!-- ---------- فرم ورود اطلاعات کاربر ---------- -->
                    <div class="comments-form-row-2">
                        <p>
                            <label for="author" class="comments-required">نام:</label>
                            <input type="text" name="author" id="author" value="<?php $this->remember('author'); ?>" required />
                        </p>
                        <p>
                            <label for="mail"<?php if ($this->options->commentsRequireMail): ?> class="comments-required"<?php endif; ?>>ایمیل:</label>
                            <input type="email" name="mail" id="mail" value="<?php $this->remember('mail'); ?>"<?php if ($this->options->commentsRequireMail): ?> required<?php endif; ?> />
                        </p>
                    </div>
                    <p>
                        <label for="url" class="comments-optional">سایت:</label>
                        <input type="url" name="url" id="url" placeholder="http://" value="<?php $this->remember('url'); ?>"<?php if ($this->options->commentsRequireUrl): ?> required<?php endif; ?> />
                    </p>
                
                <?php endif; ?>
                
                <!-- ---------- متن نظر ---------- -->
                <p>
                    <label for="textarea" class="comments-required">متن نظر:</label>
                    <textarea rows="5" cols="50" name="text" id="textarea" required><?php $this->remember('text'); ?></textarea>
                </p>
                
                <!-- ---------- دکمه ارسال ---------- -->
                <p class="comments-submit-row">
                    <button type="submit" class="btn-primary">ارسال نظر <i class="fa-solid fa-paper-plane"></i></button>
                </p>
            
            </form>
        </div>
    
    <?php else: ?>
        
        <!-- ---------- نظر دادن غیرفعال است ---------- -->
        <h3 class="comments-title">نظرات بسته شده است.</h3>
    
    <?php endif; ?>

</div>